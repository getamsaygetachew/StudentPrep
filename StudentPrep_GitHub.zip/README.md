# StudentPrep

StudentPrep is a mobile-first educational PWA for Ethiopian students.

## Repository architecture

The GitHub repository contains the core application. Large educational content is intentionally kept outside the repository and imported/downloaded through the Content Manager.

- Question Data ZIP: hosted externally
- Experiments ZIP: hosted externally
- Imported content: stored in the browser/app IndexedDB
- Premium access: separate from content import

## External content setup

Open `js/content-manager.js` and replace the two placeholders in `STUDENTPREP_CONTENT_URLS` with downloadable URLs for your hosted ZIP files:

```js
const URLS = window.STUDENTPREP_CONTENT_URLS = {
  data: 'PASTE_GOOGLE_DRIVE_DATA_ZIP_LINK_HERE',
  experiments: 'PASTE_GOOGLE_DRIVE_EXPERIMENTS_ZIP_LINK_HERE'
};
```

The links must allow the browser to download the ZIP files. A normal Google Drive sharing page may not work as a direct download URL.

## Premium testing

The current package contains the development Premium test flow. Do not use the demo code as production payment verification. Production Premium should be controlled by a backend entitlement system after payment verification.

## IndexedDB

Imported content is stored locally in IndexedDB under database `studentprep-content-v1`, object store `files`. The Content Manager provides an option to delete imported content. Deleting imported content does not grant Premium or change Premium status.

## Important

Do not commit the large question-data or experiments ZIP packages into this repository. Keep this stable package as the baseline before making further feature changes.
