const curriculum = {
  "Physics": {
    "9": [
      "Physics and Human Society",
      "Physical Quantities",
      "Motion in a Straight Line",
      "Force, Work, Energy and Power",
      "Simple Machine",
      "Mechanical Oscillation and Sound Wave",
      "Temperature and Thermometer"
    ],
    "10": [
      "Vector Quantity",
      "Uniformly Accelerated Motion",
      "Elasticity and Static Equilibrium and Rigid Body",
      "Magnetism",
      "Electromagnetic Waves and Geometrical Optics"
    ],
    "11": [
      "Vectors",
      "Motion in One and Two Dimensions",
      "Dynamics",
      "Heat Conduction and Calorimetry",
      "Electrostatics and Electric Circuit",
      "Nuclear Physics"
    ],
    "12": [
      "Application of Physics in Other Fields",
      "2D Motion",
      "Fluid Mechanics",
      "Electromagnetism",
      "Basics of Electrons"
    ]
  },
  "Mathematics": {
    "9": [
      "Further on Set",
      "The Number System",
      "Solving Equation",
      "Solving Inequality",
      "Introduction to Trigonometry",
      "Regular Polygon",
      "Congruency and Similarity",
      "Vectors in 2D",
      "Statistics and Probability"
    ],
    "10": [
      "Polynomial Function",
      "Exponential and Logarithmic Functions",
      "Trigonometric Function",
      "Circles",
      "Solid Figures",
      "Coordinate Geometry"
    ],
    "11": [
      "Relation and Function",
      "Rational Expressions and Rational Function",
      "Matrices",
      "Determinants and Their Properties",
      "Vectors",
      "Transformation of the Plane",
      "Statistics",
      "Probability"
    ],
    "12": [
      "Sequence and Series",
      "Introduction to Calculus",
      "Statistics",
      "Introduction to Linear Programming",
      "Mathematical Application in Business"
    ]
  },
  "Chemistry": {
    "9": [
      "Chemistry and It's Importance",
      "Measurements and Scientific Method",
      "Periodic Classification of Elements",
      "Chemical Bonding"
    ],
    "10": [
      "Chemical Reaction and Stoichiometry",
      "Solutions",
      "Important Inorganic Compounds",
      "Energy Changes and Electrochemistry",
      "Metals and Non Metals",
      "Hydrocarbons and Their Natural Sources"
    ],
    "11": [
      "Atomic Structure and Periodic Properties of the Elements",
      "Chemical Bonding",
      "Physical State of Matter",
      "Chemical Kinetics",
      "Chemical Equilibrium",
      "Some Important Oxygen Containing Organic Compounds"
    ],
    "12": [
      "Acid Base Equilibria",
      "Electrochemistry",
      "Industrial Chemistry",
      "Polymers",
      "Introduction to Environmental Chemistry"
    ]
  },
  "Biology": {
    "9": [
      "Introduction to Biology",
      "Characteristics and Classification of Organisms",
      "Cells",
      "Reproduction",
      "Human Health, Nutrition and Disease",
      "Ecology"
    ],
    "10": [
      "Sub Fields of Biology",
      "Plants",
      "Biochemical Molecules",
      "Human Biology",
      "Ecological Interaction"
    ],
    "11": [
      "Biology and Technology",
      "Animals",
      "Enzymes",
      "Genetics",
      "The Human Body Systems",
      "Population and Natural Resources"
    ],
    "12": [
      "Application of Biology",
      "Microorganisms",
      "Energy Transformation",
      "Evolution",
      "Human Body System",
      "Climate Change Causes and Effects"
    ]
  }
};

window.curriculum = curriculum;
