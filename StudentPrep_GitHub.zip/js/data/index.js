// Lightweight registry initializer. Large question banks are imported by js/content-manager.js.
const subjects={
  biology:{name:'Biology',code:'BIO',stream:'natural'}, chemistry:{name:'Chemistry',code:'CHEM',stream:'natural'}, economics:{name:'Economics',code:'ECO',stream:'social'},
  englishNatural:{name:'English',code:'ENG_NAT',stream:'natural'}, englishSocial:{name:'English',code:'ENG_SOC',stream:'social'}, geography:{name:'Geography',code:'GEO',stream:'social'},
  history:{name:'History',code:'HIST',stream:'social'}, mathsNatural:{name:'Mathematics',code:'MATH',stream:'natural'}, physics:{name:'Physics',code:'PHY',stream:'natural'}, satNatural:{name:'SAT Natural',code:'SAT_NAT',stream:'natural'}
};
Object.values(subjects).forEach(s=>window.registerSubject({...s,questions:[]}));
window.subjects=subjects;
