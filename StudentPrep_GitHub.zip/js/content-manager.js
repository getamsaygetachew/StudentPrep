/* StudentPrep external content manager. Keeps the core app independent of the large content packages. */
(function(){
  const DB='studentprep-content-v1', STORE='files';
  const SUBJECTS={
    'biology.js':['Biology','BIO','natural'],'chemistry.js':['Chemistry','CHEM','natural'],'economics.js':['Economics','ECO','social'],
    'english-natural.js':['English','ENG_NAT','natural'],'english-social.js':['English','ENG_SOC','social'],'geography.js':['Geography','GEO','social'],
    'history.js':['History','HIST','social'],'maths-natural.js':['Mathematics','MATH','natural'],'physics.js':['Physics','PHY','natural'],'sat-natural.js':['SAT Natural','SAT_NAT','natural']
  };
  const URLS=window.STUDENTPREP_CONTENT_URLS={data:'PASTE_GOOGLE_DRIVE_DATA_ZIP_LINK_HERE',experiments:'PASTE_GOOGLE_DRIVE_EXPERIMENTS_ZIP_LINK_HERE'};
  const openDB=()=>new Promise((res,rej)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore(STORE);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
  async function put(k,v){const db=await openDB();return new Promise((res,rej)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).put(v,k);tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}
  async function get(k){const db=await openDB();return new Promise((res,rej)=>{const tx=db.transaction(STORE,'readonly');const r=tx.objectStore(STORE).get(k);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
  async function allKeys(){const db=await openDB();return new Promise((res,rej)=>{const tx=db.transaction(STORE,'readonly');const r=tx.objectStore(STORE).getAllKeys();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
  function u16(v,o){return v.getUint16(o,true)} function u32(v,o){return v.getUint32(o,true)}
  async function unzip(blob){
    const a=new Uint8Array(await blob.arrayBuffer()), v=new DataView(a.buffer); let p=Math.max(0,a.length-65557),e=-1;
    for(let i=a.length-22;i>=p;i--){if(u32(v,i)===0x06054b50){e=i;break}}
    if(e<0)throw Error('Invalid ZIP file.');
    const n=u16(v,e+10), cdSize=u32(v,e+12), cdOff=u32(v,e+16); let pos=cdOff; const out={};
    const dec=async(b)=>new Uint8Array(await new Response(new Blob([b]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());
    for(let i=0;i<n;i++){
      if(u32(v,pos)!==0x02014b50)throw Error('Invalid ZIP directory.');
      const method=u16(v,pos+10), csize=u32(v,pos+20), nsize=u32(v,pos+24), nl=u16(v,pos+28), el=u16(v,pos+30), cl=u16(v,pos+32), lo=u32(v,pos+42);
      const name=new TextDecoder().decode(a.slice(pos+46,pos+46+nl));
      if(!name.endsWith('/')){
        if(u32(v,lo)!==0x04034b50)throw Error('Invalid ZIP entry.');
        const lnl=u16(v,lo+26), lel=u16(v,lo+28), start=lo+30+lnl+lel, comp=a.slice(start,start+csize);
        out[name]=method===0?comp:method===8?await dec(comp):(()=>{throw Error('Unsupported ZIP compression.')})();
        if(nsize && out[name].length!==nsize)throw Error('ZIP extraction failed.');
      }
      pos+=46+nl+el+cl;
    } return out;
  }
  const text=b=>new TextDecoder().decode(b);
  async function importData(file){
    const files=await unzip(file), entries=Object.entries(files).filter(([n])=>/^js\/data\/[^/]+\.js$/i.test(n)&&!/index\.js$/i.test(n));
    if(!entries.length)throw Error('This is not a StudentPrep question-data ZIP.');
    for(const [name,bytes] of entries){await put('data:'+name.split('/').pop(),text(bytes));}
    await loadData();
    return entries.length;
  }
  async function loadData(){
    const keys=await allKeys(); let count=0;
    for(const k of keys.filter(x=>String(x).startsWith('data:'))){const filename=String(k).slice(5), src=await get(k); const url=URL.createObjectURL(new Blob([src],{type:'text/javascript'}));
      try{const mod=await import(url);const meta=SUBJECTS[filename];if(meta&&Array.isArray(mod.default)){window.registerSubject({name:meta[0],code:meta[1],stream:meta[2],questions:mod.default});count+=mod.default.length}}finally{URL.revokeObjectURL(url)}
    }
    window.dispatchEvent(new CustomEvent('studentprep-content-changed',{detail:{type:'data',count}})); return count;
  }
  async function importExperiments(file){
    const files=await unzip(file), jsonEntry=Object.entries(files).find(([n])=>n==='experiments/experiments.json');
    if(!jsonEntry)throw Error('This is not a StudentPrep experiments ZIP.');
    await put('experiments:json',text(jsonEntry[1])); let count=0;
    for(const [name,bytes] of Object.entries(files)) if(/^experiments\/simulations\/[^/]+\.html$/i.test(name)){await put('experiments:'+name.slice('experiments/'.length),bytes);count++}
    window.dispatchEvent(new CustomEvent('studentprep-content-changed',{detail:{type:'experiments',count}}));
    return count;
  }
  async function deleteImportedContent(){
    const db=await openDB();
    await new Promise((res,rej)=>{
      const tx=db.transaction(STORE,'readwrite');
      tx.objectStore(STORE).clear();
      tx.oncomplete=res; tx.onerror=()=>rej(tx.error);
    });
    try{db.close()}catch(e){}
    window.dispatchEvent(new CustomEvent('studentprep-content-changed',{detail:{type:'deleted'}}));
    return true;
  }
  async function getExperiment(path){return get('experiments:'+path)}
  function addUI(){
    if(document.getElementById('contentBtn'))return;
    const side=document.getElementById('sideMenu'); if(!side)return;
    const b=document.createElement('button');b.id='contentBtn';b.innerHTML='📦 Download / Import Content';side.appendChild(b);b.onclick=()=>{window.closeMenu?.();document.getElementById('contentModal').classList.add('open');refreshStatus()};
    const m=document.createElement('div');m.id='contentModal';m.innerHTML=`<div class="contentBackdrop"></div><div class="contentBox"><div class="contentHead"><b>StudentPrep Content</b><button id="contentClose">×</button></div><p class="contentIntro">Download the two content packages after installing the app. Free and Premium users can download them.</p><div class="contentItem"><div><b>📚 Question Data</b><small id="dataStatus">Not installed</small></div><div class="contentBtns"><a id="dataDownload" class="contentBtn" target="_blank" rel="noopener">Download</a><button id="dataImport" class="contentBtn">Import ZIP</button><input id="dataFile" type="file" accept=".zip,application/zip" hidden></div></div><div class="contentItem"><div><b>🧪 Experiments</b><small id="expStatus">Not installed</small></div><div class="contentBtns"><a id="expDownload" class="contentBtn" target="_blank" rel="noopener">Download</a><button id="expImport" class="contentBtn">Import ZIP</button><input id="expFile" type="file" accept=".zip,application/zip" hidden></div></div><div class="contentNote">After importing, the content is saved on this device. You only need to import each package once.</div><button id="contentDelete" class="contentBtn contentDeleteBtn" style="width:100%;margin-top:10px;background:#b42318">Delete Imported Content</button></div>`;document.body.appendChild(m);
    document.getElementById('contentClose').onclick=()=>m.classList.remove('open');m.querySelector('.contentBackdrop').onclick=()=>m.classList.remove('open');
    document.getElementById('contentDelete').onclick=async()=>{if(!confirm('Delete all imported question data and experiments from this device? Your Premium status will not change.'))return;try{await deleteImportedContent();alert('Imported content deleted.');location.reload()}catch(e){alert('Delete failed: '+e.message)}};
    document.getElementById('dataDownload').href=URLS.data;document.getElementById('expDownload').href=URLS.experiments;
    document.getElementById('dataImport').onclick=()=>document.getElementById('dataFile').click();document.getElementById('expImport').onclick=()=>document.getElementById('expFile').click();
    document.getElementById('dataFile').onchange=async e=>handle(e.target.files[0],importData,'dataStatus','Question data');document.getElementById('expFile').onchange=async e=>handle(e.target.files[0],importExperiments,'expStatus','Experiments');
    refreshStatus();
  }
  async function handle(file,fn,id,label){if(!file)return;const el=document.getElementById(id);el.textContent='Importing…';try{const n=await fn(file);el.textContent=`Installed ✓ (${n.toLocaleString()} items)`;alert(`${label} imported successfully.`)}catch(err){console.error(err);el.textContent='Import failed';alert('Import failed: '+err.message)}}
  async function refreshStatus(){try{const keys=await allKeys();document.getElementById('dataStatus').textContent=keys.some(k=>String(k).startsWith('data:'))?'Installed ✓':'Not installed';document.getElementById('expStatus').textContent=keys.includes('experiments:json')?'Installed ✓':'Not installed'}catch(e){}}
  window.StudentPrepContent={importData,importExperiments,getExperiment,loadData,deleteImportedContent,URLS};
  document.addEventListener('DOMContentLoaded',async()=>{addUI();try{await loadData()}catch(e){console.error('Saved content load failed',e)}});
})();
