/* StudentPrep Premium access layer
   Phase 1: local freemium controls. Production payments/entitlements should
   replace the demo activation with server-side verification.
*/
(function(){
  const FREE_QUESTION_LIMIT=20;
  const FREE_CHAPTER_QUESTION_LIMIT=10;
  const FREE_YEAR_QUESTION_LIMIT=20;
  const FREE_SAVED_EXAMS_LIMIT=3;
  const FREE_PLAN_LIMIT=3;
  const FREE_EXPERIMENT_LIMIT=3;
  const FREE_UNIT_LIMIT=2;
  const PREMIUM_KEY='studentPrepPremium_v2';
  const isPremium=()=>localStorage.getItem(PREMIUM_KEY)==='true';
  const setPremium=v=>{localStorage.setItem(PREMIUM_KEY,v?'true':'false');updatePremiumUI();window.dispatchEvent(new CustomEvent('studentprep-premium-changed',{detail:{active:!!v}}));};
  function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function openPremium(){
    let m=document.getElementById('premiumModal');
    if(!m){
      document.body.insertAdjacentHTML('beforeend',`<div id="premiumModal" aria-hidden="true"><div class="premiumDialog" role="dialog" aria-modal="true" aria-labelledby="premiumTitle">
        <div class="premiumHead"><div><span class="eyebrow">STUDENTPREP PREMIUM</span><h2 id="premiumTitle">Unlock the full preparation experience</h2></div><button id="premiumClose" class="premiumClose" aria-label="Close">×</button></div>
        <p class="premiumLead">Free access stays useful. Premium removes the limits and unlocks the complete content library.</p>
        <div class="premiumFeatures">
          <div><b>📚 Full questions</b><span>Unlimited question access</span></div>
          <div><b>📝 Full exams</b><span>All exam sets and longer sessions</span></div>
          <div><b>💾 Exam Saver</b><span>Unlimited unfinished exams</span></div>
          <div><b>📅 Study Planning</b><span>Unlimited plans and full planning content</span></div>
          <div><b>🧪 Experiments</b><span>All interactive experiments</span></div>
          <div><b>📖 Notes</b><span>Full notes library when released</span></div>
        </div>
        <div class="premiumStatus" id="premiumStatus"></div>
        <div class="premiumActions"><button class="softBtn" id="premiumFreeBtn">Continue Free</button><button class="primary" id="premiumActivateBtn">Activate Premium</button></div>
        <div class="premiumDemo"><details><summary>Developer test activation</summary><p>For testing only. This will be replaced by real payment/server verification before launch.</p><label>Test code<input id="premiumCode" placeholder="Paste premium test code"></label><button class="softBtn" id="premiumCodeBtn">Activate test access</button><button class="softBtn" id="premiumResetBtn" style="display:none;margin-top:8px;width:100%">Reset to Free Plan</button></details></div>
      </div></div>`);
      m=document.getElementById('premiumModal');
      document.getElementById('premiumClose').onclick=closePremium;
      document.getElementById('premiumFreeBtn').onclick=()=>{setPremium(false);closePremium();};
      document.getElementById('premiumActivateBtn').onclick=()=>{alert('Premium payment will be connected here. Use the developer test activation below to test premium access now.');};
      document.getElementById('premiumCodeBtn').onclick=()=>{if(document.getElementById('premiumCode').value.trim()==='STUDENTPREP-PREMIUM-DEMO'){setPremium(true);closePremium();alert('Premium test access activated on this device.');}else alert('Invalid test code.');};
      document.getElementById('premiumResetBtn').onclick=()=>{setPremium(false);updatePremiumUI();alert('Free plan restored. Premium locks are active again.');};
      m.onclick=e=>{if(e.target===m)closePremium();};
    }
    updatePremiumUI();m.classList.add('open');m.setAttribute('aria-hidden','false');
  }
  function closePremium(){const m=document.getElementById('premiumModal');if(m){m.classList.remove('open');m.setAttribute('aria-hidden','true');}}
  function updatePremiumUI(){
    const b=document.getElementById('premiumBtn'); if(b)b.textContent=isPremium()?'★ Premium':'★ Premium';
    const s=document.getElementById('premiumStatus'); if(s)s.innerHTML=isPremium()?'<b>Premium active on this device.</b><span>All local limits are unlocked.</span>':'<b>Free plan active.</b><span>Questions: '+FREE_QUESTION_LIMIT+' per session · first '+FREE_UNIT_LIMIT+' non-empty units per grade/year · '+FREE_YEAR_QUESTION_LIMIT+' per year · Exam Saver: '+FREE_SAVED_EXAMS_LIMIT+' · Plans: '+FREE_PLAN_LIMIT+' · Experiments: '+FREE_EXPERIMENT_LIMIT+'</span>';
    const r=document.getElementById('premiumResetBtn'); if(r)r.style.display=isPremium()?'block':'none';
  }
  function guard(feature){if(isPremium())return true;openPremium();return false;}
  window.StudentPrepAccess={isPremium,setPremium,openPremium,closePremium,guard,limits:{questions:FREE_QUESTION_LIMIT,chapterQuestions:FREE_CHAPTER_QUESTION_LIMIT,yearQuestions:FREE_YEAR_QUESTION_LIMIT,savedExams:FREE_SAVED_EXAMS_LIMIT,plans:FREE_PLAN_LIMIT,experiments:FREE_EXPERIMENT_LIMIT,freeUnits:FREE_UNIT_LIMIT}};
  window.addEventListener('DOMContentLoaded',()=>{document.getElementById('premiumBtn')?.addEventListener('click',openPremium);updatePremiumUI();});
})();
