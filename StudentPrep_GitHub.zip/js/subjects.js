const subjectRegistry = {};

function registerSubject({code,name,stream="natural",questions=[]}) {
  subjectRegistry[code] = {code,name,stream,questions:Array.isArray(questions)?questions:[]};
}

function htmlEscape(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

function renderContent(content) {
  if (!Array.isArray(content)) return htmlEscape(content ?? "");
  return content.map(part => {
    const value = String(part ?? "");
    if (/^images\//i.test(value) || /\.(png|jpe?g|gif|webp|svg)$/i.test(value)) {
      return `<img class="question-image" src="${encodeURI(value)}" alt="Question image">`;
    }
    return htmlEscape(value);
  }).join("<br>");
}

function normalizeQuestion(q) {
  // Generated database format: content[], choices[{content[], isCorrect}], images[]
  if (Array.isArray(q?.content)) {
    const choices = Array.isArray(q.choices) ? q.choices.map(c => renderContent(c.content)) : [];
    const answer = Array.isArray(q.choices) ? q.choices.findIndex(c => c && c.isCorrect === true) : -1;
    const imageParts = (q.images || []).map(path => `<img class="question-image" src="${encodeURI(path)}" alt="Question image">`).join("");
    return {
      ...q,
      grade:q.grade==null?null:Number(q.grade),
      unit:q.unit==null?null:Number(q.unit),
      answer,
      question: renderContent(q.content) + imageParts,
      choices,
      explanation: renderContent(q.explanation || "")
    };
  }

  // Original StudentPrep format.
  return {
    ...q,
    grade:q.grade==null?null:Number(q.grade),
    unit:q.unit==null?null:Number(q.unit),
    answer:Number(q.answer),
    choices:Array.isArray(q.choices)?q.choices:[],
    explanation:q.explanation||""
  };
}

function getQuestionsForUnit(subject,grade,unit) {
  return subject.questions.map(normalizeQuestion).filter(q=>q.grade===Number(grade)&&q.unit===Number(unit));
}
function getQuestionsForYear(subject,year) {
  const y=String(year).startsWith("YEAR_")?String(year):"YEAR_"+year;
  return subject.questions.map(normalizeQuestion).filter(q=>q.year===y);
}
function getMixedQuestions(subject,count=60) {
  const a=subject.questions.map(normalizeQuestion);
  for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}
  return a.slice(0,Math.min(count,a.length));
}

// Expose the registry to module-based loaders used by the app.
window.subjectRegistry = subjectRegistry;
window.registerSubject = registerSubject;
window.normalizeQuestion = normalizeQuestion;
