const subjectRegistry=window.subjectRegistry;
const curriculum=window.curriculum;
const normalizeQuestion=window.normalizeQuestion;
let currentSubject=null,currentQuestions=[],answers=[],reviewed=new Set(),examMode='practice',pending=null,startTime=0,timerHandle=null,paused=false,pauseAt=0,currentView='homeView';
const $=id=>document.getElementById(id);
const icons={BIO:'🧬',CHEM:'⚗️',PHY:'⚛️',MATH:'📐',ENG_NAT:'📘',ENG_SOC:'📘',ECO:'📈',GEO:'🗺️',HIST:'🏛️',SAT_NAT:'🧠'};
const store={get:k=>JSON.parse(localStorage.getItem(k)||'[]'),set:(k,v)=>localStorage.setItem(k,JSON.stringify(v))};
const allQuestions=s=>s.questions.map(q=>normalizeQuestion(q,s.name));

// Topic-to-curriculum mapping for the subjects whose exam bank does not carry
// grade/unit fields. A topic can intentionally feed more than one curriculum
// unit when the same concept is taught at multiple grades.
const unitTopicMap={
  Physics:{
    9:{1:[],2:['PHY_MEASUREMENT'],3:['PHY_KINEMATICS'],4:['PHY_WORK','PHY_FORCE'],5:['PHY_DYNAMICS'],6:['PHY_SOUND'],7:['PHY_THERMODYNAMICS']},
    10:{1:['PHY_VECTOR'],2:['PHY_KINEMATICS'],3:['PHY_FORCE','PHY_DYNAMICS'],4:['PHY_ELECTROMAGNETIC','PHY_CURRENT'],5:['PHY_OPTICS','PHY_ELECTROMAGNETIC']},
    11:{1:['PHY_VECTOR'],2:['PHY_KINEMATICS','PHY_MOMENTUM'],3:['PHY_DYNAMICS','PHY_FORCE'],4:['PHY_THERMODYNAMICS'],5:['PHY_CURRENT','PHY_ELECTROMAGNETIC'],6:['PHY_PHOTON']},
    12:{1:['PHY_PHOTON'],2:['PHY_KINEMATICS','PHY_MOMENTUM'],3:['PHY_FLUID','PHY_PRESSURE','PHY_DENSITY'],4:['PHY_ELECTROMAGNETIC','PHY_CURRENT'],5:['PHY_PHOTON']}
  },
  Chemistry:{
    9:{1:['CHEMI_SCIENCE'],2:['CHEMI_MEASUREMENTS'],3:['CHEMI_PERIODIC_TABLE'],4:['CHEMI_BONDING']},
    10:{1:['CHEMI_REACTIONS'],2:['CHEMI_SOLLUTIONS'],3:['CHEMI_INORGANIC'],4:['CHEMI_ELECTROCHEMISTRY'],5:['CHEMI_METALS_NONMETALS'],6:['CHEMI_HYDROCARBONS']},
    11:{1:['CHEMI_ATOM','CHEMI_QUANTUM'],2:['CHEMI_BONDING'],3:['CHEMI_PHYSICAL_STATES'],4:['CHEMI_REACTIONS'],5:[],6:['CHEMI_HYDROCARBONS']},
    12:{1:[],2:['CHEMI_ELECTROCHEMISTRY'],3:['CHEMI_APPLICATIONS'],4:['CHEMI_POLYMER'],5:['CHEMI_INORGANIC']}
  },
  Biology:{
    9:{1:['BIO_SCIENCE'],2:['BIO_CLASSIFICATION'],3:['BIO_CELL'],4:['BIO_PLANTS'],5:['BIO_HUMAN'],6:['BIO_ECOLOGY']},
    10:{1:['BIO_SCIENCE'],2:['BIO_PLANTS'],3:['BIO_MOLECULES'],4:['BIO_HUMAN'],5:['BIO_ECOLOGY','BIO_BEHAVIOUR']},
    11:{1:['BIO_SCIENCE'],2:['BIO_PLANTS','BIO_BEHAVIOUR'],3:['BIO_ENZYMES'],4:['BIO_GENETICS'],5:['BIO_HUMAN'],6:['BIO_ECOLOGY']},
    12:{1:['BIO_SCIENCE'],2:['BIO_MICRO_ORGANISM'],3:['BIO_ENERGY_TRANSFORMATION'],4:['BIO_EVOLUTION'],5:['BIO_HUMAN'],6:['BIO_ECOLOGY']}
  },
  Mathematics:{
    9:{1:['MATH_SETS','MATH_LOGIC'],2:['MATH_NUMBER_SYSTEM'],3:['MATH_EQUATIONS'],4:['MATH_INEQUALTIES'],5:['MATH_TRIGOMETRIC'],6:['MATH_POLYGONS'],7:['MATH_SIMILARITY','MATH_GEOMETRY'],8:['MATH_VECTORS'],9:['MATH_STATISTICS','MATH_PROBABILITY']},
    10:{1:['MATH_FUNCTIONS'],2:['MATH_FUNCTIONS'],3:['MATH_TRIGOMETRIC'],4:['MATH_GEOMETRY'],5:['MATH_GEOMETRY'],6:['MATH_GEOMETRY']},
    11:{1:['MATH_FUNCTIONS','MATH_COMPLEX_NUMBERS'],2:['MATH_FUNCTIONS'],3:['MATH_MATRICS'],4:['MATH_MATRICS'],5:['MATH_VECTORS'],6:['MATH_TRANSFORMATION_PLANE'],7:['MATH_STATISTICS'],8:['MATH_PROBABILITY']},
    12:{1:['MATH_SEQUENCE'],2:['MATH_CALCULUS'],3:['MATH_STATISTICS'],4:['MATH_INEQUALTIES','MATH_APPLICATION'],5:['MATH_APPLICATION']}
  }
};

function show(id,push=true){const target=$(id);if(!target)return;if(currentView===id&&!push)return;document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));target.classList.add('active');currentView=id;document.body.classList.toggle('exam-active',id==='practiceView');if(push)history.pushState({view:id},'',`#${id.replace('View','')}`);if(id==='practiceView')document.body.classList.add('exam-active');else document.body.classList.remove('exam-active');window.scrollTo({top:0,behavior:'instant'});closeMenu();}
function goHome(){clearInterval(timerHandle);timerHandle=null;paused=false;document.body.classList.remove('exam-active');show('homeView');}
function openStream(stream){const list=Object.values(subjectRegistry).filter(s=>s.stream===stream);$('streamTitle').textContent=stream==='natural'?'Natural Science':'Social Science';$('streamSubtitle').textContent=`All ${stream==='natural'?'Natural':'Social'} stream subjects`;$('subjectList').innerHTML=list.map(s=>`<button class="subjectCard" data-code="${s.code}"><span class="subjectIcon">${icons[s.code]||'📚'}</span><div><b>${s.name}</b><small>${s.questions.length.toLocaleString()} questions</small></div><span class="arrow">›</span></button>`).join('');$('subjectList').querySelectorAll('.subjectCard').forEach(b=>b.onclick=()=>selectSubject(b.dataset.code));show('streamView');}
function selectSubject(code){currentSubject=subjectRegistry[code];if(!currentSubject)return;$('subjectName').textContent=currentSubject.name;$('subjectIcon').textContent=icons[code]||'📚';$('subjectStream').textContent=currentSubject.stream==='natural'?'NATURAL SCIENCE':'SOCIAL SCIENCE';$('subjectCount').textContent=`${currentSubject.questions.length.toLocaleString()} questions`;renderBrowse('chapter');show('subjectView');}
function chapterMap(){return curriculum[currentSubject?.name]||{}};
function renderHome(){for(const stream of ['natural','social']){const list=Object.values(subjectRegistry).filter(s=>s.stream===stream);$(`${stream}Count`).textContent=`${list.length} subjects`;renderHomeStream(stream,'chapter');}}
function renderHomeStream(stream,type){const id=stream==='natural'?'homeNaturalSubjects':'homeSocialSubjects';const list=Object.values(subjectRegistry).filter(s=>s.stream===stream);if(type==='year'){$(id).innerHTML=list.map(s=>{const years=[...new Set(s.questions.map(q=>String(q.year||'').replace(/^YEAR_/,'')).filter(Boolean))].sort((a,b)=>Number(a)-Number(b));return `<div class="homeYearGroup"><b>${icons[s.code]||'📚'} ${s.name}</b><div class="homeYearChips">${years.map(y=>`<button class="homeYearChip" data-code="${s.code}" data-year="${y}">${y}</button>`).join('')}</div></div>`}).join('');$(id).querySelectorAll('.homeYearChip').forEach(b=>b.onclick=()=>{const s=subjectRegistry[b.dataset.code];queueStart(getQuestionsForYear(s,b.dataset.year),`${s.name} • ${b.dataset.year}`,'year');});return;}
$(id).innerHTML=list.map(s=>`<button class="homeSubjectCard" data-code="${s.code}"><span class="subjectIcon">${icons[s.code]||'📚'}</span><div><b>${s.name}</b><small>${s.questions.length.toLocaleString()} questions</small><em>By chapter · By year</em></div><span class="arrow">›</span></button>`).join('');$(id).querySelectorAll('.homeSubjectCard').forEach(b=>b.onclick=()=>selectSubject(b.dataset.code));}
function renderBrowse(type){
  $('browseChapter').classList.toggle('active',type==='chapter');
  $('browseYear').classList.toggle('active',type==='year');
  if(type==='year'){showYearsPanel();return;}

  const map=chapterMap();
  const q=allQuestions(currentSubject);
  buildUniqueUnitPlacement();
  let grades=Object.keys(map).sort((a,b)=>Number(a)-Number(b));
  // Prefer the real grade values carried by the assigned question files.
  const dataGrades=[...new Set(q.map(x=>x.grade).filter(x=>x!=null).map(Number))].sort((a,b)=>a-b).map(String);
  if(dataGrades.length) grades=dataGrades;
  if(!grades.length) grades=['9','10','11','12'];

  const yearKey=`studentPrepChapterYear:${currentSubject.code}`;
  const savedYears=JSON.parse(localStorage.getItem(yearKey)||'{}');
  const normalizeYear=y=>String(y??'').replace(/^YEAR_/,'').trim();
  const gradeOf=item=>item.grade!=null?Number(item.grade):uniqueUnitPlacement.get(`${currentSubject.code}:${item.id}`)?.grade;
  const unitOf=item=>item.unit!=null?Number(item.unit):uniqueUnitPlacement.get(`${currentSubject.code}:${item.id}`)?.unit;
  const yearMatches=(itemYear, selectedYear)=>{
    if(selectedYear==='all') return true;
    const raw=normalizeYear(itemYear), sel=normalizeYear(selectedYear);
    if(raw===sel) return true;
    if(/^\d{4}\/\d{2}$/.test(sel)){
      const [start,end]=sel.split('/');
      return raw===start || raw===String(Number(start)+1) || raw===String(2000+Number(end));
    }
    return false;
  };
  const getGradeQuestions=grade=>q.filter(item=>gradeOf(item)===Number(grade));
  const getUnitQuestions=(grade,unit,year)=>q.filter(item=>gradeOf(item)===Number(grade)&&unitOf(item)===Number(unit)&&yearMatches(item.year,year));

  $('subjectBrowse').innerHTML=grades.map(g=>{
    const units=(map[g]||[]);
    const gradeQuestions=getGradeQuestions(g);
    const years=[...new Set(gradeQuestions.map(x=>normalizeYear(x.year)).filter(Boolean))].sort((a,b)=>Number(a)-Number(b));
    const stored=savedYears[String(g)];
    const selected=(stored==='all'||years.includes(String(stored)))?String(stored||'all'):'all';
    const unitCount=Math.max(units.length,...gradeQuestions.map(x=>unitOf(x)||0),0);
    const unitLabels=Array.from({length:unitCount},(_,i)=>units[i]||`Unit ${i+1}`);
    const unitData=unitLabels.map((label,i)=>{
      const unitNum=i+1;
      const count=getUnitQuestions(g,unitNum,selected).length;
      const disabled=count===0;
      return {unitNum,label,count,disabled};
    });
    // Free users get complete access to only the first two non-empty units
    // for each grade/year selection. Every remaining unit is Premium.
    const freeUnitLimit=window.StudentPrepAccess?.limits?.freeUnits||2;
    const freeUnitNums=new Set(unitData.filter(u=>!u.disabled).slice(0,freeUnitLimit).map(u=>u.unitNum));
    const unitRows=unitData.map(({unitNum,label,count,disabled})=>{
      const premiumLocked=!window.StudentPrepAccess?.isPremium?.()&&!disabled&&!freeUnitNums.has(unitNum);
      const locked=disabled;
      // Only empty units are truly disabled. Premium units remain clickable so the access gate always runs.
      return `<button type="button" class="unitCard ${locked?'disabled':''} ${premiumLocked?'premiumLocked':''}" data-action="unit" data-grade="${g}" data-unit="${unitNum}" data-year="${selected}" ${locked?'disabled aria-disabled="true"':''}>
        <span class="gradeBubble">${g}</span>
        <span class="unitInfo"><b>Unit ${unitNum}</b><small>${label}</small><i><em style="width:${count?Math.max(8,Math.min(100,count*8)):0}%"></em></i></span>
        <strong>${count} ques ${premiumLocked?'🔒':''}</strong><span class="unitArrow">${premiumLocked?'🔒':'›'}</span>
      </button>`;
    }).join('');
    return `<section class="gradeBlock chapterGrade" data-grade-block="${g}" data-selected-year="${selected}">
      <div class="gradeTitle"><span>Grade ${g}</span><small>${gradeQuestions.length.toLocaleString()} questions</small></div>
      <div class="chapterYears" role="tablist" aria-label="Grade ${g} years">
        <button type="button" class="yearChip ${selected==='all'?'active':''}" aria-selected="${selected==='all'?'true':'false'}" data-action="year" data-grade="${g}" data-year="all">All</button>
        ${years.map(y=>{const display=academicYearLabel(y);return `<button type="button" class="yearChip ${selected===y?'active':''}" aria-selected="${selected===y?'true':'false'}" data-action="year" data-grade="${g}" data-year="${y}">${display}</button>`}).join('')}
      </div>
      <div class="unitGrid" data-units-for="${g}">${unitRows || '<div class="emptyState">No units available.</div>'}</div>
    </section>`;
  }).join('');

  // One delegated handler makes year buttons reliable after every unit re-render.
  $('subjectBrowse').onclick=function(event){
    const btn=event.target.closest('[data-action]');
    if(!btn || !$('subjectBrowse').contains(btn)) return;
    event.preventDefault();
    event.stopPropagation();
    const action=btn.dataset.action;
    const grade=Number(btn.dataset.grade);
    if(action==='year'){
      const year=String(btn.dataset.year);
      savedYears[String(grade)]=year;
      localStorage.setItem(yearKey,JSON.stringify(savedYears));
      renderBrowse('chapter');
      requestAnimationFrame(()=>{
        const block=$(`[data-grade-block="${grade}"]`);
        if(block) block.scrollIntoView({block:'nearest',behavior:'smooth'});
      });
      return;
    }
    if(action==='unit'){
      if(btn.classList.contains('premiumLocked')){window.StudentPrepAccess?.openPremium?.();return;}
      if(btn.disabled)return;
      const selected=getUnitQuestions(grade,Number(btn.dataset.unit),String(btn.dataset.year));
      const label=btn.querySelector('.unitInfo small')?.textContent||`Unit ${btn.dataset.unit}`;
      const yearLabel=btn.dataset.year==='all'?'All years':academicYearLabel(btn.dataset.year);
      queueStart(selected,`${currentSubject.name} • Grade ${grade} • ${yearLabel} • ${label}`,'chapter',{grade,unit:Number(btn.dataset.unit)});
    }
  };
}
function academicYearLabel(y){const n=Number(String(y).replace(/^YEAR_/,'').trim());return Number.isFinite(n)?`${n-1}/${String(n).slice(-2)}`:String(y);}
function prettyChapter(ch){return String(ch||'').replace(/^(BIO|CHEMI|PHY|MATH|GEO|HISTORY|ECO|ENG|SAT)_?/,'').toLowerCase().split('_').map(x=>x.charAt(0).toUpperCase()+x.slice(1)).join(' ');}
function showYearsPanel(){const q=allQuestions(currentSubject);const ys=[...new Set(q.map(x=>String(x.year||'').replace(/^YEAR_/,'')).filter(Boolean))].sort((a,b)=>Number(a)-Number(b));$('subjectBrowse').innerHTML=ys.length?`<div class="yearGrid">${ys.map(y=>{const count=getQuestionsForYear(currentSubject,y).length;return `<button class="yearCard" data-year="${y}"><b>${y}</b><span>${count} questions</span></button>`}).join('')}</div>`:'<div class="emptyState">No year information is available.</div>';$('subjectBrowse').querySelectorAll('.yearCard').forEach(b=>b.onclick=()=>queueStart(getQuestionsForYear(currentSubject,b.dataset.year),`${currentSubject.name} • ${b.dataset.year}`,'year'));}
// Keep each question in one unique curriculum unit. The original question bank is
// chapter-tagged rather than grade/unit tagged, so we preserve the existing
// curriculum placement order and assign a question to the first matching unit only.
const uniqueUnitPlacement = new Map();
function buildUniqueUnitPlacement(){
  // Each chapter tag has one canonical Grade + Unit location. The first
  // curriculum occurrence is the original position and is never duplicated.
  const subject=currentSubject;
  if(!subject)return;
  const map=unitTopicMap[subject.name]||{};
  const qs=allQuestions(subject);
  const assignedChapters=new Set();
  Object.keys(map).sort((a,b)=>Number(a)-Number(b)).forEach(g=>{
    const units=map[g]||{};
    Object.keys(units).sort((a,b)=>Number(a)-Number(b)).forEach(u=>{
      (units[u]||[]).forEach(tag=>{
        if(assignedChapters.has(tag))return;
        const matching=qs.filter(q=>String(q.chapter||'')===tag);
        matching.forEach(q=>uniqueUnitPlacement.set(`${subject.code}:${q.id}`,{grade:Number(g),unit:Number(u)}));
        if(matching.length)assignedChapters.add(tag);
      });
    });
  });
  // Keep chapter-tagged questions unique even when a legacy tag was not in the map.
  const fallback={
    Mathematics:{'MATH_COMPLEX_NUMBERS':{grade:11,unit:1}},
  };
  qs.forEach(q=>{
    const key=`${subject.code}:${q.id}`;
    if(uniqueUnitPlacement.has(key))return;
    const fp=fallback[subject.name]?.[String(q.chapter||'')];
    if(fp) uniqueUnitPlacement.set(key,fp);
    else if(q.grade!=null&&q.unit!=null) uniqueUnitPlacement.set(key,{grade:Number(q.grade),unit:Number(q.unit)});
  });
}
function getQuestionsForUnit(subject,grade,unit){
  if(!subject)return [];
  const previous=currentSubject;
  currentSubject=subject;
  buildUniqueUnitPlacement();
  currentSubject=previous;
  return allQuestions(subject).filter(q=>{
    const p=uniqueUnitPlacement.get(`${subject.code}:${q.id}`);
    return p?.grade===Number(grade)&&p?.unit===Number(unit);
  });
}
function getQuestionsForYear(subject,year){const y=String(year).replace(/^YEAR_/,'');return allQuestions(subject).filter(q=>String(q.year).replace(/^YEAR_/,'')===y);}
function queueStart(q,title,scope='session',meta=null){
  if(!Array.isArray(q)||!q.length){alert('No questions are assigned to this selection yet.');return;}
  const premium=window.StudentPrepAccess?.isPremium?.();
  // Defense-in-depth: chapter access is checked from explicit grade/unit metadata.
  if(!premium && scope==='chapter' && currentSubject){
    const grade=Number(meta?.grade);
    const unitNum=Number(meta?.unit);
    if(Number.isFinite(grade)&&Number.isFinite(unitNum)){
      const allGrade=allQuestions(currentSubject).filter(item=>Number(item.grade)===grade);
      const unitNums=[...new Set(allGrade.map(item=>Number(item.unit)).filter(Number.isFinite))].sort((a,b)=>a-b);
      const allowed=new Set(unitNums.slice(0,window.StudentPrepAccess?.limits?.freeUnits||2));
      if(!allowed.has(unitNum)){window.StudentPrepAccess?.openPremium?.();return;}
    }
  }
  const sessionLimit=window.StudentPrepAccess?.limits?.questions||20;
  const yearLimit=window.StudentPrepAccess?.limits?.yearQuestions||20;
  // Chapter mode is controlled by whole-unit access in renderBrowse().
  // If a free unit is opened, the user can practice every question in that unit.
  let limit=sessionLimit;
  if(scope==='chapter') limit=q.length;
  if(scope==='year') limit=Math.min(sessionLimit,yearLimit);
  const selected=premium?q:q.slice(0,limit);
  if(!premium&&scope==='year'&&q.length>limit){
    const ok=confirm(`Free plan: ${q.length} questions are available in this year. Only ${limit} will be available. Choose Premium for full access?`);
    if(!ok){window.StudentPrepAccess?.openPremium?.();return;}
  }
  pending={id:`${Date.now()}-${Math.random().toString(36).slice(2,8)}`,q:selected,title,scope};
  $('modeSubtitle').textContent=`${selected.length} questions selected • ${title}${!premium&&q.length>limit?' • Free limit':''}`;
  show('modeView');
}

function begin(mode){if(!pending||!pending.q.length)return;examMode=mode;currentQuestions=pending.q;answers=Array(currentQuestions.length).fill(null);reviewed=new Set();startTime=Date.now();paused=false;pauseAt=0;clearInterval(timerHandle);timerHandle=setInterval(timer,1000);$('practiceTitle').textContent=pending.title;$('practiceMode').textContent=mode==='practice'?'PRACTICE MODE':mode==='quick'?'QUICK MODE':'EXAM STYLE';$('practiceHint').textContent=mode==='exam'?'Choose answers freely. Answers and explanations are revealed after you finish.':mode==='practice'?'Click an answer to see the correct answer and explanation immediately.':'Click an answer to see the correct answer immediately.';history.replaceState({view:'practiceView'},'', '#practice');show('practiceView',false);renderAll();saveSession();timer();}
function elapsed(){return paused?pauseAt-startTime:Date.now()-startTime}
function timer(){const s=Math.floor(elapsed()/1000);$('timer').textContent=String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}

function typesetMath(root=document){
  const run=()=>{
    const mj=window.MathJax;
    if(!mj?.typesetPromise)return;
    mj.typesetPromise([root]).catch(()=>{});
  };
  const mj=window.MathJax;
  if(mj?.startup?.promise){
    mj.startup.promise.then(run).catch(()=>{});
  }else if(mj?.typesetPromise){
    requestAnimationFrame(run);
  }
}

function renderAll(){const answeredN=answers.filter(Boolean).length;const checkedN=answers.filter(a=>a?.checked).length;const score=answers.filter((a,i)=>a?.checked&&a.chosen===currentQuestions[i].answer).length;$('progress').textContent=`${answeredN} of ${currentQuestions.length} answered`;$('score').textContent=examMode==='exam'?'Exam in progress':`Score: ${score}`;$('progressFill').style.width=`${currentQuestions.length?answeredN/currentQuestions.length*100:0}%`;$('questionScroll').innerHTML=currentQuestions.map((q,i)=>card(q,i)).join('');typesetMath($('questionScroll'));}
function card(q,i){
  const a=answers[i], checked=!!a?.checked, saved=!!a?.saved;
  const opts=q.choices.map((c,j)=>{
    let cl=a?.chosen===j?'selected':'';
    if(checked&&examMode!=='exam'){if(j===q.answer)cl+=' correct';else if(a.chosen===j)cl+=' wrong';}
    return `<button class="option ${cl}" ${checked?'disabled':''} onclick="chooseAnswer(${i},${j})"><b>${String.fromCharCode(65+j)}.</b><span>${c}</span></button>`;
  }).join('');
  let feedback='';
  if(checked&&examMode!=='exam'){feedback=`<div class="${a.chosen===q.answer?'good':'bad'}"><b>${a.chosen===q.answer?'Correct':'Incorrect'}</b><div>Correct answer: <strong>${q.choices[q.answer]||'—'}</strong></div>${examMode==='practice'&&q.explanation?`<div class="explanation"><b>Explanation</b><br>${q.explanation}</div>`:''}</div>`;}
  const actions=examMode==='exam'
    ? `<div class="questionActions"><button class="questionAction saveAnswerBtn ${saved?'saved':''}" onclick="saveAnswer(${i})">${saved?'✓ Saved':'Save answer'}</button></div>`
    : `<div class="questionActions"><button class="questionAction checkAnswerBtn" onclick="checkAnswer(${i})">${checked?'Checked':'Check answer'}</button></div>`;
  return `<article class="questionCard" id="q-${i}"><div class="qHeader"><span>Question ${i+1}</span><button class="reviewToggle ${reviewed.has(i)?'reviewed':''}" onclick="toggleReview(${i})">${reviewed.has(i)?'★ Marked':'☆ Review'}</button></div><div class="questionText">${q.question}</div><div>${opts}</div>${actions}${feedback}</article>`;
}
function chooseAnswer(i,j){
  if(!currentQuestions[i])return;
  const old=answers[i]||{};
  // Selecting an option does not reveal the result. The question buttons control
  // when an answer is checked/saved, matching the previous app workflow.
  answers[i]={...old,chosen:j,checked:false};
  renderAll();
  saveSession();
}
function saveAnswer(i){
  if(examMode!=='exam'||!currentQuestions[i]||!answers[i]||answers[i].chosen===undefined)return;
  answers[i]={...answers[i],saved:true};
  renderAll();
  saveSession();
}
function checkAnswer(i){
  if(examMode==='exam'||!currentQuestions[i]||!answers[i]||answers[i].chosen===undefined)return;
  answers[i]={...answers[i],checked:true};
  renderAll();
  saveSession();
}
function toggleReview(i){reviewed.has(i)?reviewed.delete(i):reviewed.add(i);renderAll();saveSession();}
// These handlers are used by the question cards' inline controls.
Object.assign(window,{chooseAnswer,saveAnswer,checkAnswer,toggleReview});
function pause(){if(paused){startTime+=Date.now()-pauseAt;paused=false;timerHandle=setInterval(timer,1000);$('pauseBtn').textContent='Pause';}else{pauseAt=Date.now();paused=true;clearInterval(timerHandle);$('pauseBtn').textContent='Resume';}saveSession();}
function finish(){if(!currentQuestions.length)return;clearInterval(timerHandle);timerHandle=null;const answeredN=answers.filter(Boolean).length;const score=answers.filter((a,i)=>a?.chosen===currentQuestions[i].answer).length;const pct=Math.round(score/currentQuestions.length*100);const session={date:new Date().toLocaleString(),subject:currentSubject?.name||'Exam',score,total:currentQuestions.length,pct,time:$('timer').textContent,mode:examMode};const h=store.get('studentPrepHistory');h.unshift(session);store.set('studentPrepHistory',h.slice(0,30));localStorage.setItem('studentPrepUnfinished',JSON.stringify(getUnfinishedSessions().filter(x=>x&&x.id!==pending?.id).slice(0,20)));document.body.classList.remove('exam-active');$('result').innerHTML=`<div class="resultBox"><strong>${pct}%</strong><p>${score} / ${currentQuestions.length} correct • ${answeredN} answered</p><p>Mode: ${examMode==='practice'?'Practice':examMode==='quick'?'Quick':'Exam Style'} • Time: ${$('timer').textContent} • ${reviewed.size} marked for review</p></div>`;$('resultDetails').innerHTML=currentQuestions.map((q,i)=>{const a=answers[i],ok=a?.chosen===q.answer;return `<div class="detail ${ok?'goodItem':'badItem'}"><b>Q${i+1} ${ok?'✓':'✕'}</b><div>${q.question}</div><p><b>Your answer:</b> ${a?String.fromCharCode(65+a.chosen)+'. '+(q.choices[a.chosen]||''):'Not answered'}</p><p><b>Correct:</b> ${q.choices[q.answer]||''}</p>${q.explanation?`<p>${q.explanation}</p>`:''}</div>`}).join('');typesetMath();show('resultView');}
function getUnfinishedSessions(){
  try{
    const raw=JSON.parse(localStorage.getItem('studentPrepUnfinished')||'[]');
    if(Array.isArray(raw))return raw;
    if(raw&&Array.isArray(raw.questions))return [raw]; // migrate the old single-session format
  }catch{}
  return [];
}
function saveSession(){
  if(!currentQuestions.length||currentView!=='practiceView')return;
  const session={
    id:pending?.id||`${Date.now()}-${Math.random().toString(36).slice(2,8)}`,
    subjectCode:currentSubject?.code||null,
    subjectName:currentSubject?.name||'Exam',
    title:$('practiceTitle')?.textContent||'Unfinished exam',
    mode:examMode,
    questions:currentQuestions,
    answers,
    reviewed:[...reviewed],
    elapsed:elapsed(),
    paused,
    updatedAt:Date.now()
  };
  pending={...(pending||{}),id:session.id,q:currentQuestions,title:session.title};
  const sessions=getUnfinishedSessions().filter(x=>x&&x.id!==session.id);
  sessions.unshift(session);
  const maxSaved=window.StudentPrepAccess?.isPremium?.()?Infinity:(window.StudentPrepAccess?.limits?.savedExams||3);
  localStorage.setItem('studentPrepUnfinished',JSON.stringify(sessions.slice(0,maxSaved)));
}
function loadUnfinished(){return getUnfinishedSessions()[0]||null}
function resumeUnfinished(id){
  const s=getUnfinishedSessions().find(x=>x.id===id)||loadUnfinished();
  if(!s||!Array.isArray(s.questions)||!s.questions.length){alert('There is no unfinished exam.');return;}
  currentSubject=s.subjectCode?subjectRegistry[s.subjectCode]:null;
  currentQuestions=s.questions;
  answers=Array.isArray(s.answers)?s.answers:Array(currentQuestions.length).fill(null);
  reviewed=new Set(Array.isArray(s.reviewed)?s.reviewed:[]);
  examMode=s.mode||'practice';
  pending={id:s.id,q:currentQuestions,title:s.title||'Unfinished exam'};
  startTime=Date.now()-(Number(s.elapsed)||0);
  paused=!!s.paused; pauseAt=paused?Date.now():0;
  clearInterval(timerHandle);
  if(!paused)timerHandle=setInterval(timer,1000);
  $('practiceTitle').textContent=pending.title;
  $('practiceMode').textContent=examMode==='practice'?'PRACTICE MODE':examMode==='quick'?'QUICK MODE':'EXAM STYLE';
  $('practiceHint').textContent=examMode==='exam'?'Choose answers freely. Answers and explanations are revealed after you finish.':examMode==='practice'?'Click an answer to see the correct answer and explanation immediately.':'Click an answer to see the correct answer immediately.';
  $('pauseBtn').textContent=paused?'Resume':'Pause';
  show('practiceView');renderAll();timer();
}
function showExamHub(){
  const maxSaved=window.StudentPrepAccess?.isPremium?.()?Infinity:(window.StudentPrepAccess?.limits?.savedExams||3);
  const sessions=getUnfinishedSessions().slice(0,maxSaved);
  const intro=`<div class="examHubWrap"><div class="examHubIntro"><span class="eyebrow">EXAM CENTER</span><h3>Keep your preparation moving</h3><p>Resume an unfinished session or return to Home to choose a subject, chapter, year, and exam mode.</p>${window.StudentPrepAccess?.isPremium?.()?'':'<div class="limitHint">Free Exam Saver: up to 3 unfinished exams. <button class="inlinePremium" onclick="StudentPrepAccess.openPremium()">Unlock Premium</button></div>'}</div>`;
  const cards=sessions.length?sessions.map(s=>`<div class="unfinishedCard"><span class="unfinishedIcon">▶</span><div><span class="eyebrow">UNFINISHED EXAM</span><h3>${s.title||'Unfinished exam'}</h3><p>${s.answers?.filter(Boolean).length||0} of ${s.questions?.length||0} answered • ${String(s.mode||'practice').replace(/^./,m=>m.toUpperCase())} mode</p></div><button class="primary resumeExamBtn" data-session="${s.id}">Resume</button></div>`).join(''):`<div class="emptyState"><div class="unfinishedIcon">✓</div><h3>No unfinished exams</h3><p>Your unfinished exams will appear here. Start a new exam from Home.</p><button id="browseExamBtn" class="primary">Choose an exam</button></div>`;
  $('examHub').innerHTML=intro+cards+'</div>';
  $('examHub').querySelectorAll('.resumeExamBtn').forEach(b=>b.onclick=()=>resumeUnfinished(b.dataset.session));
  if($('browseExamBtn'))$('browseExamBtn').onclick=goHome;
  show('examHubView');
}
function ensurePlanModal(){
  if($('planModal'))return;
  const subjects=Object.keys(window.STUDENTPREP_RELATED_CONTENTS||{});
  document.body.insertAdjacentHTML('beforeend',`<div id="planModal" aria-hidden="true"><div class="planDialog" role="dialog" aria-modal="true" aria-labelledby="planDialogTitle">
    <div class="planDialogHead"><div><span class="eyebrow">NEW PLAN</span><h3 id="planDialogTitle">Add study plan</h3></div><button class="closePlan" id="closePlanBtn" aria-label="Close">×</button></div>
    <form id="planForm" class="planForm">
      <label>Subject<select id="planSubject">${subjects.map(s=>`<option value="${s}">${s}</option>`).join('')}</select></label>
      <label>Grade<select id="planGrade"><option value="9">Grade 9</option><option value="10">Grade 10</option><option value="11">Grade 11</option><option value="12">Grade 12</option></select></label>
      <label>Related chapter<select id="planChapter"></select></label>
      <label>Study date<input id="planDate" type="date" required></label>
      <label>Daily target (minutes)<input id="planMinutes" type="number" min="5" max="600" value="60" required></label>
      <label>Note (optional)<textarea id="planNote" placeholder="What do you want to finish?"></textarea></label>
      <div class="formActions"><button type="button" class="softBtn" id="cancelPlanBtn">Cancel</button><button type="submit" class="primary">Add plan</button></div>
    </form>
  </div></div>`);
  $('closePlanBtn').onclick=closePlanModal;$('cancelPlanBtn').onclick=closePlanModal;
  $('planModal').onclick=e=>{if(e.target.id==='planModal')closePlanModal()};
  $('planSubject').onchange=updatePlanChapters;$('planGrade').onchange=updatePlanChapters;
  $('planForm').onsubmit=e=>{e.preventDefault();saveStudyPlan()};
  updatePlanChapters();
}
function updatePlanChapters(){
  const subject=$('planSubject').value, grade=$('planGrade').value;
  const list=(window.STUDENTPREP_RELATED_CONTENTS?.[subject]||[]).filter(x=>x[1].includes(`G${grade}`)||x[1].includes('G9/G10')||x[1].includes('G10/G11')||x[1].includes('G9/G11')||x[1].includes('G11/G12'));
  $('planChapter').innerHTML=list.map((x,i)=>`<option value="${i}">${x[0]} — ${x[1]}</option>`).join('')||'<option value="">No mapped chapter for this grade</option>';
}
function openPlanModal(){
  const plans=getStudyPlans(); if(!window.StudentPrepAccess?.isPremium?.() && plans.length>=(window.StudentPrepAccess?.limits?.plans||3)){window.StudentPrepAccess?.openPremium?.();return;}
  ensurePlanModal();
  const d=new Date(); $('planDate').value=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  $('planModal').classList.add('open');$('planModal').setAttribute('aria-hidden','false');
}
function closePlanModal(){if(!$('planModal'))return;$('planModal').classList.remove('open');$('planModal').setAttribute('aria-hidden','true')}
function getStudyPlans(){return JSON.parse(localStorage.getItem('studentPrepStudyPlans')||'[]')}
function setStudyPlans(v){localStorage.setItem('studentPrepStudyPlans',JSON.stringify(v))}
function saveStudyPlan(){
  const subject=$('planSubject').value, grade=$('planGrade').value;
  const raw=(window.STUDENTPREP_RELATED_CONTENTS?.[subject]||[]), filtered=raw.filter(x=>x[1].includes(`G${grade}`)||x[1].includes('G9/G10')||x[1].includes('G10/G11')||x[1].includes('G9/G11')||x[1].includes('G11/G12'));
  const item=filtered[Number($('planChapter').value)];
  if(!item)return;
  const plans=getStudyPlans();
  const maxPlans=window.StudentPrepAccess?.isPremium?.()?Infinity:(window.StudentPrepAccess?.limits?.plans||3);
  if(plans.length>=maxPlans){window.StudentPrepAccess?.openPremium?.();return;}
  plans.push({id:`plan_${Date.now()}`,subject,grade,chapter:item[0],mapping:item[1],date:$('planDate').value,minutes:Number($('planMinutes').value)||60,note:$('planNote').value.trim(),done:false,createdAt:Date.now()});
  setStudyPlans(plans);closePlanModal();renderStudyPlans();
}
function renderStudyPlans(){
  const plans=getStudyPlans().sort((a,b)=>a.date.localeCompare(b.date)||b.createdAt-a.createdAt);
  $('planCount').textContent=`${plans.length} plan${plans.length===1?'':'s'}${window.StudentPrepAccess?.isPremium?.()?'':' / 3 free'}`;
  $('studyPlanList').innerHTML=plans.length?plans.map(p=>`<article class="planCard ${p.done?'done':''}"><input class="planCheck" type="checkbox" data-plan="${p.id}" ${p.done?'checked':''} aria-label="Mark plan complete"><div class="planBody"><p class="planTitle">${p.chapter}</p><p class="planDate">${p.date} • ${p.minutes} min target</p><div class="planMeta"><span class="planTag">${p.subject}</span><span class="planTag">Grade ${p.grade}</span><span class="planTag">${p.mapping}</span></div>${p.note?`<p class="planNotes">${p.note.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}</p>`:''}</div><button class="planDelete" data-delete-plan="${p.id}" aria-label="Delete plan">×</button></article>`).join(''):`<div class="emptyState"><div class="unfinishedIcon">+</div><h3>No study plans yet</h3><p>Use the + button to add a chapter from the related entrance-exam contents.</p></div>`;
  $('studyPlanList').querySelectorAll('.planCheck').forEach(b=>b.onchange=()=>{const p=getStudyPlans();const x=p.find(x=>x.id===b.dataset.plan);if(x){x.done=b.checked;setStudyPlans(p);renderStudyPlans()}});
  $('studyPlanList').querySelectorAll('[data-delete-plan]').forEach(b=>b.onclick=()=>{setStudyPlans(getStudyPlans().filter(x=>x.id!==b.dataset.deletePlan));renderStudyPlans()});
}
function showProgress(){
  const h=store.get('studentPrepHistory'),t=h.reduce((n,x)=>n+x.total,0),c=h.reduce((n,x)=>n+x.score,0);
  $('progressSummary').innerHTML=`<div class="stat"><b>${h.length}</b><small>Sessions</small></div><div class="stat"><b>${t}</b><small>Questions</small></div><div class="stat"><b>${t?Math.round(c/t*100):0}%</b><small>Accuracy</small></div>`;
  renderStudyPlans();
  $('progressHistory').innerHTML=h.length?h.map(x=>`<div class="detail"><b>${x.subject}</b><small>${x.date}</small><p>${x.score}/${x.total} • ${x.pct}% • ${x.mode||'practice'}</p></div>`).join(''):'<div class="emptyState">No completed sessions yet.</div>';
  show('progressView');
}
function retry(){queueStart(currentQuestions.slice(),$('practiceTitle').textContent);}
function coming(title,icon){$('comingTitle').textContent=title;$('comingIcon').textContent=icon;$('comingText').textContent=`${title} is coming soon.`;show('comingView');}
function info(title,text){$('infoTitle').textContent=title;$('infoText').textContent=text;show('infoView');}
function openMenu(){$('sideMenu').classList.add('open');$('menuOverlay').classList.add('open');$('sideMenu').setAttribute('aria-hidden','false')}function closeMenu(){$('sideMenu').classList.remove('open');$('menuOverlay').classList.remove('open');$('sideMenu').setAttribute('aria-hidden','true')}
window.addEventListener('popstate',()=>{
  // App/browser Back returns to Home. The Experiments viewer keeps its own Back button.
  const hash=location.hash.replace('#','');
  const id=hash?`${hash}View`:'homeView';
  clearInterval(timerHandle);timerHandle=null;
  if(id!=='homeView'){
    $('.view.active')?.classList.remove('active');
    $('homeView')?.classList.add('active');
    currentView='homeView';
    document.body.classList.remove('exam-active');
    closeMenu();
    return;
  }
  if(id==='practiceView'){
    $('.view.active')?.classList.remove('active');
    $('practiceView')?.classList.add('active');
    currentView='practiceView';
    document.body.classList.add('exam-active');
    if(currentQuestions.length)timer();
  }else if($(id)){
    $('.view.active')?.classList.remove('active');
    $(id).classList.add('active');
    currentView=id;
    document.body.classList.remove('exam-active');
    paused=false;
    if(id==='subjectView'&&currentSubject)renderBrowse('chapter');
    if(id==='examHubView')showExamHub();
  }else{
    $('.view.active')?.classList.remove('active');
    $('homeView')?.classList.add('active');
    currentView='homeView';
    document.body.classList.remove('exam-active');
  }
  closeMenu();window.scrollTo({top:0,behavior:'instant'});
});

document.addEventListener('DOMContentLoaded',()=>{renderHome();$('browseChapter').onclick=()=>renderBrowse('chapter');$('browseYear').onclick=()=>renderBrowse('year');document.querySelectorAll('.homeBrowseTabs button').forEach(b=>b.onclick=()=>{document.querySelectorAll(`.homeBrowseTabs button[data-home-stream="${b.dataset.homeStream}"]`).forEach(x=>x.classList.remove('active'));b.classList.add('active');renderHomeStream(b.dataset.homeStream,b.dataset.homeBrowse);});document.querySelectorAll('.modeCard').forEach(b=>b.onclick=()=>begin(b.dataset.mode));$('pauseBtn').onclick=pause;$('finishBtn').onclick=finish;$('homeBtn').onclick=goHome;$('navHome').onclick=goHome;$('navExams').onclick=showExamHub;$('navNotes').onclick=()=>coming('Notes','📚');$('navProgress').onclick=showProgress;$('addPlanBtn').onclick=openPlanModal;$('navExperiments').onclick=()=>show('experimentsView');$('themeBtn').onclick=()=>{document.body.classList.toggle('dark');localStorage.setItem('studentPrepTheme',document.body.classList.contains('dark')?'dark':'light');};if(localStorage.getItem('studentPrepTheme')==='dark')document.body.classList.add('dark');$('menuBtn').onclick=openMenu;$('menuClose').onclick=closeMenu;$('menuOverlay').onclick=closeMenu;document.querySelectorAll('#sideMenu [data-menu]').forEach(b=>b.onclick=()=>{closeMenu();const k=b.dataset.menu;if(k==='updates')info('Updates','StudentPrep keeps the original question bank, image support, chapter/year browsing and three exam modes.');if(k==='rate')info('Rate Us','Thank you for supporting StudentPrep. Rating support is coming soon.');if(k==='contact')info('Contact','Contact support is coming soon.');if(k==='settings')info('Settings','Use the moon button to switch between light and dark mode.');if(k==='premium')StudentPrepAccess.openPremium();});});

// Restore the route if the app is opened/reloaded on a hash URL.
window.addEventListener('load',()=>{const hash=location.hash.replace('#','');if(hash&&$(hash+'View')&&hash!=='home'){$('.view.active')?.classList.remove('active');$(hash+'View').classList.add('active');currentView=hash+'View';document.body.classList.toggle('exam-active',currentView==='practiceView');if(currentView==='examHubView')showExamHub();}});

window.addEventListener('studentprep-content-changed',()=>{try{if(currentSubject&&window.subjectRegistry?.[currentSubject.code])currentSubject=window.subjectRegistry[currentSubject.code];renderHome();if(currentSubject){$('subjectCount').textContent=`${currentSubject.questions.length.toLocaleString()} questions`;renderBrowse('chapter')}}catch(e){console.error('Content refresh failed',e)}});
