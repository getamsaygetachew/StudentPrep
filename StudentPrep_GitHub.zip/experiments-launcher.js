// StudentPrep Experiments launcher
function openExperimentsPage(){
  window.location.href = 'experiments.html';
}
