// StudentPrep Free Content — only the first 2 non-empty curriculum units/categories per grade/subject.
const questions = [
  {
    "id": 1091,
    "content": [
      "With which one of the following ideas or institutions is capitalism associated?"
    ],
    "explanation": [
      "One of the main characteristic features of capitalism is that the motive for all companies in the capitalist system is to make and sell goods and services only for profits.\n\nCapitalism is defined as the distribution of goods that are bought at a certain price and sold at a higher price in order to generate profits.\n\nIndustrial capitalism arose due to the vast accumulation of capital during the phase of merchant capitalism and its investment in machinery. The goal of this investment is to increase productive capacity and generate more profit."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4365,
        "content": [
          "Serfdom"
        ],
        "isCorrect": false
      },
      {
        "id": 4366,
        "content": [
          "Equality of classes"
        ],
        "isCorrect": false
      },
      {
        "id": 4367,
        "content": [
          "Controlled markets"
        ],
        "isCorrect": false
      },
      {
        "id": 4368,
        "content": [
          "Making profit"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1092,
    "content": [
      "What was the fundamental organizational change that led to the Industrial Revolution?"
    ],
    "explanation": [
      "Industrial Revolution involved \"a change from dispersed production in small units under the old putting out system to the new factory system of the industrial revolution\"."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4369,
        "content": [
          "The shift from the dispersed system to factory production"
        ],
        "isCorrect": true
      },
      {
        "id": 4370,
        "content": [
          "The replacement of animal and human labor by machines"
        ],
        "isCorrect": false
      },
      {
        "id": 4371,
        "content": [
          "The shift from coal to water to generate power"
        ],
        "isCorrect": false
      },
      {
        "id": 4372,
        "content": [
          "The development of banks to lend money to Entrepreneurs"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1093,
    "content": [
      "Which one of the following was a consequence of the American Civil War?"
    ],
    "explanation": [
      "The civil war decided once and for all the issues of secession and slavery. Both ended by the victory of the North.\n\nAfter the civil war, southern political leaders had virtually no impact on the immediate post-war decisions. Thus, several amendments to the US constitution were made: the Thirteenth abolished slavery, the Fourteenth granted citizenship to former slaves, and the Fifteenth allowed them to vote."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4373,
        "content": [
          "The end of racial oppression in the USA"
        ],
        "isCorrect": false
      },
      {
        "id": 4374,
        "content": [
          "The end of the institution of slavery in the USA"
        ],
        "isCorrect": true
      },
      {
        "id": 4375,
        "content": [
          "The economic prosperity of the southern planter class"
        ],
        "isCorrect": false
      },
      {
        "id": 4376,
        "content": [
          "The acquisition of parts of the US by France"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1094,
    "content": [
      "What was the major consequence of the Second Balkan War?"
    ],
    "explanation": [
      "The Second Balkan War erupted when the Balkan allies quarreled over the partitioning of their conquests in Macedonia. This led to Serbia gaining the Kosovo region and extending into northern and central Macedonia, and Greece gaining southern Macedonia and Crete. Albania was made an independent state due to the insistence of European powers."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_EUROPE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4377,
        "content": [
          "The deepening of hostility between Austria-Hungary and Serbia over territorial claims."
        ],
        "isCorrect": true
      },
      {
        "id": 4378,
        "content": [
          "The forced withdrawal of Ottoman Turkey from all its European territories."
        ],
        "isCorrect": false
      },
      {
        "id": 4379,
        "content": [
          "The emergence of conflict between emerging Balkan nationalism and the Ottoman Empire."
        ],
        "isCorrect": false
      },
      {
        "id": 4380,
        "content": [
          "The emergence of several countries such as Greece and Macedonia as independent nations."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1095,
    "content": [
      "Which of the following innovations contributed to the success of European imperialism in Africa in the late 19th-century?"
    ],
    "explanation": [
      "Until the second half of the 19th century, European exploration did not show significant progress due to the high mortality of Europeans from malaria fever.\n\nIt was only after the early 1850s, when quinine was discovered and provided reasonable protection from malaria fever, that European exploration of Africa was quickened."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4381,
        "content": [
          "The discovery of cement for building efficient roads"
        ],
        "isCorrect": false
      },
      {
        "id": 4382,
        "content": [
          "The development of techniques for exploring minerals"
        ],
        "isCorrect": false
      },
      {
        "id": 4383,
        "content": [
          "The numerical superiority of white armies than Africans"
        ],
        "isCorrect": false
      },
      {
        "id": 4384,
        "content": [
          "The discovery of medicinal protection against malaria"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1096,
    "content": [
      "What was the main feature of British indirect rule?"
    ],
    "explanation": [
      "The British colonial policy known as \"indirect rule\" was most clearly formulated by Frederick Luggard. He recommended its application to all British tropical African colonies.\n\nIndirect rule involved using indigenous African rulers within the colonial administration. The British based their colonial administration on what they perceived as a series of minor but separate pre-colonial chiefdoms.\n\nThe British aimed to administer vast populations stretched over even vaster territories with the minimum of European personnel, making indirect rule the cheapest and most effective way according to them."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4385,
        "content": [
          "The exclusion of Africans from the administration of the colonies."
        ],
        "isCorrect": false
      },
      {
        "id": 4386,
        "content": [
          "The use of extensive violence to mobilize commodities for export."
        ],
        "isCorrect": false
      },
      {
        "id": 4387,
        "content": [
          "The granting of Africans British citizens with their political rights."
        ],
        "isCorrect": false
      },
      {
        "id": 4388,
        "content": [
          "The use of Africans in their administration of the colonies."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1097,
    "content": [
      "How did long distance trade facilitate interaction among Ethiopia's populations?"
    ],
    "explanation": [
      "The development of long-distance trade routes led to the establishment of important market centers across the Ethiopian region. Examples include Assendabo and Basso, which served as contact points for people from various regions, and Gondar, which became a meeting place for people from surrounding areas trading diverse goods.\n\nThese markets were not just places for economic exchange but also hubs for social and cultural interaction. As merchants and buyers from different ethnic and religious backgrounds gathered, they inevitably exchanged ideas, customs, and social values. The markets in Gondar, for instance, brought together foreign merchants, city residents, and the rural population."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4389,
        "content": [
          "By helping introduce Orthodox to different parts of the region."
        ],
        "isCorrect": false
      },
      {
        "id": 4390,
        "content": [
          "By giving rise to markets that served as centers of cultural interaction."
        ],
        "isCorrect": true
      },
      {
        "id": 4391,
        "content": [
          "By spreading democratic institutions such as Gada to new areas."
        ],
        "isCorrect": false
      },
      {
        "id": 4392,
        "content": [
          "By making use of the common media of exchange."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1098,
    "content": [
      "Why did Emperor Tewodros II's modernization attempts fail? Because"
    ],
    "explanation": [
      "Emperor Tewodros sought technological assistance, particularly firearms and skilled personnel, from European nations, specifically Great Britain. He understood Ethiopia's backwardness and wanted to modernize, especially his army.\n\nDue to a lack of a quick positive response from the British government to his requests, Tewodros detained the British consul, Captain Cameron, and European missionaries. He forced them to work in his gun foundry at Gafat, even though they lacked experience in arms production.\n\nThis action directly led to the British government sending a military expedition against Ethiopia in 1867, led by General Robert Napier, with the primary objective of releasing the European captives.\n\nThe British forces had marked superiority in military training and the quality of firearms compared to Tewodros's declining army. They defeated his forces, stormed his fortress at Meqdela, and Tewodros ultimately committed suicide."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4393,
        "content": [
          "he lacked the technology and resources necessary to implement the reforms."
        ],
        "isCorrect": false
      },
      {
        "id": 4394,
        "content": [
          "he tried to simply copy western institutions rather than adapt them to local conditions."
        ],
        "isCorrect": false
      },
      {
        "id": 4395,
        "content": [
          "he angered the European powers who could have helped him."
        ],
        "isCorrect": true
      },
      {
        "id": 4396,
        "content": [
          "British opposed his reforms fearing he would create a strong Ethiopian state."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1099,
    "content": [
      "What was the consequence of the Hewett (Adwa) Treaty of 1884?"
    ],
    "explanation": [
      "The Hewett Treaty was signed between Emperor Yohannis IV and the British in 1884.\n\nAccording to the treaty, Ethiopia agreed to facilitate the safe evacuation of Egyptian troops trapped in eastern Sudan via Ethiopia.\n\nIn return, the British promised to ensure the return of Bogos to Ethiopia and make Massawa a free port for Ethiopia. However, the British did not keep their promise regarding Massawa and allowed Italy to occupy it.\n\nThe Ethiopian involvement in evacuating the Egyptian troops infuriated the Mahdists of Sudan. This became the main cause for the clashes between the Mahdists of Sudan and Ethiopian forces that lasted from 1885 to 1889.\n\nThe first clash occurred at Kufit in September 1885, with an Ethiopian victory. Emperor Yohannis IV himself later died fighting the Mahdists at the Battle of Metemma in 1889."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4397,
        "content": [
          "Return of Massawa to Ethiopia"
        ],
        "isCorrect": false
      },
      {
        "id": 4398,
        "content": [
          "Ethiopian hostility with the Mahdist Sudan"
        ],
        "isCorrect": true
      },
      {
        "id": 4399,
        "content": [
          "Ethiopian control over Matama"
        ],
        "isCorrect": false
      },
      {
        "id": 4400,
        "content": [
          "Continuous Ethiopian war with the Egyptians"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1100,
    "content": [
      "What was the significance of the battle of Sagele of 1916 in Ethiopian politics?"
    ],
    "explanation": [
      "Following the deposition of Lij Iyasu in a palace coup, his father, Negus Mikael of Wollo, attempted to reverse the coup by leading a large army to Shewa.\n\nHowever, the forces of Negus Mikael were completely defeated and Mikael himself was captured at the decisive and bloody Battle of Segele, near the town of Sheno, on October 27, 1916. The Shewan army was led by Ras Teferi Mekonne.\n\nThe victory at the Battle of Segele restored the Shewan political supremacy. This was after a challenge from the Wollo region, led by Iyasu's father, to the new political order established in Addis Ababa."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4401,
        "content": [
          "It ended the political influence of Wallo in national politics."
        ],
        "isCorrect": true
      },
      {
        "id": 4402,
        "content": [
          "It led to the victory of the progressive groups in court politics."
        ],
        "isCorrect": false
      },
      {
        "id": 4403,
        "content": [
          "It marked the end of the influence of the tripartite powers in Ethiopia."
        ],
        "isCorrect": false
      },
      {
        "id": 4404,
        "content": [
          "It marked a shift of power from Shewa to Wallo."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1101,
    "content": [
      "Which one of the following is correct about the importance of history?"
    ],
    "explanation": [
      "History helps us understand contemporary issues by providing context and perspective on current events and societal trends."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4405,
        "content": [
          "It enables people to become less spiritual and more secular."
        ],
        "isCorrect": false
      },
      {
        "id": 4406,
        "content": [
          "It helps us understand contemporary issues."
        ],
        "isCorrect": true
      },
      {
        "id": 4407,
        "content": [
          "It encourages people to focus more on local than global issues."
        ],
        "isCorrect": false
      },
      {
        "id": 4408,
        "content": [
          "It deepens extreme nationalism among the diverse population."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1102,
    "content": [
      "Which of the following is correct according to the scientific theory of human evolution?"
    ],
    "explanation": [
      "According to the scientific theory of human evolution, the earliest human species originated in Africa and spread out to other continents."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4409,
        "content": [
          "The earliest human species originated in Africa and spread out to other continents."
        ],
        "isCorrect": true
      },
      {
        "id": 4410,
        "content": [
          "The major difference among the various hominid species is in terms of height and weight."
        ],
        "isCorrect": false
      },
      {
        "id": 4411,
        "content": [
          "It is by the types of iron tools that they made that we differentiate among hominids."
        ],
        "isCorrect": false
      },
      {
        "id": 4412,
        "content": [
          "The different hominid species in Africa descended from Lucy (Dinkinesh)."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1103,
    "content": [
      "What was the Ethiopian state that had emerged immediately before Aksum?"
    ],
    "explanation": [
      "Da'amat (Damat) was the first historically known state in Ethiopia, located a little to the south of Aksum. It existed from approximately 980 B.C. to 400 B.C."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4413,
        "content": [
          "Damot"
        ],
        "isCorrect": false
      },
      {
        "id": 4414,
        "content": [
          "Adulis"
        ],
        "isCorrect": false
      },
      {
        "id": 4415,
        "content": [
          "Haulti"
        ],
        "isCorrect": false
      },
      {
        "id": 4416,
        "content": [
          "Damat"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1104,
    "content": [
      "To which language super-family do the Omotic language belongs?"
    ],
    "explanation": [
      "Languages of Africa are classified into four super-families: Afro-Asiatic, Nilo-Saharan, Niger-Congo, and Khoisan.\n\nSpecifically concerning Ethiopia and the Horn, the Afro-Asiatic and Nilo-Saharan super-families are noted as being spoken in the region.\n\nThe Afro-Asiatic super-family has six families, and among these, Cushitic, Omotic, and Semitic are spoken in Ethiopia and the Horn."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4417,
        "content": [
          "Khoi-San"
        ],
        "isCorrect": false
      },
      {
        "id": 4418,
        "content": [
          "Niger-Congo"
        ],
        "isCorrect": false
      },
      {
        "id": 4419,
        "content": [
          "Afro-Asiatic"
        ],
        "isCorrect": true
      },
      {
        "id": 4420,
        "content": [
          "Nilo-Saharan"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1105,
    "content": [
      "Which of the following technologies enabled ancient Egyptians to produce large surpluses and maintain an enduring state?"
    ],
    "explanation": [
      "Egypt was described by a Greek historian as “The Gift of the Nile”. The annual flood of the Nile provided both water and fertile soil, which was essential for agriculture.\n\nTo effectively utilize the Nile's resources and overcome periods of low water, the Egyptians developed a sophisticated irrigation system. This allowed them to control the water supply, cultivate more land, and produce large amounts of crops like wheat and barley."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4421,
        "content": [
          "Building pyramids"
        ],
        "isCorrect": false
      },
      {
        "id": 4422,
        "content": [
          "Inventing hieroglyphics"
        ],
        "isCorrect": false
      },
      {
        "id": 4423,
        "content": [
          "Constructing irrigation canals"
        ],
        "isCorrect": true
      },
      {
        "id": 4424,
        "content": [
          "The art of mummification"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1106,
    "content": [
      "Which one of the following is correct about Pre-Colonial American civilizations?"
    ],
    "explanation": [
      "Inca built roads that linked distant provinces to Cuzco. Maya priests developed an accurate 365-day solar calendar."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4425,
        "content": [
          "They all achieved high standards of urban development and high rate of city structure."
        ],
        "isCorrect": false
      },
      {
        "id": 4426,
        "content": [
          "While the Inca built extensive roads and the Maya developed an accurate calendar."
        ],
        "isCorrect": true
      },
      {
        "id": 4427,
        "content": [
          "The development of writing distinguished Aztec civilization from Mayan and Incan civilizations."
        ],
        "isCorrect": false
      },
      {
        "id": 4428,
        "content": [
          "The Inca put up a stronger resistance against the Spanish because they used tools made out of silver."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1107,
    "content": [
      "To which power did Aksum eventually lose control over the Red Sea trade?"
    ],
    "explanation": [
      "The decline of Aksum began when the Red Sea came under the control of Muslim Arabs.\n\nThis is further supported by the destruction of the port of Adulis by the Arabs around 702 cut off Aksum's economic artery, and the entire network of Aksumite international trade fell under the control of the rising and expanding Arab Muslims."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4429,
        "content": [
          "Muslim Arabia"
        ],
        "isCorrect": true
      },
      {
        "id": 4430,
        "content": [
          "Ottoman Turkey"
        ],
        "isCorrect": false
      },
      {
        "id": 4431,
        "content": [
          "Mamluk Egypt"
        ],
        "isCorrect": false
      },
      {
        "id": 4432,
        "content": [
          "Safavid Persia"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1108,
    "content": [
      "What was the major achievement of the Muslim Arabs under the immediate successors of the Prophet Mohammed?"
    ],
    "explanation": [
      "The major achievement of the Muslim Arabs under the immediate successors of the Prophet Mohammed, the first four caliphs (Abu Bakr, Umar, ‘Uthman, and Ali), was the capture of extensive territories from Persia and Byzantium."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4433,
        "content": [
          "Moving the center of the empire outside of Arabia and Syria."
        ],
        "isCorrect": false
      },
      {
        "id": 4434,
        "content": [
          "The capture of Medina and its selection as the religious center."
        ],
        "isCorrect": false
      },
      {
        "id": 4435,
        "content": [
          "The capture of extensive territories from Persia and Byzantium."
        ],
        "isCorrect": true
      },
      {
        "id": 4436,
        "content": [
          "The opening of trade routes connecting Arabia with India."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1109,
    "content": [
      "Which one of the following was a cultural feature of the Zagwe dynasty?"
    ],
    "explanation": [
      "Once the Muslim Arabs controlled the lands along the Red Sea and North Africa, it became difficult for Ethiopian Christian pilgrims to visit Jerusalem.\n\nTo address this issue, the Zagwe kings, especially Lalibela, took the initiative to establish a \"second Jerusalem\" in Ethiopia.\n\nThis indicates a cultural shift where Lalibela became a significant center for pilgrimage within Ethiopia, arguably taking on some of the religious importance previously associated with the Holy Land for Ethiopian Christians."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4437,
        "content": [
          "The continuation of Christianity as the official state religion."
        ],
        "isCorrect": false
      },
      {
        "id": 4438,
        "content": [
          "The use of the Agaw language for both court and church functions."
        ],
        "isCorrect": false
      },
      {
        "id": 4439,
        "content": [
          "The shift of the pilgrimages from the Holy Land to Lalibela."
        ],
        "isCorrect": true
      },
      {
        "id": 4440,
        "content": [
          "The development of rules about royal succession."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1110,
    "content": [
      "Why did the medieval Ethiopian Christian kingdom rely on mobile courts? Because"
    ],
    "explanation": [
      "The medieval Ethiopian Christian kingdom relied on mobile courts primarily because it facilitated the administration and sustenance of a large realm. Therefore, the most fitting answer is “moveable capital made it possible to administer a vast empire easily.”"
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4441,
        "content": [
          "the tradition of permanent capitals did not familiar before."
        ],
        "isCorrect": false
      },
      {
        "id": 4442,
        "content": [
          "moveable capital made it possible to administer a vast empire easily."
        ],
        "isCorrect": true
      },
      {
        "id": 4443,
        "content": [
          "permanent capitals were easy targets for attack by subject populations"
        ],
        "isCorrect": false
      },
      {
        "id": 4444,
        "content": [
          "the empire lacked materials to construct permanent settlements."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1111,
    "content": [
      "What was the major feature of early capitalism in Europe?"
    ],
    "explanation": [
      "The major feature of early capitalism in Europe was the greater use of money as capital rather than just income.\n\nWith the increase in trade and growth of towns, new economic classes began accumulating capital for further investment, leading to the creation of modern financial institutions like banks which encouraged saving."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_EUROPE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4445,
        "content": [
          "Greater use of money as capital rather than just income."
        ],
        "isCorrect": true
      },
      {
        "id": 4446,
        "content": [
          "The shift in motivation from making profits to humanitarianism."
        ],
        "isCorrect": false
      },
      {
        "id": 4447,
        "content": [
          "Decline in international trade due to internal and external war."
        ],
        "isCorrect": false
      },
      {
        "id": 4448,
        "content": [
          "Replacement of human and animal labor to machines in production."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1112,
    "content": [
      "Which of the following is correct about the Aksumite state?"
    ],
    "explanation": [
      "Aksumite kingdom's rise and expansion were closely linked to its involvement in and desire to control trade routes.\n\nAksum generated considerable income from local and external trade conducted via the port of Adulis on the Red Sea coast.\n\nThe nucleus of the Aksumite state, initially small, gradually expanded to include territories that would facilitate its control over trade.\n\nThe importance of trade is further highlighted by Aksum's development of shipbuilding technology at Adulis, enabling it to become a major naval and trading power.\n\nThe decline of Aksum is also attributed to the loss of control over Red Sea trade routes and the destruction of Adulis."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4449,
        "content": [
          "Its expansion was due to the desire to control trade routes."
        ],
        "isCorrect": true
      },
      {
        "id": 4450,
        "content": [
          "It was established by immigrants from South Arabia."
        ],
        "isCorrect": false
      },
      {
        "id": 4451,
        "content": [
          "It directly inherited the political institutions of Punt and Damat."
        ],
        "isCorrect": false
      },
      {
        "id": 4452,
        "content": [
          "Its rulers ruled their subjects directly."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1113,
    "content": [
      "What explains the rise of the Zagwe dynasty to power?"
    ],
    "explanation": [
      "The rise of the Zagwe dynasty to power can be primarily explained by their success in effectively mobilizing the Agaw people.\n\nThe Zagwe dynasty originated from the local Agaw ruling class in Lasta. Mera Tekle Haymanot, the founder of the dynasty, was himself an Agaw. The establishment of the Zagwe dynasty around 1150 AD represented a political power shift from the Semitic-speaking Aksumite rulers to the Cushitic-speaking Agaw people."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4453,
        "content": [
          "Their success in effectively mobilizing the Agaw people."
        ],
        "isCorrect": true
      },
      {
        "id": 4454,
        "content": [
          "Their achievements in architectural development."
        ],
        "isCorrect": false
      },
      {
        "id": 4455,
        "content": [
          "Their integration into the Aksumite economic and politics."
        ],
        "isCorrect": false
      },
      {
        "id": 4456,
        "content": [
          "Their success in preserving Christianity elements."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1114,
    "content": [
      "Which one of the following accounts for the downfall of the Zagwe?"
    ],
    "explanation": [
      "Zagwe Dynasty came to an end due to internal problems of royal succession and opposition from groups claiming descent from the ancient rulers of Aksum. These groups considered the Zagwe kings “illegitimate rulers”."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4457,
        "content": [
          "Succession struggle"
        ],
        "isCorrect": true
      },
      {
        "id": 4458,
        "content": [
          "Economic decline"
        ],
        "isCorrect": false
      },
      {
        "id": 4459,
        "content": [
          "Outbreak of plague"
        ],
        "isCorrect": false
      },
      {
        "id": 4460,
        "content": [
          "Religious controversy"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1115,
    "content": [
      "What idea from the Renaissance period became and dominant in the Modern World?"
    ],
    "explanation": [
      "The Renaissance was marked by a renewed interest in the classical civilizations of Greece and Rome.\n\nLike the ancient Greeks, Renaissance thinkers believed in the power of human reason to explain the world. They placed great emphasis on the dignity, worth, and uniqueness of each person. This spirit of inquiry led to significant discoveries in science."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4461,
        "content": [
          "The divine origin of human life"
        ],
        "isCorrect": false
      },
      {
        "id": 4462,
        "content": [
          "Reconcilability of with secular life"
        ],
        "isCorrect": false
      },
      {
        "id": 4463,
        "content": [
          "The non-understandability of the universe"
        ],
        "isCorrect": false
      },
      {
        "id": 4464,
        "content": [
          "Reason and the possibility of progress"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1116,
    "content": [
      "How Yekuno Amlak restore the so-called \"Solomonic\" Dynasty in 1270?"
    ],
    "explanation": [
      "Yekuno Amlak and his followers claimed descent from the Aksumite kings through the legendary union of the Queen of Sheba and King Solomon. This claim was elaborated in the 14th-century book \"Kibre Negest\" (the Glory of Kings), which asserted that the Ethiopian ruling class descended from Menelik I, the son of Solomon and Sheba.\n\nYekuno Amlak used this legend to delegitimize the Zagwe rulers, portraying them as \"illegitimate\" successors to the Aksumite throne. By establishing a genealogy that linked him to the last Aksumite king, Dil Naod, who was allegedly deposed by the Zagwe, Yekuno Amlak presented himself as the \"restorer\" of the ancient and rightful dynasty."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4465,
        "content": [
          "By referring the Zagwe as usurpers and hence eroding its acceptance."
        ],
        "isCorrect": true
      },
      {
        "id": 4466,
        "content": [
          "By securing recognition from the Egyptian Coptic Church."
        ],
        "isCorrect": false
      },
      {
        "id": 4467,
        "content": [
          "By getting support from the Holy Land of Jerusalem."
        ],
        "isCorrect": false
      },
      {
        "id": 4468,
        "content": [
          "By blocking the Zagwe from being crowned as emperors at Aksum."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1117,
    "content": [
      "How did Islam spread in to central and eastern Ethiopia during the medieval period? It was through"
    ],
    "explanation": [
      "The port of Zeila on the Gulf of Aden was the most important gateway for the spread of Islam into the interior of the Ethiopian region.\n\nArab and non-Arab Muslim merchants were the main agents of this expansion. They established market centers along the trade routes leading from Zeyla into the interior.\n\nAs these merchants stayed in the market centers for trade, they interacted with the local pastoral communities and gradually converted them to Islam."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4469,
        "content": [
          "Islamic Holy war of jihads."
        ],
        "isCorrect": false
      },
      {
        "id": 4470,
        "content": [
          "the migration of Arab clans."
        ],
        "isCorrect": false
      },
      {
        "id": 4471,
        "content": [
          "the agency of nomadic pastoralists."
        ],
        "isCorrect": false
      },
      {
        "id": 4472,
        "content": [
          "the activities of traders and sheikhs."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1118,
    "content": [
      "What was the main factor for the expansion of the Christian kingdom in north and central Ethiopia from the 13th to the 16th centuries?"
    ],
    "explanation": [
      "The main motives of expansion were economic and political, i.e., to control the trade routes and territorial seizures."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4473,
        "content": [
          "The wish to convert Muslim populations to Christianity"
        ],
        "isCorrect": false
      },
      {
        "id": 4474,
        "content": [
          "The desire to establish ports on the Red Sea and the Indian Ocean"
        ],
        "isCorrect": false
      },
      {
        "id": 4475,
        "content": [
          "The desire to increase revenue by controlling trade routes"
        ],
        "isCorrect": true
      },
      {
        "id": 4476,
        "content": [
          "The wish to acquire new lands for a rapidly growing population"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1119,
    "content": [
      "Which of the following was a consequence of the wars between the Christian State and Adal under Imam Ahmed al-Ghazi?"
    ],
    "explanation": [
      "Christian State shifted its capital to the Lake Tana area as a result of the pressure from Adal and the subsequent Oromo expansion of the sixteenth century. Imam Ahmed's wars were a major part of this pressure in the first half of the 16th century.\n\nBefore these wars, the central highlands, including Shewa, had been a significant political center for the Christian Kingdom."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4477,
        "content": [
          "The decline of the importance of trade routes leading to Zeila."
        ],
        "isCorrect": false
      },
      {
        "id": 4478,
        "content": [
          "The partition of the Red Sea between the Portuguese and Ottomans."
        ],
        "isCorrect": false
      },
      {
        "id": 4479,
        "content": [
          "The end of ruling the Christian state from permanent seat in Shewa."
        ],
        "isCorrect": true
      },
      {
        "id": 4480,
        "content": [
          "The adoption of agriculture by many pastoralists in eastern Ethiopia."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1120,
    "content": [
      "What distinguished Imam Ahmed Al-Ghazi from his predecessors?"
    ],
    "explanation": [
      "He persuaded the fighting groups to abandon their differences and launch a war against the Christian Highland Kingdom. The restoration of peace in the region enabled Ahmad to recruit a large number of soldiers into his army from among the people."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4481,
        "content": [
          "His use of a cavalry rather than an infantry force in his wars."
        ],
        "isCorrect": false
      },
      {
        "id": 4482,
        "content": [
          "His mobilization of armies from Afar and Somali in his campaigns."
        ],
        "isCorrect": true
      },
      {
        "id": 4483,
        "content": [
          "His used the religious animosity to mobilize the Muslim population."
        ],
        "isCorrect": false
      },
      {
        "id": 4484,
        "content": [
          "His decision to conquer the Christian kingdom rather than raid it."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1121,
    "content": [
      "Which one of the following explains why Italian unification became successful?"
    ],
    "explanation": [
      "**Armed uprisings** were a significant part of the unification process. Giuseppe Garibaldi, leading his \"Red Shirts,\" successfully captured Sicily and parts of southern Italy through military action.\n\n**Diplomatic pressure and alliances** were equally crucial. Camillo Cavour, the prime minister of Piedmont-Sardinia, skillfully used diplomacy to advance the cause of unification. He formed a crucial alliance with France under Napoleon III against Austria. The Italian government also strategically used the Austro-Prussian War of 1866 and the Franco-Prussian War of 1870-71 to gain Venetia and Rome, respectively, completing the unification."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_EUROPE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4485,
        "content": [
          "The adoption of a mixed strategy by the Italians that combined armed uprising and diplomatic pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 4486,
        "content": [
          "The decision of the Austrian Hapsburgs to support Italian unification."
        ],
        "isCorrect": false
      },
      {
        "id": 4487,
        "content": [
          "The weakening of the Hapsburgs both economically and politically."
        ],
        "isCorrect": false
      },
      {
        "id": 4488,
        "content": [
          "The mobilization of liberals, conservatives and the papal states by Piedmont-Sardinia for the cause."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1122,
    "content": [
      "Which one of the following was the major factor for the colonial occupation in Africa?"
    ],
    "explanation": [
      "European powers possessed military superiority due to professional and well-trained armies.\n\nThe advent of developed technology in Europe by the period of New Imperialism, including better firearms, river boats, steam ships, and the discovery of medicine to combat malaria, enabled Europeans to penetrate deep into the African interior and overcome challenges that had hindered them before."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4489,
        "content": [
          "Collection of ethnographic and geographical information by missionaries and explorers."
        ],
        "isCorrect": false
      },
      {
        "id": 4490,
        "content": [
          "Internal divisions within African societies and the factorial support provided by the Europeans."
        ],
        "isCorrect": false
      },
      {
        "id": 4491,
        "content": [
          "Europeans military and technological superiority over the pre-colonial African states."
        ],
        "isCorrect": true
      },
      {
        "id": 4492,
        "content": [
          "The absence of centralized state structures among many African populations at the time."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1123,
    "content": [
      "Who were the traders dominated long distance trade in the Southwestern region during the 19th-century?"
    ],
    "explanation": [
      "During the 19th century, Muslim merchants were the most dominant group that travelled from the interior to the coast in long-distance trade. Among these were the northern Muslim merchants known as Jabarti and Southwestern Muslim Oromo merchants known as Afkala.\n\nThe Afkala were the dominant Muslim merchants in southwestern Ethiopia and came to dominate the local trade of the Gibe region.\n\nThe Jabarti had a dominant role in the long-distance trade of the nineteenth century until they began to face competition from the Afkala.\n\nBy the middle of the nineteenth century, most of the caravan trade between the south and northern Ethiopia was conducted by the Afkala.\n\nLong-distance trade routes of the 19th century that linked the southern and northern parts of modern Ethiopia started from Bonga, the capital of the Kingdom of Kafa. Muslim traders known as Afkala and Jabarti played a pivotal role in this trade."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4493,
        "content": [
          "Saffare"
        ],
        "isCorrect": false
      },
      {
        "id": 4494,
        "content": [
          "Jabarti"
        ],
        "isCorrect": false
      },
      {
        "id": 4495,
        "content": [
          "Jallaba"
        ],
        "isCorrect": false
      },
      {
        "id": 4496,
        "content": [
          "Afkala"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1124,
    "content": [
      "What does the Liche Treaty of 1878 tell us about Emperor Yohannes IV's' style of rule? That he"
    ],
    "explanation": [
      "Emperor Yohannes IV attempted to introduce a decentralized system of administration.\n\nThe Liche agreement of 1878, through which Yohannes IV recognized Menilek as Negus of Shewa, is a typical example of this decentralized approach and his willingness to permit regional rulers to exercise significant autonomy.\n\nYohannes IV was generally willing and ready to share power with his vassals. He granted a great deal of autonomy to regional and dynastic rulers. He generally did not interfere in the internal affairs of his vassals as long as they recognized his overlordship and paid tribute."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4497,
        "content": [
          "favored negotiations and power sharing to build imperial authority."
        ],
        "isCorrect": true
      },
      {
        "id": 4498,
        "content": [
          "was cruel towards his rivals and sought to eliminate them for the last."
        ],
        "isCorrect": false
      },
      {
        "id": 4499,
        "content": [
          "lacked consistency in his approach to local rulers."
        ],
        "isCorrect": false
      },
      {
        "id": 4500,
        "content": [
          "was influenced by his religious thought in his administration."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1125,
    "content": [
      "Which one of the following was a consequence of the battle of Adwa?"
    ],
    "explanation": [
      "After the Battle of Adwa, Italy was forced to sign the Treaty of Addis Ababa on October 26, 1896. In this treaty, Italy officially recognized the independence of Ethiopia (minus Eritrea). Italy was the first European state to do so without any reservation.\n\nFollowing Italy's recognition, several other world powers also recognized Ethiopia as a sovereign state and established legations in Addis Ababa."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4501,
        "content": [
          "The acquisition of an outlet to the sea for Ethiopia."
        ],
        "isCorrect": false
      },
      {
        "id": 4502,
        "content": [
          "The end of Ethiopia's encirclement by hostile powers."
        ],
        "isCorrect": false
      },
      {
        "id": 4503,
        "content": [
          "The recognition of Ethiopia as an independent country."
        ],
        "isCorrect": true
      },
      {
        "id": 4504,
        "content": [
          "The end of Italian colonial aspirations in the Horn of Africa."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1126,
    "content": [
      "Which of the following was a feature of the period of the Diarchy (1916-1930) in Ethiopian politics?"
    ],
    "explanation": [
      "The Diarchy (1916-1930) is described as a period where power was theoretically shared between Empress Zewditu and Ras Teferi Mekonnen.\n\nHowever, in practice, Ras Teferi's power grew progressively, leading to a deterioration in relations between the two."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4505,
        "content": [
          "The absence of power struggle within the ruling class."
        ],
        "isCorrect": false
      },
      {
        "id": 4506,
        "content": [
          "Struggle for power among groups within the ruling class."
        ],
        "isCorrect": true
      },
      {
        "id": 4507,
        "content": [
          "The introduction of major political and constitutional reforms."
        ],
        "isCorrect": false
      },
      {
        "id": 4508,
        "content": [
          "Rapid penetration of foreign capital into the country."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1127,
    "content": [
      "Why did the Shoan nobility remove Itege Tayitu from power in 1910? Because"
    ],
    "explanation": [
      "Tayitu's growing influence was seen as a threat to the Shoan nobility. Taytu’s action provoked opposition from the Shewan nobility headed by Ras Bitwoded Tesema Nadew and Fitawrari Habte Giorgis Dinegde.\n\nShoan nobles saw her as a \"significant danger to their dominion.” Tayitu's use of marriage alliances to consolidate power was likely perceived as a way to elevate non-Shoan individuals or groups, potentially at the expense of the Shoan elite."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4509,
        "content": [
          "they disliked her attempt to undermine Shoan dominance."
        ],
        "isCorrect": true
      },
      {
        "id": 4510,
        "content": [
          "she favored the Germans over the Britain and France diplomatic shift."
        ],
        "isCorrect": false
      },
      {
        "id": 4511,
        "content": [
          "she began to reverse the modernization steps of Emperor Menelik."
        ],
        "isCorrect": false
      },
      {
        "id": 4512,
        "content": [
          "she demonstrated lack of judgement in making decisions."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1128,
    "content": [
      "Which one of the following initiatives of Lij Iyasu can be said to have improved the condition of the Ethiopian peasantry?"
    ],
    "explanation": [
      "Iyasu \"tried to reform property ownership and taxation\". The idea that the payment of tithe (asrat) should be on the basis of actual produce aligns with a potential effort to make taxation fairer for the peasantry. If the tithe was previously levied based on estimated yields or fixed amounts, regardless of actual harvest, then basing it on actual produce would provide relief to peasants in years of poor harvest, thus improving their condition."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4513,
        "content": [
          "The establishment of a modern police force called Terenbulle as the first municipal force."
        ],
        "isCorrect": false
      },
      {
        "id": 4514,
        "content": [
          "The requirement that all businesses should be audited periodically to make sure they paid taxes."
        ],
        "isCorrect": false
      },
      {
        "id": 4515,
        "content": [
          "The appointment of local administrators on the basis of merit to the central administration office."
        ],
        "isCorrect": false
      },
      {
        "id": 4516,
        "content": [
          "The decision that the payment of tithe (asrat) should be on the basis of actual produce."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1129,
    "content": [
      "In what way did the Constitution of 1931 contribute to the consolidation of Haile Selassie I's autocratic power?"
    ],
    "explanation": [
      "The Constitution of 1931 significantly contributed to the consolidation of Emperor Haile Selassie I's autocratic power in several ways, most notably by reducing the power of the hereditary aristocracy.\n\nThe 1931 Constitution provided a legal framework for Haile Selassie's emerging autocratic rule. It recognized the emperor's unrestricted rights to make appointments and dismiss people, administer justice, declare and end wars, and grant lands and honors. This concentrated significant power in the hands of the emperor.\n\nThe constitution led to the loss of political influence for the provincial hereditary aristocracy. Except for Tigray, which had a special arrangement, other provinces lost their internal autonomy and were placed under governors appointed directly by the Emperor. This directly diminished the power of regional lords who could have potentially challenged the emperor's authority.\n\nThe constitution helped Emperor Haile Selassie strengthen his power by removing hereditary rulers. The focus was on creating a centralized state under his control."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4517,
        "content": [
          "It gave the emperor the right to pardon crimes against the state."
        ],
        "isCorrect": false
      },
      {
        "id": 4518,
        "content": [
          "It created a parliament that would debate and approve legislation."
        ],
        "isCorrect": false
      },
      {
        "id": 4519,
        "content": [
          "It reduced the power of nobilities not to challenge his power."
        ],
        "isCorrect": true
      },
      {
        "id": 4520,
        "content": [
          "It enhanced the image of the emperor as a progressive leader."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1130,
    "content": [
      "Which one of the following African resistance movements was related to colonial Cotton plantation?"
    ],
    "explanation": [
      "The Maji Maji Uprising in Tanganyika (modern-day Tanzania) from 1905 to 1907 was a significant African challenge to German colonial rule.\n\nThe rebellion broke out in the southern part of the colony, in the hinterland of Kilwa, in July 1905. It began in the Matumbi hills following the imposition of heavy taxes and the use of forced labor in the cotton growing farms for export.\n\nThe German rulers imposed high taxation and a system of forced labor on their colonial subjects. They were forced to grow cotton and build roads for their European occupiers."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4521,
        "content": [
          "The Ndebele resistance in Zimbabwe"
        ],
        "isCorrect": false
      },
      {
        "id": 4522,
        "content": [
          "The Maji Maji rebellion in Tanganyika"
        ],
        "isCorrect": true
      },
      {
        "id": 4523,
        "content": [
          "The resistance of the Ashanti kingdom"
        ],
        "isCorrect": false
      },
      {
        "id": 4524,
        "content": [
          "The resistance of the Mandinka Empire"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1131,
    "content": [
      "Why did Bismarck organize the alliance system?"
    ],
    "explanation": [
      "Bismarck wanted security for his country and demanded alliances to isolate France and tie other powers with Germany. This was the fundamental aim behind the creation of the Dual Alliance between Germany and Austro-Hungary in 1879, which committed them to support each other if attacked by Russia.\n\nThe Dual Alliance later expanded into the Triple Alliance in 1882, uniting Germany, Austro-Hungary, and Italy. This system of alliances was a cornerstone of German foreign policy up to World War I."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_EUROPE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4525,
        "content": [
          "To solve European colonial rivalry in Africa peacefully"
        ],
        "isCorrect": false
      },
      {
        "id": 4526,
        "content": [
          "To weaken British dominance in European politics"
        ],
        "isCorrect": false
      },
      {
        "id": 4527,
        "content": [
          "To support the Ottoman Empire against Russian expansion"
        ],
        "isCorrect": false
      },
      {
        "id": 4528,
        "content": [
          "To secure protection for Germany against French hostility"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1132,
    "content": [
      "Which of the following was a consequence of the 1917 Revolution in Russia?"
    ],
    "explanation": [
      "Following the October Revolution, the Bolsheviks, led by Vladimir Lenin, seized power and established a new government based on the ideas of Karl Marx, marking the beginning of the spread of communism in the twentieth century.\n\nThe Bolsheviks established a government called the Soviet Council of People’s Commissars, with key positions held by Bolsheviks like Lenin and Trotsky. The Russian Revolution, through Communism, served as a model for third world countries seeking to modernize their governments.\n\nThe fear of Communism spreading to Eastern Europe during the Cold War demonstrates the global impact of the Russian Revolution. The Russian Revolution became an inspiration for colonized peoples of Africa and Asia in their anti-colonial struggle.\n\nThe strengthening of the U.S.S.R. after the Second World War changed the international balance of power, with the U.S.S.R. becoming a strong supporter of the national liberation struggle in Africa, Asia, and Latin American countries.\n\nThe Soviet Union was founded on a communist system controlled by a centralized state and a single political party."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4529,
        "content": [
          "The restoration of Russian control over neighboring states such as Ukraine and Poland."
        ],
        "isCorrect": false
      },
      {
        "id": 4530,
        "content": [
          "Implementation of the Communism as an official ideology in Russia and influenced other world."
        ],
        "isCorrect": true
      },
      {
        "id": 4531,
        "content": [
          "The withdrawal of Russia from international politics until the beginning of WWII."
        ],
        "isCorrect": false
      },
      {
        "id": 4532,
        "content": [
          "The shift of Russian modernization efforts from the cities to the countryside."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1133,
    "content": [
      "What was the immediate cause of the Second World War?"
    ],
    "explanation": [
      "World War II broke out on September 1, 1939, when Hitler invaded Poland. \n\nHitler believed that England and France would not resist him, but he was wrong. On September 3, 1939, England and France declared war on Germany. This action was in response to Germany's invasion of Poland, with whom Britain and France had defensive alliances."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4533,
        "content": [
          "The publication of the Axis powers' secret plan to partition the globe."
        ],
        "isCorrect": false
      },
      {
        "id": 4534,
        "content": [
          "The withdrawal of Germany's pledge to guarantee the sovereignty of Czechoslovakia."
        ],
        "isCorrect": false
      },
      {
        "id": 4535,
        "content": [
          "British decision to occupy the port of Danzig as a pre-emptive action against German invasion."
        ],
        "isCorrect": false
      },
      {
        "id": 4536,
        "content": [
          "Germany's invasion of Poland threatened both Britain and France."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1134,
    "content": [
      "Which organ of the UN was responsible for facilitating the independence of former mandated territories?"
    ],
    "explanation": [
      "The Trusteeship Council was the fourth principal organ of the United Nations. It was responsible for the supervision of territories that were under the international trusteeship system.\n\nThese territories included former colonies of Germany, Italy, and Japan, and League of Nation mandates that had not gained independence by the end of World War II in 1945.\n\nThe Trusteeship Council was charged with helping these areas to achieve independence. By 1994, all Trust Territories had attained independence. The last to do so was Palau."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4537,
        "content": [
          "The Security Council"
        ],
        "isCorrect": false
      },
      {
        "id": 4538,
        "content": [
          "The Trusteeship Council"
        ],
        "isCorrect": true
      },
      {
        "id": 4539,
        "content": [
          "The International Court of Justice"
        ],
        "isCorrect": false
      },
      {
        "id": 4540,
        "content": [
          "The UN Secretariat"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1135,
    "content": [
      "Which of the following was a consequence of the Marshall Plan?"
    ],
    "explanation": [
      "The \"European Recovery Program\", better known as the Marshall Plan, called for the U.S. Congress to allocate billions of dollars for the reconstruction of Europe after World War II.\n\nAlmost all countries of Western Europe received economical assistance from the United States through the Marshall Plan. Proposed by U.S. Secretary of State George C. Marshall, the program was designed to speed European recovery from economic ruin.\n\nThe Marshall Plan made possible a miraculous economic recovery in the West. The program did much to set the European economy back on its feet after the war. By the time the aid ended in 1952, Western Europe's industrial production stood 35 percent above pre-war levels, and West Germany was economically booming."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4541,
        "content": [
          "The containment of Communism from spreading to Asia and Africa."
        ],
        "isCorrect": false
      },
      {
        "id": 4542,
        "content": [
          "The division of Germany between the Capitalist West and Communist East"
        ],
        "isCorrect": false
      },
      {
        "id": 4543,
        "content": [
          "The extension of American political influence to Latin American countries."
        ],
        "isCorrect": false
      },
      {
        "id": 4544,
        "content": [
          "The economic recovery of Western European countries after WWII."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1136,
    "content": [
      "What was the cause of the Cold War?"
    ],
    "explanation": [
      "The primary cause of the Cold War was the desire of the superpowers (the USA and the USSR) to extend their political and strategic influence across the globe.\n\nThis competition arose in the aftermath of World War II, which left these two nations as the dominant global powers with fundamentally different ideologies and socio-economic systems."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4545,
        "content": [
          "Conflict between the supporters of free market & planned economic systems."
        ],
        "isCorrect": false
      },
      {
        "id": 4546,
        "content": [
          "Desire of the super powers to extend their political and strategic influence across the globe."
        ],
        "isCorrect": true
      },
      {
        "id": 4547,
        "content": [
          "Difference between the two superpowers on how to partition Africa and Asia."
        ],
        "isCorrect": false
      },
      {
        "id": 4548,
        "content": [
          "Rivalry between the super powers to send the first mission to outer space."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1137,
    "content": [
      "Which of the following countries did NOT belong to the Warsaw Pact?"
    ],
    "explanation": [
      "The Warsaw Pact was a military alliance of eight European Communist nations: Albania, Bulgaria, Czechoslovakia, East Germany, Hungary, Poland, Romania, and the USSR.\n\nThe treaty establishing it was signed in Warsaw, Poland, on May 14, 1955. The establishment of the Warsaw Pact was prompted by the rearmament of West Germany and its admission to NATO. West Germany (the German Federal Republic) joined NATO in 1955.\n\nGermany was partitioned into four zones of occupation after World War II, with the American, British, and French zones forming West Germany, and the Soviet zone becoming East Germany. East Germany was a member of the Warsaw Pact."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4549,
        "content": [
          "Romania"
        ],
        "isCorrect": false
      },
      {
        "id": 4550,
        "content": [
          "The Soviet Union"
        ],
        "isCorrect": false
      },
      {
        "id": 4551,
        "content": [
          "West Germany"
        ],
        "isCorrect": true
      },
      {
        "id": 4552,
        "content": [
          "Hungary"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1138,
    "content": [
      "What was the Vietnamese city that was renamed as Ho Chi Minh City following Communist victory over the US?"
    ],
    "explanation": [
      "Following the Communist seizure of power in the South on April 30, 1975, and the reunification of Vietnam in 1976 into the Socialist Republic of Vietnam, Saigon was renamed Ho Chi Minh City."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4553,
        "content": [
          "Saigon"
        ],
        "isCorrect": true
      },
      {
        "id": 4554,
        "content": [
          "Peking"
        ],
        "isCorrect": false
      },
      {
        "id": 4555,
        "content": [
          "Dien Bien Phu"
        ],
        "isCorrect": false
      },
      {
        "id": 4556,
        "content": [
          "Hanoi"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1139,
    "content": [
      "Which of the following was a factor for the collapse of Communism in the late 1980s?"
    ],
    "explanation": [
      "In 1989, nationalist movements started and brought regime change in Poland, and this movement soon spread to Hungary, Czechoslovakia, Yugoslavia, and Romania. As these Soviet republics pulled away from the Soviet Union, the power of the central state weakened.\n\nBy 1991, the communist governments of Bulgaria, Czechoslovakia, East Germany, Hungary, Poland, and Romania were brought down as revolution swept Eastern Europe. The liberation of East Europe inspired many Soviet Union republics to struggle harder for liberation from Moscow. In 1989, anti-communism movements spread throughout the Eastern Bloc."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4557,
        "content": [
          "The rise of anti-communist movements in the Eastern Europe"
        ],
        "isCorrect": true
      },
      {
        "id": 4558,
        "content": [
          "Political and economic reforms initiated by Gorbachev"
        ],
        "isCorrect": false
      },
      {
        "id": 4559,
        "content": [
          "Rivalry between the Soviet and Chinese forms of communism"
        ],
        "isCorrect": false
      },
      {
        "id": 4560,
        "content": [
          "Loss of popular support for the ideology at the global level"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1140,
    "content": [
      "Why did the Imperial government fail to carry out a land reform program in the late 1960s and early 1970s? Because it"
    ],
    "explanation": [
      "The Imperial government failed to carry out a land reform program in the late 1960s and early 1970s primarily because it feared strong opposition from the big landowners."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4561,
        "content": [
          "lacked the technical and financial resources for its realization."
        ],
        "isCorrect": false
      },
      {
        "id": 4562,
        "content": [
          "feared that there would be opposition from the peasantry."
        ],
        "isCorrect": false
      },
      {
        "id": 4563,
        "content": [
          "was preoccupied with peasant rebellions in Gojjam and Bale."
        ],
        "isCorrect": false
      },
      {
        "id": 4564,
        "content": [
          "feared that there would be strong opposition from the big land owners."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1141,
    "content": [
      "To which of the following is the concept of objectivity related when applied to the study of history? The ability to"
    ],
    "explanation": [
      "The concept of objectivity when applied to the study of history is most closely related to the ability to avoid subjectivity on the part of the historian."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4565,
        "content": [
          "interpret events based on one's subjective experience."
        ],
        "isCorrect": false
      },
      {
        "id": 4566,
        "content": [
          "explain change in a clear and logical manner."
        ],
        "isCorrect": false
      },
      {
        "id": 4567,
        "content": [
          "avoid subjectivity on the part of the historian."
        ],
        "isCorrect": true
      },
      {
        "id": 4568,
        "content": [
          "identify original sources by the historian."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1142,
    "content": [
      "What is the significance of periodization in historical studies? It helps to"
    ],
    "explanation": [
      "Periodization in historical studies helps to trace continuities and change through time by dividing history into meaningful periods."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4569,
        "content": [
          "trace continuities and change through time."
        ],
        "isCorrect": true
      },
      {
        "id": 4570,
        "content": [
          "make the work of history to screen usable sources."
        ],
        "isCorrect": false
      },
      {
        "id": 4571,
        "content": [
          "distinguish professional history from popular history."
        ],
        "isCorrect": false
      },
      {
        "id": 4572,
        "content": [
          "sort out factual details from factious narratives."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1143,
    "content": [
      "With which of the following homo species are Acheulean tools associated?"
    ],
    "explanation": [
      "Oldowan tools are generally identified with Homo habilis, while Acheulean tools with that of Homo erectus."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4573,
        "content": [
          "Homo africanus"
        ],
        "isCorrect": false
      },
      {
        "id": 4574,
        "content": [
          "Homo habilis"
        ],
        "isCorrect": false
      },
      {
        "id": 4575,
        "content": [
          "Homo erectus"
        ],
        "isCorrect": true
      },
      {
        "id": 4576,
        "content": [
          "Homo sapiens"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1144,
    "content": [
      "Which of the following is a characteristics of the Upper Paleolithic?"
    ],
    "explanation": [
      "During the Upper Paleolithic period, standardized blade technology appeared and became more widespread than in previous times.\n\nTowards the end of the Upper Paleolithic, microliths (small, geometric-shaped blade segments) became increasingly common in many areas.\n\nThese microliths were fitted into handles and used as “Composite tools” in arrows and bows."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4577,
        "content": [
          "Composite tools made out of stone and Bone"
        ],
        "isCorrect": true
      },
      {
        "id": 4578,
        "content": [
          "Lack of change in tool making techniques in Africa"
        ],
        "isCorrect": false
      },
      {
        "id": 4579,
        "content": [
          "Tools made out of metals like copper and bronze"
        ],
        "isCorrect": false
      },
      {
        "id": 4580,
        "content": [
          "Highly selective breeding of livestock"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1145,
    "content": [
      "Which one of the following explanation is NOT correct according to the theories of emergence of early states?"
    ],
    "explanation": [
      "Chiefs along trade routes could collect tolls, increase their wealth, gain followers, and establish permanent power as kings.\n\nSuccessful military leaders becoming kings is also a recognized theory. Permanent war leaders could gain loyal followers and emerge as kings due to frequent wars.\n\nPriests establishing political control in the name of gods aligns with the \"Devine Right Theory.\""
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4581,
        "content": [
          "Those who control trade routes become rulers."
        ],
        "isCorrect": false
      },
      {
        "id": 4582,
        "content": [
          "Successful military leaders become kings."
        ],
        "isCorrect": false
      },
      {
        "id": 4583,
        "content": [
          "Priests established political control in the name of gods."
        ],
        "isCorrect": false
      },
      {
        "id": 4584,
        "content": [
          "People who organize religious pilgrimages become leaders."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1146,
    "content": [
      "Which one of the following was a major achievement of the Indus Valley civilization?"
    ],
    "explanation": [
      "Archaeologists have discovered two major cities of the Indus Valley civilization, Mohenjo-daro and Harappa, and notes that \"the rectangular pattern of the streets and the buildings suggest some kind of urban planning\"."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4585,
        "content": [
          "The development of a writing system"
        ],
        "isCorrect": false
      },
      {
        "id": 4586,
        "content": [
          "The construction of refined Buddhist temples"
        ],
        "isCorrect": false
      },
      {
        "id": 4587,
        "content": [
          "The development of urban planning techniques"
        ],
        "isCorrect": true
      },
      {
        "id": 4588,
        "content": [
          "The writing of a complex legal code"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1147,
    "content": [
      "What was the major contribution of Greek civilization to the Western world?"
    ],
    "explanation": [
      "Athens introduced the principle of direct democracy where all adult citizens, except women and slaves, took part in decision making processes.\n\nCitizens could attend, speak, and vote in the Assembly, which passed laws and determined government policies. This development of direct democracy in ancient Greece has significantly influenced political thought and systems in the Western world."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_EUROPE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4589,
        "content": [
          "Ideas about direct participatory democracy"
        ],
        "isCorrect": true
      },
      {
        "id": 4590,
        "content": [
          "Rejection of slavery as an institution"
        ],
        "isCorrect": false
      },
      {
        "id": 4591,
        "content": [
          "Techniques of building roads that last long"
        ],
        "isCorrect": false
      },
      {
        "id": 4592,
        "content": [
          "The use of the wheeled transport"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1148,
    "content": [
      "What was a common achievement of the civilizations of Egypt and Mesopotamia?"
    ],
    "explanation": [
      "Egyptians contributed a lot in the field of a writing system (hieroglyphic). Egyptian hieroglyphics developed around 3000 BC and were used in combination with papyrus, a paper-like substance.\n\nSumerians (Mesopotamia) developed a writing system between about 3200-2900 BC. This system as using wedge-shaped characters called cuneiform, written on clay tablets."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4593,
        "content": [
          "The invention of techniques for preserving the bodies of the dead."
        ],
        "isCorrect": false
      },
      {
        "id": 4594,
        "content": [
          "The development of a writing system for administrative purposes."
        ],
        "isCorrect": true
      },
      {
        "id": 4595,
        "content": [
          "The construction of elaborate religious buildings using clay bricks."
        ],
        "isCorrect": false
      },
      {
        "id": 4596,
        "content": [
          "The invention of techniques for purifying copper and iron."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1149,
    "content": [
      "Which of the following characterizes feudal society in Medieval Europe?"
    ],
    "explanation": [
      "Feudalism is described as a loosely organized system of rule in which powerful local lords divided their landholdings among lesser lords. In exchange, these lesser lords, or vassals, pledged loyalty and service to the greater lord."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_EUROPE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4597,
        "content": [
          "The revival of patronage for Arts and Architectures"
        ],
        "isCorrect": false
      },
      {
        "id": 4598,
        "content": [
          "The establishment of centralized empires"
        ],
        "isCorrect": false
      },
      {
        "id": 4599,
        "content": [
          "The existence of large and flourishing trade centers"
        ],
        "isCorrect": false
      },
      {
        "id": 4600,
        "content": [
          "The decentralization of state power"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1150,
    "content": [
      "Which of the following is correct about Byzantine emperors?"
    ],
    "explanation": [
      "The emperor was the absolute ruler and sole law maker in the Byzantine Empire. The empire was described as an \"Orthodox imperial autocracy\".\n\nWhile Christianity was the official state religion and had a strong influence, the government, including the emperor, had much influence over church officials. The Orthodox Church supported the emperor. This indicates that the church did not check the emperor's power."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_EUROPE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4601,
        "content": [
          "They were both religious and political leaders."
        ],
        "isCorrect": false
      },
      {
        "id": 4602,
        "content": [
          "Their power was checked by the Orthodox Church."
        ],
        "isCorrect": false
      },
      {
        "id": 4603,
        "content": [
          "They exercised absolute power over their subjects."
        ],
        "isCorrect": true
      },
      {
        "id": 4604,
        "content": [
          "Their rule was based on the model of Athenian politics."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1151,
    "content": [
      "Why did the 1960 attempted coup against Emperor Haile Selassie fail? Because"
    ],
    "explanation": [
      "The grave mistake of the coup leaders was that they made no attempt to win the support of the army and the air force. Army and air force units remained loyal to the emperor."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4605,
        "content": [
          "there was disagreement between the coup leaders on what to do with Haile Selassie's officials."
        ],
        "isCorrect": false
      },
      {
        "id": 4606,
        "content": [
          "the coup leaders failed to secure support from the army and the air force."
        ],
        "isCorrect": true
      },
      {
        "id": 4607,
        "content": [
          "the coup leaders failed to secure control of the radio station and the imperial palace."
        ],
        "isCorrect": false
      },
      {
        "id": 4608,
        "content": [
          "the coup leaders did not set up a government immediately after capturing power."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1152,
    "content": [
      "Which of the following initiatives of the Derg had a major socio-economic consequence for the peasantry?"
    ],
    "explanation": [
      "The Land Reform Proclamation of March 1975 nationalized all rural land and dismantled the socio-economic basis of feudalism. This was a radical measure that directly addressed the land tenure system, which had historically been a source of exploitation and hardship for the peasantry.\n\nThe proclamation abolished all private land ownership and set a limit on family land holdings at ten hectares. This directly impacted how peasants accessed and controlled the primary means of their livelihood – land."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4609,
        "content": [
          "The Land Reform"
        ],
        "isCorrect": true
      },
      {
        "id": 4610,
        "content": [
          "The Literacy Campaign"
        ],
        "isCorrect": false
      },
      {
        "id": 4611,
        "content": [
          "The nationalization of industries"
        ],
        "isCorrect": false
      },
      {
        "id": 4612,
        "content": [
          "The confiscation of extra houses"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1153,
    "content": [
      "What was the major factor for the outbreak of the Ethio-Somalia War of 1977/78?"
    ],
    "explanation": [
      "Somalia invaded Ethiopia in 1977 to promote its irredentist interest in the Ogaden region of Ethiopia.\n\nThe Somali state provoked Ethiopia, driven by Mahammad Siad Barre’s aim to annex the Ogaden area of Ethiopia inhabited by Somali-speaking Ethiopians.\n\nThe major reason for the war was the political agitation of the new republic of Somalia that was committed to bringing all Somali speaking territories under one five-pointed star in the Somalia flag, with one point representing the Ogaden region of Ethiopia.\n\nThe war was initiated by President Siad Barre of Somalia, who pursued his irredentist policy of achieving the creation of “Greater Somalia”."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4613,
        "content": [
          "Difference over interpreting the teachings of Marxism-Leninism."
        ],
        "isCorrect": false
      },
      {
        "id": 4614,
        "content": [
          "Rivalry between the two countries over the issue of Djibouti."
        ],
        "isCorrect": false
      },
      {
        "id": 4615,
        "content": [
          "Republic of Somalia claimed the Somali-inhabited territories of eastern Ethiopia."
        ],
        "isCorrect": true
      },
      {
        "id": 4616,
        "content": [
          "Personal animosity between Colonel Mengistu and General Siad Barre."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1154,
    "content": [
      "How did France punish Guinea for voting against continued political association with the former colonial master?"
    ],
    "explanation": [
      "After Guinea voted \"No\" in the 1958 referendum and became fully independent. France immediately recalled all its professionals and technical assistants from Guinea. France stopped other assistance to Guinea."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4617,
        "content": [
          "Sponsoring a coup against Sekou Toure"
        ],
        "isCorrect": false
      },
      {
        "id": 4618,
        "content": [
          "Denying any form assistance to the country"
        ],
        "isCorrect": true
      },
      {
        "id": 4619,
        "content": [
          "Establishing a rival government in France"
        ],
        "isCorrect": false
      },
      {
        "id": 4620,
        "content": [
          "Expelling Guinea from the French Union"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1155,
    "content": [
      "Which of the following shows the continued influence of western countries over the economies of African countries after independence?"
    ],
    "explanation": [
      "The dependence of African countries on western loans most directly shows the continued economic influence of Western countries over the economies of African countries after independence."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4621,
        "content": [
          "The export of primary and industrial products to western countries."
        ],
        "isCorrect": false
      },
      {
        "id": 4622,
        "content": [
          "The dependence on infrastructure built by the west."
        ],
        "isCorrect": false
      },
      {
        "id": 4623,
        "content": [
          "The dependence on western models of education."
        ],
        "isCorrect": false
      },
      {
        "id": 4624,
        "content": [
          "The dependence of African countries on western loans."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1156,
    "content": [
      "Which of the following was the characteristics of coups in African politics after independence?"
    ],
    "explanation": [
      "Coups were a frequent means of changing government throughout the 1970s and 1980s.\n\nMost coups against civilian regimes were initially welcomed because the military was perceived as disciplined and free from corruption, at least until they gained power.\n\nHowever, military rulers were just as likely to be corrupt and tyrannical as their civilian counterparts. Examples like General \"Emperor\" Jean Bedel Bokassa of the Central African Republics and Field Marshal Idi Amin of Uganda illustrate this point.\n\nIn some instances, military coups were triggered by ethnic tensions and fears of ethnic domination, as seen in Nigeria.\n\nCoups could also be a response to inefficient and detached governments, as in the case of General Murtala Muhammed's overthrow of General Gowon in Nigeria.\n\nCorruption, extravagant spending, and intolerance of criticism also led to military interventions, such as the overthrow of Dr. Kwame Nkrumah in Ghana.\n\nMilitary involvement in politics was often driven by specific military grievances in addition to broader political and economic issues."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4625,
        "content": [
          "Although coups were instrumental in removing authoritarian leaders, the regimes that replaced them brought very little change."
        ],
        "isCorrect": true
      },
      {
        "id": 4626,
        "content": [
          "Although coups were carried out by the military, the latter proved a revolutionary force of change in many African countries."
        ],
        "isCorrect": false
      },
      {
        "id": 4627,
        "content": [
          "Unlike coups carried out in former French colonies, coups in former British colonies succeeded in bringing change to African politics."
        ],
        "isCorrect": false
      },
      {
        "id": 4628,
        "content": [
          "Coups carried out by junior officers were successful in bringing change than coups led by generals."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1157,
    "content": [
      "What was the major political agenda of the Transitional Period (1991-1994) in Ethiopia?"
    ],
    "explanation": [
      "Following the overthrow of the Derg regime in 1991, the Ethiopian People's Revolutionary Democratic Front (EPRDF) facilitated the establishment of the Transitional Government of Ethiopia (TGE).\n\nA key task of the TGE was to create a new constitution. The TGE set up a constituent assembly for this purpose.\n\nThe \"Transitional Government Charter of Ethiopia\" was put in effect from 1991 until the endorsement of the new constitution in 1995. This charter served as a transitional constitution. The new constitution, endorsed in August 1995, aimed to recognize human and democratic rights and the rights of nations, nationalities, and peoples for self-determination. This addressed the significant \"nationality issue\". The Transitional Charter also established 14 \"self-governing regions\" of \"nations, nationalities, and peoples\", indicating a focus on group rights and federalism.\n\nThe 1995 constitution is highlighted as being better than previous constitutions because it recognized human and democratic rights, as well as international declarations on these rights. It also uniquely recognized the right to self-determination for nations, nationalities, and peoples."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4629,
        "content": [
          "Finding a new foreign partner to help with economic and social recovery after decades of war."
        ],
        "isCorrect": false
      },
      {
        "id": 4630,
        "content": [
          "Re-establishing an Ethiopian army on the basis of ethnic and regional representation."
        ],
        "isCorrect": false
      },
      {
        "id": 4631,
        "content": [
          "Transforming the country from a centralized command economy to one based on the principles of market liberalism."
        ],
        "isCorrect": false
      },
      {
        "id": 4632,
        "content": [
          "Developing a constitution that would guarantee both the democratic rights of individuals and groups."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1158,
    "content": [
      "In which of the following countries did Ethiopia take part in a UN led Peace keeping mission?"
    ],
    "explanation": [
      "Ethiopia has participated in peacekeeping missions in Korea, Congo, Rwanda, Burundi, Liberia, Sudan, South Sudan, and Somalia."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4633,
        "content": [
          "Zimbabwe"
        ],
        "isCorrect": false
      },
      {
        "id": 4634,
        "content": [
          "Sierra Leone"
        ],
        "isCorrect": false
      },
      {
        "id": 4635,
        "content": [
          "Liberia"
        ],
        "isCorrect": true
      },
      {
        "id": 4636,
        "content": [
          "Chad"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1159,
    "content": [
      "Which of the following features of indigenous knowledge has the potential to contribute to overall development of a society?"
    ],
    "explanation": [
      "Indigenous knowledge is holistic. All aspects of life are interconnected and are not considered in isolation but as a part of the whole. It incorporates all aspects of life: spirituality, history, cultural practices, social interactions, language, healing, etc."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4637,
        "content": [
          "Its sense of superiority"
        ],
        "isCorrect": false
      },
      {
        "id": 4638,
        "content": [
          "Its unchanging nature"
        ],
        "isCorrect": false
      },
      {
        "id": 4639,
        "content": [
          "Its disregard for morality"
        ],
        "isCorrect": false
      },
      {
        "id": 4640,
        "content": [
          "Its holistic nature"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1160,
    "content": [
      "Which one of the following is NOT an example of cultural heritage?"
    ],
    "explanation": [
      "The Semen National Park is a natural heritage site, not a cultural heritage site, while the Palace of Abba Jifar, Halala Kella of Dawro, and the Al Najashi Mosque are cultural heritage sites."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4641,
        "content": [
          "The Palace of Abba Jifar"
        ],
        "isCorrect": false
      },
      {
        "id": 4642,
        "content": [
          "Halala Kella of Dawro"
        ],
        "isCorrect": false
      },
      {
        "id": 4643,
        "content": [
          "The Semen National Park"
        ],
        "isCorrect": true
      },
      {
        "id": 4644,
        "content": [
          "The Al Najashi Mosque"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1161,
    "content": [
      "Why did the Schlieffen plan failed in the WWI? Because"
    ],
    "explanation": [
      "The Schlieffen Plan, designed by Von Schlieffen, aimed for a swift defeat of France by advancing through Belgium and capturing Paris within six weeks. The plan anticipated that Russia, being a large and less developed country, would be slow to mobilize, giving Germany enough time to focus on the Western Front before turning east.\n\nHowever, contrary to German expectations, the Russians mobilized more rapidly than anticipated. This forced the Germans to transfer part of their army to the Eastern Front, weakening their offensive on the Western Front.\n\nFurthermore, the German advance through Belgium was halted at the Battle of the Marne in September 1914. This prevented the quick capture of Paris and resulted in a stalemate on the Western Front with the development of trench warfare."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4645,
        "content": [
          "Germany did not receive support from Turkey on time."
        ],
        "isCorrect": false
      },
      {
        "id": 4646,
        "content": [
          "Russia mobilized quickly and attacked Germany."
        ],
        "isCorrect": true
      },
      {
        "id": 4647,
        "content": [
          "the US refused to send the arms Germany had paid for."
        ],
        "isCorrect": false
      },
      {
        "id": 4648,
        "content": [
          "Germany did not have air superiority on the western front."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1162,
    "content": [
      "What was the difference between the self-help associations and the political parties that emerged in Africa in the inter-war period?"
    ],
    "explanation": [
      "The self-help associations focused on exploring Africa for potential raw materials and markets, indicating an economic interest. The later rise of nationalist movements and political parties was clearly geared towards achieving political independence and challenging colonial rule.\n\nThe emergence of political parties signifies a shift towards organized political action with the primary goal of altering the existing power structures under colonial rule. These parties aimed to gain political rights, self-determination, and ultimately independence."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4649,
        "content": [
          "The former supported colonial rule while the latter demanded independence."
        ],
        "isCorrect": false
      },
      {
        "id": 4650,
        "content": [
          "The former were led by the educated elite while the latter were led by traditional leaders."
        ],
        "isCorrect": false
      },
      {
        "id": 4651,
        "content": [
          "The former were primarily concerned with economic issues while the latter focused on broader political matters."
        ],
        "isCorrect": true
      },
      {
        "id": 4652,
        "content": [
          "The former called for gradual transfer of power to Africans while the latter demanded speedy transfer."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1163,
    "content": [
      "Following the Wal-Wal incident of 1934, what action taken by Italy caused the outbreak of war between Ethiopia and Italy? Italy's"
    ],
    "explanation": [
      "Following the Wal-Wal incident of 1934, Italy's long-standing desire to colonize Ethiopia and Benito Mussolini's determination to restore ancient Roman glory led to a planned military invasion. The Wal-Wal incident provided a pretext for this aggression.\n\nItaly launched a war of aggression and invaded Ethiopia on October 3, 1935. Italian troops crossed the Mereb River separating Ethiopia from the Italian colony of Eritrea."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4653,
        "content": [
          "submission of unacceptable demands to the Ethiopian."
        ],
        "isCorrect": true
      },
      {
        "id": 4654,
        "content": [
          "decision to take the conflict to the League of Nations."
        ],
        "isCorrect": false
      },
      {
        "id": 4655,
        "content": [
          "deployment of army between Italo-Somaliland and Ethiopia."
        ],
        "isCorrect": false
      },
      {
        "id": 4656,
        "content": [
          "attempt to incite local populations in the border areas to rebel."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1164,
    "content": [
      "Why did the US declare war on Japan in the Second World War? Because"
    ],
    "explanation": [
      "On December 7, 1941, Japanese bombers launched a surprise attack on the American naval base at Pearl Harbor in Hawaii. This attack resulted in the sinking of 19 American ships, the destruction of 188 planes, and the death of more than 2,400 people. On the following day, December 8, 1941, the United States declared war on Japan."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4657,
        "content": [
          "the US disliked the prospect of a modernizing and rising Japan."
        ],
        "isCorrect": false
      },
      {
        "id": 4658,
        "content": [
          "Japan attacked US bases on the Pacific at Pearl Harbour."
        ],
        "isCorrect": true
      },
      {
        "id": 4659,
        "content": [
          "Japan criticized US support for the Allies power in the Pacific."
        ],
        "isCorrect": false
      },
      {
        "id": 4660,
        "content": [
          "the US wanted to take over Japan's colonies in the Far East."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1165,
    "content": [
      "What is the connection between the Atlantic Charter and the future UN? The charter underlined that"
    ],
    "explanation": [
      "The Atlantic Charter, signed in August 1941 by U.S. President Franklin D. Roosevelt and British Prime Minister Winston Churchill, was a significant step towards the establishment of the United Nations.\n\nThe signing of the Atlantic Charter was followed by the Declaration by the United Nations on January 1, 1942, where 26 countries aligned with the Allied powers formally adopted the name \"United Nations\" and affirmed their commitment to the principles outlined in the Atlantic Charter as their war aims."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4661,
        "content": [
          "the establishment of an international organization to ensure world peace."
        ],
        "isCorrect": true
      },
      {
        "id": 4662,
        "content": [
          "the various bodies of the future United Nations to be functionary."
        ],
        "isCorrect": false
      },
      {
        "id": 4663,
        "content": [
          "a detailed description of how the United Nations would be run."
        ],
        "isCorrect": false
      },
      {
        "id": 4664,
        "content": [
          "the UN would be a failure if the Security Council was dominated by the Big Five."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1166,
    "content": [
      "What was the cause of the First Arab-Israeli War of 1948/19492"
    ],
    "explanation": [
      "The cause of the First Arab-Israeli War of 1948 was primarily the Arab States' refusal to accept the partition of Palestine.\n\nFollowing the Holocaust, global opinion shifted towards supporting an independent Jewish state. In 1947, the United Nations (UN) passed a resolution calling for the partition of Palestine into separate Jewish and Arab states.\n\nHowever, the Arab states rejected this UN resolution, as they claimed Palestine solely for the Arabs.\n\nIn response, Jewish leaders in Palestine proclaimed the independent state of Israel in 1948. The declaration of the state of Israel then directly led to the Israeli-Arab War of 1948, as Syria, Lebanon, Jordan, Egypt, and Saudi Arabia attacked the newly formed state."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4665,
        "content": [
          "British decision to take the issue of Palestine to the UN."
        ],
        "isCorrect": false
      },
      {
        "id": 4666,
        "content": [
          "The Arab States' refusal to accept the partition of Palestine."
        ],
        "isCorrect": true
      },
      {
        "id": 4667,
        "content": [
          "US decision to recognize the establishment of the state of Israel."
        ],
        "isCorrect": false
      },
      {
        "id": 4668,
        "content": [
          "The Israeli occupation of Jerusalem and the West Bank."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1167,
    "content": [
      "Which of the following was common to national liberation movements in Kenya and Algeria?"
    ],
    "explanation": [
      "The common factor between the national liberation movements in Kenya and Algeria was that they both resorted to armed struggle as a strategy.\n\nIn Kenya, the Mau Mau revolt, which involved dispossessed peasants, was an act of armed resistance against British colonial rule. Although the path to independence also involved political organization (KANU), armed resistance was a significant part of their struggle.\n\nIn Algeria, the presence of a large number of white settlers who opposed independence meant that the Algerian nationalists had to wage a \"bitter guerrilla war of liberation\" against French colonial domination from 1954 to 1962."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4669,
        "content": [
          "Strong influence of communist ideology"
        ],
        "isCorrect": false
      },
      {
        "id": 4670,
        "content": [
          "Strong support from Socialist Tanzania"
        ],
        "isCorrect": false
      },
      {
        "id": 4671,
        "content": [
          "Resort to armed struggle as a strategy"
        ],
        "isCorrect": true
      },
      {
        "id": 4672,
        "content": [
          "Internal power struggle among the leaders"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1168,
    "content": [
      "Which one of the following African nationalist leaders took part in the 1945 Pan-African Congress that took place at Manchester?"
    ],
    "explanation": [
      "The Fifth Pan-African Conference were the future leaders of independent Africa, like Kwame Nkrumah of Ghana and Jomo Kenyatta of Kenya.\n\nSeveral delegates, such as Kwame Nkrumah and Jomo Kenyatta, soon left London for Africa and led their peoples into independence after the Fifth Pan-African Congress at Manchester in October 1945."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4673,
        "content": [
          "Edward Blyden"
        ],
        "isCorrect": false
      },
      {
        "id": 4674,
        "content": [
          "Julius Nyrere"
        ],
        "isCorrect": false
      },
      {
        "id": 4675,
        "content": [
          "Gamal Abdel Nasser"
        ],
        "isCorrect": false
      },
      {
        "id": 4676,
        "content": [
          "Kwame Nkrumah"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1169,
    "content": [
      "Which one of the following developments characterizes the post-liberation period in Ethiopia?"
    ],
    "explanation": [
      "Following the restoration of imperial rule in May 1941, Emperor Haile Selassie actively worked to strengthen his power and construct an absolutist state.\n\nThis involved measures such as reorganizing the administrative divisions of the country with centrally appointed officials, strengthening the apparatus of coercion, and revising the constitution in 1955 to further centralize authority in the hands of the monarch. The Emperor dominated Ethiopian political life from 1930 to 1974, with his words being final on important decisions."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4677,
        "content": [
          "Frequent coup attempts"
        ],
        "isCorrect": false
      },
      {
        "id": 4678,
        "content": [
          "Suppression of landlordism"
        ],
        "isCorrect": false
      },
      {
        "id": 4679,
        "content": [
          "Consolidation autocracy"
        ],
        "isCorrect": true
      },
      {
        "id": 4680,
        "content": [
          "The expansion of education"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1170,
    "content": [
      "Why did the Ethio-Eritrean federation fail? Because"
    ],
    "explanation": [
      "The federation formula that came into effect in 1952 \"neither satisfied the unionists nor the separatists\". This indicates an inherent lack of broad support for the federal arrangement from the beginning.\n\nThe imperial government also did not favor the continuation of an autonomous Eritrea, which enjoyed a level of freedom and civic liberties not present in other parts of Ethiopia. This suggests that the Ethiopian government was not fully committed to the federal structure.\n\nEventually, in 1962, the Eritrean parliament decided to dissolve the federation, and Eritrea became the 14th province of Ethiopia in 1964. This act signifies the ultimate failure and termination of the federal arrangement due to internal political decisions."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4681,
        "content": [
          "the arrangement was subverted by the Italians."
        ],
        "isCorrect": false
      },
      {
        "id": 4682,
        "content": [
          "both unionists and separatists were dissatisfied with it."
        ],
        "isCorrect": true
      },
      {
        "id": 4683,
        "content": [
          "the UN did not provide the support it promised to Ethiopia."
        ],
        "isCorrect": false
      },
      {
        "id": 4684,
        "content": [
          "the federal representative in Asmara was corrupt and ineffective."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1171,
    "content": [
      "Which of the following Oromo group settled in the south western part of the Ethiopian region?"
    ],
    "explanation": [
      "Borana confederacy moved in the direction of the central and southwestern Ethiopian regions. The Mecha are identified as one of the various sub-groups within the Borana confederacy."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4685,
        "content": [
          "Mecha"
        ],
        "isCorrect": true
      },
      {
        "id": 4686,
        "content": [
          "Borana"
        ],
        "isCorrect": false
      },
      {
        "id": 4687,
        "content": [
          "Guji"
        ],
        "isCorrect": false
      },
      {
        "id": 4688,
        "content": [
          "Ittu"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1172,
    "content": [
      "Why did Emperor Susenyos accept Catholicism? Because"
    ],
    "explanation": [
      "Just like his immediate predecessors, Susinyos leaned towards Catholicism in order to get Portuguese military assistance."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4689,
        "content": [
          "he believed that the Catholic doctrine was superior to the teachings of the Orthodox Church."
        ],
        "isCorrect": false
      },
      {
        "id": 4690,
        "content": [
          "he wanted Portuguese military help in securing an outlet through the Red sea."
        ],
        "isCorrect": false
      },
      {
        "id": 4691,
        "content": [
          "he wanted to become rich and powerful by taking over the lands of the Orthodox Church."
        ],
        "isCorrect": false
      },
      {
        "id": 4692,
        "content": [
          "he hoped to get military support from the Catholic countries against his rivals."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1173,
    "content": [
      "With which of the following was the Zemene Mesafint associated?"
    ],
    "explanation": [
      "The Zemene Mesafint (Era of Princes) in Ethiopian history was characterized by doctrinal controversies within the Ethiopian Orthodox Church, which contributed to political fragmentation and instability."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4693,
        "content": [
          "Revival of commerce and crafts"
        ],
        "isCorrect": false
      },
      {
        "id": 4694,
        "content": [
          "Consolidation of monarchical power"
        ],
        "isCorrect": false
      },
      {
        "id": 4695,
        "content": [
          "Doctrinal controversies in the Church"
        ],
        "isCorrect": true
      },
      {
        "id": 4696,
        "content": [
          "Improvement of peasant conditions"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1174,
    "content": [
      "What was the consequence of the Tokugawa Shogunate's seclusion policy for Japan?"
    ],
    "explanation": [
      "The Tokugawa Shogunate's seclusion policy (sakoku) had several consequences, but the most direct and well-established one was the suppression of Christianity.\n\nBy limiting contact with foreigners, particularly European missionaries, the policy effectively weakened Christian influence in Japan. This was a deliberate effort to eliminate perceived threats to political stability, as Christianity was associated with foreign intervention."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4697,
        "content": [
          "It ended Japanese voyages of discovery in Asia and hence the economic benefits that could come from these activities."
        ],
        "isCorrect": false
      },
      {
        "id": 4698,
        "content": [
          "It prevented Japan from importing firearms and hence the capacity of the state to consolidate power."
        ],
        "isCorrect": false
      },
      {
        "id": 4699,
        "content": [
          "It weakened Christianity in Japan by limiting regular contacts between the Japanese and foreigners."
        ],
        "isCorrect": true
      },
      {
        "id": 4700,
        "content": [
          "It limited the development of Japanese international trade and hence retarded its capitalistic development."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1175,
    "content": [
      "What was the statement by John Locke that justified rebellion?"
    ],
    "explanation": [
      "John Locke's idea of natural rights – life, liberty, property – was fundamental to the U.S. Declaration of Independence.\n\nThe Declaration of Independence, influenced by the Enlightenment and Locke, argued for the colonists' justification in rebelling against a tyrant who had broken the social contract.\n\nLocke asserted that people had the right to rebel against an unjust ruler. The Declaration of Independence, drawing on Locke's ideas, included a list of abuses by George III to justify the colonies' separation from Britain."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_EUROPE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4701,
        "content": [
          "That a government cannot ask its people for additional taxes without approval by parliament or a representative body."
        ],
        "isCorrect": false
      },
      {
        "id": 4702,
        "content": [
          "That a government which cannot protect the natural rights of its people is not a legitimate government."
        ],
        "isCorrect": true
      },
      {
        "id": 4703,
        "content": [
          "That in order to govern, a government would have to call Parliament into session regularly."
        ],
        "isCorrect": false
      },
      {
        "id": 4704,
        "content": [
          "That the legitimacy of a government is dependent on its ability to offer physical security to its citizens."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1176,
    "content": [
      "What explains the involvement of large numbers of ordinary people in the French revolution between 1788 and early 1789?"
    ],
    "explanation": [
      "Before the revolution, there were years of poor harvests that caused trouble for peasant farmers in paying their taxes.\n\nThere was the worst famine in memory, which directly affected the availability and affordability of food for ordinary people.\n\nIn Paris, the poor found it difficult to overcome the high price of bread and other daily needs, which acted as an immediate trigger for their involvement. France's economy was damaged by deficit spending, further contributing to economic hardship."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_EUROPE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4705,
        "content": [
          "The introduction of revolutionary ideas from the Americas"
        ],
        "isCorrect": false
      },
      {
        "id": 4706,
        "content": [
          "The collapse of the state's security system"
        ],
        "isCorrect": false
      },
      {
        "id": 4707,
        "content": [
          "The defeat of France in the Seven years' War"
        ],
        "isCorrect": false
      },
      {
        "id": 4708,
        "content": [
          "The food crisis and ensuing economic misery"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1177,
    "content": [
      "Which one of the following was a consequence of the Industrial Revolution?"
    ],
    "explanation": [
      "During the Industrial Revolution, manufacturing rapidly changed from mainly hand production to the use of machinery.\n\nWealthy textile merchants set up machines in large buildings called factories. Under the new factory system, industrial production was concentrated in large units employing many workers."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_EUROPE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4709,
        "content": [
          "The decline of the urban population"
        ],
        "isCorrect": false
      },
      {
        "id": 4710,
        "content": [
          "The spread of the factory system"
        ],
        "isCorrect": true
      },
      {
        "id": 4711,
        "content": [
          "The improvement of the life of workers"
        ],
        "isCorrect": false
      },
      {
        "id": 4712,
        "content": [
          "The abolition of manual labor in manufacturing"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1178,
    "content": [
      "How did the Congress of Vienna of 1815 seek to establish peace across Europe?"
    ],
    "explanation": [
      "The objective of the Congress of Vienna was to provide a long-term peace plan for Europe by settling critical issues arising from the French Revolutionary Wars and the Napoleonic Wars.\n\nThe Congress aimed to redraw territorial lines and try to restore the social and political order of the old regime. One of the key principles of settlement was the balance of power, which arranged the map of Europe so that never again could one state upset the international order and cause a general war.\n\nThe statesmen successfully worked out this principle. The major powers involved (Austria, Prussia, Russia, and Great Britain) aimed to create a stable Europe after the period of French dominance under Napoleon."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_EUROPE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4713,
        "content": [
          "By establishing a balance of power among the European powers."
        ],
        "isCorrect": true
      },
      {
        "id": 4714,
        "content": [
          "By weakening the economic and military capabilities of France."
        ],
        "isCorrect": false
      },
      {
        "id": 4715,
        "content": [
          "By recognizing the democratic and nationalistic aspirations of European populations."
        ],
        "isCorrect": false
      },
      {
        "id": 4716,
        "content": [
          "By agreeing to support the reforms of liberalizing European governments."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1179,
    "content": [
      "Which one of the following group was able to establish their own dynasty in Egypt?"
    ],
    "explanation": [
      "The Mamluks were a military aristocracy that ruled Egypt from about 1250 to 1517. They were originally Turkish slaves first brought to Egypt in the late 12th century.\n\nThe Mamluks were trained as soldiers and rose to high army and government posts before they revolted and seized control of Egypt. They founded their own dynasty that ruled Egypt."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4717,
        "content": [
          "Funj"
        ],
        "isCorrect": false
      },
      {
        "id": 4718,
        "content": [
          "Almohads"
        ],
        "isCorrect": false
      },
      {
        "id": 4719,
        "content": [
          "Abdallabi"
        ],
        "isCorrect": false
      },
      {
        "id": 4720,
        "content": [
          "Mamluks"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1180,
    "content": [
      "Which one of the following was a consequence of the Trans-Atlantic Slave trade?"
    ],
    "explanation": [
      "The principal imports from Europe during the \"legitimate trade\" era (which followed the Trans-Atlantic Slave Trade but reflects the established trade relationships) included cloth and firearms, which did nothing to strengthen indigenous African economies.\n\nImported European clothes thoroughly weakened the development of the African indigenous craft industry. The slave trade undermined African craft technology and agriculture."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4721,
        "content": [
          "The overthrow of oppressive regimes by force of arms."
        ],
        "isCorrect": false
      },
      {
        "id": 4722,
        "content": [
          "Greater availability of land and hence expansion of the economy."
        ],
        "isCorrect": false
      },
      {
        "id": 4723,
        "content": [
          "The weakening of indigenous crafts and technology due to import of European goods."
        ],
        "isCorrect": true
      },
      {
        "id": 4724,
        "content": [
          "The rapid increase of population due to introduction of new food crops and medical technologies."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1181,
    "content": [
      "Which of the following Ethiopian states had emerged first?"
    ],
    "explanation": [
      "Da’amat (980 B.C.-400 B.C.) is considered one of the earliest Ethiopian states to emerge."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4725,
        "content": [
          "Gojjam"
        ],
        "isCorrect": false
      },
      {
        "id": 4726,
        "content": [
          "Damot"
        ],
        "isCorrect": true
      },
      {
        "id": 4727,
        "content": [
          "Enareya"
        ],
        "isCorrect": false
      },
      {
        "id": 4728,
        "content": [
          "Wolayta"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1182,
    "content": [
      "Which one of the following was an outcome of the formation of the Ottoman Empire?"
    ],
    "explanation": [
      "Ottomans, who were converted to Sunni Islam, started to spread across Asia Minor and the Balkan region in Eastern Europe beginning around 1280.\n\nBy the 15th century, the Ottoman Empire had predominantly conquered the Balkan Peninsula, including Greece. Ottomans spread Islam throughout the empire."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4729,
        "content": [
          "The weakening of the Persian Empire"
        ],
        "isCorrect": false
      },
      {
        "id": 4730,
        "content": [
          "The spread of pastoral nomadism across Asia"
        ],
        "isCorrect": false
      },
      {
        "id": 4731,
        "content": [
          "The decline of trade between Europe and Asia"
        ],
        "isCorrect": false
      },
      {
        "id": 4732,
        "content": [
          "The expansion of Islam in the Balkan Peninsula"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1183,
    "content": [
      "Which one of the following was a key feature of early capitalism in Europe?"
    ],
    "explanation": [
      "During the Renaissance, which is considered a period important for the development of capitalist relations, cities in Italy emerged as centers of banking and commerce due to increased trade between Asia and Europe.\n\nAs the money economy increased in Europe, banks appeared in some Italian cities. Rich merchants lent money at interest and used their agents across Europe to help finance trade."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_EUROPE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4733,
        "content": [
          "The relocation of manufacturing from the cities to the countryside."
        ],
        "isCorrect": false
      },
      {
        "id": 4734,
        "content": [
          "Massive investment in the construction of railways and roads."
        ],
        "isCorrect": false
      },
      {
        "id": 4735,
        "content": [
          "The development of a banking system that facilitated long distance trade."
        ],
        "isCorrect": true
      },
      {
        "id": 4736,
        "content": [
          "The decline of the power of the bourgeoisie in local and international trade."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1184,
    "content": [
      "What was the motive behind the involvement of the Portuguese and the Ottomans in the Ethiopian region in the 16th-century?"
    ],
    "explanation": [
      "The Ottoman Turks were a major power in the Red Sea, the Gulf of Aden, and the Indian Ocean regions. Their rivalry with the Portuguese over control of the Red Sea and the Indian Ocean was a key motivator.\n\nThe Portuguese, being a rival maritime power, were interested in establishing new trade routes in the Gulf of Aden and the Red Sea coasts, especially after the Ottomans had blocked traditional routes.\n\nTheir initial exploration along the African coast was driven by the need to bypass Muslim North Africa and gain direct access to gold-producing regions and establish commercial links. Their intervention in the conflict between Adal and the Christian kingdom provided an opportunity to further their interests in the region.\n\nAfter assisting the Christian kingdom against the Sultanate of Adal, Portugal, supported by the Pope of Rome, sought to convert the Ethiopian king and his people to Catholicism. They allegedly claimed that King Libne Dingil had promised conversion in exchange for military aid. The arrival of Jesuit missionaries further indicates their religious objectives.\n\nWhile the Ottomans were a Muslim power, their primary focus in the Ethiopian region during this period, seems to be more about strategic and economic control, particularly in the Red Sea region. However, their expansion naturally contributed to the broader spread and consolidation of Islamic influence in the areas they controlled."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4737,
        "content": [
          "Establishing control over the source of the Abbay"
        ],
        "isCorrect": false
      },
      {
        "id": 4738,
        "content": [
          "Spreading their respective religions in the region"
        ],
        "isCorrect": false
      },
      {
        "id": 4739,
        "content": [
          "Finding markets for their manufactured goods"
        ],
        "isCorrect": false
      },
      {
        "id": 4740,
        "content": [
          "Extending their economic and political influence in the region"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1185,
    "content": [
      "Which one of the following region was believed to have been an area of Oromo settlement prior to their 16th-century movement?"
    ],
    "explanation": [
      "The region believed to have been an area of Oromo settlement prior to their 16th-century movement was the south-eastern part of Ethiopia's highlands, particularly the Bale highlands. The political and religious center of the Oromo settlement area was Madda Walabu, located on the Bale-Sidama borderlands.\n\nYoung Oromo men moved with their cattle to the Valleys of the Ganale River in the south, originating from the Bale highlands."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4741,
        "content": [
          "The Ethio-Sudan borderlands"
        ],
        "isCorrect": false
      },
      {
        "id": 4742,
        "content": [
          "The upper course of the Awash River"
        ],
        "isCorrect": false
      },
      {
        "id": 4743,
        "content": [
          "The area between the Wabi Shebelle and Juba"
        ],
        "isCorrect": false
      },
      {
        "id": 4744,
        "content": [
          "The area adjoining upper Ganale"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1186,
    "content": [
      "Which of the following 19th-century Ethiopian societies shared a similar system of political organization?"
    ],
    "explanation": [
      "Both the Wolayta and Gamo societies were Omotic states that practiced nearly similar political structures. The highest authority in both was a hereditary king who used the title Kawo or Kati.\n\nWhile the specific duties, succession procedures, and subordinate official titles might have varied between the two, the fundamental structure with a hereditary monarch bearing the Kawo/Kati title as the apex of their political system indicates a significant similarity in their political organization during the 19th century."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_ETHIOPIA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4745,
        "content": [
          "Kaffa and Hadiya"
        ],
        "isCorrect": false
      },
      {
        "id": 4746,
        "content": [
          "Wolayta and Kaffa"
        ],
        "isCorrect": true
      },
      {
        "id": 4747,
        "content": [
          "Khomosha and Nuer"
        ],
        "isCorrect": false
      },
      {
        "id": 4748,
        "content": [
          "Shewa and Gamo"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1187,
    "content": [
      "With which of the following medieval African states was Timbuktu associated?"
    ],
    "explanation": [
      "Timbuktu was the capital of the Mali Empire and became one of the most important Islamic learning and culture centers during its reign.\n\nThe greatness of Mali was closely linked to rulers like Mansa Musa, who is remembered for establishing many magnificent Mosques in West Africa, including in Timbuktu. His pilgrimage to Mecca further elevated the city's status as a center of Islamic scholarship."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_AFRICA",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4749,
        "content": [
          "Mali"
        ],
        "isCorrect": true
      },
      {
        "id": 4750,
        "content": [
          "Ghana"
        ],
        "isCorrect": false
      },
      {
        "id": 4751,
        "content": [
          "Kanem Bornu"
        ],
        "isCorrect": false
      },
      {
        "id": 4752,
        "content": [
          "Songhai"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1188,
    "content": [
      "Why was the second phase of the Trans-Atlantic slave trade also known as the Triangular trade? Because the"
    ],
    "explanation": [
      "The second phase of the Trans-Atlantic slave trade is also known as the triangular trade, because it formed one part of the triangular shaped international trade network that linked the three continents of Europe, Africa and Americas."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4753,
        "content": [
          "merchants involved in this trade transported slaves to the Americas using triangular shaped ships"
        ],
        "isCorrect": false
      },
      {
        "id": 4754,
        "content": [
          "transportation of slaves to the Americas passed through three distinctive phases."
        ],
        "isCorrect": false
      },
      {
        "id": 4755,
        "content": [
          "trade linked traders and goods drawn from the continents of Africa, Europe and the Americas."
        ],
        "isCorrect": true
      },
      {
        "id": 4756,
        "content": [
          "slave trade during this period was dominated by the Portuguese, Spanish and Dutch."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1189,
    "content": [
      "Which one of the following was a consequence of the Industrial Revolution?"
    ],
    "explanation": [
      "The Industrial Revolution created enormous amounts of wealth in the nation, but most of this new money belonged to factory owners, shippers, and merchants, who formed a growing middle class.\n\nDuring the years 1800 to 1850, laborers, or the working class, saw little improvement in their living and working conditions. They watched their livelihoods disappear as machines replaced them. This disparity in wealth accumulation and improvement in living standards indicates a widening income gap."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_EUROPE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4757,
        "content": [
          "The domination of European society by aristocrats devoted to farming and the manufacturing bourgeoisie."
        ],
        "isCorrect": false
      },
      {
        "id": 4758,
        "content": [
          "The widening of income inequality between workers and capitalists."
        ],
        "isCorrect": true
      },
      {
        "id": 4759,
        "content": [
          "The improvement of living and working conditions for factory workers."
        ],
        "isCorrect": false
      },
      {
        "id": 4760,
        "content": [
          "Increase in unemployment due to the replacement of workers by machines."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1190,
    "content": [
      "What was the fundamental cause of the American War of Independence?"
    ],
    "explanation": [
      "The fundamental cause of the American War of Independence was the thirteen colonies rejection of strict rule by the British.\n\nSeveral factors contributed to this rejection, including the introduction of various Acts by the British government, such as the Stamp Act, which imposed taxes on the colonists without their representation in Parliament. The colonists viewed these acts as violations of their natural rights.\n\nWhile French support was crucial to the colonists' eventual victory, and the Declaration of Independence formally announced their separation, these were consequences or contributing factors rather than the core underlying cause.\n\nThe fundamental issue was the growing desire for autonomy and self-governance among the thirteen colonies, leading them to resist the strict control and policies imposed by the British government."
    ],
    "year": "YEAR_2016",
    "subject": "HISTORY",
    "chapter": "HISTORY_WORLD_WIDE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4761,
        "content": [
          "The introduction of the different Acts by the British government."
        ],
        "isCorrect": false
      },
      {
        "id": 4762,
        "content": [
          "The support France gave to the Colonists against the British."
        ],
        "isCorrect": false
      },
      {
        "id": 4763,
        "content": [
          "The thirteen colonies rejection of strict rule by the British."
        ],
        "isCorrect": true
      },
      {
        "id": 4764,
        "content": [
          "The passage of the Declaration of Independence by the colonists."
        ],
        "isCorrect": false
      }
    ]
  }
];
export default questions;
