// StudentPrep Free Content — only the first 2 non-empty curriculum units/categories per grade/subject.
const questions = [
  {
    "id": 1357,
    "content": [
      "Question is based on the climate data of a hypothetical region given in the table.",
      "---",
      "What is the annual range of temperature at station \"G\"?"
    ],
    "explanation": [
      "The annual temperature range for Station \"G\" is 4°C, calculated as the difference between the highest (20°C) and lowest (16°C) monthly average temperatures."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 22,
    "groupIndex": null,
    "sharedContentId": 6,
    "sharedContent": [
      "### Climate data of a hypothetical region",
      "images/geography/year_2016/shared_1.png"
    ],
    "images": [
      "images/geography/year_2016/shared_1.png"
    ],
    "choices": [
      {
        "id": 5429,
        "content": [
          "4°C"
        ],
        "isCorrect": true
      },
      {
        "id": 5430,
        "content": [
          "2°C"
        ],
        "isCorrect": false
      },
      {
        "id": 5431,
        "content": [
          "1°C"
        ],
        "isCorrect": false
      },
      {
        "id": 5432,
        "content": [
          "3°C"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1358,
    "content": [
      "Question is based on the climate data of a hypothetical region given in the table.",
      "---",
      "Which one of the following wild animal is dominantly found in station \"Y\"?"
    ],
    "explanation": [
      "To determine which wild animal is dominantly found in station \"Y,\" we need to consider the climate data provided for station \"Y\":\n- **Temperature**: Ranges from 25°C to 33°C, indicating a warm to hot climate.\n- **Rainfall**: Significant rainfall, especially from May to October, with a peak in August (276 mm).\n\nGiven this climate:\n\n- **Crocodiles** are typically found in warm, tropical regions with abundant water sources, which matches the climate of station \"Y.\"\n- **Apes** also inhabit tropical regions but are more associated with forested areas.\n- **Zebras** are found in savannas and grasslands, which could also be a possibility given the climate.\n- **Polar bears** are found in Arctic regions with cold climates, which does not match the climate of station \"Y.\"\n\nConsidering the high rainfall and warm temperatures, **crocodiles** are the most likely dominant wild animal in station \"Y.\""
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 22,
    "groupIndex": null,
    "sharedContentId": 6,
    "sharedContent": [
      "### Climate data of a hypothetical region",
      "images/geography/year_2016/shared_1.png"
    ],
    "images": [
      "images/geography/year_2016/shared_1.png"
    ],
    "choices": [
      {
        "id": 5433,
        "content": [
          "Crocodiles"
        ],
        "isCorrect": true
      },
      {
        "id": 5434,
        "content": [
          "Apes"
        ],
        "isCorrect": false
      },
      {
        "id": 5435,
        "content": [
          "Zebras"
        ],
        "isCorrect": false
      },
      {
        "id": 5436,
        "content": [
          "Polar bears"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1359,
    "content": [
      "Question is based on the climate data of a hypothetical region given in the table.",
      "---",
      "Based on the temperature distribution, in which global pressure belt shall station 'F' be found?"
    ],
    "explanation": [
      "With relatively stable temperatures and low rainfall compared to equatorial regions, station \"F\" is most likely located in the horse latitudes, a region of high pressure."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 22,
    "groupIndex": null,
    "sharedContentId": 6,
    "sharedContent": [
      "### Climate data of a hypothetical region",
      "images/geography/year_2016/shared_1.png"
    ],
    "images": [
      "images/geography/year_2016/shared_1.png"
    ],
    "choices": [
      {
        "id": 5437,
        "content": [
          "Equatorial low"
        ],
        "isCorrect": false
      },
      {
        "id": 5438,
        "content": [
          "Polar highs"
        ],
        "isCorrect": false
      },
      {
        "id": 5439,
        "content": [
          "Horse latitude"
        ],
        "isCorrect": true
      },
      {
        "id": 5440,
        "content": [
          "Sub-tropical low"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1360,
    "content": [
      "Question is based on the climate data of a hypothetical region given in the table.",
      "---",
      "In which climate zone is station \"G\" found?"
    ],
    "explanation": [
      "Station \"G\" has cool, stable temperatures (16°C to 20°C) and significant\n rainfall, peaking in August (560 mm). These conditions are typical of a **Highland** climate, which is characterized by cooler temperatures due to higher elevation and variable rainfall patterns."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 22,
    "groupIndex": null,
    "sharedContentId": 6,
    "sharedContent": [
      "### Climate data of a hypothetical region",
      "images/geography/year_2016/shared_1.png"
    ],
    "images": [
      "images/geography/year_2016/shared_1.png"
    ],
    "choices": [
      {
        "id": 5441,
        "content": [
          "Equatorial"
        ],
        "isCorrect": false
      },
      {
        "id": 5442,
        "content": [
          "Highland"
        ],
        "isCorrect": true
      },
      {
        "id": 5443,
        "content": [
          "Tropical desert"
        ],
        "isCorrect": false
      },
      {
        "id": 5444,
        "content": [
          "Mediterranean"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1376,
    "content": [
      "Which statement describes the concept of economic development?"
    ],
    "explanation": [
      "Economic development refers to the sustained development of the material well-being of society. This goes beyond just an increase in the quantity of goods produced.\n\nIt focuses on both qualitative and quantitative development of a country’s economy. Economic development enables people to be more educated, healthier, and endowed with good access to quality housing, better sanitation, and employment opportunities. This directly translates to an improvement in their living conditions."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5505,
        "content": [
          "Increase in the amount of total agricultural production"
        ],
        "isCorrect": false
      },
      {
        "id": 5506,
        "content": [
          "Improvement in the living condition of the people"
        ],
        "isCorrect": true
      },
      {
        "id": 5507,
        "content": [
          "Increase in the total amount of manufactured goods"
        ],
        "isCorrect": false
      },
      {
        "id": 5508,
        "content": [
          "Progress in the process of industrial domestic product"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1377,
    "content": [
      "Which one of the following is a good opportunity for the development of the African continent? The availability of"
    ],
    "explanation": [
      "Africa is described as a resourceful region in the world. The continent possesses huge mineral wealth due to its long geological history, including resources like petroleum, natural gas, coal, uranium, iron, copper, zinc, tin, phosphates, platinum, and cobalt."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5509,
        "content": [
          "skilled labor force"
        ],
        "isCorrect": false
      },
      {
        "id": 5510,
        "content": [
          "political stability"
        ],
        "isCorrect": false
      },
      {
        "id": 5511,
        "content": [
          "foreign aid and loan"
        ],
        "isCorrect": false
      },
      {
        "id": 5512,
        "content": [
          "abundant natural resources"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1379,
    "content": [
      "What is the effect of latitude on ecosystem diversity? Ecosystem diversity"
    ],
    "explanation": [
      "Regions near the equator receive more direct solar radiation throughout the year, resulting in higher temperatures and generally higher rainfall in some zones like the tropical wet regions. These conditions support highly diverse ecosystems such as tropical rainforests with a large number of plant and animal species.\n\nAs we move away from the equator towards higher latitudes, the angle of the sun's rays becomes more oblique, leading to lower average temperatures and significant seasonal variations in temperature and daylight hours.\n\nIn the high-latitude zones like the polar regions and the tundra, there are extremely cold winters and cool summers with limited growing seasons. These harsh conditions support less diverse ecosystems with specialized plant and animal life adapted to the cold."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5517,
        "content": [
          "increases as we go from the equator to the poles."
        ],
        "isCorrect": false
      },
      {
        "id": 5518,
        "content": [
          "decreases from the poles towards the equator."
        ],
        "isCorrect": false
      },
      {
        "id": 5519,
        "content": [
          "remains similar wherever we go mainly due to the effect of altitude."
        ],
        "isCorrect": false
      },
      {
        "id": 5520,
        "content": [
          "decreases gradually when we travel from the equator to Tundra."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1389,
    "content": [
      "Which continent is included in the Eurasian plate?"
    ],
    "explanation": [
      "The Eurasian plate includes Europe and most of Asia."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5557,
        "content": [
          "North Africa"
        ],
        "isCorrect": false
      },
      {
        "id": 5558,
        "content": [
          "Australia"
        ],
        "isCorrect": false
      },
      {
        "id": 5559,
        "content": [
          "Part of Asia"
        ],
        "isCorrect": true
      },
      {
        "id": 5560,
        "content": [
          "Part of South America"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1390,
    "content": [
      "Which landmass is formed through the convergence of two oceanic plates?"
    ],
    "explanation": [
      "Convergent plate boundaries, where two plates move towards each other, the denser plate is forced under the less dense one (subduction). This occurs when oceanic crust meets continental crust and when oceanic crust meets another oceanic crust.\n\nIf two oceanic plates converge, subduction of one under the other may produce an arc of volcanic islands. The Mariana Islands of the western Pacific Ocean were formed this way."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5561,
        "content": [
          "The Mariana volcanic feature"
        ],
        "isCorrect": true
      },
      {
        "id": 5562,
        "content": [
          "The Himalayas mountain"
        ],
        "isCorrect": false
      },
      {
        "id": 5563,
        "content": [
          "The East African rift valley"
        ],
        "isCorrect": false
      },
      {
        "id": 5564,
        "content": [
          "The San Andreas Fault"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1391,
    "content": [
      "What is the principal agent for the chemical weathering of rocks?"
    ],
    "explanation": [
      "Water is the most important agent of chemical weathering. Rainwater is not pure and dissolves substances like oxygen and carbon dioxide as it falls through the atmosphere.\n\nThis dissolved oxygen can cause minerals like iron to rust, making them weak. Rainwater containing carbonic acid can dissolve minerals with carbonates, such as limestone."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5565,
        "content": [
          "Glacier"
        ],
        "isCorrect": false
      },
      {
        "id": 5566,
        "content": [
          "Rain water"
        ],
        "isCorrect": true
      },
      {
        "id": 5567,
        "content": [
          "Thermal expansion"
        ],
        "isCorrect": false
      },
      {
        "id": 5568,
        "content": [
          "Cold temperature"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1392,
    "content": [
      "Which one of the following country is found in the 'ring of fire' zone?"
    ],
    "explanation": [
      "Earthquake belt circles the Pacific Ocean along the mountainous west coasts of North and South America and runs through the island areas of Asia. This belt is also called the Circum-Pacific Belt or the Ring of Fire.\n\nPeru is located on the west coast of South America, which is part of the mountainous region identified within the Ring of Fire."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5569,
        "content": [
          "Norway"
        ],
        "isCorrect": false
      },
      {
        "id": 5570,
        "content": [
          "Brazil"
        ],
        "isCorrect": false
      },
      {
        "id": 5571,
        "content": [
          "United Kingdom"
        ],
        "isCorrect": false
      },
      {
        "id": 5572,
        "content": [
          "Peru"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1393,
    "content": [
      "Which statement shows the trend of world climate change?"
    ],
    "explanation": [
      "The average temperature of the Earth has been increasing for many years, and this is called global warming.\n\nThe average global surface temperature has warmed 0.80°C in the past century and 0.60°C in the past three decades. The IPCC has also projected further increases in mean global temperatures if greenhouse gas emissions continue to rise."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_CHANGE_IMPACTS_AND_SOLUTIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5573,
        "content": [
          "Temperature has declined in temperate regions since the 1970s."
        ],
        "isCorrect": false
      },
      {
        "id": 5574,
        "content": [
          "Precipitation has increased all over the globe since the 1980s."
        ],
        "isCorrect": false
      },
      {
        "id": 5575,
        "content": [
          "The average global temperature has increased over the past century."
        ],
        "isCorrect": true
      },
      {
        "id": 5576,
        "content": [
          "The global climate fluctuates at the same rate."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1394,
    "content": [
      "Which one is the effect of climate change in the tropical parts of the world? Increasing"
    ],
    "explanation": [
      "Climate change is associated with decreasing rainfall trends in tropical and sub-tropical areas, which can lead to extreme climatic events such as droughts. Tropical areas are experiencing the largest comparative extreme climatic changes."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_CHANGE_IMPACTS_AND_SOLUTIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5577,
        "content": [
          "predictable rainfall"
        ],
        "isCorrect": false
      },
      {
        "id": 5578,
        "content": [
          "crop yield"
        ],
        "isCorrect": false
      },
      {
        "id": 5579,
        "content": [
          "snow covers"
        ],
        "isCorrect": false
      },
      {
        "id": 5580,
        "content": [
          "frequency of drought"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1397,
    "content": [
      "In which geological Era is the rift valley of Ethiopia formed?"
    ],
    "explanation": [
      "In the Tertiary Period, the uplifting that began in the Cretaceous Period of the Mesozoic Era continued and reached its maximum height.\n\nIn Ethiopia and the Horn it formed huge blocks of dome over the greater part of the region. As the uplifting continued through time, great cracks opened in the crust and resulted in the pouring out of extensive basaltic lava (known as the Trappean lava series).\n\nAs the cracking and faulting continued during the period, it formed the Great East African Rift Valley System – of which the Ethiopian Rift Valley System is part."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5589,
        "content": [
          "The Paleozoic Era"
        ],
        "isCorrect": false
      },
      {
        "id": 5590,
        "content": [
          "The Mesozoic Era"
        ],
        "isCorrect": false
      },
      {
        "id": 5591,
        "content": [
          "The Cenozoic Era"
        ],
        "isCorrect": true
      },
      {
        "id": 5592,
        "content": [
          "The Precambrian Era"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1398,
    "content": [
      "Which part of the earth's physical environment is referred to as the 'life zone'?"
    ],
    "explanation": [
      "The biosphere includes all living organisms and their interactions with the environment."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5593,
        "content": [
          "The atmosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 5594,
        "content": [
          "The biosphere"
        ],
        "isCorrect": true
      },
      {
        "id": 5595,
        "content": [
          "The lithosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 5596,
        "content": [
          "The hydrosphere"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1399,
    "content": [
      "Which one of the following is the basic characteristic of metamorphic rock?"
    ],
    "explanation": [
      "The basic characteristic of metamorphic rock is that it is formed from existing rocks that have been transformed by heat or pressure."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5597,
        "content": [
          "It is produced from igneous rock through pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 5598,
        "content": [
          "It is mostly created when lava freezes."
        ],
        "isCorrect": false
      },
      {
        "id": 5599,
        "content": [
          "It is composed of newly-deposited soil particles."
        ],
        "isCorrect": false
      },
      {
        "id": 5600,
        "content": [
          "It is produced from sedimentary rock through cooling."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1401,
    "content": [
      "Where is the highest mean annual temperature recorded?"
    ],
    "explanation": [
      "The highest temperature i.e. over 45⁰C is recorded in the Danakil Depression, the hottest place of Ethiopia."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5605,
        "content": [
          "The Dallol depression"
        ],
        "isCorrect": true
      },
      {
        "id": 5606,
        "content": [
          "The Baro lowlands"
        ],
        "isCorrect": false
      },
      {
        "id": 5607,
        "content": [
          "The Elkeri plains"
        ],
        "isCorrect": false
      },
      {
        "id": 5608,
        "content": [
          "The Ghibe lowlands"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1402,
    "content": [
      "Which part of Ethiopia is in high drought probability zone?"
    ],
    "explanation": [
      "The Bereha-zone areas, which include the Afar lowlands (Danakil depression), are characterized by a hot arid climate with average annual rainfall of less than 400 mm and average annual temperature over 30°C. Evapotranspiration tends to exceed precipitation in such dry environments."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5609,
        "content": [
          "Gojjam"
        ],
        "isCorrect": false
      },
      {
        "id": 5610,
        "content": [
          "Wellega"
        ],
        "isCorrect": false
      },
      {
        "id": 5611,
        "content": [
          "Afar"
        ],
        "isCorrect": true
      },
      {
        "id": 5612,
        "content": [
          "Guji"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1404,
    "content": [
      "Which statement describes the equatorial rainforest region?"
    ],
    "explanation": [
      "The equatorial rainforest is characterized by consistently high rainfall throughout the year, supporting its dense vegetation."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5617,
        "content": [
          "It forms a continuous belt around the world."
        ],
        "isCorrect": false
      },
      {
        "id": 5618,
        "content": [
          "It receives high amount of rainfall throughout the year."
        ],
        "isCorrect": true
      },
      {
        "id": 5619,
        "content": [
          "Its annual range of temperature exceeds the daily range."
        ],
        "isCorrect": false
      },
      {
        "id": 5620,
        "content": [
          "It is dominated by deciduous forests."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1405,
    "content": [
      "Which one explains about the lowlands of Ethiopia?"
    ],
    "explanation": [
      "Kobar sink, located in the Afar region, represents the lowest point in Ethiopia's landscape.\n\nAltitude varies from about 116 meters below mean sea level at the Dallol depression (Kobar sink) to 4620 m above mean sea level (a.m.s.l.) at Ras Dashen in the Semein mountain system."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5621,
        "content": [
          "They are found in between 1000-2000 m heights."
        ],
        "isCorrect": false
      },
      {
        "id": 5622,
        "content": [
          "Lowlands are situated at the center of the country."
        ],
        "isCorrect": false
      },
      {
        "id": 5623,
        "content": [
          "Tekeze occupies the floor of the rift valley."
        ],
        "isCorrect": false
      },
      {
        "id": 5624,
        "content": [
          "Kobar sink is the lowest place in the country."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1406,
    "content": [
      "What characterizes the physical environment of the Tundra Region?"
    ],
    "explanation": [
      "The tundra region is characterized by extremely low temperatures, a short growing season, and minimal precipitation, which mostly falls as snow.\n\nThe soil remains frozen for most of the year (permafrost), and vegetation is limited to low-growing plants like mosses, lichens, and shrubs."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5625,
        "content": [
          "It is known for its low temperature and rainfall throughout the year."
        ],
        "isCorrect": true
      },
      {
        "id": 5626,
        "content": [
          "It is a densely populated region where Eskimos and Lapps are found."
        ],
        "isCorrect": false
      },
      {
        "id": 5627,
        "content": [
          "In area of low snow cover, tall plants grow during the summer season."
        ],
        "isCorrect": false
      },
      {
        "id": 5628,
        "content": [
          "It is found both in the northern and southern hemispheres."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1417,
    "content": [
      "Which sphere of the earth contains important minerals?"
    ],
    "explanation": [
      "The lithosphere, consisting of the Earth's crust and upper mantle, is the primary source of minerals.\n\nThe Lithosphere is defined as the solid layer of rocks that covers the entire surface of the planet. Minerals are found within the Earth's crust, and mining is the extraction of mineral-bearing substances from the Earth's crust."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5669,
        "content": [
          "Hydrosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 5670,
        "content": [
          "Lithosphere"
        ],
        "isCorrect": true
      },
      {
        "id": 5671,
        "content": [
          "Biosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 5672,
        "content": [
          "Atmosphere"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1418,
    "content": [
      "Which type of extrusive land feature is formed by volcanism?"
    ],
    "explanation": [
      "Craters are also formed by volcanic activity, through explosions or collapse.\n\nA caldera is a large, basin-shaped depression formed after a magma chamber drains and the overlying volcanic cone collapses inward. This is a direct result of volcanic processes occurring at the Earth's surface."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5673,
        "content": [
          "Batholith"
        ],
        "isCorrect": false
      },
      {
        "id": 5674,
        "content": [
          "Sill"
        ],
        "isCorrect": false
      },
      {
        "id": 5675,
        "content": [
          "Dike"
        ],
        "isCorrect": false
      },
      {
        "id": 5676,
        "content": [
          "Caldera"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1419,
    "content": [
      "Which statement describes the process of faulting?"
    ],
    "explanation": [
      "Normal faults occur when the Earth's crust is subjected to tensional forces, which cause the crust to stretch and pull apart. This results in the hanging wall moving downward relative to the footwall. Tensional forces are typically associated with divergent plate boundaries or regions experiencing stretching of the crust."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5677,
        "content": [
          "Reverse-fault is normally associated with strong tensional forces."
        ],
        "isCorrect": false
      },
      {
        "id": 5678,
        "content": [
          "Compressional crack results in the formation of normal faulting."
        ],
        "isCorrect": false
      },
      {
        "id": 5679,
        "content": [
          "Normal faults develop under the predominant tensional forces."
        ],
        "isCorrect": true
      },
      {
        "id": 5680,
        "content": [
          "Faulting is a process which is mainly caused by human activities."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1420,
    "content": [
      "What is the type of land feature cut off from the sea by sand banks?"
    ],
    "explanation": [
      "Lagoon is defined an area of salt water separated from the sea by loose sand banks"
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5681,
        "content": [
          "Beach"
        ],
        "isCorrect": false
      },
      {
        "id": 5682,
        "content": [
          "Tombolo"
        ],
        "isCorrect": false
      },
      {
        "id": 5683,
        "content": [
          "Spit"
        ],
        "isCorrect": false
      },
      {
        "id": 5684,
        "content": [
          "Lagoon"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1421,
    "content": [
      "How is conventional rainfall formed?"
    ],
    "explanation": [
      "Conventional rainfall is formed when the ground surface is heated by the sun, causing the air above it to warm up, become less dense, and rise.\n\nAs this warm, moist air rises, it cools and condenses, forming clouds and resulting in rainfall. This type of rainfall is common in tropical regions where intense daytime heating occurs."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5685,
        "content": [
          "When moist and less dense air is forced to rise upward."
        ],
        "isCorrect": true
      },
      {
        "id": 5686,
        "content": [
          "When dry air forced to rise above a mountain."
        ],
        "isCorrect": false
      },
      {
        "id": 5687,
        "content": [
          "When cold and warm air masses meet at the front."
        ],
        "isCorrect": false
      },
      {
        "id": 5688,
        "content": [
          "When warm and dry air descend a mountain."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1422,
    "content": [
      "What is the effect of Coriolis force on wind direction? It causes"
    ],
    "explanation": [
      "The **Coriolis force** is caused by Earth's rotation and affects the movement of winds and ocean currents. It **deflects winds to the right in the Northern Hemisphere and to the left in the Southern Hemisphere**.\n- In the **Southern Hemisphere**, high-pressure systems (**anti-cyclones**) rotate **clockwise** due to this deflection.\n- Low-pressure systems (**cyclones**) rotate **counterclockwise** in the Southern Hemisphere."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5689,
        "content": [
          "winds to bend to the left in the northern hemisphere."
        ],
        "isCorrect": false
      },
      {
        "id": 5690,
        "content": [
          "winds to turn to the right in the southern hemisphere."
        ],
        "isCorrect": false
      },
      {
        "id": 5691,
        "content": [
          "anti-cyclones to move clockwise direction in the southern hemisphere."
        ],
        "isCorrect": true
      },
      {
        "id": 5692,
        "content": [
          "cyclones to move in clock wise direction in the southern hemisphere."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1423,
    "content": [
      "Which one of the following ocean current has a cooling effect on the southwestern part of Africa?"
    ],
    "explanation": [
      "Cool Benguela Currents affect the western coast of the Kalahari Desert in Africa, leading to dry conditions.\n\nCool ocean currents generally cause moisture in winds blowing over them to condense, depriving the adjacent coasts of moisture and leading to dry conditions."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5693,
        "content": [
          "The Mexican Gulf stream"
        ],
        "isCorrect": false
      },
      {
        "id": 5694,
        "content": [
          "The Benguela current"
        ],
        "isCorrect": true
      },
      {
        "id": 5695,
        "content": [
          "The Canary current"
        ],
        "isCorrect": false
      },
      {
        "id": 5696,
        "content": [
          "The Mozambique current"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1424,
    "content": [
      "Which statement explains about the pressure belts of the world?"
    ],
    "explanation": [
      "Horse latitudes or subtropical High Pressure (STH) belts are located around 30 degrees latitude. These subtropical high-pressure zones are areas of high air pressure."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5697,
        "content": [
          "Horse latitude is an area of high air pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 5698,
        "content": [
          "Doldrums is a high pressure belt."
        ],
        "isCorrect": false
      },
      {
        "id": 5699,
        "content": [
          "Sub polar is an area of high air pressure."
        ],
        "isCorrect": false
      },
      {
        "id": 5700,
        "content": [
          "Polar high is known as 'belt of calm'."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1427,
    "content": [
      "Which one of the following is an indicator of social development?"
    ],
    "explanation": [
      "Female and male literacy rate are commonly used indicator of social development. Access to knowledge, measured by literacy rates, is also highlighted as a dimension in the calculation of the Human Development Index (HDI), which is a measure of human well-being and development.\n\nGross Domestic Product (GDP) and Per-capita income are defined and used as indicators of economic growth and development. They primarily focus on the quantitative increase in goods and services or average income.\n\nInfant mortality rate is presented as a measure of mortality and a widely used indicator of the general health situation in a country."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5709,
        "content": [
          "Gross Domestic Product"
        ],
        "isCorrect": false
      },
      {
        "id": 5710,
        "content": [
          "Per-capita income"
        ],
        "isCorrect": false
      },
      {
        "id": 5711,
        "content": [
          "Literacy rate"
        ],
        "isCorrect": true
      },
      {
        "id": 5712,
        "content": [
          "Infant mortality rate"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1428,
    "content": [
      "What is the effect of rapid population growth on the socio-economic progress of developing countries?"
    ],
    "explanation": [
      "Rapid population increase in developing countries puts a significant strain on resources, including the ability to provide an adequate food supply.\n\nThis can lead to inadequate food supply and combatting hunger and malnutrition becomes more difficult."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5713,
        "content": [
          "Expansion of economic choices"
        ],
        "isCorrect": false
      },
      {
        "id": 5714,
        "content": [
          "Formation of a healthy environment"
        ],
        "isCorrect": false
      },
      {
        "id": 5715,
        "content": [
          "Abundance of life sustaining goods"
        ],
        "isCorrect": false
      },
      {
        "id": 5716,
        "content": [
          "Incidence of widespread food insecurity"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1429,
    "content": [
      "According to the behavioral approach, which one is the cause of poverty?"
    ],
    "explanation": [
      "Behavioral or cultural approach to poverty emphasizes culture, behavior, and personal differences as significant sources of poverty.\n\nThis approach suggests the existence of a \"poverty culture,\" which includes a set of attitudes and behaviors that are passed down through generations and perpetuate poverty.\n\nAmong the attitudes of this poverty culture is fatalism. A weakness to change the sense of inability directly aligns with the concept of fatalism, where individuals may feel powerless to alter their circumstances and thus do not take actions that could lead to improvement."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5717,
        "content": [
          "Good performance in the work place"
        ],
        "isCorrect": false
      },
      {
        "id": 5718,
        "content": [
          "Rational attitude towards wealth"
        ],
        "isCorrect": false
      },
      {
        "id": 5719,
        "content": [
          "Weakness to change the sense of inability"
        ],
        "isCorrect": true
      },
      {
        "id": 5720,
        "content": [
          "Non-violent dispute resolution"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1433,
    "content": [
      "Which one describes the elements of weather and climate in Africa?"
    ],
    "explanation": [
      "Africa's temperature varies due to geographical features such as mountains and plateaus.\n\nHigh-altitude areas like the Ethiopian Highlands, the Atlas Mountains, and Mount Kilimanjaro experience cooler temperatures compared to lowland regions.\n\nElevation significantly affects climate by reducing temperatures as altitude increases, making it a key factor in Africa’s weather and climate patterns."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5733,
        "content": [
          "Its northern part is characterized by high rainfall throughout the year."
        ],
        "isCorrect": false
      },
      {
        "id": 5734,
        "content": [
          "Its northern part has maritime climate due to the influence of the sea."
        ],
        "isCorrect": false
      },
      {
        "id": 5735,
        "content": [
          "Its latitudinal position is the factor for the low income solar radiation."
        ],
        "isCorrect": false
      },
      {
        "id": 5736,
        "content": [
          "Its temperature is influenced by the presence of mountain and plateau."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1434,
    "content": [
      "What is the effect of the Mozambique Ocean current on the south eastern coastal areas of Africa?"
    ],
    "explanation": [
      "The south eastern coastal areas of Africa, particularly Natal and Cape Provinces in South Africa, as well as Mozambique, experience the influence of the warm Mozambique current.\n\nWarm ocean currents supply moisture to winds blowing over them, leading to rainfall on the adjacent coasts."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5737,
        "content": [
          "Freezing"
        ],
        "isCorrect": false
      },
      {
        "id": 5738,
        "content": [
          "Drying"
        ],
        "isCorrect": false
      },
      {
        "id": 5739,
        "content": [
          "Moisturizing"
        ],
        "isCorrect": true
      },
      {
        "id": 5740,
        "content": [
          "Cooling"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1435,
    "content": [
      "In which coastal areas of Africa is the tropical maritime climate located?"
    ],
    "explanation": [
      "The south eastern coastal areas of Africa experience conditions indicative of a tropical maritime influence.\n\nSpecifically, the eastern coast of South Africa, especially in Natal and Cape Provinces, as well as Mozambique, are under the strong influence of the warm Mozambique current and the warm southeast trade winds.\n\nThese factors contribute to generally high summer temperatures and significant annual rainfall in the region. Warm"
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5741,
        "content": [
          "North western"
        ],
        "isCorrect": false
      },
      {
        "id": 5742,
        "content": [
          "South western"
        ],
        "isCorrect": false
      },
      {
        "id": 5743,
        "content": [
          "North eastern"
        ],
        "isCorrect": false
      },
      {
        "id": 5744,
        "content": [
          "South eastern"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1436,
    "content": [
      "As compared to others, which climatic region of Africa shows lower seasonality?"
    ],
    "explanation": [
      "The Equatorial climate region, found in areas like the Congo Basin, experiences very high temperatures throughout the year with an average of around 26°C.\n\nThe diurnal temperature range is very low, about 3°C, and variations in monthly and daily temperatures are less pronounced compared to other tropical regions."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5745,
        "content": [
          "The Equatorial"
        ],
        "isCorrect": true
      },
      {
        "id": 5746,
        "content": [
          "The Mediterranean"
        ],
        "isCorrect": false
      },
      {
        "id": 5747,
        "content": [
          "The Tropical desert"
        ],
        "isCorrect": false
      },
      {
        "id": 5748,
        "content": [
          "The Tropical continental"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1439,
    "content": [
      "In which climate region is the Gorilla typically found?"
    ],
    "explanation": [
      "Gorillas are typically found in the Equatorial rainforest. This region near the equator has high temperatures and consistent, heavy rainfall.\n\nThese conditions support dense rainforests with a great variety of plants. Gorillas live in these forests because they provide the necessary food and shelter."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5757,
        "content": [
          "The Equatorial rainforest"
        ],
        "isCorrect": true
      },
      {
        "id": 5758,
        "content": [
          "The Mediterranean climate zone"
        ],
        "isCorrect": false
      },
      {
        "id": 5759,
        "content": [
          "The Desert climate region"
        ],
        "isCorrect": false
      },
      {
        "id": 5760,
        "content": [
          "The Savanna climate zone"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1445,
    "content": [
      "Which statement describes the size of Africa?"
    ],
    "explanation": [
      "Africa is the **second-largest continent** in the world, after Asia, covering about **30.37 million km²**.\n- **Europe's area** is approximately **10.18 million km²**.\n- **Antarctica's area** is around **14 million km²**.\n\nCombined, **Europe and Antarctica** cover about **24.18 million km²**, which is smaller than Africa."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5781,
        "content": [
          "It covers about one-fourth of the world's area."
        ],
        "isCorrect": false
      },
      {
        "id": 5782,
        "content": [
          "It is the largest continent of the world."
        ],
        "isCorrect": false
      },
      {
        "id": 5783,
        "content": [
          "It is larger than Europe and Antarctica put together."
        ],
        "isCorrect": true
      },
      {
        "id": 5784,
        "content": [
          "It is about two-thirds of South America."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1447,
    "content": [
      "What is the major geological event that occurred during the Cenozoic Era in Africa?"
    ],
    "explanation": [
      "The Cenozoic Era is the most recent geological era, and it was a time of very significant structural, climatic, and biological events in Africa.\n\nThese events greatly resulted in the development of the very recent landforms in the Horn of Africa and Africa in general.\n\nExample in Ethiopia, the landforms are largely the result of the Cenozoic Era's tectonic and volcanic activities. These activities led to the formation of diverse highlands, plateaus, ambas, and rugged mountains, deep river gorges, and lowlands, contributing to the present-day landscape."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5789,
        "content": [
          "The formation of the present landscape of Africa"
        ],
        "isCorrect": true
      },
      {
        "id": 5790,
        "content": [
          "The formation of crystalline basement complex rocks"
        ],
        "isCorrect": false
      },
      {
        "id": 5791,
        "content": [
          "The recording of a series of denudation and peneplanation"
        ],
        "isCorrect": false
      },
      {
        "id": 5792,
        "content": [
          "The split of the super continent Pangaea"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1448,
    "content": [
      "Which typical relief feature is more dominantly found in Africa than in Europe?"
    ],
    "explanation": [
      "Plateaus are more dominantly found in Africa than in Europe.\n\nFor example, the Ethiopian Highlands are characterized as a high plateau with a central highland complex.\n\nThe Southern Africa Platform is mentioned as a major landform region that includes the Highveld, which is a portion of the South African inland plateau."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5793,
        "content": [
          "Plains"
        ],
        "isCorrect": false
      },
      {
        "id": 5794,
        "content": [
          "Plateaus"
        ],
        "isCorrect": true
      },
      {
        "id": 5795,
        "content": [
          "Mountains"
        ],
        "isCorrect": false
      },
      {
        "id": 5796,
        "content": [
          "Hills"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1449,
    "content": [
      "Which one of the following has widely been practiced as a climate change adaptation strategy in Ethiopia?"
    ],
    "explanation": [
      "Planting trees (afforestation and reforestation) is a key climate change adaptation strategy in Ethiopia.\n\nThe \"Green Legacy\" Initiative, a large-scale, government-led program in Ethiopia, is a major effort focused on tree planting to curb the effects of climate change and deforestation. This initiative aims to plant billions of seedlings across the country."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_CHANGE_IMPACTS_AND_SOLUTIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5797,
        "content": [
          "Use of mass transportation"
        ],
        "isCorrect": false
      },
      {
        "id": 5798,
        "content": [
          "Dam construction"
        ],
        "isCorrect": false
      },
      {
        "id": 5799,
        "content": [
          "Tree plantation"
        ],
        "isCorrect": true
      },
      {
        "id": 5800,
        "content": [
          "Electric car utilization"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1450,
    "content": [
      "Which statement describes the Kyoto protocol adopted in 1997?"
    ],
    "explanation": [
      "The Kyoto Protocol, adopted in 1997 and put into force in February 2005, set mandatory targets for reducing greenhouse gas emissions in countries that adopted the plan.\n\nThe overall goal was to reduce greenhouse gas emissions in developed countries by at least 5 percent below existing 1990 levels during the five-year period of 2008 through 2012."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_CHANGE_IMPACTS_AND_SOLUTIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5801,
        "content": [
          "It set compulsory goal to reduce greenhouse emission."
        ],
        "isCorrect": true
      },
      {
        "id": 5802,
        "content": [
          "It was successful in reducing global greenhouse gases."
        ],
        "isCorrect": false
      },
      {
        "id": 5803,
        "content": [
          "The USA took the lead in ratifying the agreement."
        ],
        "isCorrect": false
      },
      {
        "id": 5804,
        "content": [
          "It was ratified by every nation of the world."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1451,
    "content": [
      "On which issues of climate change have the world leaders agreed?"
    ],
    "explanation": [
      "The United Nations Framework Convention on Climate Change (UNFCCC) emphasizes mitigation, which seeks to limit climate change by reducing the emissions of greenhouse gases.\n\nThe Kyoto Protocol (1997, enforced in 2005) set mandatory targets for reducing greenhouse gas emissions for countries that adopted the plan. The overall goal was to reduce greenhouse gas emissions in developed countries by at least 5 percent below 1990 levels during 2008-2012.\n\nThe Paris Agreement (2015), adopted by virtually every nation, involved each nation setting voluntary targets for reducing emissions and reporting their progress. Participants pledged to curb emissions to minimize the rise in temperatures."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_CHANGE_IMPACTS_AND_SOLUTIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5805,
        "content": [
          "To encourage natural gas and fuel consumption"
        ],
        "isCorrect": false
      },
      {
        "id": 5806,
        "content": [
          "To conduct social forestry activities"
        ],
        "isCorrect": false
      },
      {
        "id": 5807,
        "content": [
          "To penalize countries that depends on fossil fuel"
        ],
        "isCorrect": false
      },
      {
        "id": 5808,
        "content": [
          "To reduce emission of greenhouse gases"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1452,
    "content": [
      "Which one describes the concept of sustainable development?"
    ],
    "explanation": [
      "Sustainable development is about meeting the needs of the present without compromising the ability of future generations to meet their own needs.\n\nThis concept is rooted in balancing economic development, social development, and environmental sustainability."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5809,
        "content": [
          "Realizing environmental-friendly socio-economic development"
        ],
        "isCorrect": true
      },
      {
        "id": 5810,
        "content": [
          "Improving human welfare at the expense of the environment"
        ],
        "isCorrect": false
      },
      {
        "id": 5811,
        "content": [
          "Prioritizing good governance regardless of economic development"
        ],
        "isCorrect": false
      },
      {
        "id": 5812,
        "content": [
          "Promoting a male-controlled socio-economic development"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2518,
    "content": [
      "Which of the following is the southern limit of the Western lowlands?"
    ],
    "explanation": [
      "The southern limit of the Western Lowlands is the **Omo-Ghibe lowlands**.\n\nThe **Western Lowlands** of Ethiopia extend geographically from western Tigray in the north up to southern Gamo and Goffa in the south, bordering Sudan and South Sudan.\n\nThis physiographic region is subdivided into four lowland units:\n2. The **Tekezze and Angereb Lowlands**, which are identified as the **most northerly lowlands**.\n3. The **Abbay Dinder Lowlands**.\n4. The **Baro-Akobo Lowlands**.\n5. The **Omo-Gibe Lowlands**.\n\nThe Omo-Gibe River drains the Southwestern Highlands southwards and ends in Lake Turkana, marking the southern extent of the Western Lowlands region."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10080,
        "content": [
          "Baro-Akobo lowlands"
        ],
        "isCorrect": false
      },
      {
        "id": 10081,
        "content": [
          "Abay-Dinder lowlands"
        ],
        "isCorrect": false
      },
      {
        "id": 10082,
        "content": [
          "Omo-Ghibe lowlands"
        ],
        "isCorrect": true
      },
      {
        "id": 10083,
        "content": [
          "Tekezze-Angereb lowlands"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2521,
    "content": [
      "Which one of the following explains the temporal variation of rainfall in Ethiopia?"
    ],
    "explanation": [
      "Ethiopia’s rainfall varies greatly over time, divided into four main seasons: *Kiremt* (summer, June–August), *Belg* (spring, March–May), *Meher* (autumn, September–November), and *Bega* (winter, December–February).\n\n**Spring (*Belg*) is one of the two main rainy seasons**, providing significant rain along with *Kiremt*. Together, these two seasons supply **over 90% of Ethiopia’s total rainfall**, showing a clear **temporal variation** in the country’s climate."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10092,
        "content": [
          "Spring is the rainy season in most parts of Ethiopia."
        ],
        "isCorrect": true
      },
      {
        "id": 10093,
        "content": [
          "In Autumn, many places in Ethiopia receive the highest rainfall."
        ],
        "isCorrect": false
      },
      {
        "id": 10094,
        "content": [
          "There is little seasonal variation in the amount of rain in Ethiopia."
        ],
        "isCorrect": false
      },
      {
        "id": 10095,
        "content": [
          "The lowlands of Afar typically receive rain in summer."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2526,
    "content": [
      "Which of the following igneous rock has clearly observed crystals and coarse grain?"
    ],
    "explanation": [
      "Coarse grains and clearly visible crystals are characteristic of intrusive (or plutonic) igneous rocks, which cool slowly deep beneath the Earth's surface. Granite is a classic example of such a rock. Basalt and obsidian are extrusive (cool quickly on the surface), and marble is a metamorphic rock."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10112,
        "content": [
          "Obsidian"
        ],
        "isCorrect": false
      },
      {
        "id": 10113,
        "content": [
          "Granite"
        ],
        "isCorrect": true
      },
      {
        "id": 10114,
        "content": [
          "Marble"
        ],
        "isCorrect": false
      },
      {
        "id": 10115,
        "content": [
          "Basalt"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2527,
    "content": [
      "One of the following is a poorly drained and aerated soil type. Which one is it?"
    ],
    "explanation": [
      "Clay soils are composed of very fine particles. These particles pack tightly together, leaving very small pore spaces. This structure causes them to retain a large amount of water and restricts the movement of air, leading to poor drainage and aeration."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10116,
        "content": [
          "Loam soils"
        ],
        "isCorrect": false
      },
      {
        "id": 10117,
        "content": [
          "Silt soils"
        ],
        "isCorrect": false
      },
      {
        "id": 10118,
        "content": [
          "Clay soils"
        ],
        "isCorrect": true
      },
      {
        "id": 10119,
        "content": [
          "Sandy soils"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2528,
    "content": [
      "Which of the following is correct about natural causes of climate change?"
    ],
    "explanation": [
      "Over millions of years, the movement of continents (continental drift) alters the shape and size of ocean basins. This directly influences the patterns of ocean currents and global wind systems, which are key components in distributing heat around the planet and thus affect long-term climate."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_CHANGE_IMPACTS_AND_SOLUTIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10120,
        "content": [
          "Continental drift changes the flow of ocean currents and winds."
        ],
        "isCorrect": true
      },
      {
        "id": 10121,
        "content": [
          "Volcanic eruption leads to atmospheric heating."
        ],
        "isCorrect": false
      },
      {
        "id": 10122,
        "content": [
          "Natural causes are becoming the major causes of climate change."
        ],
        "isCorrect": false
      },
      {
        "id": 10123,
        "content": [
          "Ocean currents via releasing water vapor have a net cooling effect."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2529,
    "content": [
      "How do you explain the spatio-temporal distribution of temperature in Ethiopia?"
    ],
    "explanation": [
      "In Ethiopia, particularly in the highlands, the winter season (Bega) is characterized by dry, clear skies. This lack of cloud cover allows for significant solar radiation during the day (leading to higher temperatures) and rapid heat loss at night (leading to lower temperatures), resulting in the largest diurnal (daily) temperature range."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10124,
        "content": [
          "Annual range of temperature is greater than the daily range."
        ],
        "isCorrect": false
      },
      {
        "id": 10125,
        "content": [
          "Temperature decreases from the center to the peripheries."
        ],
        "isCorrect": false
      },
      {
        "id": 10126,
        "content": [
          "Daily range of temperature is the highest during winter season."
        ],
        "isCorrect": true
      },
      {
        "id": 10127,
        "content": [
          "Highlands exhibit the highest annual range of temperature."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2530,
    "content": [
      "Which climatic zone of Ethiopia experiences hot temperature, small cloud cover and very windy conditions throughout the year?"
    ],
    "explanation": [
      "The 'Bereha' zone is the hot, arid (desert) climate of Ethiopia, typically found at altitudes below 500 meters. It is characterized by consistently high temperatures, minimal cloud cover, low rainfall, and often windy conditions."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10128,
        "content": [
          "Woina Dega"
        ],
        "isCorrect": false
      },
      {
        "id": 10129,
        "content": [
          "Bereha"
        ],
        "isCorrect": true
      },
      {
        "id": 10130,
        "content": [
          "Dega"
        ],
        "isCorrect": false
      },
      {
        "id": 10131,
        "content": [
          "Wurch"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2536,
    "content": [
      "What is the size of Africa compared to the sizes of other continents?"
    ],
    "explanation": [
      "Africa is the world's second-largest continent in terms of both land area (about 30.37 million sq km) and population. Only Asia is larger."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10152,
        "content": [
          "It is the largest continent next to the Asian continent."
        ],
        "isCorrect": true
      },
      {
        "id": 10153,
        "content": [
          "It constitutes half of the total land surface of the earth."
        ],
        "isCorrect": false
      },
      {
        "id": 10154,
        "content": [
          "It nearly doubles the total size of North America."
        ],
        "isCorrect": false
      },
      {
        "id": 10155,
        "content": [
          "It is four times larger than the size of Antarctica."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2537,
    "content": [
      "How do the relative compact shape and unbroken coastline of Africa impact its development?"
    ],
    "explanation": [
      "A compact shape, where the distance from the center to any boundary is relatively similar, can make a country or continent easier to govern, administer, and defend because it simplifies internal transportation and communication lines and reduces the length of borders to be managed. Africa's unbroken coastline, however, limits natural harbors."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10156,
        "content": [
          "Its compact shape discourages intra-continental movements."
        ],
        "isCorrect": false
      },
      {
        "id": 10157,
        "content": [
          "Its unbroken coastline makes the continent rich in natural harbors."
        ],
        "isCorrect": false
      },
      {
        "id": 10158,
        "content": [
          "Its unbroken coastline encourages external communications."
        ],
        "isCorrect": false
      },
      {
        "id": 10159,
        "content": [
          "Its compact shape relatively eases administration and defense."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2539,
    "content": [
      "Which region of Africa lies both in the northern and southern hemispheres?"
    ],
    "explanation": [
      "Eastern Africa is bisected by the Equator. Countries like Kenya, Uganda, and Somalia have territory in both the Northern and Southern Hemispheres."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10164,
        "content": [
          "Northern Africa"
        ],
        "isCorrect": false
      },
      {
        "id": 10165,
        "content": [
          "Southern Africa"
        ],
        "isCorrect": false
      },
      {
        "id": 10166,
        "content": [
          "Western Africa"
        ],
        "isCorrect": false
      },
      {
        "id": 10167,
        "content": [
          "Eastern Africa"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2540,
    "content": [
      "Among the following geological events, which one happened during the Cenozoic Era?"
    ],
    "explanation": [
      "The Cenozoic Era, particularly in Africa, was marked by significant tectonic activity related to the formation of the Great Rift Valley. This activity led to extensive volcanism and the uplift of large plateaus and volcanic mountains, such as the Ethiopian Highlands and Mount Kilimanjaro."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10168,
        "content": [
          "Formation of Laurasia and Gondwanaland"
        ],
        "isCorrect": false
      },
      {
        "id": 10169,
        "content": [
          "Formation of plateau and volcanic mountains"
        ],
        "isCorrect": true
      },
      {
        "id": 10170,
        "content": [
          "The slow sinking and rising of landmass"
        ],
        "isCorrect": false
      },
      {
        "id": 10171,
        "content": [
          "Transgression and regression of the sea"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2541,
    "content": [
      "Which of the following is correct about the African plateaus?"
    ],
    "explanation": [
      "Africa is often called the \"plateau continent\" because a vast portion of its landmass consists of a series of extensive plateaus. These plateaus are a dominant feature of its topography, covering well over half of its total area."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10172,
        "content": [
          "Plateaus account for more than half of the landscape of the continent."
        ],
        "isCorrect": true
      },
      {
        "id": 10173,
        "content": [
          "The Bihe plateau is an example of low plateaus."
        ],
        "isCorrect": false
      },
      {
        "id": 10174,
        "content": [
          "Eastern Africa is largely areas of low plateaus."
        ],
        "isCorrect": false
      },
      {
        "id": 10175,
        "content": [
          "High plateaus are abundantly found in Northern and Western Africa."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2542,
    "content": [
      "Which wind type is dominantly affecting the tropical climate of Africa?"
    ],
    "explanation": [
      "The tropical regions of Africa are located within the belt of the Trade Winds. The Northeast Trade Winds and Southeast Trade Winds converge near the equator at the Intertropical Convergence Zone (ITCZ), and their movement and interaction are the primary drivers of rainfall and seasons in tropical Africa."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10176,
        "content": [
          "Polar easterlies"
        ],
        "isCorrect": false
      },
      {
        "id": 10177,
        "content": [
          "Guinea Monsoon"
        ],
        "isCorrect": false
      },
      {
        "id": 10178,
        "content": [
          "Westerly winds"
        ],
        "isCorrect": false
      },
      {
        "id": 10179,
        "content": [
          "Trade winds"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2543,
    "content": [
      "How do you describe the seasonal temperature condition of Africa?"
    ],
    "explanation": [
      "June to August corresponds to summer in the Northern Hemisphere. During this time, the sun is directly overhead at or near the Tropic of Cancer, leading to intensely high temperatures across the Sahara Desert."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10180,
        "content": [
          "Months from March to May exhibit low temperature in the most parts of the northern Africa."
        ],
        "isCorrect": false
      },
      {
        "id": 10181,
        "content": [
          "The Sahara Desert experiences a relatively high temperature between June to August."
        ],
        "isCorrect": true
      },
      {
        "id": 10182,
        "content": [
          "Southern Africa experiences low temperature from December to February."
        ],
        "isCorrect": false
      },
      {
        "id": 10183,
        "content": [
          "When the sun is overhead at the Tropic of Capricorn, northern parts of Africa experience the highest temperature."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2544,
    "content": [
      "One of the following is the main feature of warm temperate continental climatic region of Africa. Which one is it?"
    ],
    "explanation": [
      "The warm temperate continental climate (found for instance in the highveld of South Africa) receives a significant portion of its moisture from air masses originating over the ocean. The westerlies from the Atlantic bring rainfall to these regions."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10184,
        "content": [
          "Its main source of rainfall is from the Atlantic Ocean."
        ],
        "isCorrect": true
      },
      {
        "id": 10185,
        "content": [
          "It is mostly found in the northern parts of Africa."
        ],
        "isCorrect": false
      },
      {
        "id": 10186,
        "content": [
          "It occupies the largest climatic region of Africa."
        ],
        "isCorrect": false
      },
      {
        "id": 10187,
        "content": [
          "It has a high rainfall and low air temperature."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2545,
    "content": [
      "Which part of Africa is highly prone to drought?"
    ],
    "explanation": [
      "The region just north of the wetter tropics is the Sahel, a vast semi-arid transitional zone between the Sahara Desert to the north and the savanna to the south. This region is characterized by highly variable and unreliable rainfall, making it extremely prone to recurrent and severe droughts."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_CHANGE_IMPACTS_AND_SOLUTIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10188,
        "content": [
          "The Northern tip of Africa"
        ],
        "isCorrect": false
      },
      {
        "id": 10189,
        "content": [
          "The Southern tip of Africa"
        ],
        "isCorrect": false
      },
      {
        "id": 10190,
        "content": [
          "North of wetter tropics"
        ],
        "isCorrect": true
      },
      {
        "id": 10191,
        "content": [
          "The Central Africa"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2547,
    "content": [
      "Among the following lakes of Africa, which one is a non-rift valley lake?"
    ],
    "explanation": [
      "Lake Victoria is the largest lake in Africa but is not a Rift Valley lake. It occupies a shallow depression between the eastern and western branches of the Great Rift Valley. Lakes Tanganyika, Kivu, and Turkana are all classic examples of deep, elongated lakes formed within the rift valley itself."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10196,
        "content": [
          "Kivu"
        ],
        "isCorrect": false
      },
      {
        "id": 10197,
        "content": [
          "Victoria"
        ],
        "isCorrect": true
      },
      {
        "id": 10198,
        "content": [
          "Tanganyika"
        ],
        "isCorrect": false
      },
      {
        "id": 10199,
        "content": [
          "Turkana"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2549,
    "content": [
      "How do you analyze the hydro politics of the Nile River?"
    ],
    "explanation": [
      "While primarily designed for Ethiopia's electricity needs, the Great Ethiopian Renaissance Dam (GERD) is expected to provide benefits to neighboring downstream countries, such as Sudan and Egypt, through regulated water flow (reducing flooding and sedimentation) and the potential to purchase cheap electricity."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10204,
        "content": [
          "Lower course countries are the least beneficiary of the River water."
        ],
        "isCorrect": false
      },
      {
        "id": 10205,
        "content": [
          "The Great Ethiopian Renaissance Dam will benefit the neighboring countries."
        ],
        "isCorrect": true
      },
      {
        "id": 10206,
        "content": [
          "White Nile is the largest supplier of water to the Nile River."
        ],
        "isCorrect": false
      },
      {
        "id": 10207,
        "content": [
          "Historically, Nile basin countries have been fairly utilizing the River water."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2554,
    "content": [
      "Which of the following planet is situated very close to the Sun?"
    ],
    "explanation": [
      "Among the options provided, Earth is the closest planet to the Sun. The order of the listed planets from the Sun is Earth, Jupiter, Saturn, and Uranus. (The actual closest planet is Mercury, but it is not an option)."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10224,
        "content": [
          "Jupiter"
        ],
        "isCorrect": false
      },
      {
        "id": 10225,
        "content": [
          "Saturn"
        ],
        "isCorrect": false
      },
      {
        "id": 10226,
        "content": [
          "Uranus"
        ],
        "isCorrect": false
      },
      {
        "id": 10227,
        "content": [
          "Earth"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2555,
    "content": [
      "Which of the following describes the core structure of the earth?"
    ],
    "explanation": [
      "The Earth's core, particularly the inner core, has temperatures estimated to be around 5,000 to 6,000 degrees Celsius. This temperature range is comparable to the temperature of the surface of the Sun (the photosphere)."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10228,
        "content": [
          "It is mainly composed of silicate minerals."
        ],
        "isCorrect": false
      },
      {
        "id": 10229,
        "content": [
          "It is as hot as the surface of the sun."
        ],
        "isCorrect": true
      },
      {
        "id": 10230,
        "content": [
          "Its inner section is liquid."
        ],
        "isCorrect": false
      },
      {
        "id": 10231,
        "content": [
          "It accounts for the largest volume of the earth."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2556,
    "content": [
      "One of the following explains the Continental Drift Theory. Which one is it?"
    ],
    "explanation": [
      "According to Alfred Wegener's theory of Continental Drift, the ancient supercontinent Pangaea first broke into two large landmasses. The northern supercontinent was named Laurasia (comprising future North America, Europe, and Asia), and the southern one was Gondwanaland."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10232,
        "content": [
          "Laurasia was the northern part of the supercontinent."
        ],
        "isCorrect": true
      },
      {
        "id": 10233,
        "content": [
          "The theory was developed by Thomas Robert Malthus."
        ],
        "isCorrect": false
      },
      {
        "id": 10234,
        "content": [
          "Gondwanaland was once a single super continent."
        ],
        "isCorrect": false
      },
      {
        "id": 10235,
        "content": [
          "The drifting of continents was centered upon Europe."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2558,
    "content": [
      "If you find a large number of herbivore and carnivore animals in a certain geographical area in Africa, what can you generalize about the type of the climate of the area?"
    ],
    "explanation": [
      "The Tropical Savanna biome, with its vast grasslands dotted with trees, supports large herds of grazing herbivores (like zebras, wildebeest). This abundance of prey, in turn, supports a significant population of carnivores (like lions, cheetahs). This ecosystem is famous for its high biomass of large mammals."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10240,
        "content": [
          "Tropical desert and semi-desert"
        ],
        "isCorrect": false
      },
      {
        "id": 10241,
        "content": [
          "Highland climate"
        ],
        "isCorrect": false
      },
      {
        "id": 10242,
        "content": [
          "Tropical Savanna climate"
        ],
        "isCorrect": true
      },
      {
        "id": 10243,
        "content": [
          "Equatorial climate"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2560,
    "content": [
      "Which soil type is mainly located in the tropical monsoon climatic region of Africa?"
    ],
    "explanation": [
      "Lixisols are soils that are common in seasonally dry tropical regions, such as those with a monsoon climate. They are characterized by weathering and leaching but have a higher base saturation than more intensely leached tropical soils, making them suitable for agriculture in these climatic zones."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10248,
        "content": [
          "Acrisols"
        ],
        "isCorrect": false
      },
      {
        "id": 10249,
        "content": [
          "Calcisols"
        ],
        "isCorrect": false
      },
      {
        "id": 10250,
        "content": [
          "Lixisols"
        ],
        "isCorrect": true
      },
      {
        "id": 10251,
        "content": [
          "Luvisols"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2564,
    "content": [
      "What could be generalized about the economic growth and development trend of Africa?"
    ],
    "explanation": [
      "A common characteristic of many African economies is a reliance on exporting raw primary commodities (like oil, minerals, and agricultural products) which have relatively low prices, while importing expensive manufactured and high-tech goods. This often leads to a situation where the value of imports exceeds the value of exports, resulting in a negative trade balance."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10264,
        "content": [
          "Rapid population growth acts as an engine to many African economies."
        ],
        "isCorrect": false
      },
      {
        "id": 10265,
        "content": [
          "Different economic sectors of the continent are being integrated."
        ],
        "isCorrect": false
      },
      {
        "id": 10266,
        "content": [
          "Manufactured products dominated the export items of the continent."
        ],
        "isCorrect": false
      },
      {
        "id": 10267,
        "content": [
          "Most African countries exhibit a negative trade balance."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2565,
    "content": [
      "Which feature best explains the socioeconomic condition of developed countries?"
    ],
    "explanation": [
      "Developed countries are characterized by advanced, industrialized economies where the majority of the population is engaged in service and industrial sectors. These activities are concentrated in cities, leading to a very high level of urbanization, with most of the population residing in urban areas."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10268,
        "content": [
          "High proportion of children"
        ],
        "isCorrect": false
      },
      {
        "id": 10269,
        "content": [
          "High level of urbanization"
        ],
        "isCorrect": true
      },
      {
        "id": 10270,
        "content": [
          "Dominant primary industries"
        ],
        "isCorrect": false
      },
      {
        "id": 10271,
        "content": [
          "Labor-intensive investments"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2568,
    "content": [
      "How does the International Monetary Fund (IMF) contribute to the economic development of nations?"
    ],
    "explanation": [
      "A core mandate of the IMF is to ensure the stability of the international monetary system. It does this by monitoring exchange rates and balance of payments. Stable exchange rates are crucial for predictable and reliable international trade and investment, which are essential for economic development."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10280,
        "content": [
          "By promoting countries to set tariffs and quotas"
        ],
        "isCorrect": false
      },
      {
        "id": 10281,
        "content": [
          "By supporting green campaigns"
        ],
        "isCorrect": false
      },
      {
        "id": 10282,
        "content": [
          "By stabilizing exchange rates"
        ],
        "isCorrect": true
      },
      {
        "id": 10283,
        "content": [
          "By encouraging state ownership of enterprises"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2569,
    "content": [
      "As a citizen of Ethiopia, what is your view about the advantage your country gained as a result of globalization?"
    ],
    "explanation": [
      "Globalization facilitates the movement of people across borders for work. Many Ethiopians work abroad and send money back to their families. These financial inflows, known as remittances, are a significant source of foreign currency for the country and provide crucial economic support to many households."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10284,
        "content": [
          "It marks the domination of imported products."
        ],
        "isCorrect": false
      },
      {
        "id": 10285,
        "content": [
          "It increases the flow of remittance."
        ],
        "isCorrect": true
      },
      {
        "id": 10286,
        "content": [
          "It helps to exercise the western cultures."
        ],
        "isCorrect": false
      },
      {
        "id": 10287,
        "content": [
          "It encourages a high consumption of domestic products."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2571,
    "content": [
      "Why has the quantitative revolution been introduced to the subject matter of Geography?"
    ],
    "explanation": [
      "The quantitative revolution in the 1950s and 1960s was a major paradigm shift in geography. It introduced statistical methods, mathematical modeling, and a more scientific approach with the goal of moving beyond mere description (idiographic approach) towards developing general laws and theories (nomothetic approach) to explain spatial patterns."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_SPATIAL_INFORMATION_AND_DATA_PROCESSING",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10292,
        "content": [
          "To change the empirical nature of geography to a descriptive one"
        ],
        "isCorrect": false
      },
      {
        "id": 10293,
        "content": [
          "To explain and interpret spatial phenomena in a subjective manner"
        ],
        "isCorrect": false
      },
      {
        "id": 10294,
        "content": [
          "To enable geography to become law making science"
        ],
        "isCorrect": true
      },
      {
        "id": 10295,
        "content": [
          "To use the language of literature instead of mathematical language"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2573,
    "content": [
      "If you observe a point where a strong river cuts in to the course of a weaker river in your locality, which of the features listed below represents the observed case?"
    ],
    "explanation": [
      "This scenario describes river capture (or piracy). When a more powerful, erosive river (the pirate stream) erodes through a drainage divide and intercepts the course of a weaker river, it diverts the weaker river's flow into its own channel. The point of interception is marked by a sharp, right-angled bend, which is known as the elbow of capture."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10300,
        "content": [
          "Misfit stream"
        ],
        "isCorrect": false
      },
      {
        "id": 10301,
        "content": [
          "Elbow of capture"
        ],
        "isCorrect": true
      },
      {
        "id": 10302,
        "content": [
          "Reverse drainage"
        ],
        "isCorrect": false
      },
      {
        "id": 10303,
        "content": [
          "Wind gap"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2575,
    "content": [
      "In which of the following conditions does folding happen?"
    ],
    "explanation": [
      "Folding of rock strata occurs under compressional stress. This happens when tectonic forces cause two plates or parts of a plate to push towards each other, squeezing the rock layers and causing them to buckle and bend into folds (anticlines and synclines)."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10308,
        "content": [
          "When two forces move away from one another."
        ],
        "isCorrect": false
      },
      {
        "id": 10309,
        "content": [
          "When molten materials are forced out to the surface."
        ],
        "isCorrect": false
      },
      {
        "id": 10310,
        "content": [
          "When two plates move in parallel directions."
        ],
        "isCorrect": false
      },
      {
        "id": 10311,
        "content": [
          "When two different forces act towards each other."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2576,
    "content": [
      "What type of erosion is commonly found in coastal areas?"
    ],
    "explanation": [
      "Coastal areas are, by definition, where the land meets the sea. The primary agent of erosion and landform shaping in these environments is the constant action of sea waves, which erode, transport, and deposit sediment along the coastline."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10312,
        "content": [
          "Erosion through glaciation"
        ],
        "isCorrect": false
      },
      {
        "id": 10313,
        "content": [
          "Erosion by sea waves"
        ],
        "isCorrect": true
      },
      {
        "id": 10314,
        "content": [
          "Wind erosion"
        ],
        "isCorrect": false
      },
      {
        "id": 10315,
        "content": [
          "Stream erosion"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2577,
    "content": [
      "What is a crescent-moon shaped small hill of sediments that is formed by the action of wind called?"
    ],
    "explanation": [
      "A barchan is a specific type of sand dune characterized by its distinct crescent shape. It forms in areas with a consistent wind direction and a limited supply of sand. The \"horns\" of the crescent point downwind. While it is a type of sand dune, \"barchan\" is the precise term for this shape."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10316,
        "content": [
          "Beach"
        ],
        "isCorrect": false
      },
      {
        "id": 10317,
        "content": [
          "Loess deposit"
        ],
        "isCorrect": false
      },
      {
        "id": 10318,
        "content": [
          "Barchan"
        ],
        "isCorrect": true
      },
      {
        "id": 10319,
        "content": [
          "Sand dune"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2578,
    "content": [
      "Which structure of the atmosphere is known by containing the lowest percentage of atmospheric mass?"
    ],
    "explanation": [
      "The thermosphere is the outermost layer of the atmosphere before the exosphere. The air here is extremely thin, with gas molecules being very far apart. Although temperatures can be very high, the density is incredibly low, meaning it contains a minuscule fraction (less than 0.01%) of the total atmospheric mass."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10320,
        "content": [
          "Stratosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 10321,
        "content": [
          "Troposphere"
        ],
        "isCorrect": false
      },
      {
        "id": 10322,
        "content": [
          "Mesosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 10323,
        "content": [
          "Thermosphere"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2579,
    "content": [
      "Which of the following refers to how energy from the sun is transmitted to the surface of the earth?"
    ],
    "explanation": [
      "Solar energy travels through the vacuum of space to reach Earth. The only method of heat transfer that does not require a medium is electromagnetic radiation. The Sun radiates energy in the form of electromagnetic waves, including visible light, which heat the Earth's surface."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10324,
        "content": [
          "Radiation"
        ],
        "isCorrect": true
      },
      {
        "id": 10325,
        "content": [
          "Advection"
        ],
        "isCorrect": false
      },
      {
        "id": 10326,
        "content": [
          "Convection"
        ],
        "isCorrect": false
      },
      {
        "id": 10327,
        "content": [
          "Conduction"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2580,
    "content": [
      "What is the common feature of planetary winds?"
    ],
    "explanation": [
      "Planetary winds, also known as prevailing winds (like the Trade Winds, Westerlies, and Polar Easterlies), are large-scale wind systems that blow over vast areas of the globe. They are driven by the uneven heating of the Earth and its rotation, covering extensive belts of latitude."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10328,
        "content": [
          "They change their directions on a daily basis."
        ],
        "isCorrect": false
      },
      {
        "id": 10329,
        "content": [
          "They affect small areas for short periods of time."
        ],
        "isCorrect": false
      },
      {
        "id": 10330,
        "content": [
          "They cover a wide area of the earth."
        ],
        "isCorrect": true
      },
      {
        "id": 10331,
        "content": [
          "They are common along the coastal areas."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2581,
    "content": [
      "Which of the following is correct about ocean currents?"
    ],
    "explanation": [
      "Warm ocean currents heat the air above them, increasing the air's capacity to hold moisture through evaporation. When this warm, moist air moves over a cooler landmass, it cools, condenses, and forms clouds, often leading to increased precipitation in coastal areas."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10332,
        "content": [
          "Ocean current is the vertical movement of ocean water."
        ],
        "isCorrect": false
      },
      {
        "id": 10333,
        "content": [
          "Warm ocean currents cause precipitation to the surrounding areas."
        ],
        "isCorrect": true
      },
      {
        "id": 10334,
        "content": [
          "Cold ocean currents increase the temperature of the nearby areas."
        ],
        "isCorrect": false
      },
      {
        "id": 10335,
        "content": [
          "Warm ocean currents tend to reduce the surrounding temperature."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2585,
    "content": [
      "How do you describe the economic growth and development trend of Ethiopia?"
    ],
    "explanation": [
      "In recent decades, Ethiopia has invested heavily in infrastructure development, particularly road construction. This has significantly increased the network of all-weather roads, improving connectivity between rural and urban areas and facilitating economic activity."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10348,
        "content": [
          "Many settlements have access to all-weather roads."
        ],
        "isCorrect": true
      },
      {
        "id": 10349,
        "content": [
          "The country has the highest literacy rates in Africa."
        ],
        "isCorrect": false
      },
      {
        "id": 10350,
        "content": [
          "Malnutrition is a serious problem in urban areas than it is in rural areas."
        ],
        "isCorrect": false
      },
      {
        "id": 10351,
        "content": [
          "School dropouts are higher in urban areas than in rural areas."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2586,
    "content": [
      "What should policy makers in Ethiopia do to boost the economy?"
    ],
    "explanation": [
      "A key strategy for sustainable economic growth is export diversification. Relying on a few primary commodities makes an economy vulnerable to price fluctuations. By promoting a wider variety of export goods, including manufactured products and services, a country can create more stable revenue streams and boost its economy."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10352,
        "content": [
          "Encouraging state control of the economy"
        ],
        "isCorrect": false
      },
      {
        "id": 10353,
        "content": [
          "Encouraging population growth of the country"
        ],
        "isCorrect": false
      },
      {
        "id": 10354,
        "content": [
          "Promoting import of luxury items"
        ],
        "isCorrect": false
      },
      {
        "id": 10355,
        "content": [
          "Promoting diversification of export items"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2587,
    "content": [
      "Why was the Plan for Accelerated and Sustained Development to End Poverty (PASDEP) not successful as planned in Ethiopia?"
    ],
    "explanation": [
      "PASDEP was implemented from 2005 to 2010. Its later years coincided with the global financial crisis of 2008-2009. This crisis led to reduced foreign direct investment, lower export earnings, and decreased development aid, which significantly hampered the achievement of the ambitious goals set out in the plan."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10356,
        "content": [
          "Because of a lack of study support from experts"
        ],
        "isCorrect": false
      },
      {
        "id": 10357,
        "content": [
          "Due to the then global financial crisis"
        ],
        "isCorrect": true
      },
      {
        "id": 10358,
        "content": [
          "Because of the recurrent flooding in the country"
        ],
        "isCorrect": false
      },
      {
        "id": 10359,
        "content": [
          "Due to shortage of working labor force"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2588,
    "content": [
      "Which one the following describes the distribution of pressure over the surface of the earth?"
    ],
    "explanation": [
      "The global pressure belts (like the ITCZ and subtropical highs) follow the seasonal migration of the sun's direct rays. When the sun is overhead at the Tropic of Capricorn (during the Southern Hemisphere's summer, around December), the zone of maximum heating shifts south. This causes the entire system of pressure belts to also shift southward."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10360,
        "content": [
          "When the sun is overhead north of the equator, pressure belts shift southward."
        ],
        "isCorrect": false
      },
      {
        "id": 10361,
        "content": [
          "When the sun is overhead at the equator, pressure belts move northward by small degrees."
        ],
        "isCorrect": false
      },
      {
        "id": 10362,
        "content": [
          "When the sun is overhead at the Tropic of Cancer, pressure belts shift southward."
        ],
        "isCorrect": false
      },
      {
        "id": 10363,
        "content": [
          "When the sun is overhead at the Tropic of Capricorn, pressure belts shift southward."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2590,
    "content": [
      "One of the following describes the tropical zone of the earth. Which one is it?"
    ],
    "explanation": [
      "The tropical zone, or the tropics, is the region of the Earth surrounding the Equator. It is geographically defined as the area lying between the Tropic of Cancer in the Northern Hemisphere and the Tropic of Capricorn in the Southern Hemisphere."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10368,
        "content": [
          "It is found between the Tropic of Cancer and the Tropic of Capricorn."
        ],
        "isCorrect": true
      },
      {
        "id": 10369,
        "content": [
          "It is mostly covered by semi-desert and desert vegetation."
        ],
        "isCorrect": false
      },
      {
        "id": 10370,
        "content": [
          "It is characterized by low temperature year round."
        ],
        "isCorrect": false
      },
      {
        "id": 10371,
        "content": [
          "It is dominated by manufacturing economic activity."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2591,
    "content": [
      "Which of the following best explains the Tundra region?"
    ],
    "explanation": [
      "The Tundra is located in high latitudes (Arctic and Antarctic regions). Due to the tilt of the Earth's axis, these regions experience extreme seasonal variations in daylight. During the short summer, the sun remains above the horizon for very long periods, leading to a long duration of daily sunlight, sometimes for 24 hours a day (the \"midnight sun\")."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10372,
        "content": [
          "It has the highest daily range of temperature."
        ],
        "isCorrect": false
      },
      {
        "id": 10373,
        "content": [
          "It is mostly located in the southern hemisphere."
        ],
        "isCorrect": false
      },
      {
        "id": 10374,
        "content": [
          "It receives a long daily duration of sunlight in summer."
        ],
        "isCorrect": true
      },
      {
        "id": 10375,
        "content": [
          "It is inhabited by people whose life style is advanced."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2593,
    "content": [
      "Among the following, which one is primarily used to gather population data from a segment of the whole population?"
    ],
    "explanation": [
      "A sample survey is a statistical method that involves collecting data from a representative subset, or segment, of a population. The results from this sample are then used to make inferences or generalizations about the entire population. A census, by contrast, attempts to collect data from every member of the population."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_SPATIAL_INFORMATION_AND_DATA_PROCESSING",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10380,
        "content": [
          "Divorce records"
        ],
        "isCorrect": false
      },
      {
        "id": 10381,
        "content": [
          "Vital registration"
        ],
        "isCorrect": false
      },
      {
        "id": 10382,
        "content": [
          "Sample survey"
        ],
        "isCorrect": true
      },
      {
        "id": 10383,
        "content": [
          "Census"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2595,
    "content": [
      "What is the main role of the tertiary economic activities in a given country's development?"
    ],
    "explanation": [
      "The tertiary sector of the economy is also known as the service sector. Its main role is to provide services to consumers and other businesses, rather than producing raw materials (primary sector) or manufactured goods (secondary sector). Examples include retail, healthcare, education, finance, and transportation."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10388,
        "content": [
          "Making high-level decisions"
        ],
        "isCorrect": false
      },
      {
        "id": 10389,
        "content": [
          "Providing services"
        ],
        "isCorrect": true
      },
      {
        "id": 10390,
        "content": [
          "Producing agricultural crops"
        ],
        "isCorrect": false
      },
      {
        "id": 10391,
        "content": [
          "Processing raw materials"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2601,
    "content": [
      "How is the relative location of the Horn of Africa described?"
    ],
    "explanation": [
      "The Horn of Africa is a peninsula in Northeast Africa. Its relative location is defined by the major bodies of water surrounding it. To its northeast lies the Red Sea, which separates it from the Arabian Peninsula."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10412,
        "content": [
          "It is adjoined by the Red Sea in the northeast."
        ],
        "isCorrect": true
      },
      {
        "id": 10413,
        "content": [
          "It is bounded in the northwest by the Indian Ocean."
        ],
        "isCorrect": false
      },
      {
        "id": 10414,
        "content": [
          "It is situated to the southeast of Asia."
        ],
        "isCorrect": false
      },
      {
        "id": 10415,
        "content": [
          "It is bordered by the Sudan in the southwest."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2603,
    "content": [
      "What major event took place in the Horn during the Paleozoic Era?"
    ],
    "explanation": [
      "The Paleozoic Era (≈600–250 million years ago) is known as the **age of ancient life**, marked by the predominance of **invertebrates** like trilobites and shelled animals. In the Horn of Africa, this era saw mainly **denudation and peneplanation**, with **no major structural formations**, making the appearance of invertebrate marine life the defining global feature."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10420,
        "content": [
          "Climatic change with a massive deposition"
        ],
        "isCorrect": false
      },
      {
        "id": 10421,
        "content": [
          "Appearance of invertebrate marine creatures"
        ],
        "isCorrect": true
      },
      {
        "id": 10422,
        "content": [
          "Significant structural formation in the Horn"
        ],
        "isCorrect": false
      },
      {
        "id": 10423,
        "content": [
          "A continued and massive orogenic movement"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2604,
    "content": [
      "These questions are based on the table given.",
      "---",
      "Which station has the highest annual range of temperature?"
    ],
    "explanation": [
      "The annual range of temperature is the difference between the highest and lowest monthly average temperatures.",
      "Station I: 27°C - 26°C = 1°C.",
      "Station II: 35°C - 25°C = 10°C.",
      "Station III: 23°C - 11°C = 12°C.",
      "Station IV: 34°C - 24°C = 10°C.",
      "Station III has the highest range of 12°C."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_SPATIAL_INFORMATION_AND_DATA_PROCESSING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 86,
    "groupIndex": 1,
    "sharedContentId": 22,
    "sharedContent": [
      "The table below shows climatic data of a hypothetical region.",
      "images/geography/year_2015/shared_content_1.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_1.png"
    ],
    "choices": [
      {
        "id": 10424,
        "content": [
          "Station III"
        ],
        "isCorrect": true
      },
      {
        "id": 10425,
        "content": [
          "Station I"
        ],
        "isCorrect": false
      },
      {
        "id": 10426,
        "content": [
          "Station IV"
        ],
        "isCorrect": false
      },
      {
        "id": 10427,
        "content": [
          "Station II"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2607,
    "content": [
      "These questions are based on the table given.",
      "---",
      "Which station best represents the winter rainfall region of Ethiopia?"
    ],
    "explanation": [
      "Station IV is the best representation of a winter rainfall region. In the context of Ethiopia, winter rainfall occurs during December, January, and February, while the summer months of June to August are dry.\n\nStation I has high rainfall year-round, characteristic of a tropical rainforest climate, and Station II has very low rainfall, typical of an arid or desert climate.\n\nStation III shows a clear summer rainfall pattern, with peaks in June, July, and August.\n\nOnly Station IV exhibits the defining pattern of wet winters and dry summers, with rainfall highest in December (37 mm), January (41 mm), and February (39 mm), and lowest in June (1 mm) and July (4 mm)."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 86,
    "groupIndex": 4,
    "sharedContentId": 22,
    "sharedContent": [
      "The table below shows climatic data of a hypothetical region.",
      "images/geography/year_2015/shared_content_1.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_1.png"
    ],
    "choices": [
      {
        "id": 10436,
        "content": [
          "Station I"
        ],
        "isCorrect": false
      },
      {
        "id": 10437,
        "content": [
          "Station II"
        ],
        "isCorrect": false
      },
      {
        "id": 10438,
        "content": [
          "Station III"
        ],
        "isCorrect": false
      },
      {
        "id": 10439,
        "content": [
          "Station IV"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2617,
    "content": [
      "What is the most appropriate technique to display statistical data of portion of parts in relation to a single whole?"
    ],
    "explanation": [
      "A pie chart is specifically designed to represent proportions. The entire circle (the \"pie\") represents the total amount (100%), and the different sized \"slices\" represent the various parts or percentages that make up that whole."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_SPATIAL_INFORMATION_AND_DATA_PROCESSING",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10476,
        "content": [
          "Bar graph"
        ],
        "isCorrect": false
      },
      {
        "id": 10477,
        "content": [
          "Line graph"
        ],
        "isCorrect": false
      },
      {
        "id": 10478,
        "content": [
          "Pie chart"
        ],
        "isCorrect": true
      },
      {
        "id": 10479,
        "content": [
          "Histogram"
        ],
        "isCorrect": false
      }
    ]
  }
];
export default questions;
