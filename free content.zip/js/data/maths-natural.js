// StudentPrep Free Content — guide-selected units, maximum 25 questions per unit.
const questions = [
  {
    "id": 1028,
    "content": [
      "If f is a continuous function on [a, b] and F is its anti-derivative, then which of the following is true?"
    ],
    "explanation": [
      "If F is an antiderivative of f, then:\n$$\n\\int_{a}^{b} f(x)dx = F(b) - F(a)\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4113,
        "content": [
          "$$\\int_{a}^{b} F(x)dx$$ = $$f(b) - f(a)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4114,
        "content": [
          "$$\\int_{a}^{b} F'(x)dx$$ = $$f(b) - f(a)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4115,
        "content": [
          "$$\\int_{a}^{b} f(x)dx$$ = $$F(b) - F(a)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4116,
        "content": [
          "$$\\int_{a}^{b} f'(x)dx$$ = $$F(b) - F(a)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1032,
    "content": [
      "What are the domain and range of the function $$f(x) = 2x^{\\frac{3}{4}}$$ respectively?"
    ],
    "explanation": [
      "The function $$f(x)$$ = $$2x^{\\frac{3}{4}}$$ is defined only for $$x \\geq 0$$ because of the fractional exponent. Thus, the domain is $$[0, \\infty)$$.\n\nSince $$x^{\\frac{3}{4}} \\geq 0$$ for all $$x \\geq 0$$, the range is also $$[0, \\infty)$$.\n\nTherefore, the correct answer is $$[0, \\infty)$$ and $$[0, \\infty)$$."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4129,
        "content": [
          "$$\\mathbb{R}$$ and $$[0, \\infty)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4130,
        "content": [
          "$$[0, \\infty)$$ and $$[0, \\infty)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4131,
        "content": [
          "$$[0, \\infty)$$ and $$\\mathbb{R}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4132,
        "content": [
          "$$[0, \\infty)$$ and $$[0, \\infty)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1033,
    "content": [
      "Which one of the following defines a one-to-one function?"
    ],
    "explanation": [
      "A function is **one-to-one** if each output corresponds to exactly one input.\n- $$f = \\{(x, y): x$$ is a sister of $$y\\}$$: Not a function (one person can have multiple sisters).\n- $$f = \\{(x, y): y = 3x - 1\\}$$: y = 3x - 1 is a linear function with a unique output for each input, so it is one-to-one.\n- $$f = \\{(x, y): y = x^2 + 1\\}$$: $$y$$ = $$x^2 + 1$$ is not one-to-one (e.g., x = 1 and x = -1 give the same output).\n- $$f = \\{(x, y): y$$ is a father of $$x\\}$$: Not a function (one person can have only one father, but a father can have multiple children)."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4133,
        "content": [
          "$$f = \\{(x, y): x$$ is a sister of $$y\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4134,
        "content": [
          "$$f = \\{(x, y): y = 3x - 1\\}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4135,
        "content": [
          "$$f = \\{(x, y): y = x^2 + 1\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4136,
        "content": [
          "$$f = \\{(x, y): y$$ is a father of $$x\\}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1035,
    "content": [
      "Which one of the following sentences has a truth value?"
    ],
    "explanation": [
      "- **Truth value** requires a statement to be objectively true/false.\n- “Man is mortal!” asserts a factual, universal claim (all humans die), making it **true**.\n- “Man is selfish.” is debatable (subjective), “We shall win!” is a future prediction/opinion, ”Tomorrow is a beautiful day.” is subjective (\"beautiful\")."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4141,
        "content": [
          "Man is selfish."
        ],
        "isCorrect": false
      },
      {
        "id": 4142,
        "content": [
          "We shall win!"
        ],
        "isCorrect": false
      },
      {
        "id": 4143,
        "content": [
          "Man is mortal!"
        ],
        "isCorrect": true
      },
      {
        "id": 4144,
        "content": [
          "Tomorrow is a beautiful day."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1037,
    "content": [
      "The additive inverse of the complex number 3 - 4i is"
    ],
    "explanation": [
      "**Additive inverse** of a complex number a + bi is -a - bi.\n\nFor 3 - 4i:\n- Additive inverse = -3 + 4i."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4149,
        "content": [
          "3 + 4i"
        ],
        "isCorrect": false
      },
      {
        "id": 4150,
        "content": [
          "-3 - 4i"
        ],
        "isCorrect": false
      },
      {
        "id": 4151,
        "content": [
          "3 - 4i"
        ],
        "isCorrect": false
      },
      {
        "id": 4152,
        "content": [
          "-3 + 4i"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1038,
    "content": [
      "What is the modulus of the complex number -6 + 8i?"
    ],
    "explanation": [
      "**Modulus formula** for a complex number a + bi is $$\\sqrt{a^2 + b^2}$$.\n\nFor -6 + 8i:\n- a = -6, b = 8.\n- Modulus = $$\\sqrt{(-6)^2 + 8^2}$$ = $$\\sqrt{36 + 64}$$ = $$10$$."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4153,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 4154,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 4155,
        "content": [
          "10"
        ],
        "isCorrect": true
      },
      {
        "id": 4156,
        "content": [
          "8"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1039,
    "content": [
      "What are the modulus and argument of the complex number $$2 + 2i$$ respectively?"
    ],
    "explanation": [
      "- **Modulus**: $$\\sqrt{a^2 + b^2}$$.\n- **Argument**: $$\\tan^{-1}\\left(\\frac{b}{a}\\right)$$.\n\nFor 2 + 2i:\n\n- a = 2, b = 2.\n- Modulus = $$\\sqrt{2^2 + 2^2}$$ = $$\\sqrt{8}$$ = $$2\\sqrt{2}$$.\n- Argument = $$\\tan^{-1}\\left(\\frac{2}{2}\\right)$$ = $$\\tan^{-1}(1)$$ = $$\\frac{\\pi}{4}$$."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4157,
        "content": [
          "$$2\\sqrt{2}$$ and $$\\frac{\\pi}{4}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4158,
        "content": [
          "$$2$$ and $$\\frac{\\pi}{4}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4159,
        "content": [
          "$$2\\sqrt{2}$$ and $$-\\frac{\\pi}{4}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4160,
        "content": [
          "$$4$$ and $$\\frac{\\pi}{4}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1042,
    "content": [
      "Which one of the following forms represents an exhaustive set of events if a die is thrown once?"
    ],
    "explanation": [
      "For a set of events to be **exhaustive**, it must include all possible outcomes without any overlap or omission.\n- {(1, 2, 3), (4, 5), (6)}, subsets include all possible outcomes (1, 2, 3, 4, 5, 6) without any overlap or missing numbers."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SETS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4169,
        "content": [
          "{(1, 2), (4), (4, 5, 6)}"
        ],
        "isCorrect": false
      },
      {
        "id": 4170,
        "content": [
          "{(1, 2, 3), (4, 5), (6)}"
        ],
        "isCorrect": true
      },
      {
        "id": 4171,
        "content": [
          "{(1, 2), (2), (4, 5), (5, 6)}"
        ],
        "isCorrect": false
      },
      {
        "id": 4172,
        "content": [
          "{(1, 2, 3), (3, 4), (6)}"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1051,
    "content": [
      "Which of the following is true?"
    ],
    "explanation": [
      "The domain of $$y = \\tan^{-1}x$$ is $$(-\\infty, \\infty)$$, since the inverse tangent function is defined for all real numbers without restrictions. This function is continuous and smooth across its entire domain.\n- **Option B:** The domain of $$y = \\cos^{-1}x$$ is [-1, 1], because for real values, $$\\cos^{-1}x$$ only accepts inputs within this range, as the cosine function's range is [-1, 1].\n- **Option C:** $$\\sin^{-1}(0) = 0$$, not $$\\frac{\\pi}{2}$$, because the inverse sine of 0 corresponds to an angle of 0 radians.\n- **Option D:** $$\\tan^{-1}(0) = 0$$, as the inverse tangent of 0 is 0, corresponding to the angle whose tangent is 0."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4205,
        "content": [
          "The domain of $$y=\\tan^{-1}{x}$$ is $$(-\\infty, \\infty)$$."
        ],
        "isCorrect": true
      },
      {
        "id": 4206,
        "content": [
          "The domain of $$y=\\cos^{-1}{x}$$ is $$(-1, 1)$$."
        ],
        "isCorrect": false
      },
      {
        "id": 4207,
        "content": [
          "$$\\sin^{-1}(0)=\\frac{\\pi}{2}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 4208,
        "content": [
          "$$\\tan^{-1}(0)=1$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1052,
    "content": [
      "Which one of the following is the fourth term of the sequence $$\\left\\{cos\\left(\\frac{n\\pi}{2}\\right)\\right\\}$$?"
    ],
    "explanation": [
      "The sequence is $$\\left\\{ \\cos\\left(\\frac{n\\pi}{2}\\right) \\right\\}$$.\n\nTo find the fourth term n = 4:\n$$\n\\cos\\left(\\frac{4\\pi}{2}\\right) = \\cos(2\\pi) = 1\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4209,
        "content": [
          "0"
        ],
        "isCorrect": false
      },
      {
        "id": 4210,
        "content": [
          "-1"
        ],
        "isCorrect": false
      },
      {
        "id": 4211,
        "content": [
          "1"
        ],
        "isCorrect": true
      },
      {
        "id": 4212,
        "content": [
          "0.5"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1053,
    "content": [
      "Which of the following is a geometric sequence?"
    ],
    "explanation": [
      "8, -4, 2, -1, ... is a geometric sequence because the ratio between consecutive terms is constant:\n- $$\\frac{-4}{8} = -0.5$$\n- $$\\frac{2}{-4} = -0.5$$\n- $$\\frac{-1}{2} = -0.5$$\n\nThe common ratio is -0.5, so it is geometric."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4213,
        "content": [
          "1, 1.5, 2.5, 3.5, ..."
        ],
        "isCorrect": false
      },
      {
        "id": 4214,
        "content": [
          "0.1, 0.01, 0.0011, 0.000111, ..."
        ],
        "isCorrect": false
      },
      {
        "id": 4215,
        "content": [
          "8,-4, 2, -1 ..."
        ],
        "isCorrect": true
      },
      {
        "id": 4216,
        "content": [
          "0.1, 0.11, 0.12, 0.13,..."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1054,
    "content": [
      "A factory that produces electric cable had sales Birr 1,000,000 the first day. During each successive days the sales increased by Birr 10,000 every day. What is the total sales of the factory in the first 10 days?"
    ],
    "explanation": [
      "This is an arithmetic sequence where:\n- First term $$a_1$$ = Birr 1,000,000\n- Common difference $$d$$ = Birr 10,000\n- Number of days $$n$$ = 10\n\nThe total sales (sum of the first $$n$$ terms) is calculated using the formula for the sum of an arithmetic sequence:\n$$\nS_n = \\frac{n}{2} \\left( 2a_1 + (n-1)d \\right)\n$$\n\nSubstitute the values:\n\n$$\nS_{10} = \\frac{10}{2} \\left( 2(1,000,000) + (10-1)(10,000) \\right)\n$$\n$$\nS_{10} = 5 \\left( 2,000,000 + 90,000 \\right)\n$$\n$$\nS_{10} = 5 \\left( 2,090,000 \\right)\n$$\n$$\nS_{10} = 10,450,000\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4217,
        "content": [
          "Birr 10,000,000"
        ],
        "isCorrect": false
      },
      {
        "id": 4218,
        "content": [
          "Birr 1,090,000"
        ],
        "isCorrect": false
      },
      {
        "id": 4219,
        "content": [
          "Birr 20,900,000"
        ],
        "isCorrect": false
      },
      {
        "id": 4220,
        "content": [
          "Birr 10,450,000"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1055,
    "content": [
      "What is the least upper bound of the sequence $$\\left\\{2 + \\frac{n}{n+1}\\right\\}_{n=1}^{\\infty}$$?"
    ],
    "explanation": [
      "As $$n \\to \\infty$$, $$\\frac{n}{n+1} \\to 1$$, so the sequence approaches 2 + 1 = 3. This is the least upper bound."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4221,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 4222,
        "content": [
          "0"
        ],
        "isCorrect": false
      },
      {
        "id": 4223,
        "content": [
          "3"
        ],
        "isCorrect": true
      },
      {
        "id": 4224,
        "content": [
          "2"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1056,
    "content": [
      "Which one of the following sequences is a null sequence?"
    ],
    "explanation": [
      "A null sequence converges to 0. $$\\left\\{ \\frac{\\cos n}{n} \\right\\}$$ is a null sequence because:\n- $$\\cos n$$ is bounded $$1 \\leq \\cos n \\leq 1$$, and\n- $$\\frac{1}{n} \\to 0 \\ as \\ n \\to \\infty$$.\n\nThus, $$\\frac{\\cos n}{n} \\to 0$$, making it a null sequence."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4225,
        "content": [
          "$$\\left\\{nsin\\left(\\frac{1}{n}\\right)\\right\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4226,
        "content": [
          "$$\\left\\{\\left(1-\\frac{1}{n}\\right)\\right\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4227,
        "content": [
          "$$\\left\\{\\frac{n}{n+1}\\right\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4228,
        "content": [
          "$$\\left\\{\\frac{cos n}{n}\\right\\}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1057,
    "content": [
      "Suppose $$\\{a_n\\}$$ and $$\\{b_n\\}$$ are sequences with $$\\lim_{n \\to \\infty}a_n = L$$ and $$\\lim_{n \\to \\infty}b_n = M$$. Then which of the following is **NOT** necessarily true?"
    ],
    "explanation": [
      "The limit $$\\lim_{n \\to \\infty} \\left(\\frac{a_n}{b_n}\\right)$$ = $$\\frac{L}{M}$$ is not necessarily true unless M ≠ 0. If M = 0, the limit may not exist or may be undefined due to division by zero."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4229,
        "content": [
          "$$\\lim_{n \\to \\infty} (3a_n + 2b_n) = 3L + 2M$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4230,
        "content": [
          "$$\\lim_{n \\to \\infty}(a_n - b_n) = L - M$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4231,
        "content": [
          "$$\\lim_{n \\to \\infty} \\left(\\frac{a_n}{b_n}\\right) = \\frac{L}{M}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4232,
        "content": [
          "$$\\lim_{n \\to \\infty}a_nb_n = LM$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1058,
    "content": [
      "$$\\lim_{x \\to \\infty}\\frac{3x^2+2x}{5x-x^2}$$ is equal to"
    ],
    "explanation": [
      "To evaluate $$\\lim_{x \\to \\infty} \\frac{3x^2 + 2x}{5x - x^2}$$, divide the numerator and denominator by the highest power of $$x ( x^2 )$$:\n$$\n\\lim_{x \\to \\infty} \\frac{3x^2 + 2x}{5x - x^2} = \\lim_{x \\to \\infty} \\frac{3 + \\frac{2}{x}}{\\frac{5}{x} - 1}\n$$\nAs $$x \\to \\infty$$, $$\\frac{2}{x} \\to 0$$ and $$\\frac{5}{x} \\to 0$$, so the limit simplifies to:\n$$\n\\frac{3 + 0}{0 - 1} = \\frac{3}{-1} = -3\n$$."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4233,
        "content": [
          "-1"
        ],
        "isCorrect": false
      },
      {
        "id": 4234,
        "content": [
          "-3"
        ],
        "isCorrect": true
      },
      {
        "id": 4235,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 4236,
        "content": [
          "0"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1059,
    "content": [
      "Which of the following is the same as the derivative of a function f at a point P, where P is on the graph of f?"
    ],
    "explanation": [
      "The derivative of a function f at a point P represents the **slope of the tangent line** to the graph of f at P."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4237,
        "content": [
          "The continuity of the function at P."
        ],
        "isCorrect": false
      },
      {
        "id": 4238,
        "content": [
          "The slope of a secant line through P."
        ],
        "isCorrect": false
      },
      {
        "id": 4239,
        "content": [
          "The slope of the tangent line through P."
        ],
        "isCorrect": true
      },
      {
        "id": 4240,
        "content": [
          "The graph of $$f$$ has no jump at P."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1060,
    "content": [
      "What is the derivative of the function $$f(x) = 3x^2 + 2\\sqrt{x} - 4x$$ at $$x = 1$$?"
    ],
    "explanation": [
      "First, find the derivative of $$f(x) = 3x^2 + 2\\sqrt{x} - 4x$$:\n$$\nf'(x) = \\frac{d}{dx}(3x^2) + \\frac{d}{dx}(2\\sqrt{x}) - \\frac{d}{dx}(4x)\n$$\nUsing differentiation rules:\n$$\nf'(x) = 6x + \\frac{1}{\\sqrt{x}} - 4\n$$\nNow, evaluate $$f'(x)$$ at $$x = 1$$:\n$$\nf'(1) = 6(1) + \\frac{1}{\\sqrt{1}} - 4 = 6 + 1 - 4 = 3\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4241,
        "content": [
          "-1"
        ],
        "isCorrect": false
      },
      {
        "id": 4242,
        "content": [
          "-3"
        ],
        "isCorrect": false
      },
      {
        "id": 4243,
        "content": [
          "3"
        ],
        "isCorrect": true
      },
      {
        "id": 4244,
        "content": [
          "1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1061,
    "content": [
      "What are the 2nd and the nth derivative of $$f(x) = e^{3x}$$ respectively?"
    ],
    "explanation": [
      "For $$f(x) = e^{3x}$$, the derivatives are:\n\nFirst derivative:\n$$\nf'(x) = 3e^{3x} = 3f(x)\n$$\nSecond derivative:\n$$\nf''(x) = 3 \\cdot 3e^{3x} = 9e^{3x} = 9f(x)\n$$\n$$n^{th}$$ derivative:\n$$\nf^{(n)}(x) = 3^n e^{3x} = 3^n f(x)\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4245,
        "content": [
          "$$4f(x)$$ and $$2^nf(x)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4246,
        "content": [
          "$$2f(x)$$ and $$nf(x)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4247,
        "content": [
          "$$9f(x)$$ and $$3^nf(x)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4248,
        "content": [
          "$$9f(x)$$ and $$n^2f(x)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1062,
    "content": [
      "Which of the following is true about the zero of a function?"
    ],
    "explanation": [
      "The zero of a function is the value of x for which f(x) = 0. This corresponds to the x-intercept of the graph of the function."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4249,
        "content": [
          "It is the y-intercept of the function."
        ],
        "isCorrect": false
      },
      {
        "id": 4250,
        "content": [
          "It is the x-intercept of the function."
        ],
        "isCorrect": true
      },
      {
        "id": 4251,
        "content": [
          "It is the concavity point of the function."
        ],
        "isCorrect": false
      },
      {
        "id": 4252,
        "content": [
          "It is the critical point of the function."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1063,
    "content": [
      "Which of the following is true about the function defined by $$f(x) = x^3 - 3x^2$$ on [-1,3]?"
    ],
    "explanation": [
      "**Find critical numbers:**\n- $$f(x) = x^3 - 3x^2$$\n- $$f'(x) = 3x^2 - 6x$$\n\nSet $$f'(x) = 0$$:\n$$\n3x^2 - 6x = 0 \\implies x(x - 2) = 0 \\implies x = 0, 2\n$$\n\nCritical numbers: (0, 2)\n\n**Evaluate f(x) at critical points and endpoints:**\n\n- $$f(-1)$$ = $$(-1)^3 - 3(-1)^2$$ = $$-1 - 3$$ = $$-4$$\n- $$f(0)$$ = $$0^3 - 3(0)^2$$ = $$0$$\n- $$f(2)$$ = $$2^3 - 3(2)^2$$ = $$8 - 12$$ = $$-4$$\n- $$f(3)$$ = $$3^3 - 3(3)^2$$ = $$27 - 27$$ = $$0$$\n\nMaximum value: 0"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4253,
        "content": [
          "Its critical numbers are 0 and 2 and its maximum value is 15."
        ],
        "isCorrect": false
      },
      {
        "id": 4254,
        "content": [
          "Its critical numbers are 0, 2, 3 and its maximum value is 0."
        ],
        "isCorrect": false
      },
      {
        "id": 4255,
        "content": [
          "It has critical numbers at 0 and 2 and its maximum value is 0."
        ],
        "isCorrect": true
      },
      {
        "id": 4256,
        "content": [
          "Its critical numbers are 0 and 2 and its maximum value is -4."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1064,
    "content": [
      "What is the number that satisfies Rolle's Theorem for $$f(x) = x^2 - 3x + 1$$ on [0, 3]?"
    ],
    "explanation": [
      "Rolle's Theorem requires:\n\n- f(x) is continuous on [0, 3]\n- f(x) is differentiable on (0, 3)\n- f(0) = f(3)\n\nCheck f(0) and f(3):\n\n- $$f(0)$$ = $$0^2 - 3(0) + 1$$ = $$1$$\n- $$f(3)$$ = $$3^2 - 3(3) + 1$$ = $$9 - 9 + 1$$ = $$1$$\n\nNow, find $$f'(x)$$:\n$$\nf'(x) = 2x - 3\n$$\n\nSet $$f'(x) = 0$$ to find the critical number:\n$$\n2x - 3 = 0 \\implies x = \\frac{3}{2}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4257,
        "content": [
          "$$1$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4258,
        "content": [
          "$$-\\frac{3}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4259,
        "content": [
          "$$2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4260,
        "content": [
          "$$\\frac{3}{2}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1066,
    "content": [
      "If the radius $$r$$ of a sphere is increasing at the rate of 2 cm/min, then the rate of change of the volume when $$r = 1$$ cm is"
    ],
    "explanation": [
      "The volume of a sphere is $$V = \\frac{4}{3}\\pi r^3$$. Differentiate with respect to time t:\n$$\n\\frac{dV}{dt} = 4\\pi r^2 \\frac{dr}{dt}\n$$\nGiven $$\\frac{dr}{dt}$$ = $$2 \\, \\text{cm/min}$$ and r = 1 cm:\n$$\n\\frac{dV}{dt} = 4\\pi (1)^2 (2) = 8\\pi \\, \\text{cm}^3/\\text{min}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4265,
        "content": [
          "$$6\\pi cm^3/min$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4266,
        "content": [
          "$$4\\pi cm^3/min$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4267,
        "content": [
          "$$12\\pi cm^3/min$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4268,
        "content": [
          "$$8\\pi cm^3/min$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1067,
    "content": [
      "Which of the following is equal to $$\\int (cosx - 2x)dx$$ where c is a constant?"
    ],
    "explanation": [
      "Integrate term by term:\n$$\n\\int \\cos x \\, dx = \\sin x\n$$\n$$\n\\int -2x \\, dx = -x^2\n$$\nAdd the constant (c):\n$$\n\\int (\\cos x - 2x) \\, dx = \\sin x - x^2 + c\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4269,
        "content": [
          "$$sinx + x^2 + c.$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4270,
        "content": [
          "$$-sinx - x^2 + c.$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4271,
        "content": [
          "$$sinx - x^2 + c.$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4272,
        "content": [
          "$$-sinx + x^2 + c.$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1068,
    "content": [
      "What is the area of the region bounded by y = 0 and the graph of $$f(x) = 4 - x^2$$ on the interval [-1, 1]?"
    ],
    "explanation": [
      "$$\nA = \\int_{-1}^{1} (4 - x^2) \\, dx\n$$\nCompute the integral:\n$$\nA = \\left[ 4x - \\frac{x^3}{3} \\right]_{-1}^{1}\n$$\nEvaluate at the bounds:\n$$\nA = \\left( 4(1) - \\frac{1^3}{3} \\right) - \\left( 4(-1) - \\frac{(-1)^3}{3} \\right)\n$$\n$$\nA = \\left( 4 - \\frac{1}{3} \\right) - \\left( -4 + \\frac{1}{3} \\right)\n$$\n$$\nA = \\frac{11}{3} + \\frac{11}{3} = \\frac{22}{3}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4273,
        "content": [
          "$$\\frac{22}{3}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4274,
        "content": [
          "$$\\frac{2}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4275,
        "content": [
          "$$\\frac{26}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4276,
        "content": [
          "$$8$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1069,
    "content": [
      "Suppose $$\\int_1^2 f(x)dx = 6$$ and $$\\int_1^3 f(x)dx = 10$$, what is the value of $$\\int_2^3 f(x)dx$$ ?"
    ],
    "explanation": [
      "Given:\n\n- $$\\int_1^2 f(x)dx = 6$$\n- $$\\int_1^3 f(x)dx = 10$$\n\nSubtract the first integral from the second:\n$$\n\\int_2^3 f(x)dx = \\int_1^3 f(x)dx - \\int_1^2 f(x)dx = 10 - 6 = 4\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4277,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 4278,
        "content": [
          "-4"
        ],
        "isCorrect": false
      },
      {
        "id": 4279,
        "content": [
          "16"
        ],
        "isCorrect": false
      },
      {
        "id": 4280,
        "content": [
          "4"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1070,
    "content": [
      "Which of the following statements has a truth value T?"
    ],
    "explanation": [
      "$$\n(p \\land q) \\implies (p \\lor q)\n$$\nThis is always true (Tautology). If both p and q are true, then at least one of them is true, so the implication holds.\n\nOther statements are not tautologies and can be false for some combinations of p and q."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4281,
        "content": [
          "$$(p \\land q) \\implies (p \\lor q)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4282,
        "content": [
          "$$(p \\land q) \\implies \\lnot (p \\lor q)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4283,
        "content": [
          "$$(p \\lor q) \\implies (p \\land q)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4284,
        "content": [
          "$$(p \\implies q) \\implies (p \\lor q)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1071,
    "content": [
      "The inverse of the function $$y= 3x-5$$ is equal to"
    ],
    "explanation": [
      "**Swap x and y:**\n$$\nx = 3y - 5\n$$\n**Solve for y:**\n$$\ny = \\frac{x + 5}{3}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4285,
        "content": [
          "$$y = \\frac{x+5}{3}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4286,
        "content": [
          "$$y = \\frac{x+3}{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4287,
        "content": [
          "$$y = \\frac{x-5}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4288,
        "content": [
          "$$y = -5x+3$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1072,
    "content": [
      "Which of the following is the universal set of the expression $$\\frac{1}{x^2} + \\frac{x+1}{x^2+x}$$?"
    ],
    "explanation": [
      "The expression is defined when the denominators are not zero:\n$$\nx^2 \\neq 0 \\Rightarrow x \\neq 0\n$$\n$$\nx^2 + x \\neq 0 \\Rightarrow x(x + 1) \\neq 0 \\Rightarrow x \\neq 0, -1\n$$\nThus, the universal set excludes 0 and -1"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4289,
        "content": [
          "$$\\mathbb{R} \\backslash \\{0, 1\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4290,
        "content": [
          "$$\\mathbb{R} \\backslash \\{0\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4291,
        "content": [
          "$$\\mathbb{R} \\backslash \\{0, 1, -1\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4292,
        "content": [
          "$$\\mathbb{R} \\backslash \\{0, -1\\}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1073,
    "content": [
      "The graph of a rational function is given as in the Figure below.",
      "images/maths/year_2013_na/q48_1.png",
      "Which of the following is NOT true about the graph?"
    ],
    "explanation": [
      "The graph has:\n- A vertical asymptote at x = 1 (the function approaches $$\\pm \\infty$$ as $$x \\to 1$$)\n- A horizontal asymptote at y = 0 (the function approaches y = 0 as $$x \\to \\pm \\infty$$)\n\nChecking monotonicity:\n\n- On $$(-\\infty, 1)$$, the function is increasing.\n- On $$(1, \\infty)$$, the function is also increasing.\n\nSo the function is increasing on $$(1, \\infty)$$, not decreasing."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2013_na/q48_1.png"
    ],
    "choices": [
      {
        "id": 4293,
        "content": [
          "$$x=1$$ is its vertical asymptote."
        ],
        "isCorrect": false
      },
      {
        "id": 4294,
        "content": [
          "$$y=0$$ is its horizontal asymptote."
        ],
        "isCorrect": false
      },
      {
        "id": 4295,
        "content": [
          "It is decreasing on $$(1, \\infty)$$."
        ],
        "isCorrect": true
      },
      {
        "id": 4296,
        "content": [
          "It is increasing on $$(-\\infty, 1)$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1077,
    "content": [
      "Two statements p and q are given by:",
      "p: $$\\frac{22}{7}$$ is an irrational number.",
      "q: The sum of two odd integers is odd.",
      "Then which of the following has a truth value T?"
    ],
    "explanation": [
      "Evaluate the truth values:\n- p: $$\\frac{22}{7}$$ is not irrational → **False**\n- q: sum of two odd integers is **even** → q is **False**\n\nNow evaluate the options:\n\n- Option A: $$p \\land \\lnot q$$ = $$F \\land T$$ = $$F$$\n- Option B: $$p \\lor \\lnot q$$ = $$F \\lor T$$ = $$T$$\n- Option C: $$\\lnot p \\land q$$ = $$T \\land F$$ = $$F$$\n- Option D:  $$p \\land q$$ = $$F \\land F$$ = $$F$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4309,
        "content": [
          "$$p \\land \\lnot q$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4310,
        "content": [
          "$$p \\lor \\lnot q$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4311,
        "content": [
          "$$\\lnot p \\land q$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4312,
        "content": [
          "$$p \\land q$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1078,
    "content": [
      "Which one of the following is the contrapositive of the statement: If 21 is a prime number, then 4 is an odd number?"
    ],
    "explanation": [
      "The contrapositive of a statement $$p \\rightarrow q$$ is $$\\lnot q \\rightarrow \\lnot p$$.\n\n- Original statement: If 21 is a prime number, then 4 is an odd number.\n- Contrapositive: If 4 is **not** an odd number, then 21 is **not** a prime number."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4313,
        "content": [
          "If 4 is an odd number, then 21 is not a prime number."
        ],
        "isCorrect": false
      },
      {
        "id": 4314,
        "content": [
          "If 4 is an odd number, then 21 is a prime number."
        ],
        "isCorrect": false
      },
      {
        "id": 4315,
        "content": [
          "If 4 is not an odd number, then 21 is not a prime number."
        ],
        "isCorrect": true
      },
      {
        "id": 4316,
        "content": [
          "If 21 is not a prime number, then 4 is an even number."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1079,
    "content": [
      "Which of the following is true where c is a constant?"
    ],
    "explanation": [
      "- $$\\int \\frac{sin\\sqrt{x}}{\\sqrt{x}}dx$$ = $$-2cos\\sqrt{x} + c$$: Let u = $$\\sqrt{x}$$. Then $$du$$ = $$\\frac{1}{2\\sqrt{x}} dx$$, so $$\\int \\frac{\\sin \\sqrt{x}}{\\sqrt{x}} dx$$ = $$2 \\int \\sin u$$, $$du$$ = $$-2 \\cos u + c$$ = $$-2 \\cos \\sqrt{x}$$ + $$c$$. **True**\n- $$\\int(3x + 5)^6 dx$$ = $$\\frac{(3x+5)^7}{7}+c$$: Missing the factor $$\\frac{1}{3}$$ from the chain rule. Correct integral: $$\\frac{(3x+5)^7}{21} + c$$. **False**\n- $$\\int lnx dx$$ = $$\\frac{1}{x} + c$$: The integral of $$\\ln x$$ is $$x \\ln x - x + c$$, not $$\\frac{1}{x} + c$$. **False**\n- $$\\int xe^{x^2} dx$$ = $$\\frac{x^2}{2}e^{x^2} + c$$: The correct integral is $$\\frac{1}{2} e^{x^2}$$ + $$c$$, not $$\\frac{x^2}{2} e^{x^2} + c$$. **False**"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4317,
        "content": [
          "$$\\int \\frac{sin\\sqrt{x}}{\\sqrt{x}}dx$$ = $$-2cos\\sqrt{x} + c$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4318,
        "content": [
          "$$\\int(3x + 5)^6 dx$$ = $$\\frac{(3x+5)^7}{7}+c$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4319,
        "content": [
          "$$\\int lnx dx$$ = $$\\frac{1}{x} + c$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4320,
        "content": [
          "$$\\int xe^{x^2} dx$$ = $$\\frac{x^2}{2}e^{x^2} + c$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1080,
    "content": [
      "The acceleration of a body at any time t is given by $$a(t) = 4 - 2t + 3t^2$$ with initial velocity $$v(0) = 5.$$ Then what is the velocity $$v$$ of the body as a function of time?"
    ],
    "explanation": [
      "We integrate the acceleration function:\n$$\na(t) = 4 - 2t + 3t^2\n$$\nIntegrate to get velocity:\n$$\nv(t) = ∫(4 - 2t + 3t^2) dt = 4t - t^2 + t^3 + C\n$$\nUse initial condition $$v(0)$$ = $$5v(0)$$ = $$5$$:\n$$\nv(0) = 0 + 0 + 0 + C = 5 → C = 5\n$$\nFinal velocity function:\n$$\nv(t) = 4t - t^2 + t^3 + 5\n$$\n$$\nv(t) = 5 + 4t - t^2 + t^3\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4321,
        "content": [
          "$$v(t) = 1 + 4t - t^2 + t^3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4322,
        "content": [
          "$$v(t) = 5 + 4t - t^2 + t^3$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4323,
        "content": [
          "$$v(t) = -2 + 6t$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4324,
        "content": [
          "$$v(t) = 9 - t^2 + t^3$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1081,
    "content": [
      "Which of the following argument is valid?"
    ],
    "explanation": [
      "**Option 1:** $$p, \\lnot q \\vdash p \\implies q$$\n\n- **Invalid.** $$p \\implies q$$ is false when p is true and q is false.\n\n**Option 2:** $$\\lnot p, q \\vdash p \\implies q$$\n\n- **Valid.** $$p \\implies q$$ is true when p is false or q is true.\n\n**Option 3:** $$p, q \\vdash p \\implies \\lnot q$$\n\n- **Invalid.** $$p \\implies \\lnot q$$ is false when both p and q are true.\n\n**Option 4:** $$p, \\lnot q \\vdash p \\land q$$\n\n- **Invalid.** $$p \\land q$$ is false when q is false."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4325,
        "content": [
          "$$p, \\lnot q \\vdash p \\implies q$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4326,
        "content": [
          "$$\\lnot p, q \\vdash p \\implies q$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4327,
        "content": [
          "$$p, q \\vdash p \\implies \\lnot q$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4328,
        "content": [
          "$$p, \\lnot q \\vdash p \\land q$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1082,
    "content": [
      "Which of the following proof is more suitable to prove the assertion: $$1+2^3 + 3^3 + ... + n^3$$ = $$(1+2+3+ ... +n)^2$$?"
    ],
    "explanation": [
      "**Proof by the principle of mathematical induction** is the most suitable method to prove the assertion. It systematically verifies the statement for all natural numbers n.\n- **Base case**: Verify for n = 1\n- **Inductive step**: Assume true for n = k, then prove for n = k + 1\n\nThis method directly aligns with the structure of the given equation."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4329,
        "content": [
          "Proof by counter example."
        ],
        "isCorrect": false
      },
      {
        "id": 4330,
        "content": [
          "Proof by the principle of mathematical induction."
        ],
        "isCorrect": true
      },
      {
        "id": 4331,
        "content": [
          "Proof by contradiction."
        ],
        "isCorrect": false
      },
      {
        "id": 4332,
        "content": [
          "Proof by indirect proof."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1084,
    "content": [
      "What is the coefficient of $$x^2$$ in the binomial expansion of $$\\left(2x+\\frac{3}{x^3}\\right)^8$$ ?"
    ],
    "explanation": [
      "**Use the binomial expansion:**\n$$\nT_k = \\binom{8}{k} (2x)^{8-k} \\left(\\frac{3}{x^3}\\right)^k\n$$\n**Simplify the exponents of x**:\n$$\nx^{8 - k} \\cdot x^{-3k} = x^{8 - 4k}\n$$\n**Set the exponent of x to 2**:\n$$\n8 - 4k = 2 \\implies k = \\frac{6}{4} = 1.5\n$$\nSince k must be an integer, there is **no valid k** that satisfies this equation. The coefficient of $$x^2$$ is **0**."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4337,
        "content": [
          "6"
        ],
        "isCorrect": false
      },
      {
        "id": 4338,
        "content": [
          "0"
        ],
        "isCorrect": true
      },
      {
        "id": 4339,
        "content": [
          "576"
        ],
        "isCorrect": false
      },
      {
        "id": 4340,
        "content": [
          "500"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1087,
    "content": [
      "Which of the following series is convergent?"
    ],
    "explanation": [
      "A geometric series converges if and only if the common ratio r satisfies ∣r∣<1∣.\n\nThe series $$\\sum_{n=1}^\\infty 5^{11-2n}$$ is a geometric series. To determine its convergence, we can rewrite it in the standard geometric form $$\\sum_{n=1}^\\infty ar^{n-1}$$.\n$$\n5^{11-2n} = 5^{11} \\cdot 5^{-2n} = 5^{11} \\cdot \\left(\\frac{1}{25}\\right)^n\n$$\nThis is a geometric series with first term $$a = 5^{11} \\cdot \\left(\\frac{1}{25}\\right)^1$$ = $$\\frac{5^{11}}{25}$$ and common ratio r = $$\\frac{1}{25}$$.\n\nSince |r| < 1, the series converges."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4349,
        "content": [
          "$$\\sum_{n=1}^\\infty 5^{11-2n}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4350,
        "content": [
          "$$\\sum_{n=1}^\\infty \\left(\\frac{2}{5}\\right)^{-n}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4351,
        "content": [
          "$$\\sum_{n=1}^\\infty \\left(\\frac{3}{2}\\right)^n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4352,
        "content": [
          "$$\\sum_{n=1}^\\infty 2^{2n-5}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1088,
    "content": [
      "Let $$f$$ be a function defined on a closed bounded interval $$[a, b].$$ Which of the following describes that $$f$$ is continuous on $$[a, b]$$?"
    ],
    "explanation": [
      "A function f is continuous on a closed bounded interval $$[a, b]$$ if:\n\n- f is continuous on the open interval (a, b),\n- f is continuous from the **right** at a (i.e., $$\\lim_{x \\to a^+} f(x)$$ = $$f(a)$$), and\n- f is continuous from the **left** at b (i.e., $$\\lim_{x \\to b^-} f(x)$$ = $$f(b)$$)."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4353,
        "content": [
          "$$f$$ is continuous on $$(a, b),$$ $$f$$ is continuous from the right at $$a$$ and from the left at $$b.$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4354,
        "content": [
          "$$f$$ is continuous at each point in $$(a, b)$$ and at both $$a$$ and $$b.$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4355,
        "content": [
          "$$f$$ is continuous on $$(a, b),$$ $$f$$ is continuous from the left at $$a$$ and from the right at $$b.$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4356,
        "content": [
          "$$f$$ is continuous on $$(a, b),$$ $$f$$ is continuous from the left at $$a$$ and from the left at $$b.$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1089,
    "content": [
      "A position of a particle is given by the equation $$S(t) = 4t^4 - 4t + 1$$ where $$t$$ is measured in seconds and $$S$$ in meters. Which of the following is NOT true about the motion of the particle?"
    ],
    "explanation": [
      "**Velocity function:**\n\n- $$v(t)$$ = $$\\frac{dS}{dt}$$ = $$16t^3 - 4$$\n\n**Velocity at t = 2:**\n\n- $$v(2)$$ = $$16(2)^3 - 4$$ = $$124 \\, \\text{m/s}$$\n\n**Acceleration function:**\n\n- $$a(t)$$ = $$\\frac{dv}{dt}$$ = $$48t^2$$\n- At t = 1, $$a(1)$$ = $$48(1)^2$$ = $$48 \\, \\text{m/s}^2$$\n\n**Particle at rest:**\n\n- $$v(t)$$ = $$0$$ $$\\Rightarrow$$ 1$$6t^3 - 4$$ = $$0$\n- $$t^3$$ = $$\\frac{1}{4}$$\n- $$t \\approx 0.63 \\, \\text{s}$$\n\nSo the particle is at rest at t = 0.5 seconds is NOT true"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4357,
        "content": [
          "The velocity at 2 seconds is given by 124 m/sec."
        ],
        "isCorrect": false
      },
      {
        "id": 4358,
        "content": [
          "The velocity $$v$$ at any time $$t$$ is given by $$v(t)= 16t^3 - 4$$."
        ],
        "isCorrect": false
      },
      {
        "id": 4359,
        "content": [
          "The acceleration of the particle at 1 sec is 48 $$m/sec^2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 4360,
        "content": [
          "The particle is at rest at $$t = 0.5$$ seconds."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1090,
    "content": [
      "If $$f'(1) = 4, f(1) = 3$$ and $$g'(3) = 5,$$ then $$(g \\circ f)'(1)$$ is equal to"
    ],
    "explanation": [
      "Using the chain rule:\n$$\n(g \\circ f)'(1) = g'(f(1)) \\cdot f'(1)\n$$\nSubstitute the given values:\n$$\nf(1) = 3, \\quad f'(1) = 4, \\quad g'(3) = 5\n$$\n$$\n(g \\circ f)'(1) = g'(3) \\cdot f'(1) = 5 \\cdot 4 = 20\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4361,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 4362,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 4363,
        "content": [
          "20"
        ],
        "isCorrect": true
      },
      {
        "id": 4364,
        "content": [
          "15"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1517,
    "content": [
      "Let $$f(x)$$ = $$\\frac{x+1}{x-1}$$ and $$g(x)$$ = $$\\sqrt{x+2}$$ be two functions. Which one of the following is true about the combination values of $$f$$ and $$g$$ at $$x=2$$?"
    ],
    "explanation": [
      "To find the correct combination value, first evaluate $$f(2)$$ and $$g(2)$$.\n$$\nf(2) = \\frac{2+1}{2-1} = \\frac{3}{1} = 3\n$$\n$$\ng(2) = \\sqrt{2+2} = \\sqrt{4} = 2\n$$\nNow, evaluate the combination $$(f \\cdot g)(2)$$ which means $$f(2) \\times g(2)$$.\n$$\n(f \\cdot g)(2) = f(2) \\times g(2) = 3 \\times 2 = 6\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6069,
        "content": [
          "$$(f.g)(2)$$ = $$6$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6070,
        "content": [
          "$$(\\frac{f}{g})(2)$$ = $$\\frac{2}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6071,
        "content": [
          "$$(f+g)(2)$$ = $$3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6072,
        "content": [
          "$$(f-g)(2)$$ = $$-1$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1518,
    "content": [
      "Which one of the following defines an exponential function?"
    ],
    "explanation": [
      "An exponential function is defined by the form $$f(x) = b^x$$, where the base $$b$$ is a positive constant ($$b > 0$$) and not equal to $$1$$ ($$b \\neq 1$$), and the variable $$x$$ is the exponent.\n\nThe domain of an exponential function is all real numbers ($$\\mathbb{R}$$), and the range is all positive real numbers ($$(0, \\infty)$$).\n\n- $$f: \\mathbb{R} \\rightarrow (0, \\infty)$$ defined by $$f(x) = b^x$$, where $$b > 0$$ and $$b \\neq 1$$.\n    - This Option correctly states this definition, including the form of the function, the domain, the range, and the conditions on the base $$b$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6073,
        "content": [
          "$$f: \\mathbb{R} \\rightarrow (0, \\infty)$$ defined by $$f(x) = b^x$$, where $$b > 0$$ and $$b \\neq 1$$."
        ],
        "isCorrect": true
      },
      {
        "id": 6074,
        "content": [
          "$$f: \\mathbb{R} \\rightarrow (0, \\infty)$$ defined by $$f(x) = x^b$$, where $$b > 0$$ and $$b \\neq 1$$."
        ],
        "isCorrect": false
      },
      {
        "id": 6075,
        "content": [
          "$$f: (0, \\infty) \\rightarrow \\mathbb{R}$$ defined by $$f(x) = b^x$$, where $$b > 0$$ and $$b \\neq 1$$."
        ],
        "isCorrect": false
      },
      {
        "id": 6076,
        "content": [
          "$$f: (0, \\infty) \\rightarrow \\mathbb{R}$$ defined by $$f(x) = x^b$$, where $$b > 0$$ and $$b \\neq 1$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Polynomial Function"
  },
  {
    "id": 1519,
    "content": [
      "Let f be differentiable function at a number 'a' for a $$\\in$$ Domain f. In the expression $$\\frac{f(a+h)-f(a)}{h}$$ for $$h \\neq 0$$, as h gets closer and closer to zero from both directions, the expression becomes closer to f'(a) which is equal to"
    ],
    "explanation": [
      "The expression $$\\frac{f(a+h)-f(a)}{h}$$ represents the slope of the secant line through the points (a, f(a)) and (a+h, f(a+h)) on the graph of f.\n\nThe derivative $$f'(a)$$ is defined as the limit of this expression as $$h$$ approaches 0:\n$$\nf'(a) = \\lim_{h \\to 0} \\frac{f(a+h)-f(a)}{h}\n$$\nGeometrically, this limit represents the slope (or gradient) of the tangent line to the graph of f at the point (a, f(a)). Therefore, $$f'(a)$$ is equal to the gradient of the tangent line."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6077,
        "content": [
          "The gradient of the normal line to the graph of f at a point (a, f(a))."
        ],
        "isCorrect": false
      },
      {
        "id": 6078,
        "content": [
          "The gradient of the vertical line to the graph of f at a point (a, f(a))."
        ],
        "isCorrect": false
      },
      {
        "id": 6079,
        "content": [
          "The gradient of the secant line to the graph of f at a point (a, f(a))."
        ],
        "isCorrect": false
      },
      {
        "id": 6080,
        "content": [
          "The gradient of the tangent line to the graph of f at a point (a, f(a))."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1521,
    "content": [
      "Let p and q be propositions. Which one of the following propositions is a tautology?"
    ],
    "explanation": [
      "A tautology is a logical proposition that is true for all possible truth values of its constituent propositions.\n- $$(p \\land q) \\implies (p \\lor q)$$.\n    - An implication $$A \\implies B$$ is false only when A is true and B is false. Here, A is $$(p \\land q)$$ and B is $$(p \\lor q)$$.\n    - If A ($$p \\land q$$) is true, it means both p and q are true. If both p and q are true, then B ($$p \\lor q$$) must also be true.\n    - So, we have the case $$T \\implies T$$, which is true.\n    - If A ($$p \\land q$$) is false, then the implication $$A \\implies B$$ is automatically true, regardless of the truth value of B.\n    - Since the implication $$(p \\land q) \\implies (p \\lor q)$$ is true in all cases, it is a tautology."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6085,
        "content": [
          "$$(p \\implies \\neg q) \\iff (p \\land q)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6086,
        "content": [
          "$$(\\neg p \\implies q) \\iff (p \\land q)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6087,
        "content": [
          "$$(p \\land q) \\implies (p \\lor q)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6088,
        "content": [
          "$$(p \\lor q) \\implies (p \\land q)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1524,
    "content": [
      "Consider the following graph of a given exponential function f(x).",
      "images/maths/year_2016_na/q8_1.png",
      "Which one of the following functions represents the graph shown above?"
    ],
    "explanation": [
      "The graph passes through several key points, including (0, -1), (1, 0), and (2, 2). We can test these points in the given options.\n- For option $$f(x) = 2^x - 2$$:\n    - When $$x=0$$, $$f(0)$$ = $$2^0 - 2$$ = $$1 - 2$$ = $$-1$$. Matches point (0, -1).\n    - When $$x=1$$, $$f(1)$$ = $$2^1 - 2$$ = $$2 - 2$$ = $$0$$. Matches point (1, 0).\n    - When $$x=2$$, $$f(2)$$ = $$2^2 - 2$$ = $$4 - 2$$ = $$2$$. Matches point (2, 2).\n- Since all tested points lie on the graph of $$f(x)$$ = $$2^x - 2$$, this function represents the given graph."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2016_na/q8_1.png"
    ],
    "choices": [
      {
        "id": 6097,
        "content": [
          "$$f(x)=(2)^{x-2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6098,
        "content": [
          "$$f(x)=(\\frac{1}{2})^{x-2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6099,
        "content": [
          "$$f(x)=(2)^{x}-2$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6100,
        "content": [
          "$$f(x)=(\\frac{1}{2})^{x}-2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Polynomial Function"
  },
  {
    "id": 1527,
    "content": [
      "Which one of the following is true about the integral of a function f(x) with respect to a variable x?"
    ],
    "explanation": [
      "The indefinite integral of a function $$f(x)$$, denoted by $$\\int f(x)dx$$, represents the family of all functions whose derivative is $$f(x)$$.\n\nThese functions are called the antiderivatives of $$f(x)$$.\n\nFor example, if $$F'(x)$$ = $$f(x)$$, then $$\\int f(x)dx$$ = $$F(x) + C$$, where C is the constant of integration, representing the set of all antiderivatives."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6109,
        "content": [
          "$$\\int f'(x)dx$$ is the set of all anti-derivatives of f."
        ],
        "isCorrect": false
      },
      {
        "id": 6110,
        "content": [
          "$$\\int f'(x)dx$$ is the set of all derivatives of f."
        ],
        "isCorrect": false
      },
      {
        "id": 6111,
        "content": [
          "$$\\int f(x)dx$$ is the set of all anti-derivatives of f."
        ],
        "isCorrect": true
      },
      {
        "id": 6112,
        "content": [
          "$$\\int f(x)dx$$ is the set of all derivatives of f."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1532,
    "content": [
      "Let p and q be proposition with truth values true and false respectively. Which one of the following statements is NOT correct?"
    ],
    "explanation": [
      "We are given p is True and q is False.\n\nLet's evaluate the truth value of the inner logical expressions and then check if the overall statement is correct.\n- $$p \\implies q$$ is $$T \\implies F$$, which is False. The statement says \"$$p \\implies q$$ is false\", which is a correct statement.\n- $$p \\iff q$$ is $$T \\iff F$$, which is False. The statement says \"$$p \\iff q$$ is true\", which is an incorrect statement.\n- $$p \\land q$$ is $$T \\land F$$, which is False. The statement says \"$$p \\land q$$ is false\", which is a correct statement.\n- $$p \\lor q$$ is $$T \\lor F$$, which is True. The statement says \"$$p \\lor q$$ is true\", which is a correct statement.\n\nThe question asks which statement is NOT correct. The statement in second bullet point is not correct because $$p \\iff q$$ is actually false."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6129,
        "content": [
          "$$p \\implies q$$ is false."
        ],
        "isCorrect": false
      },
      {
        "id": 6130,
        "content": [
          "$$p \\iff q$$ is true."
        ],
        "isCorrect": true
      },
      {
        "id": 6131,
        "content": [
          "$$p \\land q$$ is false."
        ],
        "isCorrect": false
      },
      {
        "id": 6132,
        "content": [
          "$$p \\lor q$$ is true."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1533,
    "content": [
      "Which one of the following is equal to the sum $$\\sum_{n=1}^{5} 2n^2$$?"
    ],
    "explanation": [
      "The sum $$\\sum_{n=1}^{5} 2n^2$$ requires evaluating the term $$2n^2$$ for each integer $$n$$ from 1 to 5 and adding the results.\n- For $$n=1$$: $$2(1^2)$$ = $$2(1)$$ = $$2$$\n- For $$n=2$$: $$2(2^2)$$ = $$2(4)$$ = $$8$$\n- For $$n=3$$: $$2(3^2)$$ = $$2(9)$$ = $$18$$\n- For $$n=4$$: $$2(4^2)$$ = $$2(16)$$ = $$32$$\n- For $$n=5$$: $$2(5^2)$$ = $$2(25)$$ = $$50$$\n\nThe sum is 2 + 8 + 18 + 32 + 50"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6133,
        "content": [
          "2 + 8 + 16 + 32 + 64"
        ],
        "isCorrect": false
      },
      {
        "id": 6134,
        "content": [
          "2 + 4 + 8 + 16 + 32"
        ],
        "isCorrect": false
      },
      {
        "id": 6135,
        "content": [
          "2 + 4 + 6 + 8 + 10"
        ],
        "isCorrect": false
      },
      {
        "id": 6136,
        "content": [
          "2 + 8 + 18 + 32 + 50"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1535,
    "content": [
      "Let S, R and T be any three sets. Which one of the following is NOT true about the union of the sets?"
    ],
    "explanation": [
      "Let's evaluate the truth of each statement based on the properties of set union.\n- $$(S \\cup R) \\cup T$$ = $$T \\cup (R \\cup S)$$.\n    - The union operation is associative ($$A \\cup (B \\cup C)$$ = $$(A \\cup B) \\cup C$$) and commutative ($$A \\cup B$$ = $$B \\cup A$$). $$(S \\cup R) \\cup T$$ = $$S \\cup R \\cup T$$. $$T \\cup (R \\cup S)$$ = $$T \\cup (S \\cup R)$$ = $$T \\cup S \\cup R$$. Since the order doesn't matter for union, $$S \\cup R \\cup T$$ = $$T \\cup S \\cup R$$. So, statement A is true.\n- $$S \\cup S$$ = $$S$$.\n    - This is the idempotent law for union. It is always true.\n- $$S \\cup R$$ = $$R \\cup S$$.\n    - This is the commutative law for union. It is always true.\n- $$S \\cup T$$ = $$T$$.\n    - This statement is true only if S is a subset of T ($$S \\subseteq T$$). It is not true for any arbitrary sets S and T. For example, if $$S=\\{1,2\\}$$ and $$T=\\{2,3\\}$$, then $$S \\cup T$$ = $$\\{1,2,3\\} \\neq T$$. Therefore, statement D is NOT always true."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SETS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6141,
        "content": [
          "$$(S \\cup R) \\cup T$$ = $$T \\cup (R \\cup S)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6142,
        "content": [
          "$$S \\cup S$$ = $$S$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6143,
        "content": [
          "$$S \\cup R$$ = $$R \\cup S$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6144,
        "content": [
          "$$S \\cup T$$ = $$T$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1539,
    "content": [
      "Which one of the following is equal to the sum $$\\sum_{k=1}^{7} 729(3^{1-k})$$?"
    ],
    "explanation": [
      "The sum is a geometric series.\n\nLet the $$k^{th}$$ term be $$a_k$$ = $$729(3^{1-k})$$\n\nWe can rewrite this as $$a_k$$ = $$729 \\cdot 3^1 \\cdot 3^{-k}$$ = $$2187 \\cdot (\\frac{1}{3})^k$$.\n\nThe first term (for k=1) is $$a_1$$ = $$2187 \\cdot (\\frac{1}{3})^1$$ = $$729$$.\n\nThe common ratio is $$r$$ = $$\\frac{a_{k+1}}{a_k}$$ = $$\\frac{2187 (\\frac{1}{3})^{k+1}}{2187 (\\frac{1}{3})^k}$$ = $$\\frac{1}{3}$$.\n\nThe number of terms is $$n=7$$.\n\nThe sum of the first n terms of a geometric series is given by\n$$\nS_n = \\frac{a_1(1-r^n)}{1-r}\n$$\n$$\nS_7 = \\frac{729(1 - (\\frac{1}{3})^7)}{1 - \\frac{1}{3}}\n$$\n$$\nS_7 = \\frac{729(\\frac{2187-1}{2187})}{\\frac{2}{3}}\n$$\n$$\nS_7 =  \\frac{729(\\frac{2186}{2187})}{\\frac{2}{3}}\n$$\nSince $$2187$$ = $$3^7$$ and $$729$$ = $$3^6$$, we have $$\\frac{729}{2187}$$ = $$\\frac{1}{3}$$.\n$$\nS_7 = \\frac{\\frac{1}{3} \\times 2186}{\\frac{2}{3}}\n$$\n$$\nS_7 = \\frac{2186}{3} \\times \\frac{3}{2} = 1093\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6157,
        "content": [
          "1088"
        ],
        "isCorrect": false
      },
      {
        "id": 6158,
        "content": [
          "1079"
        ],
        "isCorrect": false
      },
      {
        "id": 6159,
        "content": [
          "1093"
        ],
        "isCorrect": true
      },
      {
        "id": 6160,
        "content": [
          "1092"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1541,
    "content": [
      "Which one of the following numbers is a common multiple of 324 and 1152?"
    ],
    "explanation": [
      "To find a common multiple, we can find the Least Common Multiple (LCM). \n\nFirst, find the prime factorization of each number:\n$$\n324 = 2^2 \\times 3^4\n$$\n$$\n1152 = 2^7 \\times 3^2\n$$\nThe LCM is found by taking the highest power of each prime factor present in either factorization:\n$$\nLCM(324, 1152) = 2^{\\max(2, 7)} \\times 3^{\\max(4, 2)} = 2^7 \\times 3^4= 10368\n$$\nAny common multiple must be a multiple of the LCM. We check the options:\n- 13824 / 10368 = 1.33... (Not a multiple)\n- 20736 / 10368 = 2 (This is a multiple)\n- 5184 / 10368 = 0.5 (Not a multiple)\n- 7776 / 10368 = 0.75 (Not a multiple)\n\nTherefore, 20736 is a common multiple."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_NUMBER_SYSTEM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6165,
        "content": [
          "13824"
        ],
        "isCorrect": false
      },
      {
        "id": 6166,
        "content": [
          "20736"
        ],
        "isCorrect": true
      },
      {
        "id": 6167,
        "content": [
          "5184"
        ],
        "isCorrect": false
      },
      {
        "id": 6168,
        "content": [
          "7776"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "The Number System"
  },
  {
    "id": 1546,
    "content": [
      "What is the area of the region bounded by the graph of $$f(x) = x^3$$ and the x-axis on the interval [-4, 2]?"
    ],
    "explanation": [
      "The area is calculated by integrating the absolute value of the function over the interval. Since $$f(x)=x^3$$ is negative for $$x<0$$ and positive for $$x>0$$, we split the integral:\n\nArea = $$\\int_{-4}^{2} |x^3| dx$$ = $$\\int_{-4}^{0} |x^3| dx$$ + $$\\int_{0}^{2} |x^3| dx$$\n\nArea = $$\\int_{-4}^{0} (-x^3) dx$$ + $$\\int_{0}^{2} x^3 dx$$\n\nArea = $$[-\\frac{x^4}{4}]{-4}^{0}$$ + $$[\\frac{x^4}{4}]{0}^{2}$$\n\nArea = $$(-\\frac{0^4}{4}$$ $$-$$ $$(-\\frac{(-4)^4}{4}))$$ + $$(\\frac{2^4}{4}$$ $$-$$ $$\\frac{0^4}{4})$$\n\nArea = $$-(0 - \\frac{256}{4})$$ + $$(\\frac{16}{4} - 0)$$\n\nArea = $$-(-\\frac{256}{4})$$ + $$\\frac{16}{4}$$ = $$68 \\ \\text{square units}$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6185,
        "content": [
          "120 Square units"
        ],
        "isCorrect": false
      },
      {
        "id": 6186,
        "content": [
          "136 Square units"
        ],
        "isCorrect": false
      },
      {
        "id": 6187,
        "content": [
          "60 Square units"
        ],
        "isCorrect": false
      },
      {
        "id": 6188,
        "content": [
          "68 Square units"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1547,
    "content": [
      "If $$a$$ = $$2 - 3\\sqrt{5}$$ and $$b$$ = $$3 + 2\\sqrt{5}$$, then which one of the following is true?"
    ],
    "explanation": [
      "Let's evaluate each option:\n- Option 1: $$ab$$ = $$36$$ (false)\n\n$$\nab = (2 - 3\\sqrt{5})(3 + 2\\sqrt{5})\n$$\n\n$$\n= 6 + 4\\sqrt{5} - 9\\sqrt{5} - 30\n$$\n$$\n= -24 - 5\\sqrt{5} \\neq 36\n$$\n\n- Option 2: $$11a \\div b$$ = $$-36 + 13\\sqrt{5}$$ (true)\n\n$$\n\\frac{11a}{b} = \\frac{11(2 - 3\\sqrt{5})}{3 + 2\\sqrt{5}} \\cdot \\frac{3 - 2\\sqrt{5}}{3 - 2\\sqrt{5}}\n$$\n$$\n= \\frac{11(6 - 4\\sqrt{5} - 9\\sqrt{5} + 30)}{9 - 20}\n$$\n$$\n= \\frac{11(36 - 13\\sqrt{5})}{-11}\n$$\n$$\n11a \\div b = -36 + 13\\sqrt{5}\n$$\n\n- Option 3: $$a + b$$ = $$5$$ (false)\n\n$$\na + b = (2 - 3\\sqrt{5}) + (3 + 2\\sqrt{5})\n$$\n$$\n= 5 - \\sqrt{5} \\neq 5\n$$\n\n- Option 4: $$a - b$$ = $$-1 - \\sqrt{5}$$ (false)\n\n$$\na - b = (2 - 3\\sqrt{5}) - (3 + 2\\sqrt{5})\n$$\n$$\n= -1 - 5\\sqrt{5} \\neq -1 - \\sqrt{5}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_NUMBER_SYSTEM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6189,
        "content": [
          "$$ab$$ = $$36$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6190,
        "content": [
          "$$11a \\div b$$ = $$-36 + 13\\sqrt{5}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6191,
        "content": [
          "$$a + b$$ = $$5$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6192,
        "content": [
          "$$a - b = -1 - \\sqrt{5}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "The Number System"
  },
  {
    "id": 1551,
    "content": [
      "Which one of the following numbers is the coefficient of $$x^6y^4$$ in the expansion of $$(x+y)^{10}$$?"
    ],
    "explanation": [
      "According to the Binomial Theorem, the term containing $$x^{n-k}y^k$$ in the expansion of $$(x+y)^n$$ is given by\n$$\n\\binom{n}{k}x^{n-k}y^k\n$$\nIn this case, n = 10. We are looking for the coefficient of the term $$x^6y^4$$.\n\nHere, k=4 (the power of y) and n - k = 10 - 4 = 6 (the power of x).\n\nThe coefficient is\n$$\n\\binom{n}{k} = \\binom{10}{4}\n$$\nCalculating the binomial coefficient:\n$$\n\\binom{10}{4} = \\frac{10!}{4!(10-4)!}\n$$\n$$\n= \\frac{10!}{4!6!}\n$$\n$$\n= \\frac{10 \\times 9 \\times 8 \\times 7}{4 \\times 3 \\times 2 \\times 1}\n$$\n$$\n= \\frac{5040}{24} = 210\n$$\nThus, the coefficient of $$x^6y^4$$ is 210."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6205,
        "content": [
          "4860"
        ],
        "isCorrect": false
      },
      {
        "id": 6206,
        "content": [
          "1260"
        ],
        "isCorrect": false
      },
      {
        "id": 6207,
        "content": [
          "210"
        ],
        "isCorrect": true
      },
      {
        "id": 6208,
        "content": [
          "240"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1553,
    "content": [
      "Which one of the following is equal to the expression\n$$\n\\frac{(125)^{\\frac{2}{3}} (81)^{-\\frac{3}{4}}}{(27)^{-\\frac{2}{3}} (625)^{\\frac{3}{4}}} \\ \\text{?}\n$$"
    ],
    "explanation": [
      "Rewrite the bases as powers of prime numbers: $$125$$ = $$5^3$$, $$81$$ = $$3^4$$, $$27$$ = $$3^3$$, $$625$$ = $$5^4$$.\n\nSubstitute these into the expression:\n$$\n\\frac{((5^3))^{\\frac{2}{3}} ((3^4))^{-\\frac{3}{4}}}{((3^3))^{-\\frac{2}{3}} ((5^4))^{\\frac{3}{4}}}\n$$\nApply the power rule $$(a^m)^n$$ = $$a^{mn}$$:\n$$\n\\frac{5^{3 \\times \\frac{2}{3}} 3^{4 \\times (-\\frac{3}{4})}}{3^{3 \\times (-\\frac{2}{3})} 5^{4 \\times \\frac{3}{4}}} = \\frac{5^2 \\cdot 3^{-3}}{3^{-2} \\cdot 5^3}\n$$\nApply exponent rules $$\\frac{a^m}{a^n}$$ = $$a^{m-n}$$ and $$a^{-p}$$ = $$\\frac{1}{a^p}$$:\n$$\n5^{2-3} \\cdot 3^{-3 - (-2)}\n$$\n$$\n5^{-1} \\cdot 3^{-1}\n$$\n$$\n(5 \\cdot 3)^{-1} = 15^{-1} = \\frac{1}{15}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_NUMBER_SYSTEM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6213,
        "content": [
          "$$\\frac{1}{15}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6214,
        "content": [
          "$$15$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6215,
        "content": [
          "$$\\frac{3}{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6216,
        "content": [
          "$$\\frac{5}{3}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "The Number System"
  },
  {
    "id": 1556,
    "content": [
      "Which one of the following is an onto function from $$\\mathbb{R}$$ onto $$\\mathbb{R}$$?"
    ],
    "explanation": [
      "An onto (surjective) function from $$\\mathbb{R}$$ to $$\\mathbb{R}$$ must have its range equal to $$\\mathbb{R}$$. Let's examine the ranges of the given functions:\n- $$f(x)$$ = $$-3x^2 + 2x$$ is a quadratic function representing a downward-opening parabola. Its range is limited to $$(-\\infty, y_{max}]$$ and is not $$\\mathbb{R}$$.\n- $$f(x)$$ = $$5x^3 + 1$$ is a cubic function. As $$x$$ takes all real values from $$-\\infty$$ to $$+\\infty$$, $$x^3$$ also takes all real values. Therefore, $$5x^3+1$$ covers all real numbers. Its range is $$\\mathbb{R}$$, so it is onto.\n- $$f(x)$$ = $$|x - 1|$$ is an absolute value function. Its range is $$[0, \\infty)$$, which is not $$\\mathbb{R}$$.\n- $$f(x)$$ = $$\\sqrt{x^2+1}$$. Since $$x^2 \\ge 0$$, $$x^2+1 \\ge 1$$. Thus, $$\\sqrt{x^2+1} \\ge 1$$. Its range is $$[1, \\infty)$$, which is not $$\\mathbb{R}$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6225,
        "content": [
          "$$f(x)$$ = $$2x - 3x^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6226,
        "content": [
          "$$f(x)$$ = $$5x^3 + 1$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6227,
        "content": [
          "$$f(x)$$ = $$|x - 1|$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6228,
        "content": [
          "$$f(x)$$ = $$\\sqrt{x^2+1}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Polynomial Function"
  },
  {
    "id": 1562,
    "content": [
      "Which one of the following is the range of the function $$f(x)$$ = $$\\frac{2x-1}{x+3}$$?"
    ],
    "explanation": [
      "To find the range of the rational function $$f(x)$$ = $$\\frac{2x-1}{x+3}$$, we look for the horizontal asymptote.\n\nSince the degree of the numerator (1) is equal to the degree of the denominator (1), the horizontal asymptote is given by the ratio of the leading coefficients, which is $$y$$ = $$\\frac{2}{1}$$ = $$2$$.\n\nThe function can take any real value except the value of the horizontal asymptote. Therefore, the range is all real numbers except 2, which is written as $$\\mathbb{R} \\setminus \\{2\\}$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6249,
        "content": [
          "$$\\mathbb{R} \\setminus \\{-3\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6250,
        "content": [
          "$$\\mathbb{R} \\setminus \\{2\\}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6251,
        "content": [
          "$$\\mathbb{R} \\setminus \\{-\\frac{1}{3}\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6252,
        "content": [
          "$$\\mathbb{R} \\setminus \\{\\frac{1}{2}\\}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1563,
    "content": [
      "Let $$z=-a+2i$$ and $$w=5-bi$$ be two complex numbers, where a and b are real numbers. If $$z=w$$, then which one of the following pairs of numbers are equal to a and b respectively?"
    ],
    "explanation": [
      "For two complex numbers to be equal, their real parts must be equal and their imaginary parts must be equal.\n\nGiven $$z = -a + 2i$$ and $$w = 5 - bi$$.\n\nEquating the real parts: $$-a = 5$$ $$\\implies$$ $$a = -5$$.\n\nEquating the imaginary parts: $$2 = -b$$ $$\\implies$$ $$b = -2$$.\n\nTherefore, a = -5 and b = -2."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6253,
        "content": [
          "5 and -2"
        ],
        "isCorrect": false
      },
      {
        "id": 6254,
        "content": [
          "-5 and -2"
        ],
        "isCorrect": true
      },
      {
        "id": 6255,
        "content": [
          "5 and 2"
        ],
        "isCorrect": false
      },
      {
        "id": 6256,
        "content": [
          "-5 and 2"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1568,
    "content": [
      "Which one of the following pairs of functions is an inverse of each other in their respective domains?"
    ],
    "explanation": [
      "To check if two functions f and g are inverses, we can find the inverse of f, denoted $$f^{-1}$$, and see if it equals g. Let $$y = f(x)$$. To find the inverse, swap x and y and solve for y.\n$$\ny = x^3-1\n$$\nSwap x and y:\n$$\nx = y^3-1\n$$\nSolve for y:\n$$\nx+1 = y^3 \\implies y = \\sqrt[3]{x+1}\n$$\nSo, $$f^{-1}(x)$$ = $$\\sqrt[3]{x+1}$$\n\nThis is equal to the given $$g(x)$$. Therefore, f and g are inverses of each other."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6273,
        "content": [
          "$$f(x)$$ = $$\\sqrt{x+3}$$ and $$g(x)$$ = $$x^2-9$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6274,
        "content": [
          "$$f(x)$$ = $$x^5$$ and $$g(x)$$ = $$\\frac{1}{x^5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6275,
        "content": [
          "$$f(x)$$ = $$x^3-1$$ and $$g(x)$$ = $$\\sqrt[3]{x+1}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6276,
        "content": [
          "$$f(x)$$ = $$\\frac{x+1}{x-1}$$ and $$g(x)$$ = $$\\frac{x-1}{x+1}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1571,
    "content": [
      "Let A and B be two sets that contain 15 and 17 elements respectively. If $$A \\cap B$$ contains 10 elements, what is the number of elements in $$A \\cup B$$?"
    ],
    "explanation": [
      "We use the principle of inclusion-exclusion for two sets:\n$$\n|A \\cup B| = |A| + |B| - |A \\cap B|\n$$\nGiven $$|A| = 15$$, $$|B| = 17$$, and $$|A \\cap B| = 10$$\n$$\n|A \\cup B| = 15 + 17 - 10 = 32 - 10 = 22\n$$\nSo, the number of elements in $$A \\cup B$$ is 22"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SETS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6285,
        "content": [
          "22"
        ],
        "isCorrect": true
      },
      {
        "id": 6286,
        "content": [
          "12"
        ],
        "isCorrect": false
      },
      {
        "id": 6287,
        "content": [
          "42"
        ],
        "isCorrect": false
      },
      {
        "id": 6288,
        "content": [
          "32"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1575,
    "content": [
      "If the fifth and the tenth terms of a geometric sequence are 640 and 20 respectively, then which of the following numbers are the first term and the common ratio of the given geometric sequence respectively?"
    ],
    "explanation": [
      "Let the first term be $$a_1$$ and the common ratio be $$r$$. The $$n^{th}$$ term of a geometric sequence is given by\n$$\na_n = a_1 r^{n-1}\n$$\nWe are given $$a_5$$ = $$640$$ and $$a_{10}$$ = $$20$$.\n$$\na_5 = a_1 r^{5-1} = a_1 r^4 = 640\n$$\n$$\na_{10} = a_1 r^{10-1} = a_1 r^9 = 20\n$$\nDivide the second equation by the first:\n$$\n\\frac{a_1 r^9}{a_1 r^4} = \\frac{20}{640}\n$$\n$$\nr^5 = \\frac{20}{640} = \\frac{1}{32}\n$$\nSince $$32$$ = $$2^5$$, we have $$r^5$$ = $$(\\frac{1}{2})^5$$. Therefore, the common ratio $$r$$ = $$\\frac{1}{2}$$.\n\nSubstitute $$r$$ = $$\\frac{1}{2}$$ into the equation for $$a_5$$:\n$$\na_1 (\\frac{1}{2})^4 = 640\n$$\n$$\na_1 (\\frac{1}{16}) = 640\n$$\n$$\na_1 = 640 \\times 16 = 10240\n$$\nThe first term is 10240 and the common ratio is $$\\frac{1}{2}$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6301,
        "content": [
          "1024 and 2"
        ],
        "isCorrect": false
      },
      {
        "id": 6302,
        "content": [
          "1024 and $$\\frac{1}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6303,
        "content": [
          "10240 and 2"
        ],
        "isCorrect": false
      },
      {
        "id": 6304,
        "content": [
          "10240 and $$\\frac{1}{2}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1762,
    "content": [
      "When the polynomial $$p(x)$$ = $$3x^6$$ + $$5x^4$$ - $$7x^3$$ + $$2kx^2$$ + $$3$$ is divided by $$x + 1$$ the remainder is 4. What is the value of k?"
    ],
    "explanation": [
      "According to the Remainder Theorem, when a polynomial $$p(x)$$ is divided by $$(x - a)$$, the remainder is $$p(a)$$.\n\nIn this case, the divisor is $$x + 1$$ = $$x - (-1)$$, so $$a = -1$$. We are given that the remainder is 4. Therefore, $$p(-1) = 4$$.\n\nSubstitute $$x = -1$$ into the polynomial:\n$$\np(-1) = 3(-1)^6 + 5(-1)^4 - 7(-1)^3 + 2k(-1)^2 + 3\n$$\n$$\np(-1) = 18 + 2k\n$$\nSince the remainder is 4, we set $$p(-1) = 4$$:\n$$\n18 + 2k = 4\n$$\n$$\nk = -7\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7049,
        "content": [
          "-5"
        ],
        "isCorrect": false
      },
      {
        "id": 7050,
        "content": [
          "-7"
        ],
        "isCorrect": true
      },
      {
        "id": 7051,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 7052,
        "content": [
          "6"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Polynomial Function"
  },
  {
    "id": 1764,
    "content": [
      "Which of the following statement is true about $$f(x)$$ = $$x^2$$ - $$6x$$ + $$10$$?"
    ],
    "explanation": [
      "The function $$f(x)$$ = $$x^2$$ - $$6x$$ + $$10$$ is a quadratic function $$ax^2$$ + $$bx$$ + $$c$$ with $$a=1$$, $$b=-6$$, $$c=10$$.\n\nSince $$a=1 > 0$$, the parabola opens upward (eliminating C).\n\nThe axis of symmetry is given by the line $$x$$ = $$-\\frac{b}{2a}$$.\n$$\nx = -\\frac{-6}{2(1)} = \\frac{6}{2} = 3\n$$\nSo the axis of symmetry is $$x=3$$ (eliminating B).\n\nThe vertex occurs at the axis of symmetry. The y-coordinate of the vertex is $$f(3)$$.\n$$\nf(3) = (3)^2 - 6(3) + 10 = 1\n$$\nSo the vertex is (3, 1). This confirms D is true.\n\nSince the minimum value of the function is the y-coordinate of the vertex (which is 1), we have $$f(x) \\ge 1$$ for all x. Statement A, $$f(x) \\ge 2$$, is false because the minimum value is 1."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7057,
        "content": [
          "$$f(x) \\ge 2$$ for all x in the domain of f."
        ],
        "isCorrect": false
      },
      {
        "id": 7058,
        "content": [
          "The line $$x = 1$$ is the axis of symmetry of the graph of f."
        ],
        "isCorrect": false
      },
      {
        "id": 7059,
        "content": [
          "The graph of f opens downward."
        ],
        "isCorrect": false
      },
      {
        "id": 7060,
        "content": [
          "The vertex of the graph of f is (3, 1)."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Polynomial Function"
  },
  {
    "id": 1766,
    "content": [
      "Which of the following defines a prime number?"
    ],
    "explanation": [
      "A prime number is defined as a natural number greater than 1 that has exactly two distinct positive divisors: 1 and itself."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_NUMBER_SYSTEM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7065,
        "content": [
          "It is a number that has more than two positive factors."
        ],
        "isCorrect": false
      },
      {
        "id": 7066,
        "content": [
          "It is a number whose only factor is 1."
        ],
        "isCorrect": false
      },
      {
        "id": 7067,
        "content": [
          "It is a number that has only two positive factors."
        ],
        "isCorrect": true
      },
      {
        "id": 7068,
        "content": [
          "It is a number whose only factor is itself."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "The Number System"
  },
  {
    "id": 1767,
    "content": [
      "Which of the following rational numbers is written in its standard form?"
    ],
    "explanation": [
      "Standard form (or scientific notation) requires a number to be written as $$a \\times 10^n$$, where $$1 \\le |a| < 10$$ and n is an integer.\n\n5 is greater than or equal to 1 and less than 10. Thus, $$5 \\times 10^5$$ is in standard form."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_NUMBER_SYSTEM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7069,
        "content": [
          "$$10.1 \\times 10^{-2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7070,
        "content": [
          "$$0.8 \\times 10^{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7071,
        "content": [
          "$$0.09 \\times 10^{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7072,
        "content": [
          "$$5 \\times 10^{5}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "The Number System"
  },
  {
    "id": 1770,
    "content": [
      "Given $$A$$ = $$\\{x \\in \\mathbb{N}: x < 3\\}$$ and B is the set of all possible factors of 13. Then which one of the following is equal to $$B \\times A$$?"
    ],
    "explanation": [
      "First, determine the elements of sets A and B.\n\nSet A contains natural numbers less than 3. $$\\mathbb{N} = \\{1, 2, 3, ...\\}$$, $$A = \\{1, 2\\}$$.\n\nSet B contains all factors of 13. Since 13 is prime, its factors are 1 and 13. $$B = \\{1, 13\\}$$.\n\nThe Cartesian product $$B \\times A$$ is the set of all ordered pairs $$(b, a)$$ where $$b \\in B$$ and $$a \\in A$$.\n$$\nB \\times A = \\{(1, 1), (1, 2), (13, 1), (13, 2)\\}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SETS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7081,
        "content": [
          "$$\n\\{(1, 1), (2, 1), (1, 13), (2, 13)\\}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7082,
        "content": [
          "$$\n\\{(1, 1), (1, 2), (13, 1), (13, 2)\\}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7083,
        "content": [
          "$$\n\\{(1, 1), (13, 2)\\}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7084,
        "content": [
          "$$\n\\{(1, 2), (13, 1), (13, 2)\\}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1772,
    "content": [
      "The domain of the function $$f(x) = 2x^{\\frac{2}{3}}$$"
    ],
    "explanation": [
      "The function is $$f(x) = 2x^{2/3}$$, which can be rewritten as $$f(x) = 2 \\sqrt[3]{x^2}$$.\n\nTo find the domain, we identify values of x for which the function is defined. The expression $$x^2$$ is defined for all real numbers x.\n\nThe cube root function, $$\\sqrt[3]{y}$$, is defined for all real numbers y (including negative numbers, zero, and positive numbers).\n\nSince $$x^2$$ produces non-negative results, and the cube root is defined for all real numbers, the function $$f(x)$$ is defined for all real numbers x. Therefore, the domain is $$\\mathbb{R}$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7089,
        "content": [
          "$$\\mathbb{R}\\setminus\\{0\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7090,
        "content": [
          "$$[0, \\infty)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7091,
        "content": [
          "$$\\mathbb{R}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7092,
        "content": [
          "$$(0, 2)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1780,
    "content": [
      "On the set of Natural numbers $$\\mathbb{N}$$, which one of the following propositions has a truth value True?"
    ],
    "explanation": [
      "We need to check the truth value of each proposition on the set of natural numbers $$\\mathbb{N}$$ = $$\\{1, 2, 3, ...\\}$$.\n\n$$(\\exists x)(\\exists y)(x - y = y - x)$$: This equation simplifies to $$x - y = -(x - y)$$, which implies $$2(x - y) = 0$$, or $$x = y$$. Since there exist natural numbers x and y such that $$x = y$$ (for example, let $$x = 1$$ and $$y = 1$$), this proposition is True.\n\n$$(\\forall x)(\\forall y)(x \\neq y \\Rightarrow x > y)$$: This states that for any two distinct natural numbers, the first is always greater than the second. This is false. Consider $$x = 2$$ and $$y = 3$$. Here $$x \\neq y$$, but $$x < y$$.\n\n$$(\\forall x)(\\exists y)(x - y = 5)$$: This states that for every natural number x, there exists a natural number y such that $$y = x - 5$$. If we take $$x = 1$$, then $$y = 1 - 5 = -4$$, which is not a natural number. So, this proposition is False.\n\n$$(\\forall x)(\\exists y)(xy < x)$$: This states that for every natural number x, there exists a natural number y such that $$xy < x$$. Since x is a natural number, $$x > 0$$. Dividing the inequality by x gives $$y < 1$$. There is no natural number y that is less than 1. So, this proposition is False.\nTherefore, only proposition (A) is True."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7121,
        "content": [
          "$$\n(\\exists x)(\\exists y)(x - y = y - x)\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7122,
        "content": [
          "$$\n(\\forall x)(\\forall y)(x \\neq y \\Rightarrow x > y)\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7123,
        "content": [
          "$$\n(\\forall x)(\\exists y)(x - y = 5)\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7124,
        "content": [
          "$$\n(\\forall x)(\\exists y)(xy < x)\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1786,
    "content": [
      "If the truth value of p is T, then which of the following compound propositions has a truth value T for any proposition q?"
    ],
    "explanation": [
      "We are given that p is True (T). Therefore, $$\\neg p$$ is False (F).\n\nWe need to find the proposition that is always True regardless of the truth value of q.\n- $$\\neg p \\Leftrightarrow (p \\vee \\neg q)$$ becomes $$F \\Leftrightarrow (T \\vee \\neg q)$$. Since $$T \\vee \\neg q$$ is always T, this becomes $$F \\Leftrightarrow T$$, which is False.\n- $$(\\neg p \\wedge q) \\Rightarrow q$$ becomes $$(F \\wedge q) \\Rightarrow q$$. Since $$F \\wedge q$$ is always F, this becomes $$F \\Rightarrow q$$. An implication with a False antecedent ($$F \\Rightarrow \\dots$$) is always True, regardless of the consequent q.\n- $$(p \\wedge \\neg p) \\wedge q$$ becomes $$(T \\wedge F) \\wedge q$$. Since $$T \\wedge F$$ is F, this becomes $$F \\wedge q$$, which is always False.\n- $$(p \\Leftrightarrow q) \\wedge \\neg p$$ becomes $$(T \\Leftrightarrow q) \\wedge F$$. Since anything AND False is False, this is always False.\n\nTherefore, only proposition of option B is always True when p is T."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7147,
        "content": [
          "$$\\neg p \\Leftrightarrow (p \\vee \\neg q)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7148,
        "content": [
          "$$(\\neg p \\wedge q) \\Rightarrow q$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7149,
        "content": [
          "$$(p \\wedge \\neg p) \\wedge q$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7150,
        "content": [
          "$$(p \\Leftrightarrow q) \\wedge \\neg p$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1787,
    "content": [
      "Which of the following functions is one to one?"
    ],
    "explanation": [
      "A function is one-to-one if every distinct input value maps to a unique output value ($$f(x_1)$$ = $$f(x_2)$$ $$\\implies$$ $$x_1$$ = $$x_2$$).\n\nOption A: The function maps both 1 and 6 to the same output 5 ($$f(1)=5$$, $$f(6)=5$$). Not one-to-one.\n\nOption B: The domain is $$[0, \\infty)$$. For $$x \\ge 0$$, $$|x|$$ = $$x$$. So, $$f(x)$$ = $$x - 1$$. This is a linear function with a positive slope (1) restricted to $$x \\ge 0$$. If $$f(x_1)$$ = $$f(x_2)$$, then $$x_1$$ - $$1$$ = $$x_2$$ - $$1$$, which implies $$x_1$$ = $$x_2$$. It is one-to-one.\n\nOption C: The function $$f(x)$$ = $$x^2 - 1$$ maps different inputs to the same output, e.g., $$f(2)$$ = $$2^2-1$$ = $$3$$ and $$f(-2)$$ = $$(-2)^2-1$$ = $$3$$. Not one-to-one.\n\nOption D: Different individuals (x) can have the same mother (y), e.g., siblings. Not one-to-one.\n\nTherefore, only function of option B is one-to-one."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7151,
        "content": [
          "$$\nf = \\{(1, 5), (2, 3), (5, 4), (6, 5)\\}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7152,
        "content": [
          "$$\nf: [0, \\infty) \\to \\mathbb{R}, f(x) = |x| - 1\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7153,
        "content": [
          "$$\nf: \\mathbb{R} \\to \\mathbb{R}, f(x) = x^2 - 1\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7154,
        "content": [
          "$$\nf = \\{(x, y): y \\text{ is the mother of } x\\}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1789,
    "content": [
      "Which of the following line is true about the intercept and symmetry of the graph of $$f(x)$$ = $$\\frac{x^3 - 3x}{x^2 - 6}$$?"
    ],
    "explanation": [
      "To determine the symmetry of the function $$f(x)$$ = $$\\frac{x^3 - 3x}{x^2 - 6}$$, we evaluate $$f(-x)$$.\n\n$$f(-x)$$ = $$\\frac{(-x)^3 - 3(-x)}{(-x)^2 - 6}$$ = $$\\frac{-x^3 + 3x}{x^2 - 6}$$ = $$- \\left( \\frac{x^3 - 3x}{x^2 - 6} \\right)$$ = $$-f(x)$$.\n\nSince $$f(-x) = -f(x)$$, the function is odd, and its graph is symmetrical with respect to the origin.\n\nThe y-intercept is $$f(0) = 0/(-6) = 0$$.\n\nThe x-intercepts occur when the numerator is zero: $$x^3 - 3x$$ = $$x(x^2-3)=0$$, so $$x=0$$ or $$x=\\pm\\sqrt{3}$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7159,
        "content": [
          "The graph is symmetrical with respect to the y-axis."
        ],
        "isCorrect": false
      },
      {
        "id": 7160,
        "content": [
          "Its y-intercept is 3."
        ],
        "isCorrect": false
      },
      {
        "id": 7161,
        "content": [
          "Its x-intercepts are $$\\pm \\sqrt{6}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 7162,
        "content": [
          "The graph is symmetrical with respect to the origin."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1792,
    "content": [
      "What is the value of $$\\lim_{x \\to -1} \\frac{x^2 - 1}{x^2 + 1}$$?"
    ],
    "explanation": [
      "To find the limit, we can use direct substitution since the function is a rational function and the denominator is not zero at $$x = -1$$.\n$$\n\\lim_{x \\to -1} \\frac{x^2 - 1}{x^2 + 1} = \\frac{(-1)^2 - 1}{(-1)^2 + 1}\n$$\n$$\n= \\frac{1 - 1}{1 + 1} = \\frac{0}{2} = 0\n$$\nThe limit is 0."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7171,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 7172,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 7173,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 7174,
        "content": [
          "0"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1793,
    "content": [
      "Which one of the following is the value of $$a$$ so that the function given by\n$$\nf(x) = \\begin{cases} ax+1 & \\text{for } x \\ge 1 \\\\ x^2-4 & \\text{for } x < 1 \\end{cases}\n$$\nis continuous at 1?"
    ],
    "explanation": [
      "For the function $$f(x)$$ to be continuous at $$x=1$$, the limit from the left must equal the limit from the right, and both must equal the function value at $$x=1$$.\n\nThe limit from the right and the function value is\n$$\n\\lim_{x \\to 1^+} f(x) = f(1) = a(1) + 1 = a+1\n$$\nThe limit from the left is\n$$\n\\lim_{x \\to 1^-} f(x) = \\lim_{x \\to 1^-} (x^2 - 4) = (1)^2 - 4 = -3\n$$\nFor continuity, we must have $$a+1 = -3$$.\n\nSolving for $$a$$, we get $$a = -4$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7175,
        "content": [
          "4"
        ],
        "isCorrect": false
      },
      {
        "id": 7176,
        "content": [
          "-4"
        ],
        "isCorrect": true
      },
      {
        "id": 7177,
        "content": [
          "-1"
        ],
        "isCorrect": false
      },
      {
        "id": 7178,
        "content": [
          "1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1795,
    "content": [
      "What is the fifth term of the sequence $$\\{2^n + 4n - 5\\}_{n=0}^{\\infty}$$?"
    ],
    "explanation": [
      "Let the sequence be denoted by $$\\{a_n\\}_{n=0}^{\\infty}$$, where the general term is given by the formula $$a_n = 2^n + 4n - 5$$.\n\nThe sequence starts with the index $$n=0$$. The terms of the sequence are obtained by substituting $$n=0, 1, 2, 3, \\dots$$ into the formula.\n\nTo find the fifth term, we need to calculate $$a_4$$:\n$$\na_4 = 2^4 + 4(4) - 5\n$$\nThe fifth term of the sequence is 27."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7183,
        "content": [
          "27"
        ],
        "isCorrect": true
      },
      {
        "id": 7184,
        "content": [
          "17"
        ],
        "isCorrect": false
      },
      {
        "id": 7185,
        "content": [
          "47"
        ],
        "isCorrect": false
      },
      {
        "id": 7186,
        "content": [
          "15"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1796,
    "content": [
      "If the $$6^{th}$$ and the $$11^{th}$$ term of an arithmetic sequence are 35 and 75 respectively, then what is the sum of the first 31 terms of the sequence?"
    ],
    "explanation": [
      "**Note: We added the correct choice since the question on the paper has a mistake.**\n\nLet the arithmetic sequence be denoted by $$a_n$$ with first term $$a_1$$ and common difference $$d$$.\n\nWe are given $$a_6 = 35$$ and $$a_{11} = 75$$.\n\nUsing the formula $$a_n = a_1 + (n-1)d$$, we have:\n$$\na_6 = a_1 + 5d = 35\n$$\n$$\na_{11} = a_1 + 10d = 75\n$$\nSubtracting the first equation from the second gives: $$(a_1 + 10d)$$ - $$(a_1 + 5d)$$ = $$75 - 35$$, which simplifies to $$5d = 40$$, so $$d = 8$$.\n\nSubstituting $$d=8$$ into the first equation:\n$$\na_1 + 5(8) = 35 \\implies a_1 = -5\n$$\nThe sum of the first $$n$$ terms is given by\n$$\nS_n = \\frac{n}{2}[2a_1 + (n-1)d]\n$$\nWe need the sum of the first 31 terms, $$S_{31}$$\n$$\nS_{31} = \\frac{31}{2}[2(-5) + (31-1)(8)]\n$$\n$$\n= \\frac{31}{2}[-10 + 30(8)]\n$$\n$$\n= \\frac{31}{2}[-10 + 240]\n$$\n$$\n= \\frac{31}{2}[230]\n$$\n$$\n= 31 \\times 115 = 3565\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7187,
        "content": [
          "3565"
        ],
        "isCorrect": true
      },
      {
        "id": 7188,
        "content": [
          "2145"
        ],
        "isCorrect": false
      },
      {
        "id": 7189,
        "content": [
          "724"
        ],
        "isCorrect": false
      },
      {
        "id": 7190,
        "content": [
          "2635"
        ],
        "isCorrect": false
      },
      {
        "id": 7191,
        "content": [
          "846"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1797,
    "content": [
      "Which one of the following numbers is the upper bounds of the sequence $$\\left\\{\\frac{2n+1}{n+1}\\right\\}_{n=1}^{\\infty}$$?"
    ],
    "explanation": [
      "Let the sequence term be $$a_n$$ = $$\\frac{2n+1}{n+1}$$.\n\nWe can rewrite this as $$a_n$$ = $$\\frac{2(n+1)-1}{n+1}$$ = $$2 - \\frac{1}{n+1}$$.\n\nAs $$n$$ increases starting from 1, $$n+1$$ increases, so $$\\frac{1}{n+1}$$ decreases. Therefore, $$a_n$$ = $$2 - \\frac{1}{n+1}$$ increases.\n\nThe first term is $$a_1$$ = $$2 - \\frac{1}{1+1}$$ = $$2 - \\frac{1}{2}$$ = $$\\frac{3}{2}$$.\n\nAs $$n \\to \\infty$$, $$\\frac{1}{n+1} \\to 0$$, so $$a_n \\to 2$$. Since the sequence is increasing and approaches 2, all terms are less than 2.\n\nThus, 2 is the least upper bound (supremum). Any number greater than or equal to 2 is an upper bound.\n\nAmong the options, only 4 is greater than or equal to 2. Therefore, 4 is an upper bound for the sequence."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7192,
        "content": [
          "$$\\frac{3}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7193,
        "content": [
          "0"
        ],
        "isCorrect": false
      },
      {
        "id": 7194,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 7195,
        "content": [
          "4"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1798,
    "content": [
      "Let the sequence $$\\{a_n\\}$$ converges to 3 while $$\\{b_n\\}$$ converges to -1. Then the sequence $$\\{a_n - b_n\\}$$ converges to"
    ],
    "explanation": [
      "According to the algebra of limits for sequences, if $$\\lim_{n \\to \\infty} a_n$$ = $$L$$ and $$\\lim_{n \\to \\infty} b_n$$ = $$M$$, then the limit of the difference sequence is the difference of the limits:\n$$\n\\lim_{n \\to \\infty} (a_n - b_n) = \\lim_{n \\to \\infty} a_n - \\lim_{n \\to \\infty} b_n = L - M\n$$\nGiven $$\\lim_{n \\to \\infty} a_n$$ = $$3$$ and $$\\lim_{n \\to \\infty} b_n$$ = $$-1$$.\n\nTherefore,\n$$\n\\lim_{n \\to \\infty} (a_n - b_n) = 3 - (-1) = 3 + 1 = 4\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7196,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 7197,
        "content": [
          "4"
        ],
        "isCorrect": true
      },
      {
        "id": 7198,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 7199,
        "content": [
          "$$\\frac{1}{3}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1799,
    "content": [
      "Which of the following argument is valid?"
    ],
    "explanation": [
      "**Note: We added the correct choice since the question on the paper has a mistake.**\n\nThe argument $$p \\Rightarrow q, p \\vdash q$$ is a fundamental rule of inference known as **Modus Ponens**. It states that if a conditional statement ($$p \\Rightarrow q$$, \"if p then q\") is accepted as true, and the antecedent ($$p$$) is also accepted as true, then the consequent ($$q$$) can be validly inferred as true. This is a universally accepted valid argument form.\n\nThe other options represent invalid argument forms (logical fallacies or incorrect deductions)."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7200,
        "content": [
          "$$p \\lor q, p \\Rightarrow q \\vdash \\neg q$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7201,
        "content": [
          "$$p \\Rightarrow q, p \\vdash q$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7202,
        "content": [
          "$$p, p \\Rightarrow q, r \\lor \\neg q \\vdash p \\land \\neg r$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7203,
        "content": [
          "$$p \\Rightarrow q, q, r \\Rightarrow p \\vdash \\neg r$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7204,
        "content": [
          "$$p \\Rightarrow q, \\neg r \\land q \\vdash p \\lor r$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1800,
    "content": [
      "Which of the following assertions is true applying the Principle of Mathematical Induction?"
    ],
    "explanation": [
      "We check each assertion.\n\nOption A: This is the formula for the sum of a geometric progression $$1, 2, 2^2, ..., 2^n$$. The first term is $$a=1$$, the common ratio is $$r=2$$, and there are $$n+1$$ terms. The sum is\n$$\na\\frac{r^{n+1}-1}{r-1} = 1 \\cdot \\frac{2^{n+1}-1}{2-1}\n$$\n$$\n= 2^{n+1}-1\n$$\nThe formula is correct for $$n \\ge 0$$. It can be proven by induction. Base case $$n=0$$: $$2^0 = 1$$, $$2^{0+1}-1 = 1$$.\n\nAssume true for k: $$S_k = 2^{k+1}-1$$. Then\n$$S_{k+1}$$ = $$S_k + 2^{k+1}$$ = $$(2^{k+1}-1)$$ + $$2^{k+1}$$ = $$2 \\cdot 2^{k+1}$$ - $$1$$ = $$2^{k+2}-1$$.\n\nThis matches the formula for $$n=k+1$$. So, A is true.\n\nOption B: False. Counterexample n=1: $$1! = 1$$, $$2^1 = 2$$. $$1 \\ge 2$$ is false. (True only for n=0 and $$n \\ge 4$$).\n\nOption C: False. The sum $$2+3+...+n$$ = $$(1+2+...+n)$$ - $$1$$ = $$\\frac{n(n+1)}{2}$$ - $$1$$. The assertion states $$\\frac{n(n+1)}{2} + 1$$. Base case n=2: LHS=2, RHS = $$\\frac{2(3)}{2}+1 = 4$$. $$2 \\ne 4$$.\n\nOption D: False. The sum is $$\\sum_{k=1}^{n} (2k+1)$$ = $$2\\sum k$$ + $$\\sum 1$$ = $$2\\frac{n(n+1)}{2}$$ + $$n$$ = $$n(n+1)+n$$ = $$n^2+2n$$. The assertion states $$n^2$$. Base case n=1: LHS=$$2(1)+1=3$$. RHS=$$1^2=1$$. $$3 \\ne 1$$.\n\nTherefore, only assertion A is correct and provable by induction for the specified range of n."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7205,
        "content": [
          "$$1+2+ 2^2+...+ 2^n$$ = $$2^{n+1}$$ - $$1$$ for $$n \\ge 0$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7206,
        "content": [
          "$$n! \\ge 2^n$$ for $$n \\ge 0$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7207,
        "content": [
          "$$2+3+4+...+n$$ = $$\\frac{n(n+1)}{2}$$ + $$1$$ for $$n \\ge 2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7208,
        "content": [
          "$$3+5+7+...+(2n+1)$$ = $$n^2$$ for $$n \\ge 1$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1801,
    "content": [
      "Which of the following is equal to $$\\int 3 \\cos 3x dx$$?"
    ],
    "explanation": [
      "To evaluate the integral $$\\int 3 \\cos 3x dx$$, we can use the substitution method.\n\nLet $$u = 3x$$. Then, the differential $$du = 3 dx$$. Substituting these into the integral gives $$\\int \\cos u du$$. The integral of $$\\cos u$$ with respect to $$u$$ is $$\\sin u + c$$. Substituting back $$u = 3x$$, we get $$\\sin 3x + c$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7209,
        "content": [
          "$$\\frac{1}{3} \\sin 3x + c$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7210,
        "content": [
          "$$\\sin 3x + c$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7211,
        "content": [
          "$$\\sin x + c$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7212,
        "content": [
          "$$-\\sin x + c$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1802,
    "content": [
      "What is the area of the region bounded by the graph of $$f(x) = x^2 - 4$$ and the x-axis in square units?"
    ],
    "explanation": [
      "To find the area, we first determine the points where the graph intersects the x-axis by setting $$f(x) = 0$$. So, $$x^2 - 4 = 0$$, which gives $$x = -2$$ and $$x = 2$$.\n\nThe area A is the absolute value of the definite integral of $$f(x)$$ from -2 to 2:\n$$\nA = |\\int_{-2}^{2} (x^2 - 4) dx|\n$$\nEvaluating the integral:\n$$\n\\int (x^2 - 4) dx = \\frac{x^3}{3} - 4x\n$$\n$$\nA = |[\\frac{x^3}{3} - 4x]_{-2}^{2}|\n$$\n$$\n= |(\\frac{2^3}{3} - 4(2)) - (\\frac{(-2)^3}{3} - 4(-2))|\n$$\n$$\n= |(\\frac{8}{3} - 8) - (-\\frac{8}{3} + 8)|\n$$\n$$\n= |\\frac{8}{3} - 8 + \\frac{8}{3} - 8|\n$$\n$$\n= \\frac{32}{3}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7213,
        "content": [
          "$$16$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7214,
        "content": [
          "$$32$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7215,
        "content": [
          "$$\\frac{16}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7216,
        "content": [
          "$$\\frac{32}{3}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1803,
    "content": [
      "Let f be a continuous function on [0, 1] and let F be an anti-derivative of f with $$F(1) = -11$$ and $$F(0) = 11$$. Then $$\\int_{0}^{1} f(x) dx$$ is equal to"
    ],
    "explanation": [
      "According to the Fundamental Theorem of Calculus, if F is an antiderivative of a continuous function f on the interval [a, b], then\n$$\n\\int_{a}^{b} f(x) dx = F(b) - F(a)\n$$\nHere, $$a=0$$, $$b=1$$, $$F(1)=-11$$, and $$F(0)=11$$. Therefore,\n$$\n\\int_{0}^{1} f(x) dx = F(1) - F(0) = -11 - 11 = -22\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7217,
        "content": [
          "-22"
        ],
        "isCorrect": true
      },
      {
        "id": 7218,
        "content": [
          "11"
        ],
        "isCorrect": false
      },
      {
        "id": 7219,
        "content": [
          "0"
        ],
        "isCorrect": false
      },
      {
        "id": 7220,
        "content": [
          "22"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1810,
    "content": [
      "Let $$z_1$$, $$z_2$$, and $$z_3$$ be complex numbers. Then which of the following is **NOT** necessarily true?"
    ],
    "explanation": [
      "Option B simplifies as follows: The left side is\n$$\nz_1 - (z_2 - z_3) = z_1 - z_2 + z_3\n$$\nThe right side is\n$$\n(z_1 - z_2) - z_3 = z_1 - z_2 - z_3\n$$\nThese two expressions, $$z_1 - z_2 + z_3$$ and $$z_1 - z_2 - z_3$$, are not equal unless $$z_3 = -z_3$$, which only happens if $$z_3 = 0$$.\n\nSince the statement must be true for *all* complex numbers $$z_1, z_2, z_3$$, option B is not necessarily true.\n\nOptions A, C, and D represent standard properties of complex number arithmetic (associativity of addition/subtraction, commutativity and associativity of multiplication)."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7248,
        "content": [
          "$$\nz_1 - (z_2 + z_3) = (z_1 - z_2) - z_3\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7249,
        "content": [
          "$$\nz_1 - (z_2 - z_3) = (z_1 - z_2) - z_3\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7250,
        "content": [
          "$$\n(z_1 z_2) z_3 = (z_2 z_1) z_3\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7251,
        "content": [
          "$$\n(z_1 z_2) z_3 = z_1 (z_2 z_3)\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1811,
    "content": [
      "Which of the following complex numbers corresponds to the point $$(-3, -1)$$ in the Argand plane?"
    ],
    "explanation": [
      "In the Argand plane, a point with coordinates $$(x, y)$$ corresponds to the complex number $$z = x + yi$$. For the point $$(-3, -1)$$, we have $$x = -3$$ and $$y = -1$$. Therefore, the corresponding complex number is\n$$\nz = -3 + (-1)i = -3 - i\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7252,
        "content": [
          "$$-3 + i$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7253,
        "content": [
          "$$3 + i$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7254,
        "content": [
          "$$-1 - 3i$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7255,
        "content": [
          "$$-3 - i$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1815,
    "content": [
      "Let F be the anti-derivative of f. Then which of the following is **NOT** true about F and f?"
    ],
    "explanation": [
      "F is the antiderivative of f, which means $$F'(x) = f(x)$$. This confirms option B is true.\n\nOption A states that the derivative of the indefinite integral of F(x) is F(x), which is true by the Fundamental Theorem of Calculus, Part 1 (remove).\n\nOption D states that the indefinite integral of the derivative of f(x) is f(x) + c, which is also true by the definition of the indefinite integral (up to the constant C).\n\nOption C states that the integral of F(x) is f(x) + c. Since $$F'(x) = f(x)$$, integrating F(x) would generally not give f(x).\n\nFor example, if $$f(x) = 2x$$, then $$F(x) = x^2$$. Then $$\\int F(x)dx$$ = $$\\int x^2 dx$$ = $$\\frac{x^3}{3} + c$$, which is not equal to $$f(x)+c$$ = $$2x+c$$.\n\nTherefore, option C is not generally true."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7268,
        "content": [
          "$$\\frac{d}{dx}\\int F(x)dx$$ = $$F(x)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7269,
        "content": [
          "$$F'(x)$$ = $$f(x)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7270,
        "content": [
          "$$\\int F(x)dx$$ = $$f(x) + c$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7271,
        "content": [
          "$$\\int \\frac{d}{dx}f(x)dx$$ = $$f(x) + c$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1821,
    "content": [
      "Which of the following is true about the zero(s) of a function $$f(x)$$?"
    ],
    "explanation": [
      "The Factor Theorem states that for a polynomial function $$f(x)$$, if $$f(a) = 0$$, then $$(x - a)$$ is a factor of $$f(x)$$.\n\nOption A correctly states this theorem (assuming $$f(x)$$ is a polynomial or in a context where the theorem applies).\n\nOption B is only true if $$a$$ is a zero of multiplicity at least 2 (remove).\n\nOption C is false; if $$f(a)$$ is defined, $$a$$ must be in the domain.\n\nOption D is false; $$f(a)=0$$ means $$a$$ is an x-intercept (a zero), while the y-intercept is the value of $$f(0)$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7292,
        "content": [
          "If $$f(a)=0$$, then $$x - a$$ is a factor for $$f(x)$$."
        ],
        "isCorrect": true
      },
      {
        "id": 7293,
        "content": [
          "If $$f(a)=0$$, then $$(x - a)^2$$ is a factor of $$f(x)$$."
        ],
        "isCorrect": false
      },
      {
        "id": 7294,
        "content": [
          "If $$f(a)=0$$, then a is not necessarily in the domain."
        ],
        "isCorrect": false
      },
      {
        "id": 7295,
        "content": [
          "If $$f(a)=0$$, then $$y=a$$ is the y-intercept."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Polynomial Function"
  },
  {
    "id": 2623,
    "content": [
      "What are the quotient and remainder respectively, when 75 is divided by 20?"
    ],
    "explanation": [
      "When we divide 75 by 20, we find how many times 20 fits completely into 75.\n$$\n75 = 20 \\times 3 + 15\n$$\n20 goes into 75 three times (3 × 20 = 60), with 15 left over. Therefore, the quotient is 3 and the remainder is 15."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_NUMBER_SYSTEM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10500,
        "content": [
          "3 and 15"
        ],
        "isCorrect": true
      },
      {
        "id": 10501,
        "content": [
          "4 and 5"
        ],
        "isCorrect": false
      },
      {
        "id": 10502,
        "content": [
          "15 and 3"
        ],
        "isCorrect": false
      },
      {
        "id": 10503,
        "content": [
          "2 and 19"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "The Number System"
  },
  {
    "id": 2624,
    "content": [
      "If f(x) = x² + px + 1 where f(0) and f(1) have opposite signs so that f has a root in (0, 1), then which one of the following number is a possible value p?"
    ],
    "explanation": [
      "According to the Intermediate Value Theorem, if f(0) and f(1) have opposite signs, there must be a root between 0 and 1.",
      "First, evaluate f(0):\n$$\nf(0) = 0^2 + p(0) + 1 = 1\n$$.\nSince f(0) is positive, f(1) must be negative for them to have opposite signs.",
      "Now, evaluate f(1):\n$$\nf(1) = 1^2 + p(1) + 1 = 2 + p\n$$\nSet f(1) < 0:\n$$\n2 + p < 0 \\Rightarrow p < -2\n$$\nAmong the given options, only -3 is less than -2."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10504,
        "content": [
          "-3"
        ],
        "isCorrect": true
      },
      {
        "id": 10505,
        "content": [
          "-2"
        ],
        "isCorrect": false
      },
      {
        "id": 10506,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 10507,
        "content": [
          "3"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2628,
    "content": [
      "Let R = {(x, y)|y ≥ x² + 1 and y ≤ 5} be a relation. Then which one of the following defines the inverse of R?"
    ],
    "explanation": [
      "To find the inverse relation, R⁻¹, we interchange the roles of x and y in the defining rule of the relation R.",
      "The relation R is defined by the conditions: y ≥ x² + 1 and y ≤ 5.",
      "Interchanging x and y, we get the conditions for R⁻¹: x ≥ y² + 1 and x ≤ 5.",
      "Therefore, the inverse relation is R⁻¹ = {(x, y)|x ≥ y² + 1, x ≤ 5}."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10520,
        "content": [
          "{(x, y)|x ≥ y² + 1, x ≤ 5}"
        ],
        "isCorrect": true
      },
      {
        "id": 10521,
        "content": [
          "{(x, y)|x ≥ y² + 1, x ≥ 5}"
        ],
        "isCorrect": false
      },
      {
        "id": 10522,
        "content": [
          "{(x, y)|x ≤ y² + 1, x ≥ 5}"
        ],
        "isCorrect": false
      },
      {
        "id": 10523,
        "content": [
          "{(x, y)|x > y² - 1, x ≤ 5}"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2634,
    "content": [
      "Which one of the following gives the polar form of the complex number z = 2 - 2√3i?"
    ],
    "explanation": [
      "For a complex number z = a + bi, the polar form is r(cosθ + i sinθ).",
      "The modulus is\n$$\nr = \\sqrt{a^2 + b^2} = \\sqrt{2^2 + (-2\\sqrt{3})^2} = \\sqrt{4 + 12} = \\sqrt{16} = 4\n$$\nThe argument θ is found from tanθ = b/a = -2√3 / 2 = -√3.",
      "Since the point (2, -2√3) is in the fourth quadrant, the angle is\n$$\n\\theta = \\frac{5\\pi}{3}\n$$\nThus, the polar form is\n$$\nz = 4(\\cos\\frac{5\\pi}{3} + i\\sin\\frac{5\\pi}{3})\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10544,
        "content": [
          "$$\n4(\\cos\\frac{5\\pi}{3} + i\\sin\\frac{5\\pi}{3})\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10545,
        "content": [
          "$$\n4(\\cos\\frac{\\pi}{4} + i\\sin\\frac{\\pi}{4})\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10546,
        "content": [
          "$$\n4(\\cos\\frac{3\\pi}{4} + i\\sin\\frac{3\\pi}{4})\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10547,
        "content": [
          "$$\n4(\\cos\\frac{\\pi}{3} + i\\sin\\frac{\\pi}{3})\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2636,
    "content": [
      "What is the product of the two complex number z = 2 - 3i and w = 5 + 2i?"
    ],
    "explanation": [
      "To find the product, we multiply the complex numbers using the distributive property (like FOIL).\n$$\nzw = (2 - 3i)(5 + 2i) = 2(5) + 2(2i) - 3i(5) - 3i(2i)\n$$\n$$\n= 10 + 4i - 15i - 6i^2\n$$\nSince i² = -1:\n$$\n= 10 - 11i - 6(-1) = 10 - 11i + 6 = 16 - 11i\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10552,
        "content": [
          "16 + 11i"
        ],
        "isCorrect": false
      },
      {
        "id": 10553,
        "content": [
          "4 - 11i"
        ],
        "isCorrect": false
      },
      {
        "id": 10554,
        "content": [
          "16 - 11i"
        ],
        "isCorrect": true
      },
      {
        "id": 10555,
        "content": [
          "29"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2640,
    "content": [
      "The graph of a certain relation R is represented by the shaded region shown on the figure below.",
      "images/maths/year_2014_na/q23_1_background.png",
      "Which one of the following pairs of sets respectively gives the domain and range of this relation?"
    ],
    "explanation": [
      "From the graph:\n- The shaded region extends infinitely to the **left** (x ≤ 2), so the **domain** is {x | x ≤ 2}.\n- The shaded region also extends infinitely **upward and downward**, meaning all y-values are included. So the **range** is ℝ.",
      "**Correct answer:** {x | x ≤ 2} and ℝ"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2014_na/q23_1_background.png"
    ],
    "choices": [
      {
        "id": 10568,
        "content": [
          "{x|x ≤ 2} and {y|y ≤ 6}"
        ],
        "isCorrect": false
      },
      {
        "id": 10569,
        "content": [
          "{x|x ≤ 2} and R"
        ],
        "isCorrect": true
      },
      {
        "id": 10570,
        "content": [
          "R and {y|y ≤ 2}"
        ],
        "isCorrect": false
      },
      {
        "id": 10571,
        "content": [
          "R and R"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2643,
    "content": [
      "The simplified form of the expression\n$$\n\\frac{6\\sqrt{20} - 3\\sqrt{45}}{3\\sqrt{75}} \\ \\text{is:}\n$$"
    ],
    "explanation": [
      "First, simplify each radical term in the expression.",
      "√20 = √(4⋅5) = 2√5",
      "√45 = √(9⋅5) = 3√5",
      "√75 = √(25⋅3) = 5√3",
      "Substitute these values back into the expression:\n$$\n\\frac{6(2\\sqrt{5}) - 3(3\\sqrt{5})}{3(5\\sqrt{3})} = \\frac{12\\sqrt{5} - 9\\sqrt{5}}{15\\sqrt{3}}\n$$\n$$\n= \\frac{3\\sqrt{5}}{15\\sqrt{3}} = \\frac{\\sqrt{5}}{5\\sqrt{3}}\n$$\nRationalize the denominator by multiplying the numerator and denominator by √3:\n$$\n\\frac{\\sqrt{5} \\cdot \\sqrt{3}}{5\\sqrt{3} \\cdot \\sqrt{3}} = \\frac{\\sqrt{15}}{5 \\cdot 3} = \\frac{\\sqrt{15}}{15}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_NUMBER_SYSTEM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10580,
        "content": [
          "$$\\sqrt{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10581,
        "content": [
          "$$\\frac{\\sqrt{15}}{15}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10582,
        "content": [
          "$$\\frac{1}{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10583,
        "content": [
          "$$5$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "The Number System"
  },
  {
    "id": 2644,
    "content": [
      "Which one of the following sets is the symmetric difference, A Δ B, of the sets A = {1, 3, 5, 6, 8, 10} and B = {2, 5, 8, 11}?"
    ],
    "explanation": [
      "The symmetric difference of two sets A and B, denoted A Δ B, is the set of elements which are in either of the sets, but not in their intersection. It can be calculated as (A ∪ B) \\ (A ∩ B).",
      "A ∪ B = {1, 2, 3, 5, 6, 8, 10, 11}",
      "A ∩ B = {5, 8}",
      "A Δ B = {1, 2, 3, 5, 6, 8, 10, 11} \\ {5, 8} = {1, 2, 3, 6, 10, 11}."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SETS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10584,
        "content": [
          "{1, 2, 3, 5, 6, 8, 10, 11}"
        ],
        "isCorrect": false
      },
      {
        "id": 10585,
        "content": [
          "{2, 11}"
        ],
        "isCorrect": false
      },
      {
        "id": 10586,
        "content": [
          "{1, 2, 3, 6, 10, 11}"
        ],
        "isCorrect": true
      },
      {
        "id": 10587,
        "content": [
          "{1, 3, 6, 10}"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 2651,
    "content": [
      "Which of the following is true about bounded sequence?"
    ],
    "explanation": [
      "This is the Monotone Convergence Theorem, a fundamental result in real analysis. It states that if a sequence is both monotone (either non-decreasing or non-increasing) and bounded, then it must converge to a limit. The other statements are incorrect."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10612,
        "content": [
          "Every bounded sequence is convergent."
        ],
        "isCorrect": false
      },
      {
        "id": 10613,
        "content": [
          "Every increasing bounded sequence converges to the greatest lower bound of the sequence."
        ],
        "isCorrect": false
      },
      {
        "id": 10614,
        "content": [
          "Every decreasing bounded sequence converges to the least upper bound of the sequence."
        ],
        "isCorrect": false
      },
      {
        "id": 10615,
        "content": [
          "Every monotone bounded sequence converges."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2655,
    "content": [
      "What is the seventh term of an arithmetic sequence whose third term is -4 and common difference is 5?"
    ],
    "explanation": [
      "The formula for the nth term of an arithmetic sequence is aₙ = a₁ + (n-1)d.",
      "Alternatively, we can relate two terms: aₙ = aₘ + (n-m)d.",
      "We are given a₃ = -4, d = 5, and we want to find a₇.",
      "Using the second formula with n=7 and m=3:\n$$\na_7 = a_3 + (7-3)d = -4 + (4)(5) = -4 + 20 = 16\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10628,
        "content": [
          "15"
        ],
        "isCorrect": false
      },
      {
        "id": 10629,
        "content": [
          "-15"
        ],
        "isCorrect": false
      },
      {
        "id": 10630,
        "content": [
          "16"
        ],
        "isCorrect": true
      },
      {
        "id": 10631,
        "content": [
          "-16"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2657,
    "content": [
      "The sum of the first 8 terms of a geometric sequence with first term 0.3 and common ratio 1/10 is equal to:"
    ],
    "explanation": [
      "The sum of the first n terms of a geometric sequence is given by the formula\n$$\nS_n = \\frac{a_1(1-r^n)}{1-r}\n$$\nHere, a₁ = 0.3 = 3/10, r = 1/10, and n = 8.\n$$\nS_8 = \\frac{\\frac{3}{10}(1 - (\\frac{1}{10})^8)}{1 - \\frac{1}{10}}\n$$\n$$\n= \\frac{\\frac{3}{10}(1 - \\frac{1}{10^8})}{\\frac{9}{10}}\n$$\n$$\nS_8 = \\frac{3}{10} \\times \\frac{10}{9} \\times (1 - \\frac{1}{10^8})\n$$\n$$\n= \\frac{1}{3} \\times (\\frac{10^8 - 1}{10^8})\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10636,
        "content": [
          "$$\n\\frac{3}{10}(\\frac{10^8 - 1}{10^8})\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10637,
        "content": [
          "$$\n\\frac{1}{3}(\\frac{10^8 - 1}{10^8})\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10638,
        "content": [
          "$$\n\\frac{1}{3}(\\frac{10^8 - 1}{10^7})\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10639,
        "content": [
          "$$\n\\frac{3}{10}(\\frac{10^8 - 1}{10^9})\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2663,
    "content": [
      "Which of the following is NOT true about argument and validity?"
    ],
    "explanation": [
      "The definition of a valid argument is that if all of its premises are true, then its conclusion must also be true. It is impossible for a valid argument to have all true premises and a false conclusion. Statement (C) contradicts this definition; it describes an invalid argument."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10660,
        "content": [
          "An argument which is not valid is fallacy"
        ],
        "isCorrect": false
      },
      {
        "id": 10661,
        "content": [
          "The validity of an argument can be checked by using a truth table."
        ],
        "isCorrect": false
      },
      {
        "id": 10662,
        "content": [
          "In a valid argument, the conclusion may be true or false whenever all the premises are true."
        ],
        "isCorrect": true
      },
      {
        "id": 10663,
        "content": [
          "In a valid argument if all the premises are true then the conclusion must also be true."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 2664,
    "content": [
      "Which one of the following compound statements has a converse with truth value False?"
    ],
    "explanation": [
      "The converse of a conditional statement \"If p, then q\" is \"If q, then p\". A conditional statement is false only when the hypothesis (the 'if' part) is true and the conclusion (the 'then' part) is false.",
      "For statement (A), p is \"6 is a prime integer\" (False), and q is \"4 is an even number\" (True).",
      "The converse is \"If 4 is an even number, then 6 is a prime integer\". Here, the hypothesis is True and the conclusion is False. Therefore, the converse is False."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10664,
        "content": [
          "If 6 is a prime integer, then 4 is an even number."
        ],
        "isCorrect": true
      },
      {
        "id": 10665,
        "content": [
          "If man is immortal, then the earth does not rotate around the sun."
        ],
        "isCorrect": false
      },
      {
        "id": 10666,
        "content": [
          "If athlete Derartu Tulu was born on October 21, 1971, then 6 is prime."
        ],
        "isCorrect": false
      },
      {
        "id": 10667,
        "content": [
          "If man is mortal, then the earth does not rotate around the sun."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 2670,
    "content": [
      "Which one of the following is an onto function from R on to [0, ∞)?"
    ],
    "explanation": [
      "An onto (surjective) function from set A to set B is a function where every element in B is the image of at least one element in A. Here, the domain is R and the codomain is [0, ∞).",
      "The function f(x) = √x² simplifies to f(x) = |x|. The domain of this function is all real numbers (R). The range (the set of all possible output values) is all non-negative real numbers, which is [0, ∞). Since the range is equal to the codomain, the function is onto."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10688,
        "content": [
          "f(x) = √x²"
        ],
        "isCorrect": true
      },
      {
        "id": 10689,
        "content": [
          "f(x) = |x| + 2"
        ],
        "isCorrect": false
      },
      {
        "id": 10690,
        "content": [
          "f(x) = x² + 1"
        ],
        "isCorrect": false
      },
      {
        "id": 10691,
        "content": [
          "f(x) = 2ˣ"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2681,
    "content": [
      "Let p and q be propositions. Which of the following compound statement is a tautology?"
    ],
    "explanation": [
      "A tautology is a compound statement that is always true, regardless of the truth values of the individual propositions.",
      "The statement (p ⇒ q) ⇔ (¬p ∨ q) represents the logical equivalence that defines the conditional (implication) operator. This equivalence is a fundamental law of logic and is always true, making it a tautology."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10732,
        "content": [
          "(p ∨ q) ⇔ p"
        ],
        "isCorrect": false
      },
      {
        "id": 10733,
        "content": [
          "(p ⇒ q) ⇔ p"
        ],
        "isCorrect": false
      },
      {
        "id": 10734,
        "content": [
          "(p ∧ q) ⇔ p"
        ],
        "isCorrect": false
      },
      {
        "id": 10735,
        "content": [
          "(p ⇒ q) ⇔ (¬p ∨ q)"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 2682,
    "content": [
      "Which one of the following is NOT true about the graph of f(x) = 5 + |x|/(x+1)?"
    ],
    "explanation": [
      "An oblique (or slant) asymptote occurs in a rational function when the degree of the numerator is exactly one greater than the degree of the denominator.",
      "For f(x) = 5 + |x|/(x+1), as x approaches ±∞, the term |x|/(x+1) approaches either 1 or -1. The function does not grow linearly like y=5+x. Thus, it does not have an oblique asymptote. The other statements are true: there is a vertical asymptote at x=-1 and horizontal asymptotes at y=6 (as x→∞) and y=4 (as x→-∞)."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10736,
        "content": [
          "y = 5 + x is its oblique asymptote."
        ],
        "isCorrect": true
      },
      {
        "id": 10737,
        "content": [
          "y = 6 is its horizontal asymptote of f."
        ],
        "isCorrect": false
      },
      {
        "id": 10738,
        "content": [
          "y = 4 is its horizontal asymptote."
        ],
        "isCorrect": false
      },
      {
        "id": 10739,
        "content": [
          "x = -1 is its vertical asymptote of f."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2683,
    "content": [
      "A Geometric Series with first term a and common ratio r is convergent if"
    ],
    "explanation": [
      "A geometric series converges when its terms keep getting smaller. That happens only if the common ratio’s absolute value is less than 1.",
      "If |r| ≥ 1, the terms don’t get smaller, so the sum keeps growing instead of settling to a fixed value."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10740,
        "content": [
          "|r| ≥ 1"
        ],
        "isCorrect": false
      },
      {
        "id": 10741,
        "content": [
          "|r| > 1"
        ],
        "isCorrect": false
      },
      {
        "id": 10742,
        "content": [
          "|r| ≤ 1"
        ],
        "isCorrect": false
      },
      {
        "id": 10743,
        "content": [
          "|r| < 1"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2684,
    "content": [
      "Which of the following is an upper bound for the sequence\n$$\n{\\{\\frac{n+1}{n}\\}}_{n=1}^{\\infty} \\ \\text{?}\n$$"
    ],
    "explanation": [
      "Let the sequence be\n$$\na_n = \\frac{n+1}{n} = 1 + \\frac{1}{n}\n$$\nThe first few terms are a₁=2, a₂=3/2=1.5, a₃=4/3≈1.33.",
      "The sequence is decreasing and approaches 1 as n approaches infinity. The maximum value is the first term, a₁=2. An upper bound is any number greater than or equal to the maximum value of the sequence. Therefore, 2 is an upper bound (it is also the least upper bound)."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10744,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 10745,
        "content": [
          "0"
        ],
        "isCorrect": false
      },
      {
        "id": 10746,
        "content": [
          "2"
        ],
        "isCorrect": true
      },
      {
        "id": 10747,
        "content": [
          "4/3"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2685,
    "content": [
      "The general term of a sequence is $$a_n = (\\frac{1}{2})^{1-n}$$. Then which of the following is true about this sequence?"
    ],
    "explanation": [
      "The general term can be simplified:\n$$\na_n = (2^{-1})^{1-n} = 2^{-1(1-n)} = 2^{n-1}\n$$",
      "For n=1, a₁=2⁰=1. For n=2, a₂=2¹=2. For n=3, a₃=2²=4. The sequence is {1, 2, 4, 8, ...}.",
      "All terms of the sequence are positive integers, which are by definition natural numbers."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10748,
        "content": [
          "0 is one of its terms."
        ],
        "isCorrect": false
      },
      {
        "id": 10749,
        "content": [
          "Its terms are non-positive."
        ],
        "isCorrect": false
      },
      {
        "id": 10750,
        "content": [
          "Its terms are odd numbers."
        ],
        "isCorrect": false
      },
      {
        "id": 10751,
        "content": [
          "Its terms are natural numbers."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2687,
    "content": [
      "Let $$f(x) = \\frac{x^2 - x}{2x^2 - x - 1}$$, which of the following is NOT true about f and its graph?"
    ],
    "explanation": [
      "First, factor the numerator and denominator:\n$$\nf(x) = \\frac{x(x - 1)}{(2x + 1)(x - 1)}\n$$",
      "The function simplifies to $$f(x) = \\frac{x}{2x + 1}$$ with a hole at x=1.",
      "An even function must satisfy f(-x) = f(x). For this function,\n$$\nf(-x) = \\frac{-x}{2(-x) + 1} = \\frac{-x}{-2x + 1}\n$$\nwhich is not equal to f(x). Therefore, the statement that f is an even function is NOT true.",
      "The other statements are true: The denominator 2x+1 is zero at x=-1/2 (vertical asymptote). The cancelled factor x-1 causes a hole at x=1, where y=1/(2(1)+1) = 1/3. The ratio of the leading coefficients of the original function is 1/2, so y=1/2 is a horizontal asymptote."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10756,
        "content": [
          "x = -1/2 is a vertical asymptote."
        ],
        "isCorrect": false
      },
      {
        "id": 10757,
        "content": [
          "The graph of f has a hole at (1, 1/3)."
        ],
        "isCorrect": false
      },
      {
        "id": 10758,
        "content": [
          "f is an even function."
        ],
        "isCorrect": true
      },
      {
        "id": 10759,
        "content": [
          "y = 1/2 is a horizontal asymptote."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2690,
    "content": [
      "If p: \"the rainy season is very good this year\" and q: \"rivers are rising\", then the statement \"It is not true that neither the rainy season is very good this year nor rivers are rising\" denoted by"
    ],
    "explanation": [
      "The phrase “neither p nor q” means ¬p ∧ ¬q. So, “It is not true that neither p nor q” becomes ¬(¬p ∧ ¬q).",
      "By De Morgan’s law: ¬(¬p ∧ ¬q) = ¬¬p ∨ ¬¬q = p ∨ q.",
      "Hence, the symbolic form of the given statement is ¬(¬p ∨ ¬q), equivalent to p ∧ q in logic."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10768,
        "content": [
          "(¬p ⇒ q) ∨ ¬q"
        ],
        "isCorrect": false
      },
      {
        "id": 10769,
        "content": [
          "(p ⇒ q) ∨ (¬p ⇒ ¬q)"
        ],
        "isCorrect": false
      },
      {
        "id": 10770,
        "content": [
          "¬p ∧ ¬q"
        ],
        "isCorrect": false
      },
      {
        "id": 10771,
        "content": [
          "¬(¬p ∨ ¬q)"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 2692,
    "content": [
      "Given $$0 < a_n < \\frac{1}{n}$$ for each n=1,2,3..... Which of the following is true?"
    ],
    "explanation": [
      "This is a direct application of the Squeeze Theorem (or Sandwich Theorem). We are given the inequality $$0 < a_n < \\frac{1}{n}$$.",
      "We take the limit of all parts of the inequality as n approaches infinity.\n$$\n\\lim_{n\\to\\infty} 0 \\leq \\lim_{n\\to\\infty} a_n \\leq \\lim_{n\\to\\infty} \\frac{1}{n}\n$$\n$$\n0 \\leq \\lim_{n\\to\\infty} a_n \\leq 0\n$$\nSince the limit of aₙ is squeezed between 0 and 0, the limit must be 0."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10776,
        "content": [
          "$$\\lim_{n\\to\\infty} a_n < 0$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10777,
        "content": [
          "$$\\lim_{n\\to\\infty} a_n = 0$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10778,
        "content": [
          "$$\\lim_{n\\to\\infty} a_n$$ does not exist"
        ],
        "isCorrect": false
      },
      {
        "id": 10779,
        "content": [
          "$$\\lim_{n\\to\\infty} a_n > 0$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2695,
    "content": [
      "Let z₁ = 2 + i, z₂ = 3 + i and z₃ = 1 - i, then what are the real and imaginary parts of z₁z₂z₃ respectively?"
    ],
    "explanation": [
      "First, multiply z₁ and z₂:\n$$\nz_1z_2 = (2 + i)(3 + i)\n$$\n$$\n= 6 + 2i + 3i + i^2 = 6 + 5i - 1 = 5 + 5i\n$$",
      "Now, multiply the result by z₃:\n$$\n(z_1z_2)z_3 = (5 + 5i)(1 - i)\n$$\n$$\n= 5(1+i)(1-i) = 5(1^2 - i^2)\n$$\n$$\n= 5(1 - (-1)) = 5(2) = 10\n$$",
      "The result is 10, which can be written as 10 + 0i. The real part is 10 and the imaginary part is 0."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10788,
        "content": [
          "6 and 3"
        ],
        "isCorrect": false
      },
      {
        "id": 10789,
        "content": [
          "-6 and -3"
        ],
        "isCorrect": false
      },
      {
        "id": 10790,
        "content": [
          "-1 and 1"
        ],
        "isCorrect": false
      },
      {
        "id": 10791,
        "content": [
          "10 and 0"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2696,
    "content": [
      "What is the value of a and b if\n$$\n\\frac{a + 2i}{3i} = \\frac{b+i}{4} \\ \\text{?}\n$$"
    ],
    "explanation": [
      "Cross-multiply the terms to get an equation without fractions:\n$$\n4(a + 2i) = 3i(b + i)\n$$\n$$\n4a + 8i = 3bi + 3i^2\n$$\n$$\n4a + 8i = 3bi - 3\n$$",
      "Group the real and imaginary parts:\n$$\n4a + 8i = -3 + (3b)i\n$$",
      "Equate the real parts:\n$$\n4a = -3 \\implies a = -3/4\n$$",
      "Equate the imaginary parts:\n$$\n8 = 3b \\implies b = 8/3\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10792,
        "content": [
          "a = 3/4, b = -8/3"
        ],
        "isCorrect": false
      },
      {
        "id": 10793,
        "content": [
          "a = 3/4, b = 8/3"
        ],
        "isCorrect": false
      },
      {
        "id": 10794,
        "content": [
          "a = -3/4, b = 8/3"
        ],
        "isCorrect": true
      },
      {
        "id": 10795,
        "content": [
          "a = -3/4, b = -8/3"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2699,
    "content": [
      "If p and q are propositions, then which one of the following pairs of compound propositions are equivalent?"
    ],
    "explanation": [
      "Two propositions are equivalent if they have the same truth table. Let's analyze option C.",
      "p ⇔ q (biconditional) is true only when p and q have the same truth value (both true or both false).",
      "¬p ⇔ ¬q is true only when ¬p and ¬q have the same truth value. This happens when p and q are both false (so ¬p and ¬q are both true) or when p and q are both true (so ¬p and ¬q are both false). This is the same condition as for p ⇔ q. Thus, they are equivalent."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10804,
        "content": [
          "p ⇒ ¬q and ¬p ∧ q"
        ],
        "isCorrect": false
      },
      {
        "id": 10805,
        "content": [
          "¬(p ∧ q) and ¬p ∨ q"
        ],
        "isCorrect": false
      },
      {
        "id": 10806,
        "content": [
          "p ⇔ q and ¬p ⇔ ¬q"
        ],
        "isCorrect": true
      },
      {
        "id": 10807,
        "content": [
          "¬p ⇒ q and q ⇒ ¬p"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 2706,
    "content": [
      "If the 1st and 4th terms of a geometric progression are 3 and 81 respectively, what is the common ratio for this progression?"
    ],
    "explanation": [
      "Let the first term be a₁ and the common ratio be r. The nth term is given by\n$$\na_n = a_1 r^{n-1}\n$$",
      "We are given a₁ = 3 and a₄ = 81.",
      "Using the formula for the 4th term:\n$$\na_4 = a_1 r^{4-1} \\implies 81 = 3 \\cdot r^3\n$$\n$$\nr^3 = \\frac{81}{3} = 27\n$$\n$$\nr = \\sqrt{27} = 3\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10832,
        "content": [
          "1/3"
        ],
        "isCorrect": false
      },
      {
        "id": 10833,
        "content": [
          "9"
        ],
        "isCorrect": false
      },
      {
        "id": 10834,
        "content": [
          "1/9"
        ],
        "isCorrect": false
      },
      {
        "id": 10835,
        "content": [
          "3"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2714,
    "content": [
      "Consider the sequence whose terms are $$a_1 = 6$$, and $$a_{n+1} = -\\frac{1}{3}(a_n)$$ for n∈N. Then what is the sum of the first ten terms is"
    ],
    "explanation": [
      "The sequence is a geometric progression with first term a = a₁ = 6 and common ratio r = -1/3.",
      "The sum of the first n terms of a geometric series is given by the formula\n$$\nS_n = \\frac{a(1 - r^n)}{1 - r}\n$$",
      "We need to find S₁₀:\n$$\nS_{10} = \\frac{6(1 - (-1/3)^{10})}{1 - (-1/3)}\n$$\n$$\n= \\frac{6(1 - (-1/3)^{10})}{1 + 1/3} = \\frac{6(1 - (-1/3)^{10})}{4/3}\n$$\n$$\nS_{10} = 6 \\cdot \\frac{3}{4} \\left(1 - \\left(-\\frac{1}{3}\\right)^{10}\\right)\n$$\n$$\n= \\frac{18}{4}\\left(1 - \\left(-\\frac{1}{3}\\right)^{10}\\right)\n$$\n$$\n= \\frac{9}{2}\\left(1 - \\left(-\\frac{1}{3}\\right)^{10}\\right)\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10864,
        "content": [
          "$$9\\left(1 - \\left(-\\frac{1}{3}\\right)^{10}\\right)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10865,
        "content": [
          "$$\\frac{9}{2}\\left(1 - \\left(-\\frac{1}{3}\\right)^{10}\\right)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10866,
        "content": [
          "$$9\\left(1 - \\left(-\\frac{1}{3}\\right)^{11}\\right)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10867,
        "content": [
          "$$\\frac{9}{2}\\left(1 - \\left(-\\frac{1}{3}\\right)^{11}\\right)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2718,
    "content": [
      "The following graph is the graph of the function $$y = x^{m/n}$$, where m and n are positive integers and n ≠ 0.",
      "images/maths/year_2012/q36_1.png",
      "Which of the following is true about m and n?"
    ],
    "explanation": [
      "The curve starts at the origin and is only in the right half (x ≥ 0). This means the denominator n is even, because for even roots (like √x, ⁴√x), negative x-values are not allowed.",
      "The graph is steeper than y = x, meaning the exponent (m/n > 1). So (m > n).",
      "The graph is increasing (not reflected or inverted), meaning (m) is odd, not even."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2012/q36_1.png"
    ],
    "choices": [
      {
        "id": 10880,
        "content": [
          "m is odd, n is even and m > n."
        ],
        "isCorrect": true
      },
      {
        "id": 10881,
        "content": [
          "m is even, n is odd and m < n."
        ],
        "isCorrect": false
      },
      {
        "id": 10882,
        "content": [
          "m is odd, n is even and m < n."
        ],
        "isCorrect": false
      },
      {
        "id": 10883,
        "content": [
          "m is even, n is odd and m > n."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2722,
    "content": [
      "Given the function f(x) = 2x² - 3x + 1, what is the slope of the line passing through the points (-1, f(-1)) and (2, f(2))?"
    ],
    "explanation": [
      "This is asking for the slope of the secant line connecting two points on the function's graph.",
      "First, find the coordinates of the points:\n$$\nf(-1) = 2(-1)^2 - 3(-1) + 1 = 2 + 3 + 1 = 6. \\text{ Point is } (-1, 6).\n$$\n$$\nf(2) = 2(2)^2 - 3(2) + 1 = 8 - 6 + 1 = 3. \\text{ Point is } (2, 3).\n$$",
      "Now use the slope formula:\n$$\nm = \\frac{y_2 - y_1}{x_2 - x_1}\n$$\n$$\nm = \\frac{3 - 6}{2 - (-1)} = \\frac{-3}{3} = -1\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10896,
        "content": [
          "-1"
        ],
        "isCorrect": true
      },
      {
        "id": 10897,
        "content": [
          "-1/3"
        ],
        "isCorrect": false
      },
      {
        "id": 10898,
        "content": [
          "1/3"
        ],
        "isCorrect": false
      },
      {
        "id": 10899,
        "content": [
          "1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2726,
    "content": [
      "If z = -1+i and w = 1-3i, what is the simplified form of\n$$\n\\frac{5z}{w} + |z|^2w \\ \\text{?}\n$$"
    ],
    "explanation": [
      "First, calculate$$|z|^2$$:\n$$\n|z|^2 = (-1)^2 + (1)^2 = 1+1=2\n$$\nNext, calculate $$\\frac{5z}{w}$$:\n$$\n\\frac{5(-1+i)}{1-3i} = \\frac{5(-1+i)(1+3i)}{(1-3i)(1+3i)}\n$$\n$$\n= \\frac{5(-1-3i+i+3i^2)}{1^2 - (3i)^2}\n$$\n$$\n= \\frac{5(-1-2i-3)}{1+9} = \\frac{5(-4-2i)}{10}\n$$\n$$\n= \\frac{-4-2i}{2} = -2-i\n$$\nNow calculate $$|z|^2w$$:\n$$\n2(1-3i) = 2-6i\n$$\nFinally, add the two parts:\n$$\n(-2-i) + (2-6i) = -7i\n$$\nNote: The question on the paper doesn't include the correct choice, so we added the correct choice here."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10912,
        "content": [
          "4i"
        ],
        "isCorrect": false
      },
      {
        "id": 10913,
        "content": [
          "5i"
        ],
        "isCorrect": false
      },
      {
        "id": 10914,
        "content": [
          "-7i"
        ],
        "isCorrect": true
      },
      {
        "id": 10915,
        "content": [
          "4+5i"
        ],
        "isCorrect": true
      },
      {
        "id": 10916,
        "content": [
          "5+4i"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2730,
    "content": [
      "Let p and q be propositions with truth value True and False respectively. Then which of the following is correct?"
    ],
    "explanation": [
      "Given p is True (T) and q is False (F).",
      "A. (p ∨ ¬q) ⇒ q is (T ∨ ¬F) ⇒ F is (T ∨ T) ⇒ F is T ⇒ F, which is False.",
      "B. ¬p ⇒ q is ¬T ⇒ F is F ⇒ F, which is True.",
      "C. p ∨ (q ∧ ¬p) is T ∨ (F ∧ ¬T) is T ∨ (F ∧ F) is T ∨ F, which is True.",
      "D. (p ⇒ q) ∧ p is (T ⇒ F) ∧ T is F ∧ T, which is False.",
      "Therefore, the only correct statement is (C)."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10929,
        "content": [
          "(p ∨ ¬q) ⇒ q is True."
        ],
        "isCorrect": false
      },
      {
        "id": 10930,
        "content": [
          "¬p ⇒ q is False"
        ],
        "isCorrect": false
      },
      {
        "id": 10931,
        "content": [
          "p ∨ (q ∧ ¬p) is True."
        ],
        "isCorrect": true
      },
      {
        "id": 10932,
        "content": [
          "(p ⇒ q) ∧ p is True."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 2731,
    "content": [
      "Let $$f(x) = \\sqrt{x+2}$$ and $$g(x) = x^2 - 1$$. What are the domain and range of the composition of f with g, f∘g respectively?"
    ],
    "explanation": [
      "The composition is\n$$\n(f \\circ g)(x) = f(g(x))\n$$\n$$\n= \\sqrt{(x^2-1)+2} = \\sqrt{x^2+1}\n$$",
      "Domain: The expression inside the square root, x²+1, is always positive for any real number x. Therefore, the domain of f∘g is all real numbers, R.",
      "Range: The minimum value of x² is 0. So the minimum value of x²+1 is 1. The minimum value of $$\\sqrt{x^2+1}$$ is $$\\sqrt{1}=1$$. As x increases, the value increases without bound. So the range is [1, ∞)."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10933,
        "content": [
          "R and [1, ∞)"
        ],
        "isCorrect": true
      },
      {
        "id": 10934,
        "content": [
          "R and [0, ∞)"
        ],
        "isCorrect": false
      },
      {
        "id": 10935,
        "content": [
          "[0, ∞) and [1, ∞)"
        ],
        "isCorrect": false
      },
      {
        "id": 10936,
        "content": [
          "[0, ∞) and [0, ∞)"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2732,
    "content": [
      "Given a rational function $$f(x) = \\frac{2x+4}{x-1}$$ which of the following is NOT true about its graph? The graph has;"
    ],
    "explanation": [
      "Let's check each statement.",
      "A. Horizontal asymptote: Since the degrees of the numerator and denominator are equal, the asymptote is the ratio of the leading coefficients, y = 2/1 = 2. True.",
      "B. Vertical asymptote: This occurs where the denominator is zero, so x-1=0, which means x=1. True.",
      "C. y-intercept: Set x=0. f(0) = (2(0)+4)/(0-1) = 4/-1 = -4. The y-intercept is (0, -4). True.",
      "D. x-intercept: Set y=f(x)=0. This occurs when the numerator is zero. 2x+4=0 → 2x=-4 → x=-2. The x-intercept is (-2, 0). The statement says it is (-4, 0), which is false."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10937,
        "content": [
          "a horizontal asymptote, y = 2."
        ],
        "isCorrect": false
      },
      {
        "id": 10938,
        "content": [
          "a vertical asymptote, x = 1."
        ],
        "isCorrect": false
      },
      {
        "id": 10939,
        "content": [
          "y - intercept (0, -4)."
        ],
        "isCorrect": false
      },
      {
        "id": 10940,
        "content": [
          "x - intercept at (-4, 0)."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2738,
    "content": [
      "Which of the following is a zero for the function f(x) = x³ - 3x² + 3x - 1?"
    ],
    "explanation": [
      "The given function is a perfect cube. It matches the binomial expansion of (a-b)³ = a³ - 3a²b + 3ab² - b³.",
      "With a=x and b=1, we have f(x) = (x-1)³.",
      "A zero of the function is a value of x for which f(x)=0.\n$$\n(x-1)^3 = 0 \\implies x-1 = 0 \\implies x = 1\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10961,
        "content": [
          "0"
        ],
        "isCorrect": false
      },
      {
        "id": 10962,
        "content": [
          "1"
        ],
        "isCorrect": true
      },
      {
        "id": 10963,
        "content": [
          "-2"
        ],
        "isCorrect": false
      },
      {
        "id": 10964,
        "content": [
          "-1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2745,
    "content": [
      "Let f (x) = 3 - 2x. What is the inverse of f?"
    ],
    "explanation": [
      "To find the inverse function, let y = f(x), then swap x and y, and solve for y.",
      "Start with y = 3 - 2x.",
      "Swap variables: x = 3 - 2y.",
      "Solve for y:\n$$\n2y = 3 - x\n$$\n$$\ny = \\frac{3 - x}{2}\n$$\n$$\nf^{-1}(x) = \\frac{3-x}{2}\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10989,
        "content": [
          "f⁻¹(x) = 2x - 3"
        ],
        "isCorrect": false
      },
      {
        "id": 10990,
        "content": [
          "f⁻¹(x) = 3 + 2x"
        ],
        "isCorrect": false
      },
      {
        "id": 10991,
        "content": [
          "$$f^{-1}(x) = \\frac{x-3}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10992,
        "content": [
          "$$f^{-1}(x) = \\frac{3-x}{2}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  }
];

export default questions;
