// StudentPrep Free Content — guide-selected units, maximum 25 questions per unit.
const questions = [
  {
    "id": 402,
    "content": [
      "Which of the following CORRECTLY relates the vapor pressure of a liquid with its boiling point? Boiling point is"
    ],
    "explanation": [
      "The boiling point of a liquid is defined as the temperature at which its vapor pressure equals the external pressure surrounding the liquid."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1605,
        "content": [
          "the temperature at which all the three physical state co-exist."
        ],
        "isCorrect": false
      },
      {
        "id": 1606,
        "content": [
          "the temperature at which the vapor pressure becomes equal to the external pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 1607,
        "content": [
          "the temperature at which molecules present in the vapor phase go back to the liquid state."
        ],
        "isCorrect": false
      },
      {
        "id": 1608,
        "content": [
          "the temperature at which the kinetic energy of molecules is much less than the intermolecular force."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 404,
    "content": [
      "Which one of the following resulted from interaction of the atomic orbitals of bonding atoms to produce new electron distribution associated with the entire molecule?"
    ],
    "explanation": [
      "Molecular orbitals are formed from the interaction of atomic orbitals of bonding atoms, resulting in a new electron distribution associated with the entire molecule. This process is described by the molecular orbital theory."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1613,
        "content": [
          "Electron orbit"
        ],
        "isCorrect": false
      },
      {
        "id": 1614,
        "content": [
          "Bohr orbit"
        ],
        "isCorrect": false
      },
      {
        "id": 1615,
        "content": [
          "Hybrid orbital"
        ],
        "isCorrect": false
      },
      {
        "id": 1616,
        "content": [
          "Molecular orbital"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 406,
    "content": [
      "Which one of the following is the reducing agent in the following reaction?\n$$\n8NH_3 (g) +6NO_2 (g) \\rightarrow 7N_2 (g) + 12H_2O (l)\n$$"
    ],
    "explanation": [
      "In this reaction, ammonia ($$NH_3$$) is oxidized as its nitrogen changes from an oxidation state of -3 in $$NH_3$$ to 0 in $$N_2$$. This means $$NH_3$$ loses electrons and thus acts as the reducing agent."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1621,
        "content": [
          "$$NO_2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1622,
        "content": [
          "$$NH_3$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1623,
        "content": [
          "$$H_2O$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1624,
        "content": [
          "$$N_2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 408,
    "content": [
      "When a system at equilibrium is disturbed by a change of variable, the system shifts the equilibrium position in a way that tends to counteract this change of variable. This is a statement for"
    ],
    "explanation": [
      "Le Chatelier’s Principle states that if a dynamic equilibrium is disturbed by changing the conditions, the position of equilibrium shifts to counteract the change and reestablish equilibrium.\n\nThis principle helps predict how a system at equilibrium will respond to changes in concentration, temperature, or pressure."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1629,
        "content": [
          "Pauli's exclusion principle"
        ],
        "isCorrect": false
      },
      {
        "id": 1630,
        "content": [
          "Aufbau principle"
        ],
        "isCorrect": false
      },
      {
        "id": 1631,
        "content": [
          "Heisenberg uncertainty principle"
        ],
        "isCorrect": false
      },
      {
        "id": 1632,
        "content": [
          "Le Chatelier Principle"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 409,
    "content": [
      "Which one of the following graphs illustrates the rate change in terms of change in reactant concentration with time?"
    ],
    "explanation": [
      "The correct graph shows a curve that starts high and decreases rapidly at first, then levels off as it approaches the horizontal axis.\n\nThis indicates a rapid initial decrease in reactant concentration, which slows down over time."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1633,
        "content": [
          "images/chemistry/year_2015/q9c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1634,
        "content": [
          "images/chemistry/year_2015/q9c2_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 1635,
        "content": [
          "images/chemistry/year_2015/q9c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1636,
        "content": [
          "images/chemistry/year_2015/q9c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Acid Base Equilibria"
  },
  {
    "id": 410,
    "content": [
      "Which one of the following gas laws states the volume of a fixed amount of gas maintained at constant pressure is directly proportional to the absolute temperature of the gas?"
    ],
    "explanation": [
      "Charles' law states that the volume of a fixed amount of gas is directly proportional to its absolute temperature, provided the pressure remains constant.\n$$\n\\frac{V_1}{T_1} = \\frac{V_2}{T_2}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1637,
        "content": [
          "Charles' law"
        ],
        "isCorrect": true
      },
      {
        "id": 1638,
        "content": [
          "Boyle's law"
        ],
        "isCorrect": false
      },
      {
        "id": 1639,
        "content": [
          "Avogadro's law"
        ],
        "isCorrect": false
      },
      {
        "id": 1640,
        "content": [
          "Combined gas law"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 412,
    "content": [
      "A system does 15 J of work and no other changes take place. Which of the following function has fallen by 15 J?"
    ],
    "explanation": [
      "When a system does work, it loses energy. Since no other changes take place, the work done by the system (15 J) results in a decrease in its internal energy by the same amount. Therefore, the internal energy has fallen by 15 J."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1645,
        "content": [
          "Internal energy"
        ],
        "isCorrect": true
      },
      {
        "id": 1646,
        "content": [
          "Specific heat"
        ],
        "isCorrect": false
      },
      {
        "id": 1647,
        "content": [
          "Enthalpy"
        ],
        "isCorrect": false
      },
      {
        "id": 1648,
        "content": [
          "Entropy"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 413,
    "content": [
      "Which of the following is CORRECTLY stated about the spontaneity of a reaction?"
    ],
    "explanation": [
      "To determine the spontaneity of a reaction, we use the Gibbs free energy equation:\n\n$$\n\\Delta G = \\Delta H - T \\Delta S\n$$\n\nWhere:\n\n- $$\\Delta G$$ is the change in Gibbs free energy,\n- $$\\Delta H$$ is the change in enthalpy,\n- T is the temperature in Kelvin, and\n- $$\\Delta S$$ is the change in entropy.\n\nA reaction is **spontaneous** if $$\\Delta G < 0$$.\n\nFor an endothermic reaction ($$\\Delta H > 0$$) with positive reaction entropy ($$\\Delta S > 0$$), at low temperatures, $$T \\Delta S$$ is small, and $$\\Delta G$$ will be positive. Thus, the reaction is non-spontaneous at low temperatures. At higher temperatures, $$T \\Delta S$$ can dominate, potentially making $$\\Delta G$$ negative, leading to spontaneity."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1649,
        "content": [
          "For an endothermic reaction with negative reaction entropy, the reaction is spontaneous at all temperature."
        ],
        "isCorrect": false
      },
      {
        "id": 1650,
        "content": [
          "For an exothermic reaction with positive reaction entropy, the reaction is non-spontaneous at all temperature."
        ],
        "isCorrect": false
      },
      {
        "id": 1651,
        "content": [
          "For an endothermic reaction with positive reaction entropy, the reaction is non-spontaneous at low temperature."
        ],
        "isCorrect": true
      },
      {
        "id": 1652,
        "content": [
          "For an exothermic reaction with negative reaction entropy, the reaction is spontaneous at high temperature."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 414,
    "content": [
      "In thermodynamics: solutions in a beaker, a gas in a cylinder, a reaction vessel, a biological cell are examples of a"
    ],
    "explanation": [
      "A thermodynamic system is a specific portion of matter or a space where thermodynamic processes occur and are studied."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1653,
        "content": [
          "thermodynamic variables"
        ],
        "isCorrect": false
      },
      {
        "id": 1654,
        "content": [
          "state function"
        ],
        "isCorrect": false
      },
      {
        "id": 1655,
        "content": [
          "path function"
        ],
        "isCorrect": false
      },
      {
        "id": 1656,
        "content": [
          "thermodynamic system"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 416,
    "content": [
      "The rate law for: $$(CH_3)_3 \\text{-} C \\text{-} Br (aq)$$ + $$H_2O (l)$$ $$\\rightarrow$$ $$(CH_3)_3 \\text{-} C \\text{-} OH (aq)$$ + $$H^+$$ + $$Br^ \\text{-} (aq)$$ is rate= $$k [(CH_3)_3 \\text{-} C \\text{-} Br]$$.\n\nThe accepted mechanism for the reaction is\n\nI. $$(CH_3)_3 \\text{-} C \\text{-} Br(aq)$$ $$\\rightarrow$$ $$(CH_3)_3 \\text{-} C^+(aq)$$ + $$Br^-(aq)$$ [slow]\n\nII. $$(CH_3)_3 \\text{-} C^+(aq)$$ + $$H_2O(l)$$ $$\\rightarrow$$ $$(CH_3)_3 \\text{-} C \\text{-} OH_2^+ (aq)$$ [fast]\n\nIII. $$(CH_3)_3 \\text{-} C \\text{-} OH_2^+ (aq)$$ $$\\rightarrow$$ $$H^+$$+ $$(CH_3)_3 \\text{-} C \\text{-} OH(aq)$$ [fast]\n\nWhy DOES NOT $$H_2O$$ appear in the rate law? Beacuse"
    ],
    "explanation": [
      "The rate law is determined by the rate-determining step, which is the slowest step in the reaction mechanism.\n\nIn the given mechanism, the first step (I) is the slow step. Since this step does not involve water, water does not appear in the rate law. The species that participate in the slow step are what determine the rate law."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1661,
        "content": [
          "water is a catalyst in the reaction."
        ],
        "isCorrect": false
      },
      {
        "id": 1662,
        "content": [
          "water is an intermediate species."
        ],
        "isCorrect": false
      },
      {
        "id": 1663,
        "content": [
          "water exists in the liquid state in the reaction."
        ],
        "isCorrect": false
      },
      {
        "id": 1664,
        "content": [
          "water is missing in the rate determining step."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 418,
    "content": [
      "The rate law for this reaction\n$$\nCO (g) + NO_2 (g) \\rightarrow CO+2 (g) + NO (g)\n$$\nis rate = $$k[NO_2]^2$$.\n\nWhich one of the following could be a plausible mechanism for the reaction?"
    ],
    "explanation": [
      "For this rate law, the rate-determining step (slow step) must involve two molecules of $$NO_2$$.\n\nThe correct choice is:\n\n$$\nNO_2(g) + NO_2(g) \\rightarrow NO_3(g) + NO(g) \\ \\text{[slow]}\n$$\n\n$$\nNO_3(g) + CO(g) \\rightarrow NO_2(g) + CO_2(g) \\ \\text{[fast]}\n$$\n\nSince the slow step involves two molecules of $$NO_2$$, the rate law for the slow step is:\n$$\n\\text{rate} = k[NO_2]^2\n$$\n\nOther options involve different steps as the slow step, but they do not yield the correct rate law involving $$[NO_2]^2$$."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1669,
        "content": [
          "$$NO_2(g)$$ + $$NO_2 (g)$$ $$\\rightarrow$$ $$NO_3 (g)$$ + $$NO (g)$$ [slow]",
          "$$NO_3(g)$$ + $$CO (g)$$ $$\\rightarrow$$ $$NO_2 (g)$$ + $$CO_2(g)$$ [fast]"
        ],
        "isCorrect": true
      },
      {
        "id": 1670,
        "content": [
          "$$NO_3(g)$$ + $$NO (g)$$ $$\\rightarrow$$ $$NO_2 (g)$$ + $$NO_2 (g)$$ [slow]",
          "$$NO_3(g)$$ + $$CO (g)$$ $$\\rightarrow$$ $$NO_2 (g)$$ + $$CO_2 (g)$$ [fast]"
        ],
        "isCorrect": false
      },
      {
        "id": 1671,
        "content": [
          "$$NO_3 (g)$$ + $$NO (g)$$ $$\\rightarrow$$ $$NO_2(g)$$ + $$NO_2 (g)$$ [slow]",
          "$$NO_2 (g)$$ + $$CO_2 (g)$$ $$\\rightarrow$$ $$NO_3 (g)$$ + $$CO (g)$$ [fast]"
        ],
        "isCorrect": false
      },
      {
        "id": 1672,
        "content": [
          "$$NO_2 (g)$$ + $$NO_2 (g)$$ $$\\rightarrow$$ $$NO_3 (g)$$ + $$NO (g)$$ [fast]",
          "$$NO_3 (g)$$ + $$CO (g)$$ $$\\rightarrow$$ $$NO_2 (g)$$ + $$CO_2 (g)$$ [slow]"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 419,
    "content": [
      "The speed with which a solute goes into solution is"
    ],
    "explanation": [
      "The rate of dissolution refers to how quickly a solute dissolves in a solvent."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1673,
        "content": [
          "degree of solvation"
        ],
        "isCorrect": false
      },
      {
        "id": 1674,
        "content": [
          "heat of solution"
        ],
        "isCorrect": false
      },
      {
        "id": 1675,
        "content": [
          "rate of dissolution"
        ],
        "isCorrect": true
      },
      {
        "id": 1676,
        "content": [
          "extent of dissolution"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 420,
    "content": [
      "Which one of the following explains how 2 L of 1 M NaOH aqueous stock solution is converted into a 0.25 M NaOH solution?"
    ],
    "explanation": [
      "The dilution formula is:\n\n$$\nM_1 \\times V_1 = M_2 \\times V_2\n$$\n\n$$\n1 \\times 2 = 0.25 \\times V_2\n$$\n\n$$\nV_2 = \\frac{2}{0.25} = 8 \\, \\text{L}\n$$\n\nSo, the final volume $$V_2$$ should be 8 L. To achieve this, you need to add water to the initial 2 L solution to make up the total volume to 8 L. Therefore, you need to add:\n\n$$\n8 \\, \\text{L} - 2 \\, \\text{L} = 6 \\, \\text{L}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1677,
        "content": [
          "Adding 6 L water to the stock solution"
        ],
        "isCorrect": true
      },
      {
        "id": 1678,
        "content": [
          "Adding 8 L water to the stock solution"
        ],
        "isCorrect": false
      },
      {
        "id": 1679,
        "content": [
          "Evaporating 0.25 L of water from the stock solution"
        ],
        "isCorrect": false
      },
      {
        "id": 1680,
        "content": [
          "Evaporating 1 L of water from the stock solution"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 421,
    "content": [
      "Which one of the following IS TRUE about isotopes?"
    ],
    "explanation": [
      "Isotopes of an element have the same number of protons and electrons, which means they have the same chemical properties. However, they differ in the number of neutrons, leading to different mass numbers."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1681,
        "content": [
          "Isotopes of an element are identical in mass number."
        ],
        "isCorrect": false
      },
      {
        "id": 1682,
        "content": [
          "Isotopes of the same elements contain the same number of neutrons."
        ],
        "isCorrect": false
      },
      {
        "id": 1683,
        "content": [
          "Isotopes of an element have the same chemical properties."
        ],
        "isCorrect": true
      },
      {
        "id": 1684,
        "content": [
          "Isotopes of an element are atoms that have different number of electrons and protons."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 422,
    "content": [
      "Which one of the following describes the quantum mechanical model?"
    ],
    "explanation": [
      "The quantum mechanical model of the atom describes the behavior of electrons in terms of probabilities rather than fixed paths. This model indicates that electrons do not follow precise orbits but are found within regions called orbitals, where there is a high probability of locating them."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1685,
        "content": [
          "The locations of electrons in an atom are described in terms of probability."
        ],
        "isCorrect": true
      },
      {
        "id": 1686,
        "content": [
          "An atom is represented by a solid indestructible sphere."
        ],
        "isCorrect": false
      },
      {
        "id": 1687,
        "content": [
          "An atom is a sphere with a positively charged matter, in which electrons are embedded."
        ],
        "isCorrect": false
      },
      {
        "id": 1688,
        "content": [
          "Electrons moved around the nucleus of an atom in circular orbits."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 423,
    "content": [
      "Which one of the following is the diagrammatic representation of $$_{17}^{35}Cl$$?"
    ],
    "explanation": [
      "The correct arrangement is 17 protons and 18 neutrons (35 - 17), with 2 electrons in the first shell, 8 in the second, and 7 in the third."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1689,
        "content": [
          "images/chemistry/year_2015/q23c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1690,
        "content": [
          "images/chemistry/year_2015/q23c2_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 1691,
        "content": [
          "images/chemistry/year_2015/q23c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1692,
        "content": [
          "images/chemistry/year_2015/q23c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 426,
    "content": [
      "Which of the properties of solvents WOULD NOT be affected by the formation of a solution with a non-volatile solute?"
    ],
    "explanation": [
      "The chemical identity of a solvent remains unchanged by the formation of a solution, as the solvent retains its molecular structure and composition. However, properties like boiling point, chemical potential, and freezing point would be affected when a non-volatile solute is added."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1701,
        "content": [
          "Boiling Point"
        ],
        "isCorrect": false
      },
      {
        "id": 1702,
        "content": [
          "Chemical potential"
        ],
        "isCorrect": false
      },
      {
        "id": 1703,
        "content": [
          "Chemical identity"
        ],
        "isCorrect": true
      },
      {
        "id": 1704,
        "content": [
          "Freezing Point"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 427,
    "content": [
      "The partial pressure of acetylene, $$C_2H_2$$, in a container is 10 atm at 25°C. What is the solubility in molarity of $$C_2H_2$$, assume that $$C_2H_2$$ obeys Henry's law? ($$K_H$$ = $$1.04 \\ \\text{mol/L atm}$$)"
    ],
    "explanation": [
      "Using Henry's Law:\n\n$$\nC = K_H \\cdot P\n$$\n\nWhere\n\n- C is the solubility in mol/L\n- $$K_H$$ is the Henry's law constant\n- P is the partial pressure of the gas.\n\n$$\nC = (1.04 \\ \\text{mol/L atm}) \\times (10 \\ \\text{atm}) = 10.4 \\ \\text{mol/L}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1705,
        "content": [
          "0.104"
        ],
        "isCorrect": false
      },
      {
        "id": 1706,
        "content": [
          "9.62"
        ],
        "isCorrect": false
      },
      {
        "id": 1707,
        "content": [
          "104"
        ],
        "isCorrect": false
      },
      {
        "id": 1708,
        "content": [
          "10.4"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 428,
    "content": [
      "What is the normality of a solution that contains 19.6 g of $$H_2SO_4$$, in 20 mL of the solution?"
    ],
    "explanation": [
      "$$\nN = \\frac{\\text{Weight of Solute (g)}}{\\text{Equivalent Weight of Solute (g/eq)} \\times \\text{Volume of Solution (L)}}\n$$\n\nGiven:\n\n- Weight of  $$H_2SO_4$$ = 19.6 g\n- Volume of solution = 20 mL = 0.02 L\n\nThe molecular weight of  $$H_2SO_4$$ is 98 g/mol, and since  $$H_2SO_4$$ has 2 hydrogen ions (H⁺), its equivalent weight is:\n\n$$\n\\text{Equivalent Weight} = \\frac{\\text{Molecular Weight}}{\\text{Number of H⁺ ions}} = \\frac{98}{2} = 49 \\text{ g/eq}\n$$\n\nCalculate the normality:\n\n$$\nN = \\frac{19.6 \\text{ g}}{49 \\text{ g/eq} \\times 0.02 \\text{ L}} = 20 \\text{ N}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1709,
        "content": [
          "0.02"
        ],
        "isCorrect": false
      },
      {
        "id": 1710,
        "content": [
          "0.01"
        ],
        "isCorrect": false
      },
      {
        "id": 1711,
        "content": [
          "20"
        ],
        "isCorrect": true
      },
      {
        "id": 1712,
        "content": [
          "10"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 429,
    "content": [
      "Which one of the following illustrates an extensive property?"
    ],
    "explanation": [
      "An extensive property is one that depends on the amount of matter or size of the system. If a system is divided into parts, the value of an extensive property for the entire system will be the sum of the values of that property for all the individual parts.\n\nExamples of extensive properties include mass, volume, and total energy. This behavior distinguishes extensive properties from intensive properties, which remain the same regardless of the system's size or amount of matter."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1713,
        "content": [
          "The electrode potential at standard condition for the half-reaction $$2Cu^{2+}$$ + $$4e^-$$ $$\\rightarrow$$ $$2Cu$$ is the same as for $$Cu^{2+}$$ + $$2e^-$$ $$\\rightarrow$$ $$2Cu$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1714,
        "content": [
          "If a system is divided into parts and it is found that the property of the complete system has a value that is the sum of the values of the property of all the parts."
        ],
        "isCorrect": true
      },
      {
        "id": 1715,
        "content": [
          "Doubling the volume of a sample also doubles the mass; so the ratio of mass to volume remains the same."
        ],
        "isCorrect": false
      },
      {
        "id": 1716,
        "content": [
          "If water in two beakers at the same temperature are mixed to make a single quantity of water and the temperature of the combined quantity of water is the same as it was in the two separate beakers."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 430,
    "content": [
      "The point in a titration at which the number of moles of $$OH^-$$ ions added to a solution is equal to the number of moles of $$H^+$$ ions originally present is"
    ],
    "explanation": [
      "In a titration, the **equivalence point** is reached when the amount of titrant added (in this case, the base containing $$OH^-$$ ions) is stoichiometrically equivalent to the amount of substance being titrated (the acid containing $$H^+$$ ions).\n\nAt this point, the number of moles of $$OH^-$$ ions is equal to the number of moles of $$H^+$$ ions in the solution. This indicates that the acid has been completely neutralized by the base."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1717,
        "content": [
          "Zero point"
        ],
        "isCorrect": false
      },
      {
        "id": 1718,
        "content": [
          "End point"
        ],
        "isCorrect": false
      },
      {
        "id": 1719,
        "content": [
          "Triple point"
        ],
        "isCorrect": false
      },
      {
        "id": 1720,
        "content": [
          "Equivalence point"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 438,
    "content": [
      "Which one of the following shows the hybridization scheme of the central atom in $$H_2O$$?"
    ],
    "explanation": [
      "- In water, oxygen has two lone pairs of electrons and forms two sigma bonds with hydrogen atoms.\n- Oxygen's ground state electron configuration is $$1s^2 2s^2 2p^4$$, where two electrons in the 2p orbitals are unpaired and the other two are paired.\n- During $$sp^3$$ hybridization, one s orbital and three p orbitals combine to form four sp³ hybrid orbitals. Two of these orbitals will contain lone pairs of electrons, while the other two will contain single electrons to form bonds with hydrogen."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1749,
        "content": [
          "images/chemistry/year_2015/q38c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1750,
        "content": [
          "images/chemistry/year_2015/q38c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1751,
        "content": [
          "images/chemistry/year_2015/q38c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1752,
        "content": [
          "images/chemistry/year_2015/q38c4_1.png"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 439,
    "content": [
      "In which of the following order of a reaction, a plot of $$ln [A]_t$$ versus time is a straight line whose slope is - k?"
    ],
    "explanation": [
      "For a first-order reaction, the integrated rate law is expressed as:\n\n$$\n\\ln [A]_t = -kt + \\ln [A]_0\n$$\n\nWhen plotting $$\\ln [A]_t$$ versus time (t), the equation takes the form of a straight line y = mx + b, where:\n\n- y is $$\\ln [A]_t$$,\n- m (the slope) is $$-k$$, and\n- b (the y-intercept) is $$\\ln [A]_0$$."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1753,
        "content": [
          "First"
        ],
        "isCorrect": true
      },
      {
        "id": 1754,
        "content": [
          "Zero"
        ],
        "isCorrect": false
      },
      {
        "id": 1755,
        "content": [
          "Third"
        ],
        "isCorrect": false
      },
      {
        "id": 1756,
        "content": [
          "Second"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 440,
    "content": [
      "A forward and reverse reaction continues to take place at equal rate in microscopic level without change in composition at macroscopic level. This statement is the definition of"
    ],
    "explanation": [
      "Dynamic equilibrium refers to the state in which the forward and reverse reactions occur at the same rate, leading to no net change in the concentrations of reactants and products at the macroscopic level. While the reactions continue to happen on a microscopic level, the overall system appears stable and unchanged over time."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1757,
        "content": [
          "Chemical kinetics"
        ],
        "isCorrect": false
      },
      {
        "id": 1758,
        "content": [
          "Dynamic equilibrium"
        ],
        "isCorrect": true
      },
      {
        "id": 1759,
        "content": [
          "Degree of freedom"
        ],
        "isCorrect": false
      },
      {
        "id": 1760,
        "content": [
          "The law of mass action"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 441,
    "content": [
      "The heat change at constant pressure that results when 1 mole of a compound is formed from its elements in their standard states is"
    ],
    "explanation": [
      "The standard enthalpy of formation is defined as the heat change that occurs at constant pressure when one mole of a compound is formed from its elements in their standard states.\n$$\n\\Delta H_f^\\circ = \\sum \\Delta H_f^\\circ (\\text{products}) - \\sum \\Delta H_f^\\circ (\\text{reactants})\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1761,
        "content": [
          "standard entropy of reaction"
        ],
        "isCorrect": false
      },
      {
        "id": 1762,
        "content": [
          "standard enthalpy of reaction"
        ],
        "isCorrect": false
      },
      {
        "id": 1763,
        "content": [
          "standard reduction potential"
        ],
        "isCorrect": false
      },
      {
        "id": 1764,
        "content": [
          "standard enthalpy of formation"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 442,
    "content": [
      "What is a redox reaction? It is a reaction in which"
    ],
    "explanation": [
      "A redox reaction involves the transfer of electrons between two chemical species. In these reactions, one species loses electrons (is oxidized), while the other gains electrons (is reduced)."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1765,
        "content": [
          "two insoluble ions in compounds form an insoluble products."
        ],
        "isCorrect": false
      },
      {
        "id": 1766,
        "content": [
          "electrons are transferred between species."
        ],
        "isCorrect": true
      },
      {
        "id": 1767,
        "content": [
          "atoms or ions of two compound exchange bonding partners."
        ],
        "isCorrect": false
      },
      {
        "id": 1768,
        "content": [
          "an acid and a base neutralize each other."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 444,
    "content": [
      "How does the equivalent mass of a base is obtained?"
    ],
    "explanation": [
      "The equivalent mass of a base is defined as the mass of the base that can furnish one mole of hydroxide ions ($$OH^-$$) in a reaction. To calculate it, you take the molar mass of the base and divide it by the number of hydroxide ions produced per formula unit. This gives you the equivalent mass.\n$$\n\\text{Equivalent mass} = \\frac{\\text{Molar mass}}{\\text{Number of } OH^- \\text{ ions}}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1773,
        "content": [
          "By multiplying its molar mass by the number of $$OH^-$$ ions furnished by one formula unit of a base."
        ],
        "isCorrect": false
      },
      {
        "id": 1774,
        "content": [
          "By dividing its molar mass by the number of $$OH^-$$ ions furnished by one formula unit of a base."
        ],
        "isCorrect": true
      },
      {
        "id": 1775,
        "content": [
          "By multiplying its number of equivalent by the number of $$OH^-$$ ions furnished by one formula unit of a base."
        ],
        "isCorrect": false
      },
      {
        "id": 1776,
        "content": [
          "By dividing its number of equivalent by the number of $$OH^-$$ ions furnished by one formula unit of a base."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 445,
    "content": [
      "Which one of the following reactions would occur spontaneously in an aqueous solution at 25°C? Assume that the initial concentrations of the dissolved species are all 1.0M.",
      "images/chemistry/year_2015/q45_1.png"
    ],
    "explanation": [
      "A reaction is spontaneous if the cell potential is positive. The overall cell potential is given by:\n\n$$\nE°_{\\text{cell}} = E°_{\\text{cathode}} - E°_{\\text{anode}}\n$$\n\nOption: $$2Br^- (aq)$$ + $$Sn^{2+} (aq)$$ $$\\rightarrow$$ $$Br_2 (l)$$ + $$Sn (s)$$\n\n**Cathode**:\n$$\nBr_2 + 2e^- \\rightarrow 2Br^- (E° = -1.07 V)\n$$\nThe half-reaction is reversed thus we use −1.07 V.\n\n**Anode**:\n$$\nSn^{2+} + 2e^- \\rightarrow Sn \\quad (E° = -0.14 \\, \\text{V})\n$$\n\n$$\nE°_{\\text{cell}} = (-1.07) - (-0.14) = -0.93 \\, \\text{V} \\quad \\text{(Non-spontaneous)}\n$$\nOption: $$2Ag (s)$$ + $$Ni^{2+} (aq)$$ $$\\rightarrow$$ $$2Ag^+ (aq)$$ + $$Ni (s)$$\n\n**Cathode**:\n\n$$\nNi^{2+} + 2e^- \\rightarrow Ni \\quad (E° = -0.25 \\, \\text{V})\n$$\n**Anode**:\n\n$$\n2Ag \\rightarrow 2Ag^+ + 2e^- \\quad (E° = -1.6 \\, \\text{V})\n$$\nThe half-reaction is for 2 moles so we use (0.8 * 2) = −1.5 V.\n$$\nE°_{\\text{cell}} = (−0.25 V) - (−0.16 V) = −0.09 V \\, \\text{V} \\quad \\text{(Non-spontaneous)}\n$$\nOption: $$Ca (s)$$ + $$Cd^{2+} (aq)$$ $$\\rightarrow$$ $$Ca^{2+} (aq)$$ + $$Cd (s)$$\n\n**Anode**:\n\n$$\nCa \\rightarrow Ca^{2+} + 2e^- \\quad (E° = 2.87 \\, \\text{V})\n$$\nThe half-reaction is reversed thus we use 2.87 V.\n\n**Cathode**:\n$$\nCd^{2+} + 2e^- \\rightarrow Cd \\quad (E° = -0.40 \\, \\text{V})\n$$\n\n$$\nE°_{\\text{cell}} = (-0.40) - (-2.87) = - 3.27 V \\, \\text{V} \\quad \\text{(Non-spontaneous)}\n$$\nOption: $$Cu^{2+} (aq)$$ + $$Fe^{2+} (aq)$$ $$\\rightarrow$$ $$Cu^+ (aq)$$ + $$Fe^{3+} (aq)$$\n\n**Cathode**:\n\n$$\nCu+(E°=+0.15 V)Cu^{2+} + e^- \\rightarrow Cu^{+} \\quad (E° = +0.15 \\, \\text{V})\n$$\n\n**Anode**:\n$$\nFe^{2+} \\rightarrow Fe^{3+} + e^- \\quad (E° = -0.77 \\, \\text{V})\n$$\nThe half-reaction is reversed thus we use -0.77 V.\n\n$$\nE°_{\\text{cell}} = 0.15 - (-0.77) = +0.92 \\, \\text{V} \\quad \\text{(Spontaneous)}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2015/q45_1.png"
    ],
    "choices": [
      {
        "id": 1777,
        "content": [
          "$$2Br^- (aq)$$ + $$Sn^{2+} (aq)$$ $$\\rightarrow$$ $$Br_2 (l)$$ + $$Sn (s)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1778,
        "content": [
          "$$2Ag (s)$$ + $$Ni^{2+} (aq)$$ $$\\rightarrow$$ $$2Ag^+ (aq)$$ + $$Ni (s)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1779,
        "content": [
          "$$Ca (s)$$ + $$Cd^{2+} (aq)$$ $$\\rightarrow$$ $$Ca^{2+} (aq)$$ + $$Cd (s)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1780,
        "content": [
          "$$Cu^{2+} (aq)$$ + $$Fe^{2+} (aq)$$ $$\\rightarrow$$ $$Cu^+ (aq)$$ + $$Fe^{3+} (aq)$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 446,
    "content": [
      "Which of the following statements describes chemical industries? It is"
    ],
    "explanation": [
      "Industrial chemistry applies procedures to transform natural raw materials into beneficial products. This branch of chemistry bridges the gap between theoretical chemistry and its practical commercial application."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1781,
        "content": [
          "an area of chemistry concerned with the speeds, or rates, at which chemical reactions occur."
        ],
        "isCorrect": false
      },
      {
        "id": 1782,
        "content": [
          "the symbols of the atoms of the elements involved."
        ],
        "isCorrect": false
      },
      {
        "id": 1783,
        "content": [
          "an expression for the chemical composition of a compound in terms of a process in which dissolved solute comes out of solution and forms crystals."
        ],
        "isCorrect": false
      },
      {
        "id": 1784,
        "content": [
          "a firm that involves usage of raw material to produce desired products by using chemical reactions and refining methods."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 447,
    "content": [
      "What will be the product if phosphorus reacts with excess amount of oxygen?"
    ],
    "explanation": [
      "Phosphorus reacts with oxygen in two main ways, depending on the amount of oxygen present:\n- **Limited oxygen:** Forms tetraphosphorus hexoxide ($$P_4O_6$$)\n- **Excess oxygen:** Forms tetraphosphorus decoxide ( $$P_4O_{10}$$)"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1785,
        "content": [
          "$$H_3PO_3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1786,
        "content": [
          "$$H_3PO_4$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1787,
        "content": [
          "$$P_4O_{10}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1788,
        "content": [
          "$$P_4O_6$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Acid Base Equilibria"
  },
  {
    "id": 450,
    "content": [
      "The number of digits to the right of the decimal point denotes:"
    ],
    "explanation": [
      "The number of digits to the right of the decimal point indicates the decimal places in a number.\n\nSignificant figures represent the precision of a measurement and include all certain digits plus one uncertain digit.\n\nConversion factors are used to convert between different units of measurement, such as converting meters to kilometers.\n\nScientific notation is a way to express very large or small numbers using powers of ten."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1797,
        "content": [
          "Significant figures"
        ],
        "isCorrect": false
      },
      {
        "id": 1798,
        "content": [
          "Decimal places"
        ],
        "isCorrect": true
      },
      {
        "id": 1799,
        "content": [
          "Conversion factor"
        ],
        "isCorrect": false
      },
      {
        "id": 1800,
        "content": [
          "Scientific notation"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 454,
    "content": [
      "Which one of the following reactions creates energy in our bodies during respiration?"
    ],
    "explanation": [
      "$$\nC_6H_{12}O_6 (s) + 6O_2 (g) \\rightarrow 6CO_2 (g) + 6H_2O (l)\n$$\nThis equation represents the process of cellular respiration, where glucose is broken down in the presence of oxygen to produce carbon dioxide, water and energy in the form of ATP. This reaction is exothermic, meaning it releases energy."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1813,
        "content": [
          "$$C_6H_{12}O_6 (s)$$ + $$6O_2 (g)$$ $$\\rightarrow$$ $$6CO_2 (g)$$ + $$6H_2O (l)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1814,
        "content": [
          "$$6CO_2 (g)$$ + $$6H_2O (l)$$ $$\\rightarrow$$  $$C_6H_{12}O_6 (s)$$ + $$6O2 (g)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1815,
        "content": [
          "$$C_6H_{12}O_6 (s)$$ $$\\rightarrow$$ $$2C_2H_5OH (l)$$ + $$2CO_2 (g)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1816,
        "content": [
          "$$N_2H_4CO (g)$$ + $$H_2O (g)$$ $$\\rightarrow$$ $$2NH_3 (l)$$ + $$CO_2 (g)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 455,
    "content": [
      "\"A reaction that involves the exchange of positive and negative ions of each reactant\". This is a definition of a"
    ],
    "explanation": [
      "A double displacement reaction is defined as a reaction in which two compounds react to form two new compounds by exchanging the positive and negative ions of each reactant.\n\nDecomposition reaction: This involves the breakdown of a single compound into two or more elements or simpler compounds.\n\nCombination reaction: This involves two or more substances combining to form a single product.\n\nSingle displacement reaction: In this reaction, a more reactive element displaces a less reactive element from a compound."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1817,
        "content": [
          "Decomposition reaction"
        ],
        "isCorrect": false
      },
      {
        "id": 1818,
        "content": [
          "Combination reaction"
        ],
        "isCorrect": false
      },
      {
        "id": 1819,
        "content": [
          "Double displacement reaction"
        ],
        "isCorrect": true
      },
      {
        "id": 1820,
        "content": [
          "Single displacement reaction"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 456,
    "content": [
      "What are the four quantum numbers for an electron in a 2s orbital?"
    ],
    "explanation": [
      "The four quantum numbers and their values for an electron in a 2s orbital are:\n\n- **Principal quantum number (n):** This number represents the electron's energy level. For a 2s orbital, n = **2**.\n- **Angular momentum quantum number (ℓ):** This number indicates the shape of the orbital and has values ranging from 0 to n-1. For n = 2, the possible values of ℓ are 0 and 1. ℓ = 0 corresponds to an s orbital, and ℓ = 1 corresponds to a p orbital. Therefore, for a 2s orbital, ℓ = 0.\n- **Magnetic quantum number (mℓ):** This number describes the orbital's orientation in space. It can take on integer values from -ℓ to +ℓ, including 0. Since ℓ = 0 for a 2s orbital, the only possible value for mℓ is **0**.\n- **Spin quantum number (ms):** This number designates the electron's intrinsic spin. It can have two possible values: **+½** or -½. The problem specifies the electron has a spin of +½."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1821,
        "content": [
          "$$2$$, $$1$$, $$0$$, $$+\\frac{1}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1822,
        "content": [
          "$$2$$, $$1$$, $$1$$, $$+\\frac{1}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1823,
        "content": [
          "$$2$$, $$0$$, $$0$$, $$+\\frac{1}{2}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1824,
        "content": [
          "$$2$$, $$0$$, $$1$$, $$+\\frac{1}{2}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 457,
    "content": [
      "A student uses a digital balance (±0.02), a thermometer (±0.1), a measuring cylinder (+0.05), and a beaker (±0.5) during an experiment. Which of the above instrument is more precise?"
    ],
    "explanation": [
      "The **digital balance (±0.02)** is the most precise instrument among the given options.\n\n- **Precision** refers to the closeness of multiple measurements to each other. In simpler terms, a precise instrument will give very similar readings if you measure the same thing multiple times.\n- **Uncertainty** in a measurement indicates the range within which the true value likely lies. A lower uncertainty value means the instrument is more precise."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1825,
        "content": [
          "The thermometer"
        ],
        "isCorrect": false
      },
      {
        "id": 1826,
        "content": [
          "The digital balance"
        ],
        "isCorrect": true
      },
      {
        "id": 1827,
        "content": [
          "The Beaker"
        ],
        "isCorrect": false
      },
      {
        "id": 1828,
        "content": [
          "The measuring cylinder"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 458,
    "content": [
      "Which one of the following explains that light has BOTH wave and particle nature?"
    ],
    "explanation": [
      "Electromagnetic radiation (EMR) can be understood as a stream of particles called photons.\n\nEach photon carries energy (E) that is directly proportional to its frequency (ν), represented by the equation E = hν, where h is Planck's constant. This concept of quantized energy packets demonstrates the particle-like nature of light."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1829,
        "content": [
          "A beam of light is a stream of particles of electromagnetic energy, with energy proportional to the observed frequency of the light."
        ],
        "isCorrect": true
      },
      {
        "id": 1830,
        "content": [
          "An electron that is bound to the nucleus behaves like a standing wave and its position is given in terms of probability."
        ],
        "isCorrect": false
      },
      {
        "id": 1831,
        "content": [
          "Microscopic systems, such as atoms and molecules can possess wave properties."
        ],
        "isCorrect": false
      },
      {
        "id": 1832,
        "content": [
          "Light consists of electromagnetic waves which have an oscillating electric and magnetic disturbance that spreads electromagnetic radiation."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 459,
    "content": [
      "A nuclear breakdown in which particles or electromagnetic radiation is emitted is _____________."
    ],
    "explanation": [
      "Radioactive decay is defined as the spontaneous emission of particles and/or radiation from the unstable nuclei of certain atoms."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1833,
        "content": [
          "Radioactive isotopes"
        ],
        "isCorrect": false
      },
      {
        "id": 1834,
        "content": [
          "Radioactivity"
        ],
        "isCorrect": false
      },
      {
        "id": 1835,
        "content": [
          "Radio wave"
        ],
        "isCorrect": false
      },
      {
        "id": 1836,
        "content": [
          "Radioactive decay"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 460,
    "content": [
      "Which statement describes valence shell electron pair repulsion (VSEPR) theory?"
    ],
    "explanation": [
      "VSEPR Theory centers around the idea that electron pairs in the valence shell (outermost shell) of an atom will repel each other. This repulsion influences the shape of the molecule.\n\nIn VSEPR, the electron pairs, whether bonding pairs (involved in a bond) or lone pairs (not involved in a bond), will position themselves to maximize the distance between them, minimizing repulsion and leading to a stable molecular geometry."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1837,
        "content": [
          "Each degenerate orbitals are occupied by a single electron before the second electrons of opposite spin enters the orbitals."
        ],
        "isCorrect": false
      },
      {
        "id": 1838,
        "content": [
          "Electron pairs will be as far apart from each other in three dimensional spaces as possible."
        ],
        "isCorrect": true
      },
      {
        "id": 1839,
        "content": [
          "Atomic orbitals are capable of combining to produce new electron distribution."
        ],
        "isCorrect": false
      },
      {
        "id": 1840,
        "content": [
          "A covalent bond is formed when orbitals of two atoms overlap and the overlap region is occupied by a pair of electrons."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 469,
    "content": [
      "Which one of the following statements is CORRECT?"
    ],
    "explanation": [
      "Valence Bond (VB) theory, unlike the Lewis model, goes beyond simply showing electron pairs and linkages. It explains molecular shapes by considering how atomic orbitals interact and overlap when forming bonds.\n\nFor instance, VB theory explains the tetrahedral shape of methane ($$CH_4$$) by the hybridization of carbon's atomic orbitals into four equivalent $$sp^3$$ orbitals."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1873,
        "content": [
          "Valence bond model simply shows the linkage between atoms and the presence of lone pairs."
        ],
        "isCorrect": false
      },
      {
        "id": 1874,
        "content": [
          "Lewis model predicts the shapes of molecules based on electron-pair repulsions around a central atom."
        ],
        "isCorrect": false
      },
      {
        "id": 1875,
        "content": [
          "In Lewis model, electrons repel one another and a pair of bonding electrons lies far apart as possible."
        ],
        "isCorrect": false
      },
      {
        "id": 1876,
        "content": [
          "Valence bond model explain molecular shape from the interaction of atomic orbitals."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 476,
    "content": [
      "Which one of the following statement is TRUE about gases?"
    ],
    "explanation": [
      "Gases do not have a fixed shape or volume. They take the shape and volume of their container. Liquids, on the other hand, have a fixed volume but no fixed shape, meaning they take the shape of their container. Solids have a fixed shape and volume."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1901,
        "content": [
          "The particles of gases are closely packed together."
        ],
        "isCorrect": false
      },
      {
        "id": 1902,
        "content": [
          "The volume of a gas is kept constant as pressure increases."
        ],
        "isCorrect": false
      },
      {
        "id": 1903,
        "content": [
          "When a gas sample is heated at constant pressure, its volume decreases."
        ],
        "isCorrect": false
      },
      {
        "id": 1904,
        "content": [
          "The volume of a gas is equal to the volume of its container."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 477,
    "content": [
      "Which one of the following mathematical expressions is derived from the combination of Boyle's law, Charles' law and Avogadro's law?"
    ],
    "explanation": [
      "$$\nV \\ \\alpha \\ \\frac{nT}{P}\n$$\n\nThis expression is derived from the combination of Boyle's law, Charles' law, and Avogadro's law, which together form the ideal gas law:\n\n$$\nPV = nRT\n$$\n\nFrom this, you can solve for V:\n\n$$\nV = \\frac{nRT}{P}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1905,
        "content": [
          "$$V \\ \\alpha \\ \\frac{nT}{P}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1906,
        "content": [
          "$$V \\ \\alpha \\ \\frac{T}{nP}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1907,
        "content": [
          "$$V \\ \\alpha \\ \\frac{nP}{T}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1908,
        "content": [
          "$$V \\ \\alpha \\ \\frac{P}{nT}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 478,
    "content": [
      "180 g of calcium carbonate ($$CaCO_3$$) is allowed to react with 156 gram of hydrochloric acid ($$HCI$$), according to the following reaction. Which of the following substances is the limiting reagent? (Atomic masses; Ca = 40, CI = 35.5, O = 16, C = 12, H = 1)\n$$\nCaCO_3 + 2HCI \\rightarrow CaCl_2 + CO_2 + H_2O\n$$"
    ],
    "explanation": [
      "To determine the limiting reagent, we need to compare the moles of each reactant. The formula for calculating moles is:\n$$\nn=\\frac{m}{M}\n$$\n\n**Moles of $$CaCO_3$$:**\n\n- $$M_{CaCO_3} = 40 + 12 + (16 \\times 3) = 100 \\, \\text{g/mol}$$\n- $$n_{CaCO_3} = \\frac{180}{100} = 1.8 \\, \\text{mol}$$\n\n**Moles of $$HCl$$:**\n\n- $$M_{HCl} = 1 + 35.5 = 36.5 \\, \\text{g/mol}$$\n- $$n_{HCl} = \\frac{156}{36.5} \\approx 4.27 \\, \\text{mol}$$\n\nFrom the balanced equation, 1 mole of $$CaCO_3$$ reacts with 2 moles of $$HCl$$.\n\nFor 1.8 moles of $$CaCO_3$$, the required moles of $$HCl$$ are:\n$$\nn_{HCl, \\, \\text{required}} = 1.8 \\times 2 = 3.6 \\, \\text{mol}\n$$\n\nSince we have 4.27 moles of $$HCl$$ available and only 3.6 moles are needed, $$HCl$$ is in excess, and $$CaCO_3$$ is the limiting reagent."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1909,
        "content": [
          "$$HCI$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1910,
        "content": [
          "$$CaCO_3$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1911,
        "content": [
          "$$H_2O$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1912,
        "content": [
          "$$CO_2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 726,
    "content": [
      "What is the significance of electron probability distribution? It tells us about"
    ],
    "explanation": [
      "The exact position and momentum of an electron cannot be simultaneously known with precision.\n\nInstead, we use probability distributions to describe the likelihood of finding an electron in a particular region around the nucleus. This distribution reflects the inherent uncertainty and wave-like nature of electrons, making it impossible to assign them fixed paths or orbits."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2903,
        "content": [
          "the probability of finding an electron is very far away from the nucleus."
        ],
        "isCorrect": false
      },
      {
        "id": 2904,
        "content": [
          "finding the electron very close to the nucleus at all times."
        ],
        "isCorrect": false
      },
      {
        "id": 2905,
        "content": [
          "finding the electron in its orbit at a particular time."
        ],
        "isCorrect": false
      },
      {
        "id": 2906,
        "content": [
          "the uncertainty to assign fixed path for electrons."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 727,
    "content": [
      "Which group in the periodic table contains elements with the valence electron configuration of $$ns^2np^1$$?"
    ],
    "explanation": [
      "Elements with the valence electron configuration of $$ns^2np^1$$ are found in **Group 13 (III)** of the periodic table.\n\nThis group includes elements like boron, aluminum, and gallium. These elements have three valence electrons, with two in the s orbital and one in the p orbital, corresponding to the $$ns^2np^1$$ configuration."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2907,
        "content": [
          "IV"
        ],
        "isCorrect": false
      },
      {
        "id": 2908,
        "content": [
          "II"
        ],
        "isCorrect": false
      },
      {
        "id": 2909,
        "content": [
          "I"
        ],
        "isCorrect": false
      },
      {
        "id": 2910,
        "content": [
          "III"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 731,
    "content": [
      "Which of the following postulates of Dalton's atomic theory was modified by the modern atomic theory?"
    ],
    "explanation": [
      "Dalton's atomic stated that atoms were the smallest particles of an element and were indivisible and indestructible. \n\nHowever, later scientific discoveries, as discussed in the sources, showed that atoms are actually composed of even smaller subatomic particles: protons, neutrons, and electrons."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2923,
        "content": [
          "Compounds are formed when atoms of more than one element combine."
        ],
        "isCorrect": false
      },
      {
        "id": 2924,
        "content": [
          "Atoms are neither created nor destroyed in chemical reactions."
        ],
        "isCorrect": false
      },
      {
        "id": 2925,
        "content": [
          "Atoms are indivisible and indestructible."
        ],
        "isCorrect": true
      },
      {
        "id": 2926,
        "content": [
          "Atoms are the smallest particles of all elements."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 732,
    "content": [
      "Which of the following includes all of the known atomic models?"
    ],
    "explanation": [
      "- Dalton's Atomic Model: described atoms as indivisible and indestructible particles that make up elements.\n- Thomson Model (Plum Pudding Model): disproving the idea of atoms being indivisible. His model, depicted the atom as a sphere of positive charge with negatively charged electrons embedded within it, similar to plums in a pudding.\n- Rutherford Model (Nuclear Model):  This model positioned a tiny, dense, positively charged nucleus at the center of the atom, with electrons orbiting it at a distance.\n- Bohr Model: Niels Bohr refined Rutherford's model by proposing that electrons orbit the nucleus in specific energy levels or shells.\n- Quantum Mechanical Model: The most modern and accurate model, it builds upon the previous models and incorporates the wave-particle duality of matter."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2927,
        "content": [
          "Bohr Model, Thomson Model, Rutherford Model, Dalton's Atomic Model, de Broglie Model"
        ],
        "isCorrect": false
      },
      {
        "id": 2928,
        "content": [
          "Bohr Model, the Quantum Mechanical Model, Rutherford Model, Thomson Model, Dalton's Atomic Model"
        ],
        "isCorrect": true
      },
      {
        "id": 2929,
        "content": [
          "Bohr Model, the Quantum Mechanical Model, Thomson Model, Rutherford Model"
        ],
        "isCorrect": false
      },
      {
        "id": 2930,
        "content": [
          "Bohr Model, Quantum Mechanical Model, Dalton's Atomic Model, Valence Bond Model"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 733,
    "content": [
      "The electron configuration of Cu (Z=29) is:"
    ],
    "explanation": [
      "The correct electron configuration of Cu (Z = 29) is:\n$$\n[Ar] 4s^1 3d^{10}\n$$\n\nThe Aufbau principle provides a general order for filling orbitals with electrons, starting with the lowest energy levels. However, there are exceptions, and copper is one of them.\n\nChromium (Cr) and copper (Cu) are exceptions to the Aufbau principle because half-filled and fully filled d subshells are particularly stable. Chromium has an electron configuration of $$[Ar]4s^13d^5$$ (half-filled 3d subshell), and copper has an electron configuration of $$[Ar]4s^13d^{10}$$ (fully filled 3d subshell)."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2931,
        "content": [
          "$$[Ar]4s^13d^{10}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 2932,
        "content": [
          "$$[Kr]4s^23d^9$$"
        ],
        "isCorrect": false
      },
      {
        "id": 2933,
        "content": [
          "$$[Ar]4s^24d^9$$"
        ],
        "isCorrect": false
      },
      {
        "id": 2934,
        "content": [
          "$$[Ar]4s^23p^8$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 734,
    "content": [
      "What does Mendeleev's Periodic Law state? Properties of elements are periodic functions of their"
    ],
    "explanation": [
      "Mendeleev's periodic law states that the physical and chemical properties of elements are the periodic function of their atomic weights.  Mendeleev organized the elements in increasing order of atomic weight and noticed that elements with similar properties appeared periodically."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2935,
        "content": [
          "atomic radius."
        ],
        "isCorrect": false
      },
      {
        "id": 2936,
        "content": [
          "atomic masses."
        ],
        "isCorrect": true
      },
      {
        "id": 2937,
        "content": [
          "electron configurations."
        ],
        "isCorrect": false
      },
      {
        "id": 2938,
        "content": [
          "atomic numbers."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 741,
    "content": [
      "What is enthalpy change? It is"
    ],
    "explanation": [
      "Enthalpy change is defined as the amount of heat released or absorbed during the dissolution process. It is symbolized by $$\\Delta H$$ and is calculated as the enthalpy of products minus the enthalpy of reactants.\n\nEnthalpy change is expressed in kJ/mol for reactions occurring at standard conditions, which is defined as a temperature of 298.15 K and a pressure of 1 atm."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2963,
        "content": [
          "the amount of heat absorbed in a reaction."
        ],
        "isCorrect": false
      },
      {
        "id": 2964,
        "content": [
          "the amount of heat given out or absorbed in a reaction at constant pressure and volume."
        ],
        "isCorrect": false
      },
      {
        "id": 2965,
        "content": [
          "the amount of heat given out or absorbed in a reaction at constant pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 2966,
        "content": [
          "the amount of heat given out in a reaction."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 742,
    "content": [
      "What is oxidation? Oxidation is"
    ],
    "explanation": [
      "Oxidation is defined as the loss of one or more electrons by an atom. When an atom loses electrons, its oxidation number increases.\n\nConversely, reduction is the gain of one or more electrons by an atom, and a reduction is the gain of one or more electrons. When an atom gains electrons, its oxidation number decreases. \n\nOxidation and reduction always occur simultaneously."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2967,
        "content": [
          "the reduction of the oxidation state of the oxidizing agent."
        ],
        "isCorrect": false
      },
      {
        "id": 2968,
        "content": [
          "the addition of electron(s) to the oxidizing agent."
        ],
        "isCorrect": false
      },
      {
        "id": 2969,
        "content": [
          "the loss of electrons by a species, accompanied by an increase in oxidation number."
        ],
        "isCorrect": true
      },
      {
        "id": 2970,
        "content": [
          "the addition of hydrogen to a substance and the removal of oxygen from a substance."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 751,
    "content": [
      "What is the mole ratio of oxygen gas to carbon dioxide gas in the following reaction?\n$$\nC_3H_8 (g) +5O_2 (g) \\rightarrow 3CO_2 (g) + 4H_2O (l)\n$$"
    ],
    "explanation": [
      "The mole ratio of oxygen gas to carbon dioxide gas in the reaction is 5:3. The chemical equation provided shows that 5 moles of oxygen gas ($$O_2$$) react to produce 3 moles of carbon dioxide ($$CO_2$$)."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3003,
        "content": [
          "7 mole oxygen gas to 5 mole carbon dioxide"
        ],
        "isCorrect": false
      },
      {
        "id": 3004,
        "content": [
          "2 mole oxygen gas to 3 mole carbon dioxide"
        ],
        "isCorrect": false
      },
      {
        "id": 3005,
        "content": [
          "5 mole oxygen gas to 3 mole carbon dioxide"
        ],
        "isCorrect": true
      },
      {
        "id": 3006,
        "content": [
          "10 mole oxygen gas to 6 mole carbon dioxide"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 752,
    "content": [
      "Consider the following chemical equation for the combustion of ethane ($$C_2H_6$$) in the presence of oxygen to produce carbon dioxide and water.\n$$\n2C_2H_6 (g) +7O_2 (g) \\rightarrow 4CO_2 (g) + 6H_2O (l)\n$$\nIn this reaction:"
    ],
    "explanation": [
      "The balanced chemical equation you provided shows that 2 moles of ethane react with 7 moles of oxygen to produce 4 moles of carbon dioxide and 6 moles of water.\n\nThis means that for every 2 moles of ethane consumed, 4 moles of carbon dioxide are produced. Therefore, carbon dioxide is formed twice as fast as ethane is consumed."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3007,
        "content": [
          "$$CO_2$$ is formed twice as fast as ethane is consumed."
        ],
        "isCorrect": true
      },
      {
        "id": 3008,
        "content": [
          "water is formed at a rate equal to 2/3 the rate of formation of $$CO_2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 3009,
        "content": [
          "the rate of formation of $$CO_2$$ equals the rate of formation of water."
        ],
        "isCorrect": false
      },
      {
        "id": 3010,
        "content": [
          "the rate of consumption of ethane is 7 times faster than the rate of consumption of oxygen."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 753,
    "content": [
      "Which of the following factors DOES NOT affect the rate of a reaction?"
    ],
    "explanation": [
      "Enthalpy is a thermodynamic property that describes the heat absorbed or released during a reaction at constant pressure. While enthalpy indicates whether a reaction is exothermic or endothermic, it doesn't directly determine how fast the reaction proceeds."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3011,
        "content": [
          "Enthalpy"
        ],
        "isCorrect": true
      },
      {
        "id": 3012,
        "content": [
          "Temperature"
        ],
        "isCorrect": false
      },
      {
        "id": 3013,
        "content": [
          "Surface area"
        ],
        "isCorrect": false
      },
      {
        "id": 3014,
        "content": [
          "Concentration"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 755,
    "content": [
      "Which of the following statements correctly describes Boyle's Law?"
    ],
    "explanation": [
      "Boyle's Law states that for a fixed amount of gas at a constant temperature, the volume of the gas is inversely proportional to the pressure exerted on it. This means that if the pressure increases, the volume decreases, and vice versa. The mathematical expression for Boyle's Law is:\n$$\nP V = \\text{constant}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3019,
        "content": [
          "The volume of a gas at a given temperature is inversely proportional to the square root of the applied pressure."
        ],
        "isCorrect": false
      },
      {
        "id": 3020,
        "content": [
          "The volume of a gas at a given temperature is proportional to the square root of the applied pressure."
        ],
        "isCorrect": false
      },
      {
        "id": 3021,
        "content": [
          "The volume of a gas at a given temperature is inversely proportional to the applied pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 3022,
        "content": [
          "The volume of a gas at a given temperature is directly proportional to the applied pressure."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 757,
    "content": [
      "How do the elements of Group IIA form ions?"
    ],
    "explanation": [
      "The elements of Group IIA form ions by losing 2 electrons. The elements in Group IIA are alkaline earth metals. Alkaline earth metals have an $$ns^2$$ outer electron configuration. To achieve an octet, elements in Group IIA lose their two outermost electrons."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3027,
        "content": [
          "By gaining 2 electrons"
        ],
        "isCorrect": false
      },
      {
        "id": 3028,
        "content": [
          "By losing 2 electrons"
        ],
        "isCorrect": true
      },
      {
        "id": 3029,
        "content": [
          "By losing one electron"
        ],
        "isCorrect": false
      },
      {
        "id": 3030,
        "content": [
          "By gaining one electron"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 759,
    "content": [
      "Which one of the following forms of energy change occurs from the combustion of carbon in oxygen is"
    ],
    "explanation": [
      "Combustion of carbon in oxygen is an exothermic reaction, meaning it releases energy in the form of heat."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3035,
        "content": [
          "solar energy."
        ],
        "isCorrect": false
      },
      {
        "id": 3036,
        "content": [
          "heat energy."
        ],
        "isCorrect": true
      },
      {
        "id": 3037,
        "content": [
          "electrical energy."
        ],
        "isCorrect": false
      },
      {
        "id": 3038,
        "content": [
          "light energy."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 760,
    "content": [
      "What is the molar volume of a gas?"
    ],
    "explanation": [
      "STP for gases is defined as a temperature of 0°C (273 K) and a pressure of 1 atmosphere (atm).\n\nAt STP, the volume of one mole of any ideal gas is 22.4 liters (L). This is considered the standard molar volume."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3039,
        "content": [
          "The volume of a gas at STP (standard temperature 25°C and pressure, 1 kPa), which is equal to 22. 4 L/mol."
        ],
        "isCorrect": false
      },
      {
        "id": 3040,
        "content": [
          "The volume of a gas at STP (standard temperature 0°C and pressure, 1 kPa), which is equal to 22. 4 L/mol."
        ],
        "isCorrect": false
      },
      {
        "id": 3041,
        "content": [
          "The volume of a gas at STP (standard temperature 25°C and pressure, 1 atm.), which is equal to 22. 4 L/mol."
        ],
        "isCorrect": false
      },
      {
        "id": 3042,
        "content": [
          "The volume of a gas at STP (standard temperature, 0°C and pressure, 1 atm.), which is equal to 22. 4 L/mol."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 762,
    "content": [
      "What is the difference between reversible and irreversible reactions?"
    ],
    "explanation": [
      "Reversible reactions are reactions that do not go to completion. Instead, they reach a state of equilibrium, where the rates of the forward and reverse reactions are equal. \n\nAt equilibrium, there is a mixture of both reactants and products present."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3047,
        "content": [
          "In irreversible reactions, there is a mixture of products and reactants."
        ],
        "isCorrect": false
      },
      {
        "id": 3048,
        "content": [
          "In reversible reactions, the reaction goes to completion."
        ],
        "isCorrect": false
      },
      {
        "id": 3049,
        "content": [
          "In irreversible reactions, there is equilibrium between reactants and products."
        ],
        "isCorrect": false
      },
      {
        "id": 3050,
        "content": [
          "In reversible reactions, there is equilibrium between reactants and products."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 763,
    "content": [
      "Consider the reactions all given bellow are in gaseous state. For which of the following reactions is $$K_p$$ less than $$K_c$$?"
    ],
    "explanation": [
      "The relationship between the equilibrium constants $$K_p$$ (in terms of partial pressures) and $$K_c$$ (in terms of concentrations) is given by the equation:\n\n$$\nK_p = K_c \\cdot (RT)^{\\Delta n}\n$$\n\n$$\n\\Delta n = \\text{moles of gaseous products} - \\text{moles of gaseous reactants}\n$$\n\nFor $$K_p$$ to be less than $$K_c$$, the term $$(RT)^{\\Delta n}$$ must be less than 1, which implies that $$\\Delta n$$ should be negative.\nOption: $$2SO_2 + O_2$$ ⇌ $$2SO_3$$\n\n- $$\\Delta n$$ = (2) - (2 + 1) = -1 so $$K_p < K_c$$.\n\nOption: $$N_2O_4$$ ⇌ $$2NO_2$$\n\n- $$\\Delta n$$ = (2) - (1) = +1 so $$K_p > K_c$$.\n\nOption: $$N_2 + O_2$$ ⇌ $$2NO$$\n\n- $$\\Delta n$$ = (2) - (2) = 0 do $$K_p = K_c$$.\n\nOption: $$2HI$$ ⇌ $$H_2 + I_2$$\n\n- $$\\Delta n$$ = (2) - (2) = 0 so $$K_p = K_c$$."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3051,
        "content": [
          "$$2SO_2$$ + $$O_2$$ ⇌ $ $$2SO_3$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3052,
        "content": [
          "$$N_2O_4$$ ⇌ $$2NO_2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3053,
        "content": [
          "$$N_2$$ + $$O_2$$ ⇌ $$2NO$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3054,
        "content": [
          "$$2HI$$ ⇌ $$H_2$$ + $$I_2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 764,
    "content": [
      "The heating curve shown below shows a substance in the solid, liquid and gas phase. Which segment represents only the liquid phase?",
      "images/chemistry/year_2014/q39_1.png"
    ],
    "explanation": [
      "- **Segment 1:** Solid\n- **Segment 2:** Solid to Liquid (Melting)\n- **Segment 3:** Liquid\n- **Segment 4:** Liquid to Gas (Boiling)\n- **Segment 5:** Gas"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2014/q39_1.png"
    ],
    "choices": [
      {
        "id": 3055,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 3056,
        "content": [
          "3"
        ],
        "isCorrect": true
      },
      {
        "id": 3057,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 3058,
        "content": [
          "1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 766,
    "content": [
      "What is the concentration of a solution? It is"
    ],
    "explanation": [
      "Concentration is defined as the relative amount of solute compared to the total quantity of the solution or the solvent."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3063,
        "content": [
          "number of moles of solute and number of moles of solvent."
        ],
        "isCorrect": false
      },
      {
        "id": 3064,
        "content": [
          "the amount of solute needed to make a concentrated solution."
        ],
        "isCorrect": false
      },
      {
        "id": 3065,
        "content": [
          "the amount of solvent needed to dissolve a solute."
        ],
        "isCorrect": false
      },
      {
        "id": 3066,
        "content": [
          "the quantity of solute in a given quantity of solution."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 767,
    "content": [
      "How many moles of $$C_{12}H_{22}O_{11}$$ (sucrose molecular weight = 342.91 g/mol) is needed there to prepare 2.0L of 0.3 M solution?"
    ],
    "explanation": [
      "$$\nn = M \\times V\n$$\n\nGiven:\n\n- M = 0.3 mol/L,\n- V = 2.0 L\n\n$$\nn = 0.3 \\, \\text{mol/L} \\times 2.0 \\, \\text{L} = 0.6 \\, \\text{mol}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3067,
        "content": [
          "6.6"
        ],
        "isCorrect": false
      },
      {
        "id": 3068,
        "content": [
          "0.6"
        ],
        "isCorrect": true
      },
      {
        "id": 3069,
        "content": [
          "0.43"
        ],
        "isCorrect": false
      },
      {
        "id": 3070,
        "content": [
          "0.15"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 768,
    "content": [
      "At 75°C, the vapor pressure of pure water is 39 kPa. Which one of the vapor pressure of a solution obtained by dissolving 34.2 g sucrose in 180 mL of water? (Assume that the density of water is 1.000 g/mL)"
    ],
    "explanation": [
      "To calculate the vapor pressure of the solution, we use Raoult's Law:\n$$\nP_{\\text{solution}} = X_{\\text{solvent}} \\cdot P_{\\text{pure}}\n$$\nThe mass of water is:\n$$\\text{Mass of water} = 180 \\, \\text{mL} \\times 1.000 \\, \\frac{\\text{g}}{\\text{mL}} = 180 \\, \\text{g}$$\nThe molar mass of water is 18.015 g/mol, so the moles of water are:\n$$\n\\text{Moles of water} = \\frac{180 \\, \\text{g}}{18.015 \\, \\text{g/mol}} = 9.993 \\, \\text{mol}\n$$\nThe mass of sucrose is 34.2 g. The molar mass of sucrose is = 342.3 g/mol, so the moles of sucrose are:\n$$\n\\text{Moles of sucrose} = \\frac{34.2 \\, \\text{g}}{342.3 \\, \\text{g/mol}} = 0.100 \\, \\text{mol}\n$$\n\nThe mole fraction of water is:\n$$X_{\\text{water}} = \\frac{M_\\text{water}}{M_\\text{water} + M_\\text{sucrose}} = \\frac{9.993}{9.993 + 0.100} = 0.990$$\n\nApplying Raoult's Law:\n$$\nP_{\\text{solution}} = 0.990 \\times 39 \\, \\text{kPa} = 38.6 \\, \\text{kPa}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3071,
        "content": [
          "44.5 kPa"
        ],
        "isCorrect": false
      },
      {
        "id": 3072,
        "content": [
          "41.1 kPa"
        ],
        "isCorrect": false
      },
      {
        "id": 3073,
        "content": [
          "38.6 kPa"
        ],
        "isCorrect": true
      },
      {
        "id": 3074,
        "content": [
          "31.2 kPa"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 769,
    "content": [
      "Which of the following statements is NOT true about the colligative properties of electrolytes and non-electrolytes?"
    ],
    "explanation": [
      "Electrolytes, when dissolved in water, dissociate into ions. This dissociation results in a greater number of particles in the solution compared to non-electrolytes.\n\nColligative properties depend on the number of solute particles in a solution, not their nature. Since electrolytes produce more particles in solution than non-electrolytes, they have a greater effect on colligative properties."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3075,
        "content": [
          "The effect of non-electrolytes on colligative properties is the same as those of electrolytes."
        ],
        "isCorrect": true
      },
      {
        "id": 3076,
        "content": [
          "The effect of non-electrolytes on colligative properties is very low compared to electrolytes."
        ],
        "isCorrect": false
      },
      {
        "id": 3077,
        "content": [
          "The colligative properties of non-electrolytes are not considerably changed."
        ],
        "isCorrect": false
      },
      {
        "id": 3078,
        "content": [
          "The effect of electrolytes on colligative properties is very high compared to non-electrolytes."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 771,
    "content": [
      "Which of the following assumptions of the kinetic molecular theory of gases explains the high compressibility of gases?"
    ],
    "explanation": [
      "Gases are highly compressible because the space between the gas particles is very large compared to the size of the particles themselves. When pressure is applied, the gas particles can be forced closer together, reducing the volume of the gas."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3083,
        "content": [
          "Different particles have different speeds."
        ],
        "isCorrect": false
      },
      {
        "id": 3084,
        "content": [
          "Particles are always in random motion."
        ],
        "isCorrect": false
      },
      {
        "id": 3085,
        "content": [
          "There is no force of attraction between gas molecules."
        ],
        "isCorrect": false
      },
      {
        "id": 3086,
        "content": [
          "The actual volume of gas molecules in negligible."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 772,
    "content": [
      "Consider a bottle containing water, water vapor and air in equilibrium. If the temperature decreases slightly, the amount of water vapors;"
    ],
    "explanation": [
      "When the temperature of a system containing water vapor decreases, the water vapor loses kinetic energy. As a result, the water molecules slow down and the intermolecular forces of attraction between them become stronger, causing the water vapor to condense into liquid water. This decreases the amount of water vapor in the bottle."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3087,
        "content": [
          "and vapor pressure will decrease."
        ],
        "isCorrect": true
      },
      {
        "id": 3088,
        "content": [
          "will decrease and the vapor pressure will increase."
        ],
        "isCorrect": false
      },
      {
        "id": 3089,
        "content": [
          "will increase and the vapor pressure will decrease."
        ],
        "isCorrect": false
      },
      {
        "id": 3090,
        "content": [
          "and vapor pressure will increase."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 773,
    "content": [
      "Why do water droplets collect on the outside of a glass of water on a hot day?"
    ],
    "explanation": [
      "Condensation is the process by which water vapor changes into liquid water. This happens when the water vapor cools down.\n\nOn a hot day, the air surrounding the glass of cold water is warm and holds more moisture. When this warm, moist air comes into contact with the cold surface of the glass, the water vapor in the air loses energy and cools down. As the water vapor cools, it reaches a point where it can no longer remain in its gaseous state and condenses into liquid water droplets on the outside of the glass."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3091,
        "content": [
          "There will be a sublimation of water vapor on the outside of a glass."
        ],
        "isCorrect": false
      },
      {
        "id": 3092,
        "content": [
          "There will be a condensation of water vapor on the glass."
        ],
        "isCorrect": true
      },
      {
        "id": 3093,
        "content": [
          "Water from the glass starts to vaporize."
        ],
        "isCorrect": false
      },
      {
        "id": 3094,
        "content": [
          "There is heat exchange between the water in the glass and the surrounding."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 777,
    "content": [
      "What is the effect of a common ion in an electrolytic solution?"
    ],
    "explanation": [
      "The common ion effect is the shift in an ionic equilibrium caused by the addition of a solute that provides an ion that takes part in the equilibrium.\n\nFor example, if you add HCl (aq) to a solution of acetic acid, the equilibrium composition should shift to the left because HCl (aq) is a strong acid that provides  $$H_3O^+$$ ion. The degree of ionization of acetic acid is decreased by the addition of a strong acid."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3107,
        "content": [
          "It has no effect on the pH of a solution."
        ],
        "isCorrect": false
      },
      {
        "id": 3108,
        "content": [
          "It decreases the solubility of a solute."
        ],
        "isCorrect": true
      },
      {
        "id": 3109,
        "content": [
          "It suppresses the imitation of a weak base and lowers the pOH."
        ],
        "isCorrect": false
      },
      {
        "id": 3110,
        "content": [
          "It suppresses the imitation of a weak acid and raises the pH."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 780,
    "content": [
      "What is the change in internal energy ($$\\Delta E$$) for a reaction, in which the system absorbs 650 J of heat and 125 J of work is done on the system?"
    ],
    "explanation": [
      "The change in internal energy ($$\\Delta E$$) for a system can be calculated using the first law of thermodynamics, which is given by:\n$$\n\\Delta E = q + w\n$$\n\nwhere:\n\n- q is the heat absorbed by the system,\n- w is the work done on the system.\n\nIn this case:\n\n- q = 650 J,\n- w = 125 J\n\n$$\n\\Delta E = 650 \\, \\text{J} + 125 \\, \\text{J} = 775 \\, \\text{J}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3119,
        "content": [
          "-535 J"
        ],
        "isCorrect": false
      },
      {
        "id": 3120,
        "content": [
          "-775 J"
        ],
        "isCorrect": false
      },
      {
        "id": 3121,
        "content": [
          "535 J"
        ],
        "isCorrect": false
      },
      {
        "id": 3122,
        "content": [
          "775 J"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 782,
    "content": [
      "Which one of the following is correctly stated regarding solubility as an equilibrium process?"
    ],
    "explanation": [
      "- A saturated solution is in equilibrium with the undissolved solute, meaning no more solute can be dissolved.\n- An unsaturated solution has not reached its solubility limit, so more solute can be dissolved.\n- A supersaturated solution is a meta-stable state where more solute is dissolved than is normally possible at a given temperature. They are not more stable than saturated solutions."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3127,
        "content": [
          "Saturated solution is a solution in which more of the solute can be dissolved."
        ],
        "isCorrect": false
      },
      {
        "id": 3128,
        "content": [
          "Unsaturated solution is a solution that is in equilibrium with respect to a given dissolved substance."
        ],
        "isCorrect": false
      },
      {
        "id": 3129,
        "content": [
          "Supersaturated solution is more stable than saturated solution."
        ],
        "isCorrect": false
      },
      {
        "id": 3130,
        "content": [
          "Supersaturated solution is a solution that contains more than the equilibrium amount of dissolved solute."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 784,
    "content": [
      "What is the rate of dissolution? It is"
    ],
    "explanation": [
      "The rate of dissolution specifically refers to how quickly a solid solute (such as salt or sugar) dissolves in a solvent (like water) to form a solution. This process involves the breaking apart of the solute particles and their integration into the solvent."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3135,
        "content": [
          "the speed at which a solid substrate goes into solution."
        ],
        "isCorrect": true
      },
      {
        "id": 3136,
        "content": [
          "the rate at which a solid turns to liquid."
        ],
        "isCorrect": false
      },
      {
        "id": 3137,
        "content": [
          "the speed at which a solid sublimes."
        ],
        "isCorrect": false
      },
      {
        "id": 3138,
        "content": [
          "the rate at which a solid dissociates."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 787,
    "content": [
      "Why is $$CaCl_2$$ added to $$NaCl$$ in a $$1:1\\frac{1}{2}$$ ratio in the Down's cell for the manufacturing of sodium metal?"
    ],
    "explanation": [
      "Pure $$NaCl$$ melts at 801°C. To make the process more economical, the melting temperature is lowered by adding $$CaCl_2$$. This allows the electrolysis to be carried out at a lower temperature, saving energy."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3147,
        "content": [
          "$$CaCl_2$$ is used as an electrolyte."
        ],
        "isCorrect": false
      },
      {
        "id": 3148,
        "content": [
          "$$CaCl_2$$ is used to lower the density of the mixture."
        ],
        "isCorrect": false
      },
      {
        "id": 3149,
        "content": [
          "$$CaCl_2$$ is used to lower the melting temperature of $$NaCl$$."
        ],
        "isCorrect": true
      },
      {
        "id": 3150,
        "content": [
          "$$CaCl_2$$ is used as a catalyst."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 788,
    "content": [
      "Which of the following is NOT a major step in metallurgical processes?"
    ],
    "explanation": [
      "The three principal steps in extracting a metal from its ore are:\n\n- **Preparation (concentration) of the ore:** This step involves processes like oil floatation and magnetic separation to remove impurities and increase the concentration of the desired metal.\n- **Production of the metal:** This step involves processes like roasting and calcination to convert the metal compound in the ore into a more usable form.\n- **Purification of the metal:** This is the final step and involves processes like chemical reduction and electrolytic reduction to obtain the metal in its pure form.\n\n**Mining the ore** is the process of extracting the ore from the earth, which is a necessary preliminary step to the metallurgical process, but not a metallurgical process itself."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3151,
        "content": [
          "Extracting the metal and refining"
        ],
        "isCorrect": false
      },
      {
        "id": 3152,
        "content": [
          "Pretreatment"
        ],
        "isCorrect": false
      },
      {
        "id": 3153,
        "content": [
          "Concentrating the ore"
        ],
        "isCorrect": false
      },
      {
        "id": 3154,
        "content": [
          "Mining the ore"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 791,
    "content": [
      "What is the purpose of synthetic cryolite in the extraction of aluminum by the Hall's process?"
    ],
    "explanation": [
      "- Pure aluminum oxide has a melting point of 2045 °C.\n- Adding cryolite ($$Na_3AlF_6$$) reduces the melting point to 1000 °C.\n- This makes the electrolysis process more efficient and cost-effective.\n- The molten cryolite also acts as a conducting medium for the electrolysis."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3163,
        "content": [
          "Cryolite is used as a catalyst in the extraction of aluminum."
        ],
        "isCorrect": false
      },
      {
        "id": 3164,
        "content": [
          "Cryolite increases the melting point of alumina."
        ],
        "isCorrect": false
      },
      {
        "id": 3165,
        "content": [
          "Cryolite reduces the melting point of alumina."
        ],
        "isCorrect": true
      },
      {
        "id": 3166,
        "content": [
          "Cryolite increases the purity of the extracted aluminum."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 793,
    "content": [
      "How is tanning carried out? In tanning the hides or skins are"
    ],
    "explanation": [
      "Tanning is a process that converts animal hides or skins into leather by treating them with various chemicals to prevent decomposition and to enhance their durability and appearance.\n\nOne common method of tanning involves the use of chromium salts, particularly chromium(III) sulfate, which is effective in providing flexibility and water resistance to the leather."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3171,
        "content": [
          "treated with dilute hydrochloric acid to remove the lime."
        ],
        "isCorrect": false
      },
      {
        "id": 3172,
        "content": [
          "treated with chromium salts."
        ],
        "isCorrect": true
      },
      {
        "id": 3173,
        "content": [
          "soaked in lime and water for several days."
        ],
        "isCorrect": false
      },
      {
        "id": 3174,
        "content": [
          "soaked in water for several days."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 795,
    "content": [
      "Which of the following is a fundamental quantity SI unit?"
    ],
    "explanation": [
      "The SI base unit for length is the meter (m). The other options are derived units."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3179,
        "content": [
          "Length"
        ],
        "isCorrect": true
      },
      {
        "id": 3180,
        "content": [
          "Pressure"
        ],
        "isCorrect": false
      },
      {
        "id": 3181,
        "content": [
          "Force"
        ],
        "isCorrect": false
      },
      {
        "id": 3182,
        "content": [
          "Speed"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 799,
    "content": [
      "For a reaction:\n$$\n\\frac{1}{2}A \\rightarrow 2B\n$$\nthe rate of disappearance of 'A' is related to the appearance of 'B' by the expression:"
    ],
    "explanation": [
      "To relate the rate of disappearance of A to the rate of appearance of \\( B \\) for the reaction\n$$\n\\frac{1}{2}A \\rightarrow 2B\n$$\n\nwe can use the stoichiometric coefficients from the balanced equation. The relationship can be expressed as:\n$$\n-\\frac{1}{a} \\frac{\\Delta A}{\\Delta t} = \\frac{1}{b} \\frac{\\Delta B}{\\Delta t}\n$$\n\nSubstituting these values into the equation gives:\n$$\n-\\frac{1}{\\frac{1}{2}} \\frac{\\Delta A}{\\Delta t} = \\frac{1}{2} \\frac{\\Delta B}{\\Delta t}\n$$\n\nRearranging this gives:\n$$\n-\\frac{\\Delta A}{\\Delta t} = \\frac{1}{4} \\frac{\\Delta B}{\\Delta t}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3195,
        "content": [
          "$$-\\frac{\\Delta A}{\\Delta t}$$ = $$\\frac{1}{4} \\frac{\\Delta B}{\\Delta t}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3196,
        "content": [
          "$$-\\frac{\\Delta A}{\\Delta t}$$ = $$\\frac{1}{2} \\frac{\\Delta B}{\\Delta t}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3197,
        "content": [
          "$$-\\frac{\\Delta A}{\\Delta t}$$ = $$\\frac{4 \\Delta B}{\\Delta t}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3198,
        "content": [
          "$$-\\frac{\\Delta A}{\\Delta t}$$ = $$\\frac{\\Delta B}{\\Delta t}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 800,
    "content": [
      "The half-life of a reaction is the time taken for the"
    ],
    "explanation": [
      "The half-life of a reaction refers specifically to the time required for the concentration of a reactant to decrease to half of its initial concentration."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3199,
        "content": [
          "complete conversion of a reactant into a product."
        ],
        "isCorrect": false
      },
      {
        "id": 3200,
        "content": [
          "rate constant to decrease by 50% of its initial value."
        ],
        "isCorrect": false
      },
      {
        "id": 3201,
        "content": [
          "rate constant to increase by 50% of its initial value."
        ],
        "isCorrect": false
      },
      {
        "id": 3202,
        "content": [
          "reactant concentration to decrease by 50% of its initial value."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 801,
    "content": [
      "For the conversion of 3.5 yards into meter using the factor label method, which of the following is the correct step?\n\n1 yard = 3.5 feet; 1 foot = 12 inch; 1 inch = 2.54 cm; 1m = 100 cm"
    ],
    "explanation": [
      "The conversion process must use the correct unit ratios to ensure proper cancellation of units, leading to the desired outcome of meters.\n\n- Starting with **3.5 yards**, we convert it to feet using the ratio $$\\frac{3.5 \\text{ feet}}{1 \\text{ yard}}$$.\n- Next, we convert feet to inches using $$\\frac{12 \\text{ inches}}{1 \\text{ foot}}$$.\n- Then, we convert inches to centimeters using $$\\frac{2.54 \\text{ cm}}{1 \\text{ inch}}$$.\n- Finally, we convert centimeters to meters using $$\\frac{1 \\text{ m}}{100 \\text{ cm}}$$.\n\nThus, the correct setup should be:\n$$\n(\\frac{3.5 \\text{yards}}{1})(\\frac{3.5 \\text{ feet}}{1 \\text{ yard}})(\\frac{12 \\text{ in}}{1 \\text{ foot}})(\\frac{2.54 \\text{ cm}}{1 \\text{ in}})(\\frac{1 \\text{ m}}{100 \\text{ cm}})\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3203,
        "content": [
          "(3.5 yards/1)(3.5 feet/1 yard)(1foot/112 in)(2.54 cm/1 in)(1 m/100 cm)"
        ],
        "isCorrect": false
      },
      {
        "id": 3204,
        "content": [
          "(3.5 yards/1)(3.5 feet/1 yard)(12 in/1 foot)(1 in/2.54 m)(1m/100 cm)"
        ],
        "isCorrect": false
      },
      {
        "id": 3205,
        "content": [
          "(3.5 yards/1)(1 yard/3.5 feet)(12 in/1 foot)(2.54 cm/1 in)(1m/100 cm)"
        ],
        "isCorrect": false
      },
      {
        "id": 3206,
        "content": [
          "(3.5 yards/1)(3.5 feet/1 yard)(12 in/1 foot)(2.54 cm/1 in)(1m/100 cm)"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 802,
    "content": [
      "In the scientific method, a predictive statement that can be tested experimentally is:"
    ],
    "explanation": [
      "A hypothesis is a testable prediction or statement that proposes an explanation for an observed phenomenon. It's a crucial part of the scientific method because it provides a specific direction for experimental investigation."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3207,
        "content": [
          "hypothesis."
        ],
        "isCorrect": true
      },
      {
        "id": 3208,
        "content": [
          "proof."
        ],
        "isCorrect": false
      },
      {
        "id": 3209,
        "content": [
          "evidence."
        ],
        "isCorrect": false
      },
      {
        "id": 3210,
        "content": [
          "truth."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Chemistry and it's Importance"
  },
  {
    "id": 803,
    "content": [
      "Which of the following is NOT true about cathode rays? Cathode rays"
    ],
    "explanation": [
      "- Cathode rays are beams of negatively charged particles called electrons.\n- Electrons are constituents of all matter.\n- The characteristics of cathode rays are independent of the material making up the cathode, and their mass-to-charge ratio is constant for all gases.\n- Cathode rays travel in straight lines from the cathode (negative electrode) to the anode (positive electrode)."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3211,
        "content": [
          "are common constituents of all matter and their m/e is constant for all gases."
        ],
        "isCorrect": false
      },
      {
        "id": 3212,
        "content": [
          "contain particles, which are positively charged."
        ],
        "isCorrect": true
      },
      {
        "id": 3213,
        "content": [
          "travel in straight lines from cathode to the anode."
        ],
        "isCorrect": false
      },
      {
        "id": 3214,
        "content": [
          "contain particles, which are negatively charged."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 804,
    "content": [
      "Which of the following statements is correct about the energy of a photon?"
    ],
    "explanation": [
      "- The energy of a single quantum of energy is given by the equation: E = hν, where h is Planck's constant and ν is the frequency of the radiation.\n- This equation shows that the energy of a quantum is directly proportional to the frequency of the radiation.\n- Therefore, the energy of a photon, which is a quantum of light, is also directly proportional to the observed frequency of the light."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3215,
        "content": [
          "It is directly proportional to the wave length of the light."
        ],
        "isCorrect": false
      },
      {
        "id": 3216,
        "content": [
          "It is directly related to the intensity of the light."
        ],
        "isCorrect": false
      },
      {
        "id": 3217,
        "content": [
          "It is inversely proportional to the observed frequency of the light."
        ],
        "isCorrect": false
      },
      {
        "id": 3218,
        "content": [
          "It is directly proportional to the observed frequency of the light."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 805,
    "content": [
      "Which of the following explains the emission spectra of atoms consisting of a series of fine lines?"
    ],
    "explanation": [
      "When an electron in an atom absorbs energy, it can move to a higher energy level (excitation). When the electron returns to a lower energy level, it releases energy in the form of electromagnetic radiation (photons).\n\nThe energy of the emitted photon corresponds to the difference in energy between the two levels. Because energy levels in atoms are quantized (discrete), the emitted light consists of specific wavelengths, resulting in the characteristic fine lines observed in atomic emission spectra."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3219,
        "content": [
          "An electron that revolves around the nucleus emits radiation."
        ],
        "isCorrect": false
      },
      {
        "id": 3220,
        "content": [
          "The energy of the atoms is continuous with discreet frequencies."
        ],
        "isCorrect": false
      },
      {
        "id": 3221,
        "content": [
          "An electron undergoes a transition by energy changes corresponding to photon of specific wave length."
        ],
        "isCorrect": true
      },
      {
        "id": 3222,
        "content": [
          "An electron can have specific energy values in an atom."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 806,
    "content": [
      "The branch of chemistry that is involved in separation, identifying and determining the relative amounts of components in a sample of material is known as"
    ],
    "explanation": [
      "Analytical chemistry is the branch of chemistry that deals with the separation, identification, and quantification of the components of a sample."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3223,
        "content": [
          "biochemistry."
        ],
        "isCorrect": false
      },
      {
        "id": 3224,
        "content": [
          "analytical chemistry."
        ],
        "isCorrect": true
      },
      {
        "id": 3225,
        "content": [
          "physical chemistry."
        ],
        "isCorrect": false
      },
      {
        "id": 3226,
        "content": [
          "inorganic chemistry."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Chemistry and it's Importance"
  },
  {
    "id": 807,
    "content": [
      "Significant figures are figures with"
    ],
    "explanation": [
      "Significant figures are digits in a number that are known with certainty, plus one final digit that is uncertain or estimated."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3227,
        "content": [
          "measured values with the highest precision."
        ],
        "isCorrect": false
      },
      {
        "id": 3228,
        "content": [
          "measured values with the highest accuracy."
        ],
        "isCorrect": false
      },
      {
        "id": 3229,
        "content": [
          "measured values with the highest uncertainty."
        ],
        "isCorrect": false
      },
      {
        "id": 3230,
        "content": [
          "exactly known digits with the last digit uncertain."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 808,
    "content": [
      "For the determination of the density of a new ceramic, a student measured the mass of a piece on an analytical balance and obtained 3.8056 gram and its volume 2.5 mL by displacement of water in a graduated cylinder. The correct reported density of the ceramic should be"
    ],
    "explanation": [
      "To calculate the density, we use the formula:\n$$\nDensity = \\frac{Mass}{Volume}\n$$\nGiven the mass is 3.8056 g and the volume is 2.5 mL.\n$$\nDensity = \\frac{3.8056 \\, g}{2.5 \\, mL} = 1.52224 \\, g/mL\n$$\nHowever, we need to consider significant figures. The volume (2.5 mL) has only two significant figures, so the density should also be reported with two significant figures. Therefore, the correct reported density is 1.5 g/mL."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3231,
        "content": [
          "1.5222 g/mL"
        ],
        "isCorrect": false
      },
      {
        "id": 3232,
        "content": [
          "1.5224 g/mL"
        ],
        "isCorrect": false
      },
      {
        "id": 3233,
        "content": [
          "1.5 g/mL"
        ],
        "isCorrect": true
      },
      {
        "id": 3234,
        "content": [
          "3.5 g/mL"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 809,
    "content": [
      "The scientific method is"
    ],
    "explanation": [
      "The scientific method is a systematic approach to gaining knowledge through observation, experimentation, and analysis.\n\nIt involves formulating hypotheses, designing experiments to test those hypotheses, collecting data, and drawing conclusions based on the evidence.\n\nThe key aspect is that the experiments must be reproducible to validate the findings."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3235,
        "content": [
          "a collection of scientific guesses and hypotheses by seeking patterns in the observations."
        ],
        "isCorrect": false
      },
      {
        "id": 3236,
        "content": [
          "a method of arriving at an organized body of knowledge based on reproducible experiments and observations."
        ],
        "isCorrect": true
      },
      {
        "id": 3237,
        "content": [
          "the sum total of unique guidelines for the practice of science in the world."
        ],
        "isCorrect": false
      },
      {
        "id": 3238,
        "content": [
          "the result of fortunate, accidental discovery in the development of science."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Chemistry and it's Importance"
  },
  {
    "id": 810,
    "content": [
      "One of the following is NOT a cause of uncertainty in measurement?"
    ],
    "explanation": [
      "The type of material measured itself is not a cause of uncertainty; rather, factors related to the measurement process and the tools used contribute to uncertainty."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3239,
        "content": [
          "The type of material measured"
        ],
        "isCorrect": true
      },
      {
        "id": 3240,
        "content": [
          "The person doing the experiment"
        ],
        "isCorrect": false
      },
      {
        "id": 3241,
        "content": [
          "The measuring device"
        ],
        "isCorrect": false
      },
      {
        "id": 3242,
        "content": [
          "The environment where the measurement is made"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 811,
    "content": [
      "Which of the following is true about isotopes? Isotopes of an element have"
    ],
    "explanation": [
      "Isotopes of an element have the same number of protons but different numbers of neutrons. This difference in neutron number leads to variations in their atomic mass."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3243,
        "content": [
          "the same number of electrons and neutrons."
        ],
        "isCorrect": false
      },
      {
        "id": 3244,
        "content": [
          "different number of neutrons and the same number protons."
        ],
        "isCorrect": true
      },
      {
        "id": 3245,
        "content": [
          "different physical and chemical properties."
        ],
        "isCorrect": false
      },
      {
        "id": 3246,
        "content": [
          "the same atomic mass but different atomic numbers."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 812,
    "content": [
      "The following diagrammatic representations shows the shape for various orbitals. Which one represents the $$d_z^2$$ orbitals?"
    ],
    "explanation": [
      "The $$d_z^2$$ orbital has a unique shape, consisting of two lobes along the z-axis and a donut-shaped ring (torus) around the center in the xy-plane. This shape is accurately represented in option A."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_QUANTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3247,
        "content": [
          "images/chemistry/year_2013/q7c1_1_background.png"
        ],
        "isCorrect": true
      },
      {
        "id": 3248,
        "content": [
          "images/chemistry/year_2013/q7c2_1_background.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3249,
        "content": [
          "images/chemistry/year_2013/q7c3_1_background.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3250,
        "content": [
          "images/chemistry/year_2013/q7c4_1_background.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 814,
    "content": [
      "Which statement correctly describes Heisenberg's uncertainty principle?"
    ],
    "explanation": [
      "Heisenberg's uncertainty principle states that it is impossible to know both the exact position and momentum of a particle."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_QUANTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3255,
        "content": [
          "If we measure the momentum of a particle precisely then its position will be correspondingly precise."
        ],
        "isCorrect": false
      },
      {
        "id": 3256,
        "content": [
          "A particle with a mass moving at a given speed can be described by the wave characteristics of material particles."
        ],
        "isCorrect": false
      },
      {
        "id": 3257,
        "content": [
          "A small particle like the electron can behave both as a particle and a wave."
        ],
        "isCorrect": false
      },
      {
        "id": 3258,
        "content": [
          "Both the location and the momentum of a subatomic particle like the electron cannot be precisely known."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 815,
    "content": [
      "Which of the following statement is correct about energy changes when an electron changes its energy level?"
    ],
    "explanation": [
      "When an electron jumps from a lower energy level to a higher energy level, it absorbs energy equal to the difference between the two energy levels."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_QUANTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3259,
        "content": [
          "When an electron jumps from a lower energy level to a higher level, the photon emitted is equal to the difference between the two energy levels."
        ],
        "isCorrect": false
      },
      {
        "id": 3260,
        "content": [
          "When an electron falls from a higher energy level to a lower energy level, the energy is equal to the difference between the two energy levels is observed."
        ],
        "isCorrect": false
      },
      {
        "id": 3261,
        "content": [
          "When an electron jumps from a lower energy level to a higher level, the energy is equal to the difference between the two energy levels is absorbed."
        ],
        "isCorrect": true
      },
      {
        "id": 3262,
        "content": [
          "When an electron falls from a higher energy level to a lower energy level, the energy is higher than the difference between the two energy levels is emitted."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 816,
    "content": [
      "The sanitizer in wide use for protection against Covid-19 is labeled 83% alcohol. How can one scientifically check the concentration? This can be done by"
    ],
    "explanation": [
      "To scientifically check the concentration of the alcohol in the sanitizer, the best approach is through experimentation."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3263,
        "content": [
          "forming a hypothesis."
        ],
        "isCorrect": false
      },
      {
        "id": 3264,
        "content": [
          "experimentation."
        ],
        "isCorrect": true
      },
      {
        "id": 3265,
        "content": [
          "collection of data."
        ],
        "isCorrect": false
      },
      {
        "id": 3266,
        "content": [
          "making observation."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Chemistry and it's Importance"
  },
  {
    "id": 817,
    "content": [
      "The correct electronic configuration for chromium (Cr, Z=24) is"
    ],
    "explanation": [
      "The correct electronic configuration for Chromium (Cr, Z=24) is $$1s^22s^22p^63s^23p^64s^13d^5$$.\n\nChromium is an exception to Hund's rule. It promotes an electron from the 4s orbital to the 3d orbital to achieve a more stable half-filled d subshell."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3267,
        "content": [
          "$$1s^22s^22p^63s^23p^63d^44d^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3268,
        "content": [
          "$$1s^22s^22p^63s^23p^64s^03d^6$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3269,
        "content": [
          "$$1s^22s^22p^63s^23p^64s^13d^5$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3270,
        "content": [
          "$$1s^22s^22p^63s^23p^64s^23d^4$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 828,
    "content": [
      "Which of the following pair is true about the general properties of the different types of crystalline solids",
      "images/chemistry/year_2013/q23_1.png"
    ],
    "explanation": [
      "- Ionic solids are hard, have high melting points, and conduct electricity when dissolved in water or molten.\n- Metallic solids have hardness ranging from soft to hard, have melting points ranging from low to high, and are good conductors of electricity and heat.\n\nTherefore, statements I and IV are true."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2013/q23_1.png"
    ],
    "choices": [
      {
        "id": 3311,
        "content": [
          "I and III"
        ],
        "isCorrect": false
      },
      {
        "id": 3312,
        "content": [
          "II and III"
        ],
        "isCorrect": false
      },
      {
        "id": 3313,
        "content": [
          "I and II"
        ],
        "isCorrect": false
      },
      {
        "id": 3314,
        "content": [
          "I and IV"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 832,
    "content": [
      "According to the transition state theory"
    ],
    "explanation": [
      "According to transition state theory, during a reaction, reactants pass through a transition state where the original bonds are weakened and new bonds are partially formed in an activated complex. This complex represents the highest energy point in the reaction pathway between reactants and products."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3327,
        "content": [
          "the collision between two reacting species results in the formation of an activated complex, which has less energy than both the reactants and products."
        ],
        "isCorrect": false
      },
      {
        "id": 3328,
        "content": [
          "in the activated complex, the original bonds are weakened and the new bonds are partially formed."
        ],
        "isCorrect": true
      },
      {
        "id": 3329,
        "content": [
          "the activation energy is the energy that must be absorbed or released by reactants to reach the activated complex."
        ],
        "isCorrect": false
      },
      {
        "id": 3330,
        "content": [
          "the standard reaction enthalpy ($$\\Delta H^0$$) depends on the magnitude of the activation energy ($$E_a$$)."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 834,
    "content": [
      "For a first order reaction, the concentration versus time of the reaction mixture is given by the following graph",
      "images/chemistry/year_2013/q29_1.png",
      "If a is the initial concentration of the reactant and if the half-life is 1hr, after how many hours would be the concentration of reactant reduced to a/32?"
    ],
    "explanation": [
      "For a first-order reaction, the concentration reduces by half in each half-life period. The half-life is given as 1 hour. To reach a/32, the concentration must halve 5 times ($$1/2^5 = 1/32$$). Therefore, it will take 5 half-lives, which equals 5 hours."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2013/q29_1.png"
    ],
    "choices": [
      {
        "id": 3335,
        "content": [
          "1 hr"
        ],
        "isCorrect": false
      },
      {
        "id": 3336,
        "content": [
          "4 hr"
        ],
        "isCorrect": false
      },
      {
        "id": 3337,
        "content": [
          "5 hr"
        ],
        "isCorrect": true
      },
      {
        "id": 3338,
        "content": [
          "3 hr"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Acid Base Equilibria"
  },
  {
    "id": 838,
    "content": [
      "The law of mass action states that"
    ],
    "explanation": [
      "The law of mass action states that the rate of a chemical reaction is directly proportional to the product of the activities or concentrations of the reactants raised to the power of their respective stoichiometric coefficients in the balanced chemical equation."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3351,
        "content": [
          "the rate of a reaction is directly proportional to the product of the concentration of reactants raised to the power of their respective coefficients in the balanced equation."
        ],
        "isCorrect": true
      },
      {
        "id": 3352,
        "content": [
          "the Keq expression is the ratio of the concentrations of reactants to the products raised to their coefficients."
        ],
        "isCorrect": false
      },
      {
        "id": 3353,
        "content": [
          "a chemical equilibrium is attained only when the reaction is started with reactants."
        ],
        "isCorrect": false
      },
      {
        "id": 3354,
        "content": [
          "for a reaction at equilibrium, the reaction quotient, Q is always less than the equilibrium constant, Keq."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 842,
    "content": [
      "Which one of the following statements describes laboratory and industrial preparation of acetic acid respectively?"
    ],
    "explanation": [
      "**Laboratory Preparation:**\n\n- Acetic acid can be prepared in the lab by oxidation of ethanol using an oxidizing agent like sodium dichromate in acidic medium.\n- This method is commonly used in organic chemistry laboratories.\n\n**Industrial Preparation:**\n\n- Acetic acid is industrially produced by fermentation of ethanol using acetic acid bacteria (*Acetobacter* species).\n- The process is called oxidative fermentation, where ethanol is oxidized to acetic acid.\n- This is the principle behind vinegar production."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3367,
        "content": [
          "Reduction of toluene by $$KMnO_4$$ and reduction of ethanol by sodium dichromate."
        ],
        "isCorrect": false
      },
      {
        "id": 3368,
        "content": [
          "Reduction of ethanol by $$NaBH_4$$ and fermentation of propanol."
        ],
        "isCorrect": false
      },
      {
        "id": 3369,
        "content": [
          "Oxidation of toluene by $$KMnO_4$$ and fermentation of ethanol."
        ],
        "isCorrect": true
      },
      {
        "id": 3370,
        "content": [
          "The oxidation of ethanol by sodium dichromate and fermentation of ethanol."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 848,
    "content": [
      "The difference between colloids and suspension is that"
    ],
    "explanation": [
      "Colloidal particles are smaller than the particles in a suspension. This smaller size allows colloidal particles to remain dispersed and prevents them from settling down, unlike the larger particles in a suspension, which will eventually settle out of the mixture."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3391,
        "content": [
          "colloidal particles are small enough and do not settle down unlike in a suspension."
        ],
        "isCorrect": true
      },
      {
        "id": 3392,
        "content": [
          "most colloids and suspensions appear cloudy."
        ],
        "isCorrect": false
      },
      {
        "id": 3393,
        "content": [
          "both colloids and suspensions are heterogeneous mixtures."
        ],
        "isCorrect": false
      },
      {
        "id": 3394,
        "content": [
          "colloids are as transparent as solutions."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 849,
    "content": [
      "The solubility of a substance is the amount of a substance that"
    ],
    "explanation": [
      "Solubility refers to the maximum amount of a solute that can dissolve in a solvent at a given temperature to form a saturated solution."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3395,
        "content": [
          "gives an unsaturated solution of the substance at given temperature."
        ],
        "isCorrect": false
      },
      {
        "id": 3396,
        "content": [
          "dissolves more amount of solute than it can normally dissolve."
        ],
        "isCorrect": false
      },
      {
        "id": 3397,
        "content": [
          "gives a saturated solution of the substance at a given temperature."
        ],
        "isCorrect": true
      },
      {
        "id": 3398,
        "content": [
          "dissolves double the amount of solute than it can normally dissolve."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 850,
    "content": [
      "50 mL of the supernatant saturated solution of $$NaCl$$ was taken in an evaporating dish (weight = $$w_0$$) and evaporated over a Bunsen burner until all the water has evaporated and dry sodium chloride is left in the evaporating dish. The evaporating dish with the dry sodium chloride is weighed (weight = $$w_1$$). Given the following information, $$w_0$$= 47.5 g and $$w_1$$ = 66.2. Calculate the solubility of $$NaCl$$ in water assuming 50 mL of the solution is equal to 50 mL of the solvent"
    ],
    "explanation": [
      "The mass of $$NaCl$$ is $$w_1 - w_0$$ = $$66.2 - 47.5$$ = $$18.7 \\, g$$. Assuming the density of water is 1 g/mL, 50 mL of water has a mass of 50 g. The mass of water in the solution is therefore 50 g. Solubility is expressed as g of solute per 100 g of water. So, $$S$$ = ($$18.7 \\, g \\, NaCl$$ / $$50 \\, g \\, water$$) $$\\times$$ $$100$$ = $$37.4 \\, g \\, NaCl$$ / $$100 \\, g \\, water$$."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3399,
        "content": [
          "37.4 g/100 g of water"
        ],
        "isCorrect": true
      },
      {
        "id": 3400,
        "content": [
          "113.7 g/100 g of water"
        ],
        "isCorrect": false
      },
      {
        "id": 3401,
        "content": [
          "18.7 g/100 g of water"
        ],
        "isCorrect": false
      },
      {
        "id": 3402,
        "content": [
          "187 g/100 g of water"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 851,
    "content": [
      "The \"like dissolves like \" rule accounts for one of the following observation"
    ],
    "explanation": [
      "The \"like dissolves like\" rule states that polar solvents dissolve polar solutes, and nonpolar solvents dissolve nonpolar solutes. Benzene ($$C_6H_6$$) is a nonpolar molecule, and carbon tetrachloride ($$CCl_4$$) is also a nonpolar solvent. Therefore, benzene is soluble in carbon tetrachloride because both are nonpolar."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3403,
        "content": [
          "The solubility of $$C_6H_6$$ in $$CCl_4$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3404,
        "content": [
          "The solubility of $$C_2H_6$$ in $$H_2O$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3405,
        "content": [
          "The solubility of $$KBr$$ in $$C_7H_8$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3406,
        "content": [
          "The insolubility of $$I_2$$ in $$H_2O$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 852,
    "content": [
      "Which of the following concentration units is correctly defined?"
    ],
    "explanation": [
      "Mass percentage is defined as the mass of the solute divided by the mass of the solution (solute + solvent), multiplied by 100. The correct formula is:\n$$\nMass \\, Percentage = \\frac{Mass \\, of \\, Solute}{Mass \\, of \\, Solution} \\times 100\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3407,
        "content": [
          "mass percentage = $$\\frac{mass \\, of \\, solute}{mass \\, of \\, solvent} \\times 100$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3408,
        "content": [
          "ppm (parts per million) = $$\\frac{mass \\, of \\, solute}{mass \\, of \\, solvent} \\times 10^6$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3409,
        "content": [
          "ppb (parts per billion) = $$\\frac{mass \\, of \\, solute}{mass \\, of \\, solution} \\times 10^6$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3410,
        "content": [
          "mass percentage = $$\\frac{mass \\, of \\, solute}{mass \\, of \\, solution} \\times 100$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 853,
    "content": [
      "The concentrated sulphuric acid $$H_2SO_4$$ we use in the laboratory is 98% $$H_2SO_4$$ by mass and has a density of 1.83 g/ mL. Below are given the concentrations of the acid in various units. which of the given alternatives correctly describes the concentration of the acid?"
    ],
    "explanation": [
      "The molar mass of H₂SO₄ is approximately 98 g/mol.\n\nGiven: 98% H₂SO₄  by mass, density = 1.83 g/mL\n\nIn 100 g of solution, there are 98 g of H₂SO₄. The volume of this solution is $$100 \\, g / 1.83 \\, g/mL$$ $$\\approx$$ $$54.64 \\, mL$$.\n\nTo find molarity (M): M = $$\\frac{moles \\, of \\, solute}{liters \\, of \\, solution}$$ = $$\\frac{98 \\, g / 98 \\, g/mol}{0.05464 \\, L}$$ = $$\\frac{1 \\, mol}{0.05464 \\, L} \\approx 18.3 \\, M$$\n\nNormality (N) is related to molarity by the number of equivalents per mole. For H2SO4, there are 2 acidic protons, so normality\n\nN = $$M \\times 2$$ = $$18.3 \\, M \\times 2$$ = $$36.6 \\, N$$.\n\nMole fraction (x) is the number of moles of solute divided by the total number of moles in the solution. Moles of H2SO4 = 1 mol (in 100 g solution).\n\nMoles of water = $$2 \\, g \\, H_2O / 18 \\, g/mol$$ $$\\approx$$ $$0.11 \\, mol$$.\n\nMole fraction = $$\\frac{1}{1 + 0.11}$$ $$\\approx$$ $$0.9$$"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3411,
        "content": [
          "Molarity = 18.3 M, Normality = 36.6 N, Mole fraction = 0.9"
        ],
        "isCorrect": true
      },
      {
        "id": 3412,
        "content": [
          "Molarity = 36.6 M, Normality = 18.3, N Mole fraction = 0.1"
        ],
        "isCorrect": false
      },
      {
        "id": 3413,
        "content": [
          "Molarity = 18.3 M, Normality = 3.66 N, Mole fraction = 0.9"
        ],
        "isCorrect": false
      },
      {
        "id": 3414,
        "content": [
          "Molarity = 1.83 M, Normality = 3.66 N, Mole fraction = 0.9"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 854,
    "content": [
      "How do you prepare 500mL of 1N $$Ca(OH)_2$$ solution? (Ca = 40, H = 1, O = 16)"
    ],
    "explanation": [
      "To prepare a **1N (Normal) solution** of **Ca(OH)₂**, we must determine the weight of **Ca(OH)₂** required per liter.\n\nThe molecular weight of **Ca(OH)₂** is: $$40$$ + $$(2 \\times 16)$$ + $$(2 \\times 1)$$ = $$74 \\text{ g/mol}$$\n\nSince **Ca(OH)₂** provides **2 hydroxide ions (OH⁻)** per molecule, the **equivalent weight** is:\n$$\n\\frac{74}{2} = 37 \\text{ g}\n$$\nBy definition, a **1N** solution contains **1 equivalent weight** (37 g) of solute per **liter** of solution.\nThus, for **1 liter of 1N solution**, we need **37 g of Ca(OH)₂**.\n\nSince 500 mL is **half of 1 liter**, we need half of 37 g:\n$$\n\\frac{37}{2} = 18.5 \\text{ g}\n$$\nOr we can dissolve 37g of $$Ca(OH)_2$$ in one liter and use 500ml from it to prepare 500mL of 1N $$Ca(OH)_2$$ solution,"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3415,
        "content": [
          "By dissolving 37 g of $$Ca(OH)_2$$ in 1 liter of solution."
        ],
        "isCorrect": true
      },
      {
        "id": 3416,
        "content": [
          "By dissolving 74 g of $$Ca(OH)_2$$ in 500.mL of solution."
        ],
        "isCorrect": false
      },
      {
        "id": 3417,
        "content": [
          "By dissolving 74 g of $$Ca(OH)_2$$ in 1 liter of solution."
        ],
        "isCorrect": false
      },
      {
        "id": 3418,
        "content": [
          "By dissolving 37 g of $$Ca(OH)_2$$ in 500.mL of solution."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 855,
    "content": [
      "The Ka of acetic acid $$CH_3COOH$$ is $$1.8 \\times 10^{-5}$$. What is the percent ionization of 1M $$CH_3COOH$$?"
    ],
    "explanation": [
      "**Note: We added the correct choice since the question on the paper has a mistake.**\n\nWe begin by writing the acid dissociation equilibrium for acetic acid:\n\n$$CH_3COOH$$ ⇌ $$H^+ + CH_3COO^-$$\n\nGiven that the initial concentration is 1 M and the acid dissociates by an amount x, at equilibrium we have:\n- $$[CH_3COOH] \\approx 1 - x \\approx 1$$ (since  is very small)\n- $$[H^+]$$ = $$x$$\n- $$[CH_3COO^-]$$ = $$x$$\n\nThe acid dissociation constant $$K_a$$ is given by:\n\n$$\nK_a = \\frac{[H^+][CH_3COO^-]}{[CH_3COOH]} \\approx \\frac{x^2}{1}\n$$\n\n$$\nx^2 = K_a = 1.8 \\times 10^{-5}\n$$\n\n$$\nx = \\sqrt{1.8 \\times 10^{-5}} \\approx 0.00424\n$$\n\n$$\n\\text{Percentage Ionization} = \\left(\\frac{x}{1}\\right) \\times 100\\% \\approx 0.424\\%\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3419,
        "content": [
          "3.6"
        ],
        "isCorrect": false
      },
      {
        "id": 3420,
        "content": [
          "1.42"
        ],
        "isCorrect": false
      },
      {
        "id": 3421,
        "content": [
          "1.34"
        ],
        "isCorrect": false
      },
      {
        "id": 3422,
        "content": [
          "4.2"
        ],
        "isCorrect": false
      },
      {
        "id": 3423,
        "content": [
          "0.42"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 878,
    "content": [
      "$$CO_2$$ is released into the atmosphere by one of the following processes"
    ],
    "explanation": [
      "Natural fires and volcanoes release carbon dioxide ($$CO_2$$) into the atmosphere as they burn organic material or emit gases from the Earth's crust."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3512,
        "content": [
          "Plants consume atmospheric carbon dioxide during photosynthesis."
        ],
        "isCorrect": false
      },
      {
        "id": 3513,
        "content": [
          "Animals eat plants and release $$CO_2$$ by photosynthesis."
        ],
        "isCorrect": false
      },
      {
        "id": 3514,
        "content": [
          "Natural fires and volcanoes release $$CO_2$$ into the air."
        ],
        "isCorrect": true
      },
      {
        "id": 3515,
        "content": [
          "Utilization of electrical energy as energy sources."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Chemistry and it's Importance"
  },
  {
    "id": 949,
    "content": [
      "Which of the following is the product of fractional distillation of crude oil?"
    ],
    "explanation": [
      "Fractional distillation of crude oil is a process that separates crude oil into different fractions based on their boiling points. Kerosene is one of the fractions obtained through this process."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3796,
        "content": [
          "Producer gas"
        ],
        "isCorrect": false
      },
      {
        "id": 3797,
        "content": [
          "Naphthalene"
        ],
        "isCorrect": false
      },
      {
        "id": 3798,
        "content": [
          "Water gas"
        ],
        "isCorrect": false
      },
      {
        "id": 3799,
        "content": [
          "Kerosene"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 952,
    "content": [
      "During summer, the average value for the temperature measured in a certain chemistry laboratory is 298.15 K. How many decimal places are there in the measured value?"
    ],
    "explanation": [
      "The number of decimal places is determined by counting the digits to the right of the decimal point. **298.15** has **two** decimal places."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3808,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 3809,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 3810,
        "content": [
          "2"
        ],
        "isCorrect": true
      },
      {
        "id": 3811,
        "content": [
          "1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 954,
    "content": [
      "A student collected four beakers in his/her laboratory and added some small amounts of the following: naphthalene to the first, graphite to the second, iodine to the third and alcohol to the fourth. If they added equal volume of water to each of the above beakers and shake each beaker, which of the following will be their observation?"
    ],
    "explanation": [
      "Naphthalene, graphite, and iodine are non-polar substances that are not soluble in water (a polar solvent). Alcohol, however, is soluble in water."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3816,
        "content": [
          "There will be dissolution in the first three breakers."
        ],
        "isCorrect": false
      },
      {
        "id": 3817,
        "content": [
          "Water will dissolve iodine rather than graphite."
        ],
        "isCorrect": false
      },
      {
        "id": 3818,
        "content": [
          "Water will dissolve the whole given chemicals in the four beakers."
        ],
        "isCorrect": false
      },
      {
        "id": 3819,
        "content": [
          "There will be dissolution of alcohol in the fourth beaker."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 955,
    "content": [
      "Which of the following explanations about reversible and irreversible reactions is CORRECT?"
    ],
    "explanation": [
      "An irreversible reaction is a chemical reaction that proceeds in one direction only: the reactants form products, but the products do not reform the reactants to any noticeable extent."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3820,
        "content": [
          "A reaction that has only a forward reaction or a reverse reaction is known as a reversible chemical reaction."
        ],
        "isCorrect": false
      },
      {
        "id": 3821,
        "content": [
          "A reaction that proceeds from reactant to product and from product to reactant is known as an irreversible reaction."
        ],
        "isCorrect": false
      },
      {
        "id": 3822,
        "content": [
          "Chemical reactions that proceed only towards the formation of a product are known as irreversible reactions."
        ],
        "isCorrect": true
      },
      {
        "id": 3823,
        "content": [
          "Chemical reactions that proceed only towards the formation of a product are known as reversible reactions."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 956,
    "content": [
      "Consider the following three steps:",
      "Step: 1 Electrolysis of water and fractional distillation of air",
      "Step: 2 Passing hot mixture of gases through a condenser",
      "Step: 3 Introducing hydrogen and nitrogen gases in a chamber containing iron particles at a temperature of 300-500 °C and a pressure of 15-25 MPa",
      "Which of the following is the CORRECT sequence involved during the industrial production of ammonia using the Haber process?"
    ],
    "explanation": [
      "Reactants (H₂, N₂) are first produced (Step 1), then reacted under catalytic conditions to form ammonia (Step 3), and finally, ammonia is separated by condensation (Step 2)."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3824,
        "content": [
          "Step 1 → Step 3 → Step 2"
        ],
        "isCorrect": true
      },
      {
        "id": 3825,
        "content": [
          "Step 2 → Step 3 → Step 1"
        ],
        "isCorrect": false
      },
      {
        "id": 3826,
        "content": [
          "Step 2 → Step 1 → Step 3"
        ],
        "isCorrect": false
      },
      {
        "id": 3827,
        "content": [
          "Step 1 → Step 2 → Step 3"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 959,
    "content": [
      "A student collected the following information from the community on the preparation of the local alcoholic drink \"ARAKI\":",
      "Step: 1 Distillation of the liquid mixture in traditional ways",
      "Step: 2 Adding a proportional amount of water to liquidity the tick dough-like mixture and leaving for 1-2 days for further fermentation",
      "Step: 3 \"Bikel\" preparation from barely, the starter (\"Tinses\") preparation by mixing the Bikel with Gesho (Rhamnuspronoides) powder and fermentation of the starter for few days",
      "Step: 4 Baking of bread from different ingredients and breaking down the bread and mixing with the fermented starter and leaving for fermentation for couple of days",
      "Which of the following is the correct procedure for the preparation of Araki?"
    ],
    "explanation": [
      "First, the starter (\"Tinses\") is prepared (Step 3). This starter is then used to ferment the main ingredients (bread) (Step 4). The resulting mixture is liquefied and undergoes further fermentation (Step 2). Finally, the fermented liquid is distilled (Step 1)."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3836,
        "content": [
          "Step - 2 → Step - 4 → Step - 3 → Step - 1"
        ],
        "isCorrect": false
      },
      {
        "id": 3837,
        "content": [
          "Step - 2 → Step - 3 → Step - 4 → Step - 1"
        ],
        "isCorrect": false
      },
      {
        "id": 3838,
        "content": [
          "Step - 3 → Step - 4 → Step - 2 → Step - 1"
        ],
        "isCorrect": true
      },
      {
        "id": 3839,
        "content": [
          "Step - 4 → Step - 3 → Step - 2 → Step - 1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 967,
    "content": [
      "The pH of a 0.10 M solution of an aqueous solution of a certain acid is 3. What is the value of acid ionization constant ($$K_a$$) of this acid?"
    ],
    "explanation": [
      "Given pH = 3, we can find the concentration of $$H^+$$ ions:\n$$\n[H^+] = 10^{-pH} = 10^{-3} \\text{ M}\n$$\nFor a weak acid HA, the dissociation is: $$HA$$ ⇌ $$H^+ + A^-$$",
      "|  | HA | H⁺ | A⁻ |\n| --- | --- | --- | --- |\n| Initial | 0.10 M | 0 | 0 |\n| Change | -x | +x | +x |\n| Equilibrium | 0.10 - x | x | x |",
      "Since the pH is 3, x = $$[H^+]$$ = $$10^{-3}$$\n\nThe acid ionization constant $$K_a$$ is given by:\n$$\nK_a = \\frac{[H^+][A^-]}{[HA]}\n$$\n$$\nK_a = \\frac{x^2}{0.10-x}\n$$\n$$\nK_a = \\frac{(10^{-3})^2}{0.10 - 10^{-3}} \\approx \\frac{10^{-6}}{0.10} = 10^{-5}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3868,
        "content": [
          "$$1.0 \\times 10^{-7}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3869,
        "content": [
          "$$1.0 \\times 10^{-5}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3870,
        "content": [
          "$$1.0 \\times 10^{-3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3871,
        "content": [
          "$$1.0 \\times 10^{-1}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 968,
    "content": [
      "The shift in the position of equilibrium caused by the addition of an ion already involved in the reaction is known as"
    ],
    "explanation": [
      "The common ion effect describes the decrease in the solubility of a sparingly soluble salt when a soluble salt containing a common ion is added to the solution."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3872,
        "content": [
          "common - ion effect"
        ],
        "isCorrect": true
      },
      {
        "id": 3873,
        "content": [
          "buffer - ion effect"
        ],
        "isCorrect": false
      },
      {
        "id": 3874,
        "content": [
          "hydrolysis - effect"
        ],
        "isCorrect": false
      },
      {
        "id": 3875,
        "content": [
          "titration -effect"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 969,
    "content": [
      "Which of the following is CORRECT about equivalents of acids and bases?"
    ],
    "explanation": [
      "The equivalent of an acid or base is the amount that reacts with one mole of hydroxide ions or hydrogen ions, respectively."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3876,
        "content": [
          "The volume of an acid or base required to reach equivalence point during acid - base titration reaction."
        ],
        "isCorrect": false
      },
      {
        "id": 3877,
        "content": [
          "The number of moles of an acid or base required to form a one molar aqueous acidic or basic solution."
        ],
        "isCorrect": false
      },
      {
        "id": 3878,
        "content": [
          "It is the amount of a substance that is required to react with one mole of hydroxide ions in redox reactions."
        ],
        "isCorrect": false
      },
      {
        "id": 3879,
        "content": [
          "It is the amount of a substance that is required to react with one mole of hydrogen ions in acid - base reactions."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 970,
    "content": [
      "A 250 mL solution is formed from 24.5 g of sulfuric acid (H₂SO₄). What is the normality of this solution? (Mt. wt. H₂SO₄ = 98 g/mol)"
    ],
    "explanation": [
      "First, calculate the number of moles of $$H_2SO_4$$:\n$$\nmoles = \\frac{mass}{molar \\ mass} = \\frac{24.5 \\ g}{98 \\ g/mol} = 0.25 \\ mol\n$$\nSince $$H_2SO_4$$ is a diprotic acid, its equivalent weight is half of its molar mass. Thus, 1 mol of $$H_2SO_4$$ is 2 equivalents.\n$$\nequivalents = moles \\times n_{factor}\n$$\n$$\nequivalents = 0.25 \\ mol \\times 2 = 0.5 \\ equivalents\n$$\nNormality is defined as equivalents per liter of solution:\n$$\nN = \\frac{equivalents}{volume \\ in \\ liters}\n$$\n$$\nN = \\frac{0.5 \\ equivalents}{0.250 \\ L} = 2.00 \\ N\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3880,
        "content": [
          "4.00 N"
        ],
        "isCorrect": false
      },
      {
        "id": 3881,
        "content": [
          "2.00 N"
        ],
        "isCorrect": true
      },
      {
        "id": 3882,
        "content": [
          "0.250 N"
        ],
        "isCorrect": false
      },
      {
        "id": 3883,
        "content": [
          "0.125 N"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 971,
    "content": [
      "Which of the following reaction is used for the preparation of bases?"
    ],
    "explanation": [
      "Active metal oxides react with water to form metal hydroxides, which are bases. For example, $$Na_2O + H_2O \\rightarrow 2NaOH$$."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3884,
        "content": [
          "Reaction of metal hydroxides with dilute acids."
        ],
        "isCorrect": false
      },
      {
        "id": 3885,
        "content": [
          "Reaction of active metal oxides with water."
        ],
        "isCorrect": true
      },
      {
        "id": 3886,
        "content": [
          "Heating of a salt with a non- volatile acid."
        ],
        "isCorrect": false
      },
      {
        "id": 3887,
        "content": [
          "Heating of carbonates with dilute acids."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 973,
    "content": [
      "A student prepared two beakers, each containing 100 mL of water. The student dissolved 10 mL of concentrated $$HCl$$ in the first beaker and 10 mL of concentrated $$CH_3COOH$$ in the second beaker, which of the following would occur in the solution?"
    ],
    "explanation": [
      "$$HCl$$ is a strong acid and dissociates almost completely into ions in water. $$CH_3COOH$$ (acetic acid) is a weak acid and only a small fraction dissociates into ions in water."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3892,
        "content": [
          "In the first beaker, a large fraction of $$HCl$$ dissociates into ions and in the second beaker, a small fraction of $$CH_3COOH$$ dissociates into ions."
        ],
        "isCorrect": true
      },
      {
        "id": 3893,
        "content": [
          "In the first beaker, a small fraction of $$HCl$$ dissociates into ions and in the second beaker, a large fraction of $$CH_3COOH$$ dissociates into ions."
        ],
        "isCorrect": false
      },
      {
        "id": 3894,
        "content": [
          "There is no dissociation or ionization of the $$HCl$$ and $$CH_3COOH$$ in both the first and second beakers."
        ],
        "isCorrect": false
      },
      {
        "id": 3895,
        "content": [
          "The amount of $$HCl$$ dissociated in the first beaker and the amount of $$CH_3COOH$$ dissociated in the second beaker are identical."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 975,
    "content": [
      "Which of the following food preservation methods leaves a product without loss of aroma or flavor?"
    ],
    "explanation": [
      "Freeze-drying (lyophilization) removes water from the product by sublimation, which occurs under low temperatures and vacuum conditions. This process minimizes the loss of volatile aromatic compounds, thus preserving the aroma and flavor of the food."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3900,
        "content": [
          "Vacuum - packing"
        ],
        "isCorrect": false
      },
      {
        "id": 3901,
        "content": [
          "Freeze - drying"
        ],
        "isCorrect": true
      },
      {
        "id": 3902,
        "content": [
          "Freezing"
        ],
        "isCorrect": false
      },
      {
        "id": 3903,
        "content": [
          "Melting"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 981,
    "content": [
      "From the assumption of kinetic molecular theory of gases, which of the following is CORRECT?"
    ],
    "explanation": [
      "According to the kinetic molecular theory, gas particles are in constant, random motion, and the volume of the gas particles themselves is negligible compared to the space they occupy.\n\nTherefore, under ordinary conditions, the total volume of gas molecules is much smaller than the total volume of gas."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3924,
        "content": [
          "The pressure of a gas is the effect of the negligible volume of the gas compared to the total volume of the gas"
        ],
        "isCorrect": false
      },
      {
        "id": 3925,
        "content": [
          "The average kinetic energy of gas particles is inversely proportional to the absolute temperature of the gas."
        ],
        "isCorrect": false
      },
      {
        "id": 3926,
        "content": [
          "There are some forces of attraction or repulsion between gas particles."
        ],
        "isCorrect": false
      },
      {
        "id": 3927,
        "content": [
          "Under ordinary conditions, the total volume of gas molecules is much smaller than the total volume of gas."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 982,
    "content": [
      "Which of the following is CORRECT about the phase change observed in water?"
    ],
    "explanation": [
      "At the melting point of ice, the temperature remains constant because the energy added is used to break the intermolecular forces (hydrogen bonds) holding the solid structure together, rather than increasing the kinetic energy of the molecules (which would raise the temperature)."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3928,
        "content": [
          "Water starts to evaporate at the boiling point and condenses at the melting point."
        ],
        "isCorrect": false
      },
      {
        "id": 3929,
        "content": [
          "When a solid ice is heated, it is changed to liquuid water without melting."
        ],
        "isCorrect": false
      },
      {
        "id": 3930,
        "content": [
          "At the boiling point temperature, water exists in three different physical states."
        ],
        "isCorrect": false
      },
      {
        "id": 3931,
        "content": [
          "At the melting point of ice, the temperature remains constant."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 991,
    "content": [
      "A student is interested in determining the content of a leaf from his/her environment and performed the following.",
      "Step 1: He/she dried the leaves up in sun light",
      "Step 2: Evaluated the work and draw conclusions",
      "Step 3: Collected leaves from the tree around his village",
      "Step 4: He/she boiled the leaves and collected the leaves extracted",
      "Step 5: Analyze the content of the leaves extracted using an instrument\nWhich of the following is the CORRECT procedure if a student developed an experimental skill?"
    ],
    "explanation": [
      "The logical sequence of steps in this experiment would be:\n- **Collect leaves** (Step 3)\n- **Dry the leaves** (Step 1)\n- **Boil the leaves** (Step 4)\n- **Analyze the content** (Step 5)\n- **Evaluate the work and draw conclusions** (Step 2)"
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3964,
        "content": [
          "Steps: 3 → 5 → 4 → 1 → 2"
        ],
        "isCorrect": false
      },
      {
        "id": 3965,
        "content": [
          "Steps: 3 → 4 → 1 → 5 → 2"
        ],
        "isCorrect": false
      },
      {
        "id": 3966,
        "content": [
          "Steps: 3 → 1 → 4 → 5 → 2"
        ],
        "isCorrect": true
      },
      {
        "id": 3967,
        "content": [
          "Steps: 3 → 1 → 5 → 4 → 2"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Chemistry and it's Importance"
  },
  {
    "id": 998,
    "content": [
      "A student collected few lemons from his/her backyard, brought it to their class and prepared a lemon juice in a beaker. They got blue and red litmus papers from his/her teacher and placed few drops of the lemon juice both on the red and blue litmus papers. What will be their observation on the litmus papers?"
    ],
    "explanation": [
      "Lemon juice is acidic due to the presence of citric acid.\n\nAcids turn blue litmus paper red. Red litmus paper remains red in acidic solutions. Therefore, the blue litmus paper will turn red, and the red litmus paper will maintain its color."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3993,
        "content": [
          "The blue litmus paper as well as the red litmus paper will maintain their color."
        ],
        "isCorrect": false
      },
      {
        "id": 3994,
        "content": [
          "The blue litmus paper and the red litmus paper will turn colorless."
        ],
        "isCorrect": false
      },
      {
        "id": 3995,
        "content": [
          "The red litmus paper will turn to blue and the blue litmus paper will maintain its color."
        ],
        "isCorrect": false
      },
      {
        "id": 3996,
        "content": [
          "The blue litmus paper will turn red and the red litmus paper will maintain its color."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 1005,
    "content": [
      "Which of the following chemical industries is INCORRECTLY matched with its products?"
    ],
    "explanation": [
      "The textile industry primarily deals with fabrics, yarns, and clothing, not glass. Therefore, the pairing of the textile industry with glasses is incorrect."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4021,
        "content": [
          "Textile industry- glasses"
        ],
        "isCorrect": true
      },
      {
        "id": 4022,
        "content": [
          "Beverage industry- alcohols"
        ],
        "isCorrect": false
      },
      {
        "id": 4023,
        "content": [
          "Food industry- Biscuits"
        ],
        "isCorrect": false
      },
      {
        "id": 4024,
        "content": [
          "Paper industry- cartons"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 1006,
    "content": [
      "A student added 25 mL of $$AgNO_3$$ solution to a beaker and weighed the mass of the beaker and its content as $$m_1$$. He/she added 50 mL of a saturated solution of $$NaCl$$ into the second beaker and weighed the mass of the beaker and its content as $$m_2$$. Finally, he/she mixed the two solutions and weighed the mass of the resulting solution with the two beakers and recorded as $$m_3$$. If he/she found that $$m_3$$ = $$m_1$$ + $$m_2$$, which one of the following laws is investigated by this trial?"
    ],
    "explanation": [
      "The law of conservation of mass states that mass is neither created nor destroyed in a chemical reaction. This means that the total mass of the reactants equals the total mass of the products."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4025,
        "content": [
          "Law of definite composition"
        ],
        "isCorrect": false
      },
      {
        "id": 4026,
        "content": [
          "Law of multiple proportions"
        ],
        "isCorrect": false
      },
      {
        "id": 4027,
        "content": [
          "Law of conservation of energy"
        ],
        "isCorrect": false
      },
      {
        "id": 4028,
        "content": [
          "Law of conservation of mass"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 1009,
    "content": [
      "\"At a given temperature and pressure, equal volumes of different gases contain equal number of molecules\", this is known as"
    ],
    "explanation": [
      "Avogadro's law states that at a given temperature and pressure, equal volumes of all gases contain the same number of molecules. This means that the number of molecules in a given volume of gas is independent of the size or mass of the gas molecules."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4037,
        "content": [
          "Charle's law"
        ],
        "isCorrect": false
      },
      {
        "id": 4038,
        "content": [
          "Boyle's law"
        ],
        "isCorrect": false
      },
      {
        "id": 4039,
        "content": [
          "Gay Lussac's law"
        ],
        "isCorrect": false
      },
      {
        "id": 4040,
        "content": [
          "Avogadro's law"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 1013,
    "content": [
      "A sample of a certain gas has a volume of 100 L at 27 °C and 750 torr. The gas is expanded to a volume of 250 L at 200 torr. What is the final temperature of the gas?"
    ],
    "explanation": [
      "We can use the combined gas law:\n$$\n\\frac{P_1V_1}{T_1} = \\frac{P_2V_2}{T_2}\n$$\nGiven:\n- $$P_1$$ = $$750 \\text{ torr}$$\n- $$V_1$$ = $$100 \\text{ L}$$\n- $$T_1$$ = $$27^\\circ C$$ = $$27 + 273.15$$ = $$300.15 \\text{ K}$$\n- $$P_2$$ = $$200 \\text{ torr}$$\n- $$V_2$$ = $$250 \\text{ L}$$\n\nSolve for $$T_2$$:\n$$\nT_2 = \\frac{P_2V_2T_1}{P_1V_1}\n$$\n$$\nT_2= \\frac{200 \\times 250 \\times 300.15}{750 \\times 100} = 200.1 \\text{ K}\n$$\nConvert to Celsius:\n$$\nT_2 = 200.1 - 273.15 = -73.05 ^\\circ C\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4053,
        "content": [
          "-83 °C"
        ],
        "isCorrect": false
      },
      {
        "id": 4054,
        "content": [
          "-73 °C"
        ],
        "isCorrect": true
      },
      {
        "id": 4055,
        "content": [
          "-17 °C"
        ],
        "isCorrect": false
      },
      {
        "id": 4056,
        "content": [
          "-273 °C"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 1014,
    "content": [
      "Which of the following is a CORRECT explanation of the given term?"
    ],
    "explanation": [
      "The boiling point is correctly defined as the temperature at which the vapor pressure of the liquid equals the atmospheric pressure. At this point, the liquid can overcome the surrounding pressure and change into a gaseous state."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4057,
        "content": [
          "Boiling point is the temperature at which the vapor pressure of the liquid equals the atmospheric pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 4058,
        "content": [
          "Condensation is the process by which a liquid changes to a gas at the boiling point of the liquid."
        ],
        "isCorrect": false
      },
      {
        "id": 4059,
        "content": [
          "Normal boiling point is the temperature at which the liquid starts to be converted to the gaseous state."
        ],
        "isCorrect": false
      },
      {
        "id": 4060,
        "content": [
          "Heat of vaporization is the energy required to convert one gram of a solid to a gas at its boiling point."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 1023,
    "content": [
      "What is the scientific notation for 0.0000055?"
    ],
    "explanation": [
      "The correct scientific notation for 0.0000055 is $$5.5 \\times 10^{-6}$$."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4093,
        "content": [
          "$$55 \\times 10^{-7}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4094,
        "content": [
          "$$5.5 \\times 10^{-6}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4095,
        "content": [
          "$$55 \\times 10^{-5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4096,
        "content": [
          "$$5.5 \\times 10^{-4}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  }
];

export default questions;
