// StudentPrep Free Content — only the first 2 non-empty curriculum units/categories per grade/subject.
const questions = [
  {
    "id": 3308,
    "content": [
      "Choose the sentence with the correct punctuation and capitalization."
    ],
    "explanation": [
      "The sentence is a simple declarative statement. Therefore, it should end with a period (.). The other punctuation marks (comma, exclamation mark, colon) are not appropriate for this type of sentence."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 125,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13240,
        "content": [
          "It is difficult for students to make changes in essays written by hand,"
        ],
        "isCorrect": false
      },
      {
        "id": 13241,
        "content": [
          "It is difficult for students to make changes in essays written by hand!"
        ],
        "isCorrect": false
      },
      {
        "id": 13242,
        "content": [
          "It is difficult for students to make changes in essays written by hand:"
        ],
        "isCorrect": false
      },
      {
        "id": 13243,
        "content": [
          "It is difficult for students to make changes in essays written by hand."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3309,
    "content": [
      "Choose the sentence with the correct punctuation and capitalization."
    ],
    "explanation": [
      "When a dialogue tag like \"he said\" interrupts a sentence of dialogue, a comma is needed before the tag and inside the quotation marks. Another comma is needed after the tag. The final period goes inside the closing quotation mark."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 125,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13244,
        "content": [
          "\"I thought she knew the answer, he said, \"but she didn't.\""
        ],
        "isCorrect": false
      },
      {
        "id": 13245,
        "content": [
          "\"I thought she knew the answer\" he said, \"but she didn't.\""
        ],
        "isCorrect": false
      },
      {
        "id": 13246,
        "content": [
          "\"I thought she knew the answer,\" he said, \"but she didn't.\""
        ],
        "isCorrect": true
      },
      {
        "id": 13247,
        "content": [
          "\"I thought she knew the answer,\" he said, \"but she didn't\"."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3310,
    "content": [
      "Choose the sentence with the correct punctuation and capitalization."
    ],
    "explanation": [
      "A comma is needed before the coordinating conjunction \"but\" that joins two independent clauses. The possessive pronoun \"hers\" should not have an apostrophe."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 125,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13248,
        "content": [
          "I passed my driving test last week but she failed her's."
        ],
        "isCorrect": false
      },
      {
        "id": 13249,
        "content": [
          "I passed my driving test last week, but she failed hers."
        ],
        "isCorrect": true
      },
      {
        "id": 13250,
        "content": [
          "I passed my driving test last week, but, she failed hers."
        ],
        "isCorrect": false
      },
      {
        "id": 13251,
        "content": [
          "I passed my driving test last week but, she failed hers."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3311,
    "content": [
      "Choose the sentence with the correct punctuation and capitalization."
    ],
    "explanation": [
      "\"Addis Ababa\" and \"Dire-Dawa\" are proper nouns (names of cities) and all parts of the names must be capitalized."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 125,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13252,
        "content": [
          "Both addis Ababa and Dire-Dawa have become exciting cities for living."
        ],
        "isCorrect": false
      },
      {
        "id": 13253,
        "content": [
          "Both Addis Ababa and Dire-dawa have become exciting cities for living."
        ],
        "isCorrect": false
      },
      {
        "id": 13254,
        "content": [
          "Both Addis Ababa and Dire-Dawa have become exciting cities for living."
        ],
        "isCorrect": true
      },
      {
        "id": 13255,
        "content": [
          "Both Addis Ababa and dire-Dawa have become exciting cities for living."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3350,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which of the following is an example of non-recyclable material?"
    ],
    "explanation": [
      "Paragraph 2 explicitly states, \"While newspapers are recyclable, their glossy, colored inserts are not.\" Junk mail inserts are often glossy and colored."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 1,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13408,
        "content": [
          "junk mail inserts"
        ],
        "isCorrect": true
      },
      {
        "id": 13409,
        "content": [
          "paper bags"
        ],
        "isCorrect": false
      },
      {
        "id": 13410,
        "content": [
          "newspapers"
        ],
        "isCorrect": false
      },
      {
        "id": 13411,
        "content": [
          "egg cartons"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3351,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Recycled paper can be used to make one of the following products. Which one is it?"
    ],
    "explanation": [
      "Paragraph 3 lists several products made from recycled paper, including \"food and clothing boxes.\" Paragraph 2 also mentions \"some food packaging can all be recycled.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 2,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13412,
        "content": [
          "chemicals"
        ],
        "isCorrect": false
      },
      {
        "id": 13413,
        "content": [
          "wax"
        ],
        "isCorrect": false
      },
      {
        "id": 13414,
        "content": [
          "cleaner-burning fuels"
        ],
        "isCorrect": false
      },
      {
        "id": 13415,
        "content": [
          "food packaging can"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3352,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which word used in paragraph 2 refers to a site for sanitary waste disposal?"
    ],
    "explanation": [
      "A landfill is a designated site for the disposal of waste materials by burial. Paragraph 2 mentions that the majority of used paper \"ends up in the landfills.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 3,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13416,
        "content": [
          "landfill"
        ],
        "isCorrect": true
      },
      {
        "id": 13417,
        "content": [
          "cellophane"
        ],
        "isCorrect": false
      },
      {
        "id": 13418,
        "content": [
          "plain"
        ],
        "isCorrect": false
      },
      {
        "id": 13419,
        "content": [
          "particles"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3353,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Why is the process of manufacturing recycled paper better for the environment than the process of new paper manufacturing is?"
    ],
    "explanation": [
      "Paragraph 5 states that manufacturing recycled paper \"uses less water, fewer trees and causes less pollution\" than making paper from new pulp."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 4,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13420,
        "content": [
          "The by-product of the recycled paper manufacturing process is sludge."
        ],
        "isCorrect": false
      },
      {
        "id": 13421,
        "content": [
          "The former releases treated wastes."
        ],
        "isCorrect": false
      },
      {
        "id": 13422,
        "content": [
          "The waste of the recycled paper manufacturing can be added to construction materials."
        ],
        "isCorrect": false
      },
      {
        "id": 13423,
        "content": [
          "The process does not require as much water as is required in new paper manufacturing."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3354,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which of the following can be the best title for the passage?"
    ],
    "explanation": [
      "The passage discusses the problems of paper pollution and waste, but its main focus is on recycling as a solution, detailing what can be recycled, the products made from it, and its environmental benefits. Therefore, \"Recycling Paper\" is the most encompassing title."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 5,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13424,
        "content": [
          "Paper Pollution"
        ],
        "isCorrect": false
      },
      {
        "id": 13425,
        "content": [
          "Recycling Paper"
        ],
        "isCorrect": true
      },
      {
        "id": 13426,
        "content": [
          "Recyclable and Unrecyclable Things"
        ],
        "isCorrect": false
      },
      {
        "id": 13427,
        "content": [
          "Paper Manufacturing"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3355,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Why is paper considered as an environmental problem by paper manufacturers themselves?"
    ],
    "explanation": [
      "Paragraph 1 discusses the pollution caused by paper manufacturing, including releasing \"untreated production wastes, such as chemicals, into nearby streams and rivers.\" This is a problem directly caused by the manufacturers."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 6,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13428,
        "content": [
          "Much of the paper produced cannot be recycled."
        ],
        "isCorrect": false
      },
      {
        "id": 13429,
        "content": [
          "Much of the paper produced is dumped into landfills."
        ],
        "isCorrect": false
      },
      {
        "id": 13430,
        "content": [
          "Much of the paper produced, if not recycled, is dumped into landfill."
        ],
        "isCorrect": false
      },
      {
        "id": 13431,
        "content": [
          "Many paper companies release untreated wastes."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3356,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which of the statements below is true about cleaner-burning fuels?"
    ],
    "explanation": [
      "Paragraph 1 states, \"Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 7,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13432,
        "content": [
          "They reduce the amount of sulfur dioxide produced."
        ],
        "isCorrect": true
      },
      {
        "id": 13433,
        "content": [
          "They pollute the landfills."
        ],
        "isCorrect": false
      },
      {
        "id": 13434,
        "content": [
          "They make many paper packaging unrecyclable."
        ],
        "isCorrect": false
      },
      {
        "id": 13435,
        "content": [
          "They affect the growth of trees and plants."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3357,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which of the following is true according to paragraph 2?"
    ],
    "explanation": [
      "Paragraph 2 begins, \"Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem.\" This directly names these three things as concerns."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 8,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13436,
        "content": [
          "Particles, wax-coated cellophane and chemicals are the environmental concerns of the paper industry."
        ],
        "isCorrect": false
      },
      {
        "id": 13437,
        "content": [
          "Cleaner burning fuels, chemicals and the paper produced are the environmental concerns of the paper industry."
        ],
        "isCorrect": false
      },
      {
        "id": 13438,
        "content": [
          "The paper produced, particles and chemicals are the environmental concerns of the paper industry."
        ],
        "isCorrect": true
      },
      {
        "id": 13439,
        "content": [
          "Chemicals, corrugated cardboard and the paper produced are the environmental concerns of the paper industry."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3358,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "What does them as used in This makes them non-recyclable... (Paragraph 2) refer to?"
    ],
    "explanation": [
      "In paragraph 2 of the passage, the sentence says \"Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable.\" The pronoun \"them\" clearly refers to \"Many kinds of paper packaging.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 9,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13440,
        "content": [
          "kinds of paper packaging"
        ],
        "isCorrect": true
      },
      {
        "id": 13441,
        "content": [
          "food packaging"
        ],
        "isCorrect": false
      },
      {
        "id": 13442,
        "content": [
          "newspapers"
        ],
        "isCorrect": false
      },
      {
        "id": 13443,
        "content": [
          "corrugated boxes"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3359,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which of the following is similar in meaning to glossy as used in paragraph 2?"
    ],
    "explanation": [
      "In paragraph 2 of the passage, \"glossy\" describes the inserts in newspapers. Glossy means having a shiny, smooth surface. \"Smooth\" is the closest synonym."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 10,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13444,
        "content": [
          "soft"
        ],
        "isCorrect": false
      },
      {
        "id": 13445,
        "content": [
          "smooth"
        ],
        "isCorrect": true
      },
      {
        "id": 13446,
        "content": [
          "rough"
        ],
        "isCorrect": false
      },
      {
        "id": 13447,
        "content": [
          "harsh"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3360,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Of the words given below, which one from paragraph 3 can be replaced by dislike?"
    ],
    "explanation": [
      "Paragraph 3 states, \"Trappist monks abhor the taking of life...\" To abhor something means to regard it with disgust and hatred, which is a very strong form of dislike."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 1,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13448,
        "content": [
          "exploit"
        ],
        "isCorrect": false
      },
      {
        "id": 13449,
        "content": [
          "impose"
        ],
        "isCorrect": false
      },
      {
        "id": 13450,
        "content": [
          "abhor"
        ],
        "isCorrect": true
      },
      {
        "id": 13451,
        "content": [
          "prohibit"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3361,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which statement is true according to paragraph 4?"
    ],
    "explanation": [
      "Paragraph 4 describes \"enforced vegetarianism\" in Africa and Asia due to the high cost of meat. It then states that \"About eighteen per cent of the world's populations... eat less than 10g... of animal protein,\" which is a form of enforced vegetarianism due to economic reasons."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 2,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13452,
        "content": [
          "In Africa and Asia, the cost of meat is seldom beyond what the poor can afford to buy."
        ],
        "isCorrect": false
      },
      {
        "id": 13453,
        "content": [
          "Vegetarianism has become a matter of individual choice in Africa and Asia."
        ],
        "isCorrect": false
      },
      {
        "id": 13454,
        "content": [
          "Followers of the Ethiopian Coptic church abhor the taking of life on more than 200 days."
        ],
        "isCorrect": false
      },
      {
        "id": 13455,
        "content": [
          "Enforced vegetarianism is common among eighteen percent of the world's population."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3362,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which of the following is the consequence of the spread of wealth in Europe and the West?"
    ],
    "explanation": [
      "Paragraph 5 states, \"But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing.\" \"Affluence\" means wealth."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 3,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13456,
        "content": [
          "an increase in the mount of vegetable eaten"
        ],
        "isCorrect": false
      },
      {
        "id": 13457,
        "content": [
          "an increase in enforced vegetarianism"
        ],
        "isCorrect": false
      },
      {
        "id": 13458,
        "content": [
          "an increase in the amount of animal protein eaten"
        ],
        "isCorrect": true
      },
      {
        "id": 13459,
        "content": [
          "a decrease in the amount of animal protein produced"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3363,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Why are 'voluntary vegetarians' mentioned in paragraph 5 in the passage?"
    ],
    "explanation": [
      "Paragraph 5 contrasts the \"economic necessity\" of enforced vegetarianism (paragraph 4) with the situation in the West, stating, \"Vegetarianism in the West is therefore less than a matter of economic necessity than of choice.\" The 'voluntary vegetarians' are an example of this choice, not necessity."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 4,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13460,
        "content": [
          "to disprove the belief that there is an increase in the amount of animal protein eaten in the average diet"
        ],
        "isCorrect": false
      },
      {
        "id": 13461,
        "content": [
          "to support the author's argument against animal protein in one's diet"
        ],
        "isCorrect": false
      },
      {
        "id": 13462,
        "content": [
          "to supplement the author's argument against the consequence of an increase in affluence"
        ],
        "isCorrect": false
      },
      {
        "id": 13463,
        "content": [
          "to indicate that economic necessity is no longer significant in choosing what to eat"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3364,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which of the following can be the best title for the passage?"
    ],
    "explanation": [
      "The passage covers many aspects of vegetarianism, including its supposed evolutionary roots, cultural and religious reasons, economic enforcement, voluntary choice, and its extreme form, veganism. \"Vegetarianism\" is the broad title that encompasses all these topics."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 5,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13464,
        "content": [
          "Voluntary Vegetarianism"
        ],
        "isCorrect": false
      },
      {
        "id": 13465,
        "content": [
          "Vegetarianism"
        ],
        "isCorrect": true
      },
      {
        "id": 13466,
        "content": [
          "Enforced Vegetarianism"
        ],
        "isCorrect": false
      },
      {
        "id": 13467,
        "content": [
          "Becoming a Vegetarian"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3365,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "As used in paragraph 1, which word from those given below is similar in meaning to gorge?"
    ],
    "explanation": [
      "Paragraph 1 says, \"We cannot gorge ourselves on meat...\" To gorge means to eat a large amount greedily. \"Stuff\" oneself is a common, informal synonym for this action."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 6,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13468,
        "content": [
          "gather"
        ],
        "isCorrect": false
      },
      {
        "id": 13469,
        "content": [
          "stuff"
        ],
        "isCorrect": true
      },
      {
        "id": 13470,
        "content": [
          "hunt"
        ],
        "isCorrect": false
      },
      {
        "id": 13471,
        "content": [
          "cheat"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3366,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which one of the following is true about carnivores as implied in paragraph 1?"
    ],
    "explanation": [
      "Paragraph 1 states that humans \"cannot gorge ourselves on meat and then go without eating for days as many carnivores do,\" implying that this is precisely what carnivores *can* do."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 6,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13472,
        "content": [
          "They hunt poultry and fish to get as much meat as they need."
        ],
        "isCorrect": false
      },
      {
        "id": 13473,
        "content": [
          "They have meat, poultry and fish as part of their everyday diet."
        ],
        "isCorrect": false
      },
      {
        "id": 13474,
        "content": [
          "They cannot eat tubers and seeds because of their teeth."
        ],
        "isCorrect": false
      },
      {
        "id": 13475,
        "content": [
          "They can eat much at a time and stay for days on that."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3367,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Disheartening as used in paragraph 2 can be replaced with which one of the following words?"
    ],
    "explanation": [
      "Paragraph 2 says many people find the prospect of giving up meat \"disheartening.\" Something that is disheartening causes someone to lose determination or confidence. \"Depressing\" has a similar meaning of causing unhappiness and discouragement."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 7,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13476,
        "content": [
          "engraving"
        ],
        "isCorrect": false
      },
      {
        "id": 13477,
        "content": [
          "interesting"
        ],
        "isCorrect": false
      },
      {
        "id": 13478,
        "content": [
          "impressing"
        ],
        "isCorrect": false
      },
      {
        "id": 13479,
        "content": [
          "depressing"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3368,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Choose from those given below an example of the evolutionary argument referred to in paragraph 2."
    ],
    "explanation": [
      "Paragraph 2 refers back to \"Such evolutionary arguments\" from paragraph 1. Paragraph 1 provides examples like \"Our teeth evolved to deal with tubers and seeds, not flesh,\" which are characteristics of foragers. This makes \"foragers' teeth\" a direct example of the evolutionary argument."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 8,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13480,
        "content": [
          "going without eating for days"
        ],
        "isCorrect": false
      },
      {
        "id": 13481,
        "content": [
          "carnivores' teeth"
        ],
        "isCorrect": false
      },
      {
        "id": 13482,
        "content": [
          "foragers' teeth"
        ],
        "isCorrect": true
      },
      {
        "id": 13483,
        "content": [
          "hunters' digestive system"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3369,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which one of the following is a reason why vegetarianism eventually gained public acceptance?"
    ],
    "explanation": [
      "Paragraph 2 states that \"a habit that was once regarded as an eccentricity is gaining respect.\" Paragraphs 3 and 5 then list various reasons: philosophical, religious, moral, economic, and health. All of these contribute to an increased awareness of the potential benefits or reasons for vegetarianism."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 9,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13484,
        "content": [
          "increase in our awareness of the benefits of vegetarianism"
        ],
        "isCorrect": true
      },
      {
        "id": 13485,
        "content": [
          "decline in the flavors and smell of meat"
        ],
        "isCorrect": false
      },
      {
        "id": 13486,
        "content": [
          "increase in our understanding of the appetizing nature of meat"
        ],
        "isCorrect": false
      },
      {
        "id": 13487,
        "content": [
          "decline in the spread of a concentrated form of nutrient"
        ],
        "isCorrect": false
      }
    ]
  }
];
export default questions;
