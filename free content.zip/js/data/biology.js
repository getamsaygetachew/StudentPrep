// StudentPrep Free Content — guide-selected units, maximum 25 questions per unit.
const questions = [
  {
    "id": 2,
    "content": [
      "Which one of the following can best explain behavior? It is"
    ],
    "explanation": [
      "Behavior isn't just a random reaction to a stimulus; it's a coordinated response that involves the organism's nervous system and often other organ systems.\n\nFor instance, if an animal senses a predator (external stimulus), its nervous system triggers a fear response. This might lead to a coordinated set of behaviors such as fleeing, hiding, or fighting."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5,
        "content": [
          "the co-ordinated response of an organism to an internal or external stimuli."
        ],
        "isCorrect": true
      },
      {
        "id": 6,
        "content": [
          "the tendency for parts of plants to grow towards light."
        ],
        "isCorrect": false
      },
      {
        "id": 7,
        "content": [
          "the actions or reactions of a person or animal in response to external or internal stimuli."
        ],
        "isCorrect": false
      },
      {
        "id": 8,
        "content": [
          "a cell or group of cells that receives and processes stimuli."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 3,
    "content": [
      "The quick withdrawal of your hand from a hot plate is an example of"
    ],
    "explanation": [
      "Innate behavior is defined as an inborn behavior determined by genes and not influenced by experience.\nThis aligns with the involuntary, instinctual nature of withdrawing your hand from a hot surface.\n\nReflex behaviors, a subtype of innate behavior, are described as \"sudden, involuntary responses to stimuli,\" such as pulling your hand away from a hot or sharp object."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9,
        "content": [
          "fixed action pattern"
        ],
        "isCorrect": false
      },
      {
        "id": 10,
        "content": [
          "innate behavior"
        ],
        "isCorrect": true
      },
      {
        "id": 11,
        "content": [
          "biological clock"
        ],
        "isCorrect": false
      },
      {
        "id": 12,
        "content": [
          "key stimulus"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 4,
    "content": [
      "Which one of the following processes describes a biological clock?"
    ],
    "explanation": [
      "Biological clocks are described as \"24-hour cycles that are part of the body's internal clock, running in the background to carry out essential functions and processes\".\nThey are also known as circadian rhythms, like the sleep-wake cycle.\n\nCircannual migration of birds is a behavioral pattern that aligns with this concept.\nIt's a yearly cycle influenced by internal biological factors and environmental cues, prompting birds to move between breeding and non-breeding grounds in response to changing seasons, food availability, and optimal conditions for survival and reproduction."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13,
        "content": [
          "Removal of one's thumb from hot objects quickly"
        ],
        "isCorrect": false
      },
      {
        "id": 14,
        "content": [
          "The growing of plants towards light"
        ],
        "isCorrect": false
      },
      {
        "id": 15,
        "content": [
          "Circannual migration of birds from temperate to tropical areas"
        ],
        "isCorrect": true
      },
      {
        "id": 16,
        "content": [
          "Kinesis and taxes of woodlice and other simple animals"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 5,
    "content": [
      "Identify learned behavior from the following."
    ],
    "explanation": [
      "Learned behavior, as defined, is \"not inherited and not determined by genes\" but rather \"acquired during the lifetime of an individual.\"\nIt enables adaptation to environmental changes based on prior experiences.\n\nTraining a dog to hunt perfectly illustrates this concept.\nIt involves shaping a dog's natural instincts and behaviors through consistent instruction, positive reinforcement, and repeated experiences."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 17,
        "content": [
          "Dog trained to hunt."
        ],
        "isCorrect": true
      },
      {
        "id": 18,
        "content": [
          "Honey bee making honey."
        ],
        "isCorrect": false
      },
      {
        "id": 19,
        "content": [
          "Child withdraws hand from hot things."
        ],
        "isCorrect": false
      },
      {
        "id": 20,
        "content": [
          "Ants making nest."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 6,
    "content": [
      "Which one of the following features is unique to bacteria?"
    ],
    "explanation": [
      "Bacteria and Archaea are prokaryotic cells, which are small and simple cells that do not have a nucleus or other compartments bound by internal membranes. \n\nOn the other hand, eukaryotes, such as plants and animals, have a nucleus and other membrane-bound organelles."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 21,
        "content": [
          "Presence of permeable membrane"
        ],
        "isCorrect": false
      },
      {
        "id": 22,
        "content": [
          "Being unicellular"
        ],
        "isCorrect": false
      },
      {
        "id": 23,
        "content": [
          "Absence of nuclear membrane"
        ],
        "isCorrect": true
      },
      {
        "id": 24,
        "content": [
          "Having flagella for locomotion"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 7,
    "content": [
      "This item is based on the diagram which shows the different shape of bacteria below.",
      "images/biology/year_2013/q7_1.png",
      "What is the correct name of the shape of bacteria represented by letters A, B and C, respectively?"
    ],
    "explanation": [
      "- **A** represents a *spirochaete* (spiral-shaped bacteria).\n- **B** represents a *sphere* (cocci-shaped bacteria).\n- **C** represents a *rod* (bacilli-shaped bacteria)."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/biology/year_2013/q7_1.png"
    ],
    "choices": [
      {
        "id": 25,
        "content": [
          "Rod, spirochaete, sphere"
        ],
        "isCorrect": false
      },
      {
        "id": 26,
        "content": [
          "Sphere, rod, spirochaete"
        ],
        "isCorrect": false
      },
      {
        "id": 27,
        "content": [
          "Flagellated bacilli, clusters, spirilla"
        ],
        "isCorrect": false
      },
      {
        "id": 28,
        "content": [
          "Spirochaete, sphere, rod"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 8,
    "content": [
      "It is possible to produce human insulin in a bacterial strain. The insulin gene should be inserted in a plasmid and the recombinant DNA plasmid should be inserted into a bacterium.\n\nWhat is the role of the bacterium in this process?"
    ],
    "explanation": [
      "Bacteria reproduce very quickly. Scientists can insert a desired gene, such as the human insulin gene, into a plasmid and then insert the plasmid into a bacterium. This process is called recombinant DNA technology.\n\nThe bacteria then reproduce rapidly, creating many copies of the recombinant DNA molecule that contains the insulin gene."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 29,
        "content": [
          "The source of insulin and modification"
        ],
        "isCorrect": false
      },
      {
        "id": 30,
        "content": [
          "The source of plasmid and insulin production"
        ],
        "isCorrect": false
      },
      {
        "id": 31,
        "content": [
          "Multiplying the recombinant DNA molecule"
        ],
        "isCorrect": true
      },
      {
        "id": 32,
        "content": [
          "Joining the gene of insulin with the gene of plasmid"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 9,
    "content": [
      "Bacteria can cause diseases in all of the following mechanisms **EXCEPT**"
    ],
    "explanation": [
      "Bacteria can cause disease through a variety of mechanisms, but they do not typically directly alter the genetic structure of host cells in a way that would be passed down to future generations."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 33,
        "content": [
          "changing the genetic structure of host cells."
        ],
        "isCorrect": true
      },
      {
        "id": 34,
        "content": [
          "entering living cells and disrupting metabolic systems."
        ],
        "isCorrect": false
      },
      {
        "id": 35,
        "content": [
          "releasing toxins as they multiply."
        ],
        "isCorrect": false
      },
      {
        "id": 36,
        "content": [
          "invading and growing on the tissues of organs."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 10,
    "content": [
      "Functional diseases differ from infectious diseases in that they"
    ],
    "explanation": [
      "Functional diseases are characterized by a disruption in the normal function of an organ or system, but without visible signs of damage upon examination.\nThis means that while the organ appears structurally sound, it is not functioning properly.\n\nInfectious diseases, on the other hand, are caused by pathogenic microorganisms such as bacteria, viruses, or fungi.\nThese microorganisms can invade and damage tissues and organs, leading to visible signs of infection."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 37,
        "content": [
          "are caused by microorganisms."
        ],
        "isCorrect": false
      },
      {
        "id": 38,
        "content": [
          "occur in the brain and heart."
        ],
        "isCorrect": false
      },
      {
        "id": 39,
        "content": [
          "are common in females than males."
        ],
        "isCorrect": false
      },
      {
        "id": 40,
        "content": [
          "show no signs of damage on the organ."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 11,
    "content": [
      "This item is based on the drawing of a bacteriophage given below.",
      "images/biology/year_2013/q11_1_background.png",
      "In the above diagram of a bacteriophage, DNA and Protein coat are respectively represented by"
    ],
    "explanation": [
      "- **1** represents the DNA.\n- **2** represents the protein coat (capsid).\n- **3** represents the tail fibers."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/biology/year_2013/q11_1_background.png"
    ],
    "choices": [
      {
        "id": 41,
        "content": [
          "2 and 3."
        ],
        "isCorrect": false
      },
      {
        "id": 42,
        "content": [
          "1 and 3."
        ],
        "isCorrect": false
      },
      {
        "id": 43,
        "content": [
          "1 and 2."
        ],
        "isCorrect": true
      },
      {
        "id": 44,
        "content": [
          "2 and 1."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 12,
    "content": [
      "The social impact of AlDS can be mainly revealed by"
    ],
    "explanation": [
      "Stigmatization and discrimination are common social challenges faced by individuals with AIDS, leading to social isolation, mental health issues, and barriers to accessing treatment."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 45,
        "content": [
          "fear of stigmatization"
        ],
        "isCorrect": true
      },
      {
        "id": 46,
        "content": [
          "loss of appetite"
        ],
        "isCorrect": false
      },
      {
        "id": 47,
        "content": [
          "reduced labor force"
        ],
        "isCorrect": false
      },
      {
        "id": 48,
        "content": [
          "loss of body weight"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 13,
    "content": [
      "Which one of the following is a DNA virus?"
    ],
    "explanation": [
      "- **Herpes complex**: Herpesviruses, including Herpes simplex, are DNA viruses.\n- **HIV**: HIV is a retrovirus, which means it's an RNA virus that uses reverse transcription to create DNA from its RNA genome.\n- **Hepatitis C**: Hepatitis C virus (HCV) is an RNA virus.\n- **H1N1**: H1N1 is a type of influenza virus, which is an RNA virus."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 49,
        "content": [
          "Herpes complex"
        ],
        "isCorrect": true
      },
      {
        "id": 50,
        "content": [
          "HIV"
        ],
        "isCorrect": false
      },
      {
        "id": 51,
        "content": [
          "Hepatitis C"
        ],
        "isCorrect": false
      },
      {
        "id": 52,
        "content": [
          "H1N1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 14,
    "content": [
      "Which one of the following is a correct comparison of lytic and lysogenic cycles of virus\nmultiplication?"
    ],
    "explanation": [
      "In the **lytic cycle**, a virus infects a host cell, replicates rapidly, and then destroys the host cell to release new viruses.\nThis splitting of the host cell is a key characteristic of the lytic cycle.\n\nIn the **lysogenic cycle**, the viral DNA integrates into the host cell's DNA.\nIt can remain dormant for some time, replicating along with the host cell's DNA.\nCertain triggers can cause the virus to enter the lytic cycle from the lysogenic cycle."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 53,
        "content": [
          "Lysogenic cycle releases new viruses using only chronic cycle."
        ],
        "isCorrect": false
      },
      {
        "id": 54,
        "content": [
          "Lytic cycle involves incorporation of viral DNA into the host DNA."
        ],
        "isCorrect": false
      },
      {
        "id": 55,
        "content": [
          "Lytic cycle releases new viruses only by splitting the host cell."
        ],
        "isCorrect": true
      },
      {
        "id": 56,
        "content": [
          "Both cycles damage the host cell DNA following infection."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 15,
    "content": [
      "In an HIV/AIDS community screening, students were asked to take part in voluntary testing. The following discussion presents the views of four grade 12 students named A, B, C and D towards HIV testing.",
      "Student A: I should not take the testing; it is simply boring.",
      "Student B: We should take the testing, since we are educated; we should be exemplary.",
      "Student C: If we get tested and got positive, what should we do? So, let us not get tested.",
      "Student D: You know, this HIVIAIDS testing is simply a business. We should not be cheated.",
      "Which student do you think is correct?"
    ],
    "explanation": [
      "Student B emphasizes the importance of being educated and setting an example by participating in voluntary HIV testing. This reflects a responsible attitude towards personal and public health."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 57,
        "content": [
          "Student B"
        ],
        "isCorrect": true
      },
      {
        "id": 58,
        "content": [
          "Student A"
        ],
        "isCorrect": false
      },
      {
        "id": 59,
        "content": [
          "Student D"
        ],
        "isCorrect": false
      },
      {
        "id": 60,
        "content": [
          "Student C"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 26,
    "content": [
      "The behavior which trainers look, if modified, could lead to the desired behavior and reward such a behavior is"
    ],
    "explanation": [
      "Operant conditioning is a type of associative learning where an animal's behavior is modified through reinforcement or punishment.\n\nIf an animal performs a desired behavior, trainers can reward that behavior, making it more likely to occur in the future. Conversely, undesired behaviors can be punished or ignored, making them less likely to happen again."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 101,
        "content": [
          "innate."
        ],
        "isCorrect": false
      },
      {
        "id": 102,
        "content": [
          "instinct."
        ],
        "isCorrect": false
      },
      {
        "id": 103,
        "content": [
          "reflex."
        ],
        "isCorrect": false
      },
      {
        "id": 104,
        "content": [
          "operant."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 27,
    "content": [
      "Which one of the following examples of behavior describes when an animal stops responding to stimulus or cue after a period of repeated exposure?"
    ],
    "explanation": [
      "Habituation is a simple form of learning where an animal gradually stops responding to a repeated stimulus that provides no reward or punishment.\nThis is a type of non-associative learning.\n\nFor example, imagine you are reading a book, and someone turns on the television in the same room.\nInitially, the sound of the television might be distracting.\nHowever, after a while, you might stop noticing it."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 105,
        "content": [
          "Imprinting"
        ],
        "isCorrect": false
      },
      {
        "id": 106,
        "content": [
          "Reflex"
        ],
        "isCorrect": false
      },
      {
        "id": 107,
        "content": [
          "Habituation"
        ],
        "isCorrect": true
      },
      {
        "id": 108,
        "content": [
          "Conditioning"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 28,
    "content": [
      "A police man trained a dog on how to find explosive materials through sniffing, on another instant the same police man observed a week old puppy following him on the roadside.\n\nWhich one of the following is correct about the behaviors of the animals in the observation?"
    ],
    "explanation": [
      "In the first case, the dog learns to detect explosives through training, which is a learned behavior developed through trial and experience.\n\nIn the second case, the puppy following the policeman is instinctive and genetically coded behavior (imprinting)."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 109,
        "content": [
          "The first case is genetically encoded and the second is adaptive."
        ],
        "isCorrect": false
      },
      {
        "id": 110,
        "content": [
          "Both of the cases indicate natural behavior of the animals."
        ],
        "isCorrect": false
      },
      {
        "id": 111,
        "content": [
          "Both of the cases indicate learned behavior of the animals."
        ],
        "isCorrect": false
      },
      {
        "id": 112,
        "content": [
          "The first cases develop through trial and the second genetically coded."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 29,
    "content": [
      "Which one of the following behaviors is a courtship behavior?"
    ],
    "explanation": [
      "Courtship behavior refers to specific actions animals exhibit to attract mates and initiate the mating process.\n\nRitual fighting can be a part of courtship, where individuals engage in displays of strength or agility to impress potential partners. This behavior is more about display than causing actual harm."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 113,
        "content": [
          "Touch"
        ],
        "isCorrect": false
      },
      {
        "id": 114,
        "content": [
          "Scent marking"
        ],
        "isCorrect": false
      },
      {
        "id": 115,
        "content": [
          "Ritual fighting"
        ],
        "isCorrect": true
      },
      {
        "id": 116,
        "content": [
          "Defending a den"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 30,
    "content": [
      "The Ethiopian wolf (Canis simensis) lives and hunt in packs. During patrolling their habitat, both male and female wolves of the group maintain their area with urine containing pheromone. This pattern of behavior best exemplifies"
    ],
    "explanation": [
      "Ethiopian wolves use urine containing pheromones to mark their territory. \n\nTerritoriality is a behavioral pattern in which animals protect their space from other animals.\nTerritories contain resources animals need to survive, and animals often use signals to warn others to stay away."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 117,
        "content": [
          "courtship behavior."
        ],
        "isCorrect": false
      },
      {
        "id": 118,
        "content": [
          "territorial behavior."
        ],
        "isCorrect": true
      },
      {
        "id": 119,
        "content": [
          "operant behavior."
        ],
        "isCorrect": false
      },
      {
        "id": 120,
        "content": [
          "learned behavior."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 36,
    "content": [
      "What is the major difference that viruses have with free living cells? Viruses"
    ],
    "explanation": [
      "One of the most important differences between viruses and living cells is that viruses cannot function outside of a living cell.\n\nViruses are essentially just packages of genetic material (either DNA or RNA) surrounded by a protein coat.\nThey don't have their own ribosomes to make proteins, nor do they have the enzymes necessary for metabolism.\n\nThis means that they can't replicate or carry out any biological processes on their own.\nThey need to hijack the machinery of a living cell in order to function."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 141,
        "content": [
          "reproduce only asexually."
        ],
        "isCorrect": false
      },
      {
        "id": 142,
        "content": [
          "lack genetic material of their own."
        ],
        "isCorrect": false
      },
      {
        "id": 143,
        "content": [
          "do not function outside of a living cell."
        ],
        "isCorrect": true
      },
      {
        "id": 144,
        "content": [
          "lack locomotary structure."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 51,
    "content": [
      "Which one of the following organic molecules is used to make hemoglobin?"
    ],
    "explanation": [
      "Hemoglobin is a complex protein found in red blood cells."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 201,
        "content": [
          "Glycogen"
        ],
        "isCorrect": false
      },
      {
        "id": 202,
        "content": [
          "Lipids"
        ],
        "isCorrect": false
      },
      {
        "id": 203,
        "content": [
          "Proteins"
        ],
        "isCorrect": true
      },
      {
        "id": 204,
        "content": [
          "Nucleic acids"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 52,
    "content": [
      "Which one of the following is the correct formula of maltose?"
    ],
    "explanation": [
      "Maltose is a disaccharide, which is made up of two glucose molecules.\nWhen two glucose molecules  combine to form maltose, a water molecule ($$H_{2}O$$) is lost during the condensation reaction.\nThis results in the molecular formula of maltose being:\n$$\nC_{12}H_{22}O_{11}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 205,
        "content": [
          "$$C_{6}H_{12}O_{6}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 206,
        "content": [
          "$$C_{12}H_{24}O_{12}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 207,
        "content": [
          "$$C_{5}H_{10}O_{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 208,
        "content": [
          "$$C_{12}H_{22}O_{11}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 53,
    "content": [
      "A grade 11 student added Benedict's reagent on food sample and heated the mixture for 5 minutes. Then he observed a color change.\n\nWhich one of the following is FALSE about the result?"
    ],
    "explanation": [
      "Benedict's reagent is used to test for the presence of reducing sugars.\n\nReducing sugars are capable of donating electrons (reducing other molecules) which causes a color change in Benedict's solution.\n\nNon-reducing sugars do not react with Benedict's reagent and will not cause a color change."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 209,
        "content": [
          "An orange color shows that a reducing sugar is present."
        ],
        "isCorrect": false
      },
      {
        "id": 210,
        "content": [
          "A yellow color shows that a reducing sugar is present."
        ],
        "isCorrect": false
      },
      {
        "id": 211,
        "content": [
          "An orange color shows that a non-reducing sugar is present."
        ],
        "isCorrect": true
      },
      {
        "id": 212,
        "content": [
          "A red color shows that a reducing sugar is present."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 54,
    "content": [
      "In a Benedict's test for sucrose, why does the test sample first boil with hydrochloric acid?"
    ],
    "explanation": [
      "This test is used to detect the presence of reducing sugars, like glucose and fructose.\n\nSucrose is a disaccharide composed of glucose and fructose, but it's a non-reducing sugar.\nThis means it won't directly react with Benedict's reagent.\n\nBoiling sucrose with hydrochloric acid breaks the glycosidic bond between glucose and fructose, effectively hydrolyzing it into its constituent monosaccharides.\n\nOnce sucrose is broken down into glucose and fructose, these reducing sugars can then react with Benedict's reagent."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 213,
        "content": [
          "To reduce Benedict's solution"
        ],
        "isCorrect": false
      },
      {
        "id": 214,
        "content": [
          "To neutralize the solution"
        ],
        "isCorrect": false
      },
      {
        "id": 215,
        "content": [
          "To hydrolyze non-reducing sugar"
        ],
        "isCorrect": true
      },
      {
        "id": 216,
        "content": [
          "To retest the mixture with Benedict's solution"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 56,
    "content": [
      "The relevance and promise of biological sciences can be demonstrated by their contribution in"
    ],
    "explanation": [
      "Biological sciences play a crucial role in agriculture, food production, and sustainability, directly addressing food security challenges."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 221,
        "content": [
          "finding mechanisms to feed the growing human population."
        ],
        "isCorrect": true
      },
      {
        "id": 222,
        "content": [
          "finding solutions to ethnic conflicts."
        ],
        "isCorrect": false
      },
      {
        "id": 223,
        "content": [
          "development of housing and construction sectors."
        ],
        "isCorrect": false
      },
      {
        "id": 224,
        "content": [
          "advancement of aviation technology."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Application of Biology"
  },
  {
    "id": 57,
    "content": [
      "All are the roles of biology to combat the spread of HIV/AIDS EXCEPT"
    ],
    "explanation": [
      "Raising funds, while crucial for support and infrastructure, falls outside the realm of biology itself. It's a socioeconomic action rather than a direct biological intervention."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 225,
        "content": [
          "producing drugs that can stop the virus from reproducing"
        ],
        "isCorrect": false
      },
      {
        "id": 226,
        "content": [
          "breaking the transmission pathway."
        ],
        "isCorrect": false
      },
      {
        "id": 227,
        "content": [
          "raising fund for infected people."
        ],
        "isCorrect": true
      },
      {
        "id": 228,
        "content": [
          "producing a vaccine against the virus."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Application of Biology"
  },
  {
    "id": 58,
    "content": [
      "Which one of the following statements is INCORRECT about AIDS?\nThe rate of transmission of AIDS will reduce when"
    ],
    "explanation": [
      "HIV/AIDS is transmitted through the exchange of bodily fluids like blood, semen, breast milk, and vaginal fluids.\n\nCircumcision has no known impact on the transmission of HIV/AIDS."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 229,
        "content": [
          "the transmission path ways is broken."
        ],
        "isCorrect": false
      },
      {
        "id": 230,
        "content": [
          "promiscuous sexual intercourse is reduced."
        ],
        "isCorrect": false
      },
      {
        "id": 231,
        "content": [
          "the number of sexual partners is restricted."
        ],
        "isCorrect": false
      },
      {
        "id": 232,
        "content": [
          "men and women are circumcised."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 59,
    "content": [
      "Which one of the following statements explains the property of water? It"
    ],
    "explanation": [
      "Water is **transparent** which means light can pass through it.\n\nWhy other options are incorrect:\n\n- **Takes less energy to heat water up:** Water actually has a high specific heat capacity, meaning it takes *more* energy to raise its temperature compared to many other substances.\n- **Has the lowest latent heat of vaporization:** Water has a relatively *high* latent heat of vaporization, meaning it takes a lot of energy for it to change from liquid to gas.\n- **Is a highly viscous substance:** Viscosity refers to a fluid's resistance to flow. Water is not highly viscous; it flows relatively easily."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 233,
        "content": [
          "takes less energy to heat water up."
        ],
        "isCorrect": false
      },
      {
        "id": 234,
        "content": [
          "has the lowest latent heat of vaporization."
        ],
        "isCorrect": false
      },
      {
        "id": 235,
        "content": [
          "is a transparent molecule."
        ],
        "isCorrect": true
      },
      {
        "id": 236,
        "content": [
          "is highly viscous substance."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 60,
    "content": [
      "Suppose there are two communities in a village. Community A actively participates in HIV/AIDS awareness creation, HIV prevention and gets blood test for HIV whereas community B frequently requests for food aid, participates only in afforestation activities and HIV positive individuals keep the secret to themselves.\n\nIn which community do you think that the incidence of HIV/AIDS most probably high?"
    ],
    "explanation": [
      "Community B's behavior suggests a lack of engagement in HIV/AIDS awareness and prevention, which can lead to higher rates of transmission.\nAdditionally, the secrecy around HIV-positive individuals indicates stigma and a lack of support, further contributing to the problem.\n\nIn contrast, community A's active participation in awareness and prevention efforts likely helps reduce their incidence of HIV/AIDS."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 237,
        "content": [
          "In both communities"
        ],
        "isCorrect": false
      },
      {
        "id": 238,
        "content": [
          "In community B"
        ],
        "isCorrect": true
      },
      {
        "id": 239,
        "content": [
          "Impossible to decide"
        ],
        "isCorrect": false
      },
      {
        "id": 240,
        "content": [
          "In community A"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 61,
    "content": [
      "Which property of water is useful for life that it continues in relatively warm water underneath through the cold weather?"
    ],
    "explanation": [
      "Water's high specific heat capacity means it can absorb a large amount of heat energy without undergoing a drastic temperature change.\n\nThis property is what allows bodies of water to stay relatively warm even when the air temperature drops significantly during cold weather."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 241,
        "content": [
          "High specific heat capacity"
        ],
        "isCorrect": true
      },
      {
        "id": 242,
        "content": [
          "High density in its solid form than its liquid form"
        ],
        "isCorrect": false
      },
      {
        "id": 243,
        "content": [
          "High surface tension"
        ],
        "isCorrect": false
      },
      {
        "id": 244,
        "content": [
          "High latent heat of vaporization"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 62,
    "content": [
      "Consider the following table which contains organic and inorganic molecules.",
      "images/biology/year_2013/q62_1.png",
      "Which rows contain the corresponding organic and inorganic molecules correctly?"
    ],
    "explanation": [
      "- **Organic Molecules**: Generally contain carbon-hydrogen (C-H) bonds and are often associated with living organisms. Examples of elements and monomers (building blocks) that form organic molecules, including carbohydrates, lipids, proteins, and nucleic acids.\n- **Inorganic Molecules**:  May contain carbon, but they typically don't have C-H bonds and are not exclusively produced by living organisms.\n\nRow 1 (Correct):\n\n- Lysine: An amino acid, which is a building block of proteins (organic).\n- Sucrose: A disaccharide sugar (organic).\n- Salts:  Ionic compounds formed from the reaction of an acid and a base (inorganic).\n- Hydrochloric Acid (HCl):  A strong acid (inorganic).\n\nRow 2 (Incorrect):\n\n- Deoxyribose: A sugar found in DNA (organic).\n- Carbon Monoxide (CO): An inorganic compound, even though it contains carbon.\n- Fructose:  A monosaccharide sugar (organic).\n- Sodium Chloride (NaCl): Common table salt, an ionic compound (inorganic).\n\nRow 3 (Correct):\n\n- Fatty Acid:  A building block of lipids (fats and oils) (organic).\n- Methane (CH4): The simplest hydrocarbon, often associated with organic matter (organic).\n- Sodium Hydroxide (NaOH):  A strong base (inorganic).\n- Carbon Dioxide (CO₂):  Inorganic, even though it's a product of respiration in living organisms.\n\nRow 4 (Incorrect):\n\n- Water (H2O):  Inorganic, even though it's essential for life.\n- Calcium Carbonate (CaCO3):  The main component of seashells and limestone (inorganic).\n- Stearic Acid:  A saturated fatty acid (organic).\n- Starch: A polysaccharide carbohydrate (organic)."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/biology/year_2013/q62_1.png"
    ],
    "choices": [
      {
        "id": 245,
        "content": [
          "2 and 3"
        ],
        "isCorrect": false
      },
      {
        "id": 246,
        "content": [
          "1 and 2"
        ],
        "isCorrect": false
      },
      {
        "id": 247,
        "content": [
          "3 and 4"
        ],
        "isCorrect": false
      },
      {
        "id": 248,
        "content": [
          "1 and 3"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 63,
    "content": [
      "Cellulose is"
    ],
    "explanation": [
      "Cellulose is made up of beta-glucose molecules linked together in a linear chain.\nThis linkage creates a strong, rigid structure that is difficult to break down.\n\nThe difference between alpha-glucose and beta-glucose is the orientation of the hydroxyl group on the first carbon atom.\nIn alpha-glucose, the hydroxyl group is below the ring, while in beta-glucose, it is above the ring."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 249,
        "content": [
          "a mixture of amylose and amylopectin."
        ],
        "isCorrect": false
      },
      {
        "id": 250,
        "content": [
          "a polymer of β-glucose molecule."
        ],
        "isCorrect": true
      },
      {
        "id": 251,
        "content": [
          "a non-reducing monosaccharide sugar."
        ],
        "isCorrect": false
      },
      {
        "id": 252,
        "content": [
          "a polymer of α-glucose molecule."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 64,
    "content": [
      "Which organic molecules are formed when two fatty acid molecules are bounded to the glycerol and the place of the third is taken by a phosphate group?"
    ],
    "explanation": [
      "Phospholipids are a type of lipid that is a major component of cell membranes.\nThey are similar in structure to triglycerides, but they have a phosphate group attached to the glycerol molecule instead of one of the fatty acids.\n\nTriglycerides, on the other hand, are made up of a glycerol molecule bonded to three fatty acids.\nThey are the main form of stored energy in the body and are found in adipose tissue.\n\nWaxes are composed of a long-chain fatty acid linked to a long-chain alcohol.\nThey serve as a waterproof coating on leaves and fruits."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 253,
        "content": [
          "Waxes"
        ],
        "isCorrect": false
      },
      {
        "id": 254,
        "content": [
          "Glycolipids"
        ],
        "isCorrect": false
      },
      {
        "id": 255,
        "content": [
          "Triglycerides"
        ],
        "isCorrect": false
      },
      {
        "id": 256,
        "content": [
          "Phospholipids"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 65,
    "content": [
      "All are the function of lipids EXCEPT"
    ],
    "explanation": [
      "- **Lipids determining a particular feature**: While lipids play a role in the structure of cell membranes and contribute to the overall form and function of organisms, they don't directly \"determine a particular feature\" in the same way that genetic material like DNA does.\n- **Lipids as thermal insulation**: Lipids, particularly fats, are excellent thermal insulators. They help animals conserve heat, especially those living in cold environments.\n- **Lipids for water proofing**: Lipids contribute to waterproofing in organisms. For instance, the waxy coatings on plant leaves help reduce water loss.\n- **Lipids as respiratory substrates**: Lipids are a rich source of energy and can be broken down through respiration to provide energy for cellular processes."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 257,
        "content": [
          "thermal insulation."
        ],
        "isCorrect": false
      },
      {
        "id": 258,
        "content": [
          "water proofing."
        ],
        "isCorrect": false
      },
      {
        "id": 259,
        "content": [
          "respiratory substrates"
        ],
        "isCorrect": false
      },
      {
        "id": 260,
        "content": [
          "determines a particular features."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 91,
    "content": [
      "The step of scientific method which comes after analyzing results and draw conclusion is"
    ],
    "explanation": [
      "After analyzing results and drawing a conclusion, the next step is to determine whether the conclusion supports or contradicts the initial hypothesis.\nThis step is crucial for refining scientific understanding and guiding future research."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 361,
        "content": [
          "doing background research."
        ],
        "isCorrect": false
      },
      {
        "id": 362,
        "content": [
          "constructing hypothesis."
        ],
        "isCorrect": false
      },
      {
        "id": 363,
        "content": [
          "designing and carrying out experiment."
        ],
        "isCorrect": false
      },
      {
        "id": 364,
        "content": [
          "accepting or rejecting the hypothesis."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 92,
    "content": [
      "In a group of individuals in which group A was a control and group B was an experimental group, a student gave a placebo to the control group, and an unknown drug to the experimental group. At the end, the experimental group got better.\n\nWhich one of the following is true about the result?"
    ],
    "explanation": [
      "Since the experimental group, which received the drug, got better compared to the control group (which received a placebo), the logical conclusion would suggest that the drug had an effect."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 365,
        "content": [
          "The drug has an effect."
        ],
        "isCorrect": true
      },
      {
        "id": 366,
        "content": [
          "Placebo has better effect."
        ],
        "isCorrect": false
      },
      {
        "id": 367,
        "content": [
          "The experiment was wrong."
        ],
        "isCorrect": false
      },
      {
        "id": 368,
        "content": [
          "Conclusion cannot be reached."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 93,
    "content": [
      "A biologist conducted simple experiment to investigate the effect of pH on salivary amylase. She added $$5cm^3$$ amylase solution into $$5cm^3$$ starch suspension with a neutral pH in a test tube. After ten minutes, she tested it with iodine reagent and the solution turned into blue-black color.\n\nWhat is the dependent variable of this experiment?"
    ],
    "explanation": [
      "The dependent variable is the variable that is being measured or observed in an experiment.\n\nIn this case, the biologist is observing the formation of a blue-black color after adding iodine reagent.\nThis color change indicates the presence of starch. Therefore, the dependent variable in this experiment is formation of a blue-black color."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 369,
        "content": [
          "Applying iodine treatment"
        ],
        "isCorrect": false
      },
      {
        "id": 370,
        "content": [
          "pH of the solution"
        ],
        "isCorrect": false
      },
      {
        "id": 371,
        "content": [
          "Adding salivary amylase"
        ],
        "isCorrect": false
      },
      {
        "id": 372,
        "content": [
          "Formation of blue-black color"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 94,
    "content": [
      "Which one of the following pairs of biological tools and their functions is FALSE?"
    ],
    "explanation": [
      "A quadrat is a square frame used to isolate a standard unit of area for study and ecological sampling.\nIt is primarily used for studying plants and immobile or slow-moving animals.\n\nTherefore, the function stated for quadrate is incorrect."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 373,
        "content": [
          "Petri dish -used for culturing microorganisms"
        ],
        "isCorrect": false
      },
      {
        "id": 374,
        "content": [
          "Balances-used for measuring mass"
        ],
        "isCorrect": false
      },
      {
        "id": 375,
        "content": [
          "Quadrate- to separate solids from liquids"
        ],
        "isCorrect": true
      },
      {
        "id": 376,
        "content": [
          "Optical microscope- use beam of light to produce magnified image"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Application of Biology"
  },
  {
    "id": 95,
    "content": [
      "Grade 12 students went to a field and collected plant specimens for identification in the laboratory. They wanted to preserve the plant parts for some times and specimens can be analyzed later.\n\nWhich one of the following biological tool is used for their activities?"
    ],
    "explanation": [
      "A plant press is a common tool used by botanists to flatten and dry plant specimens for preservation."
    ],
    "year": "YEAR_2013",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 377,
        "content": [
          "Plant press"
        ],
        "isCorrect": true
      },
      {
        "id": 378,
        "content": [
          "Pitfall traps"
        ],
        "isCorrect": false
      },
      {
        "id": 379,
        "content": [
          "Theodolite"
        ],
        "isCorrect": false
      },
      {
        "id": 380,
        "content": [
          "Quadrat"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 101,
    "content": [
      "Which of the following is the Greek word for life?"
    ],
    "explanation": [
      "The word bios meaning \"life\" is combined with the Greek word logos meaning \"study\" to form the word biology. Biology is the scientific study of life or living things."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 401,
        "content": [
          "'logos'"
        ],
        "isCorrect": false
      },
      {
        "id": 402,
        "content": [
          "'Bios'"
        ],
        "isCorrect": true
      },
      {
        "id": 403,
        "content": [
          "'Cientia'"
        ],
        "isCorrect": false
      },
      {
        "id": 404,
        "content": [
          "'Cell'"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 103,
    "content": [
      "In which of the following groups of organisms are all the members unicellular?"
    ],
    "explanation": [
      "Bacteria are unicellular prokaryotic organisms.\nThis means they are single-celled organisms that lack a nucleus and other membrane-bound organelles.\nLet's look at the other options:\n- Algae can be both unicellular and multicellular. Unicellular algae form the base of aquatic food chains, while multicellular algae include seaweeds.\n- Fungi can also be unicellular or multicellular. Yeasts are examples of unicellular fungi, while molds and mushrooms are multicellular.\n- Viruses are not considered living organisms because they lack key characteristics of life, such as the ability to grow, develop, or carry out respiration independently."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 409,
        "content": [
          "Algae"
        ],
        "isCorrect": false
      },
      {
        "id": 410,
        "content": [
          "Fungi"
        ],
        "isCorrect": false
      },
      {
        "id": 411,
        "content": [
          "Bacteria"
        ],
        "isCorrect": true
      },
      {
        "id": 412,
        "content": [
          "Viruses"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 105,
    "content": [
      "What is the type of scientific research that is directly concerned with studies of the way of solving problems related to human needs?"
    ],
    "explanation": [
      "Applied science focuses on using scientific knowledge to address practical problems and develop solutions for human needs."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 417,
        "content": [
          "Basic science"
        ],
        "isCorrect": false
      },
      {
        "id": 418,
        "content": [
          "Applied science"
        ],
        "isCorrect": true
      },
      {
        "id": 419,
        "content": [
          "Space science"
        ],
        "isCorrect": false
      },
      {
        "id": 420,
        "content": [
          "Current science"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 106,
    "content": [
      "For which of the following purposes do biologist uses centrifuges?"
    ],
    "explanation": [
      "Fractionation of cell content involves breaking open cells and separating their internal components (organelles, molecules) for study.\nThis process often utilizes centrifugation. Denser components settle at the bottom (pellet) while lighter ones remain suspended (supernatant)."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 421,
        "content": [
          "Measuring volume"
        ],
        "isCorrect": false
      },
      {
        "id": 422,
        "content": [
          "Magnifying cell part"
        ],
        "isCorrect": false
      },
      {
        "id": 423,
        "content": [
          "Culturing microorganism"
        ],
        "isCorrect": false
      },
      {
        "id": 424,
        "content": [
          "Fractionation of cell content"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Application of Biology"
  },
  {
    "id": 112,
    "content": [
      "Of the following patterns of innate behavior in animals, which one is considered the simplest?"
    ],
    "explanation": [
      "Reflex action is defined as \"a sudden, involuntary response to stimuli\".\nThis means that it's an immediate, unconscious reaction to something in the environment.\nFor example, blinking when something comes close to your eye is a reflex action."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 445,
        "content": [
          "Instinctive behavior"
        ],
        "isCorrect": false
      },
      {
        "id": 446,
        "content": [
          "Reflex action"
        ],
        "isCorrect": true
      },
      {
        "id": 447,
        "content": [
          "Taxi movement"
        ],
        "isCorrect": false
      },
      {
        "id": 448,
        "content": [
          "Kinesis movement"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 113,
    "content": [
      "The hypothesis which a scientist tries to disprove is called:"
    ],
    "explanation": [
      "Scientists often focus on disproving a null hypothesis.\n\nThe null hypothesis states that there is no relationship between the variables being studied. \n\nFor example, if a scientist is testing the effectiveness of a new fertilizer, the null hypothesis would be that the fertilizer has no effect on plant growth. By trying to disprove the null hypothesis, scientists can gain evidence to support their original hypothesis."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 449,
        "content": [
          "Alternative hypothesis"
        ],
        "isCorrect": false
      },
      {
        "id": 450,
        "content": [
          "Ad hoc hypothesis"
        ],
        "isCorrect": false
      },
      {
        "id": 451,
        "content": [
          "Null hypothesis"
        ],
        "isCorrect": true
      },
      {
        "id": 452,
        "content": [
          "Auxiliary hypothesis"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 114,
    "content": [
      "What are the compounds that have the same chemical composition, but different arrangement of atom?"
    ],
    "explanation": [
      "Isomers are molecules that have the same chemical formula (the same number and types of atoms) but different structural arrangements of those atoms."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 453,
        "content": [
          "Anomers"
        ],
        "isCorrect": false
      },
      {
        "id": 454,
        "content": [
          "Isomers"
        ],
        "isCorrect": true
      },
      {
        "id": 455,
        "content": [
          "Polymers"
        ],
        "isCorrect": false
      },
      {
        "id": 456,
        "content": [
          "Monomers"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 120,
    "content": [
      "The daily cycle of activity that occurs over a 24-hour period of time is called a:"
    ],
    "explanation": [
      "Circadian rhythms are biological cycles that repeat approximately every 24 hours, influencing various physiological processes and behaviors.\nThese rhythms are driven by internal biological clocks but can be synchronized with external cues like light and darkness."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 477,
        "content": [
          "Stimulus-response"
        ],
        "isCorrect": false
      },
      {
        "id": 478,
        "content": [
          "Kinesis behavior"
        ],
        "isCorrect": false
      },
      {
        "id": 479,
        "content": [
          "Circadian rhythm"
        ],
        "isCorrect": true
      },
      {
        "id": 480,
        "content": [
          "Taxis behavior"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 121,
    "content": [
      "Within a few weeks after a heavy rain, pools become teemed with tadpoles. What is the source of the tadpoles?"
    ],
    "explanation": [
      "Frogs lay their eggs in water, and the eggs hatch into tadpoles."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 481,
        "content": [
          "The rain water"
        ],
        "isCorrect": false
      },
      {
        "id": 482,
        "content": [
          "The eggs laid by frog"
        ],
        "isCorrect": true
      },
      {
        "id": 483,
        "content": [
          "The decaying vegetation of the pond"
        ],
        "isCorrect": false
      },
      {
        "id": 484,
        "content": [
          "The mud on the floor"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 122,
    "content": [
      "In what way does an antiretroviral drug help AIDS patients? It"
    ],
    "explanation": [
      "Antiretroviral therapy (ART) uses a combination of medicines to prevent HIV from replicating.\nThis helps to protect the immune system from further damage.\nART does not cure HIV, but it can help people with HIV live longer, healthier lives."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 485,
        "content": [
          "stops the multiplication of HIV"
        ],
        "isCorrect": true
      },
      {
        "id": 486,
        "content": [
          "kills opportunistic infection agent"
        ],
        "isCorrect": false
      },
      {
        "id": 487,
        "content": [
          "stimulates multiplication of T - helper cells"
        ],
        "isCorrect": false
      },
      {
        "id": 488,
        "content": [
          "provides immunity"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 123,
    "content": [
      "Of the following four elements, which one is the least abundant in living thing?"
    ],
    "explanation": [
      "Oxygen, carbon, and hydrogen are all mentioned as primary components of the four major classes of organic macromolecules: carbohydrates, lipids, proteins, and nucleic acids.\n\nSulfur is not mentioned as a primary component of any of these macromolecules."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 489,
        "content": [
          "Oxygen"
        ],
        "isCorrect": false
      },
      {
        "id": 490,
        "content": [
          "Hydrogen"
        ],
        "isCorrect": false
      },
      {
        "id": 491,
        "content": [
          "Carbon"
        ],
        "isCorrect": false
      },
      {
        "id": 492,
        "content": [
          "Sulfur"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 124,
    "content": [
      "If a homogenate of eukaryotic cells is spun in a centrifuge, which of the cellular organelles settles out first?"
    ],
    "explanation": [
      "Denser particles sediment at lower centrifugal forces, forming a pellet at the bottom. Lighter particles remain in the supernatant (the liquid above the pellet).\n\nThe nucleus is the largest organelle in a eukaryotic cell. The nucleus contains densely packed DNA within chromosomes.\n\nOther organelles like ribosomes, chloroplasts, and mitochondria are smaller and relatively less dense than the nucleus. Therefore, they would require higher centrifugal forces to sediment."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 493,
        "content": [
          "Nucleus"
        ],
        "isCorrect": true
      },
      {
        "id": 494,
        "content": [
          "Ribosome"
        ],
        "isCorrect": false
      },
      {
        "id": 495,
        "content": [
          "Chloroplast"
        ],
        "isCorrect": false
      },
      {
        "id": 496,
        "content": [
          "Mitochondria"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Application of Biology"
  },
  {
    "id": 127,
    "content": [
      "Which one of the following human diseases is NOT correctly matched with its mode of transmission?"
    ],
    "explanation": [
      "Sleeping sickness is transmitted through the bite of the tsetse fly, which acts as a vector."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 505,
        "content": [
          "Malaria-vector"
        ],
        "isCorrect": false
      },
      {
        "id": 506,
        "content": [
          "Sleeping sickness-physical contact"
        ],
        "isCorrect": true
      },
      {
        "id": 507,
        "content": [
          "Cholera-contaminated water"
        ],
        "isCorrect": false
      },
      {
        "id": 508,
        "content": [
          "Influenza-droplet infection"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 128,
    "content": [
      "Which clinical test is routinely performed to diagnose patients for AIDS?"
    ],
    "explanation": [
      "A serological test for anti-HIV antibodies is routinely performed to diagnose patients for AIDS.\n\nHIV tests are detectors used to identify if a person has been infected with the virus.\nThese tests check for the presence of antibodies to the virus in the blood, not the virus itself.\nIf HIV antibodies are present, the person is considered HIV-positive."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 509,
        "content": [
          "Cultural opportunistic infectious agent"
        ],
        "isCorrect": false
      },
      {
        "id": 510,
        "content": [
          "Culturing the virus on a special media"
        ],
        "isCorrect": false
      },
      {
        "id": 511,
        "content": [
          "Serological test for anti-HIV antibody"
        ],
        "isCorrect": true
      },
      {
        "id": 512,
        "content": [
          "Determining hemoglobin amount"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 133,
    "content": [
      "What is the behavior that an animal learns to ignore a trivial stimulus that is repeated many times?"
    ],
    "explanation": [
      "Habituation is a simple form of learning where an animal gradually stops responding to a repeated stimulus that has no significant consequence."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 529,
        "content": [
          "Sensitization"
        ],
        "isCorrect": false
      },
      {
        "id": 530,
        "content": [
          "Insight learning"
        ],
        "isCorrect": false
      },
      {
        "id": 531,
        "content": [
          "Habituation"
        ],
        "isCorrect": true
      },
      {
        "id": 532,
        "content": [
          "Latent Learning"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 134,
    "content": [
      "One of the following is true about a behavior that has a fixed action pattern."
    ],
    "explanation": [
      "Fixed action patterns are instinctive behaviors in animals that are triggered by specific stimuli and proceed in a predictable, unchanging sequence."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 533,
        "content": [
          "It is a learned behavior"
        ],
        "isCorrect": false
      },
      {
        "id": 534,
        "content": [
          "It is always done in the same way"
        ],
        "isCorrect": true
      },
      {
        "id": 535,
        "content": [
          "It can be perfected through experience"
        ],
        "isCorrect": false
      },
      {
        "id": 536,
        "content": [
          "It does not need a stimulus to trigger it"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 135,
    "content": [
      "If a chimpanzee piles up boxes and climbs on it to reach a bunch of banana hanging from a ceiling, which behavior is manifested?"
    ],
    "explanation": [
      "Insight learning is a type of learning where an organism demonstrates a sudden understanding of a problem's solution without overt trial-and-error.\n\nThis is evident in the chimpanzee's behavior, where it seemingly contemplates the situation and devises a plan (piling boxes) to reach the bananas, rather than just randomly attempting different actions."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 537,
        "content": [
          "Operant conditioning"
        ],
        "isCorrect": false
      },
      {
        "id": 538,
        "content": [
          "Trial and error learning"
        ],
        "isCorrect": false
      },
      {
        "id": 539,
        "content": [
          "Insight learning"
        ],
        "isCorrect": true
      },
      {
        "id": 540,
        "content": [
          "Latent learning"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 136,
    "content": [
      "In which of the following is the current state of biology more of promises than realized major contributions?"
    ],
    "explanation": [
      "While there have been significant advancements in genetic engineering and its potential for food production, many of the promises, such as increased yields, improved nutritional content, and reduced pesticide use, remain largely unrealized."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 541,
        "content": [
          "Food production by GMO and genetic"
        ],
        "isCorrect": true
      },
      {
        "id": 542,
        "content": [
          "Pest control and understanding about diseases"
        ],
        "isCorrect": false
      },
      {
        "id": 543,
        "content": [
          "Food production and population control"
        ],
        "isCorrect": false
      },
      {
        "id": 544,
        "content": [
          "Understanding of health and biodiversity conservation"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Biology and Technology"
  },
  {
    "id": 141,
    "content": [
      "If the average diameter of human red blood cell is 0.000007m, which one is its correct diameter when expressed in a smaller unit?"
    ],
    "explanation": [
      "1 m = $$10^9$$ nm = 0.000007 m * ($$10^9$$ nm / 1 m) = 7000 nm"
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 561,
        "content": [
          "0.00007μm"
        ],
        "isCorrect": false
      },
      {
        "id": 562,
        "content": [
          "0.007μm"
        ],
        "isCorrect": false
      },
      {
        "id": 563,
        "content": [
          "7mm"
        ],
        "isCorrect": false
      },
      {
        "id": 564,
        "content": [
          "7000nm"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 144,
    "content": [
      "What is the main method of transmission of botulism?"
    ],
    "explanation": [
      "Botulism is caused by a toxin produced by the bacterium Clostridium botulinum.  This toxin is often found in improperly canned or preserved foods where the bacteria can thrive in the anaerobic environment. Eating contaminated food allows the toxin to enter the body and cause illness."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 573,
        "content": [
          "Direct contact"
        ],
        "isCorrect": false
      },
      {
        "id": 574,
        "content": [
          "Droplet infection"
        ],
        "isCorrect": false
      },
      {
        "id": 575,
        "content": [
          "Eating contaminated food"
        ],
        "isCorrect": true
      },
      {
        "id": 576,
        "content": [
          "Drinking contaminated water"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 145,
    "content": [
      "From which group of microorganism was the first antibiotics produced?"
    ],
    "explanation": [
      "The first antibiotic, **penicillin**, was produced from a microorganism belonging to the group of **fungi** (specifically *Penicillium* fungi)."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 577,
        "content": [
          "Members of viruses"
        ],
        "isCorrect": false
      },
      {
        "id": 578,
        "content": [
          "Members of the fungi"
        ],
        "isCorrect": true
      },
      {
        "id": 579,
        "content": [
          "Gram- negative bacteria"
        ],
        "isCorrect": false
      },
      {
        "id": 580,
        "content": [
          "Gram-positive bacteria"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 151,
    "content": [
      "Which animal behavior pattern is best illustrated by the famous Pavlov's dog?"
    ],
    "explanation": [
      "Pavlov's dog is a famous experiment in classical conditioning, a type of associative learning. In this experiment, Pavlov rang a bell (a neutral stimulus) before presenting food (an unconditioned stimulus) to a dog.\n\nOver time, the dog learned to associate the bell with food and began to salivate (a conditioned response) at the sound of the bell alone, even without the presence of food. This demonstrates associative learning, where an animal learns to connect two previously unrelated stimuli."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 601,
        "content": [
          "Associative learning"
        ],
        "isCorrect": true
      },
      {
        "id": 602,
        "content": [
          "Latent learning"
        ],
        "isCorrect": false
      },
      {
        "id": 603,
        "content": [
          "Instinctive behavior"
        ],
        "isCorrect": false
      },
      {
        "id": 604,
        "content": [
          "Habituation"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 153,
    "content": [
      "The most abundant inorganic molecule in the atmosphere that traps heat is:"
    ],
    "explanation": [
      "Greenhouse gases trap heat in the atmosphere. Carbon dioxide (CO₂) as a greenhouse gas that contributes to global warming."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 609,
        "content": [
          "$$H_2S$$"
        ],
        "isCorrect": false
      },
      {
        "id": 610,
        "content": [
          "$$O_2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 611,
        "content": [
          "$$H_2O$$"
        ],
        "isCorrect": false
      },
      {
        "id": 612,
        "content": [
          "$$CO_2$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 154,
    "content": [
      "When glucose molecules are joined by α-linkage which of the following carbohydrate is obtained?"
    ],
    "explanation": [
      "α-linkage refers to a type of chemical bond that connects glucose molecules to form polysaccharides. In an α-linkage, the connecting oxygen atom on the first glucose molecule is below the plane of the ring.\n\nStarch is a polysaccharide made up of glucose units joined by α-linkages.\n\nGlycogen is similar to starch in that it's a storage form of glucose in animals it is also formed by α-linkages"
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 613,
        "content": [
          "lactose"
        ],
        "isCorrect": false
      },
      {
        "id": 614,
        "content": [
          "starch"
        ],
        "isCorrect": true
      },
      {
        "id": 615,
        "content": [
          "glycogen"
        ],
        "isCorrect": false
      },
      {
        "id": 616,
        "content": [
          "cellulose"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 160,
    "content": [
      "The active sludge method Sewage treatment is based on the principle of"
    ],
    "explanation": [
      "In this process, microorganisms decompose organic pollutants in sewage through aerobic biological treatment, breaking them down into simpler compounds."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 637,
        "content": [
          "Decomposition and removal of organic matter"
        ],
        "isCorrect": true
      },
      {
        "id": 638,
        "content": [
          "Removal of polluting organic matter through filtration"
        ],
        "isCorrect": false
      },
      {
        "id": 639,
        "content": [
          "Denitrification"
        ],
        "isCorrect": false
      },
      {
        "id": 640,
        "content": [
          "Anaerobic respiration"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 162,
    "content": [
      "When is reverse transcriptase a useful enzyme? When:"
    ],
    "explanation": [
      "Reverse transcriptase enzyme reverses the typical flow of genetic information, going from RNA back to DNA. This is unusual because cells usually transcribe DNA into RNA as the first step in protein synthesis."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 645,
        "content": [
          "nutrient are scarce"
        ],
        "isCorrect": false
      },
      {
        "id": 646,
        "content": [
          "there are no host cells present"
        ],
        "isCorrect": false
      },
      {
        "id": 647,
        "content": [
          "spikes are forming in the new virus"
        ],
        "isCorrect": false
      },
      {
        "id": 648,
        "content": [
          "an RNA virus converts its RNA to DNA"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 167,
    "content": [
      "Transfer of a genes through a virus is called:"
    ],
    "explanation": [
      "Transduction is the process by which a virus transfers genetic material from one bacterium to another."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 665,
        "content": [
          "transformation"
        ],
        "isCorrect": false
      },
      {
        "id": 666,
        "content": [
          "transduction"
        ],
        "isCorrect": true
      },
      {
        "id": 667,
        "content": [
          "genetic engineering"
        ],
        "isCorrect": false
      },
      {
        "id": 668,
        "content": [
          "conjugation"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 170,
    "content": [
      "''Skinner box'' is used to for experiment in:"
    ],
    "explanation": [
      "Operant conditioning is a type of associative learning discovered by B.F. Skinner, in which an organism's behavior is modified through reinforcement or punishment.  A \"Skinner box\" is a chamber designed to study operant conditioning in animals."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 677,
        "content": [
          "operant conditioning"
        ],
        "isCorrect": true
      },
      {
        "id": 678,
        "content": [
          "classical conditioning"
        ],
        "isCorrect": false
      },
      {
        "id": 679,
        "content": [
          "migration"
        ],
        "isCorrect": false
      },
      {
        "id": 680,
        "content": [
          "taxis"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 173,
    "content": [
      "In what way do retro viruses differ from other RNA viruses?"
    ],
    "explanation": [
      "Retroviruses are a class of viruses that are characterized by their ability to copy their RNA genome into DNA, which is then integrated into the host cell's genome. This process is called reverse transcription, and it is carried out by an enzyme called reverse transcriptase, which is encoded by the retroviral genome."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 689,
        "content": [
          "Their genetic material is RNA"
        ],
        "isCorrect": false
      },
      {
        "id": 690,
        "content": [
          "They are parasitic"
        ],
        "isCorrect": false
      },
      {
        "id": 691,
        "content": [
          "They copy RNA to DNA"
        ],
        "isCorrect": true
      },
      {
        "id": 692,
        "content": [
          "They are smaller in size"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 177,
    "content": [
      "How many nucleotides are needed to form codons for a protein that is 100 amino acids long?"
    ],
    "explanation": [
      "A codon is a sequence of three nucleotides that codes for a specific amino acid. Since there are 100 amino acids in the protein, you would need 100 codons.\n\nTherefore, you would need 300 nucleotides (100 codons x 3 nucleotides per codon) to form the codons for the protein."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 705,
        "content": [
          "100 nucleotides"
        ],
        "isCorrect": false
      },
      {
        "id": 706,
        "content": [
          "200 nucleotides"
        ],
        "isCorrect": false
      },
      {
        "id": 707,
        "content": [
          "300 nucleotides"
        ],
        "isCorrect": true
      },
      {
        "id": 708,
        "content": [
          "640 nucleotides"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 180,
    "content": [
      "One of the following behavioral pattern of human babies is more or less similar to the imprinting of newly hatched goose?"
    ],
    "explanation": [
      "Imprinting is a type of learning that occurs during a critical period early in life.\n\nAttachment-formation in human babies shares similarities with imprinting."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 717,
        "content": [
          "Fixed action pattern"
        ],
        "isCorrect": false
      },
      {
        "id": 718,
        "content": [
          "Attachment-formation"
        ],
        "isCorrect": true
      },
      {
        "id": 719,
        "content": [
          "Habituation"
        ],
        "isCorrect": false
      },
      {
        "id": 720,
        "content": [
          "Breast sucking"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 182,
    "content": [
      "Which of the following has highest water potential than all the other?"
    ],
    "explanation": [
      "Water potential is the measure of the tendency of water to move from one area to another. Water naturally moves from areas of high water potential to areas of low water potential.\n\nPure water has the highest possible water potential because it has no dissolved solutes. Any solute added to water will lower its water potential."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 725,
        "content": [
          "Animal cells"
        ],
        "isCorrect": false
      },
      {
        "id": 726,
        "content": [
          "Different solutions"
        ],
        "isCorrect": false
      },
      {
        "id": 727,
        "content": [
          "Pure liquid water"
        ],
        "isCorrect": true
      },
      {
        "id": 728,
        "content": [
          "Different suspensions"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 185,
    "content": [
      "Which of the following is a correct statement about the difference between a bacterium and virus?"
    ],
    "explanation": [
      "Bacteria are unicellular organisms, meaning they are made up of a single cell. Viruses, on the other hand, are not made up of cells. They are considered particles that are not alive because they lack key characteristics of living things, such as growth, development, and respiration. Viruses are much smaller than bacteria and are made up of nucleic acids (either DNA or RNA) surrounded by a protein coat."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 737,
        "content": [
          "DNA is present in the former, but absent in the latter"
        ],
        "isCorrect": false
      },
      {
        "id": 738,
        "content": [
          "The former is cellular, but the latter is acellular"
        ],
        "isCorrect": true
      },
      {
        "id": 739,
        "content": [
          "Protein absent in the former, but present in the latter"
        ],
        "isCorrect": false
      },
      {
        "id": 740,
        "content": [
          "The former causes malaria, but the latter causes cholera"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 188,
    "content": [
      "What is the survival value of a social behavior in which some birds move in large groups?"
    ],
    "explanation": [
      "Moving in large groups, or flocking, helps birds reduce the risk of predation through strategies like confusing predators, enhancing vigilance, and providing safety in numbers. This behavior is especially common among species that are vulnerable to predators."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 749,
        "content": [
          "Protection of territory"
        ],
        "isCorrect": false
      },
      {
        "id": 750,
        "content": [
          "Protection from predator"
        ],
        "isCorrect": true
      },
      {
        "id": 751,
        "content": [
          "Technique for trapping prey"
        ],
        "isCorrect": false
      },
      {
        "id": 752,
        "content": [
          "Displaying courtship activities"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 190,
    "content": [
      "Which of the following statement is NOT correct?"
    ],
    "explanation": [
      "The statement that is NOT correct is HIV-positive people are forced by law to disclose their HIV status."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 757,
        "content": [
          "Employers may not dismiss an employee because of his/her HIV status"
        ],
        "isCorrect": false
      },
      {
        "id": 758,
        "content": [
          "HIV-positive people are forced by law to disclose their HIV status"
        ],
        "isCorrect": true
      },
      {
        "id": 759,
        "content": [
          "There is no medication that can reduce your chances of contracting HIV"
        ],
        "isCorrect": false
      },
      {
        "id": 760,
        "content": [
          "Mothers can give their babies HIV by means of breastfeeding"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 191,
    "content": [
      "Lipids to become sphingolipids must contain:"
    ],
    "explanation": [
      "Sphingolipids are a class of lipids that are structurally different from typical fats (triglycerides). A key characteristic of sphingolipids is that they contain a nitrogen atom in their structure, usually as part of a sphingosine backbone."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 761,
        "content": [
          "Glycerol"
        ],
        "isCorrect": false
      },
      {
        "id": 762,
        "content": [
          "Nitrogen"
        ],
        "isCorrect": true
      },
      {
        "id": 763,
        "content": [
          "Alcohol"
        ],
        "isCorrect": false
      },
      {
        "id": 764,
        "content": [
          "Triglycerides"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 197,
    "content": [
      "Which of the following happens during integration of viruses in host cells?"
    ],
    "explanation": [
      "Viral integration is a key step in the lifecycle of some viruses, where the virus inserts its genetic material into the host cell's DNA. This allows the virus to essentially become a part of the host cell's genome."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 785,
        "content": [
          "The virus takes over host cell machinery"
        ],
        "isCorrect": false
      },
      {
        "id": 786,
        "content": [
          "The viral DNA enters the host cell receptor"
        ],
        "isCorrect": false
      },
      {
        "id": 787,
        "content": [
          "The virus attaches to a host cell receptor"
        ],
        "isCorrect": false
      },
      {
        "id": 788,
        "content": [
          "The viral DNA in inserted into the host DNA"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 200,
    "content": [
      "One of the following is NOT true about operant conditioning."
    ],
    "explanation": [
      "Operant conditioning is a type of learned or acquired behavior, meaning it is not determined by genes and is developed during an individual's lifetime. This type of conditioning is influenced by rewards and punishments, which directly relate to the consequences of actions. Innate or inherent behaviors, on the other hand, are inborn and determined by genes."
    ],
    "year": "YEAR_2011",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 797,
        "content": [
          "It is based on innate behavior"
        ],
        "isCorrect": true
      },
      {
        "id": 798,
        "content": [
          "It is based on reward and punishment"
        ],
        "isCorrect": false
      },
      {
        "id": 799,
        "content": [
          "It is concerned with learnt behavior"
        ],
        "isCorrect": false
      },
      {
        "id": 800,
        "content": [
          "It is based on consequence of actions"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 202,
    "content": [
      "During culturing micro-organisms, all of the following activities are important EXCEPT"
    ],
    "explanation": [
      "It is crucial to use sterile techniques during the process of culturing microorganisms. Petri dishes, culture tubes, and flasks are sterilized in an autoclave to eliminate any potential contaminants."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 805,
        "content": [
          "tilting the lid of the Petri dish during inoculation."
        ],
        "isCorrect": false
      },
      {
        "id": 806,
        "content": [
          "adding distilled water to a sterilized agar."
        ],
        "isCorrect": true
      },
      {
        "id": 807,
        "content": [
          "sterilizing the inoculating loops."
        ],
        "isCorrect": false
      },
      {
        "id": 808,
        "content": [
          "transferring target micro-organisms into an agar medium."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 203,
    "content": [
      "Which one of the following diseases can be caused by more than one type of microorganisms?"
    ],
    "explanation": [
      "Gastroenteritis can be caused by various microorganisms, including bacteria such as Escherichia coli (E. coli) and Salmonella, viruses such as norovirus and rotavirus, and parasites such as Giardia lamblia and Cryptosporidium."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 809,
        "content": [
          "Cholera"
        ],
        "isCorrect": false
      },
      {
        "id": 810,
        "content": [
          "Gastroenteritis"
        ],
        "isCorrect": true
      },
      {
        "id": 811,
        "content": [
          "Typhoid"
        ],
        "isCorrect": false
      },
      {
        "id": 812,
        "content": [
          "Tuberculosis"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 204,
    "content": [
      "Which one of the following diseases is correctly explained with its causes or symptoms?"
    ],
    "explanation": [
      "*Gonorrhoea*, which is caused by *Neisseria gonorrhoeae*, can cause symptoms like a burning sensation while urinating."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_MICRO_ORGANISM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 813,
        "content": [
          "Syphilis is caused by Neisseria gonorrhoeae."
        ],
        "isCorrect": false
      },
      {
        "id": 814,
        "content": [
          "Gonorrhoea has a burning sensation symptom while urinating."
        ],
        "isCorrect": true
      },
      {
        "id": 815,
        "content": [
          "Gonorrhoea is caused by Treponema pallidum."
        ],
        "isCorrect": false
      },
      {
        "id": 816,
        "content": [
          "Syphilis has sore ulceration on the genitals as a symptom."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Microorganisms"
  },
  {
    "id": 205,
    "content": [
      "The names of which two taxa are used in binomial nomenclature?"
    ],
    "explanation": [
      "In binomial nomenclature, the two taxa used are the **genus** and **species**, which are among the lowest units in biological classification. The genus is capitalized and comes first, followed by the species, which is not capitalized. For example, in *Homo sapiens*, *Homo* is the genus and *sapiens* is the species."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 817,
        "content": [
          "The two lowest units of classification"
        ],
        "isCorrect": true
      },
      {
        "id": 818,
        "content": [
          "The two middle units of classification"
        ],
        "isCorrect": false
      },
      {
        "id": 819,
        "content": [
          "The highest and the lowest unit of classification"
        ],
        "isCorrect": false
      },
      {
        "id": 820,
        "content": [
          "The two highest units of classification"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 211,
    "content": [
      "Which one of the following sentences explains the traditional use of biotechnology? Production of"
    ],
    "explanation": [
      "The production of yogurt, cheese, and other fermented dairy products has been a cornerstone of traditional food preservation and culinary practices for millennia."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 841,
        "content": [
          "insulin using transgenic bacteria"
        ],
        "isCorrect": false
      },
      {
        "id": 842,
        "content": [
          "dairy products at household level"
        ],
        "isCorrect": true
      },
      {
        "id": 843,
        "content": [
          "myco-proteins under a laboratory"
        ],
        "isCorrect": false
      },
      {
        "id": 844,
        "content": [
          "vinegar using industrial fermenter"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Biology and Technology"
  },
  {
    "id": 216,
    "content": [
      "Which one of the following phyla is characterized by a flexible cartilaginous rod-like structure, that runs along the dorsal side of the body?"
    ],
    "explanation": [
      "The flexible cartilaginous rod-like structure that runs along the dorsal side of the body is called a notochord. The presence of a notochord is a defining characteristic of animals belonging to the Phylum Chordata."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 861,
        "content": [
          "Phylum Mollusca"
        ],
        "isCorrect": false
      },
      {
        "id": 862,
        "content": [
          "Phylum Chordata"
        ],
        "isCorrect": true
      },
      {
        "id": 863,
        "content": [
          "Phylum Annelida"
        ],
        "isCorrect": false
      },
      {
        "id": 864,
        "content": [
          "Phylum Arthropoda"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 217,
    "content": [
      "Which one of the following groups of organisms is correctly matched with its phylum?"
    ],
    "explanation": [
      "Starfish belong to the Phylum Echinodermata. This phylum is characterized by radial symmetry, often with five points, and a unique water vascular system, which starfish use for movement, feeding, and respiration."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 865,
        "content": [
          "Starfish-Phylum Echinodermata"
        ],
        "isCorrect": true
      },
      {
        "id": 866,
        "content": [
          "Fish- Phylum Arthropoda"
        ],
        "isCorrect": false
      },
      {
        "id": 867,
        "content": [
          "Earthworm - Phylum Mollusca"
        ],
        "isCorrect": false
      },
      {
        "id": 868,
        "content": [
          "Snail - Phylum Annelida"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 220,
    "content": [
      "A zoologist studied 5 vertebrate species (spA, spB, spC, spD & spE) and described their features as follows.",
      "**spA**: Smooth moist skin; pass parts of their lives in water and on land",
      "**spB**: Streamlined bodies with scales; gills for gaseous exchange",
      "**spC**: Feathers over the body and scales on legs; endothermic; horny beak",
      "**spD**: Dry skin with scales; ectothermic; lungs for respiration",
      "**spE**: Mammary glands; endothermic; higher internal body temperature",
      "Based on the features listed above, spA, spB, spC, spD and spE can be classified under the vertebrate classes, respectively"
    ],
    "explanation": [
      "- spA (Amphibia): \"Smooth moist skin; pass parts of their lives in water and on land\" aligns with the characteristics of amphibians, like frogs, which have permeable skin and live in both aquatic and terrestrial environments.\n- spB (Pisces):  \"Streamlined bodies with scales; gills for gaseous exchange\" are classic characteristics of fish, belonging to the Pisces class.\n- spC (Aves): \"Feathers over the body and scales on legs; endothermic; horny beak\" matches the features of birds (Aves), known for their feathers, endothermy (warm-bloodedness), and beaks.\n- spD (Reptilia): \"Dry skin with scales; ectothermic; lungs for respiration\" describes reptiles, such as snakes and lizards, which rely on external sources for body heat (ectothermic).\n- spE (Mammalia): \"Mammary glands; endothermic; higher internal body temperature\"  These are defining characteristics of mammals."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 877,
        "content": [
          "Amphibia, Reptilia, Aves, Mammalia, and Pisces."
        ],
        "isCorrect": false
      },
      {
        "id": 878,
        "content": [
          "Pisces, Aves, Reptilia, Mammalia, and Amphibia."
        ],
        "isCorrect": false
      },
      {
        "id": 879,
        "content": [
          "Pisces, Amphibia, Aves, Reptilia, and Mammalia."
        ],
        "isCorrect": false
      },
      {
        "id": 880,
        "content": [
          "Amphibia, Pisces, Aves, Reptilia, and Mammalia."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 226,
    "content": [
      "Which of the following temperature controlling mechanisms in homoiotherms is categorized into behavioral method?"
    ],
    "explanation": [
      "Homeothermic animals, also known as endothermic animals, maintain a stable internal body temperature despite changes in the external environment. They achieve this through various morphological, physiological, and behavioral methods.\n\nSeeking shade is a behavioral adaptation that allows homeothermic animals to regulate their body temperature by minimizing heat gain from direct sunlight."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 901,
        "content": [
          "Sweating when the temperature increases"
        ],
        "isCorrect": false
      },
      {
        "id": 902,
        "content": [
          "Constriction of capillaries when the temperature falls"
        ],
        "isCorrect": false
      },
      {
        "id": 903,
        "content": [
          "Shivering as a result of drop in temperature"
        ],
        "isCorrect": false
      },
      {
        "id": 904,
        "content": [
          "Seeking shade when the temperature rises"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 236,
    "content": [
      "Which one of the following sentences correctly describes the properties of water? It"
    ],
    "explanation": [
      "Water has a high specific heat capacity, meaning it takes a lot of energy to raise its temperature."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 941,
        "content": [
          "contracts when it freezes and ice acts as an insulator."
        ],
        "isCorrect": false
      },
      {
        "id": 942,
        "content": [
          "takes low energy to change into vapor."
        ],
        "isCorrect": false
      },
      {
        "id": 943,
        "content": [
          "allows all light wavelengths to pass through its various depths."
        ],
        "isCorrect": false
      },
      {
        "id": 944,
        "content": [
          "requires high amount of energy to heat up."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 237,
    "content": [
      "An organic molecule which is an important part of structure of chromosome is"
    ],
    "explanation": [
      "Chromosomes are made of DNA and proteins. While DNA carries the genetic information, proteins provide structural support and help to organize the DNA.\n\nAmino acids are the building blocks of proteins. Amino acids link together to create long chains that fold into specific shapes, forming proteins."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 945,
        "content": [
          "amino acid."
        ],
        "isCorrect": true
      },
      {
        "id": 946,
        "content": [
          "glycogen."
        ],
        "isCorrect": false
      },
      {
        "id": 947,
        "content": [
          "amylose."
        ],
        "isCorrect": false
      },
      {
        "id": 948,
        "content": [
          "triglyceride."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 238,
    "content": [
      "In animal cells, glycogen is hydrolyzed quickly to release glucose for respiration. This is due to the presence of several"
    ],
    "explanation": [
      "Glycogen is a branched polymer of glucose that serves as a form of energy storage in animals.\n\nThe presence of α-1,6-glycosidic bonds at the branch points of glycogen allows for the rapid hydrolysis of glucose monomers when energy is needed. These branch points provide multiple sites for enzymes to break down the glycogen molecule, releasing glucose for respiration."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 949,
        "content": [
          "microfibrils in its side chain."
        ],
        "isCorrect": false
      },
      {
        "id": 950,
        "content": [
          "α-1,6- glyosidic bonds."
        ],
        "isCorrect": true
      },
      {
        "id": 951,
        "content": [
          "β-1,4-glycosidic bonds."
        ],
        "isCorrect": false
      },
      {
        "id": 952,
        "content": [
          "enzymes that hydrolyze it easily."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 240,
    "content": [
      "This item is based on the following diagram which depicts structural formula of a biological molecule.",
      "images/biology/year_2015/q40_1.png",
      "The molecule represented by the above structure is"
    ],
    "explanation": [
      "Glycerol is a triol, meaning it has three hydroxyl groups (-OH) attached to a carbon backbone."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/biology/year_2015/q40_1.png"
    ],
    "choices": [
      {
        "id": 957,
        "content": [
          "cellulose."
        ],
        "isCorrect": false
      },
      {
        "id": 958,
        "content": [
          "amylopectin."
        ],
        "isCorrect": false
      },
      {
        "id": 959,
        "content": [
          "fatty acid."
        ],
        "isCorrect": false
      },
      {
        "id": 960,
        "content": [
          "glycerol."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 242,
    "content": [
      "When a biologist shares her research findings with other fellow biologists, she is"
    ],
    "explanation": [
      "Sharing research findings aligns with the final step of the scientific method, \"Communicating the findings\". This step involves scientists compiling their research methods and the results into a paper and submitting it to a scientific journal to be shared with others in their field."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 965,
        "content": [
          "making her hypothesis."
        ],
        "isCorrect": false
      },
      {
        "id": 966,
        "content": [
          "reporting her result."
        ],
        "isCorrect": true
      },
      {
        "id": 967,
        "content": [
          "drawing her conclusion."
        ],
        "isCorrect": false
      },
      {
        "id": 968,
        "content": [
          "analyzing her data."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 245,
    "content": [
      "This item is based on the table below which shows a list of molecules.",
      "images/biology/year_2015/q45_1.png",
      "In the above table, which number holds only organic molecules?"
    ],
    "explanation": [
      "- 1: Calcium carbonate ($$CaCO_3$$) is an inorganic molecule because it does not contain carbon-hydrogen bonds.\n- 2: Carbon dioxide ($$CO_2$$) is considered inorganic despite containing carbon. It lacks the carbon-hydrogen bond that characterizes organic molecules.\n- 3:  Linoleic acid, glucose, and methane all contain carbon-hydrogen bonds, making them organic molecules.\n- 4: Iron III oxide ($$Fe_2O_3$$) is inorganic, lacking carbon-hydrogen bonds.\n\nTherefore, 3 is the only option containing solely organic molecules."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/biology/year_2015/q45_1.png"
    ],
    "choices": [
      {
        "id": 977,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 978,
        "content": [
          "3"
        ],
        "isCorrect": true
      },
      {
        "id": 979,
        "content": [
          "4"
        ],
        "isCorrect": false
      },
      {
        "id": 980,
        "content": [
          "1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 254,
    "content": [
      "Which one of the following is an example of a learned behavior?"
    ],
    "explanation": [
      "Classical conditioning is a type of learned behavior discovered by Ivan Pavlov. It involves forming associations between a neutral stimulus and a stimulus that naturally elicits a response. Through repeated pairings, the neutral stimulus comes to elicit the same response as the original stimulus."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1013,
        "content": [
          "Nest-building"
        ],
        "isCorrect": false
      },
      {
        "id": 1014,
        "content": [
          "Knee-jerk reflex"
        ],
        "isCorrect": false
      },
      {
        "id": 1015,
        "content": [
          "Weaving a web"
        ],
        "isCorrect": false
      },
      {
        "id": 1016,
        "content": [
          "Classical conditioning"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 258,
    "content": [
      "All of the following are examples of innate behaviors EXCEPT"
    ],
    "explanation": [
      "Training killer whales at marine parks is a learned behavior rather than an innate behavior. Learned behavior, unlike innate behavior, is shaped by experience."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1029,
        "content": [
          "training killer whales at marine parks."
        ],
        "isCorrect": true
      },
      {
        "id": 1030,
        "content": [
          "increasing breathing rate during exercise."
        ],
        "isCorrect": false
      },
      {
        "id": 1031,
        "content": [
          "producing tears when dust gets into the eyes."
        ],
        "isCorrect": false
      },
      {
        "id": 1032,
        "content": [
          "a fly moving its maggot into more humid environment."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 259,
    "content": [
      "Which one of the following is an example of in-sight learning?"
    ],
    "explanation": [
      "Insight learning is a type of learning where an organism develops a sudden understanding or solution to a problem without trial-and-error. It often involves using past experiences and reasoning to solve a new challenge.\n\nThe chimpanzee exemplifies insight learning, after several trials, likely understands the relationship between the boxes and reaching the bananas."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1033,
        "content": [
          "Salivation of a dog when a bell was rung in the absence of food, which was paired with the conditioned stimulus."
        ],
        "isCorrect": false
      },
      {
        "id": 1034,
        "content": [
          "Use of boxes, after several trials, by a chimpanzee placed in an enclosed area to obtain bananas placed on the top of an enclosure."
        ],
        "isCorrect": true
      },
      {
        "id": 1035,
        "content": [
          "Exhibition of modifications of natural behaviors of guide dogs, horses or zoo animals to desired behaviors."
        ],
        "isCorrect": false
      },
      {
        "id": 1036,
        "content": [
          "Lack of response from a lady, which sat in a shop in which a strong deodorant was continuously released from a can."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 260,
    "content": [
      "Which one of the following is an example of territorial behavior of animals?"
    ],
    "explanation": [
      "Territorial behavior refers to actions animals take to defend an area they consider their own from rivals, usually within the same species. This area, or territory, often holds valuable resources like food, mates, or nesting sites.\n\nA male robin threatening an intruder aligns with this concept because the male robin is actively trying to protect its territory and its resources from a competitor."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1037,
        "content": [
          "A male robin threatening an intruder"
        ],
        "isCorrect": true
      },
      {
        "id": 1038,
        "content": [
          "Fixed action of zebra fish to find a mate"
        ],
        "isCorrect": false
      },
      {
        "id": 1039,
        "content": [
          "Penguins huddling to reduce heat loss"
        ],
        "isCorrect": false
      },
      {
        "id": 1040,
        "content": [
          "Honeybees nesting in a tree"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 261,
    "content": [
      "One of the following renowned Ethiopian biologists has developed a vaccine for the rinderpest disease."
    ],
    "explanation": [
      "Professor Tilahun Yilma is a renowned Ethiopian virologist who developed a genetically engineered vaccine for rinderpest, a deadly disease affecting cattle. His work in veterinary medicine has been pivotal in the control and eventual eradication of rinderpest worldwide."
    ],
    "year": "YEAR_2015",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1041,
        "content": [
          "Professor Sebsebe Demissew"
        ],
        "isCorrect": false
      },
      {
        "id": 1042,
        "content": [
          "Professor Yalemtsehay Mekonnen"
        ],
        "isCorrect": false
      },
      {
        "id": 1043,
        "content": [
          "Professor Beyene Petros"
        ],
        "isCorrect": false
      },
      {
        "id": 1044,
        "content": [
          "Professor Tilahun Yilma"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 1583,
    "content": [
      "The binomial system of naming developed by Linnaeus comprises two names. Which hierarchical groups are used?"
    ],
    "explanation": [
      "The binomial nomenclature system, formalized by Carl Linnaeus, assigns a unique two-part scientific name to each species.\n\nThe first part identifies the Genus (always capitalized), and the second part identifies the specific epithet or species (never capitalized).\n\nFor example, *Homo sapiens* refers to the genus *Homo* and the species *sapiens*."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6333,
        "content": [
          "Order and family"
        ],
        "isCorrect": false
      },
      {
        "id": 6334,
        "content": [
          "Kingdome and species"
        ],
        "isCorrect": false
      },
      {
        "id": 6335,
        "content": [
          "Genus and species"
        ],
        "isCorrect": true
      },
      {
        "id": 6336,
        "content": [
          "Kingdome and phylum"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 1586,
    "content": [
      "Which one of the following is a feature of Octopi and squid in phylum mollusca? They have"
    ],
    "explanation": [
      "Octopi and squid belong to the class Cephalopoda within the phylum Mollusca.\n\nCephalopods are renowned for having the most complex nervous systems and largest brains among all invertebrates.\n\nThis well-developed brain supports their active predatory lifestyle, complex behaviors, and sophisticated sensory capabilities."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6345,
        "content": [
          "segmented body with head and thorax."
        ],
        "isCorrect": false
      },
      {
        "id": 6346,
        "content": [
          "well-developed brain."
        ],
        "isCorrect": true
      },
      {
        "id": 6347,
        "content": [
          "lung as a breathing structure."
        ],
        "isCorrect": false
      },
      {
        "id": 6348,
        "content": [
          "hard muscular foot with a hard body."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 1599,
    "content": [
      "A mother milks her cow every morning and the milk usually forms curd after three days. What is the first step to investigate why this change happens?"
    ],
    "explanation": [
      "The scientific method typically begins with an observation (milk curdles after three days).\n\nThe immediate next step is to formulate a specific question based on that observation.\n\nAsking \"Why does the milk form curd?\" is the crucial first step in initiating a scientific investigation to understand the phenomenon."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6397,
        "content": [
          "Take action to prevent the milk from curdling"
        ],
        "isCorrect": false
      },
      {
        "id": 6398,
        "content": [
          "Read scientific articles about the reason for curdling of milk"
        ],
        "isCorrect": false
      },
      {
        "id": 6399,
        "content": [
          "Formulate hypothesis about the reason for milk curdling"
        ],
        "isCorrect": false
      },
      {
        "id": 6400,
        "content": [
          "Ask a question why the milk forms curd"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 1600,
    "content": [
      "A drug efficacy test was conducted under similar set up on two groups of infected mice (A and B). groups A were the control whereas group B were experimental group. A student gave a placebo to the control group and the drug to the experimental group. At the end, the experimental group got better. Which one of the following is true about the result?"
    ],
    "explanation": [
      "The experiment compared a group receiving a drug (experimental) to a group receiving a placebo (control) under similar conditions.\n\nSince the experimental group showed improvement (\"got better\") compared to the control group, it indicates that the drug itself had a positive effect beyond any placebo effect."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6401,
        "content": [
          "Conclusion cannot be reached."
        ],
        "isCorrect": false
      },
      {
        "id": 6402,
        "content": [
          "The drug has an effect."
        ],
        "isCorrect": true
      },
      {
        "id": 6403,
        "content": [
          "Placebo has better effect."
        ],
        "isCorrect": false
      },
      {
        "id": 6404,
        "content": [
          "The experiment was wrong."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 1601,
    "content": [
      "Suppose you did an experiment in a biology laboratory and need to report your work to your biology teacher. Which one of the following steps is correct to report the finding?"
    ],
    "explanation": [
      "A standard scientific report follows a logical structure.\n\nIt typically starts with a Title, introduces the background leading to a Hypothesis and Prediction, describes the Methods/Procedure used, presents the obtained Results, interprets these results in the Conclusion, assesses the experiment in the Evaluation, and finally includes Acknowledgments if necessary."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6405,
        "content": [
          "Title → Procedure → Result → Hypothesis → Prediction → Conclusion → Acknowledgment"
        ],
        "isCorrect": false
      },
      {
        "id": 6406,
        "content": [
          "Title → Hypothesis → Procedure → Prediction → Conclusion → Result → Evaluation → Acknowledgment"
        ],
        "isCorrect": false
      },
      {
        "id": 6407,
        "content": [
          "Title → Hypothesis → Prediction → Procedure → Result → Conclusion → Evaluation → Acknowledgment"
        ],
        "isCorrect": true
      },
      {
        "id": 6408,
        "content": [
          "Title → Prediction → Procedure → Hypothesis → Result → Conclusion → Evaluation → Acknowledgment"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 1604,
    "content": [
      "Which of the following is the most advanced and recent event in the history of cell biology?"
    ],
    "explanation": [
      "While all listed events were significant, the sequencing of the human genome (completed in the early 2000s) represents a more recent and technologically advanced milestone in biology compared to the discovery of DNA structure (1953), the invention of early electron microscopes (mid-20th century), or the description of the Golgi apparatus (1898).\n\nGenome sequencing provides a comprehensive blueprint of an organism's genetic information, enabling vast advancements in medicine, genetics, and evolutionary biology."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6417,
        "content": [
          "Discovery of the double-helix structure of DNA"
        ],
        "isCorrect": false
      },
      {
        "id": 6418,
        "content": [
          "Enovation of the first scanning electron microscope"
        ],
        "isCorrect": false
      },
      {
        "id": 6419,
        "content": [
          "Description of the Golgi apparatus"
        ],
        "isCorrect": false
      },
      {
        "id": 6420,
        "content": [
          "Sequencing of the human genome"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Application of Biology"
  },
  {
    "id": 1607,
    "content": [
      "Which biological tool is correctly matched with its function?"
    ],
    "explanation": [
      "Petri dishes are shallow, cylindrical glass or plastic containers with lids, specifically designed to hold a thin layer of nutrient agar or other growth medium for the purpose of culturing microorganisms like bacteria, yeast, or molds in a laboratory setting."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6429,
        "content": [
          "Petri dishes - to culture microorganisms"
        ],
        "isCorrect": true
      },
      {
        "id": 6430,
        "content": [
          "Burette - to measure mass of a substance"
        ],
        "isCorrect": false
      },
      {
        "id": 6431,
        "content": [
          "Centrifuges - to collect insects"
        ],
        "isCorrect": false
      },
      {
        "id": 6432,
        "content": [
          "Theodolite - to measure the rate of water flow"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 1608,
    "content": [
      "A student centrifuge a solution containing plant material in order to separate them based on their mass. After 10 minutes of centrifugation some of the components move to the bottom (remove A), others to the middle layer (remove B) and the remaining once to the top layer (remove C). Which alternative shows the mass of the components in decreasing order?"
    ],
    "explanation": [
      "Centrifugation separates components based on their density and mass. Denser and more massive particles experience a greater centrifugal force and sediment faster, accumulating at the bottom of the tube. Less dense/massive particles sediment slower or remain suspended higher up.\n\nTherefore, the components at the bottom (remove A) have the greatest mass, followed by those in the middle layer (B), and finally those at the top layer (remove C) have the least mass. The decreasing order of mass is A > B > C."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6433,
        "content": [
          "C>A>B"
        ],
        "isCorrect": false
      },
      {
        "id": 6434,
        "content": [
          "A>B>C"
        ],
        "isCorrect": true
      },
      {
        "id": 6435,
        "content": [
          "B>A>C"
        ],
        "isCorrect": false
      },
      {
        "id": 6436,
        "content": [
          "A=B=C"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Application of Biology"
  },
  {
    "id": 1609,
    "content": [
      "Which one of the following statements shows the future promise of biological sciences?"
    ],
    "explanation": [
      "Stem cell research holds significant promise for regenerative medicine. Stem cells have the unique ability to differentiate into various specialized cell types.\n\nThis potential allows scientists to explore using them to repair tissues damaged by disease or injury (e.g., heart muscle after a heart attack, nerve cells in spinal cord injuries) and potentially even grow entire new organs for transplantation, addressing organ shortages and rejection issues."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6437,
        "content": [
          "Finding alternative living place for human population"
        ],
        "isCorrect": false
      },
      {
        "id": 6438,
        "content": [
          "Using stem cells to repair damaged organs and grow new organ"
        ],
        "isCorrect": true
      },
      {
        "id": 6439,
        "content": [
          "Finding the adaptation mechanism of plant in new condition"
        ],
        "isCorrect": false
      },
      {
        "id": 6440,
        "content": [
          "Advising the government on how to conserve environment"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Application of Biology"
  },
  {
    "id": 1610,
    "content": [
      "Which one of the following alternatives contains only organic molecules?"
    ],
    "explanation": [
      "Organic molecules are primarily composed of carbon atoms bonded to hydrogen, often along with oxygen, nitrogen, and other elements.\n\n- Methane ($$CH_4$$) is the simplest alkane, an organic compound.\n- Glycine ($$C_2H_5NO_2$$) is an amino acid, an organic compound.\n- Linoleic acid ($$C_{18}H_{32}O_2$$) is a fatty acid, an organic compound.\n- Glucose ($$C_6H_{12}O_6$$) is a simple sugar (monosaccharide), an organic compound.\n\nOther options include inorganic molecules: Carbon dioxide ($$CO_2$$) and Calcium carbonate ($$CaCO_3$$)."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6441,
        "content": [
          "Glucose, carbon dioxide, glycine and linoleic acid"
        ],
        "isCorrect": false
      },
      {
        "id": 6442,
        "content": [
          "Methane, calcium carbonate, linoleic acid and glucose"
        ],
        "isCorrect": false
      },
      {
        "id": 6443,
        "content": [
          "Methane, glycine, linoleic acid and glucose"
        ],
        "isCorrect": true
      },
      {
        "id": 6444,
        "content": [
          "Linoleic acid, glucose, calcium carbonate and methane"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 1611,
    "content": [
      "Which one of the following properties permits insects to freely walk on water? Its high"
    ],
    "explanation": [
      "Water molecules are cohesive (attracted to each other) due to hydrogen bonding.\n\nAt the surface, water molecules are pulled more strongly by molecules below and beside them than by the air above. This creates a \"skin\" or film on the surface, known as surface tension.\n\nThis property is strong enough to support the weight of small insects, allowing them to walk on water without sinking."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6445,
        "content": [
          "specific heat capacity"
        ],
        "isCorrect": false
      },
      {
        "id": 6446,
        "content": [
          "adhesive force"
        ],
        "isCorrect": false
      },
      {
        "id": 6447,
        "content": [
          "latent heat of vaporization"
        ],
        "isCorrect": false
      },
      {
        "id": 6448,
        "content": [
          "surface tension"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 1617,
    "content": [
      "Which one of the following organic molecules has ester bonds in its molecular structure?"
    ],
    "explanation": [
      "Triglycerides, the main components of body fat and vegetable oils, are formed by the reaction of one molecule of glycerol with three molecules of fatty acids.\n\nThis reaction is an esterification, forming three ester bonds (-COO-) linking each fatty acid to the glycerol backbone.\n\nGlycogen and cellulose have glycosidic bonds, and amino acids link via peptide bonds to form proteins."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6469,
        "content": [
          "Triglyceride"
        ],
        "isCorrect": true
      },
      {
        "id": 6470,
        "content": [
          "Glycogen"
        ],
        "isCorrect": false
      },
      {
        "id": 6471,
        "content": [
          "Amino acid"
        ],
        "isCorrect": false
      },
      {
        "id": 6472,
        "content": [
          "Cellulose"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 1618,
    "content": [
      "Which one of the following statement is correct about the structural organization of hemoglobin? It is formed"
    ],
    "explanation": [
      "Hemoglobin is a protein with a quaternary structure. This level of protein structure arises from the assembly of multiple separate polypeptide chains (subunits) into a functional protein complex.\n\nHemoglobin specifically consists of four polypeptide chains (two alpha and two beta chains)."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_MOLECULES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6473,
        "content": [
          "when a polypeptide chain folds itself during protein synthesis."
        ],
        "isCorrect": false
      },
      {
        "id": 6474,
        "content": [
          "through the association of two or more polypeptide chains."
        ],
        "isCorrect": true
      },
      {
        "id": 6475,
        "content": [
          "through folding of secondary structure of a polypeptide chain."
        ],
        "isCorrect": false
      },
      {
        "id": 6476,
        "content": [
          "by hydrogen bonding between quaternary and tertiary structures."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Biochemical Molecules"
  },
  {
    "id": 1637,
    "content": [
      "Which one of the following research activities has been conducted at Armauer Hansen Research Institute?"
    ],
    "explanation": [
      "The Armauer Hansen Research Institute (AHRI), located in Ethiopia, is a biomedical research institute primarily focused on infectious diseases of public health significance in developing countries.\n\nIts historical and ongoing research focuses heavily on diseases like leprosy (caused by *Mycobacterium leprae*, discovered by Armauer Hansen), tuberculosis, leishmaniasis, and other mycobacterial diseases, including drug development and diagnostics."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6549,
        "content": [
          "Improving crop production through genetic engineering"
        ],
        "isCorrect": false
      },
      {
        "id": 6550,
        "content": [
          "Conserving the genes of endemic plants and animals"
        ],
        "isCorrect": false
      },
      {
        "id": 6551,
        "content": [
          "Assessing the nutritional status of mothers and babies"
        ],
        "isCorrect": false
      },
      {
        "id": 6552,
        "content": [
          "Developing drugs for leishmaniasis and tuberculosis"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 1663,
    "content": [
      "Which one of the following features is NOT the characteristic feature of fungi? They"
    ],
    "explanation": [
      "Fungi are exclusively heterotrophic, meaning they obtain nutrients from external sources.\n\nThey can be saprophytic (decomposers), parasitic (harming a host), or mutualistic.\n\nThey lack chlorophyll and cannot perform photosynthesis, thus they are never autotrophic (producing their own food)."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6653,
        "content": [
          "have haploid nuclei and multinucleate hypha."
        ],
        "isCorrect": false
      },
      {
        "id": 6654,
        "content": [
          "reproduce asexually through spore production."
        ],
        "isCorrect": false
      },
      {
        "id": 6655,
        "content": [
          "are either autotrophic, parasitic or saprophytic."
        ],
        "isCorrect": true
      },
      {
        "id": 6656,
        "content": [
          "exhibit apical growth of networked hypha."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 1668,
    "content": [
      "Which of the following explains how biology takes part in biosensor technology? Using microorganism to"
    ],
    "explanation": [
      "Biosensors are analytical devices that combine a biological component with a physicochemical detector.\n\nMicroorganisms can be used as the biological component to detect specific substances, such as pollutants.\n\nThe metabolic activity or specific reactions of the microorganism in the presence of the pollutant can generate a measurable signal, allowing for the monitoring of environmental contaminants."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6673,
        "content": [
          "monitor pollutants"
        ],
        "isCorrect": true
      },
      {
        "id": 6674,
        "content": [
          "develop vaccines"
        ],
        "isCorrect": false
      },
      {
        "id": 6675,
        "content": [
          "extract metals from ores"
        ],
        "isCorrect": false
      },
      {
        "id": 6676,
        "content": [
          "produce antibiotics"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 1671,
    "content": [
      "Which one of the following statements correctly describes bacteria? They are"
    ],
    "explanation": [
      "Bacteria are defined by their cellular structure.\n\nThey are prokaryotes, meaning their cells lack a membrane-bound nucleus and other complex organelles.\n\nThe vast majority of bacteria are unicellular, existing as independent single cells."
    ],
    "year": "YEAR_2016",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6685,
        "content": [
          "multicellular eukaryotic organisms."
        ],
        "isCorrect": false
      },
      {
        "id": 6686,
        "content": [
          "single celled prokaryotic organisms."
        ],
        "isCorrect": true
      },
      {
        "id": 6687,
        "content": [
          "single celled eukaryotic organisms."
        ],
        "isCorrect": false
      },
      {
        "id": 6688,
        "content": [
          "multicellular prokaryotic organisms."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 2748,
    "content": [
      "Which one of the following Ethiopian biological research institutes is known for housing a major gene bank in Africa?"
    ],
    "explanation": [
      "The Ethiopian Institute of Biodiversity Conservation (IBC) is renowned for being one of the largest and most significant gene banks in Africa, preserving a vast collection of plant, animal, and microbial genetic resources."
    ],
    "year": "YEAR_2017",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11001,
        "content": [
          "Addis Ababa University Biology Department"
        ],
        "isCorrect": false
      },
      {
        "id": 11002,
        "content": [
          "Institute of Biodiversity Conservation"
        ],
        "isCorrect": true
      },
      {
        "id": 11003,
        "content": [
          "Aklilu Lemma Institute of Pathobiology"
        ],
        "isCorrect": false
      },
      {
        "id": 11004,
        "content": [
          "Armauer Hansen Research Institute"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 2749,
    "content": [
      "A grade 12 student marked two dots close to each other using a pen on a piece of paper and observed them under a microscope. The two dots appeared well separated under the microscope. This was due to"
    ],
    "explanation": [
      "Resolution is the ability of a microscope to distinguish between two adjacent points as separate entities. The fact that the close dots appeared well separated indicates that the microscope has good resolving power. Magnification just makes the image larger, but without resolution, the dots would appear as a single, larger blur."
    ],
    "year": "YEAR_2017",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11005,
        "content": [
          "resolution"
        ],
        "isCorrect": true
      },
      {
        "id": 11006,
        "content": [
          "magnification."
        ],
        "isCorrect": false
      },
      {
        "id": 11007,
        "content": [
          "staining"
        ],
        "isCorrect": false
      },
      {
        "id": 11008,
        "content": [
          "mounting."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Application of Biology"
  },
  {
    "id": 2759,
    "content": [
      "A biology teacher provided common names of three organisms; human being, dog and housefly to his students to write the correct scientific names of each organism. In which of the following ways should the students write the correct scientific names, respectively?"
    ],
    "explanation": [
      "According to the rules of binomial nomenclature, the scientific name consists of two parts. The first part is the genus, which is always capitalized. The second part is the species, which is always in lowercase. The entire name is typically italicized.",
      "Therefore, *Homo sapiens*, *Canis familiaris*, and *Musca domestica* are the correctly written names."
    ],
    "year": "YEAR_2017",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11045,
        "content": [
          "Homo Sapiens, Canis Familiaris and Musca Domestica"
        ],
        "isCorrect": false
      },
      {
        "id": 11046,
        "content": [
          "Homo sapiens, Canis familiaris and Musca domestica"
        ],
        "isCorrect": true
      },
      {
        "id": 11047,
        "content": [
          "homo sapiens, Canis familiaris and Musca domestica"
        ],
        "isCorrect": false
      },
      {
        "id": 11048,
        "content": [
          "Homo sapiens, Canis familiaris and musca domestica"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 2770,
    "content": [
      "In which one of the following alternatives the whole list contains characteristics of animals?"
    ],
    "explanation": [
      "The defining characteristics of the animal kingdom include being heterotrophic (cannot make their own food), excreting waste products, being motile (able to move) at some stage of life, and growing. Animals are not autotrophic, and while most are multicellular, \"unicellular\" is incorrect as a general characteristic."
    ],
    "year": "YEAR_2017",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11089,
        "content": [
          "Respire, excrete, autotrophic and reproduce"
        ],
        "isCorrect": false
      },
      {
        "id": 11090,
        "content": [
          "Unicellular, excrete, heterotrophic and motility"
        ],
        "isCorrect": false
      },
      {
        "id": 11091,
        "content": [
          "Heterotrophic, excrete, motility and grow"
        ],
        "isCorrect": true
      },
      {
        "id": 11092,
        "content": [
          "Respire, multicellular, autotrophic and reproduce"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 2771,
    "content": [
      "A grade 11 student observed and identified some animals group having closed circulatory system, centralized nervous system with brain and sensory organs. Based on their identification select one of the following animals that can belong to this group?"
    ],
    "explanation": [
      "All vertebrates, including snakes, possess a closed circulatory system (where blood is contained within vessels) and a highly centralized nervous system with a well-developed brain and complex sensory organs. While squids and earthworms also have closed circulatory systems, snakes (as vertebrates) are a prime example of a group defined by all these advanced features. Snails typically have an open circulatory system."
    ],
    "year": "YEAR_2017",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11093,
        "content": [
          "Snails"
        ],
        "isCorrect": false
      },
      {
        "id": 11094,
        "content": [
          "Earthworm"
        ],
        "isCorrect": false
      },
      {
        "id": 11095,
        "content": [
          "Squid"
        ],
        "isCorrect": false
      },
      {
        "id": 11096,
        "content": [
          "Snake"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 2772,
    "content": [
      "What does it mean if an animal is poikilothermic? It"
    ],
    "explanation": [
      "A poikilothermic animal, often referred to as \"cold-blooded,\" is an organism whose internal body temperature varies considerably, typically in conjunction with the temperature of its surrounding environment. They lack internal physiological mechanisms to regulate their body temperature."
    ],
    "year": "YEAR_2017",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11097,
        "content": [
          "changes its body temperature with environmental condition."
        ],
        "isCorrect": true
      },
      {
        "id": 11098,
        "content": [
          "increases its metabolic rate during cold and hot conditions."
        ],
        "isCorrect": false
      },
      {
        "id": 11099,
        "content": [
          "keeps its body temperature constant regardless of external changes."
        ],
        "isCorrect": false
      },
      {
        "id": 11100,
        "content": [
          "produces heat when temperature falls by activating the hypothalamus."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 2787,
    "content": [
      "Farmers want to maintain their sheep with long tails for the next generation through similar sheep from their locality in their breeding program. What process do these farmers apply to keep the desired traits in their program?"
    ],
    "explanation": [
      "Inbreeding is the mating of closely related individuals within the same breed or locality. This practice is used to concentrate and maintain desirable traits, such as long tails in this case, within a population."
    ],
    "year": "YEAR_2017",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11156,
        "content": [
          "Inbreeding"
        ],
        "isCorrect": true
      },
      {
        "id": 11157,
        "content": [
          "Crossbreeding"
        ],
        "isCorrect": false
      },
      {
        "id": 11158,
        "content": [
          "Genetic engineering"
        ],
        "isCorrect": false
      },
      {
        "id": 11159,
        "content": [
          "Cloning"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 2792,
    "content": [
      "The finding of the study conducted in two different villages showed that there are harmful practices that affect reproductive health. The common practices in village 1 were forcing underage girls to get married based norms and sexual abuse or harassment. In village 2 abduction to make the girl a wife unwillingly was very common. Which one of the following options is correct about the two villages?"
    ],
    "explanation": [
      "The question states that in village 1, practices included \"forcing underage girls to get married\" (early marriage) and \"sexual abuse or harassment\" (a form of gender-based violence). The other options incorrectly assign practices to the villages or mention practices not described in the text (like FGM)."
    ],
    "year": "YEAR_2017",
    "subject": "BIOLOGY",
    "chapter": "BIO_BEHAVIOUR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11176,
        "content": [
          "In village 1, gender-based violence, kidnapping and female genital mutilation are common."
        ],
        "isCorrect": false
      },
      {
        "id": 11177,
        "content": [
          "In village 1, gender-based violence and early marriage are common."
        ],
        "isCorrect": true
      },
      {
        "id": 11178,
        "content": [
          "In village 2, kidnapping and female genital mutilation are common."
        ],
        "isCorrect": false
      },
      {
        "id": 11179,
        "content": [
          "In village 2, gender-based violence and female genital mutilation are common."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Animals"
  },
  {
    "id": 2798,
    "content": [
      "What is the primary purpose of creating transgenic organisms? To"
    ],
    "explanation": [
      "The primary goal of creating transgenic organisms is to introduce specific genes from one organism into another to confer a desirable trait. A major application of this technology is in agriculture, for example, to create crops with improved nutritional value (like Golden Rice with vitamin A), pest resistance, or herbicide tolerance."
    ],
    "year": "YEAR_2017",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11200,
        "content": [
          "generate pathogenic organisms that fight against non-pathogenic ones"
        ],
        "isCorrect": false
      },
      {
        "id": 11201,
        "content": [
          "produce organisms that mimic human beings in every aspect of behaviors"
        ],
        "isCorrect": false
      },
      {
        "id": 11202,
        "content": [
          "promote expression of desired genes that improve nutritional quality of organisms"
        ],
        "isCorrect": true
      },
      {
        "id": 11203,
        "content": [
          "produce novel organisms that can affect reproduction across different species"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Introduction to Biology"
  },
  {
    "id": 2857,
    "content": [
      "Which one of the following statements is correct about the binomial nomenclature?"
    ],
    "explanation": [
      "Binomial nomenclature is the formal system of naming species.",
      "A key rule is that the first part, the genus name, always begins with a capital letter. The second part, the specific epithet (species name), is always written in lowercase letters. For example, *Homo sapiens*."
    ],
    "year": "YEAR_2014",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11436,
        "content": [
          "The genus name is written in full while the species name is abbreviated."
        ],
        "isCorrect": false
      },
      {
        "id": 11437,
        "content": [
          "Both genus and species names are capitalized and italicized when printed."
        ],
        "isCorrect": false
      },
      {
        "id": 11438,
        "content": [
          "The first letter of genus name is capitalized while the species name is written in small letters."
        ],
        "isCorrect": true
      },
      {
        "id": 11439,
        "content": [
          "The genus name is written in English while the species name is written in Latin."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 2876,
    "content": [
      "Which one of the following plants is NOT endemic to Ethiopia?"
    ],
    "explanation": [
      "A plant is endemic if its native range is restricted to a particular geographical area.",
      "Enset, Noug, and Zigba are native to Ethiopia. The mango (*Mangifera indica*) is native to South Asia and was introduced to Ethiopia, where it is now widely cultivated but is not endemic."
    ],
    "year": "YEAR_2014",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11512,
        "content": [
          "Mango"
        ],
        "isCorrect": true
      },
      {
        "id": 11513,
        "content": [
          "Zigba"
        ],
        "isCorrect": false
      },
      {
        "id": 11514,
        "content": [
          "Noug"
        ],
        "isCorrect": false
      },
      {
        "id": 11515,
        "content": [
          "Enset"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 2878,
    "content": [
      "In kingdom animalia, which phylum poisons its prey by tentacles that contain stinging cells?"
    ],
    "explanation": [
      "The phylum Coelenterata (also known as Cnidaria) includes animals like jellyfish, corals, and sea anemones.",
      "A defining characteristic of this phylum is the presence of specialized stinging cells called cnidocytes, which they use for capturing prey and for defense."
    ],
    "year": "YEAR_2014",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11520,
        "content": [
          "Nematoda"
        ],
        "isCorrect": false
      },
      {
        "id": 11521,
        "content": [
          "Coelenterata"
        ],
        "isCorrect": true
      },
      {
        "id": 11522,
        "content": [
          "Annelida"
        ],
        "isCorrect": false
      },
      {
        "id": 11523,
        "content": [
          "Porifera"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 2879,
    "content": [
      "Mosses are grouped under division bryophyta because they"
    ],
    "explanation": [
      "Bryophytes are a group of non-vascular plants that include mosses, liverworts, and hornworts.",
      "Their key defining feature is the absence of a vascular system (xylem and phloem). This means they lack true roots, stems, and leaves for transport, and instead absorb water directly through their surfaces."
    ],
    "year": "YEAR_2014",
    "subject": "BIOLOGY",
    "chapter": "BIO_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11524,
        "content": [
          "lack true root system and vascular tissue."
        ],
        "isCorrect": true
      },
      {
        "id": 11525,
        "content": [
          "have true leaves, stems and roots."
        ],
        "isCorrect": false
      },
      {
        "id": 11526,
        "content": [
          "have flat and broad leaves."
        ],
        "isCorrect": false
      },
      {
        "id": 11527,
        "content": [
          "are evergreen and photosynthesize all year round."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Characteristics and Classification of Organisms"
  },
  {
    "id": 2884,
    "content": [
      "The importance of stains in microscopic investigations is explained by their effect in"
    ],
    "explanation": [
      "Many biological specimens and their components are nearly transparent, making them difficult to see under a light microscope.",
      "Stains are dyes that selectively bind to different cellular structures, imparting color to them. This creates contrast between different parts of the cell and between the cell and its background, making them visible."
    ],
    "year": "YEAR_2014",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11544,
        "content": [
          "increasing resolution."
        ],
        "isCorrect": false
      },
      {
        "id": 11545,
        "content": [
          "creating contrast."
        ],
        "isCorrect": true
      },
      {
        "id": 11546,
        "content": [
          "increasing magnification."
        ],
        "isCorrect": false
      },
      {
        "id": 11547,
        "content": [
          "decreasing air bubbles."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Application of Biology"
  },
  {
    "id": 2929,
    "content": [
      "What type of force is responsible if a stool solution is placed in a centrifuge, spins the tube at high speed and the solid particles are forced to settle down at the bottom?"
    ],
    "explanation": [
      "A centrifuge spins samples in a circular path at high velocity.",
      "The force that keeps the sample moving in this circle is the centripetal force, directed towards the center of rotation. Due to inertia, the denser particles in the solution tend to move in a straight line, which forces them outwards towards the bottom of the tube, causing them to sediment."
    ],
    "year": "YEAR_2014",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 11724,
        "content": [
          "Cohesive force"
        ],
        "isCorrect": false
      },
      {
        "id": 11725,
        "content": [
          "Adhesive force"
        ],
        "isCorrect": false
      },
      {
        "id": 11726,
        "content": [
          "Centripetal force"
        ],
        "isCorrect": true
      },
      {
        "id": 11727,
        "content": [
          "Gravitational force"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Application of Biology"
  },
  {
    "id": 3008,
    "content": [
      "A medical laboratory technologist at Black Lion Hospital placed a solution of stool in a centrifuge to separate the particles quickly for stool test. Which one of the following will happen when he spins the centrifuge at high speed?"
    ],
    "explanation": [
      "A centrifuge works by spinning samples at high velocity, creating a powerful centrifugal force that is much stronger than gravity. This force causes denser components (like solid particles in the stool) to move away from the center of rotation and accumulate at the bottom of the centrifuge tube, forming a pellet."
    ],
    "year": "YEAR_2012",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12040,
        "content": [
          "The solid particles of the stool will float on the top of the mixture."
        ],
        "isCorrect": false
      },
      {
        "id": 12041,
        "content": [
          "The gravitational forces on the solid particles force the solid particles of the stool to the bottom of the tube."
        ],
        "isCorrect": true
      },
      {
        "id": 12042,
        "content": [
          "The solid particles of the stool will mix up highly and suspended freely."
        ],
        "isCorrect": false
      },
      {
        "id": 12043,
        "content": [
          "The liquid particles will evaporate but the solid particles will remain in the centrifuge tube."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Application of Biology"
  },
  {
    "id": 3009,
    "content": [
      "The relevance and promise of biology as a field of science can be best explained by its application in"
    ],
    "explanation": [
      "Biology has profound impacts on human society. Its applications in agriculture (improving crop yields, pest resistance) and genetic engineering (producing medicines like insulin, gene therapy, developing GMOs) are some of the most significant areas demonstrating its relevance and potential to solve major global challenges."
    ],
    "year": "YEAR_2012",
    "subject": "BIOLOGY",
    "chapter": "BIO_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12044,
        "content": [
          "agriculture and genetic engineering."
        ],
        "isCorrect": true
      },
      {
        "id": 12045,
        "content": [
          "sport and culture."
        ],
        "isCorrect": false
      },
      {
        "id": 12046,
        "content": [
          "oil and mineral production."
        ],
        "isCorrect": false
      },
      {
        "id": 12047,
        "content": [
          "economic growth and urbanization."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Biology and Technology"
  }
];

export default questions;
