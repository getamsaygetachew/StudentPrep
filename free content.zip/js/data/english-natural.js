// StudentPrep Free Content — only the first 2 non-empty curriculum units/categories per grade/subject.
const questions = [
  {
    "id": 551,
    "content": [
      "Choose the statement which is correctly punctuated and capitalized."
    ],
    "explanation": [
      "Proper nouns, such as the names of specific hotels and restaurants, should be capitalized. \"Hilton Hotel\" and \"Kokeb Restaurant\" are specific names, so both \"Hotel\" and \"Restaurant\" should be capitalized."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 12,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2201,
        "content": [
          "We used to stay at the Hilton Hotel and dine at Kokeb restaurant."
        ],
        "isCorrect": false
      },
      {
        "id": 2202,
        "content": [
          "We used to stay at the Hilton hotel and dine at Kokeb Restaurant."
        ],
        "isCorrect": false
      },
      {
        "id": 2203,
        "content": [
          "We used to stay at the Hilton Hotel and dine at Kokeb Restaurant."
        ],
        "isCorrect": true
      },
      {
        "id": 2204,
        "content": [
          "We used to stay at the Hilton hotel and dine at Kokeb restaurant."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 552,
    "content": [
      "Choose the statement which is correctly punctuated and capitalized."
    ],
    "explanation": [
      "In a list of items, the Oxford comma (the comma before \"and\" in a series) is used to avoid ambiguity and improve clarity. Correct choice correctly uses the Oxford comma after \"cloths\" and before \"and some rice.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 12,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2205,
        "content": [
          "We bought them blankets, bed sheets, cloths and some rice."
        ],
        "isCorrect": false
      },
      {
        "id": 2206,
        "content": [
          "We bought them blankets, bed sheets, cloths and, some rice."
        ],
        "isCorrect": false
      },
      {
        "id": 2207,
        "content": [
          "We bought them blankets, bed sheets, cloths and some rice."
        ],
        "isCorrect": false
      },
      {
        "id": 2208,
        "content": [
          "We bought them blankets, bed sheets, cloths, and some rice."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 553,
    "content": [
      "Choose the statement which is correctly punctuated and capitalized."
    ],
    "explanation": [
      "- \"St. Paul Hospital\" requires a period after \"St\" because it is an abbreviation for \"Saint.\"\n- \"e.g.\" is the correct abbreviation for \"for example,\" and it requires periods after both \"e\" and \"g,\" followed by a comma (\"e.g.,\").\n- The sentence is correctly punctuated and capitalized in option (C)."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 12,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2209,
        "content": [
          "At St. Paul Hospital, they train doctors in a variety of fields, eg., cardiology, neurology, etc."
        ],
        "isCorrect": false
      },
      {
        "id": 2210,
        "content": [
          "At St Paul Hospital, they train doctors in a variety of fields, e.g., cardiology, neurology, etc."
        ],
        "isCorrect": false
      },
      {
        "id": 2211,
        "content": [
          "At St. Paul Hospital, they train doctors in a variety of fields, e.g., cardiology, neurology, etc."
        ],
        "isCorrect": true
      },
      {
        "id": 2212,
        "content": [
          "At St. Paul Hospital, they train doctors in a variety of fields, e.g, cardiology, neurology, etc."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 554,
    "content": [
      "Choose the statement which is correctly punctuated and capitalized."
    ],
    "explanation": [
      "Semicolons are used to separate items in a list when the items themselves contain commas.\n- In this sentence, \"gave out food, clothing and medication\" is a single item in the list, so it is separated by a semicolon from the other items (\"donated money\" and \"pledged a lot more\").\n\nThe comma between \"food\" and \"clothing and medication\" is correct because it separates elements within the same list item."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 12,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2213,
        "content": [
          "They donated money; gave out food; clothing and medication, and pledged a lot more."
        ],
        "isCorrect": false
      },
      {
        "id": 2214,
        "content": [
          "They donated money; gave out food; clothing and medication; and pledged a lot more."
        ],
        "isCorrect": false
      },
      {
        "id": 2215,
        "content": [
          "They donated money; gave out food, clothing; and medication; and pledged a lot more."
        ],
        "isCorrect": false
      },
      {
        "id": 2216,
        "content": [
          "They donated money; gave out food, clothing and medication; and pledged a lot more."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 625,
    "content": [
      "**Passage**: Grown-ups On Campus",
      "---",
      "What makes adult students feel insecure?"
    ],
    "explanation": [
      "The passage directly states: \"Friends and family may not like or understand their new status.\" This directly relates to the adult students feeling insecure."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 18,
    "groupIndex": null,
    "sharedContentId": 4,
    "sharedContent": [
      "## Grown-ups on Campus\n\n1. Many professors enjoy teaching adults because they frequently work harder and have a better idea of what they want out of school than their younger classmates. \"A lot of young people who come in here at 18 don't have the foggiest notion of why they're here,\" says Art Gallaher, vice president of academic affairs at the University of Kentucky.\n2. The adults tend to be better prepared, too. Because they went to high school at a time when learning how to write was considered more important than advanced student leadership, their compositions have fewer errors in syntax, grammar and spelling than the essays of some of today's brightest undergraduates. And older students usually get their work in on time. \"I'm going to get the assignment done because I know I might have to stay home one day with my sick child,\" says Phyllis Dunham, 27, a psychology major at the University of Florida. \"Younger students seem to wait until the last minute and have to have an extension for this reason or that.\" A few teachers even find their older students intimidating. \"If you're in your early 30's with a fresh PhD. and a lot of book knowledge, it's rather threatening to be teaching someone who's been working in your field for years and is questioning your theories,\" says Arthur Chickering, director of the Center for the Study of Higher Education at Memphis State University.\n3. But more often than not it is the adult students who are insecure. Friends and family may not like or understand their new status. Jean Byrd, 46, a Hood sophomore says, returning to school at first created some friction with her 12-year-old daughter. \"She resented it because my grades were better than hers.\" Younger classmates aren't always friendly either. \"My first couple of years it was, like, what are these women doing here?\" says a young Hood junior. \"I'm in college. I thought I left my mother at home.\" The sense of alienation is heightened at places like Florida, which is still very much geared toward youngsters though about one-fifth of its students are older. \"They're putting a strain on the place because we're not used to dealing with them,\" confesses Mike Rollo, assistant dean for student services.\n4. The feeling can be mutual. \"In the beginning I felt very old,\" says Juliet Margolin, 28, a Florida pre-vet student who lived in a dorm for three months and felt \"like a counselor in a sleep-away camp.\" Appalled by ketchup in the showers and jelly on the mirrors in the communal bathroom, Margolin soon found a roommate of her own age and moved off campus. Kate Erickson, a 35-year-old English major at Rice University, says she is so out of place that she is trying to organize older students into a group she might call \"Anachronisms Anonymous.\" At Hood, Dixie Miller has set up a hide-away cottage for her continuing-ed students a place she says, \"to meet somebody else who is gray and grumpy.\"\n\nSource: Reading and Study Skills (Second Edition)"
    ],
    "images": [],
    "choices": [
      {
        "id": 2497,
        "content": [
          "Friends and family members may dislike them."
        ],
        "isCorrect": true
      },
      {
        "id": 2498,
        "content": [
          "Younger students sometimes swear at them."
        ],
        "isCorrect": false
      },
      {
        "id": 2499,
        "content": [
          "Socially, it is hard to compete with younger students."
        ],
        "isCorrect": false
      },
      {
        "id": 2500,
        "content": [
          "Some of the students may envy their performance."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 626,
    "content": [
      "**Passage**: Grown-ups On Campus",
      "---",
      "Comparatively, why do older students tend to get their work done in time?"
    ],
    "explanation": [
      "The passage quotes Phyllis Dunham, a psychology major, saying: \"I'm going to get the assignment done because I know I might have to stay home one day with my sick child.\" This illustrates that adult students prioritize getting work done on time because they anticipate potential unforeseen circumstances that could disrupt their schedules."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 18,
    "groupIndex": null,
    "sharedContentId": 4,
    "sharedContent": [
      "## Grown-ups on Campus\n\n1. Many professors enjoy teaching adults because they frequently work harder and have a better idea of what they want out of school than their younger classmates. \"A lot of young people who come in here at 18 don't have the foggiest notion of why they're here,\" says Art Gallaher, vice president of academic affairs at the University of Kentucky.\n2. The adults tend to be better prepared, too. Because they went to high school at a time when learning how to write was considered more important than advanced student leadership, their compositions have fewer errors in syntax, grammar and spelling than the essays of some of today's brightest undergraduates. And older students usually get their work in on time. \"I'm going to get the assignment done because I know I might have to stay home one day with my sick child,\" says Phyllis Dunham, 27, a psychology major at the University of Florida. \"Younger students seem to wait until the last minute and have to have an extension for this reason or that.\" A few teachers even find their older students intimidating. \"If you're in your early 30's with a fresh PhD. and a lot of book knowledge, it's rather threatening to be teaching someone who's been working in your field for years and is questioning your theories,\" says Arthur Chickering, director of the Center for the Study of Higher Education at Memphis State University.\n3. But more often than not it is the adult students who are insecure. Friends and family may not like or understand their new status. Jean Byrd, 46, a Hood sophomore says, returning to school at first created some friction with her 12-year-old daughter. \"She resented it because my grades were better than hers.\" Younger classmates aren't always friendly either. \"My first couple of years it was, like, what are these women doing here?\" says a young Hood junior. \"I'm in college. I thought I left my mother at home.\" The sense of alienation is heightened at places like Florida, which is still very much geared toward youngsters though about one-fifth of its students are older. \"They're putting a strain on the place because we're not used to dealing with them,\" confesses Mike Rollo, assistant dean for student services.\n4. The feeling can be mutual. \"In the beginning I felt very old,\" says Juliet Margolin, 28, a Florida pre-vet student who lived in a dorm for three months and felt \"like a counselor in a sleep-away camp.\" Appalled by ketchup in the showers and jelly on the mirrors in the communal bathroom, Margolin soon found a roommate of her own age and moved off campus. Kate Erickson, a 35-year-old English major at Rice University, says she is so out of place that she is trying to organize older students into a group she might call \"Anachronisms Anonymous.\" At Hood, Dixie Miller has set up a hide-away cottage for her continuing-ed students a place she says, \"to meet somebody else who is gray and grumpy.\"\n\nSource: Reading and Study Skills (Second Edition)"
    ],
    "images": [],
    "choices": [
      {
        "id": 2501,
        "content": [
          "Some of them have sick children whom they have to look after."
        ],
        "isCorrect": false
      },
      {
        "id": 2502,
        "content": [
          "They do not want to be rushed up when it is too late."
        ],
        "isCorrect": false
      },
      {
        "id": 2503,
        "content": [
          "It is to have time for unforeseen situations that may unexpectedly drag them away."
        ],
        "isCorrect": true
      },
      {
        "id": 2504,
        "content": [
          "The old school system shaped them in a way that does not procrastinate duties."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 627,
    "content": [
      "**Passage**: Grown-ups On Campus",
      "---",
      "What, according to Mike Rollo, was the problem at the University of Florida?"
    ],
    "explanation": [
      "Mike Rollo, assistant dean for student services, confesses: \"They're putting a strain on the place because we're not used to dealing with them.\"\n\nThis quote directly states that the University of Florida was having difficulty because they were not accustomed to handling older students."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 18,
    "groupIndex": null,
    "sharedContentId": 4,
    "sharedContent": [
      "## Grown-ups on Campus\n\n1. Many professors enjoy teaching adults because they frequently work harder and have a better idea of what they want out of school than their younger classmates. \"A lot of young people who come in here at 18 don't have the foggiest notion of why they're here,\" says Art Gallaher, vice president of academic affairs at the University of Kentucky.\n2. The adults tend to be better prepared, too. Because they went to high school at a time when learning how to write was considered more important than advanced student leadership, their compositions have fewer errors in syntax, grammar and spelling than the essays of some of today's brightest undergraduates. And older students usually get their work in on time. \"I'm going to get the assignment done because I know I might have to stay home one day with my sick child,\" says Phyllis Dunham, 27, a psychology major at the University of Florida. \"Younger students seem to wait until the last minute and have to have an extension for this reason or that.\" A few teachers even find their older students intimidating. \"If you're in your early 30's with a fresh PhD. and a lot of book knowledge, it's rather threatening to be teaching someone who's been working in your field for years and is questioning your theories,\" says Arthur Chickering, director of the Center for the Study of Higher Education at Memphis State University.\n3. But more often than not it is the adult students who are insecure. Friends and family may not like or understand their new status. Jean Byrd, 46, a Hood sophomore says, returning to school at first created some friction with her 12-year-old daughter. \"She resented it because my grades were better than hers.\" Younger classmates aren't always friendly either. \"My first couple of years it was, like, what are these women doing here?\" says a young Hood junior. \"I'm in college. I thought I left my mother at home.\" The sense of alienation is heightened at places like Florida, which is still very much geared toward youngsters though about one-fifth of its students are older. \"They're putting a strain on the place because we're not used to dealing with them,\" confesses Mike Rollo, assistant dean for student services.\n4. The feeling can be mutual. \"In the beginning I felt very old,\" says Juliet Margolin, 28, a Florida pre-vet student who lived in a dorm for three months and felt \"like a counselor in a sleep-away camp.\" Appalled by ketchup in the showers and jelly on the mirrors in the communal bathroom, Margolin soon found a roommate of her own age and moved off campus. Kate Erickson, a 35-year-old English major at Rice University, says she is so out of place that she is trying to organize older students into a group she might call \"Anachronisms Anonymous.\" At Hood, Dixie Miller has set up a hide-away cottage for her continuing-ed students a place she says, \"to meet somebody else who is gray and grumpy.\"\n\nSource: Reading and Study Skills (Second Edition)"
    ],
    "images": [],
    "choices": [
      {
        "id": 2505,
        "content": [
          "Younger girls embarrass older women calling them 'mothers'."
        ],
        "isCorrect": false
      },
      {
        "id": 2506,
        "content": [
          "Older students feel so unfit to the context."
        ],
        "isCorrect": false
      },
      {
        "id": 2507,
        "content": [
          "Older students account for only about one-fifth of the student community."
        ],
        "isCorrect": false
      },
      {
        "id": 2508,
        "content": [
          "The University administration is new to handling older students."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 628,
    "content": [
      "**Passage**: Grown-ups On Campus",
      "---",
      "\"I thought I left my mother at home\" (Paragraph 3). **MY MOTHER** in this sentence refers to"
    ],
    "explanation": [
      "The quote \"I thought I left my mother at home\" comes from a young Hood junior who is expressing the sentiment that older, female students don't belong in college.\n\nThe speaker is implying that these older women should be at home fulfilling a maternal role rather than being classmates."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 18,
    "groupIndex": null,
    "sharedContentId": 4,
    "sharedContent": [
      "## Grown-ups on Campus\n\n1. Many professors enjoy teaching adults because they frequently work harder and have a better idea of what they want out of school than their younger classmates. \"A lot of young people who come in here at 18 don't have the foggiest notion of why they're here,\" says Art Gallaher, vice president of academic affairs at the University of Kentucky.\n2. The adults tend to be better prepared, too. Because they went to high school at a time when learning how to write was considered more important than advanced student leadership, their compositions have fewer errors in syntax, grammar and spelling than the essays of some of today's brightest undergraduates. And older students usually get their work in on time. \"I'm going to get the assignment done because I know I might have to stay home one day with my sick child,\" says Phyllis Dunham, 27, a psychology major at the University of Florida. \"Younger students seem to wait until the last minute and have to have an extension for this reason or that.\" A few teachers even find their older students intimidating. \"If you're in your early 30's with a fresh PhD. and a lot of book knowledge, it's rather threatening to be teaching someone who's been working in your field for years and is questioning your theories,\" says Arthur Chickering, director of the Center for the Study of Higher Education at Memphis State University.\n3. But more often than not it is the adult students who are insecure. Friends and family may not like or understand their new status. Jean Byrd, 46, a Hood sophomore says, returning to school at first created some friction with her 12-year-old daughter. \"She resented it because my grades were better than hers.\" Younger classmates aren't always friendly either. \"My first couple of years it was, like, what are these women doing here?\" says a young Hood junior. \"I'm in college. I thought I left my mother at home.\" The sense of alienation is heightened at places like Florida, which is still very much geared toward youngsters though about one-fifth of its students are older. \"They're putting a strain on the place because we're not used to dealing with them,\" confesses Mike Rollo, assistant dean for student services.\n4. The feeling can be mutual. \"In the beginning I felt very old,\" says Juliet Margolin, 28, a Florida pre-vet student who lived in a dorm for three months and felt \"like a counselor in a sleep-away camp.\" Appalled by ketchup in the showers and jelly on the mirrors in the communal bathroom, Margolin soon found a roommate of her own age and moved off campus. Kate Erickson, a 35-year-old English major at Rice University, says she is so out of place that she is trying to organize older students into a group she might call \"Anachronisms Anonymous.\" At Hood, Dixie Miller has set up a hide-away cottage for her continuing-ed students a place she says, \"to meet somebody else who is gray and grumpy.\"\n\nSource: Reading and Study Skills (Second Edition)"
    ],
    "images": [],
    "choices": [
      {
        "id": 2509,
        "content": [
          "The speaker's mom"
        ],
        "isCorrect": false
      },
      {
        "id": 2510,
        "content": [
          "Women classmates"
        ],
        "isCorrect": false
      },
      {
        "id": 2511,
        "content": [
          "Older women in the group"
        ],
        "isCorrect": true
      },
      {
        "id": 2512,
        "content": [
          "Elderly women on campus"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 629,
    "content": [
      "**Passage**: Grown-ups On Campus",
      "---",
      "What does \"The feeling can be mutual\" mean (Paragraph 4)?"
    ],
    "explanation": [
      "Paragraph 3 describes how adult students feel insecure or alienated due \nto younger classmates' unfriendliness and institutional challenges. \n\nParagraph 4 then shifts to show that **adult students also find it difficult to coexist with younger students**, as illustrated by examples like Juliet Margolin’s frustration with dorm\n life and Kate Erickson’s effort to create a group for older students."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 18,
    "groupIndex": null,
    "sharedContentId": 4,
    "sharedContent": [
      "## Grown-ups on Campus\n\n1. Many professors enjoy teaching adults because they frequently work harder and have a better idea of what they want out of school than their younger classmates. \"A lot of young people who come in here at 18 don't have the foggiest notion of why they're here,\" says Art Gallaher, vice president of academic affairs at the University of Kentucky.\n2. The adults tend to be better prepared, too. Because they went to high school at a time when learning how to write was considered more important than advanced student leadership, their compositions have fewer errors in syntax, grammar and spelling than the essays of some of today's brightest undergraduates. And older students usually get their work in on time. \"I'm going to get the assignment done because I know I might have to stay home one day with my sick child,\" says Phyllis Dunham, 27, a psychology major at the University of Florida. \"Younger students seem to wait until the last minute and have to have an extension for this reason or that.\" A few teachers even find their older students intimidating. \"If you're in your early 30's with a fresh PhD. and a lot of book knowledge, it's rather threatening to be teaching someone who's been working in your field for years and is questioning your theories,\" says Arthur Chickering, director of the Center for the Study of Higher Education at Memphis State University.\n3. But more often than not it is the adult students who are insecure. Friends and family may not like or understand their new status. Jean Byrd, 46, a Hood sophomore says, returning to school at first created some friction with her 12-year-old daughter. \"She resented it because my grades were better than hers.\" Younger classmates aren't always friendly either. \"My first couple of years it was, like, what are these women doing here?\" says a young Hood junior. \"I'm in college. I thought I left my mother at home.\" The sense of alienation is heightened at places like Florida, which is still very much geared toward youngsters though about one-fifth of its students are older. \"They're putting a strain on the place because we're not used to dealing with them,\" confesses Mike Rollo, assistant dean for student services.\n4. The feeling can be mutual. \"In the beginning I felt very old,\" says Juliet Margolin, 28, a Florida pre-vet student who lived in a dorm for three months and felt \"like a counselor in a sleep-away camp.\" Appalled by ketchup in the showers and jelly on the mirrors in the communal bathroom, Margolin soon found a roommate of her own age and moved off campus. Kate Erickson, a 35-year-old English major at Rice University, says she is so out of place that she is trying to organize older students into a group she might call \"Anachronisms Anonymous.\" At Hood, Dixie Miller has set up a hide-away cottage for her continuing-ed students a place she says, \"to meet somebody else who is gray and grumpy.\"\n\nSource: Reading and Study Skills (Second Edition)"
    ],
    "images": [],
    "choices": [
      {
        "id": 2513,
        "content": [
          "Both the grownups and their roommates feel the same way."
        ],
        "isCorrect": false
      },
      {
        "id": 2514,
        "content": [
          "Both groups think it is hard to live with the other."
        ],
        "isCorrect": true
      },
      {
        "id": 2515,
        "content": [
          "Both the university and the youngsters think those grownups are unfit."
        ],
        "isCorrect": false
      },
      {
        "id": 2516,
        "content": [
          "Both the university and the youngsters think the grownups are old."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 630,
    "content": [
      "**Passage**: Grown-ups On Campus",
      "---",
      "\"... because we're not used to dealing with them\" (Paragraph 3). What does the word **THEM** refer to?"
    ],
    "explanation": [
      "The paragraph discusses challenges faced by adult students (e.g., family friction, alienation from younger classmates). It specifically mentions that universities like Florida are \"geared toward youngsters\" but have older students (about one-fifth of the population)."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 18,
    "groupIndex": null,
    "sharedContentId": 4,
    "sharedContent": [
      "## Grown-ups on Campus\n\n1. Many professors enjoy teaching adults because they frequently work harder and have a better idea of what they want out of school than their younger classmates. \"A lot of young people who come in here at 18 don't have the foggiest notion of why they're here,\" says Art Gallaher, vice president of academic affairs at the University of Kentucky.\n2. The adults tend to be better prepared, too. Because they went to high school at a time when learning how to write was considered more important than advanced student leadership, their compositions have fewer errors in syntax, grammar and spelling than the essays of some of today's brightest undergraduates. And older students usually get their work in on time. \"I'm going to get the assignment done because I know I might have to stay home one day with my sick child,\" says Phyllis Dunham, 27, a psychology major at the University of Florida. \"Younger students seem to wait until the last minute and have to have an extension for this reason or that.\" A few teachers even find their older students intimidating. \"If you're in your early 30's with a fresh PhD. and a lot of book knowledge, it's rather threatening to be teaching someone who's been working in your field for years and is questioning your theories,\" says Arthur Chickering, director of the Center for the Study of Higher Education at Memphis State University.\n3. But more often than not it is the adult students who are insecure. Friends and family may not like or understand their new status. Jean Byrd, 46, a Hood sophomore says, returning to school at first created some friction with her 12-year-old daughter. \"She resented it because my grades were better than hers.\" Younger classmates aren't always friendly either. \"My first couple of years it was, like, what are these women doing here?\" says a young Hood junior. \"I'm in college. I thought I left my mother at home.\" The sense of alienation is heightened at places like Florida, which is still very much geared toward youngsters though about one-fifth of its students are older. \"They're putting a strain on the place because we're not used to dealing with them,\" confesses Mike Rollo, assistant dean for student services.\n4. The feeling can be mutual. \"In the beginning I felt very old,\" says Juliet Margolin, 28, a Florida pre-vet student who lived in a dorm for three months and felt \"like a counselor in a sleep-away camp.\" Appalled by ketchup in the showers and jelly on the mirrors in the communal bathroom, Margolin soon found a roommate of her own age and moved off campus. Kate Erickson, a 35-year-old English major at Rice University, says she is so out of place that she is trying to organize older students into a group she might call \"Anachronisms Anonymous.\" At Hood, Dixie Miller has set up a hide-away cottage for her continuing-ed students a place she says, \"to meet somebody else who is gray and grumpy.\"\n\nSource: Reading and Study Skills (Second Edition)"
    ],
    "images": [],
    "choices": [
      {
        "id": 2517,
        "content": [
          "Younger students"
        ],
        "isCorrect": false
      },
      {
        "id": 2518,
        "content": [
          "Older students"
        ],
        "isCorrect": true
      },
      {
        "id": 2519,
        "content": [
          "The student community"
        ],
        "isCorrect": false
      },
      {
        "id": 2520,
        "content": [
          "Places like Florida"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 631,
    "content": [
      "**Passage**: Grown-ups On Campus",
      "---",
      "What is the central idea of the last paragraph?"
    ],
    "explanation": [
      "The central idea of the last paragraph focuses on **the challenges of integrating older and younger students in a university environment**."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 18,
    "groupIndex": null,
    "sharedContentId": 4,
    "sharedContent": [
      "## Grown-ups on Campus\n\n1. Many professors enjoy teaching adults because they frequently work harder and have a better idea of what they want out of school than their younger classmates. \"A lot of young people who come in here at 18 don't have the foggiest notion of why they're here,\" says Art Gallaher, vice president of academic affairs at the University of Kentucky.\n2. The adults tend to be better prepared, too. Because they went to high school at a time when learning how to write was considered more important than advanced student leadership, their compositions have fewer errors in syntax, grammar and spelling than the essays of some of today's brightest undergraduates. And older students usually get their work in on time. \"I'm going to get the assignment done because I know I might have to stay home one day with my sick child,\" says Phyllis Dunham, 27, a psychology major at the University of Florida. \"Younger students seem to wait until the last minute and have to have an extension for this reason or that.\" A few teachers even find their older students intimidating. \"If you're in your early 30's with a fresh PhD. and a lot of book knowledge, it's rather threatening to be teaching someone who's been working in your field for years and is questioning your theories,\" says Arthur Chickering, director of the Center for the Study of Higher Education at Memphis State University.\n3. But more often than not it is the adult students who are insecure. Friends and family may not like or understand their new status. Jean Byrd, 46, a Hood sophomore says, returning to school at first created some friction with her 12-year-old daughter. \"She resented it because my grades were better than hers.\" Younger classmates aren't always friendly either. \"My first couple of years it was, like, what are these women doing here?\" says a young Hood junior. \"I'm in college. I thought I left my mother at home.\" The sense of alienation is heightened at places like Florida, which is still very much geared toward youngsters though about one-fifth of its students are older. \"They're putting a strain on the place because we're not used to dealing with them,\" confesses Mike Rollo, assistant dean for student services.\n4. The feeling can be mutual. \"In the beginning I felt very old,\" says Juliet Margolin, 28, a Florida pre-vet student who lived in a dorm for three months and felt \"like a counselor in a sleep-away camp.\" Appalled by ketchup in the showers and jelly on the mirrors in the communal bathroom, Margolin soon found a roommate of her own age and moved off campus. Kate Erickson, a 35-year-old English major at Rice University, says she is so out of place that she is trying to organize older students into a group she might call \"Anachronisms Anonymous.\" At Hood, Dixie Miller has set up a hide-away cottage for her continuing-ed students a place she says, \"to meet somebody else who is gray and grumpy.\"\n\nSource: Reading and Study Skills (Second Edition)"
    ],
    "images": [],
    "choices": [
      {
        "id": 2521,
        "content": [
          "Youngsters do not like to see older students on university campus."
        ],
        "isCorrect": false
      },
      {
        "id": 2522,
        "content": [
          "It is not very wise for older students to go back to university."
        ],
        "isCorrect": false
      },
      {
        "id": 2523,
        "content": [
          "University is a place where distinctions should not be made because of age."
        ],
        "isCorrect": false
      },
      {
        "id": 2524,
        "content": [
          "It is very hard to have young and old students together in a university."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 632,
    "content": [
      "**Passage**: Grown-ups On Campus",
      "---",
      "Why did Juliet Margolin eventually decide to evacuate her dorm?"
    ],
    "explanation": [
      "Juliet Margolin, a 28-year-old pre-vet student, decided to move out of her dorm because she was \"appalled by ketchup in the showers and jelly on the mirrors in the communal bathroom\". She felt very old and described her experience as feeling \"like a counselor in a sleep-away camp\". Therefore, she found a roommate of her own age and moved off campus."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 18,
    "groupIndex": null,
    "sharedContentId": 4,
    "sharedContent": [
      "## Grown-ups on Campus\n\n1. Many professors enjoy teaching adults because they frequently work harder and have a better idea of what they want out of school than their younger classmates. \"A lot of young people who come in here at 18 don't have the foggiest notion of why they're here,\" says Art Gallaher, vice president of academic affairs at the University of Kentucky.\n2. The adults tend to be better prepared, too. Because they went to high school at a time when learning how to write was considered more important than advanced student leadership, their compositions have fewer errors in syntax, grammar and spelling than the essays of some of today's brightest undergraduates. And older students usually get their work in on time. \"I'm going to get the assignment done because I know I might have to stay home one day with my sick child,\" says Phyllis Dunham, 27, a psychology major at the University of Florida. \"Younger students seem to wait until the last minute and have to have an extension for this reason or that.\" A few teachers even find their older students intimidating. \"If you're in your early 30's with a fresh PhD. and a lot of book knowledge, it's rather threatening to be teaching someone who's been working in your field for years and is questioning your theories,\" says Arthur Chickering, director of the Center for the Study of Higher Education at Memphis State University.\n3. But more often than not it is the adult students who are insecure. Friends and family may not like or understand their new status. Jean Byrd, 46, a Hood sophomore says, returning to school at first created some friction with her 12-year-old daughter. \"She resented it because my grades were better than hers.\" Younger classmates aren't always friendly either. \"My first couple of years it was, like, what are these women doing here?\" says a young Hood junior. \"I'm in college. I thought I left my mother at home.\" The sense of alienation is heightened at places like Florida, which is still very much geared toward youngsters though about one-fifth of its students are older. \"They're putting a strain on the place because we're not used to dealing with them,\" confesses Mike Rollo, assistant dean for student services.\n4. The feeling can be mutual. \"In the beginning I felt very old,\" says Juliet Margolin, 28, a Florida pre-vet student who lived in a dorm for three months and felt \"like a counselor in a sleep-away camp.\" Appalled by ketchup in the showers and jelly on the mirrors in the communal bathroom, Margolin soon found a roommate of her own age and moved off campus. Kate Erickson, a 35-year-old English major at Rice University, says she is so out of place that she is trying to organize older students into a group she might call \"Anachronisms Anonymous.\" At Hood, Dixie Miller has set up a hide-away cottage for her continuing-ed students a place she says, \"to meet somebody else who is gray and grumpy.\"\n\nSource: Reading and Study Skills (Second Edition)"
    ],
    "images": [],
    "choices": [
      {
        "id": 2525,
        "content": [
          "She wanted to live with someone more matured."
        ],
        "isCorrect": false
      },
      {
        "id": 2526,
        "content": [
          "The little dorm mates made her feels very old."
        ],
        "isCorrect": false
      },
      {
        "id": 2527,
        "content": [
          "She didn't like the ketch up her dorm mates were using."
        ],
        "isCorrect": false
      },
      {
        "id": 2528,
        "content": [
          "She couldn't bear the way her dorm mates behaved."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 633,
    "content": [
      "**Passage**: Grown-ups On Campus",
      "---",
      "Why do adult learners writing better than some of the best younger students?"
    ],
    "explanation": [
      "The passage states that adult learners went to high school \"at a time when learning how to write was considered more important than advanced student leadership.\" This directly supports option “Because during their days, the system had given more emphasis to writing.”"
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 18,
    "groupIndex": null,
    "sharedContentId": 4,
    "sharedContent": [
      "## Grown-ups on Campus\n\n1. Many professors enjoy teaching adults because they frequently work harder and have a better idea of what they want out of school than their younger classmates. \"A lot of young people who come in here at 18 don't have the foggiest notion of why they're here,\" says Art Gallaher, vice president of academic affairs at the University of Kentucky.\n2. The adults tend to be better prepared, too. Because they went to high school at a time when learning how to write was considered more important than advanced student leadership, their compositions have fewer errors in syntax, grammar and spelling than the essays of some of today's brightest undergraduates. And older students usually get their work in on time. \"I'm going to get the assignment done because I know I might have to stay home one day with my sick child,\" says Phyllis Dunham, 27, a psychology major at the University of Florida. \"Younger students seem to wait until the last minute and have to have an extension for this reason or that.\" A few teachers even find their older students intimidating. \"If you're in your early 30's with a fresh PhD. and a lot of book knowledge, it's rather threatening to be teaching someone who's been working in your field for years and is questioning your theories,\" says Arthur Chickering, director of the Center for the Study of Higher Education at Memphis State University.\n3. But more often than not it is the adult students who are insecure. Friends and family may not like or understand their new status. Jean Byrd, 46, a Hood sophomore says, returning to school at first created some friction with her 12-year-old daughter. \"She resented it because my grades were better than hers.\" Younger classmates aren't always friendly either. \"My first couple of years it was, like, what are these women doing here?\" says a young Hood junior. \"I'm in college. I thought I left my mother at home.\" The sense of alienation is heightened at places like Florida, which is still very much geared toward youngsters though about one-fifth of its students are older. \"They're putting a strain on the place because we're not used to dealing with them,\" confesses Mike Rollo, assistant dean for student services.\n4. The feeling can be mutual. \"In the beginning I felt very old,\" says Juliet Margolin, 28, a Florida pre-vet student who lived in a dorm for three months and felt \"like a counselor in a sleep-away camp.\" Appalled by ketchup in the showers and jelly on the mirrors in the communal bathroom, Margolin soon found a roommate of her own age and moved off campus. Kate Erickson, a 35-year-old English major at Rice University, says she is so out of place that she is trying to organize older students into a group she might call \"Anachronisms Anonymous.\" At Hood, Dixie Miller has set up a hide-away cottage for her continuing-ed students a place she says, \"to meet somebody else who is gray and grumpy.\"\n\nSource: Reading and Study Skills (Second Edition)"
    ],
    "images": [],
    "choices": [
      {
        "id": 2529,
        "content": [
          "Because their teachers preferred teaching writing to the other skills."
        ],
        "isCorrect": false
      },
      {
        "id": 2530,
        "content": [
          "Because they liked writing more than they did the other skills."
        ],
        "isCorrect": false
      },
      {
        "id": 2531,
        "content": [
          "Because during their days, the system had given more emphasis to writing."
        ],
        "isCorrect": true
      },
      {
        "id": 2532,
        "content": [
          "Because today's students attach more importance to leadership only."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 634,
    "content": [
      "**Passage**: Grown-ups On Campus",
      "---",
      "Why do university professors prefer teaching adults to teaching young people?"
    ],
    "explanation": [
      "The first sentence of the passage directly states that professors enjoy teaching adults because they \"frequently work harder and have a better idea of what they want out of school than their younger classmates.\n\nHaving \"a better idea of what they want out of school\" equates to having a clear purpose.\n\nNote: We changed the original option in the question paper: “Adults work much harder than their younger counterparts.” to “Adults work much less harder than their younger counterparts.” in order to have a clear answer."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 18,
    "groupIndex": null,
    "sharedContentId": 4,
    "sharedContent": [
      "## Grown-ups on Campus\n\n1. Many professors enjoy teaching adults because they frequently work harder and have a better idea of what they want out of school than their younger classmates. \"A lot of young people who come in here at 18 don't have the foggiest notion of why they're here,\" says Art Gallaher, vice president of academic affairs at the University of Kentucky.\n2. The adults tend to be better prepared, too. Because they went to high school at a time when learning how to write was considered more important than advanced student leadership, their compositions have fewer errors in syntax, grammar and spelling than the essays of some of today's brightest undergraduates. And older students usually get their work in on time. \"I'm going to get the assignment done because I know I might have to stay home one day with my sick child,\" says Phyllis Dunham, 27, a psychology major at the University of Florida. \"Younger students seem to wait until the last minute and have to have an extension for this reason or that.\" A few teachers even find their older students intimidating. \"If you're in your early 30's with a fresh PhD. and a lot of book knowledge, it's rather threatening to be teaching someone who's been working in your field for years and is questioning your theories,\" says Arthur Chickering, director of the Center for the Study of Higher Education at Memphis State University.\n3. But more often than not it is the adult students who are insecure. Friends and family may not like or understand their new status. Jean Byrd, 46, a Hood sophomore says, returning to school at first created some friction with her 12-year-old daughter. \"She resented it because my grades were better than hers.\" Younger classmates aren't always friendly either. \"My first couple of years it was, like, what are these women doing here?\" says a young Hood junior. \"I'm in college. I thought I left my mother at home.\" The sense of alienation is heightened at places like Florida, which is still very much geared toward youngsters though about one-fifth of its students are older. \"They're putting a strain on the place because we're not used to dealing with them,\" confesses Mike Rollo, assistant dean for student services.\n4. The feeling can be mutual. \"In the beginning I felt very old,\" says Juliet Margolin, 28, a Florida pre-vet student who lived in a dorm for three months and felt \"like a counselor in a sleep-away camp.\" Appalled by ketchup in the showers and jelly on the mirrors in the communal bathroom, Margolin soon found a roommate of her own age and moved off campus. Kate Erickson, a 35-year-old English major at Rice University, says she is so out of place that she is trying to organize older students into a group she might call \"Anachronisms Anonymous.\" At Hood, Dixie Miller has set up a hide-away cottage for her continuing-ed students a place she says, \"to meet somebody else who is gray and grumpy.\"\n\nSource: Reading and Study Skills (Second Edition)"
    ],
    "images": [],
    "choices": [
      {
        "id": 2533,
        "content": [
          "Adult learners have a clear purpose for being on campus."
        ],
        "isCorrect": true
      },
      {
        "id": 2534,
        "content": [
          "Eighteen year-olds join universities with foggy notions."
        ],
        "isCorrect": false
      },
      {
        "id": 2535,
        "content": [
          "Adults work much less harder than their younger counterparts."
        ],
        "isCorrect": false
      },
      {
        "id": 2536,
        "content": [
          "Younger students are much more careless about their life."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 635,
    "content": [
      "**Passage**: Laziness or Dishonesty is Ruining Reputation",
      "---",
      "Which one of the following is NOT a possible cause of cheating?"
    ],
    "explanation": [
      "The passage states that a **lack of recognition of plagiarism** is a cause of cheating, not the recognition of it."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 19,
    "groupIndex": null,
    "sharedContentId": 5,
    "sharedContent": [
      "## Laziness or Dishonesty is Ruining Reputation\n\n1. A study by the Center for Academic Integrity found that almost 80% of college students admit to cheating at least once, while this is between 75% and 98% of high school students. You might not believe this, but the statistics of 2018 show that. Although, it is not astonishing news when there are fears of failing, desires to get better grades, poor time management, or a lack of recognition of plagiarism among students.\n2. Also, there is another kind of plagiarism that is stealing other's quotes, arts, recipes, and ideas without mentioning the name of the owner, and it is non-academic plagiarism. There are some similarities between academic and non-academic plagiarism, particularly, in motivations or reasons, methods, and effects. In academic plagiarism, students have reasons and methods to cheat and obviously, they will result in negative effects. Plagiarism in academic situations is nothing new, and there has been a high percentage of college students and high schools' who have plagiarized for several years. The most important reason should be getting better grades without enough effort, due to laziness or lack of talent, confidence, and knowledge to stand on their own feet. Most cheaters would like to have a fun social life so; they don't spend time studying as much as they should.\n3. Students steal others' research, ideas, and statistics, and use other students' lab reports and fake signatures on official documents for their financial aid applications. Ultimately, the consequence shows that most of the cheaters get disciplinary actions, alerts, and notifications. They can be removed from all classes for one or more terms, and this affects the student's ability to attend graduate schools and will be noted on their academic transcript. On the other hand, hold and pending may be placed on students' records, and the record will be kept for a minimum of five years. And the worst result of that trauma and shock is the psychological and mental impact on them which remains for years. However, all the sanctions and policies are to protect the safety and integrity of the university community, and to learn the students, new behaviors.\n4. Non-academic plagiarism is similar to academics in terms of motivation, methods, and effects. For instance, the pressure and fear could be the motivations for the politicians to plagiarize, because it would be a safer way to steal a confirmed presentation. On the other hand, other reasons would be lack of preparation, or confusion. The same as academics, the politicians repost some sentences in their speeches or books without mentioning the name of origin, and without respecting the real author and mentioning her/his name. As a matter of fact, the result will be losing their reputation, trust, dignity, expulsion, losing their positions, quitting their job, getting impeached, just like the college students when be caught of plagiarism.\n5. In summary, the main similarity between academic and non-academic plagiarism should be the personal, professional, ethical, and legal consequences. If in academics, plagiarism causes a student to be suspended, the same can cause to a politician to be impeached. In the case where a journalist works for a magazine, newspaper or other publishers, or even a student is found plagiarizing in school, the offending plagiarist could have to pay monetary penalties. Both types mean a destroyed reputation and the end of the academic position. Following as a result, laziness or dishonesty can lead to ruined reputation, the loss of a career, and legal problems.\n\nAccessed and adapter on 20 March 2023 from https://www.kqed.org/mind"
    ],
    "images": [],
    "choices": [
      {
        "id": 2537,
        "content": [
          "Lack of awareness that cheating is wrong."
        ],
        "isCorrect": false
      },
      {
        "id": 2538,
        "content": [
          "The fear to fail in a test one is taking."
        ],
        "isCorrect": false
      },
      {
        "id": 2539,
        "content": [
          "Recognition of the role of plagiarism."
        ],
        "isCorrect": true
      },
      {
        "id": 2540,
        "content": [
          "The interest to score good grades."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 636,
    "content": [
      "**Passage**: Laziness or Dishonesty is Ruining Reputation",
      "---",
      "According to paragraph one, which one of the following is true about cheating?"
    ],
    "explanation": [
      "Paragraph 1 states: \"You might not believe this, but the statistics of 2018 show that... almost 80% of college students admit to cheating at least once, while this is between 75% and 98% of high school students.\" This directly supports the idea that cheating was very common among students based on 2018 statistics."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 19,
    "groupIndex": null,
    "sharedContentId": 5,
    "sharedContent": [
      "## Laziness or Dishonesty is Ruining Reputation\n\n1. A study by the Center for Academic Integrity found that almost 80% of college students admit to cheating at least once, while this is between 75% and 98% of high school students. You might not believe this, but the statistics of 2018 show that. Although, it is not astonishing news when there are fears of failing, desires to get better grades, poor time management, or a lack of recognition of plagiarism among students.\n2. Also, there is another kind of plagiarism that is stealing other's quotes, arts, recipes, and ideas without mentioning the name of the owner, and it is non-academic plagiarism. There are some similarities between academic and non-academic plagiarism, particularly, in motivations or reasons, methods, and effects. In academic plagiarism, students have reasons and methods to cheat and obviously, they will result in negative effects. Plagiarism in academic situations is nothing new, and there has been a high percentage of college students and high schools' who have plagiarized for several years. The most important reason should be getting better grades without enough effort, due to laziness or lack of talent, confidence, and knowledge to stand on their own feet. Most cheaters would like to have a fun social life so; they don't spend time studying as much as they should.\n3. Students steal others' research, ideas, and statistics, and use other students' lab reports and fake signatures on official documents for their financial aid applications. Ultimately, the consequence shows that most of the cheaters get disciplinary actions, alerts, and notifications. They can be removed from all classes for one or more terms, and this affects the student's ability to attend graduate schools and will be noted on their academic transcript. On the other hand, hold and pending may be placed on students' records, and the record will be kept for a minimum of five years. And the worst result of that trauma and shock is the psychological and mental impact on them which remains for years. However, all the sanctions and policies are to protect the safety and integrity of the university community, and to learn the students, new behaviors.\n4. Non-academic plagiarism is similar to academics in terms of motivation, methods, and effects. For instance, the pressure and fear could be the motivations for the politicians to plagiarize, because it would be a safer way to steal a confirmed presentation. On the other hand, other reasons would be lack of preparation, or confusion. The same as academics, the politicians repost some sentences in their speeches or books without mentioning the name of origin, and without respecting the real author and mentioning her/his name. As a matter of fact, the result will be losing their reputation, trust, dignity, expulsion, losing their positions, quitting their job, getting impeached, just like the college students when be caught of plagiarism.\n5. In summary, the main similarity between academic and non-academic plagiarism should be the personal, professional, ethical, and legal consequences. If in academics, plagiarism causes a student to be suspended, the same can cause to a politician to be impeached. In the case where a journalist works for a magazine, newspaper or other publishers, or even a student is found plagiarizing in school, the offending plagiarist could have to pay monetary penalties. Both types mean a destroyed reputation and the end of the academic position. Following as a result, laziness or dishonesty can lead to ruined reputation, the loss of a career, and legal problems.\n\nAccessed and adapter on 20 March 2023 from https://www.kqed.org/mind"
    ],
    "images": [],
    "choices": [
      {
        "id": 2541,
        "content": [
          "Recently, cheating has become part of every student's life in the US."
        ],
        "isCorrect": false
      },
      {
        "id": 2542,
        "content": [
          "Almost 80% of college students in the US cheat in their exams."
        ],
        "isCorrect": false
      },
      {
        "id": 2543,
        "content": [
          "Cheating is more severe among university students than high school students."
        ],
        "isCorrect": false
      },
      {
        "id": 2544,
        "content": [
          "The statistics of 2018 show that cheating is very common among students."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 637,
    "content": [
      "**Passage**: Laziness or Dishonesty is Ruining Reputation",
      "---",
      "What do you think is the most important reason behind secondary school leavers’ attempt to plagiarize in this exam?"
    ],
    "explanation": [
      "The paragraph 2 highlights that the primary motivation behind plagiarism, both academic and non-academic, is the desire to achieve better results with minimal effort, making the desire for good grades the primary motivation for plagiarism.\n\nOther factors like laziness or lack of confidence are secondary."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 19,
    "groupIndex": null,
    "sharedContentId": 5,
    "sharedContent": [
      "## Laziness or Dishonesty is Ruining Reputation\n\n1. A study by the Center for Academic Integrity found that almost 80% of college students admit to cheating at least once, while this is between 75% and 98% of high school students. You might not believe this, but the statistics of 2018 show that. Although, it is not astonishing news when there are fears of failing, desires to get better grades, poor time management, or a lack of recognition of plagiarism among students.\n2. Also, there is another kind of plagiarism that is stealing other's quotes, arts, recipes, and ideas without mentioning the name of the owner, and it is non-academic plagiarism. There are some similarities between academic and non-academic plagiarism, particularly, in motivations or reasons, methods, and effects. In academic plagiarism, students have reasons and methods to cheat and obviously, they will result in negative effects. Plagiarism in academic situations is nothing new, and there has been a high percentage of college students and high schools' who have plagiarized for several years. The most important reason should be getting better grades without enough effort, due to laziness or lack of talent, confidence, and knowledge to stand on their own feet. Most cheaters would like to have a fun social life so; they don't spend time studying as much as they should.\n3. Students steal others' research, ideas, and statistics, and use other students' lab reports and fake signatures on official documents for their financial aid applications. Ultimately, the consequence shows that most of the cheaters get disciplinary actions, alerts, and notifications. They can be removed from all classes for one or more terms, and this affects the student's ability to attend graduate schools and will be noted on their academic transcript. On the other hand, hold and pending may be placed on students' records, and the record will be kept for a minimum of five years. And the worst result of that trauma and shock is the psychological and mental impact on them which remains for years. However, all the sanctions and policies are to protect the safety and integrity of the university community, and to learn the students, new behaviors.\n4. Non-academic plagiarism is similar to academics in terms of motivation, methods, and effects. For instance, the pressure and fear could be the motivations for the politicians to plagiarize, because it would be a safer way to steal a confirmed presentation. On the other hand, other reasons would be lack of preparation, or confusion. The same as academics, the politicians repost some sentences in their speeches or books without mentioning the name of origin, and without respecting the real author and mentioning her/his name. As a matter of fact, the result will be losing their reputation, trust, dignity, expulsion, losing their positions, quitting their job, getting impeached, just like the college students when be caught of plagiarism.\n5. In summary, the main similarity between academic and non-academic plagiarism should be the personal, professional, ethical, and legal consequences. If in academics, plagiarism causes a student to be suspended, the same can cause to a politician to be impeached. In the case where a journalist works for a magazine, newspaper or other publishers, or even a student is found plagiarizing in school, the offending plagiarist could have to pay monetary penalties. Both types mean a destroyed reputation and the end of the academic position. Following as a result, laziness or dishonesty can lead to ruined reputation, the loss of a career, and legal problems.\n\nAccessed and adapter on 20 March 2023 from https://www.kqed.org/mind"
    ],
    "images": [],
    "choices": [
      {
        "id": 2545,
        "content": [
          "Laziness and making little effort"
        ],
        "isCorrect": false
      },
      {
        "id": 2546,
        "content": [
          "Lack of self-confidence"
        ],
        "isCorrect": false
      },
      {
        "id": 2547,
        "content": [
          "The feeling of dependence on others"
        ],
        "isCorrect": false
      },
      {
        "id": 2548,
        "content": [
          "The interest to score good grades"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 638,
    "content": [
      "**Passage**: Laziness or Dishonesty is Ruining Reputation",
      "---",
      "Which one of the following is NOT among the similarities between academic and non-academic plagiarism (Paragraph 2)?"
    ],
    "explanation": [
      "Paragraph 2 states that academic and non-academic plagiarism share similarities in motivations, methods, and effects.\n\nHowever, the **actors** differ—academic plagiarism is committed by students, while non-academic plagiarism involves politicians, artists, or professionals."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 19,
    "groupIndex": null,
    "sharedContentId": 5,
    "sharedContent": [
      "## Laziness or Dishonesty is Ruining Reputation\n\n1. A study by the Center for Academic Integrity found that almost 80% of college students admit to cheating at least once, while this is between 75% and 98% of high school students. You might not believe this, but the statistics of 2018 show that. Although, it is not astonishing news when there are fears of failing, desires to get better grades, poor time management, or a lack of recognition of plagiarism among students.\n2. Also, there is another kind of plagiarism that is stealing other's quotes, arts, recipes, and ideas without mentioning the name of the owner, and it is non-academic plagiarism. There are some similarities between academic and non-academic plagiarism, particularly, in motivations or reasons, methods, and effects. In academic plagiarism, students have reasons and methods to cheat and obviously, they will result in negative effects. Plagiarism in academic situations is nothing new, and there has been a high percentage of college students and high schools' who have plagiarized for several years. The most important reason should be getting better grades without enough effort, due to laziness or lack of talent, confidence, and knowledge to stand on their own feet. Most cheaters would like to have a fun social life so; they don't spend time studying as much as they should.\n3. Students steal others' research, ideas, and statistics, and use other students' lab reports and fake signatures on official documents for their financial aid applications. Ultimately, the consequence shows that most of the cheaters get disciplinary actions, alerts, and notifications. They can be removed from all classes for one or more terms, and this affects the student's ability to attend graduate schools and will be noted on their academic transcript. On the other hand, hold and pending may be placed on students' records, and the record will be kept for a minimum of five years. And the worst result of that trauma and shock is the psychological and mental impact on them which remains for years. However, all the sanctions and policies are to protect the safety and integrity of the university community, and to learn the students, new behaviors.\n4. Non-academic plagiarism is similar to academics in terms of motivation, methods, and effects. For instance, the pressure and fear could be the motivations for the politicians to plagiarize, because it would be a safer way to steal a confirmed presentation. On the other hand, other reasons would be lack of preparation, or confusion. The same as academics, the politicians repost some sentences in their speeches or books without mentioning the name of origin, and without respecting the real author and mentioning her/his name. As a matter of fact, the result will be losing their reputation, trust, dignity, expulsion, losing their positions, quitting their job, getting impeached, just like the college students when be caught of plagiarism.\n5. In summary, the main similarity between academic and non-academic plagiarism should be the personal, professional, ethical, and legal consequences. If in academics, plagiarism causes a student to be suspended, the same can cause to a politician to be impeached. In the case where a journalist works for a magazine, newspaper or other publishers, or even a student is found plagiarizing in school, the offending plagiarist could have to pay monetary penalties. Both types mean a destroyed reputation and the end of the academic position. Following as a result, laziness or dishonesty can lead to ruined reputation, the loss of a career, and legal problems.\n\nAccessed and adapter on 20 March 2023 from https://www.kqed.org/mind"
    ],
    "images": [],
    "choices": [
      {
        "id": 2549,
        "content": [
          "The way the act is committed"
        ],
        "isCorrect": false
      },
      {
        "id": 2550,
        "content": [
          "The actors of plagiarism"
        ],
        "isCorrect": true
      },
      {
        "id": 2551,
        "content": [
          "The specific interest behind the act"
        ],
        "isCorrect": false
      },
      {
        "id": 2552,
        "content": [
          "The anticipated rewards of the act"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 639,
    "content": [
      "**Passage**: Laziness or Dishonesty is Ruining Reputation",
      "---",
      "Which one of the following, in your opinion, belongs to non-academic cheating?"
    ],
    "explanation": [
      "Non-academic cheating involves dishonesty outside the academic setting. Using fake signatures for financial aid applications is a form of fraud that does not directly relate to coursework or academic assessments, making it a non-academic act. ."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 19,
    "groupIndex": null,
    "sharedContentId": 5,
    "sharedContent": [
      "## Laziness or Dishonesty is Ruining Reputation\n\n1. A study by the Center for Academic Integrity found that almost 80% of college students admit to cheating at least once, while this is between 75% and 98% of high school students. You might not believe this, but the statistics of 2018 show that. Although, it is not astonishing news when there are fears of failing, desires to get better grades, poor time management, or a lack of recognition of plagiarism among students.\n2. Also, there is another kind of plagiarism that is stealing other's quotes, arts, recipes, and ideas without mentioning the name of the owner, and it is non-academic plagiarism. There are some similarities between academic and non-academic plagiarism, particularly, in motivations or reasons, methods, and effects. In academic plagiarism, students have reasons and methods to cheat and obviously, they will result in negative effects. Plagiarism in academic situations is nothing new, and there has been a high percentage of college students and high schools' who have plagiarized for several years. The most important reason should be getting better grades without enough effort, due to laziness or lack of talent, confidence, and knowledge to stand on their own feet. Most cheaters would like to have a fun social life so; they don't spend time studying as much as they should.\n3. Students steal others' research, ideas, and statistics, and use other students' lab reports and fake signatures on official documents for their financial aid applications. Ultimately, the consequence shows that most of the cheaters get disciplinary actions, alerts, and notifications. They can be removed from all classes for one or more terms, and this affects the student's ability to attend graduate schools and will be noted on their academic transcript. On the other hand, hold and pending may be placed on students' records, and the record will be kept for a minimum of five years. And the worst result of that trauma and shock is the psychological and mental impact on them which remains for years. However, all the sanctions and policies are to protect the safety and integrity of the university community, and to learn the students, new behaviors.\n4. Non-academic plagiarism is similar to academics in terms of motivation, methods, and effects. For instance, the pressure and fear could be the motivations for the politicians to plagiarize, because it would be a safer way to steal a confirmed presentation. On the other hand, other reasons would be lack of preparation, or confusion. The same as academics, the politicians repost some sentences in their speeches or books without mentioning the name of origin, and without respecting the real author and mentioning her/his name. As a matter of fact, the result will be losing their reputation, trust, dignity, expulsion, losing their positions, quitting their job, getting impeached, just like the college students when be caught of plagiarism.\n5. In summary, the main similarity between academic and non-academic plagiarism should be the personal, professional, ethical, and legal consequences. If in academics, plagiarism causes a student to be suspended, the same can cause to a politician to be impeached. In the case where a journalist works for a magazine, newspaper or other publishers, or even a student is found plagiarizing in school, the offending plagiarist could have to pay monetary penalties. Both types mean a destroyed reputation and the end of the academic position. Following as a result, laziness or dishonesty can lead to ruined reputation, the loss of a career, and legal problems.\n\nAccessed and adapter on 20 March 2023 from https://www.kqed.org/mind"
    ],
    "images": [],
    "choices": [
      {
        "id": 2553,
        "content": [
          "Using fake signatures in applications for financial aid"
        ],
        "isCorrect": true
      },
      {
        "id": 2554,
        "content": [
          "Using others' lab reports for submission in a course"
        ],
        "isCorrect": false
      },
      {
        "id": 2555,
        "content": [
          "Stealing others' research plans and designs to write a thesis"
        ],
        "isCorrect": false
      },
      {
        "id": 2556,
        "content": [
          "Taking other students' statistics for report in assignments"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 640,
    "content": [
      "**Passage**: Laziness or Dishonesty is Ruining Reputation",
      "---",
      "What does the word **THEY** in “... Obviously, **THEY** will result in negative effects” refer to (Paragraph 2)?"
    ],
    "explanation": [
      "In Paragraph 2, the sentence states: *\"In academic plagiarism, students have reasons and methods to cheat and obviously, they will result in negative effects.\"*\n\nHere, **\"they\"** refers to **\"reasons and methods\"**, as these are the subjects that lead to negative effects."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 19,
    "groupIndex": null,
    "sharedContentId": 5,
    "sharedContent": [
      "## Laziness or Dishonesty is Ruining Reputation\n\n1. A study by the Center for Academic Integrity found that almost 80% of college students admit to cheating at least once, while this is between 75% and 98% of high school students. You might not believe this, but the statistics of 2018 show that. Although, it is not astonishing news when there are fears of failing, desires to get better grades, poor time management, or a lack of recognition of plagiarism among students.\n2. Also, there is another kind of plagiarism that is stealing other's quotes, arts, recipes, and ideas without mentioning the name of the owner, and it is non-academic plagiarism. There are some similarities between academic and non-academic plagiarism, particularly, in motivations or reasons, methods, and effects. In academic plagiarism, students have reasons and methods to cheat and obviously, they will result in negative effects. Plagiarism in academic situations is nothing new, and there has been a high percentage of college students and high schools' who have plagiarized for several years. The most important reason should be getting better grades without enough effort, due to laziness or lack of talent, confidence, and knowledge to stand on their own feet. Most cheaters would like to have a fun social life so; they don't spend time studying as much as they should.\n3. Students steal others' research, ideas, and statistics, and use other students' lab reports and fake signatures on official documents for their financial aid applications. Ultimately, the consequence shows that most of the cheaters get disciplinary actions, alerts, and notifications. They can be removed from all classes for one or more terms, and this affects the student's ability to attend graduate schools and will be noted on their academic transcript. On the other hand, hold and pending may be placed on students' records, and the record will be kept for a minimum of five years. And the worst result of that trauma and shock is the psychological and mental impact on them which remains for years. However, all the sanctions and policies are to protect the safety and integrity of the university community, and to learn the students, new behaviors.\n4. Non-academic plagiarism is similar to academics in terms of motivation, methods, and effects. For instance, the pressure and fear could be the motivations for the politicians to plagiarize, because it would be a safer way to steal a confirmed presentation. On the other hand, other reasons would be lack of preparation, or confusion. The same as academics, the politicians repost some sentences in their speeches or books without mentioning the name of origin, and without respecting the real author and mentioning her/his name. As a matter of fact, the result will be losing their reputation, trust, dignity, expulsion, losing their positions, quitting their job, getting impeached, just like the college students when be caught of plagiarism.\n5. In summary, the main similarity between academic and non-academic plagiarism should be the personal, professional, ethical, and legal consequences. If in academics, plagiarism causes a student to be suspended, the same can cause to a politician to be impeached. In the case where a journalist works for a magazine, newspaper or other publishers, or even a student is found plagiarizing in school, the offending plagiarist could have to pay monetary penalties. Both types mean a destroyed reputation and the end of the academic position. Following as a result, laziness or dishonesty can lead to ruined reputation, the loss of a career, and legal problems.\n\nAccessed and adapter on 20 March 2023 from https://www.kqed.org/mind"
    ],
    "images": [],
    "choices": [
      {
        "id": 2557,
        "content": [
          "Students behind the act of cheating"
        ],
        "isCorrect": false
      },
      {
        "id": 2558,
        "content": [
          "Reasons and methods of cheating"
        ],
        "isCorrect": true
      },
      {
        "id": 2559,
        "content": [
          "Both academic and non-academic cheating"
        ],
        "isCorrect": false
      },
      {
        "id": 2560,
        "content": [
          "The way the act is committed"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 641,
    "content": [
      "**Passage**: Laziness or Dishonesty is Ruining Reputation",
      "---",
      "What is the main purpose of taking measures against cheaters in a university environment?"
    ],
    "explanation": [
      "The main purpose of taking measures against cheaters in a university environment is explicitly stated in paragraph 3: \"all the sanctions and policies are to protect the safety and integrity of the university community, and to learn the students, new behaviors.\"\n\nThis indicates that the primary goal is to protect the safety and integrity of the academic environment."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 19,
    "groupIndex": null,
    "sharedContentId": 5,
    "sharedContent": [
      "## Laziness or Dishonesty is Ruining Reputation\n\n1. A study by the Center for Academic Integrity found that almost 80% of college students admit to cheating at least once, while this is between 75% and 98% of high school students. You might not believe this, but the statistics of 2018 show that. Although, it is not astonishing news when there are fears of failing, desires to get better grades, poor time management, or a lack of recognition of plagiarism among students.\n2. Also, there is another kind of plagiarism that is stealing other's quotes, arts, recipes, and ideas without mentioning the name of the owner, and it is non-academic plagiarism. There are some similarities between academic and non-academic plagiarism, particularly, in motivations or reasons, methods, and effects. In academic plagiarism, students have reasons and methods to cheat and obviously, they will result in negative effects. Plagiarism in academic situations is nothing new, and there has been a high percentage of college students and high schools' who have plagiarized for several years. The most important reason should be getting better grades without enough effort, due to laziness or lack of talent, confidence, and knowledge to stand on their own feet. Most cheaters would like to have a fun social life so; they don't spend time studying as much as they should.\n3. Students steal others' research, ideas, and statistics, and use other students' lab reports and fake signatures on official documents for their financial aid applications. Ultimately, the consequence shows that most of the cheaters get disciplinary actions, alerts, and notifications. They can be removed from all classes for one or more terms, and this affects the student's ability to attend graduate schools and will be noted on their academic transcript. On the other hand, hold and pending may be placed on students' records, and the record will be kept for a minimum of five years. And the worst result of that trauma and shock is the psychological and mental impact on them which remains for years. However, all the sanctions and policies are to protect the safety and integrity of the university community, and to learn the students, new behaviors.\n4. Non-academic plagiarism is similar to academics in terms of motivation, methods, and effects. For instance, the pressure and fear could be the motivations for the politicians to plagiarize, because it would be a safer way to steal a confirmed presentation. On the other hand, other reasons would be lack of preparation, or confusion. The same as academics, the politicians repost some sentences in their speeches or books without mentioning the name of origin, and without respecting the real author and mentioning her/his name. As a matter of fact, the result will be losing their reputation, trust, dignity, expulsion, losing their positions, quitting their job, getting impeached, just like the college students when be caught of plagiarism.\n5. In summary, the main similarity between academic and non-academic plagiarism should be the personal, professional, ethical, and legal consequences. If in academics, plagiarism causes a student to be suspended, the same can cause to a politician to be impeached. In the case where a journalist works for a magazine, newspaper or other publishers, or even a student is found plagiarizing in school, the offending plagiarist could have to pay monetary penalties. Both types mean a destroyed reputation and the end of the academic position. Following as a result, laziness or dishonesty can lead to ruined reputation, the loss of a career, and legal problems.\n\nAccessed and adapter on 20 March 2023 from https://www.kqed.org/mind"
    ],
    "images": [],
    "choices": [
      {
        "id": 2561,
        "content": [
          "To safeguard the academic community"
        ],
        "isCorrect": true
      },
      {
        "id": 2562,
        "content": [
          "To discourage undeserved merits"
        ],
        "isCorrect": false
      },
      {
        "id": 2563,
        "content": [
          "To protect students' safety and integrity"
        ],
        "isCorrect": false
      },
      {
        "id": 2564,
        "content": [
          "To teach new behaviors to the cheaters"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 642,
    "content": [
      "**Passage**: Laziness or Dishonesty is Ruining Reputation",
      "---",
      "What, according to Paragraph 3, is the most undesirable consequence of academic cheating?"
    ],
    "explanation": [
      "Paragraph 3 describes several consequences of academic cheating, including disciplinary actions, academic suspensions, and records being kept for five years.\n\nHowever, it emphasizes that the **worst result** is the **psychological and mental impact** that lasts for years."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 19,
    "groupIndex": null,
    "sharedContentId": 5,
    "sharedContent": [
      "## Laziness or Dishonesty is Ruining Reputation\n\n1. A study by the Center for Academic Integrity found that almost 80% of college students admit to cheating at least once, while this is between 75% and 98% of high school students. You might not believe this, but the statistics of 2018 show that. Although, it is not astonishing news when there are fears of failing, desires to get better grades, poor time management, or a lack of recognition of plagiarism among students.\n2. Also, there is another kind of plagiarism that is stealing other's quotes, arts, recipes, and ideas without mentioning the name of the owner, and it is non-academic plagiarism. There are some similarities between academic and non-academic plagiarism, particularly, in motivations or reasons, methods, and effects. In academic plagiarism, students have reasons and methods to cheat and obviously, they will result in negative effects. Plagiarism in academic situations is nothing new, and there has been a high percentage of college students and high schools' who have plagiarized for several years. The most important reason should be getting better grades without enough effort, due to laziness or lack of talent, confidence, and knowledge to stand on their own feet. Most cheaters would like to have a fun social life so; they don't spend time studying as much as they should.\n3. Students steal others' research, ideas, and statistics, and use other students' lab reports and fake signatures on official documents for their financial aid applications. Ultimately, the consequence shows that most of the cheaters get disciplinary actions, alerts, and notifications. They can be removed from all classes for one or more terms, and this affects the student's ability to attend graduate schools and will be noted on their academic transcript. On the other hand, hold and pending may be placed on students' records, and the record will be kept for a minimum of five years. And the worst result of that trauma and shock is the psychological and mental impact on them which remains for years. However, all the sanctions and policies are to protect the safety and integrity of the university community, and to learn the students, new behaviors.\n4. Non-academic plagiarism is similar to academics in terms of motivation, methods, and effects. For instance, the pressure and fear could be the motivations for the politicians to plagiarize, because it would be a safer way to steal a confirmed presentation. On the other hand, other reasons would be lack of preparation, or confusion. The same as academics, the politicians repost some sentences in their speeches or books without mentioning the name of origin, and without respecting the real author and mentioning her/his name. As a matter of fact, the result will be losing their reputation, trust, dignity, expulsion, losing their positions, quitting their job, getting impeached, just like the college students when be caught of plagiarism.\n5. In summary, the main similarity between academic and non-academic plagiarism should be the personal, professional, ethical, and legal consequences. If in academics, plagiarism causes a student to be suspended, the same can cause to a politician to be impeached. In the case where a journalist works for a magazine, newspaper or other publishers, or even a student is found plagiarizing in school, the offending plagiarist could have to pay monetary penalties. Both types mean a destroyed reputation and the end of the academic position. Following as a result, laziness or dishonesty can lead to ruined reputation, the loss of a career, and legal problems.\n\nAccessed and adapter on 20 March 2023 from https://www.kqed.org/mind"
    ],
    "images": [],
    "choices": [
      {
        "id": 2565,
        "content": [
          "A disciplinary note recorded on and academic transcript"
        ],
        "isCorrect": false
      },
      {
        "id": 2566,
        "content": [
          "Suspension from the University for one or more terms"
        ],
        "isCorrect": false
      },
      {
        "id": 2567,
        "content": [
          "A five-year hold and pending remark on the cheater's records"
        ],
        "isCorrect": false
      },
      {
        "id": 2568,
        "content": [
          "The psychological and mental trauma inflicted on the cheater"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 643,
    "content": [
      "**Passage**: Laziness or Dishonesty is Ruining Reputation",
      "---",
      "If you send a plagiarist to jail for one-year service, the most likely, what is the consequence of the decision?"
    ],
    "explanation": [
      "Sending a plagiarist to jail for one year is a **legal consequence**. Jail time is a punishment imposed by the legal system, not an ethical, professional, or personal consequence."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 19,
    "groupIndex": null,
    "sharedContentId": 5,
    "sharedContent": [
      "## Laziness or Dishonesty is Ruining Reputation\n\n1. A study by the Center for Academic Integrity found that almost 80% of college students admit to cheating at least once, while this is between 75% and 98% of high school students. You might not believe this, but the statistics of 2018 show that. Although, it is not astonishing news when there are fears of failing, desires to get better grades, poor time management, or a lack of recognition of plagiarism among students.\n2. Also, there is another kind of plagiarism that is stealing other's quotes, arts, recipes, and ideas without mentioning the name of the owner, and it is non-academic plagiarism. There are some similarities between academic and non-academic plagiarism, particularly, in motivations or reasons, methods, and effects. In academic plagiarism, students have reasons and methods to cheat and obviously, they will result in negative effects. Plagiarism in academic situations is nothing new, and there has been a high percentage of college students and high schools' who have plagiarized for several years. The most important reason should be getting better grades without enough effort, due to laziness or lack of talent, confidence, and knowledge to stand on their own feet. Most cheaters would like to have a fun social life so; they don't spend time studying as much as they should.\n3. Students steal others' research, ideas, and statistics, and use other students' lab reports and fake signatures on official documents for their financial aid applications. Ultimately, the consequence shows that most of the cheaters get disciplinary actions, alerts, and notifications. They can be removed from all classes for one or more terms, and this affects the student's ability to attend graduate schools and will be noted on their academic transcript. On the other hand, hold and pending may be placed on students' records, and the record will be kept for a minimum of five years. And the worst result of that trauma and shock is the psychological and mental impact on them which remains for years. However, all the sanctions and policies are to protect the safety and integrity of the university community, and to learn the students, new behaviors.\n4. Non-academic plagiarism is similar to academics in terms of motivation, methods, and effects. For instance, the pressure and fear could be the motivations for the politicians to plagiarize, because it would be a safer way to steal a confirmed presentation. On the other hand, other reasons would be lack of preparation, or confusion. The same as academics, the politicians repost some sentences in their speeches or books without mentioning the name of origin, and without respecting the real author and mentioning her/his name. As a matter of fact, the result will be losing their reputation, trust, dignity, expulsion, losing their positions, quitting their job, getting impeached, just like the college students when be caught of plagiarism.\n5. In summary, the main similarity between academic and non-academic plagiarism should be the personal, professional, ethical, and legal consequences. If in academics, plagiarism causes a student to be suspended, the same can cause to a politician to be impeached. In the case where a journalist works for a magazine, newspaper or other publishers, or even a student is found plagiarizing in school, the offending plagiarist could have to pay monetary penalties. Both types mean a destroyed reputation and the end of the academic position. Following as a result, laziness or dishonesty can lead to ruined reputation, the loss of a career, and legal problems.\n\nAccessed and adapter on 20 March 2023 from https://www.kqed.org/mind"
    ],
    "images": [],
    "choices": [
      {
        "id": 2569,
        "content": [
          "ethical"
        ],
        "isCorrect": false
      },
      {
        "id": 2570,
        "content": [
          "legal"
        ],
        "isCorrect": true
      },
      {
        "id": 2571,
        "content": [
          "Professional"
        ],
        "isCorrect": false
      },
      {
        "id": 2572,
        "content": [
          "Personal"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 644,
    "content": [
      "**Passage**: Laziness or Dishonesty is Ruining Reputation",
      "---",
      "Which one of the following sentences is true about politicians in relation to plagiarism?"
    ],
    "explanation": [
      "Paragraph 4 states that \"lack of preparation\" is a reason for politicians to plagiarize. Lack of preparation suggests a form of laziness, where they avoid putting in the necessary work to create original content."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 19,
    "groupIndex": null,
    "sharedContentId": 5,
    "sharedContent": [
      "## Laziness or Dishonesty is Ruining Reputation\n\n1. A study by the Center for Academic Integrity found that almost 80% of college students admit to cheating at least once, while this is between 75% and 98% of high school students. You might not believe this, but the statistics of 2018 show that. Although, it is not astonishing news when there are fears of failing, desires to get better grades, poor time management, or a lack of recognition of plagiarism among students.\n2. Also, there is another kind of plagiarism that is stealing other's quotes, arts, recipes, and ideas without mentioning the name of the owner, and it is non-academic plagiarism. There are some similarities between academic and non-academic plagiarism, particularly, in motivations or reasons, methods, and effects. In academic plagiarism, students have reasons and methods to cheat and obviously, they will result in negative effects. Plagiarism in academic situations is nothing new, and there has been a high percentage of college students and high schools' who have plagiarized for several years. The most important reason should be getting better grades without enough effort, due to laziness or lack of talent, confidence, and knowledge to stand on their own feet. Most cheaters would like to have a fun social life so; they don't spend time studying as much as they should.\n3. Students steal others' research, ideas, and statistics, and use other students' lab reports and fake signatures on official documents for their financial aid applications. Ultimately, the consequence shows that most of the cheaters get disciplinary actions, alerts, and notifications. They can be removed from all classes for one or more terms, and this affects the student's ability to attend graduate schools and will be noted on their academic transcript. On the other hand, hold and pending may be placed on students' records, and the record will be kept for a minimum of five years. And the worst result of that trauma and shock is the psychological and mental impact on them which remains for years. However, all the sanctions and policies are to protect the safety and integrity of the university community, and to learn the students, new behaviors.\n4. Non-academic plagiarism is similar to academics in terms of motivation, methods, and effects. For instance, the pressure and fear could be the motivations for the politicians to plagiarize, because it would be a safer way to steal a confirmed presentation. On the other hand, other reasons would be lack of preparation, or confusion. The same as academics, the politicians repost some sentences in their speeches or books without mentioning the name of origin, and without respecting the real author and mentioning her/his name. As a matter of fact, the result will be losing their reputation, trust, dignity, expulsion, losing their positions, quitting their job, getting impeached, just like the college students when be caught of plagiarism.\n5. In summary, the main similarity between academic and non-academic plagiarism should be the personal, professional, ethical, and legal consequences. If in academics, plagiarism causes a student to be suspended, the same can cause to a politician to be impeached. In the case where a journalist works for a magazine, newspaper or other publishers, or even a student is found plagiarizing in school, the offending plagiarist could have to pay monetary penalties. Both types mean a destroyed reputation and the end of the academic position. Following as a result, laziness or dishonesty can lead to ruined reputation, the loss of a career, and legal problems.\n\nAccessed and adapter on 20 March 2023 from https://www.kqed.org/mind"
    ],
    "images": [],
    "choices": [
      {
        "id": 2573,
        "content": [
          "Confirmed presentations tempt politicians and push them to plagiarize."
        ],
        "isCorrect": false
      },
      {
        "id": 2574,
        "content": [
          "Politicians avoid plagiarism due to fear of pressure from the public."
        ],
        "isCorrect": false
      },
      {
        "id": 2575,
        "content": [
          "Consequences of plagiarism could be comparatively less harsh on politicians."
        ],
        "isCorrect": false
      },
      {
        "id": 2576,
        "content": [
          "Politicians may resort to plagiarism as a means of covering up their laziness."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1938,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What can we deduce from Paragraph 2 about the mission of the University of Michigan's Animal Diversity Web (ADW)?"
    ],
    "explanation": [
      "The passage cites the ADW as the source for a direct comparison between the weights of male and female chimpanzees. This suggests that the ADW provides data that allows for such comparisons between different groups within a species."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 39,
    "groupIndex": null,
    "sharedContentId": 12,
    "sharedContent": [
      "## Chimpanzees: Intelligent, Social and Violent\n\n1. Chimpanzees (Pan troglodytes), also known as chimps, are one of **our** closest living relatives and members of the great ape family, along with gorillas, orangutans, bonobos and humans. Chimps share 98.7% of their DNA with humans and have a lot of the same traits. They are known for being intelligent, social and violent animals that live in complex societies. Chimpanzees have suffered greatly from the increasing presence and influence of modern humans in their environment and are now threatened with extinction.\n\n## How Big Is a Chimpanzee?\n\n2. Chimpanzees are between 3 feet 3 inches and 5 feet 6 inches (1 to 1.7 meters) tall when standing upright like a human. However, they mostly walk on all fours using their knuckles and feet. Males are slightly bigger than females. A male can weigh up to about 154 lbs. (70 kilograms) compared with a maximum weight of about 110 lbs. (50 kg) for a female, according to the University of Michigan's Animal Diversity Web (ADW). Although currently categorized among endangered species, chimps can live up to about 50 years. They are stronger than humans, despite being smaller. In fact, they are about 1.35 times more powerful than humans as they have more fast-twitch muscle fibers, which are good for strength and speed, Live Science reported. These fast-twitch muscle fibers enable chimps to outperform people in tasks such as pulling and jumping. Humans evolved to have more slow-twitch muscle fibers that are better for endurance and traveling long distances.\n\n## Do Chimpanzees Attack People?\n\n3. Wild chimpanzees are usually fearful of humans and will keep their distance. However, there have been recorded incidents of chimpanzees attacking and killing people. This usually happens when humans move into and destroy chimpanzee habitats, reducing their access to food. Chimpanzees may then take to stealing unprotected human food, such as crops, and in the process become more confident around humans. Chimpanzees have attacked more than 20 people in the Western Region of Uganda over the past 20 years and killed at least three human infants since 2014, National Geographic reported in 2019. Chimpanzees typically direct their aggressive and sometimes **predatory behavior** toward children because the animals are more fearful of larger human adults, especially men, according to National Geographic. Chimps have also snatched and killed human babies. Most of the time these are isolated and seemingly reckless attacks by individual chimps, but one chimpanzee in the 1990s killed seven children before he was killed by humans, National Geographic reported.\n\nSlightly adapted from Patrick Pester https://www.livescience.com/chimpanzee-facts.html*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7760,
        "content": [
          "It offers courses on various animals found in different parts of the world."
        ],
        "isCorrect": false
      },
      {
        "id": 7761,
        "content": [
          "It provides information on different animal species to foster comparisons."
        ],
        "isCorrect": true
      },
      {
        "id": 7762,
        "content": [
          "It specializes in chimps and has comprehensive information on them."
        ],
        "isCorrect": false
      },
      {
        "id": 7763,
        "content": [
          "It is among the top institutions in the world that studies the apes family."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1939,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which one of the following sentences best describes the relationship of chimps with humans?"
    ],
    "explanation": [
      "The passage states in paragraph 3, \"Wild chimpanzees are usually fearful of humans and will keep their distance.\" While attacks can happen under specific circumstances, their usual disposition is to be fearful and avoid contact."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 39,
    "groupIndex": null,
    "sharedContentId": 12,
    "sharedContent": [
      "## Chimpanzees: Intelligent, Social and Violent\n\n1. Chimpanzees (Pan troglodytes), also known as chimps, are one of **our** closest living relatives and members of the great ape family, along with gorillas, orangutans, bonobos and humans. Chimps share 98.7% of their DNA with humans and have a lot of the same traits. They are known for being intelligent, social and violent animals that live in complex societies. Chimpanzees have suffered greatly from the increasing presence and influence of modern humans in their environment and are now threatened with extinction.\n\n## How Big Is a Chimpanzee?\n\n2. Chimpanzees are between 3 feet 3 inches and 5 feet 6 inches (1 to 1.7 meters) tall when standing upright like a human. However, they mostly walk on all fours using their knuckles and feet. Males are slightly bigger than females. A male can weigh up to about 154 lbs. (70 kilograms) compared with a maximum weight of about 110 lbs. (50 kg) for a female, according to the University of Michigan's Animal Diversity Web (ADW). Although currently categorized among endangered species, chimps can live up to about 50 years. They are stronger than humans, despite being smaller. In fact, they are about 1.35 times more powerful than humans as they have more fast-twitch muscle fibers, which are good for strength and speed, Live Science reported. These fast-twitch muscle fibers enable chimps to outperform people in tasks such as pulling and jumping. Humans evolved to have more slow-twitch muscle fibers that are better for endurance and traveling long distances.\n\n## Do Chimpanzees Attack People?\n\n3. Wild chimpanzees are usually fearful of humans and will keep their distance. However, there have been recorded incidents of chimpanzees attacking and killing people. This usually happens when humans move into and destroy chimpanzee habitats, reducing their access to food. Chimpanzees may then take to stealing unprotected human food, such as crops, and in the process become more confident around humans. Chimpanzees have attacked more than 20 people in the Western Region of Uganda over the past 20 years and killed at least three human infants since 2014, National Geographic reported in 2019. Chimpanzees typically direct their aggressive and sometimes **predatory behavior** toward children because the animals are more fearful of larger human adults, especially men, according to National Geographic. Chimps have also snatched and killed human babies. Most of the time these are isolated and seemingly reckless attacks by individual chimps, but one chimpanzee in the 1990s killed seven children before he was killed by humans, National Geographic reported.\n\nSlightly adapted from Patrick Pester https://www.livescience.com/chimpanzee-facts.html*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7764,
        "content": [
          "It is usual for chimps to steal unprotected human food."
        ],
        "isCorrect": false
      },
      {
        "id": 7765,
        "content": [
          "Chimps can leave their habitats in the interest of humans."
        ],
        "isCorrect": false
      },
      {
        "id": 7766,
        "content": [
          "Chimps can kill if humans get into their territory."
        ],
        "isCorrect": false
      },
      {
        "id": 7767,
        "content": [
          "Wild chimps are fearful of humans and do not attack."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1940,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which one of the following is true about chimpanzees in the Western Region of Uganda?"
    ],
    "explanation": [
      "Paragraph 3 explicitly states, \"Chimpanzees typically direct their aggressive and sometimes predatory behavior toward children because the animals are more fearful of larger human adults...\""
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 39,
    "groupIndex": null,
    "sharedContentId": 12,
    "sharedContent": [
      "## Chimpanzees: Intelligent, Social and Violent\n\n1. Chimpanzees (Pan troglodytes), also known as chimps, are one of **our** closest living relatives and members of the great ape family, along with gorillas, orangutans, bonobos and humans. Chimps share 98.7% of their DNA with humans and have a lot of the same traits. They are known for being intelligent, social and violent animals that live in complex societies. Chimpanzees have suffered greatly from the increasing presence and influence of modern humans in their environment and are now threatened with extinction.\n\n## How Big Is a Chimpanzee?\n\n2. Chimpanzees are between 3 feet 3 inches and 5 feet 6 inches (1 to 1.7 meters) tall when standing upright like a human. However, they mostly walk on all fours using their knuckles and feet. Males are slightly bigger than females. A male can weigh up to about 154 lbs. (70 kilograms) compared with a maximum weight of about 110 lbs. (50 kg) for a female, according to the University of Michigan's Animal Diversity Web (ADW). Although currently categorized among endangered species, chimps can live up to about 50 years. They are stronger than humans, despite being smaller. In fact, they are about 1.35 times more powerful than humans as they have more fast-twitch muscle fibers, which are good for strength and speed, Live Science reported. These fast-twitch muscle fibers enable chimps to outperform people in tasks such as pulling and jumping. Humans evolved to have more slow-twitch muscle fibers that are better for endurance and traveling long distances.\n\n## Do Chimpanzees Attack People?\n\n3. Wild chimpanzees are usually fearful of humans and will keep their distance. However, there have been recorded incidents of chimpanzees attacking and killing people. This usually happens when humans move into and destroy chimpanzee habitats, reducing their access to food. Chimpanzees may then take to stealing unprotected human food, such as crops, and in the process become more confident around humans. Chimpanzees have attacked more than 20 people in the Western Region of Uganda over the past 20 years and killed at least three human infants since 2014, National Geographic reported in 2019. Chimpanzees typically direct their aggressive and sometimes **predatory behavior** toward children because the animals are more fearful of larger human adults, especially men, according to National Geographic. Chimps have also snatched and killed human babies. Most of the time these are isolated and seemingly reckless attacks by individual chimps, but one chimpanzee in the 1990s killed seven children before he was killed by humans, National Geographic reported.\n\nSlightly adapted from Patrick Pester https://www.livescience.com/chimpanzee-facts.html*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7768,
        "content": [
          "They are aggressive and usually attack human beings."
        ],
        "isCorrect": false
      },
      {
        "id": 7769,
        "content": [
          "When stealing food, they become more confident than humans."
        ],
        "isCorrect": false
      },
      {
        "id": 7770,
        "content": [
          "They obviously kill one person per year."
        ],
        "isCorrect": false
      },
      {
        "id": 7771,
        "content": [
          "They attack children more than they do adults."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1941,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What does '**predatory behavior**' as used in Paragraph 3 mean?"
    ],
    "explanation": [
      "In biology, predatory behavior refers to the act of an animal hunting, killing, and eating other animals. The context of chimps snatching, attacking, and killing babies strongly suggests this meaning of hunting and killing for food."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 39,
    "groupIndex": null,
    "sharedContentId": 12,
    "sharedContent": [
      "## Chimpanzees: Intelligent, Social and Violent\n\n1. Chimpanzees (Pan troglodytes), also known as chimps, are one of **our** closest living relatives and members of the great ape family, along with gorillas, orangutans, bonobos and humans. Chimps share 98.7% of their DNA with humans and have a lot of the same traits. They are known for being intelligent, social and violent animals that live in complex societies. Chimpanzees have suffered greatly from the increasing presence and influence of modern humans in their environment and are now threatened with extinction.\n\n## How Big Is a Chimpanzee?\n\n2. Chimpanzees are between 3 feet 3 inches and 5 feet 6 inches (1 to 1.7 meters) tall when standing upright like a human. However, they mostly walk on all fours using their knuckles and feet. Males are slightly bigger than females. A male can weigh up to about 154 lbs. (70 kilograms) compared with a maximum weight of about 110 lbs. (50 kg) for a female, according to the University of Michigan's Animal Diversity Web (ADW). Although currently categorized among endangered species, chimps can live up to about 50 years. They are stronger than humans, despite being smaller. In fact, they are about 1.35 times more powerful than humans as they have more fast-twitch muscle fibers, which are good for strength and speed, Live Science reported. These fast-twitch muscle fibers enable chimps to outperform people in tasks such as pulling and jumping. Humans evolved to have more slow-twitch muscle fibers that are better for endurance and traveling long distances.\n\n## Do Chimpanzees Attack People?\n\n3. Wild chimpanzees are usually fearful of humans and will keep their distance. However, there have been recorded incidents of chimpanzees attacking and killing people. This usually happens when humans move into and destroy chimpanzee habitats, reducing their access to food. Chimpanzees may then take to stealing unprotected human food, such as crops, and in the process become more confident around humans. Chimpanzees have attacked more than 20 people in the Western Region of Uganda over the past 20 years and killed at least three human infants since 2014, National Geographic reported in 2019. Chimpanzees typically direct their aggressive and sometimes **predatory behavior** toward children because the animals are more fearful of larger human adults, especially men, according to National Geographic. Chimps have also snatched and killed human babies. Most of the time these are isolated and seemingly reckless attacks by individual chimps, but one chimpanzee in the 1990s killed seven children before he was killed by humans, National Geographic reported.\n\nSlightly adapted from Patrick Pester https://www.livescience.com/chimpanzee-facts.html*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7772,
        "content": [
          "Attacking individual children consistently."
        ],
        "isCorrect": false
      },
      {
        "id": 7773,
        "content": [
          "Taking advantage of vulnerable situations."
        ],
        "isCorrect": false
      },
      {
        "id": 7774,
        "content": [
          "Killing and eating human beings."
        ],
        "isCorrect": true
      },
      {
        "id": 7775,
        "content": [
          "Being afraid of larger human beings."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1942,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Who does 'our' as used in Paragraph 1 Line 1 refer to?"
    ],
    "explanation": [
      "The first sentence lists the members of the great ape family as \"gorillas, orangutans, bonobos and humans.\" Since \"humans\" are included in the list of relatives, the pronoun \"our\" refers to human beings."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 39,
    "groupIndex": null,
    "sharedContentId": 12,
    "sharedContent": [
      "## Chimpanzees: Intelligent, Social and Violent\n\n1. Chimpanzees (Pan troglodytes), also known as chimps, are one of **our** closest living relatives and members of the great ape family, along with gorillas, orangutans, bonobos and humans. Chimps share 98.7% of their DNA with humans and have a lot of the same traits. They are known for being intelligent, social and violent animals that live in complex societies. Chimpanzees have suffered greatly from the increasing presence and influence of modern humans in their environment and are now threatened with extinction.\n\n## How Big Is a Chimpanzee?\n\n2. Chimpanzees are between 3 feet 3 inches and 5 feet 6 inches (1 to 1.7 meters) tall when standing upright like a human. However, they mostly walk on all fours using their knuckles and feet. Males are slightly bigger than females. A male can weigh up to about 154 lbs. (70 kilograms) compared with a maximum weight of about 110 lbs. (50 kg) for a female, according to the University of Michigan's Animal Diversity Web (ADW). Although currently categorized among endangered species, chimps can live up to about 50 years. They are stronger than humans, despite being smaller. In fact, they are about 1.35 times more powerful than humans as they have more fast-twitch muscle fibers, which are good for strength and speed, Live Science reported. These fast-twitch muscle fibers enable chimps to outperform people in tasks such as pulling and jumping. Humans evolved to have more slow-twitch muscle fibers that are better for endurance and traveling long distances.\n\n## Do Chimpanzees Attack People?\n\n3. Wild chimpanzees are usually fearful of humans and will keep their distance. However, there have been recorded incidents of chimpanzees attacking and killing people. This usually happens when humans move into and destroy chimpanzee habitats, reducing their access to food. Chimpanzees may then take to stealing unprotected human food, such as crops, and in the process become more confident around humans. Chimpanzees have attacked more than 20 people in the Western Region of Uganda over the past 20 years and killed at least three human infants since 2014, National Geographic reported in 2019. Chimpanzees typically direct their aggressive and sometimes **predatory behavior** toward children because the animals are more fearful of larger human adults, especially men, according to National Geographic. Chimps have also snatched and killed human babies. Most of the time these are isolated and seemingly reckless attacks by individual chimps, but one chimpanzee in the 1990s killed seven children before he was killed by humans, National Geographic reported.\n\nSlightly adapted from Patrick Pester https://www.livescience.com/chimpanzee-facts.html*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7776,
        "content": [
          "Human beings"
        ],
        "isCorrect": true
      },
      {
        "id": 7777,
        "content": [
          "Friends talking"
        ],
        "isCorrect": false
      },
      {
        "id": 7778,
        "content": [
          "Chimps"
        ],
        "isCorrect": false
      },
      {
        "id": 7779,
        "content": [
          "The writers"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1943,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which one of the following sentences, according to the passage, is true about the great ape family?"
    ],
    "explanation": [
      "Paragraph 1 states that the great ape family includes \"gorillas, orangutans, bonobos and humans.\" By this definition provided in the text, humans are classified within the same family, meaning they do not differ from apes in that specific categorization."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 39,
    "groupIndex": null,
    "sharedContentId": 12,
    "sharedContent": [
      "## Chimpanzees: Intelligent, Social and Violent\n\n1. Chimpanzees (Pan troglodytes), also known as chimps, are one of **our** closest living relatives and members of the great ape family, along with gorillas, orangutans, bonobos and humans. Chimps share 98.7% of their DNA with humans and have a lot of the same traits. They are known for being intelligent, social and violent animals that live in complex societies. Chimpanzees have suffered greatly from the increasing presence and influence of modern humans in their environment and are now threatened with extinction.\n\n## How Big Is a Chimpanzee?\n\n2. Chimpanzees are between 3 feet 3 inches and 5 feet 6 inches (1 to 1.7 meters) tall when standing upright like a human. However, they mostly walk on all fours using their knuckles and feet. Males are slightly bigger than females. A male can weigh up to about 154 lbs. (70 kilograms) compared with a maximum weight of about 110 lbs. (50 kg) for a female, according to the University of Michigan's Animal Diversity Web (ADW). Although currently categorized among endangered species, chimps can live up to about 50 years. They are stronger than humans, despite being smaller. In fact, they are about 1.35 times more powerful than humans as they have more fast-twitch muscle fibers, which are good for strength and speed, Live Science reported. These fast-twitch muscle fibers enable chimps to outperform people in tasks such as pulling and jumping. Humans evolved to have more slow-twitch muscle fibers that are better for endurance and traveling long distances.\n\n## Do Chimpanzees Attack People?\n\n3. Wild chimpanzees are usually fearful of humans and will keep their distance. However, there have been recorded incidents of chimpanzees attacking and killing people. This usually happens when humans move into and destroy chimpanzee habitats, reducing their access to food. Chimpanzees may then take to stealing unprotected human food, such as crops, and in the process become more confident around humans. Chimpanzees have attacked more than 20 people in the Western Region of Uganda over the past 20 years and killed at least three human infants since 2014, National Geographic reported in 2019. Chimpanzees typically direct their aggressive and sometimes **predatory behavior** toward children because the animals are more fearful of larger human adults, especially men, according to National Geographic. Chimps have also snatched and killed human babies. Most of the time these are isolated and seemingly reckless attacks by individual chimps, but one chimpanzee in the 1990s killed seven children before he was killed by humans, National Geographic reported.\n\nSlightly adapted from Patrick Pester https://www.livescience.com/chimpanzee-facts.html*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7780,
        "content": [
          "In terms of family categorization, humans do not differ from apes."
        ],
        "isCorrect": true
      },
      {
        "id": 7781,
        "content": [
          "Chimps are the most intelligent of all members of its family group."
        ],
        "isCorrect": false
      },
      {
        "id": 7782,
        "content": [
          "Chimps are closer to humans than any other living relative."
        ],
        "isCorrect": false
      },
      {
        "id": 7783,
        "content": [
          "Except chimps, other apes close to humans have gone extinct."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1944,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What could be taken as contradictory about chimps in the passage, in Paragraph 1?"
    ],
    "explanation": [
      "Paragraph 1 states, \"They are known for being intelligent, social and violent animals...\" The juxtaposition of the positive traits \"intelligent\" and \"social\" with the negative trait \"violent\" presents a complexity or contradiction in their nature."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 39,
    "groupIndex": null,
    "sharedContentId": 12,
    "sharedContent": [
      "## Chimpanzees: Intelligent, Social and Violent\n\n1. Chimpanzees (Pan troglodytes), also known as chimps, are one of **our** closest living relatives and members of the great ape family, along with gorillas, orangutans, bonobos and humans. Chimps share 98.7% of their DNA with humans and have a lot of the same traits. They are known for being intelligent, social and violent animals that live in complex societies. Chimpanzees have suffered greatly from the increasing presence and influence of modern humans in their environment and are now threatened with extinction.\n\n## How Big Is a Chimpanzee?\n\n2. Chimpanzees are between 3 feet 3 inches and 5 feet 6 inches (1 to 1.7 meters) tall when standing upright like a human. However, they mostly walk on all fours using their knuckles and feet. Males are slightly bigger than females. A male can weigh up to about 154 lbs. (70 kilograms) compared with a maximum weight of about 110 lbs. (50 kg) for a female, according to the University of Michigan's Animal Diversity Web (ADW). Although currently categorized among endangered species, chimps can live up to about 50 years. They are stronger than humans, despite being smaller. In fact, they are about 1.35 times more powerful than humans as they have more fast-twitch muscle fibers, which are good for strength and speed, Live Science reported. These fast-twitch muscle fibers enable chimps to outperform people in tasks such as pulling and jumping. Humans evolved to have more slow-twitch muscle fibers that are better for endurance and traveling long distances.\n\n## Do Chimpanzees Attack People?\n\n3. Wild chimpanzees are usually fearful of humans and will keep their distance. However, there have been recorded incidents of chimpanzees attacking and killing people. This usually happens when humans move into and destroy chimpanzee habitats, reducing their access to food. Chimpanzees may then take to stealing unprotected human food, such as crops, and in the process become more confident around humans. Chimpanzees have attacked more than 20 people in the Western Region of Uganda over the past 20 years and killed at least three human infants since 2014, National Geographic reported in 2019. Chimpanzees typically direct their aggressive and sometimes **predatory behavior** toward children because the animals are more fearful of larger human adults, especially men, according to National Geographic. Chimps have also snatched and killed human babies. Most of the time these are isolated and seemingly reckless attacks by individual chimps, but one chimpanzee in the 1990s killed seven children before he was killed by humans, National Geographic reported.\n\nSlightly adapted from Patrick Pester https://www.livescience.com/chimpanzee-facts.html*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7784,
        "content": [
          "That chimps are apes but still share a lot with humans."
        ],
        "isCorrect": false
      },
      {
        "id": 7785,
        "content": [
          "That chimps live in complex societies but are just apes."
        ],
        "isCorrect": false
      },
      {
        "id": 7786,
        "content": [
          "That chimps are intelligent and social but violent."
        ],
        "isCorrect": true
      },
      {
        "id": 7787,
        "content": [
          "That chimps and humans belong to the same family."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1945,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "How tall could an average chimpanzee be when standing upright?"
    ],
    "explanation": [
      "Paragraph 2 gives the height range of chimpanzees as 3 feet 3 inches (3.25 feet) to 5 feet 6 inches (5.5 feet). The average of this range is (3.25 + 5.5) / 2 = 4.375 feet, which is 4 feet and 4.5 inches. This falls within the given range."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 39,
    "groupIndex": null,
    "sharedContentId": 12,
    "sharedContent": [
      "## Chimpanzees: Intelligent, Social and Violent\n\n1. Chimpanzees (Pan troglodytes), also known as chimps, are one of **our** closest living relatives and members of the great ape family, along with gorillas, orangutans, bonobos and humans. Chimps share 98.7% of their DNA with humans and have a lot of the same traits. They are known for being intelligent, social and violent animals that live in complex societies. Chimpanzees have suffered greatly from the increasing presence and influence of modern humans in their environment and are now threatened with extinction.\n\n## How Big Is a Chimpanzee?\n\n2. Chimpanzees are between 3 feet 3 inches and 5 feet 6 inches (1 to 1.7 meters) tall when standing upright like a human. However, they mostly walk on all fours using their knuckles and feet. Males are slightly bigger than females. A male can weigh up to about 154 lbs. (70 kilograms) compared with a maximum weight of about 110 lbs. (50 kg) for a female, according to the University of Michigan's Animal Diversity Web (ADW). Although currently categorized among endangered species, chimps can live up to about 50 years. They are stronger than humans, despite being smaller. In fact, they are about 1.35 times more powerful than humans as they have more fast-twitch muscle fibers, which are good for strength and speed, Live Science reported. These fast-twitch muscle fibers enable chimps to outperform people in tasks such as pulling and jumping. Humans evolved to have more slow-twitch muscle fibers that are better for endurance and traveling long distances.\n\n## Do Chimpanzees Attack People?\n\n3. Wild chimpanzees are usually fearful of humans and will keep their distance. However, there have been recorded incidents of chimpanzees attacking and killing people. This usually happens when humans move into and destroy chimpanzee habitats, reducing their access to food. Chimpanzees may then take to stealing unprotected human food, such as crops, and in the process become more confident around humans. Chimpanzees have attacked more than 20 people in the Western Region of Uganda over the past 20 years and killed at least three human infants since 2014, National Geographic reported in 2019. Chimpanzees typically direct their aggressive and sometimes **predatory behavior** toward children because the animals are more fearful of larger human adults, especially men, according to National Geographic. Chimps have also snatched and killed human babies. Most of the time these are isolated and seemingly reckless attacks by individual chimps, but one chimpanzee in the 1990s killed seven children before he was killed by humans, National Geographic reported.\n\nSlightly adapted from Patrick Pester https://www.livescience.com/chimpanzee-facts.html*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7788,
        "content": [
          "Around 4 feet 7 inches"
        ],
        "isCorrect": false
      },
      {
        "id": 7789,
        "content": [
          "Around 4 feet 2 inches"
        ],
        "isCorrect": false
      },
      {
        "id": 7790,
        "content": [
          "Around 5 feet 3 inches"
        ],
        "isCorrect": false
      },
      {
        "id": 7791,
        "content": [
          "Around 4 feet 4.5 inches"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1946,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "According to Paragraph 2, which one of the following is true about chimps?"
    ],
    "explanation": [
      "Paragraph 2 explicitly states, \"They are stronger than humans, despite being smaller.\" This directly confirms that they are more powerful but smaller in size."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 39,
    "groupIndex": null,
    "sharedContentId": 12,
    "sharedContent": [
      "## Chimpanzees: Intelligent, Social and Violent\n\n1. Chimpanzees (Pan troglodytes), also known as chimps, are one of **our** closest living relatives and members of the great ape family, along with gorillas, orangutans, bonobos and humans. Chimps share 98.7% of their DNA with humans and have a lot of the same traits. They are known for being intelligent, social and violent animals that live in complex societies. Chimpanzees have suffered greatly from the increasing presence and influence of modern humans in their environment and are now threatened with extinction.\n\n## How Big Is a Chimpanzee?\n\n2. Chimpanzees are between 3 feet 3 inches and 5 feet 6 inches (1 to 1.7 meters) tall when standing upright like a human. However, they mostly walk on all fours using their knuckles and feet. Males are slightly bigger than females. A male can weigh up to about 154 lbs. (70 kilograms) compared with a maximum weight of about 110 lbs. (50 kg) for a female, according to the University of Michigan's Animal Diversity Web (ADW). Although currently categorized among endangered species, chimps can live up to about 50 years. They are stronger than humans, despite being smaller. In fact, they are about 1.35 times more powerful than humans as they have more fast-twitch muscle fibers, which are good for strength and speed, Live Science reported. These fast-twitch muscle fibers enable chimps to outperform people in tasks such as pulling and jumping. Humans evolved to have more slow-twitch muscle fibers that are better for endurance and traveling long distances.\n\n## Do Chimpanzees Attack People?\n\n3. Wild chimpanzees are usually fearful of humans and will keep their distance. However, there have been recorded incidents of chimpanzees attacking and killing people. This usually happens when humans move into and destroy chimpanzee habitats, reducing their access to food. Chimpanzees may then take to stealing unprotected human food, such as crops, and in the process become more confident around humans. Chimpanzees have attacked more than 20 people in the Western Region of Uganda over the past 20 years and killed at least three human infants since 2014, National Geographic reported in 2019. Chimpanzees typically direct their aggressive and sometimes **predatory behavior** toward children because the animals are more fearful of larger human adults, especially men, according to National Geographic. Chimps have also snatched and killed human babies. Most of the time these are isolated and seemingly reckless attacks by individual chimps, but one chimpanzee in the 1990s killed seven children before he was killed by humans, National Geographic reported.\n\nSlightly adapted from Patrick Pester https://www.livescience.com/chimpanzee-facts.html*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7792,
        "content": [
          "Female chimpanzees do not weigh as much as human beings do."
        ],
        "isCorrect": false
      },
      {
        "id": 7793,
        "content": [
          "Chimps are now given special attention so they grow in number."
        ],
        "isCorrect": false
      },
      {
        "id": 7794,
        "content": [
          "Chimpanzees are more powerful, but smaller than human beings."
        ],
        "isCorrect": true
      },
      {
        "id": 7795,
        "content": [
          "These days, most chimpanzees live as long as human beings do."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1947,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which one of the following, according to Paragraph 2, is true about child abuse reports in Philadelphia?"
    ],
    "explanation": [
      "Paragraph 2 states that while over 5,000 cases are reported, a spokeswoman says, \"There's a lot more out there that goes unreported.\" Additionally, only 300 reports came from schools with a quarter-million kids. This indicates the reported number is much smaller than the real number of incidents."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 40,
    "groupIndex": null,
    "sharedContentId": 13,
    "sharedContent": [
      "1. Child abuse is a phenomenon that knows no social, geographic or racial boundaries. It occurs in the best of families in wealthy suburbs and in rural areas as well. It is, in fact, a national **plague** that experts say is likely to create another generation of child abusers in America from among those being abused today.\n2. For years, the problem was hidden behind the closed doors of houses or apartments. But, since the passage of laws in the 1970s requiring health and other professionals to report all cases of suspected abuse, a quiet revolution has been occurring. More cases of child abuse are being reported, and social-welfare agencies are getting help for both the children and **their** parents. That is not to say, however, that the reporting is in any way complete. More than 5,000 cases are reported annually to the Philadelphia County Children and Youth Agency, but a spokeswoman said, \"There's a lot more out there that goes unreported.\" Schools are just now beginning to focus on abuse, the spokeswoman said. \"Out of the quarter-million kids within the Philadelphia schools, we received only 300 reports last year. However, the schools are making strides in this area,\" she said. To increase the frequency of reporting, institutions that come into contact with injured children are training staff members to recognize abuse. The tremendous amount of stress in today's society both within and outside the home is considered one of the main factors in the rise of child abuse.\n3. Poor marital relationships, single parenthood, social and economic problems, unemployment and social isolation add undue stress to our lives. The problem of social isolation is critical. Today, people are moving around and finding themselves living further away from their families and the emotional support which they provide. Mothers find themselves living either in large city apartment complexes or suburban communities in which they know absolutely no one. In this lonely atmosphere, they try to deal with the pressures of being the parent of one, two or three children.\n\n*Source: Reading and Study Skills, by John Langan.*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7796,
        "content": [
          "Reports of over 5,000 cases per annum are promisingly high."
        ],
        "isCorrect": false
      },
      {
        "id": 7797,
        "content": [
          "The Children and Youth Agency is receiving incomplete reports on cases."
        ],
        "isCorrect": false
      },
      {
        "id": 7798,
        "content": [
          "Cases are being reported extensively."
        ],
        "isCorrect": false
      },
      {
        "id": 7799,
        "content": [
          "Incidents reported are far less than the actual problem."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1948,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What, according to the passage, is a possible cause of child abuse?"
    ],
    "explanation": [
      "Paragraph 3 lists several factors that \"add undue stress to our lives,\" such as poor relationships, single parenthood, economic problems, and social isolation. These are all straining situations that contribute to the problem."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 40,
    "groupIndex": null,
    "sharedContentId": 13,
    "sharedContent": [
      "1. Child abuse is a phenomenon that knows no social, geographic or racial boundaries. It occurs in the best of families in wealthy suburbs and in rural areas as well. It is, in fact, a national **plague** that experts say is likely to create another generation of child abusers in America from among those being abused today.\n2. For years, the problem was hidden behind the closed doors of houses or apartments. But, since the passage of laws in the 1970s requiring health and other professionals to report all cases of suspected abuse, a quiet revolution has been occurring. More cases of child abuse are being reported, and social-welfare agencies are getting help for both the children and **their** parents. That is not to say, however, that the reporting is in any way complete. More than 5,000 cases are reported annually to the Philadelphia County Children and Youth Agency, but a spokeswoman said, \"There's a lot more out there that goes unreported.\" Schools are just now beginning to focus on abuse, the spokeswoman said. \"Out of the quarter-million kids within the Philadelphia schools, we received only 300 reports last year. However, the schools are making strides in this area,\" she said. To increase the frequency of reporting, institutions that come into contact with injured children are training staff members to recognize abuse. The tremendous amount of stress in today's society both within and outside the home is considered one of the main factors in the rise of child abuse.\n3. Poor marital relationships, single parenthood, social and economic problems, unemployment and social isolation add undue stress to our lives. The problem of social isolation is critical. Today, people are moving around and finding themselves living further away from their families and the emotional support which they provide. Mothers find themselves living either in large city apartment complexes or suburban communities in which they know absolutely no one. In this lonely atmosphere, they try to deal with the pressures of being the parent of one, two or three children.\n\n*Source: Reading and Study Skills, by John Langan.*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7800,
        "content": [
          "Being under straining situations"
        ],
        "isCorrect": true
      },
      {
        "id": 7801,
        "content": [
          "Social events in or outside the home"
        ],
        "isCorrect": false
      },
      {
        "id": 7802,
        "content": [
          "Poor reporting system"
        ],
        "isCorrect": false
      },
      {
        "id": 7803,
        "content": [
          "Individuals with ill motives"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1949,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which one of the following is **NOT** a possible cause of undue stress?"
    ],
    "explanation": [
      "Paragraph 3 mentions \"Poor marital relationships\" (disagreement between spouses), \"economic problems\" (failure to afford a living), and \"social isolation\" (loneliness). It does not mention doing a job one is not interested in."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 40,
    "groupIndex": null,
    "sharedContentId": 13,
    "sharedContent": [
      "1. Child abuse is a phenomenon that knows no social, geographic or racial boundaries. It occurs in the best of families in wealthy suburbs and in rural areas as well. It is, in fact, a national **plague** that experts say is likely to create another generation of child abusers in America from among those being abused today.\n2. For years, the problem was hidden behind the closed doors of houses or apartments. But, since the passage of laws in the 1970s requiring health and other professionals to report all cases of suspected abuse, a quiet revolution has been occurring. More cases of child abuse are being reported, and social-welfare agencies are getting help for both the children and **their** parents. That is not to say, however, that the reporting is in any way complete. More than 5,000 cases are reported annually to the Philadelphia County Children and Youth Agency, but a spokeswoman said, \"There's a lot more out there that goes unreported.\" Schools are just now beginning to focus on abuse, the spokeswoman said. \"Out of the quarter-million kids within the Philadelphia schools, we received only 300 reports last year. However, the schools are making strides in this area,\" she said. To increase the frequency of reporting, institutions that come into contact with injured children are training staff members to recognize abuse. The tremendous amount of stress in today's society both within and outside the home is considered one of the main factors in the rise of child abuse.\n3. Poor marital relationships, single parenthood, social and economic problems, unemployment and social isolation add undue stress to our lives. The problem of social isolation is critical. Today, people are moving around and finding themselves living further away from their families and the emotional support which they provide. Mothers find themselves living either in large city apartment complexes or suburban communities in which they know absolutely no one. In this lonely atmosphere, they try to deal with the pressures of being the parent of one, two or three children.\n\n*Source: Reading and Study Skills, by John Langan.*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7804,
        "content": [
          "Disagreement between spouses"
        ],
        "isCorrect": false
      },
      {
        "id": 7805,
        "content": [
          "Doing a job one is not interested in"
        ],
        "isCorrect": true
      },
      {
        "id": 7806,
        "content": [
          "Failure to afford a living"
        ],
        "isCorrect": false
      },
      {
        "id": 7807,
        "content": [
          "Loneliness and isolated life"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1950,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Why do mothers move to large city apartment complexes or suburban communities?"
    ],
    "explanation": [
      "The passage does not explicitly state why mothers move to these places, but it describes them as being \"further away from their families and the emotional support which they provide.\" This implies a move towards a more independent, albeit isolated, life. The other options are not supported by the text."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 40,
    "groupIndex": null,
    "sharedContentId": 13,
    "sharedContent": [
      "1. Child abuse is a phenomenon that knows no social, geographic or racial boundaries. It occurs in the best of families in wealthy suburbs and in rural areas as well. It is, in fact, a national **plague** that experts say is likely to create another generation of child abusers in America from among those being abused today.\n2. For years, the problem was hidden behind the closed doors of houses or apartments. But, since the passage of laws in the 1970s requiring health and other professionals to report all cases of suspected abuse, a quiet revolution has been occurring. More cases of child abuse are being reported, and social-welfare agencies are getting help for both the children and **their** parents. That is not to say, however, that the reporting is in any way complete. More than 5,000 cases are reported annually to the Philadelphia County Children and Youth Agency, but a spokeswoman said, \"There's a lot more out there that goes unreported.\" Schools are just now beginning to focus on abuse, the spokeswoman said. \"Out of the quarter-million kids within the Philadelphia schools, we received only 300 reports last year. However, the schools are making strides in this area,\" she said. To increase the frequency of reporting, institutions that come into contact with injured children are training staff members to recognize abuse. The tremendous amount of stress in today's society both within and outside the home is considered one of the main factors in the rise of child abuse.\n3. Poor marital relationships, single parenthood, social and economic problems, unemployment and social isolation add undue stress to our lives. The problem of social isolation is critical. Today, people are moving around and finding themselves living further away from their families and the emotional support which they provide. Mothers find themselves living either in large city apartment complexes or suburban communities in which they know absolutely no one. In this lonely atmosphere, they try to deal with the pressures of being the parent of one, two or three children.\n\n*Source: Reading and Study Skills, by John Langan.*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7808,
        "content": [
          "That allows them to live independently."
        ],
        "isCorrect": true
      },
      {
        "id": 7809,
        "content": [
          "That is where they can keep their children."
        ],
        "isCorrect": false
      },
      {
        "id": 7810,
        "content": [
          "That is what they can afford."
        ],
        "isCorrect": false
      },
      {
        "id": 7811,
        "content": [
          "Such places are luxurious to live in."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1951,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What does the first sentence in Paragraph 1 mean?"
    ],
    "explanation": [
      "The sentence states that child abuse \"knows no social, geographic or racial boundaries.\" This means it can happen anywhere, to anyone, in any social class or race, making it a universal problem."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 40,
    "groupIndex": null,
    "sharedContentId": 13,
    "sharedContent": [
      "1. Child abuse is a phenomenon that knows no social, geographic or racial boundaries. It occurs in the best of families in wealthy suburbs and in rural areas as well. It is, in fact, a national **plague** that experts say is likely to create another generation of child abusers in America from among those being abused today.\n2. For years, the problem was hidden behind the closed doors of houses or apartments. But, since the passage of laws in the 1970s requiring health and other professionals to report all cases of suspected abuse, a quiet revolution has been occurring. More cases of child abuse are being reported, and social-welfare agencies are getting help for both the children and **their** parents. That is not to say, however, that the reporting is in any way complete. More than 5,000 cases are reported annually to the Philadelphia County Children and Youth Agency, but a spokeswoman said, \"There's a lot more out there that goes unreported.\" Schools are just now beginning to focus on abuse, the spokeswoman said. \"Out of the quarter-million kids within the Philadelphia schools, we received only 300 reports last year. However, the schools are making strides in this area,\" she said. To increase the frequency of reporting, institutions that come into contact with injured children are training staff members to recognize abuse. The tremendous amount of stress in today's society both within and outside the home is considered one of the main factors in the rise of child abuse.\n3. Poor marital relationships, single parenthood, social and economic problems, unemployment and social isolation add undue stress to our lives. The problem of social isolation is critical. Today, people are moving around and finding themselves living further away from their families and the emotional support which they provide. Mothers find themselves living either in large city apartment complexes or suburban communities in which they know absolutely no one. In this lonely atmosphere, they try to deal with the pressures of being the parent of one, two or three children.\n\n*Source: Reading and Study Skills, by John Langan.*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7812,
        "content": [
          "Whether young or old, you are always abused."
        ],
        "isCorrect": false
      },
      {
        "id": 7813,
        "content": [
          "Some races in the world do not practice child abuse."
        ],
        "isCorrect": false
      },
      {
        "id": 7814,
        "content": [
          "Child abuse should not be practiced."
        ],
        "isCorrect": false
      },
      {
        "id": 7815,
        "content": [
          "Child abuse is everywhere regardless."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1952,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What does the writer specifically say about America in relation to child abuse?"
    ],
    "explanation": [
      "Paragraph 1 says the national plague \"is likely to create another generation of child abusers in America from among those being abused today,\" which directly supports this statement."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 40,
    "groupIndex": null,
    "sharedContentId": 13,
    "sharedContent": [
      "1. Child abuse is a phenomenon that knows no social, geographic or racial boundaries. It occurs in the best of families in wealthy suburbs and in rural areas as well. It is, in fact, a national **plague** that experts say is likely to create another generation of child abusers in America from among those being abused today.\n2. For years, the problem was hidden behind the closed doors of houses or apartments. But, since the passage of laws in the 1970s requiring health and other professionals to report all cases of suspected abuse, a quiet revolution has been occurring. More cases of child abuse are being reported, and social-welfare agencies are getting help for both the children and **their** parents. That is not to say, however, that the reporting is in any way complete. More than 5,000 cases are reported annually to the Philadelphia County Children and Youth Agency, but a spokeswoman said, \"There's a lot more out there that goes unreported.\" Schools are just now beginning to focus on abuse, the spokeswoman said. \"Out of the quarter-million kids within the Philadelphia schools, we received only 300 reports last year. However, the schools are making strides in this area,\" she said. To increase the frequency of reporting, institutions that come into contact with injured children are training staff members to recognize abuse. The tremendous amount of stress in today's society both within and outside the home is considered one of the main factors in the rise of child abuse.\n3. Poor marital relationships, single parenthood, social and economic problems, unemployment and social isolation add undue stress to our lives. The problem of social isolation is critical. Today, people are moving around and finding themselves living further away from their families and the emotional support which they provide. Mothers find themselves living either in large city apartment complexes or suburban communities in which they know absolutely no one. In this lonely atmosphere, they try to deal with the pressures of being the parent of one, two or three children.\n\n*Source: Reading and Study Skills, by John Langan.*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7816,
        "content": [
          "American children abused today and will abuse others when they grow up."
        ],
        "isCorrect": true
      },
      {
        "id": 7817,
        "content": [
          "Americans are intentionally creating another generation of child abusers."
        ],
        "isCorrect": false
      },
      {
        "id": 7818,
        "content": [
          "Tomorrow's America will see less child abuse."
        ],
        "isCorrect": false
      },
      {
        "id": 7819,
        "content": [
          "Wealthy Americans are the main actors in child abuse."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1953,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which one of the following is closest in meaning to the word '**plague**' in Paragraph 1, Line 3?"
    ],
    "explanation": [
      "A 'plague' is used metaphorically here to describe something that causes widespread trouble or suffering, much like a widespread disease. An 'epidemic', which is a widespread occurrence of an infectious disease in a community at a particular time, is the closest synonym in this context."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 40,
    "groupIndex": null,
    "sharedContentId": 13,
    "sharedContent": [
      "1. Child abuse is a phenomenon that knows no social, geographic or racial boundaries. It occurs in the best of families in wealthy suburbs and in rural areas as well. It is, in fact, a national **plague** that experts say is likely to create another generation of child abusers in America from among those being abused today.\n2. For years, the problem was hidden behind the closed doors of houses or apartments. But, since the passage of laws in the 1970s requiring health and other professionals to report all cases of suspected abuse, a quiet revolution has been occurring. More cases of child abuse are being reported, and social-welfare agencies are getting help for both the children and **their** parents. That is not to say, however, that the reporting is in any way complete. More than 5,000 cases are reported annually to the Philadelphia County Children and Youth Agency, but a spokeswoman said, \"There's a lot more out there that goes unreported.\" Schools are just now beginning to focus on abuse, the spokeswoman said. \"Out of the quarter-million kids within the Philadelphia schools, we received only 300 reports last year. However, the schools are making strides in this area,\" she said. To increase the frequency of reporting, institutions that come into contact with injured children are training staff members to recognize abuse. The tremendous amount of stress in today's society both within and outside the home is considered one of the main factors in the rise of child abuse.\n3. Poor marital relationships, single parenthood, social and economic problems, unemployment and social isolation add undue stress to our lives. The problem of social isolation is critical. Today, people are moving around and finding themselves living further away from their families and the emotional support which they provide. Mothers find themselves living either in large city apartment complexes or suburban communities in which they know absolutely no one. In this lonely atmosphere, they try to deal with the pressures of being the parent of one, two or three children.\n\n*Source: Reading and Study Skills, by John Langan.*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7820,
        "content": [
          "infection"
        ],
        "isCorrect": false
      },
      {
        "id": 7821,
        "content": [
          "epidemic"
        ],
        "isCorrect": true
      },
      {
        "id": 7822,
        "content": [
          "torture"
        ],
        "isCorrect": false
      },
      {
        "id": 7823,
        "content": [
          "wound"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1954,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which one of the following sentences is true about child abuse?"
    ],
    "explanation": [
      "Paragraph 2 states, \"For years, the problem was hidden behind the closed doors of houses or apartments.\" This directly supports the idea that the abuse was carried out secretly for a long time."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 40,
    "groupIndex": null,
    "sharedContentId": 13,
    "sharedContent": [
      "1. Child abuse is a phenomenon that knows no social, geographic or racial boundaries. It occurs in the best of families in wealthy suburbs and in rural areas as well. It is, in fact, a national **plague** that experts say is likely to create another generation of child abusers in America from among those being abused today.\n2. For years, the problem was hidden behind the closed doors of houses or apartments. But, since the passage of laws in the 1970s requiring health and other professionals to report all cases of suspected abuse, a quiet revolution has been occurring. More cases of child abuse are being reported, and social-welfare agencies are getting help for both the children and **their** parents. That is not to say, however, that the reporting is in any way complete. More than 5,000 cases are reported annually to the Philadelphia County Children and Youth Agency, but a spokeswoman said, \"There's a lot more out there that goes unreported.\" Schools are just now beginning to focus on abuse, the spokeswoman said. \"Out of the quarter-million kids within the Philadelphia schools, we received only 300 reports last year. However, the schools are making strides in this area,\" she said. To increase the frequency of reporting, institutions that come into contact with injured children are training staff members to recognize abuse. The tremendous amount of stress in today's society both within and outside the home is considered one of the main factors in the rise of child abuse.\n3. Poor marital relationships, single parenthood, social and economic problems, unemployment and social isolation add undue stress to our lives. The problem of social isolation is critical. Today, people are moving around and finding themselves living further away from their families and the emotional support which they provide. Mothers find themselves living either in large city apartment complexes or suburban communities in which they know absolutely no one. In this lonely atmosphere, they try to deal with the pressures of being the parent of one, two or three children.\n\n*Source: Reading and Study Skills, by John Langan.*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7824,
        "content": [
          "Many people stood against child abuse after reading passages in laws."
        ],
        "isCorrect": false
      },
      {
        "id": 7825,
        "content": [
          "Initially, Americans remained quiet on the revolution against child abuse."
        ],
        "isCorrect": false
      },
      {
        "id": 7826,
        "content": [
          "Child abuse was exercised secretly for a very long time."
        ],
        "isCorrect": true
      },
      {
        "id": 7827,
        "content": [
          "Parents for long used to close their doors and abuse children."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1955,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What does '**their**' as used in Paragraph 2, Line 5 refer to?"
    ],
    "explanation": [
      "The sentence reads, \"...welfare agencies are getting help for both the children and their parents.\" The pronoun 'their' refers back to the noun 'children,' indicating the parents belong to the children."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 40,
    "groupIndex": null,
    "sharedContentId": 13,
    "sharedContent": [
      "1. Child abuse is a phenomenon that knows no social, geographic or racial boundaries. It occurs in the best of families in wealthy suburbs and in rural areas as well. It is, in fact, a national **plague** that experts say is likely to create another generation of child abusers in America from among those being abused today.\n2. For years, the problem was hidden behind the closed doors of houses or apartments. But, since the passage of laws in the 1970s requiring health and other professionals to report all cases of suspected abuse, a quiet revolution has been occurring. More cases of child abuse are being reported, and social-welfare agencies are getting help for both the children and **their** parents. That is not to say, however, that the reporting is in any way complete. More than 5,000 cases are reported annually to the Philadelphia County Children and Youth Agency, but a spokeswoman said, \"There's a lot more out there that goes unreported.\" Schools are just now beginning to focus on abuse, the spokeswoman said. \"Out of the quarter-million kids within the Philadelphia schools, we received only 300 reports last year. However, the schools are making strides in this area,\" she said. To increase the frequency of reporting, institutions that come into contact with injured children are training staff members to recognize abuse. The tremendous amount of stress in today's society both within and outside the home is considered one of the main factors in the rise of child abuse.\n3. Poor marital relationships, single parenthood, social and economic problems, unemployment and social isolation add undue stress to our lives. The problem of social isolation is critical. Today, people are moving around and finding themselves living further away from their families and the emotional support which they provide. Mothers find themselves living either in large city apartment complexes or suburban communities in which they know absolutely no one. In this lonely atmosphere, they try to deal with the pressures of being the parent of one, two or three children.\n\n*Source: Reading and Study Skills, by John Langan.*"
    ],
    "images": [],
    "choices": [
      {
        "id": 7828,
        "content": [
          "children"
        ],
        "isCorrect": true
      },
      {
        "id": 7829,
        "content": [
          "reporters"
        ],
        "isCorrect": false
      },
      {
        "id": 7830,
        "content": [
          "parents"
        ],
        "isCorrect": false
      },
      {
        "id": 7831,
        "content": [
          "agencies"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1973,
    "content": [
      "Choose the statement that is correctly punctuated and capitalized."
    ],
    "explanation": [
      "A colon is correctly used after the phrase \"the following\" to introduce a list of items. The items in the list are correctly separated by commas."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 45,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7900,
        "content": [
          "If you go to Merkato, you'll need to buy the following: a shirt, a jacket and a coat."
        ],
        "isCorrect": true
      },
      {
        "id": 7901,
        "content": [
          "If you go to Merkato, you'll need to buy the following a shirt, a jacket: and a coat."
        ],
        "isCorrect": false
      },
      {
        "id": 7902,
        "content": [
          "If you go to Merkato, you'll need to buy: the following, a shirt, a jacket, and a coat."
        ],
        "isCorrect": false
      },
      {
        "id": 7903,
        "content": [
          "If you go to Merkato, you'll need to buy the following, a shirt: a jacket: and a coat."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1974,
    "content": [
      "Choose the statement that is correctly punctuated and capitalized."
    ],
    "explanation": [
      "Proper nouns, including the full names of specific geographical locations and establishments like \"Sor River\" and \"Khalifa Hotel,\" must be capitalized."
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 45,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7904,
        "content": [
          "When he went to visit the Sor River, he stayed at Khalifa hotel in Metu."
        ],
        "isCorrect": false
      },
      {
        "id": 7905,
        "content": [
          "When he went to visit the Sor River, he stayed at Khalifa Hotel in Metu."
        ],
        "isCorrect": true
      },
      {
        "id": 7906,
        "content": [
          "When he went to visit the Sor river, he stayed at Khalifa Hotel in Metu."
        ],
        "isCorrect": false
      },
      {
        "id": 7907,
        "content": [
          "When he went to visit the Sor river, he stayed at Khalifa Hotel in Metu."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1975,
    "content": [
      "Choose the statement that is correctly punctuated and capitalized."
    ],
    "explanation": [
      "The sentence correctly places the exclamation mark inside the quotation marks and uses a comma before the direct quote introduced by a verb of speaking like \"shouted.\""
    ],
    "year": "YEAR_2016",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 45,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7908,
        "content": [
          "\"What is for lunch\"? he asked."
        ],
        "isCorrect": false
      },
      {
        "id": 7909,
        "content": [
          "Martha shouted, \"Leave me alone!\""
        ],
        "isCorrect": true
      },
      {
        "id": 7910,
        "content": [
          "\"Come here, she said\"."
        ],
        "isCorrect": false
      },
      {
        "id": 7911,
        "content": [
          "I read \"Romeo and Juliet.\""
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2028,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "The fact that the composition of air is constant all over the world is an indicator of how ______"
    ],
    "explanation": [
      "The passage mentions that it is \"fortunately\" that the air's composition is constant. This consistency is presented as a fundamental and beneficial aspect of how the natural world functions."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 52,
    "groupIndex": null,
    "sharedContentId": 14,
    "sharedContent": [
      "1. Air pollution is an issue which concerns us all alike. One can willingly choose or reject a food, a drink or a life comfort, but unfortunately there is little choice for the air we breathe. All, what is there in the air is inhaled by one and all living in those surroundings.\n2. Air pollutant is defined as a substance which is present while normally it is not there or present in an amount exceeding the normal concentrations. It could either be gaseous or a particulate matter. The major harmful polluting gases are carbon monoxide, carbon dioxide, ozone and oxides of sulphur and nitrogen. The common particulate pollutants are the dusts of various inorganic or organic origins. Although we often talk of the outdoor air pollution caused by industrial and vehicular exhausts, the indoor pollution may prove to be as or a more serious cause of health problems.\n3. Recognition of air pollution is relatively recent. It is not uncommon to experience a feeling of ‘suffocation’ in a closed environment, which is often ascribed to the lack of oxygen. Fortunately, however, the composition of air is remarkably constant all over the world. There is about 79 per cent nitrogen and 21 per cent oxygen in the air, the other gases forming a very small fraction. It is true that carbon dioxide exhaled out of lungs may accumulate in a closed and overcrowded place. But such an increase is usually small and temporary unless the room is really airtight. Exposure to poisonous gases such as carbon monoxide may occur in a closed room, heated by burning coal inside. This may also prove to be fatal.\n4. What is more common in a poorly ventilated home is a vague constellation of symptoms described as the sick building syndrome. It is characterized by a general feeling of malaise, headache, dizziness and irritation of mucous membranes. It may also be accompanied by nausea, itching, aches, pains and depression. Sick building syndrome is getting commoner in big cities with small houses which are generally over-furnished. Some of the major pollutants whose indoor concentrations exceed those of the outdoor include gases such as carbon monoxide, carbon dioxide, oxides of nitrogen and organic substances like spores, formaldehydes, hydrocarbon aerosols and allergens. The sources are attributed to a variety of construction materials, insulations, furnishings, adhesives, cosmetics, house dusts, fungi and other indoor products.\n5. Obviously, the spectrum of pollution is very wide and our options are limited. Indoor pollution may be handled relatively easily by an individual. Moreover, the good work must start from one's own house.\n\nAdapted from https://www.learncbse.in/reading-comprchension"
    ],
    "images": [],
    "choices": [
      {
        "id": 8120,
        "content": [
          "nature is uniform."
        ],
        "isCorrect": false
      },
      {
        "id": 8121,
        "content": [
          "nature works."
        ],
        "isCorrect": true
      },
      {
        "id": 8122,
        "content": [
          "we should change the nature."
        ],
        "isCorrect": false
      },
      {
        "id": 8123,
        "content": [
          "nature is stagnant."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2029,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "Air pollutant is said to be present when ______"
    ],
    "explanation": [
      "The passage defines an air pollutant as a substance \"present in an amount exceeding the normal concentrations.\" Since the air is normally 79% nitrogen, an excess of it would fit this definition."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 52,
    "groupIndex": null,
    "sharedContentId": 14,
    "sharedContent": [
      "1. Air pollution is an issue which concerns us all alike. One can willingly choose or reject a food, a drink or a life comfort, but unfortunately there is little choice for the air we breathe. All, what is there in the air is inhaled by one and all living in those surroundings.\n2. Air pollutant is defined as a substance which is present while normally it is not there or present in an amount exceeding the normal concentrations. It could either be gaseous or a particulate matter. The major harmful polluting gases are carbon monoxide, carbon dioxide, ozone and oxides of sulphur and nitrogen. The common particulate pollutants are the dusts of various inorganic or organic origins. Although we often talk of the outdoor air pollution caused by industrial and vehicular exhausts, the indoor pollution may prove to be as or a more serious cause of health problems.\n3. Recognition of air pollution is relatively recent. It is not uncommon to experience a feeling of ‘suffocation’ in a closed environment, which is often ascribed to the lack of oxygen. Fortunately, however, the composition of air is remarkably constant all over the world. There is about 79 per cent nitrogen and 21 per cent oxygen in the air, the other gases forming a very small fraction. It is true that carbon dioxide exhaled out of lungs may accumulate in a closed and overcrowded place. But such an increase is usually small and temporary unless the room is really airtight. Exposure to poisonous gases such as carbon monoxide may occur in a closed room, heated by burning coal inside. This may also prove to be fatal.\n4. What is more common in a poorly ventilated home is a vague constellation of symptoms described as the sick building syndrome. It is characterized by a general feeling of malaise, headache, dizziness and irritation of mucous membranes. It may also be accompanied by nausea, itching, aches, pains and depression. Sick building syndrome is getting commoner in big cities with small houses which are generally over-furnished. Some of the major pollutants whose indoor concentrations exceed those of the outdoor include gases such as carbon monoxide, carbon dioxide, oxides of nitrogen and organic substances like spores, formaldehydes, hydrocarbon aerosols and allergens. The sources are attributed to a variety of construction materials, insulations, furnishings, adhesives, cosmetics, house dusts, fungi and other indoor products.\n5. Obviously, the spectrum of pollution is very wide and our options are limited. Indoor pollution may be handled relatively easily by an individual. Moreover, the good work must start from one's own house.\n\nAdapted from https://www.learncbse.in/reading-comprchension"
    ],
    "images": [],
    "choices": [
      {
        "id": 8124,
        "content": [
          "We release carbon dioxide"
        ],
        "isCorrect": false
      },
      {
        "id": 8125,
        "content": [
          "There is excess nitrogen"
        ],
        "isCorrect": true
      },
      {
        "id": 8126,
        "content": [
          "There is excess oxygen"
        ],
        "isCorrect": false
      },
      {
        "id": 8127,
        "content": [
          "We feel suffocated during breathing"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2030,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "The writer of the passage thinks that ______"
    ],
    "explanation": [
      "The final paragraph explicitly states, \"Indoor pollution may be handled relatively easily by an individual. Moreover, the good work must start from one's own house.\" This shows the writer's belief in individual contribution."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 52,
    "groupIndex": null,
    "sharedContentId": 14,
    "sharedContent": [
      "1. Air pollution is an issue which concerns us all alike. One can willingly choose or reject a food, a drink or a life comfort, but unfortunately there is little choice for the air we breathe. All, what is there in the air is inhaled by one and all living in those surroundings.\n2. Air pollutant is defined as a substance which is present while normally it is not there or present in an amount exceeding the normal concentrations. It could either be gaseous or a particulate matter. The major harmful polluting gases are carbon monoxide, carbon dioxide, ozone and oxides of sulphur and nitrogen. The common particulate pollutants are the dusts of various inorganic or organic origins. Although we often talk of the outdoor air pollution caused by industrial and vehicular exhausts, the indoor pollution may prove to be as or a more serious cause of health problems.\n3. Recognition of air pollution is relatively recent. It is not uncommon to experience a feeling of ‘suffocation’ in a closed environment, which is often ascribed to the lack of oxygen. Fortunately, however, the composition of air is remarkably constant all over the world. There is about 79 per cent nitrogen and 21 per cent oxygen in the air, the other gases forming a very small fraction. It is true that carbon dioxide exhaled out of lungs may accumulate in a closed and overcrowded place. But such an increase is usually small and temporary unless the room is really airtight. Exposure to poisonous gases such as carbon monoxide may occur in a closed room, heated by burning coal inside. This may also prove to be fatal.\n4. What is more common in a poorly ventilated home is a vague constellation of symptoms described as the sick building syndrome. It is characterized by a general feeling of malaise, headache, dizziness and irritation of mucous membranes. It may also be accompanied by nausea, itching, aches, pains and depression. Sick building syndrome is getting commoner in big cities with small houses which are generally over-furnished. Some of the major pollutants whose indoor concentrations exceed those of the outdoor include gases such as carbon monoxide, carbon dioxide, oxides of nitrogen and organic substances like spores, formaldehydes, hydrocarbon aerosols and allergens. The sources are attributed to a variety of construction materials, insulations, furnishings, adhesives, cosmetics, house dusts, fungi and other indoor products.\n5. Obviously, the spectrum of pollution is very wide and our options are limited. Indoor pollution may be handled relatively easily by an individual. Moreover, the good work must start from one's own house.\n\nAdapted from https://www.learncbse.in/reading-comprchension"
    ],
    "images": [],
    "choices": [
      {
        "id": 8128,
        "content": [
          "we can fully control air pollution."
        ],
        "isCorrect": false
      },
      {
        "id": 8129,
        "content": [
          "the scale of pollution is too wide to handle in our present capacity."
        ],
        "isCorrect": false
      },
      {
        "id": 8130,
        "content": [
          "our understanding of air pollution is low."
        ],
        "isCorrect": false
      },
      {
        "id": 8131,
        "content": [
          "individuals can contribute to handling indoor air pollution."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2031,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "A feeling of suffocation ______"
    ],
    "explanation": [
      "The passage introduces the feeling of suffocation in the context of air pollution, mentioning it happens in closed environments and is \"not uncommon,\" directly linking it to pollution."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 52,
    "groupIndex": null,
    "sharedContentId": 14,
    "sharedContent": [
      "1. Air pollution is an issue which concerns us all alike. One can willingly choose or reject a food, a drink or a life comfort, but unfortunately there is little choice for the air we breathe. All, what is there in the air is inhaled by one and all living in those surroundings.\n2. Air pollutant is defined as a substance which is present while normally it is not there or present in an amount exceeding the normal concentrations. It could either be gaseous or a particulate matter. The major harmful polluting gases are carbon monoxide, carbon dioxide, ozone and oxides of sulphur and nitrogen. The common particulate pollutants are the dusts of various inorganic or organic origins. Although we often talk of the outdoor air pollution caused by industrial and vehicular exhausts, the indoor pollution may prove to be as or a more serious cause of health problems.\n3. Recognition of air pollution is relatively recent. It is not uncommon to experience a feeling of ‘suffocation’ in a closed environment, which is often ascribed to the lack of oxygen. Fortunately, however, the composition of air is remarkably constant all over the world. There is about 79 per cent nitrogen and 21 per cent oxygen in the air, the other gases forming a very small fraction. It is true that carbon dioxide exhaled out of lungs may accumulate in a closed and overcrowded place. But such an increase is usually small and temporary unless the room is really airtight. Exposure to poisonous gases such as carbon monoxide may occur in a closed room, heated by burning coal inside. This may also prove to be fatal.\n4. What is more common in a poorly ventilated home is a vague constellation of symptoms described as the sick building syndrome. It is characterized by a general feeling of malaise, headache, dizziness and irritation of mucous membranes. It may also be accompanied by nausea, itching, aches, pains and depression. Sick building syndrome is getting commoner in big cities with small houses which are generally over-furnished. Some of the major pollutants whose indoor concentrations exceed those of the outdoor include gases such as carbon monoxide, carbon dioxide, oxides of nitrogen and organic substances like spores, formaldehydes, hydrocarbon aerosols and allergens. The sources are attributed to a variety of construction materials, insulations, furnishings, adhesives, cosmetics, house dusts, fungi and other indoor products.\n5. Obviously, the spectrum of pollution is very wide and our options are limited. Indoor pollution may be handled relatively easily by an individual. Moreover, the good work must start from one's own house.\n\nAdapted from https://www.learncbse.in/reading-comprchension"
    ],
    "images": [],
    "choices": [
      {
        "id": 8132,
        "content": [
          "has nothing to do with pollution."
        ],
        "isCorrect": false
      },
      {
        "id": 8133,
        "content": [
          "is a human nature."
        ],
        "isCorrect": false
      },
      {
        "id": 8134,
        "content": [
          "is an indication of pollution."
        ],
        "isCorrect": true
      },
      {
        "id": 8135,
        "content": [
          "is a rare occurrence."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2032,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "It is NOT stated in the passage that ______"
    ],
    "explanation": [
      "The passage explicitly states that air pollution is an issue that \"concerns us all alike,\" which is the opposite of affecting us all in different ways. Therefore, this statement is not in the passage."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 52,
    "groupIndex": null,
    "sharedContentId": 14,
    "sharedContent": [
      "1. Air pollution is an issue which concerns us all alike. One can willingly choose or reject a food, a drink or a life comfort, but unfortunately there is little choice for the air we breathe. All, what is there in the air is inhaled by one and all living in those surroundings.\n2. Air pollutant is defined as a substance which is present while normally it is not there or present in an amount exceeding the normal concentrations. It could either be gaseous or a particulate matter. The major harmful polluting gases are carbon monoxide, carbon dioxide, ozone and oxides of sulphur and nitrogen. The common particulate pollutants are the dusts of various inorganic or organic origins. Although we often talk of the outdoor air pollution caused by industrial and vehicular exhausts, the indoor pollution may prove to be as or a more serious cause of health problems.\n3. Recognition of air pollution is relatively recent. It is not uncommon to experience a feeling of ‘suffocation’ in a closed environment, which is often ascribed to the lack of oxygen. Fortunately, however, the composition of air is remarkably constant all over the world. There is about 79 per cent nitrogen and 21 per cent oxygen in the air, the other gases forming a very small fraction. It is true that carbon dioxide exhaled out of lungs may accumulate in a closed and overcrowded place. But such an increase is usually small and temporary unless the room is really airtight. Exposure to poisonous gases such as carbon monoxide may occur in a closed room, heated by burning coal inside. This may also prove to be fatal.\n4. What is more common in a poorly ventilated home is a vague constellation of symptoms described as the sick building syndrome. It is characterized by a general feeling of malaise, headache, dizziness and irritation of mucous membranes. It may also be accompanied by nausea, itching, aches, pains and depression. Sick building syndrome is getting commoner in big cities with small houses which are generally over-furnished. Some of the major pollutants whose indoor concentrations exceed those of the outdoor include gases such as carbon monoxide, carbon dioxide, oxides of nitrogen and organic substances like spores, formaldehydes, hydrocarbon aerosols and allergens. The sources are attributed to a variety of construction materials, insulations, furnishings, adhesives, cosmetics, house dusts, fungi and other indoor products.\n5. Obviously, the spectrum of pollution is very wide and our options are limited. Indoor pollution may be handled relatively easily by an individual. Moreover, the good work must start from one's own house.\n\nAdapted from https://www.learncbse.in/reading-comprchension"
    ],
    "images": [],
    "choices": [
      {
        "id": 8136,
        "content": [
          "choosing what we eat or drink can give us life comfort."
        ],
        "isCorrect": false
      },
      {
        "id": 8137,
        "content": [
          "we have no role in the air we breathe."
        ],
        "isCorrect": false
      },
      {
        "id": 8138,
        "content": [
          "air pollution affects us all in different ways."
        ],
        "isCorrect": true
      },
      {
        "id": 8139,
        "content": [
          "we can choose or reject a food, a drink or a life comfort when we have the chance."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2033,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "The accumulation of carbon dioxide exhaled from lungs ______"
    ],
    "explanation": [
      "Paragraph 3 states that an increase in exhaled carbon dioxide is \"usually small and temporary unless the room is really airtight,\" and that exposure to poisonous gases in a closed room \"may also prove to be fatal.\" Combining these ideas, a significant accumulation in an airtight room could be dangerous."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 52,
    "groupIndex": null,
    "sharedContentId": 14,
    "sharedContent": [
      "1. Air pollution is an issue which concerns us all alike. One can willingly choose or reject a food, a drink or a life comfort, but unfortunately there is little choice for the air we breathe. All, what is there in the air is inhaled by one and all living in those surroundings.\n2. Air pollutant is defined as a substance which is present while normally it is not there or present in an amount exceeding the normal concentrations. It could either be gaseous or a particulate matter. The major harmful polluting gases are carbon monoxide, carbon dioxide, ozone and oxides of sulphur and nitrogen. The common particulate pollutants are the dusts of various inorganic or organic origins. Although we often talk of the outdoor air pollution caused by industrial and vehicular exhausts, the indoor pollution may prove to be as or a more serious cause of health problems.\n3. Recognition of air pollution is relatively recent. It is not uncommon to experience a feeling of ‘suffocation’ in a closed environment, which is often ascribed to the lack of oxygen. Fortunately, however, the composition of air is remarkably constant all over the world. There is about 79 per cent nitrogen and 21 per cent oxygen in the air, the other gases forming a very small fraction. It is true that carbon dioxide exhaled out of lungs may accumulate in a closed and overcrowded place. But such an increase is usually small and temporary unless the room is really airtight. Exposure to poisonous gases such as carbon monoxide may occur in a closed room, heated by burning coal inside. This may also prove to be fatal.\n4. What is more common in a poorly ventilated home is a vague constellation of symptoms described as the sick building syndrome. It is characterized by a general feeling of malaise, headache, dizziness and irritation of mucous membranes. It may also be accompanied by nausea, itching, aches, pains and depression. Sick building syndrome is getting commoner in big cities with small houses which are generally over-furnished. Some of the major pollutants whose indoor concentrations exceed those of the outdoor include gases such as carbon monoxide, carbon dioxide, oxides of nitrogen and organic substances like spores, formaldehydes, hydrocarbon aerosols and allergens. The sources are attributed to a variety of construction materials, insulations, furnishings, adhesives, cosmetics, house dusts, fungi and other indoor products.\n5. Obviously, the spectrum of pollution is very wide and our options are limited. Indoor pollution may be handled relatively easily by an individual. Moreover, the good work must start from one's own house.\n\nAdapted from https://www.learncbse.in/reading-comprchension"
    ],
    "images": [],
    "choices": [
      {
        "id": 8140,
        "content": [
          "is the same in all places."
        ],
        "isCorrect": false
      },
      {
        "id": 8141,
        "content": [
          "could result in series illness and death."
        ],
        "isCorrect": false
      },
      {
        "id": 8142,
        "content": [
          "increases in an airtight room and could cause suffocation."
        ],
        "isCorrect": true
      },
      {
        "id": 8143,
        "content": [
          "is smaller and temporary in airtight rooms."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2034,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "An appropriate title for the passage could be ______"
    ],
    "explanation": [
      "The passage discusses various sources of pollution (industrial, indoor, burning coal) and its effects (suffocation, sick building syndrome, fatal exposure), making \"Causes and effects of air pollution\" the most comprehensive title."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 52,
    "groupIndex": null,
    "sharedContentId": 14,
    "sharedContent": [
      "1. Air pollution is an issue which concerns us all alike. One can willingly choose or reject a food, a drink or a life comfort, but unfortunately there is little choice for the air we breathe. All, what is there in the air is inhaled by one and all living in those surroundings.\n2. Air pollutant is defined as a substance which is present while normally it is not there or present in an amount exceeding the normal concentrations. It could either be gaseous or a particulate matter. The major harmful polluting gases are carbon monoxide, carbon dioxide, ozone and oxides of sulphur and nitrogen. The common particulate pollutants are the dusts of various inorganic or organic origins. Although we often talk of the outdoor air pollution caused by industrial and vehicular exhausts, the indoor pollution may prove to be as or a more serious cause of health problems.\n3. Recognition of air pollution is relatively recent. It is not uncommon to experience a feeling of ‘suffocation’ in a closed environment, which is often ascribed to the lack of oxygen. Fortunately, however, the composition of air is remarkably constant all over the world. There is about 79 per cent nitrogen and 21 per cent oxygen in the air, the other gases forming a very small fraction. It is true that carbon dioxide exhaled out of lungs may accumulate in a closed and overcrowded place. But such an increase is usually small and temporary unless the room is really airtight. Exposure to poisonous gases such as carbon monoxide may occur in a closed room, heated by burning coal inside. This may also prove to be fatal.\n4. What is more common in a poorly ventilated home is a vague constellation of symptoms described as the sick building syndrome. It is characterized by a general feeling of malaise, headache, dizziness and irritation of mucous membranes. It may also be accompanied by nausea, itching, aches, pains and depression. Sick building syndrome is getting commoner in big cities with small houses which are generally over-furnished. Some of the major pollutants whose indoor concentrations exceed those of the outdoor include gases such as carbon monoxide, carbon dioxide, oxides of nitrogen and organic substances like spores, formaldehydes, hydrocarbon aerosols and allergens. The sources are attributed to a variety of construction materials, insulations, furnishings, adhesives, cosmetics, house dusts, fungi and other indoor products.\n5. Obviously, the spectrum of pollution is very wide and our options are limited. Indoor pollution may be handled relatively easily by an individual. Moreover, the good work must start from one's own house.\n\nAdapted from https://www.learncbse.in/reading-comprchension"
    ],
    "images": [],
    "choices": [
      {
        "id": 8144,
        "content": [
          "Human contribution to air pollution"
        ],
        "isCorrect": false
      },
      {
        "id": 8145,
        "content": [
          "How to tackle air pollution"
        ],
        "isCorrect": false
      },
      {
        "id": 8146,
        "content": [
          "Causes and effects of air pollution"
        ],
        "isCorrect": true
      },
      {
        "id": 8147,
        "content": [
          "Types of pollution"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2035,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "Which one of the following is NOT true according to the passage?"
    ],
    "explanation": [
      "The passage identifies industrial and vehicular exhausts as causes of \"outdoor air pollution,\" not indoor pollution. Indoor pollution sources are listed as construction materials, furnishings, etc."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 52,
    "groupIndex": null,
    "sharedContentId": 14,
    "sharedContent": [
      "1. Air pollution is an issue which concerns us all alike. One can willingly choose or reject a food, a drink or a life comfort, but unfortunately there is little choice for the air we breathe. All, what is there in the air is inhaled by one and all living in those surroundings.\n2. Air pollutant is defined as a substance which is present while normally it is not there or present in an amount exceeding the normal concentrations. It could either be gaseous or a particulate matter. The major harmful polluting gases are carbon monoxide, carbon dioxide, ozone and oxides of sulphur and nitrogen. The common particulate pollutants are the dusts of various inorganic or organic origins. Although we often talk of the outdoor air pollution caused by industrial and vehicular exhausts, the indoor pollution may prove to be as or a more serious cause of health problems.\n3. Recognition of air pollution is relatively recent. It is not uncommon to experience a feeling of ‘suffocation’ in a closed environment, which is often ascribed to the lack of oxygen. Fortunately, however, the composition of air is remarkably constant all over the world. There is about 79 per cent nitrogen and 21 per cent oxygen in the air, the other gases forming a very small fraction. It is true that carbon dioxide exhaled out of lungs may accumulate in a closed and overcrowded place. But such an increase is usually small and temporary unless the room is really airtight. Exposure to poisonous gases such as carbon monoxide may occur in a closed room, heated by burning coal inside. This may also prove to be fatal.\n4. What is more common in a poorly ventilated home is a vague constellation of symptoms described as the sick building syndrome. It is characterized by a general feeling of malaise, headache, dizziness and irritation of mucous membranes. It may also be accompanied by nausea, itching, aches, pains and depression. Sick building syndrome is getting commoner in big cities with small houses which are generally over-furnished. Some of the major pollutants whose indoor concentrations exceed those of the outdoor include gases such as carbon monoxide, carbon dioxide, oxides of nitrogen and organic substances like spores, formaldehydes, hydrocarbon aerosols and allergens. The sources are attributed to a variety of construction materials, insulations, furnishings, adhesives, cosmetics, house dusts, fungi and other indoor products.\n5. Obviously, the spectrum of pollution is very wide and our options are limited. Indoor pollution may be handled relatively easily by an individual. Moreover, the good work must start from one's own house.\n\nAdapted from https://www.learncbse.in/reading-comprchension"
    ],
    "images": [],
    "choices": [
      {
        "id": 8148,
        "content": [
          "Our indoor activities contribute to air pollution."
        ],
        "isCorrect": false
      },
      {
        "id": 8149,
        "content": [
          "Industrial and vehicular exhausts are the main sources of indoor air pollution."
        ],
        "isCorrect": true
      },
      {
        "id": 8150,
        "content": [
          "Indoor pollution relatively less than outdoor pollution."
        ],
        "isCorrect": false
      },
      {
        "id": 8151,
        "content": [
          "Human beings cannot manage air pollution."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2036,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "Which one of the following is mentioned as a source of indoor pollutants?"
    ],
    "explanation": [
      "Paragraph 4 explicitly lists \"cosmetics\" as one of the sources for indoor pollutants that contribute to sick building syndrome."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 52,
    "groupIndex": null,
    "sharedContentId": 14,
    "sharedContent": [
      "1. Air pollution is an issue which concerns us all alike. One can willingly choose or reject a food, a drink or a life comfort, but unfortunately there is little choice for the air we breathe. All, what is there in the air is inhaled by one and all living in those surroundings.\n2. Air pollutant is defined as a substance which is present while normally it is not there or present in an amount exceeding the normal concentrations. It could either be gaseous or a particulate matter. The major harmful polluting gases are carbon monoxide, carbon dioxide, ozone and oxides of sulphur and nitrogen. The common particulate pollutants are the dusts of various inorganic or organic origins. Although we often talk of the outdoor air pollution caused by industrial and vehicular exhausts, the indoor pollution may prove to be as or a more serious cause of health problems.\n3. Recognition of air pollution is relatively recent. It is not uncommon to experience a feeling of ‘suffocation’ in a closed environment, which is often ascribed to the lack of oxygen. Fortunately, however, the composition of air is remarkably constant all over the world. There is about 79 per cent nitrogen and 21 per cent oxygen in the air, the other gases forming a very small fraction. It is true that carbon dioxide exhaled out of lungs may accumulate in a closed and overcrowded place. But such an increase is usually small and temporary unless the room is really airtight. Exposure to poisonous gases such as carbon monoxide may occur in a closed room, heated by burning coal inside. This may also prove to be fatal.\n4. What is more common in a poorly ventilated home is a vague constellation of symptoms described as the sick building syndrome. It is characterized by a general feeling of malaise, headache, dizziness and irritation of mucous membranes. It may also be accompanied by nausea, itching, aches, pains and depression. Sick building syndrome is getting commoner in big cities with small houses which are generally over-furnished. Some of the major pollutants whose indoor concentrations exceed those of the outdoor include gases such as carbon monoxide, carbon dioxide, oxides of nitrogen and organic substances like spores, formaldehydes, hydrocarbon aerosols and allergens. The sources are attributed to a variety of construction materials, insulations, furnishings, adhesives, cosmetics, house dusts, fungi and other indoor products.\n5. Obviously, the spectrum of pollution is very wide and our options are limited. Indoor pollution may be handled relatively easily by an individual. Moreover, the good work must start from one's own house.\n\nAdapted from https://www.learncbse.in/reading-comprchension"
    ],
    "images": [],
    "choices": [
      {
        "id": 8152,
        "content": [
          "Industrial exhausts"
        ],
        "isCorrect": false
      },
      {
        "id": 8153,
        "content": [
          "Particulate matters"
        ],
        "isCorrect": false
      },
      {
        "id": 8154,
        "content": [
          "Car exhausts"
        ],
        "isCorrect": false
      },
      {
        "id": 8155,
        "content": [
          "Cosmetics"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2037,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "Which one of the following is NOT a characteristic of the sick building syndrome?"
    ],
    "explanation": [
      "The passage describes it as a \"vague constellation of symptoms\" caused by pollutants, not as a result of the \"combined effect of various diseases.\""
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 52,
    "groupIndex": null,
    "sharedContentId": 14,
    "sharedContent": [
      "1. Air pollution is an issue which concerns us all alike. One can willingly choose or reject a food, a drink or a life comfort, but unfortunately there is little choice for the air we breathe. All, what is there in the air is inhaled by one and all living in those surroundings.\n2. Air pollutant is defined as a substance which is present while normally it is not there or present in an amount exceeding the normal concentrations. It could either be gaseous or a particulate matter. The major harmful polluting gases are carbon monoxide, carbon dioxide, ozone and oxides of sulphur and nitrogen. The common particulate pollutants are the dusts of various inorganic or organic origins. Although we often talk of the outdoor air pollution caused by industrial and vehicular exhausts, the indoor pollution may prove to be as or a more serious cause of health problems.\n3. Recognition of air pollution is relatively recent. It is not uncommon to experience a feeling of ‘suffocation’ in a closed environment, which is often ascribed to the lack of oxygen. Fortunately, however, the composition of air is remarkably constant all over the world. There is about 79 per cent nitrogen and 21 per cent oxygen in the air, the other gases forming a very small fraction. It is true that carbon dioxide exhaled out of lungs may accumulate in a closed and overcrowded place. But such an increase is usually small and temporary unless the room is really airtight. Exposure to poisonous gases such as carbon monoxide may occur in a closed room, heated by burning coal inside. This may also prove to be fatal.\n4. What is more common in a poorly ventilated home is a vague constellation of symptoms described as the sick building syndrome. It is characterized by a general feeling of malaise, headache, dizziness and irritation of mucous membranes. It may also be accompanied by nausea, itching, aches, pains and depression. Sick building syndrome is getting commoner in big cities with small houses which are generally over-furnished. Some of the major pollutants whose indoor concentrations exceed those of the outdoor include gases such as carbon monoxide, carbon dioxide, oxides of nitrogen and organic substances like spores, formaldehydes, hydrocarbon aerosols and allergens. The sources are attributed to a variety of construction materials, insulations, furnishings, adhesives, cosmetics, house dusts, fungi and other indoor products.\n5. Obviously, the spectrum of pollution is very wide and our options are limited. Indoor pollution may be handled relatively easily by an individual. Moreover, the good work must start from one's own house.\n\nAdapted from https://www.learncbse.in/reading-comprchension"
    ],
    "images": [],
    "choices": [
      {
        "id": 8156,
        "content": [
          "It is the result of the combined effect of various diseases."
        ],
        "isCorrect": true
      },
      {
        "id": 8157,
        "content": [
          "It commonly occurs in homes with little or no ventilation."
        ],
        "isCorrect": false
      },
      {
        "id": 8158,
        "content": [
          "It is an indistinct collection of symptoms."
        ],
        "isCorrect": false
      },
      {
        "id": 8159,
        "content": [
          "It is becoming more common in big cities with small but over-furnished houses."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2038,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "As discussed in the passage, spirituality is about ______"
    ],
    "explanation": [
      "Paragraph 3 defines practicing spirituality as \"a way of recognizing and trying to understand the wonder and beauty of existence,\" which includes activities like going for long walks in nature. This aligns with getting happiness from understanding nature's beauty."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 53,
    "groupIndex": null,
    "sharedContentId": 15,
    "sharedContent": [
      "1. Research suggests that our level of happiness depends partly on factors we cannot control - our genes and our life circumstances. But our level of happiness is also shaped by the choices we make. If you've been chasing wealth, fame, good looks, material things, and power, you may be looking for happiness in all the wrong places. According to psychologists, the following are some of the factors which make people happier.\n2. To begin with, people who form close relationships tend to be happier than those who do not. The number of friends we have is not important. What matters is the quality of our relationships. Relationships that bring happiness usually involve the sharing of feelings, mutual respect, acceptance, trust, fun and empathy. As well as forming intimate relationships, caring for the wellbeing of others can be a source of happiness. This might involve volunteering for an organization or reaching out to support friends and family on a regular basis.\n3. People who include spirituality in their daily life also tend to be happier. Practicing spirituality is a way of recognizing and trying to understand the wonder and beauty of existence. Some people do this by going to a place of worship or praying. Some people practice yoga or meditation. Some people go for long walks in nature.\n4. In addition, people who think positively by being grateful, mindful, and optimistic are more likely to be happy. Being grateful means being thankful. Being mindful means being open to, focusing on, and enjoying the experiences of the present moment. Being optimistic means being hopeful about the future.\n\nAdapted from https://continuingstudies.uvic.ca/elc/studyzone//410/reading/happy-brain1"
    ],
    "images": [],
    "choices": [
      {
        "id": 8160,
        "content": [
          "how devotion to religion is the source of happiness."
        ],
        "isCorrect": false
      },
      {
        "id": 8161,
        "content": [
          "how we can lead our life properly."
        ],
        "isCorrect": false
      },
      {
        "id": 8162,
        "content": [
          "Getting happiness by understanding the beauty of nature."
        ],
        "isCorrect": true
      },
      {
        "id": 8163,
        "content": [
          "recognizing and knowing more about the environment in which we live."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2039,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "The writer believes that ______"
    ],
    "explanation": [
      "The first paragraph explicitly states that if you chase wealth and fame, \"you may be looking for happiness in all the wrong places,\" implying these are not the right sources."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 53,
    "groupIndex": null,
    "sharedContentId": 15,
    "sharedContent": [
      "1. Research suggests that our level of happiness depends partly on factors we cannot control - our genes and our life circumstances. But our level of happiness is also shaped by the choices we make. If you've been chasing wealth, fame, good looks, material things, and power, you may be looking for happiness in all the wrong places. According to psychologists, the following are some of the factors which make people happier.\n2. To begin with, people who form close relationships tend to be happier than those who do not. The number of friends we have is not important. What matters is the quality of our relationships. Relationships that bring happiness usually involve the sharing of feelings, mutual respect, acceptance, trust, fun and empathy. As well as forming intimate relationships, caring for the wellbeing of others can be a source of happiness. This might involve volunteering for an organization or reaching out to support friends and family on a regular basis.\n3. People who include spirituality in their daily life also tend to be happier. Practicing spirituality is a way of recognizing and trying to understand the wonder and beauty of existence. Some people do this by going to a place of worship or praying. Some people practice yoga or meditation. Some people go for long walks in nature.\n4. In addition, people who think positively by being grateful, mindful, and optimistic are more likely to be happy. Being grateful means being thankful. Being mindful means being open to, focusing on, and enjoying the experiences of the present moment. Being optimistic means being hopeful about the future.\n\nAdapted from https://continuingstudies.uvic.ca/elc/studyzone//410/reading/happy-brain1"
    ],
    "images": [],
    "choices": [
      {
        "id": 8164,
        "content": [
          "people always look for happiness in the wrong places."
        ],
        "isCorrect": false
      },
      {
        "id": 8165,
        "content": [
          "wealth, fame, and power are some of the factors that make us happy."
        ],
        "isCorrect": false
      },
      {
        "id": 8166,
        "content": [
          "wealth, fame, and power are not necessarily the right sources of happiness."
        ],
        "isCorrect": true
      },
      {
        "id": 8167,
        "content": [
          "the sources of happiness do not vary according to individuals."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2040,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "Which one of the following is **NOT** an aspect of thinking positively?"
    ],
    "explanation": [
      "Paragraph 4 lists the aspects of positive thinking as being grateful (thankful), mindful (enjoying the present), and optimistic (expecting good in the future). \"Being concerned about your position\" is not mentioned as part of this."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 53,
    "groupIndex": null,
    "sharedContentId": 15,
    "sharedContent": [
      "1. Research suggests that our level of happiness depends partly on factors we cannot control - our genes and our life circumstances. But our level of happiness is also shaped by the choices we make. If you've been chasing wealth, fame, good looks, material things, and power, you may be looking for happiness in all the wrong places. According to psychologists, the following are some of the factors which make people happier.\n2. To begin with, people who form close relationships tend to be happier than those who do not. The number of friends we have is not important. What matters is the quality of our relationships. Relationships that bring happiness usually involve the sharing of feelings, mutual respect, acceptance, trust, fun and empathy. As well as forming intimate relationships, caring for the wellbeing of others can be a source of happiness. This might involve volunteering for an organization or reaching out to support friends and family on a regular basis.\n3. People who include spirituality in their daily life also tend to be happier. Practicing spirituality is a way of recognizing and trying to understand the wonder and beauty of existence. Some people do this by going to a place of worship or praying. Some people practice yoga or meditation. Some people go for long walks in nature.\n4. In addition, people who think positively by being grateful, mindful, and optimistic are more likely to be happy. Being grateful means being thankful. Being mindful means being open to, focusing on, and enjoying the experiences of the present moment. Being optimistic means being hopeful about the future.\n\nAdapted from https://continuingstudies.uvic.ca/elc/studyzone//410/reading/happy-brain1"
    ],
    "images": [],
    "choices": [
      {
        "id": 8168,
        "content": [
          "Being concerned about your position"
        ],
        "isCorrect": true
      },
      {
        "id": 8169,
        "content": [
          "Being thankful"
        ],
        "isCorrect": false
      },
      {
        "id": 8170,
        "content": [
          "Enjoying the present experience"
        ],
        "isCorrect": false
      },
      {
        "id": 8171,
        "content": [
          "Expecting good in the future"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2041,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "According to the passage:"
    ],
    "explanation": [
      "The first paragraph states, \"our level of happiness is also shaped by the choices we make,\" directly supporting this option. It also mentions uncontrollable factors like genes, ruling out the other options."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 53,
    "groupIndex": null,
    "sharedContentId": 15,
    "sharedContent": [
      "1. Research suggests that our level of happiness depends partly on factors we cannot control - our genes and our life circumstances. But our level of happiness is also shaped by the choices we make. If you've been chasing wealth, fame, good looks, material things, and power, you may be looking for happiness in all the wrong places. According to psychologists, the following are some of the factors which make people happier.\n2. To begin with, people who form close relationships tend to be happier than those who do not. The number of friends we have is not important. What matters is the quality of our relationships. Relationships that bring happiness usually involve the sharing of feelings, mutual respect, acceptance, trust, fun and empathy. As well as forming intimate relationships, caring for the wellbeing of others can be a source of happiness. This might involve volunteering for an organization or reaching out to support friends and family on a regular basis.\n3. People who include spirituality in their daily life also tend to be happier. Practicing spirituality is a way of recognizing and trying to understand the wonder and beauty of existence. Some people do this by going to a place of worship or praying. Some people practice yoga or meditation. Some people go for long walks in nature.\n4. In addition, people who think positively by being grateful, mindful, and optimistic are more likely to be happy. Being grateful means being thankful. Being mindful means being open to, focusing on, and enjoying the experiences of the present moment. Being optimistic means being hopeful about the future.\n\nAdapted from https://continuingstudies.uvic.ca/elc/studyzone//410/reading/happy-brain1"
    ],
    "images": [],
    "choices": [
      {
        "id": 8172,
        "content": [
          "The choice we make are partly responsible for our level of happiness."
        ],
        "isCorrect": true
      },
      {
        "id": 8173,
        "content": [
          "Our genes do not influence our level of happiness."
        ],
        "isCorrect": false
      },
      {
        "id": 8174,
        "content": [
          "We have no control over the things that make us happy."
        ],
        "isCorrect": false
      },
      {
        "id": 8175,
        "content": [
          "We have control over the things that make us happy."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2042,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "Which of the following is **NOT** the writer's purpose in this passage?"
    ],
    "explanation": [
      "The passage explicitly states that happiness depends \"partly on factors we cannot control - our genes and our life circumstances.\" This contradicts the idea that people have full control."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 53,
    "groupIndex": null,
    "sharedContentId": 15,
    "sharedContent": [
      "1. Research suggests that our level of happiness depends partly on factors we cannot control - our genes and our life circumstances. But our level of happiness is also shaped by the choices we make. If you've been chasing wealth, fame, good looks, material things, and power, you may be looking for happiness in all the wrong places. According to psychologists, the following are some of the factors which make people happier.\n2. To begin with, people who form close relationships tend to be happier than those who do not. The number of friends we have is not important. What matters is the quality of our relationships. Relationships that bring happiness usually involve the sharing of feelings, mutual respect, acceptance, trust, fun and empathy. As well as forming intimate relationships, caring for the wellbeing of others can be a source of happiness. This might involve volunteering for an organization or reaching out to support friends and family on a regular basis.\n3. People who include spirituality in their daily life also tend to be happier. Practicing spirituality is a way of recognizing and trying to understand the wonder and beauty of existence. Some people do this by going to a place of worship or praying. Some people practice yoga or meditation. Some people go for long walks in nature.\n4. In addition, people who think positively by being grateful, mindful, and optimistic are more likely to be happy. Being grateful means being thankful. Being mindful means being open to, focusing on, and enjoying the experiences of the present moment. Being optimistic means being hopeful about the future.\n\nAdapted from https://continuingstudies.uvic.ca/elc/studyzone//410/reading/happy-brain1"
    ],
    "images": [],
    "choices": [
      {
        "id": 8176,
        "content": [
          "advise people that they need to form close relationships in order to be happy."
        ],
        "isCorrect": false
      },
      {
        "id": 8177,
        "content": [
          "explain why people should be happy in life."
        ],
        "isCorrect": false
      },
      {
        "id": 8178,
        "content": [
          "tell people that they have full control over their happiness."
        ],
        "isCorrect": true
      },
      {
        "id": 8179,
        "content": [
          "inform people about the choices they have to make themselves happy."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2043,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "The writer of the passage believes that in order to be happy one ______"
    ],
    "explanation": [
      "Paragraph 2 states that what matters is the \"quality of our relationships,\" which involves \"sharing of feelings\" and \"empathy.\" This points to having a deeper understanding of a friend's feelings."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 53,
    "groupIndex": null,
    "sharedContentId": 15,
    "sharedContent": [
      "1. Research suggests that our level of happiness depends partly on factors we cannot control - our genes and our life circumstances. But our level of happiness is also shaped by the choices we make. If you've been chasing wealth, fame, good looks, material things, and power, you may be looking for happiness in all the wrong places. According to psychologists, the following are some of the factors which make people happier.\n2. To begin with, people who form close relationships tend to be happier than those who do not. The number of friends we have is not important. What matters is the quality of our relationships. Relationships that bring happiness usually involve the sharing of feelings, mutual respect, acceptance, trust, fun and empathy. As well as forming intimate relationships, caring for the wellbeing of others can be a source of happiness. This might involve volunteering for an organization or reaching out to support friends and family on a regular basis.\n3. People who include spirituality in their daily life also tend to be happier. Practicing spirituality is a way of recognizing and trying to understand the wonder and beauty of existence. Some people do this by going to a place of worship or praying. Some people practice yoga or meditation. Some people go for long walks in nature.\n4. In addition, people who think positively by being grateful, mindful, and optimistic are more likely to be happy. Being grateful means being thankful. Being mindful means being open to, focusing on, and enjoying the experiences of the present moment. Being optimistic means being hopeful about the future.\n\nAdapted from https://continuingstudies.uvic.ca/elc/studyzone//410/reading/happy-brain1"
    ],
    "images": [],
    "choices": [
      {
        "id": 8180,
        "content": [
          "should have as many friends as possible."
        ],
        "isCorrect": false
      },
      {
        "id": 8181,
        "content": [
          "should have deeper understanding of friends feeling."
        ],
        "isCorrect": true
      },
      {
        "id": 8182,
        "content": [
          "should be able to make others accept his/her thoughts."
        ],
        "isCorrect": false
      },
      {
        "id": 8183,
        "content": [
          "should give priority to the benefits of others."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2044,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "Which one of the following is **NOT** mentioned as a source of happiness?"
    ],
    "explanation": [
      "The passage explicitly mentions \"material things\" as one of the \"wrong places\" to look for happiness. Mutual respect, helping others (caring for their wellbeing), and sharing feelings are all mentioned as positive factors."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 53,
    "groupIndex": null,
    "sharedContentId": 15,
    "sharedContent": [
      "1. Research suggests that our level of happiness depends partly on factors we cannot control - our genes and our life circumstances. But our level of happiness is also shaped by the choices we make. If you've been chasing wealth, fame, good looks, material things, and power, you may be looking for happiness in all the wrong places. According to psychologists, the following are some of the factors which make people happier.\n2. To begin with, people who form close relationships tend to be happier than those who do not. The number of friends we have is not important. What matters is the quality of our relationships. Relationships that bring happiness usually involve the sharing of feelings, mutual respect, acceptance, trust, fun and empathy. As well as forming intimate relationships, caring for the wellbeing of others can be a source of happiness. This might involve volunteering for an organization or reaching out to support friends and family on a regular basis.\n3. People who include spirituality in their daily life also tend to be happier. Practicing spirituality is a way of recognizing and trying to understand the wonder and beauty of existence. Some people do this by going to a place of worship or praying. Some people practice yoga or meditation. Some people go for long walks in nature.\n4. In addition, people who think positively by being grateful, mindful, and optimistic are more likely to be happy. Being grateful means being thankful. Being mindful means being open to, focusing on, and enjoying the experiences of the present moment. Being optimistic means being hopeful about the future.\n\nAdapted from https://continuingstudies.uvic.ca/elc/studyzone//410/reading/happy-brain1"
    ],
    "images": [],
    "choices": [
      {
        "id": 8184,
        "content": [
          "Mutual respect"
        ],
        "isCorrect": false
      },
      {
        "id": 8185,
        "content": [
          "Material things"
        ],
        "isCorrect": true
      },
      {
        "id": 8186,
        "content": [
          "Helping others"
        ],
        "isCorrect": false
      },
      {
        "id": 8187,
        "content": [
          "Sharing of feelings"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2045,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "Based on the passage, which one of the following is **NOT** a way of practicing spirituality?"
    ],
    "explanation": [
      "Paragraph 3 lists ways of practicing spirituality as going to a place of worship, praying, yoga, meditation, and long walks in nature (appreciating nature). Political leadership is not mentioned."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 53,
    "groupIndex": null,
    "sharedContentId": 15,
    "sharedContent": [
      "1. Research suggests that our level of happiness depends partly on factors we cannot control - our genes and our life circumstances. But our level of happiness is also shaped by the choices we make. If you've been chasing wealth, fame, good looks, material things, and power, you may be looking for happiness in all the wrong places. According to psychologists, the following are some of the factors which make people happier.\n2. To begin with, people who form close relationships tend to be happier than those who do not. The number of friends we have is not important. What matters is the quality of our relationships. Relationships that bring happiness usually involve the sharing of feelings, mutual respect, acceptance, trust, fun and empathy. As well as forming intimate relationships, caring for the wellbeing of others can be a source of happiness. This might involve volunteering for an organization or reaching out to support friends and family on a regular basis.\n3. People who include spirituality in their daily life also tend to be happier. Practicing spirituality is a way of recognizing and trying to understand the wonder and beauty of existence. Some people do this by going to a place of worship or praying. Some people practice yoga or meditation. Some people go for long walks in nature.\n4. In addition, people who think positively by being grateful, mindful, and optimistic are more likely to be happy. Being grateful means being thankful. Being mindful means being open to, focusing on, and enjoying the experiences of the present moment. Being optimistic means being hopeful about the future.\n\nAdapted from https://continuingstudies.uvic.ca/elc/studyzone//410/reading/happy-brain1"
    ],
    "images": [],
    "choices": [
      {
        "id": 8188,
        "content": [
          "Engaging in meditation"
        ],
        "isCorrect": false
      },
      {
        "id": 8189,
        "content": [
          "Love to a partner"
        ],
        "isCorrect": false
      },
      {
        "id": 8190,
        "content": [
          "Political leadership"
        ],
        "isCorrect": true
      },
      {
        "id": 8191,
        "content": [
          "Appreciating nature"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2046,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "People who do **NOT** have close relationships are ______"
    ],
    "explanation": [
      "Paragraph 2 opens by stating, \"people who form close relationships tend to be happier than those who do not.\" This directly implies that those without such relationships are not as happy."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 53,
    "groupIndex": null,
    "sharedContentId": 15,
    "sharedContent": [
      "1. Research suggests that our level of happiness depends partly on factors we cannot control - our genes and our life circumstances. But our level of happiness is also shaped by the choices we make. If you've been chasing wealth, fame, good looks, material things, and power, you may be looking for happiness in all the wrong places. According to psychologists, the following are some of the factors which make people happier.\n2. To begin with, people who form close relationships tend to be happier than those who do not. The number of friends we have is not important. What matters is the quality of our relationships. Relationships that bring happiness usually involve the sharing of feelings, mutual respect, acceptance, trust, fun and empathy. As well as forming intimate relationships, caring for the wellbeing of others can be a source of happiness. This might involve volunteering for an organization or reaching out to support friends and family on a regular basis.\n3. People who include spirituality in their daily life also tend to be happier. Practicing spirituality is a way of recognizing and trying to understand the wonder and beauty of existence. Some people do this by going to a place of worship or praying. Some people practice yoga or meditation. Some people go for long walks in nature.\n4. In addition, people who think positively by being grateful, mindful, and optimistic are more likely to be happy. Being grateful means being thankful. Being mindful means being open to, focusing on, and enjoying the experiences of the present moment. Being optimistic means being hopeful about the future.\n\nAdapted from https://continuingstudies.uvic.ca/elc/studyzone//410/reading/happy-brain1"
    ],
    "images": [],
    "choices": [
      {
        "id": 8192,
        "content": [
          "not concerned about happiness in life."
        ],
        "isCorrect": false
      },
      {
        "id": 8193,
        "content": [
          "happier than those who have."
        ],
        "isCorrect": false
      },
      {
        "id": 8194,
        "content": [
          "not as happy as those who have."
        ],
        "isCorrect": true
      },
      {
        "id": 8195,
        "content": [
          "care more about happiness in life."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2047,
    "content": [
      "Based on the passage, choose the best answer for each question.",
      "---",
      "Volunteering is mentioned in the passage as  ______"
    ],
    "explanation": [
      "The passage states: “As well as forming intimate relationships, caring for the wellbeing of others can be a source of happiness. This might involve volunteering for an organization...”. This shows volunteering is mentioned as a way to get happiness by helping others."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 53,
    "groupIndex": null,
    "sharedContentId": 15,
    "sharedContent": [
      "1. Research suggests that our level of happiness depends partly on factors we cannot control - our genes and our life circumstances. But our level of happiness is also shaped by the choices we make. If you've been chasing wealth, fame, good looks, material things, and power, you may be looking for happiness in all the wrong places. According to psychologists, the following are some of the factors which make people happier.\n2. To begin with, people who form close relationships tend to be happier than those who do not. The number of friends we have is not important. What matters is the quality of our relationships. Relationships that bring happiness usually involve the sharing of feelings, mutual respect, acceptance, trust, fun and empathy. As well as forming intimate relationships, caring for the wellbeing of others can be a source of happiness. This might involve volunteering for an organization or reaching out to support friends and family on a regular basis.\n3. People who include spirituality in their daily life also tend to be happier. Practicing spirituality is a way of recognizing and trying to understand the wonder and beauty of existence. Some people do this by going to a place of worship or praying. Some people practice yoga or meditation. Some people go for long walks in nature.\n4. In addition, people who think positively by being grateful, mindful, and optimistic are more likely to be happy. Being grateful means being thankful. Being mindful means being open to, focusing on, and enjoying the experiences of the present moment. Being optimistic means being hopeful about the future.\n\nAdapted from https://continuingstudies.uvic.ca/elc/studyzone//410/reading/happy-brain1"
    ],
    "images": [],
    "choices": [
      {
        "id": 8196,
        "content": [
          "getting fame by helping others."
        ],
        "isCorrect": false
      },
      {
        "id": 8197,
        "content": [
          "getting happiness by helping others."
        ],
        "isCorrect": true
      },
      {
        "id": 8198,
        "content": [
          "getting spiritual satisfaction."
        ],
        "isCorrect": false
      },
      {
        "id": 8199,
        "content": [
          "influencing others to be dependent."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2069,
    "content": [
      "Choose the correctly punctuated and capitalized sentence."
    ],
    "explanation": [
      "Proper nouns must be capitalized. 'Guba', 'Great Renaissance Dam', and 'September' are all proper nouns and should start with a capital letter."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 58,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 8284,
        "content": [
          "We are going to guba to see the great renaissance Dam In September."
        ],
        "isCorrect": false
      },
      {
        "id": 8285,
        "content": [
          "We are going to guba to see the Great Renaissance Dam in september."
        ],
        "isCorrect": false
      },
      {
        "id": 8286,
        "content": [
          "We are going to Guba to see the Great Renaissance Dam in September."
        ],
        "isCorrect": true
      },
      {
        "id": 8287,
        "content": [
          "We are going to Guba to see the great renaissance Dam in september."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2070,
    "content": [
      "Choose the correctly punctuated and capitalized sentence."
    ],
    "explanation": [
      "A comma should precede direct speech. The speech should be enclosed in quotation marks, and the first word of the speech should be capitalized. The sentence should end with a period inside the quotation marks."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 58,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 8288,
        "content": [
          "The teacher said, “Answer the questions in complete sentences.”"
        ],
        "isCorrect": true
      },
      {
        "id": 8289,
        "content": [
          "The teacher said, Answer the questions in complete sentences."
        ],
        "isCorrect": false
      },
      {
        "id": 8290,
        "content": [
          "The teacher said answer the questions in complete sentences."
        ],
        "isCorrect": false
      },
      {
        "id": 8291,
        "content": [
          "The teacher said, “answer the questions in complete sentences.”"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2071,
    "content": [
      "Choose the correctly punctuated sentence."
    ],
    "explanation": [
      "This is an indirect question embedded within a declarative statement. Therefore, it should end with a period, not a question mark or an exclamation mark."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 58,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 8292,
        "content": [
          "He wanted to find out how the accident occurred?"
        ],
        "isCorrect": false
      },
      {
        "id": 8293,
        "content": [
          "He wanted to find out how the accident occurred."
        ],
        "isCorrect": true
      },
      {
        "id": 8294,
        "content": [
          "He wanted to find out how the accident occurred!"
        ],
        "isCorrect": false
      },
      {
        "id": 8295,
        "content": [
          "He wanted to find out how the accident occurred"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2072,
    "content": [
      "Choose the correctly punctuated sentence."
    ],
    "explanation": [
      "Commas should be used to separate items in a list. No comma is needed before the conjunction 'and' unless it's necessary to avoid confusion (Oxford comma), and no comma should be placed between the verb 'bought' and its object."
    ],
    "year": "YEAR_2014",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 58,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 8296,
        "content": [
          "She went to the shop and bought, a kilo of sugar, a litre of milk, a kilo of bananas and some vegetables."
        ],
        "isCorrect": false
      },
      {
        "id": 8297,
        "content": [
          "She went to the shop and bought, a kilo of sugar a litre of milk a kilo of bananas and some vegetables."
        ],
        "isCorrect": false
      },
      {
        "id": 8298,
        "content": [
          "She went to the shop and bought a kilo of sugar, a litre of milk, a kilo of bananas and some vegetables."
        ],
        "isCorrect": true
      },
      {
        "id": 8299,
        "content": [
          "She went to the shop and bought a kilo of sugar, a litre of milk, a kilo of bananas, and some vegetables."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2117,
    "content": [
      "Read the passage and choose the best answer for the questions that follow.",
      "---",
      "According to paragraph 2, how much of our soil is getting out of use every six months?"
    ],
    "explanation": [
      "Paragraph 2 states that soil is lost at a rate of \"two and a half billion tons per year.\" Six months is half of a year, so the amount lost would be half of 2.5 billion, which is 1.25 billion tons."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 65,
    "groupIndex": null,
    "sharedContentId": 16,
    "sharedContent": [
      "### **The Shrinking Earth: Ecological Threats**\n\n1. In 1977, the Food and Agriculture Organization (FAO) and UNESCO jointly published an alarming map of the spread of deserts across the world. Shaded in orange, pink and red were all the areas in danger of desertification. The coloured patches a major part of the developing world outside the rainy equatorial belt. In Latin America they covered north east Brazil, central and northern Mexico and stretched right down the Andes as far as Chili. They ate in to the Horn of Africa and much of the south west of the continent. And without interruption they reached half way round the globe in a broad swath from the Atlantic coast of the Sahara, right across North Africa and the Sahel, through the Middle East and Persia to Pakistan and north west India.\n2. There could be no more graphic expression of the ecological dangers that threaten so much food production, so many livelihoods in the developing countries. The world is losing precious agriculture land at twice the rate that new land is being broken for farming. An area greater than great Britain is disappearing every year. Soil is being exhausted, eroded, and blown away at the rate of two and a half billion tons per year. By the end of the century, the world may have to support one and a half times its present population on only three quarters of its present cultivated area.\n3. In this report on the state of the environment in 1977, United Nations Environment Programme Director, Mostafa Tolba, warned that, if present trends continue, there would by only 0.15 hectares of farm land per person by the year 2000, half the 1975 level. Productivity would have to double merely to allow people to get the same amount of food as today, these are the figures on which he based that cultivation: in 1975 there were 1240 million hectares under cultivation. Over the next 25 years, perhaps another 300 million new hectares may be opened up but over the same period 600 million hectares half the entire 1975 cultivated area may be lost of these, half will probably disappear under the ink - blot spread of cities, which are expanding horizontally twice as fast as the populations are growing and over some of the best agriculture land. The other 300 million will be the toll of soil degradation.\n4. At least half of the total erosion will be in the world's 45 million square kilometers of potentially productive but ecologically precarious dry lands, which stretch through a hundred nations. About 700 million people live in this zone, almost all of them in developing countries, and 18 million live in areas that are currently undergoing rapid desertification.\n5. Everywhere the deserts are advancing. In Sudan, the southern edge of the Sahara moved south by 100 kms between 1958 and 1957. The deserts do not march forward on a solid font, like an army. Patches appear, like those at Aorema in Burkina Faso, around centers of population or watering holes, then spread, link up with others, and finally merge into the desert itself.\n6. The chief agent of what has been called leprosy of the soil is man, the impart of his activates on highly sensitive and delicately balanced ecosystems. The prime factor in the process is population increase. The number of people in the Sahel, for example, is doubling every 25 to 30 years. We can see everywhere the consequences of this among settled farmers: the cutting down of fallow periods, progressive decline in the vegetation cover, increasing erosion. As population goes on growing cultivation is pushed into areas that are entirely unsuitable for agriculture, and there the process progresses even more rapidly.\n\nTaken from English four, ETC, department of English"
    ],
    "images": [],
    "choices": [
      {
        "id": 8476,
        "content": [
          "1.75 billion tons"
        ],
        "isCorrect": false
      },
      {
        "id": 8477,
        "content": [
          "2.50 billion tons"
        ],
        "isCorrect": false
      },
      {
        "id": 8478,
        "content": [
          "1.50 billion tons"
        ],
        "isCorrect": false
      },
      {
        "id": 8479,
        "content": [
          "1.25 billion tons"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2118,
    "content": [
      "Read the passage and choose the best answer for the questions that follow.",
      "---",
      "Which paragraph could be cited as a good example to show that the continent of Africa has been seriously affected by desertification?"
    ],
    "explanation": [
      "Paragraph 5 provides specific examples of active desertification in Africa, stating that \"In Sudan, the southern edge of the Sahara moved south by 100 kms\" and mentions patches appearing in \"Burkina Faso\". This serves as a concrete example of the serious impact."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 65,
    "groupIndex": null,
    "sharedContentId": 16,
    "sharedContent": [
      "### **The Shrinking Earth: Ecological Threats**\n\n1. In 1977, the Food and Agriculture Organization (FAO) and UNESCO jointly published an alarming map of the spread of deserts across the world. Shaded in orange, pink and red were all the areas in danger of desertification. The coloured patches a major part of the developing world outside the rainy equatorial belt. In Latin America they covered north east Brazil, central and northern Mexico and stretched right down the Andes as far as Chili. They ate in to the Horn of Africa and much of the south west of the continent. And without interruption they reached half way round the globe in a broad swath from the Atlantic coast of the Sahara, right across North Africa and the Sahel, through the Middle East and Persia to Pakistan and north west India.\n2. There could be no more graphic expression of the ecological dangers that threaten so much food production, so many livelihoods in the developing countries. The world is losing precious agriculture land at twice the rate that new land is being broken for farming. An area greater than great Britain is disappearing every year. Soil is being exhausted, eroded, and blown away at the rate of two and a half billion tons per year. By the end of the century, the world may have to support one and a half times its present population on only three quarters of its present cultivated area.\n3. In this report on the state of the environment in 1977, United Nations Environment Programme Director, Mostafa Tolba, warned that, if present trends continue, there would by only 0.15 hectares of farm land per person by the year 2000, half the 1975 level. Productivity would have to double merely to allow people to get the same amount of food as today, these are the figures on which he based that cultivation: in 1975 there were 1240 million hectares under cultivation. Over the next 25 years, perhaps another 300 million new hectares may be opened up but over the same period 600 million hectares half the entire 1975 cultivated area may be lost of these, half will probably disappear under the ink - blot spread of cities, which are expanding horizontally twice as fast as the populations are growing and over some of the best agriculture land. The other 300 million will be the toll of soil degradation.\n4. At least half of the total erosion will be in the world's 45 million square kilometers of potentially productive but ecologically precarious dry lands, which stretch through a hundred nations. About 700 million people live in this zone, almost all of them in developing countries, and 18 million live in areas that are currently undergoing rapid desertification.\n5. Everywhere the deserts are advancing. In Sudan, the southern edge of the Sahara moved south by 100 kms between 1958 and 1957. The deserts do not march forward on a solid font, like an army. Patches appear, like those at Aorema in Burkina Faso, around centers of population or watering holes, then spread, link up with others, and finally merge into the desert itself.\n6. The chief agent of what has been called leprosy of the soil is man, the impart of his activates on highly sensitive and delicately balanced ecosystems. The prime factor in the process is population increase. The number of people in the Sahel, for example, is doubling every 25 to 30 years. We can see everywhere the consequences of this among settled farmers: the cutting down of fallow periods, progressive decline in the vegetation cover, increasing erosion. As population goes on growing cultivation is pushed into areas that are entirely unsuitable for agriculture, and there the process progresses even more rapidly.\n\nTaken from English four, ETC, department of English"
    ],
    "images": [],
    "choices": [
      {
        "id": 8480,
        "content": [
          "Paragraph 1"
        ],
        "isCorrect": false
      },
      {
        "id": 8481,
        "content": [
          "Paragraph 5"
        ],
        "isCorrect": true
      },
      {
        "id": 8482,
        "content": [
          "Paragraph 4"
        ],
        "isCorrect": false
      },
      {
        "id": 8483,
        "content": [
          "Paragraph 6"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2119,
    "content": [
      "Read the passage and choose the best answer for the questions that follow.",
      "---",
      "In relative terms, which one of the following factors contributes more to desertification?"
    ],
    "explanation": [
      "Paragraph 6 identifies population increase as the \"prime factor\" which leads to several consequences. It explicitly states that when \"cultivation is pushed into areas that are entirely unsuitable for agriculture... the process progresses even more rapidly,\" indicating this factor significantly accelerates desertification."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 65,
    "groupIndex": null,
    "sharedContentId": 16,
    "sharedContent": [
      "### **The Shrinking Earth: Ecological Threats**\n\n1. In 1977, the Food and Agriculture Organization (FAO) and UNESCO jointly published an alarming map of the spread of deserts across the world. Shaded in orange, pink and red were all the areas in danger of desertification. The coloured patches a major part of the developing world outside the rainy equatorial belt. In Latin America they covered north east Brazil, central and northern Mexico and stretched right down the Andes as far as Chili. They ate in to the Horn of Africa and much of the south west of the continent. And without interruption they reached half way round the globe in a broad swath from the Atlantic coast of the Sahara, right across North Africa and the Sahel, through the Middle East and Persia to Pakistan and north west India.\n2. There could be no more graphic expression of the ecological dangers that threaten so much food production, so many livelihoods in the developing countries. The world is losing precious agriculture land at twice the rate that new land is being broken for farming. An area greater than great Britain is disappearing every year. Soil is being exhausted, eroded, and blown away at the rate of two and a half billion tons per year. By the end of the century, the world may have to support one and a half times its present population on only three quarters of its present cultivated area.\n3. In this report on the state of the environment in 1977, United Nations Environment Programme Director, Mostafa Tolba, warned that, if present trends continue, there would by only 0.15 hectares of farm land per person by the year 2000, half the 1975 level. Productivity would have to double merely to allow people to get the same amount of food as today, these are the figures on which he based that cultivation: in 1975 there were 1240 million hectares under cultivation. Over the next 25 years, perhaps another 300 million new hectares may be opened up but over the same period 600 million hectares half the entire 1975 cultivated area may be lost of these, half will probably disappear under the ink - blot spread of cities, which are expanding horizontally twice as fast as the populations are growing and over some of the best agriculture land. The other 300 million will be the toll of soil degradation.\n4. At least half of the total erosion will be in the world's 45 million square kilometers of potentially productive but ecologically precarious dry lands, which stretch through a hundred nations. About 700 million people live in this zone, almost all of them in developing countries, and 18 million live in areas that are currently undergoing rapid desertification.\n5. Everywhere the deserts are advancing. In Sudan, the southern edge of the Sahara moved south by 100 kms between 1958 and 1957. The deserts do not march forward on a solid font, like an army. Patches appear, like those at Aorema in Burkina Faso, around centers of population or watering holes, then spread, link up with others, and finally merge into the desert itself.\n6. The chief agent of what has been called leprosy of the soil is man, the impart of his activates on highly sensitive and delicately balanced ecosystems. The prime factor in the process is population increase. The number of people in the Sahel, for example, is doubling every 25 to 30 years. We can see everywhere the consequences of this among settled farmers: the cutting down of fallow periods, progressive decline in the vegetation cover, increasing erosion. As population goes on growing cultivation is pushed into areas that are entirely unsuitable for agriculture, and there the process progresses even more rapidly.\n\nTaken from English four, ETC, department of English"
    ],
    "images": [],
    "choices": [
      {
        "id": 8484,
        "content": [
          "Cultivation of land unsuitable for farming"
        ],
        "isCorrect": true
      },
      {
        "id": 8485,
        "content": [
          "Increase in the amount of erosion"
        ],
        "isCorrect": false
      },
      {
        "id": 8486,
        "content": [
          "Decrease in land left uncultivated"
        ],
        "isCorrect": false
      },
      {
        "id": 8487,
        "content": [
          "Decline in vegetation covering the areas"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2120,
    "content": [
      "Read the passage and choose the best answer for the questions that follow.",
      "---",
      "Which one of the following sentences best summarizes paragraph 2?"
    ],
    "explanation": [
      "Paragraph 2 describes how the world is \"losing precious agriculture land at twice the rate that new land is being broken for farming,\" mentioning that an area \"greater than great Britain is disappearing every year.\" This captures the essence of losing agricultural land at an alarming rate."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 65,
    "groupIndex": null,
    "sharedContentId": 16,
    "sharedContent": [
      "### **The Shrinking Earth: Ecological Threats**\n\n1. In 1977, the Food and Agriculture Organization (FAO) and UNESCO jointly published an alarming map of the spread of deserts across the world. Shaded in orange, pink and red were all the areas in danger of desertification. The coloured patches a major part of the developing world outside the rainy equatorial belt. In Latin America they covered north east Brazil, central and northern Mexico and stretched right down the Andes as far as Chili. They ate in to the Horn of Africa and much of the south west of the continent. And without interruption they reached half way round the globe in a broad swath from the Atlantic coast of the Sahara, right across North Africa and the Sahel, through the Middle East and Persia to Pakistan and north west India.\n2. There could be no more graphic expression of the ecological dangers that threaten so much food production, so many livelihoods in the developing countries. The world is losing precious agriculture land at twice the rate that new land is being broken for farming. An area greater than great Britain is disappearing every year. Soil is being exhausted, eroded, and blown away at the rate of two and a half billion tons per year. By the end of the century, the world may have to support one and a half times its present population on only three quarters of its present cultivated area.\n3. In this report on the state of the environment in 1977, United Nations Environment Programme Director, Mostafa Tolba, warned that, if present trends continue, there would by only 0.15 hectares of farm land per person by the year 2000, half the 1975 level. Productivity would have to double merely to allow people to get the same amount of food as today, these are the figures on which he based that cultivation: in 1975 there were 1240 million hectares under cultivation. Over the next 25 years, perhaps another 300 million new hectares may be opened up but over the same period 600 million hectares half the entire 1975 cultivated area may be lost of these, half will probably disappear under the ink - blot spread of cities, which are expanding horizontally twice as fast as the populations are growing and over some of the best agriculture land. The other 300 million will be the toll of soil degradation.\n4. At least half of the total erosion will be in the world's 45 million square kilometers of potentially productive but ecologically precarious dry lands, which stretch through a hundred nations. About 700 million people live in this zone, almost all of them in developing countries, and 18 million live in areas that are currently undergoing rapid desertification.\n5. Everywhere the deserts are advancing. In Sudan, the southern edge of the Sahara moved south by 100 kms between 1958 and 1957. The deserts do not march forward on a solid font, like an army. Patches appear, like those at Aorema in Burkina Faso, around centers of population or watering holes, then spread, link up with others, and finally merge into the desert itself.\n6. The chief agent of what has been called leprosy of the soil is man, the impart of his activates on highly sensitive and delicately balanced ecosystems. The prime factor in the process is population increase. The number of people in the Sahel, for example, is doubling every 25 to 30 years. We can see everywhere the consequences of this among settled farmers: the cutting down of fallow periods, progressive decline in the vegetation cover, increasing erosion. As population goes on growing cultivation is pushed into areas that are entirely unsuitable for agriculture, and there the process progresses even more rapidly.\n\nTaken from English four, ETC, department of English"
    ],
    "images": [],
    "choices": [
      {
        "id": 8488,
        "content": [
          "The world is losing its precious agricultural and at an alarming rate."
        ],
        "isCorrect": true
      },
      {
        "id": 8489,
        "content": [
          "The amount of cultivable land is decreasing while population remains constant."
        ],
        "isCorrect": false
      },
      {
        "id": 8490,
        "content": [
          "Soil degradation is a serious problem threatening people in developing countries"
        ],
        "isCorrect": false
      },
      {
        "id": 8491,
        "content": [
          "The amount of cultivable land population growth are inversely proportional."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2121,
    "content": [
      "Read the passage and choose the best answer for the questions that follow.",
      "---",
      "What does the phrase, the ink blot spread of cities (paragraph 3) mean?"
    ],
    "explanation": [
      "Paragraph 3 describes cities \"expanding horizontally... over some of the best agriculture land.\" An ink blot spreads outward from a center, covering the surface it is on. This metaphor effectively describes cities expanding into and covering the surrounding farmland."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 65,
    "groupIndex": null,
    "sharedContentId": 16,
    "sharedContent": [
      "### **The Shrinking Earth: Ecological Threats**\n\n1. In 1977, the Food and Agriculture Organization (FAO) and UNESCO jointly published an alarming map of the spread of deserts across the world. Shaded in orange, pink and red were all the areas in danger of desertification. The coloured patches a major part of the developing world outside the rainy equatorial belt. In Latin America they covered north east Brazil, central and northern Mexico and stretched right down the Andes as far as Chili. They ate in to the Horn of Africa and much of the south west of the continent. And without interruption they reached half way round the globe in a broad swath from the Atlantic coast of the Sahara, right across North Africa and the Sahel, through the Middle East and Persia to Pakistan and north west India.\n2. There could be no more graphic expression of the ecological dangers that threaten so much food production, so many livelihoods in the developing countries. The world is losing precious agriculture land at twice the rate that new land is being broken for farming. An area greater than great Britain is disappearing every year. Soil is being exhausted, eroded, and blown away at the rate of two and a half billion tons per year. By the end of the century, the world may have to support one and a half times its present population on only three quarters of its present cultivated area.\n3. In this report on the state of the environment in 1977, United Nations Environment Programme Director, Mostafa Tolba, warned that, if present trends continue, there would by only 0.15 hectares of farm land per person by the year 2000, half the 1975 level. Productivity would have to double merely to allow people to get the same amount of food as today, these are the figures on which he based that cultivation: in 1975 there were 1240 million hectares under cultivation. Over the next 25 years, perhaps another 300 million new hectares may be opened up but over the same period 600 million hectares half the entire 1975 cultivated area may be lost of these, half will probably disappear under the ink - blot spread of cities, which are expanding horizontally twice as fast as the populations are growing and over some of the best agriculture land. The other 300 million will be the toll of soil degradation.\n4. At least half of the total erosion will be in the world's 45 million square kilometers of potentially productive but ecologically precarious dry lands, which stretch through a hundred nations. About 700 million people live in this zone, almost all of them in developing countries, and 18 million live in areas that are currently undergoing rapid desertification.\n5. Everywhere the deserts are advancing. In Sudan, the southern edge of the Sahara moved south by 100 kms between 1958 and 1957. The deserts do not march forward on a solid font, like an army. Patches appear, like those at Aorema in Burkina Faso, around centers of population or watering holes, then spread, link up with others, and finally merge into the desert itself.\n6. The chief agent of what has been called leprosy of the soil is man, the impart of his activates on highly sensitive and delicately balanced ecosystems. The prime factor in the process is population increase. The number of people in the Sahel, for example, is doubling every 25 to 30 years. We can see everywhere the consequences of this among settled farmers: the cutting down of fallow periods, progressive decline in the vegetation cover, increasing erosion. As population goes on growing cultivation is pushed into areas that are entirely unsuitable for agriculture, and there the process progresses even more rapidly.\n\nTaken from English four, ETC, department of English"
    ],
    "images": [],
    "choices": [
      {
        "id": 8492,
        "content": [
          "Spread of cities along the main roads."
        ],
        "isCorrect": false
      },
      {
        "id": 8493,
        "content": [
          "Establishment of a city to be followed by another in short distance"
        ],
        "isCorrect": false
      },
      {
        "id": 8494,
        "content": [
          "Establishment of mega cities on farmlands"
        ],
        "isCorrect": false
      },
      {
        "id": 8495,
        "content": [
          "Establishment and spread of cities into the farmland"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2122,
    "content": [
      "Read the passage and choose the best answer for the questions that follow.",
      "---",
      "How many Africa countries have specifically been mentioned as those in danger of desertification?"
    ],
    "explanation": [
      "The passage mentions several regions in Africa like the \"Horn of Africa\" and \"the Sahel,\" but it specifically names only two countries: \"Sudan\" and \"Burkina Faso\" in paragraph 5."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 65,
    "groupIndex": null,
    "sharedContentId": 16,
    "sharedContent": [
      "### **The Shrinking Earth: Ecological Threats**\n\n1. In 1977, the Food and Agriculture Organization (FAO) and UNESCO jointly published an alarming map of the spread of deserts across the world. Shaded in orange, pink and red were all the areas in danger of desertification. The coloured patches a major part of the developing world outside the rainy equatorial belt. In Latin America they covered north east Brazil, central and northern Mexico and stretched right down the Andes as far as Chili. They ate in to the Horn of Africa and much of the south west of the continent. And without interruption they reached half way round the globe in a broad swath from the Atlantic coast of the Sahara, right across North Africa and the Sahel, through the Middle East and Persia to Pakistan and north west India.\n2. There could be no more graphic expression of the ecological dangers that threaten so much food production, so many livelihoods in the developing countries. The world is losing precious agriculture land at twice the rate that new land is being broken for farming. An area greater than great Britain is disappearing every year. Soil is being exhausted, eroded, and blown away at the rate of two and a half billion tons per year. By the end of the century, the world may have to support one and a half times its present population on only three quarters of its present cultivated area.\n3. In this report on the state of the environment in 1977, United Nations Environment Programme Director, Mostafa Tolba, warned that, if present trends continue, there would by only 0.15 hectares of farm land per person by the year 2000, half the 1975 level. Productivity would have to double merely to allow people to get the same amount of food as today, these are the figures on which he based that cultivation: in 1975 there were 1240 million hectares under cultivation. Over the next 25 years, perhaps another 300 million new hectares may be opened up but over the same period 600 million hectares half the entire 1975 cultivated area may be lost of these, half will probably disappear under the ink - blot spread of cities, which are expanding horizontally twice as fast as the populations are growing and over some of the best agriculture land. The other 300 million will be the toll of soil degradation.\n4. At least half of the total erosion will be in the world's 45 million square kilometers of potentially productive but ecologically precarious dry lands, which stretch through a hundred nations. About 700 million people live in this zone, almost all of them in developing countries, and 18 million live in areas that are currently undergoing rapid desertification.\n5. Everywhere the deserts are advancing. In Sudan, the southern edge of the Sahara moved south by 100 kms between 1958 and 1957. The deserts do not march forward on a solid font, like an army. Patches appear, like those at Aorema in Burkina Faso, around centers of population or watering holes, then spread, link up with others, and finally merge into the desert itself.\n6. The chief agent of what has been called leprosy of the soil is man, the impart of his activates on highly sensitive and delicately balanced ecosystems. The prime factor in the process is population increase. The number of people in the Sahel, for example, is doubling every 25 to 30 years. We can see everywhere the consequences of this among settled farmers: the cutting down of fallow periods, progressive decline in the vegetation cover, increasing erosion. As population goes on growing cultivation is pushed into areas that are entirely unsuitable for agriculture, and there the process progresses even more rapidly.\n\nTaken from English four, ETC, department of English"
    ],
    "images": [],
    "choices": [
      {
        "id": 8496,
        "content": [
          "2"
        ],
        "isCorrect": true
      },
      {
        "id": 8497,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 8498,
        "content": [
          "4"
        ],
        "isCorrect": false
      },
      {
        "id": 8499,
        "content": [
          "3"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2123,
    "content": [
      "Read the passage and choose the best answer for the questions that follow.",
      "---",
      "What is the main idea conveyed in paragraph 1"
    ],
    "explanation": [
      "The paragraph begins by describing the \"alarming map\" published jointly by FAO and UNESCO to show the global threat of desertification. This action of creating and publishing such a detailed, alarming map is a clear demonstration of their serious concern about the issue."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 65,
    "groupIndex": null,
    "sharedContentId": 16,
    "sharedContent": [
      "### **The Shrinking Earth: Ecological Threats**\n\n1. In 1977, the Food and Agriculture Organization (FAO) and UNESCO jointly published an alarming map of the spread of deserts across the world. Shaded in orange, pink and red were all the areas in danger of desertification. The coloured patches a major part of the developing world outside the rainy equatorial belt. In Latin America they covered north east Brazil, central and northern Mexico and stretched right down the Andes as far as Chili. They ate in to the Horn of Africa and much of the south west of the continent. And without interruption they reached half way round the globe in a broad swath from the Atlantic coast of the Sahara, right across North Africa and the Sahel, through the Middle East and Persia to Pakistan and north west India.\n2. There could be no more graphic expression of the ecological dangers that threaten so much food production, so many livelihoods in the developing countries. The world is losing precious agriculture land at twice the rate that new land is being broken for farming. An area greater than great Britain is disappearing every year. Soil is being exhausted, eroded, and blown away at the rate of two and a half billion tons per year. By the end of the century, the world may have to support one and a half times its present population on only three quarters of its present cultivated area.\n3. In this report on the state of the environment in 1977, United Nations Environment Programme Director, Mostafa Tolba, warned that, if present trends continue, there would by only 0.15 hectares of farm land per person by the year 2000, half the 1975 level. Productivity would have to double merely to allow people to get the same amount of food as today, these are the figures on which he based that cultivation: in 1975 there were 1240 million hectares under cultivation. Over the next 25 years, perhaps another 300 million new hectares may be opened up but over the same period 600 million hectares half the entire 1975 cultivated area may be lost of these, half will probably disappear under the ink - blot spread of cities, which are expanding horizontally twice as fast as the populations are growing and over some of the best agriculture land. The other 300 million will be the toll of soil degradation.\n4. At least half of the total erosion will be in the world's 45 million square kilometers of potentially productive but ecologically precarious dry lands, which stretch through a hundred nations. About 700 million people live in this zone, almost all of them in developing countries, and 18 million live in areas that are currently undergoing rapid desertification.\n5. Everywhere the deserts are advancing. In Sudan, the southern edge of the Sahara moved south by 100 kms between 1958 and 1957. The deserts do not march forward on a solid font, like an army. Patches appear, like those at Aorema in Burkina Faso, around centers of population or watering holes, then spread, link up with others, and finally merge into the desert itself.\n6. The chief agent of what has been called leprosy of the soil is man, the impart of his activates on highly sensitive and delicately balanced ecosystems. The prime factor in the process is population increase. The number of people in the Sahel, for example, is doubling every 25 to 30 years. We can see everywhere the consequences of this among settled farmers: the cutting down of fallow periods, progressive decline in the vegetation cover, increasing erosion. As population goes on growing cultivation is pushed into areas that are entirely unsuitable for agriculture, and there the process progresses even more rapidly.\n\nTaken from English four, ETC, department of English"
    ],
    "images": [],
    "choices": [
      {
        "id": 8500,
        "content": [
          "Deserts affected developing countries more than they did the developed ones."
        ],
        "isCorrect": false
      },
      {
        "id": 8501,
        "content": [
          "Africa has been more seriously affected by desert than Latin America."
        ],
        "isCorrect": false
      },
      {
        "id": 8502,
        "content": [
          "The areas outside the rainy equatorial belt have not been affected by deserts."
        ],
        "isCorrect": false
      },
      {
        "id": 8503,
        "content": [
          "FAO and UNESCO have shown a serious concern about desertification problems."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2124,
    "content": [
      "Read the passage and choose the best answer for the questions that follow.",
      "---",
      "Which of the following sentences reflects Antonio Guterres view towards refugees?\""
    ],
    "explanation": [
      "In paragraph 5, Antonio Guterres is quoted as calling for \"a renewed global commitment to tolerance and protection for people fleeing conflict an persecution.\" This directly states his view that the world needs to show more tolerance towards refugees."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 66,
    "groupIndex": null,
    "sharedContentId": 17,
    "sharedContent": [
      "### UNITED NATIONS\n\n1. Nearly 60 million people have been driven from their homes by war and persecution an unprecedented global exodus that has burdened fragile countries with waves of new comers and littered deserts and seas with the bodies of those who died trying to reach safety. The new figures, released recently by the United Nations refugee agency, paint a staggering picture of a world where new conflicts are erupting and old ones are refusing to subside, driving up the total number displaced people to a record 59.5 million by the end of 2014, the most recent year tallied.\n2. Half of the displaced are children. Nearly 14 million people were newly displaced in 2014, according to the annual report by the office of the United Nations High Commissioner for Refugees to other words, tens of thousands of people were forced to leave their homes every day and seek protection elsewhere \"\"last year, the report found. Tens of millions of others fled in previous years and remain stuck, sometimes for decades, unable to go home of find a permanent new one, according to the refugee agency. The include the more than 2.5 million displaced is the Darfur region of Sudan, and the 1.5 million Afghans still living in Pakistan.\n3. When refugees flee their own countries, most of them wind up in the worlds less developed nations, with Turkey, Iran and Pakistan hosting the largest numbers. One in for refugees now finds shelter in the world's poorest countries, with Ethiopia and Kenya taking many more refugees than, say Britain and France. As the report states. \"\"the global distribution of refugees remains heavily skewed away from wealthier nation and towards the less wealthy.\"\" Even so, there has been a sharp backlash in European capitals against the waves of people coming across the Mediterranean Sea, including many who are fleeing conflict and repression in countries like Syria and Eritrea. For now, the European Union has shelved its plans to get approval from the Unite Nations Security Council to target human smugglers who operate in lawless Libya and to destroy the shops they use to bring migrants across the sea. Instead, the European Union is scheduled to meet on Monday to discuss whether it will start military operations in the international waters of the Mediterranean Sea, for which it does not need the council's blessings.\n4. European Union leaders are still squabbling with one another over how to split up at least 40,000 asylum seekers across their 28 member states. And they have stepped up search and rescue operation after intense public pressure stemming from a sharp increase in the deaths of migrants crossing the Mediterranean this year. Australia has felt no such compaction. Its prime minister, Tony Abbott, has pledged to turn around migrate boats before they enter Australian territorial water, including those with minority Rohingyas fleeing persecution in Myanmar. His administration faces scrutiny over allegations that it paid smugglers to turn a boat back to Indonesia after it was intercepted on the high seas.\n5. \"\"For an age of unprecedented mass displacement, we need an unprecedented humanitarian response and a renewed global commitment to tolerance and protection for people fleeing conflict an persecution.\"\" Antonio Guterres, the high commissioner for refugees, said in a statement accompanying the annual report.\"\"\n6. Amnesty international in a report issued this week, accused governments and smugglers alike of pursuing\"\" selfish political interest instead of showing basic human compassion.\"\" The United States offers permanent resettlement to roughly 70,000 refugees each year, though its plants too admit 2,000 Syrian refugees this year have drawn scrutiny from Republican lawmakers who worry that some among them might be terrorists. The war in Syria is the largest source of displacement. By the end of 2014, 7.6 million Syrians were displaced within the country itself, and nearly another 3.9 million were refugees living outside the war torn nation.\n\nSource: United National English Language Programme"
    ],
    "images": [],
    "choices": [
      {
        "id": 8504,
        "content": [
          "People are being persecuted at an unprecedented rate."
        ],
        "isCorrect": false
      },
      {
        "id": 8505,
        "content": [
          "The world should be more tolerant to those displaced from their homes."
        ],
        "isCorrect": true
      },
      {
        "id": 8506,
        "content": [
          "People who flee conflict and persecution need to be more tolerant."
        ],
        "isCorrect": false
      },
      {
        "id": 8507,
        "content": [
          "We need to be aware that there is an unprecedented humanitarian response today."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2125,
    "content": [
      "Read the passage and choose the best answer for the questions that follow.",
      "---",
      "Why is the Unites States reluctant to admit Syrian refugees?"
    ],
    "explanation": [
      "Paragraph 6 states that the U.S. plans to admit Syrian refugees \"have drawn scrutiny from Republican lawmakers who worry that some among them might be terrorists.\" This fear of potential terrorists among the refugees is the reason for the reluctance."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 66,
    "groupIndex": null,
    "sharedContentId": 17,
    "sharedContent": [
      "### UNITED NATIONS\n\n1. Nearly 60 million people have been driven from their homes by war and persecution an unprecedented global exodus that has burdened fragile countries with waves of new comers and littered deserts and seas with the bodies of those who died trying to reach safety. The new figures, released recently by the United Nations refugee agency, paint a staggering picture of a world where new conflicts are erupting and old ones are refusing to subside, driving up the total number displaced people to a record 59.5 million by the end of 2014, the most recent year tallied.\n2. Half of the displaced are children. Nearly 14 million people were newly displaced in 2014, according to the annual report by the office of the United Nations High Commissioner for Refugees to other words, tens of thousands of people were forced to leave their homes every day and seek protection elsewhere \"\"last year, the report found. Tens of millions of others fled in previous years and remain stuck, sometimes for decades, unable to go home of find a permanent new one, according to the refugee agency. The include the more than 2.5 million displaced is the Darfur region of Sudan, and the 1.5 million Afghans still living in Pakistan.\n3. When refugees flee their own countries, most of them wind up in the worlds less developed nations, with Turkey, Iran and Pakistan hosting the largest numbers. One in for refugees now finds shelter in the world's poorest countries, with Ethiopia and Kenya taking many more refugees than, say Britain and France. As the report states. \"\"the global distribution of refugees remains heavily skewed away from wealthier nation and towards the less wealthy.\"\" Even so, there has been a sharp backlash in European capitals against the waves of people coming across the Mediterranean Sea, including many who are fleeing conflict and repression in countries like Syria and Eritrea. For now, the European Union has shelved its plans to get approval from the Unite Nations Security Council to target human smugglers who operate in lawless Libya and to destroy the shops they use to bring migrants across the sea. Instead, the European Union is scheduled to meet on Monday to discuss whether it will start military operations in the international waters of the Mediterranean Sea, for which it does not need the council's blessings.\n4. European Union leaders are still squabbling with one another over how to split up at least 40,000 asylum seekers across their 28 member states. And they have stepped up search and rescue operation after intense public pressure stemming from a sharp increase in the deaths of migrants crossing the Mediterranean this year. Australia has felt no such compaction. Its prime minister, Tony Abbott, has pledged to turn around migrate boats before they enter Australian territorial water, including those with minority Rohingyas fleeing persecution in Myanmar. His administration faces scrutiny over allegations that it paid smugglers to turn a boat back to Indonesia after it was intercepted on the high seas.\n5. \"\"For an age of unprecedented mass displacement, we need an unprecedented humanitarian response and a renewed global commitment to tolerance and protection for people fleeing conflict an persecution.\"\" Antonio Guterres, the high commissioner for refugees, said in a statement accompanying the annual report.\"\"\n6. Amnesty international in a report issued this week, accused governments and smugglers alike of pursuing\"\" selfish political interest instead of showing basic human compassion.\"\" The United States offers permanent resettlement to roughly 70,000 refugees each year, though its plants too admit 2,000 Syrian refugees this year have drawn scrutiny from Republican lawmakers who worry that some among them might be terrorists. The war in Syria is the largest source of displacement. By the end of 2014, 7.6 million Syrians were displaced within the country itself, and nearly another 3.9 million were refugees living outside the war torn nation.\n\nSource: United National English Language Programme"
    ],
    "images": [],
    "choices": [
      {
        "id": 8508,
        "content": [
          "Because it runs own political interest."
        ],
        "isCorrect": false
      },
      {
        "id": 8509,
        "content": [
          "Because there are terrorists mixed with the refugees."
        ],
        "isCorrect": true
      },
      {
        "id": 8510,
        "content": [
          "Because it is possible for the refugees to settle with in Syria."
        ],
        "isCorrect": false
      },
      {
        "id": 8511,
        "content": [
          "Because Republican lawmakers do not trust the refugees."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2126,
    "content": [
      "Read the passage and choose the best answer for the questions that follow.",
      "---",
      "According to paragraph 2, which one of the following sentences is NOT true?"
    ],
    "explanation": [
      "Paragraph 2 states that millions of refugees \"remain stuck... unable to go home,\" which describes their situation, not their desire. The passage does not provide information about whether the Afghans want to go home or not, only that they are still in Pakistan and unable to leave."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 66,
    "groupIndex": null,
    "sharedContentId": 17,
    "sharedContent": [
      "### UNITED NATIONS\n\n1. Nearly 60 million people have been driven from their homes by war and persecution an unprecedented global exodus that has burdened fragile countries with waves of new comers and littered deserts and seas with the bodies of those who died trying to reach safety. The new figures, released recently by the United Nations refugee agency, paint a staggering picture of a world where new conflicts are erupting and old ones are refusing to subside, driving up the total number displaced people to a record 59.5 million by the end of 2014, the most recent year tallied.\n2. Half of the displaced are children. Nearly 14 million people were newly displaced in 2014, according to the annual report by the office of the United Nations High Commissioner for Refugees to other words, tens of thousands of people were forced to leave their homes every day and seek protection elsewhere \"\"last year, the report found. Tens of millions of others fled in previous years and remain stuck, sometimes for decades, unable to go home of find a permanent new one, according to the refugee agency. The include the more than 2.5 million displaced is the Darfur region of Sudan, and the 1.5 million Afghans still living in Pakistan.\n3. When refugees flee their own countries, most of them wind up in the worlds less developed nations, with Turkey, Iran and Pakistan hosting the largest numbers. One in for refugees now finds shelter in the world's poorest countries, with Ethiopia and Kenya taking many more refugees than, say Britain and France. As the report states. \"\"the global distribution of refugees remains heavily skewed away from wealthier nation and towards the less wealthy.\"\" Even so, there has been a sharp backlash in European capitals against the waves of people coming across the Mediterranean Sea, including many who are fleeing conflict and repression in countries like Syria and Eritrea. For now, the European Union has shelved its plans to get approval from the Unite Nations Security Council to target human smugglers who operate in lawless Libya and to destroy the shops they use to bring migrants across the sea. Instead, the European Union is scheduled to meet on Monday to discuss whether it will start military operations in the international waters of the Mediterranean Sea, for which it does not need the council's blessings.\n4. European Union leaders are still squabbling with one another over how to split up at least 40,000 asylum seekers across their 28 member states. And they have stepped up search and rescue operation after intense public pressure stemming from a sharp increase in the deaths of migrants crossing the Mediterranean this year. Australia has felt no such compaction. Its prime minister, Tony Abbott, has pledged to turn around migrate boats before they enter Australian territorial water, including those with minority Rohingyas fleeing persecution in Myanmar. His administration faces scrutiny over allegations that it paid smugglers to turn a boat back to Indonesia after it was intercepted on the high seas.\n5. \"\"For an age of unprecedented mass displacement, we need an unprecedented humanitarian response and a renewed global commitment to tolerance and protection for people fleeing conflict an persecution.\"\" Antonio Guterres, the high commissioner for refugees, said in a statement accompanying the annual report.\"\"\n6. Amnesty international in a report issued this week, accused governments and smugglers alike of pursuing\"\" selfish political interest instead of showing basic human compassion.\"\" The United States offers permanent resettlement to roughly 70,000 refugees each year, though its plants too admit 2,000 Syrian refugees this year have drawn scrutiny from Republican lawmakers who worry that some among them might be terrorists. The war in Syria is the largest source of displacement. By the end of 2014, 7.6 million Syrians were displaced within the country itself, and nearly another 3.9 million were refugees living outside the war torn nation.\n\nSource: United National English Language Programme"
    ],
    "images": [],
    "choices": [
      {
        "id": 8512,
        "content": [
          "Compared to the adolescent or the elderly emigrant, children are larger in number."
        ],
        "isCorrect": false
      },
      {
        "id": 8513,
        "content": [
          "The 1.5 million Afghans living in Pakistan do not seem to want to go back home."
        ],
        "isCorrect": true
      },
      {
        "id": 8514,
        "content": [
          "Newly dislocated people in 2014 make up nearly a quarter of the total number of dis placed people."
        ],
        "isCorrect": false
      },
      {
        "id": 8515,
        "content": [
          "Relatively a significant number of those who flee their countries fail to find permanent homes."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2127,
    "content": [
      "Read the passage and choose the best answer for the questions that follow.",
      "---",
      "What is the paradox that one can see in paragraph 3?"
    ],
    "explanation": [
      "Paragraph 3 highlights a paradox by stating that most refugees end up in \"less developed nations\" and \"the world's poorest countries,\" and that the distribution is \"heavily skewed away from wealthier nation.\" This means that countries with fewer resources are bearing a larger burden."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 66,
    "groupIndex": null,
    "sharedContentId": 17,
    "sharedContent": [
      "### UNITED NATIONS\n\n1. Nearly 60 million people have been driven from their homes by war and persecution an unprecedented global exodus that has burdened fragile countries with waves of new comers and littered deserts and seas with the bodies of those who died trying to reach safety. The new figures, released recently by the United Nations refugee agency, paint a staggering picture of a world where new conflicts are erupting and old ones are refusing to subside, driving up the total number displaced people to a record 59.5 million by the end of 2014, the most recent year tallied.\n2. Half of the displaced are children. Nearly 14 million people were newly displaced in 2014, according to the annual report by the office of the United Nations High Commissioner for Refugees to other words, tens of thousands of people were forced to leave their homes every day and seek protection elsewhere \"\"last year, the report found. Tens of millions of others fled in previous years and remain stuck, sometimes for decades, unable to go home of find a permanent new one, according to the refugee agency. The include the more than 2.5 million displaced is the Darfur region of Sudan, and the 1.5 million Afghans still living in Pakistan.\n3. When refugees flee their own countries, most of them wind up in the worlds less developed nations, with Turkey, Iran and Pakistan hosting the largest numbers. One in for refugees now finds shelter in the world's poorest countries, with Ethiopia and Kenya taking many more refugees than, say Britain and France. As the report states. \"\"the global distribution of refugees remains heavily skewed away from wealthier nation and towards the less wealthy.\"\" Even so, there has been a sharp backlash in European capitals against the waves of people coming across the Mediterranean Sea, including many who are fleeing conflict and repression in countries like Syria and Eritrea. For now, the European Union has shelved its plans to get approval from the Unite Nations Security Council to target human smugglers who operate in lawless Libya and to destroy the shops they use to bring migrants across the sea. Instead, the European Union is scheduled to meet on Monday to discuss whether it will start military operations in the international waters of the Mediterranean Sea, for which it does not need the council's blessings.\n4. European Union leaders are still squabbling with one another over how to split up at least 40,000 asylum seekers across their 28 member states. And they have stepped up search and rescue operation after intense public pressure stemming from a sharp increase in the deaths of migrants crossing the Mediterranean this year. Australia has felt no such compaction. Its prime minister, Tony Abbott, has pledged to turn around migrate boats before they enter Australian territorial water, including those with minority Rohingyas fleeing persecution in Myanmar. His administration faces scrutiny over allegations that it paid smugglers to turn a boat back to Indonesia after it was intercepted on the high seas.\n5. \"\"For an age of unprecedented mass displacement, we need an unprecedented humanitarian response and a renewed global commitment to tolerance and protection for people fleeing conflict an persecution.\"\" Antonio Guterres, the high commissioner for refugees, said in a statement accompanying the annual report.\"\"\n6. Amnesty international in a report issued this week, accused governments and smugglers alike of pursuing\"\" selfish political interest instead of showing basic human compassion.\"\" The United States offers permanent resettlement to roughly 70,000 refugees each year, though its plants too admit 2,000 Syrian refugees this year have drawn scrutiny from Republican lawmakers who worry that some among them might be terrorists. The war in Syria is the largest source of displacement. By the end of 2014, 7.6 million Syrians were displaced within the country itself, and nearly another 3.9 million were refugees living outside the war torn nation.\n\nSource: United National English Language Programme"
    ],
    "images": [],
    "choices": [
      {
        "id": 8516,
        "content": [
          "Poor countries take more refugees than the wealthy ones."
        ],
        "isCorrect": true
      },
      {
        "id": 8517,
        "content": [
          "Wealthy countries take more refugees than the poor ones."
        ],
        "isCorrect": false
      },
      {
        "id": 8518,
        "content": [
          "Wealthy countries were supposed to take more refugees than the poor ones."
        ],
        "isCorrect": false
      },
      {
        "id": 8519,
        "content": [
          "People who flee their own countries eventually land in less developed nations."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2128,
    "content": [
      "Read the passage and choose the best answer for the questions that follow.",
      "---",
      "Which countries in paragraph 3 are among those that should take the blame with regard to creating refugees?"
    ],
    "explanation": [
      "Paragraph 3 mentions people \"fleeing conflict and repression in countries like Syria and Eritrea.\" This identifies them as source countries where the conditions that create refugees exist. The other countries listed are mentioned as host nations."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 66,
    "groupIndex": null,
    "sharedContentId": 17,
    "sharedContent": [
      "### UNITED NATIONS\n\n1. Nearly 60 million people have been driven from their homes by war and persecution an unprecedented global exodus that has burdened fragile countries with waves of new comers and littered deserts and seas with the bodies of those who died trying to reach safety. The new figures, released recently by the United Nations refugee agency, paint a staggering picture of a world where new conflicts are erupting and old ones are refusing to subside, driving up the total number displaced people to a record 59.5 million by the end of 2014, the most recent year tallied.\n2. Half of the displaced are children. Nearly 14 million people were newly displaced in 2014, according to the annual report by the office of the United Nations High Commissioner for Refugees to other words, tens of thousands of people were forced to leave their homes every day and seek protection elsewhere \"\"last year, the report found. Tens of millions of others fled in previous years and remain stuck, sometimes for decades, unable to go home of find a permanent new one, according to the refugee agency. The include the more than 2.5 million displaced is the Darfur region of Sudan, and the 1.5 million Afghans still living in Pakistan.\n3. When refugees flee their own countries, most of them wind up in the worlds less developed nations, with Turkey, Iran and Pakistan hosting the largest numbers. One in for refugees now finds shelter in the world's poorest countries, with Ethiopia and Kenya taking many more refugees than, say Britain and France. As the report states. \"\"the global distribution of refugees remains heavily skewed away from wealthier nation and towards the less wealthy.\"\" Even so, there has been a sharp backlash in European capitals against the waves of people coming across the Mediterranean Sea, including many who are fleeing conflict and repression in countries like Syria and Eritrea. For now, the European Union has shelved its plans to get approval from the Unite Nations Security Council to target human smugglers who operate in lawless Libya and to destroy the shops they use to bring migrants across the sea. Instead, the European Union is scheduled to meet on Monday to discuss whether it will start military operations in the international waters of the Mediterranean Sea, for which it does not need the council's blessings.\n4. European Union leaders are still squabbling with one another over how to split up at least 40,000 asylum seekers across their 28 member states. And they have stepped up search and rescue operation after intense public pressure stemming from a sharp increase in the deaths of migrants crossing the Mediterranean this year. Australia has felt no such compaction. Its prime minister, Tony Abbott, has pledged to turn around migrate boats before they enter Australian territorial water, including those with minority Rohingyas fleeing persecution in Myanmar. His administration faces scrutiny over allegations that it paid smugglers to turn a boat back to Indonesia after it was intercepted on the high seas.\n5. \"\"For an age of unprecedented mass displacement, we need an unprecedented humanitarian response and a renewed global commitment to tolerance and protection for people fleeing conflict an persecution.\"\" Antonio Guterres, the high commissioner for refugees, said in a statement accompanying the annual report.\"\"\n6. Amnesty international in a report issued this week, accused governments and smugglers alike of pursuing\"\" selfish political interest instead of showing basic human compassion.\"\" The United States offers permanent resettlement to roughly 70,000 refugees each year, though its plants too admit 2,000 Syrian refugees this year have drawn scrutiny from Republican lawmakers who worry that some among them might be terrorists. The war in Syria is the largest source of displacement. By the end of 2014, 7.6 million Syrians were displaced within the country itself, and nearly another 3.9 million were refugees living outside the war torn nation.\n\nSource: United National English Language Programme"
    ],
    "images": [],
    "choices": [
      {
        "id": 8520,
        "content": [
          "Syria and Eritrea"
        ],
        "isCorrect": true
      },
      {
        "id": 8521,
        "content": [
          "Ethiopia and Kenya"
        ],
        "isCorrect": false
      },
      {
        "id": 8522,
        "content": [
          "Britain and France"
        ],
        "isCorrect": false
      },
      {
        "id": 8523,
        "content": [
          "Turkey, Iran and Pakistan"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2129,
    "content": [
      "Read the passage and choose the best answer for the questions that follow.",
      "---",
      "What made the European Union intensify its search and rescue operations?"
    ],
    "explanation": [
      "Paragraph 4 states that the EU \"stepped up search and rescue operation after intense public pressure.\" While this pressure was caused by the increase in deaths, the public demand was the direct factor that made the EU act."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 66,
    "groupIndex": null,
    "sharedContentId": 17,
    "sharedContent": [
      "### UNITED NATIONS\n\n1. Nearly 60 million people have been driven from their homes by war and persecution an unprecedented global exodus that has burdened fragile countries with waves of new comers and littered deserts and seas with the bodies of those who died trying to reach safety. The new figures, released recently by the United Nations refugee agency, paint a staggering picture of a world where new conflicts are erupting and old ones are refusing to subside, driving up the total number displaced people to a record 59.5 million by the end of 2014, the most recent year tallied.\n2. Half of the displaced are children. Nearly 14 million people were newly displaced in 2014, according to the annual report by the office of the United Nations High Commissioner for Refugees to other words, tens of thousands of people were forced to leave their homes every day and seek protection elsewhere \"\"last year, the report found. Tens of millions of others fled in previous years and remain stuck, sometimes for decades, unable to go home of find a permanent new one, according to the refugee agency. The include the more than 2.5 million displaced is the Darfur region of Sudan, and the 1.5 million Afghans still living in Pakistan.\n3. When refugees flee their own countries, most of them wind up in the worlds less developed nations, with Turkey, Iran and Pakistan hosting the largest numbers. One in for refugees now finds shelter in the world's poorest countries, with Ethiopia and Kenya taking many more refugees than, say Britain and France. As the report states. \"\"the global distribution of refugees remains heavily skewed away from wealthier nation and towards the less wealthy.\"\" Even so, there has been a sharp backlash in European capitals against the waves of people coming across the Mediterranean Sea, including many who are fleeing conflict and repression in countries like Syria and Eritrea. For now, the European Union has shelved its plans to get approval from the Unite Nations Security Council to target human smugglers who operate in lawless Libya and to destroy the shops they use to bring migrants across the sea. Instead, the European Union is scheduled to meet on Monday to discuss whether it will start military operations in the international waters of the Mediterranean Sea, for which it does not need the council's blessings.\n4. European Union leaders are still squabbling with one another over how to split up at least 40,000 asylum seekers across their 28 member states. And they have stepped up search and rescue operation after intense public pressure stemming from a sharp increase in the deaths of migrants crossing the Mediterranean this year. Australia has felt no such compaction. Its prime minister, Tony Abbott, has pledged to turn around migrate boats before they enter Australian territorial water, including those with minority Rohingyas fleeing persecution in Myanmar. His administration faces scrutiny over allegations that it paid smugglers to turn a boat back to Indonesia after it was intercepted on the high seas.\n5. \"\"For an age of unprecedented mass displacement, we need an unprecedented humanitarian response and a renewed global commitment to tolerance and protection for people fleeing conflict an persecution.\"\" Antonio Guterres, the high commissioner for refugees, said in a statement accompanying the annual report.\"\"\n6. Amnesty international in a report issued this week, accused governments and smugglers alike of pursuing\"\" selfish political interest instead of showing basic human compassion.\"\" The United States offers permanent resettlement to roughly 70,000 refugees each year, though its plants too admit 2,000 Syrian refugees this year have drawn scrutiny from Republican lawmakers who worry that some among them might be terrorists. The war in Syria is the largest source of displacement. By the end of 2014, 7.6 million Syrians were displaced within the country itself, and nearly another 3.9 million were refugees living outside the war torn nation.\n\nSource: United National English Language Programme"
    ],
    "images": [],
    "choices": [
      {
        "id": 8524,
        "content": [
          "The sharp increase in death of migrants"
        ],
        "isCorrect": false
      },
      {
        "id": 8525,
        "content": [
          "The serious demand put to them by the public"
        ],
        "isCorrect": true
      },
      {
        "id": 8526,
        "content": [
          "The increasing number of asylum seekers"
        ],
        "isCorrect": false
      },
      {
        "id": 8527,
        "content": [
          "Their intention to send back new arrivals"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2130,
    "content": [
      "Read the passage and choose the best answer for the questions that follow.",
      "---",
      "What does the phrase 'fragile countries' (paragraph 1) refer to?"
    ],
    "explanation": [
      "In paragraph 1, the \"global exodus... has burdened fragile countries with waves of new comers.\" The context indicates that \"fragile countries\" are the nations receiving and hosting the large numbers of refugees, which puts a strain on their resources and makes them fragile."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 66,
    "groupIndex": null,
    "sharedContentId": 17,
    "sharedContent": [
      "### UNITED NATIONS\n\n1. Nearly 60 million people have been driven from their homes by war and persecution an unprecedented global exodus that has burdened fragile countries with waves of new comers and littered deserts and seas with the bodies of those who died trying to reach safety. The new figures, released recently by the United Nations refugee agency, paint a staggering picture of a world where new conflicts are erupting and old ones are refusing to subside, driving up the total number displaced people to a record 59.5 million by the end of 2014, the most recent year tallied.\n2. Half of the displaced are children. Nearly 14 million people were newly displaced in 2014, according to the annual report by the office of the United Nations High Commissioner for Refugees to other words, tens of thousands of people were forced to leave their homes every day and seek protection elsewhere \"\"last year, the report found. Tens of millions of others fled in previous years and remain stuck, sometimes for decades, unable to go home of find a permanent new one, according to the refugee agency. The include the more than 2.5 million displaced is the Darfur region of Sudan, and the 1.5 million Afghans still living in Pakistan.\n3. When refugees flee their own countries, most of them wind up in the worlds less developed nations, with Turkey, Iran and Pakistan hosting the largest numbers. One in for refugees now finds shelter in the world's poorest countries, with Ethiopia and Kenya taking many more refugees than, say Britain and France. As the report states. \"\"the global distribution of refugees remains heavily skewed away from wealthier nation and towards the less wealthy.\"\" Even so, there has been a sharp backlash in European capitals against the waves of people coming across the Mediterranean Sea, including many who are fleeing conflict and repression in countries like Syria and Eritrea. For now, the European Union has shelved its plans to get approval from the Unite Nations Security Council to target human smugglers who operate in lawless Libya and to destroy the shops they use to bring migrants across the sea. Instead, the European Union is scheduled to meet on Monday to discuss whether it will start military operations in the international waters of the Mediterranean Sea, for which it does not need the council's blessings.\n4. European Union leaders are still squabbling with one another over how to split up at least 40,000 asylum seekers across their 28 member states. And they have stepped up search and rescue operation after intense public pressure stemming from a sharp increase in the deaths of migrants crossing the Mediterranean this year. Australia has felt no such compaction. Its prime minister, Tony Abbott, has pledged to turn around migrate boats before they enter Australian territorial water, including those with minority Rohingyas fleeing persecution in Myanmar. His administration faces scrutiny over allegations that it paid smugglers to turn a boat back to Indonesia after it was intercepted on the high seas.\n5. \"\"For an age of unprecedented mass displacement, we need an unprecedented humanitarian response and a renewed global commitment to tolerance and protection for people fleeing conflict an persecution.\"\" Antonio Guterres, the high commissioner for refugees, said in a statement accompanying the annual report.\"\"\n6. Amnesty international in a report issued this week, accused governments and smugglers alike of pursuing\"\" selfish political interest instead of showing basic human compassion.\"\" The United States offers permanent resettlement to roughly 70,000 refugees each year, though its plants too admit 2,000 Syrian refugees this year have drawn scrutiny from Republican lawmakers who worry that some among them might be terrorists. The war in Syria is the largest source of displacement. By the end of 2014, 7.6 million Syrians were displaced within the country itself, and nearly another 3.9 million were refugees living outside the war torn nation.\n\nSource: United National English Language Programme"
    ],
    "images": [],
    "choices": [
      {
        "id": 8528,
        "content": [
          "Countries located around deserts and seas"
        ],
        "isCorrect": false
      },
      {
        "id": 8529,
        "content": [
          "Countries form where people are persecuted for some reason"
        ],
        "isCorrect": false
      },
      {
        "id": 8530,
        "content": [
          "Countries that had to host emigrants from other places"
        ],
        "isCorrect": true
      },
      {
        "id": 8531,
        "content": [
          "Countries form where people leave their homes because of war"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2206,
    "content": [
      "Which one of the following is correctly punctuated?"
    ],
    "explanation": [
      "The sentence consists of two independent clauses. They can be joined by a semicolon. The phrase \"in fact\" is an introductory element for the second clause and should be followed by a comma."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 71,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 8832,
        "content": [
          "I have never been to England; in fact, I have never been outside this country."
        ],
        "isCorrect": true
      },
      {
        "id": 8833,
        "content": [
          "I have never been to England; in fact; I have never been outside this country."
        ],
        "isCorrect": false
      },
      {
        "id": 8834,
        "content": [
          "I have never been to England; in fact I have never been outside this country."
        ],
        "isCorrect": false
      },
      {
        "id": 8835,
        "content": [
          "I have never been to England, in fact, I have never been outside this country."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2207,
    "content": [
      "Which one of the following sentences has correct capitalizations?"
    ],
    "explanation": [
      "Names of languages (like Arabic and French) and the first word of a sentence (The) are proper nouns and should always be capitalized."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 71,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 8836,
        "content": [
          "The language I wanted to learn was arabic, not French."
        ],
        "isCorrect": false
      },
      {
        "id": 8837,
        "content": [
          "The language I wanted to learn was arabic, not french."
        ],
        "isCorrect": false
      },
      {
        "id": 8838,
        "content": [
          "The language I wanted to learn was Arabic, not French."
        ],
        "isCorrect": true
      },
      {
        "id": 8839,
        "content": [
          "the language I wanted to learn was Arabic, not french."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2213,
    "content": [
      "Which of the following contains errors in capitalization, mechanics and punctuation?"
    ],
    "explanation": [
      "This sentence has several errors. There should be a comma after \"brother\" to set off the appositive phrase. The subjects \"Astronomy,\" \"chemistry,\" and \"Mathematics\" should all be capitalized as they are names of specific fields of study in this context, and there should be a preposition like \"to\" before Astronomy, Chemistry and Mathematics."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 71,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 8860,
        "content": [
          "Peter, my elder brother received medals for his contributions Astronomy, chemistry and Mathematics."
        ],
        "isCorrect": true
      },
      {
        "id": 8861,
        "content": [
          "The fire, although it had been burning for several hours, was still blazing fiercely."
        ],
        "isCorrect": false
      },
      {
        "id": 8862,
        "content": [
          "you should, indeed you must report the matter to the police."
        ],
        "isCorrect": false
      },
      {
        "id": 8863,
        "content": [
          "\"When the judge said, 'Not guilty,' I could have hugged him.\""
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2217,
    "content": [
      "Which one of the following is correctly punctuated?"
    ],
    "explanation": [
      "This sentence correctly punctuates a line of dialogue interrupted by an attribution. The first part of the quote ends with a comma inside the quotation marks. The attribution (\"she says\") is followed by a comma, and the second part of the quote begins with a lowercase letter because it continues the same sentence."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 71,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 8876,
        "content": [
          "I have tried to sing dozens of times, she says, \"but I can't.\""
        ],
        "isCorrect": false
      },
      {
        "id": 8877,
        "content": [
          "\"I have tried to sing dozens of times,\" she says, \"but I can't.\""
        ],
        "isCorrect": true
      },
      {
        "id": 8878,
        "content": [
          "\"I have tried to sing dozens of time, \"she say\"but I can't.\""
        ],
        "isCorrect": false
      },
      {
        "id": 8879,
        "content": [
          "\"I have tried to sing dozens of times\" she say, \"but I can't.\""
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2219,
    "content": [
      "Which one of the following is correctly punctuated?"
    ],
    "explanation": [
      "The sentence contains two closely related independent clauses. Using a comma to join them would create a comma splice. A semicolon is the correct punctuation mark to connect two independent clauses in this manner."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 71,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 8884,
        "content": [
          "The meeting ended at dawn, nothing had been decided."
        ],
        "isCorrect": false
      },
      {
        "id": 8885,
        "content": [
          "The meeting ended at dawn nothing had been decided"
        ],
        "isCorrect": false
      },
      {
        "id": 8886,
        "content": [
          "the meeting at dawn nothing had been decided."
        ],
        "isCorrect": false
      },
      {
        "id": 8887,
        "content": [
          "the meeting ended at dawn; nothing had been decided."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2220,
    "content": [
      "Which one of the following sentences has correct capitalization?"
    ],
    "explanation": [
      "Proper nouns, including the specific names of people (Sara, Hana) and institutions (the school \"Learning to Learn\"), must be capitalized. The word \"school\" is a common noun here and should not be capitalized."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 71,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 8888,
        "content": [
          "Sara and Hana first met at a school called Learning to Learn."
        ],
        "isCorrect": true
      },
      {
        "id": 8889,
        "content": [
          "Sara and Hana first met at a school called learning to Learn."
        ],
        "isCorrect": false
      },
      {
        "id": 8890,
        "content": [
          "Sara and Hana first met at a school called Learning to learn."
        ],
        "isCorrect": false
      },
      {
        "id": 8891,
        "content": [
          "Sara and Hana first met at a School called Learning to Learn."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2223,
    "content": [
      "The questions are based on the information in the table. Read the questions carefully and answer them.",
      "---",
      "What is the most useful instrument used to gather the survey data displayed in the table?\""
    ],
    "explanation": [
      "The data is presented as precise percentages for specific, predefined categories of strategies. This type of quantitative data is most effectively and efficiently collected from a group of people using a standardized set of questions, which is a questionnaire."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 74,
    "groupIndex": null,
    "sharedContentId": 18,
    "sharedContent": [
      "A survey was carried out to determine first year university students' essay writing strategies. The survey, in particular, focused on the students'' language use strategies. Below is the summary of the data obtained in response to the questions asked.",
      "images/english/year_2010/shared_1.png"
    ],
    "images": [
      "images/english/year_2010/shared_1.png"
    ],
    "choices": [
      {
        "id": 8900,
        "content": [
          "Questionnaire"
        ],
        "isCorrect": true
      },
      {
        "id": 8901,
        "content": [
          "Observation"
        ],
        "isCorrect": false
      },
      {
        "id": 8902,
        "content": [
          "Classroom observation"
        ],
        "isCorrect": false
      },
      {
        "id": 8903,
        "content": [
          "Interview"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2224,
    "content": [
      "The questions are based on the information in the table. Read the questions carefully and answer them.",
      "---",
      "How many instances of use of L 1 can be observed from the data reported in the table?"
    ],
    "explanation": [
      "Looking at the \"Strategies\" column, there are two distinct strategies that explicitly mention the use of L1 (local language): \"Write in the local language (L 1) & translate\" and \"Outline in L 1 and write in English.\""
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 74,
    "groupIndex": null,
    "sharedContentId": 18,
    "sharedContent": [
      "A survey was carried out to determine first year university students' essay writing strategies. The survey, in particular, focused on the students'' language use strategies. Below is the summary of the data obtained in response to the questions asked.",
      "images/english/year_2010/shared_1.png"
    ],
    "images": [
      "images/english/year_2010/shared_1.png"
    ],
    "choices": [
      {
        "id": 8904,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 8905,
        "content": [
          "2"
        ],
        "isCorrect": true
      },
      {
        "id": 8906,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 8907,
        "content": [
          "4"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2225,
    "content": [
      "The questions are based on the information in the table. Read the questions carefully and answer them.",
      "---",
      "From the data in the above table, what proportion of first year university students considered in the survey wrote their essays directly In English?"
    ],
    "explanation": [
      "The table shows that 25% of students chose the strategy \"Write directly in English.\" The fractional equivalent of 25% is 1/4, or a quarter."
    ],
    "year": "YEAR_2010",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 74,
    "groupIndex": null,
    "sharedContentId": 18,
    "sharedContent": [
      "A survey was carried out to determine first year university students' essay writing strategies. The survey, in particular, focused on the students'' language use strategies. Below is the summary of the data obtained in response to the questions asked.",
      "images/english/year_2010/shared_1.png"
    ],
    "images": [
      "images/english/year_2010/shared_1.png"
    ],
    "choices": [
      {
        "id": 8908,
        "content": [
          "A quarter"
        ],
        "isCorrect": true
      },
      {
        "id": 8909,
        "content": [
          "Three- fourths"
        ],
        "isCorrect": false
      },
      {
        "id": 8910,
        "content": [
          "Two-thirds"
        ],
        "isCorrect": false
      },
      {
        "id": 8911,
        "content": [
          "Half"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2237,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What does the phrase.... this type of cheating.... (Para. 3, last sentence) refer to?"
    ],
    "explanation": [
      "The sentence just before the phrase discusses how graphing calculators \"have the capabilities to store material.\" The phrase \"this type of cheating\" directly refers to the specific action mentioned immediately prior, which is storing materials on calculators."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 77,
    "groupIndex": 1,
    "sharedContentId": 19,
    "sharedContent": [
      "**Reasons and Solutions to Student Exam and Essay Cheating**",
      "1. Cheating comes in many variations. Just because you are not leaning over and peaking at somebody else's exam, it does not mean that you are not cheating. Cheating includes any dishonest action used by a student to complete an assignment without actually having to complete it themselves. Some of the most common forms of cheating are looking at someone else's exam, using materials without permission, collaborating with other students without permission, and not reporting another student if you see that he or she is cheating. Students cheat for all types of reasons: pressure to succeed, lack of time to study, peer pressure, laziness, and the list goes on. While schools claim that a student can be expelled for cheating, many cheating students escape the consequences. I do not think that it's possible to set consequences based on the reason why a person cheated because the severity of a reason can be relative, but it's more logical to base consequences on the method in which the cheating was done.",
      "2. Perhaps the most classic form of cheating on an exam is taking a quick peek at the exam of the person sitting next to you or in front of you. Oftentimes it's easy to see answers in the corner of your eye and the teacher seldom notices. I believe that this type of cheating should result in automatic failure of the exam, no questions asked. Likewise, if the student tries to cheat again then he or she should fail the whole course. Looking at someone else's exam is extremely unfair because you're putting forth no effort to complete the work, and you're benefitting from someone else's hard work. Students generally do this when they're not confident in their own answers and they want confirmation of the correct answer, but that doesn't make it acceptable. Not enforcing consequences for this type of cheating will result in the student feeling as if he or she never has to study or do work, because there will always be someone to copy off. One possible way to solve this problem is to have the exam questions in different orders so that a student would have to really try in order to steal someone's answers, and it would make it more noticeable for the teacher.",
      "3. Using restricted material is another common form of cheating. Students find ways to sneak in note-cards, write answers on their hands, peek at a textbook, or store information in electronic devices. Students usually do this to ensure that they don't forget any information while taking the test. The best way to prevent any of these actions from happening is for the teacher to walk around the room and make sure that there is no material present. Unfortunately, technology makes this difficult. If a student is taking a math test then oftentimes a graphing calculator is needed, but these calculators have the capabilities to store material. I feel that if a student tries to cheat in this manner then the consequences should be that they are no longer able to use a calculator in future exams and they will fail the current test. Not allowing calculators during future exams would be a drastic consequence because many algebra and geometry tests require calculators. Obviously, if this type of cheating occurred again then the student should fail the course. If this type of cheating is not stopped, then students will see no need to study or read their textbooks because they can just record the information.",
      "4. Although many students do not realize that unapproved collaboration is a form of cheating, it actually is. Sometimes the teacher will walk out of the room or the classroom is so big that it's impossible to hear whispering. Collaborating with classmates during an exam that is supposed to be done by each individual is dishonest. The consequence for this type of cheating should be failing the test, being separated from the class for future tests, and failing the class if it happens again. Collaborating with classmates gives some students an advantage over the ones that are not doing so, and it fails to reflect the skills of each individual. Obviously cheating in this way is a huge disadvantage to the student because they are not always going to have someone there to help.",
      "5. Lastly, failing to report someone else's cheating or allowing someone to copy cheat off you is a form of cheating. Most students are not willing to report a cheater because they are concerned about the reactions they will get from their classmates. There are ways to anonymously report a cheater. While you may feel like you are throwing someone under the bus, you will actually be harming a lot more people if you don't tell. If someone in the class gets a perfect score because they cheated, then the curve of the test might be higher, and the expectations for high scores will also be higher. People that are not cheating do not have the same advantage as the ones that are, they did the hard work, and they are going to be the ones that get the short end of the stick. The consequences for not reporting a cheater should not be as severe as the ones for cheating. In fact, the consequences are mostly personal because it's nearly impossible to tell if someone knows someone else cheated. The consequences are that you put in a lot of time and effort to study and you have less of a chance of getting a good grade."
    ],
    "images": [],
    "choices": [
      {
        "id": 8956,
        "content": [
          "Using restricted materials"
        ],
        "isCorrect": false
      },
      {
        "id": 8957,
        "content": [
          "Sneaking in cards to take notes"
        ],
        "isCorrect": false
      },
      {
        "id": 8958,
        "content": [
          "Using calculators during maths tests"
        ],
        "isCorrect": false
      },
      {
        "id": 8959,
        "content": [
          "Storing materials on calculators"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2238,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "According to the first paragraph, what consequence do cheaters in schools face?"
    ],
    "explanation": [
      "Paragraph 1 states, \"While schools claim that a student can be expelled for cheating, many cheating students escape the consequences.\" This directly mentions expulsion as a potential consequence claimed by schools."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 77,
    "groupIndex": 2,
    "sharedContentId": 19,
    "sharedContent": [
      "**Reasons and Solutions to Student Exam and Essay Cheating**",
      "1. Cheating comes in many variations. Just because you are not leaning over and peaking at somebody else's exam, it does not mean that you are not cheating. Cheating includes any dishonest action used by a student to complete an assignment without actually having to complete it themselves. Some of the most common forms of cheating are looking at someone else's exam, using materials without permission, collaborating with other students without permission, and not reporting another student if you see that he or she is cheating. Students cheat for all types of reasons: pressure to succeed, lack of time to study, peer pressure, laziness, and the list goes on. While schools claim that a student can be expelled for cheating, many cheating students escape the consequences. I do not think that it's possible to set consequences based on the reason why a person cheated because the severity of a reason can be relative, but it's more logical to base consequences on the method in which the cheating was done.",
      "2. Perhaps the most classic form of cheating on an exam is taking a quick peek at the exam of the person sitting next to you or in front of you. Oftentimes it's easy to see answers in the corner of your eye and the teacher seldom notices. I believe that this type of cheating should result in automatic failure of the exam, no questions asked. Likewise, if the student tries to cheat again then he or she should fail the whole course. Looking at someone else's exam is extremely unfair because you're putting forth no effort to complete the work, and you're benefitting from someone else's hard work. Students generally do this when they're not confident in their own answers and they want confirmation of the correct answer, but that doesn't make it acceptable. Not enforcing consequences for this type of cheating will result in the student feeling as if he or she never has to study or do work, because there will always be someone to copy off. One possible way to solve this problem is to have the exam questions in different orders so that a student would have to really try in order to steal someone's answers, and it would make it more noticeable for the teacher.",
      "3. Using restricted material is another common form of cheating. Students find ways to sneak in note-cards, write answers on their hands, peek at a textbook, or store information in electronic devices. Students usually do this to ensure that they don't forget any information while taking the test. The best way to prevent any of these actions from happening is for the teacher to walk around the room and make sure that there is no material present. Unfortunately, technology makes this difficult. If a student is taking a math test then oftentimes a graphing calculator is needed, but these calculators have the capabilities to store material. I feel that if a student tries to cheat in this manner then the consequences should be that they are no longer able to use a calculator in future exams and they will fail the current test. Not allowing calculators during future exams would be a drastic consequence because many algebra and geometry tests require calculators. Obviously, if this type of cheating occurred again then the student should fail the course. If this type of cheating is not stopped, then students will see no need to study or read their textbooks because they can just record the information.",
      "4. Although many students do not realize that unapproved collaboration is a form of cheating, it actually is. Sometimes the teacher will walk out of the room or the classroom is so big that it's impossible to hear whispering. Collaborating with classmates during an exam that is supposed to be done by each individual is dishonest. The consequence for this type of cheating should be failing the test, being separated from the class for future tests, and failing the class if it happens again. Collaborating with classmates gives some students an advantage over the ones that are not doing so, and it fails to reflect the skills of each individual. Obviously cheating in this way is a huge disadvantage to the student because they are not always going to have someone there to help.",
      "5. Lastly, failing to report someone else's cheating or allowing someone to copy cheat off you is a form of cheating. Most students are not willing to report a cheater because they are concerned about the reactions they will get from their classmates. There are ways to anonymously report a cheater. While you may feel like you are throwing someone under the bus, you will actually be harming a lot more people if you don't tell. If someone in the class gets a perfect score because they cheated, then the curve of the test might be higher, and the expectations for high scores will also be higher. People that are not cheating do not have the same advantage as the ones that are, they did the hard work, and they are going to be the ones that get the short end of the stick. The consequences for not reporting a cheater should not be as severe as the ones for cheating. In fact, the consequences are mostly personal because it's nearly impossible to tell if someone knows someone else cheated. The consequences are that you put in a lot of time and effort to study and you have less of a chance of getting a good grade."
    ],
    "images": [],
    "choices": [
      {
        "id": 8960,
        "content": [
          "reprimand"
        ],
        "isCorrect": false
      },
      {
        "id": 8961,
        "content": [
          "withdrawal"
        ],
        "isCorrect": false
      },
      {
        "id": 8962,
        "content": [
          "expulsion"
        ],
        "isCorrect": true
      },
      {
        "id": 8963,
        "content": [
          "dishonesty"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2239,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What would be the possible situation of students who get the short end of the stick (Para 5)?"
    ],
    "explanation": [
      "Paragraph 5 explains that honest students get \"the short end of the stick\" because cheating can raise the grading curve, making it harder for them to get a good grade despite their hard work. This implies their scores are comparatively lower or less valuable than they should be."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 77,
    "groupIndex": 3,
    "sharedContentId": 19,
    "sharedContent": [
      "**Reasons and Solutions to Student Exam and Essay Cheating**",
      "1. Cheating comes in many variations. Just because you are not leaning over and peaking at somebody else's exam, it does not mean that you are not cheating. Cheating includes any dishonest action used by a student to complete an assignment without actually having to complete it themselves. Some of the most common forms of cheating are looking at someone else's exam, using materials without permission, collaborating with other students without permission, and not reporting another student if you see that he or she is cheating. Students cheat for all types of reasons: pressure to succeed, lack of time to study, peer pressure, laziness, and the list goes on. While schools claim that a student can be expelled for cheating, many cheating students escape the consequences. I do not think that it's possible to set consequences based on the reason why a person cheated because the severity of a reason can be relative, but it's more logical to base consequences on the method in which the cheating was done.",
      "2. Perhaps the most classic form of cheating on an exam is taking a quick peek at the exam of the person sitting next to you or in front of you. Oftentimes it's easy to see answers in the corner of your eye and the teacher seldom notices. I believe that this type of cheating should result in automatic failure of the exam, no questions asked. Likewise, if the student tries to cheat again then he or she should fail the whole course. Looking at someone else's exam is extremely unfair because you're putting forth no effort to complete the work, and you're benefitting from someone else's hard work. Students generally do this when they're not confident in their own answers and they want confirmation of the correct answer, but that doesn't make it acceptable. Not enforcing consequences for this type of cheating will result in the student feeling as if he or she never has to study or do work, because there will always be someone to copy off. One possible way to solve this problem is to have the exam questions in different orders so that a student would have to really try in order to steal someone's answers, and it would make it more noticeable for the teacher.",
      "3. Using restricted material is another common form of cheating. Students find ways to sneak in note-cards, write answers on their hands, peek at a textbook, or store information in electronic devices. Students usually do this to ensure that they don't forget any information while taking the test. The best way to prevent any of these actions from happening is for the teacher to walk around the room and make sure that there is no material present. Unfortunately, technology makes this difficult. If a student is taking a math test then oftentimes a graphing calculator is needed, but these calculators have the capabilities to store material. I feel that if a student tries to cheat in this manner then the consequences should be that they are no longer able to use a calculator in future exams and they will fail the current test. Not allowing calculators during future exams would be a drastic consequence because many algebra and geometry tests require calculators. Obviously, if this type of cheating occurred again then the student should fail the course. If this type of cheating is not stopped, then students will see no need to study or read their textbooks because they can just record the information.",
      "4. Although many students do not realize that unapproved collaboration is a form of cheating, it actually is. Sometimes the teacher will walk out of the room or the classroom is so big that it's impossible to hear whispering. Collaborating with classmates during an exam that is supposed to be done by each individual is dishonest. The consequence for this type of cheating should be failing the test, being separated from the class for future tests, and failing the class if it happens again. Collaborating with classmates gives some students an advantage over the ones that are not doing so, and it fails to reflect the skills of each individual. Obviously cheating in this way is a huge disadvantage to the student because they are not always going to have someone there to help.",
      "5. Lastly, failing to report someone else's cheating or allowing someone to copy cheat off you is a form of cheating. Most students are not willing to report a cheater because they are concerned about the reactions they will get from their classmates. There are ways to anonymously report a cheater. While you may feel like you are throwing someone under the bus, you will actually be harming a lot more people if you don't tell. If someone in the class gets a perfect score because they cheated, then the curve of the test might be higher, and the expectations for high scores will also be higher. People that are not cheating do not have the same advantage as the ones that are, they did the hard work, and they are going to be the ones that get the short end of the stick. The consequences for not reporting a cheater should not be as severe as the ones for cheating. In fact, the consequences are mostly personal because it's nearly impossible to tell if someone knows someone else cheated. The consequences are that you put in a lot of time and effort to study and you have less of a chance of getting a good grade."
    ],
    "images": [],
    "choices": [
      {
        "id": 8964,
        "content": [
          "They score higher than those who cheat."
        ],
        "isCorrect": false
      },
      {
        "id": 8965,
        "content": [
          "They score lower than those who cheat."
        ],
        "isCorrect": true
      },
      {
        "id": 8966,
        "content": [
          "They score equally with those who cheat."
        ],
        "isCorrect": false
      },
      {
        "id": 8967,
        "content": [
          "They are compensated for their hard work."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2240,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "According to the passage, who could possibly solve the problem of cheating?"
    ],
    "explanation": [
      "The passage repeatedly suggests solutions that involve the teacher. For example, in paragraph 2, it suggests the teacher should change exam question order. In paragraph 3, it suggests the teacher should walk around the room. These actions place the responsibility for solving the problem on the teacher."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 77,
    "groupIndex": 4,
    "sharedContentId": 19,
    "sharedContent": [
      "**Reasons and Solutions to Student Exam and Essay Cheating**",
      "1. Cheating comes in many variations. Just because you are not leaning over and peaking at somebody else's exam, it does not mean that you are not cheating. Cheating includes any dishonest action used by a student to complete an assignment without actually having to complete it themselves. Some of the most common forms of cheating are looking at someone else's exam, using materials without permission, collaborating with other students without permission, and not reporting another student if you see that he or she is cheating. Students cheat for all types of reasons: pressure to succeed, lack of time to study, peer pressure, laziness, and the list goes on. While schools claim that a student can be expelled for cheating, many cheating students escape the consequences. I do not think that it's possible to set consequences based on the reason why a person cheated because the severity of a reason can be relative, but it's more logical to base consequences on the method in which the cheating was done.",
      "2. Perhaps the most classic form of cheating on an exam is taking a quick peek at the exam of the person sitting next to you or in front of you. Oftentimes it's easy to see answers in the corner of your eye and the teacher seldom notices. I believe that this type of cheating should result in automatic failure of the exam, no questions asked. Likewise, if the student tries to cheat again then he or she should fail the whole course. Looking at someone else's exam is extremely unfair because you're putting forth no effort to complete the work, and you're benefitting from someone else's hard work. Students generally do this when they're not confident in their own answers and they want confirmation of the correct answer, but that doesn't make it acceptable. Not enforcing consequences for this type of cheating will result in the student feeling as if he or she never has to study or do work, because there will always be someone to copy off. One possible way to solve this problem is to have the exam questions in different orders so that a student would have to really try in order to steal someone's answers, and it would make it more noticeable for the teacher.",
      "3. Using restricted material is another common form of cheating. Students find ways to sneak in note-cards, write answers on their hands, peek at a textbook, or store information in electronic devices. Students usually do this to ensure that they don't forget any information while taking the test. The best way to prevent any of these actions from happening is for the teacher to walk around the room and make sure that there is no material present. Unfortunately, technology makes this difficult. If a student is taking a math test then oftentimes a graphing calculator is needed, but these calculators have the capabilities to store material. I feel that if a student tries to cheat in this manner then the consequences should be that they are no longer able to use a calculator in future exams and they will fail the current test. Not allowing calculators during future exams would be a drastic consequence because many algebra and geometry tests require calculators. Obviously, if this type of cheating occurred again then the student should fail the course. If this type of cheating is not stopped, then students will see no need to study or read their textbooks because they can just record the information.",
      "4. Although many students do not realize that unapproved collaboration is a form of cheating, it actually is. Sometimes the teacher will walk out of the room or the classroom is so big that it's impossible to hear whispering. Collaborating with classmates during an exam that is supposed to be done by each individual is dishonest. The consequence for this type of cheating should be failing the test, being separated from the class for future tests, and failing the class if it happens again. Collaborating with classmates gives some students an advantage over the ones that are not doing so, and it fails to reflect the skills of each individual. Obviously cheating in this way is a huge disadvantage to the student because they are not always going to have someone there to help.",
      "5. Lastly, failing to report someone else's cheating or allowing someone to copy cheat off you is a form of cheating. Most students are not willing to report a cheater because they are concerned about the reactions they will get from their classmates. There are ways to anonymously report a cheater. While you may feel like you are throwing someone under the bus, you will actually be harming a lot more people if you don't tell. If someone in the class gets a perfect score because they cheated, then the curve of the test might be higher, and the expectations for high scores will also be higher. People that are not cheating do not have the same advantage as the ones that are, they did the hard work, and they are going to be the ones that get the short end of the stick. The consequences for not reporting a cheater should not be as severe as the ones for cheating. In fact, the consequences are mostly personal because it's nearly impossible to tell if someone knows someone else cheated. The consequences are that you put in a lot of time and effort to study and you have less of a chance of getting a good grade."
    ],
    "images": [],
    "choices": [
      {
        "id": 8968,
        "content": [
          "The exam writer"
        ],
        "isCorrect": false
      },
      {
        "id": 8969,
        "content": [
          "The invigilators"
        ],
        "isCorrect": false
      },
      {
        "id": 8970,
        "content": [
          "The teacher"
        ],
        "isCorrect": true
      },
      {
        "id": 8971,
        "content": [
          "The students"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2241,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What is the writer's view about the consequence of cheating in schools (Para. 1)?"
    ],
    "explanation": [
      "In the last sentence of paragraph 1, the writer states, \"...it's more logical to base consequences on the method in which the cheating was done.\" This clearly indicates the writer's view that the \"how\" (the method) is the most important factor for determining consequences."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 77,
    "groupIndex": 5,
    "sharedContentId": 19,
    "sharedContent": [
      "**Reasons and Solutions to Student Exam and Essay Cheating**",
      "1. Cheating comes in many variations. Just because you are not leaning over and peaking at somebody else's exam, it does not mean that you are not cheating. Cheating includes any dishonest action used by a student to complete an assignment without actually having to complete it themselves. Some of the most common forms of cheating are looking at someone else's exam, using materials without permission, collaborating with other students without permission, and not reporting another student if you see that he or she is cheating. Students cheat for all types of reasons: pressure to succeed, lack of time to study, peer pressure, laziness, and the list goes on. While schools claim that a student can be expelled for cheating, many cheating students escape the consequences. I do not think that it's possible to set consequences based on the reason why a person cheated because the severity of a reason can be relative, but it's more logical to base consequences on the method in which the cheating was done.",
      "2. Perhaps the most classic form of cheating on an exam is taking a quick peek at the exam of the person sitting next to you or in front of you. Oftentimes it's easy to see answers in the corner of your eye and the teacher seldom notices. I believe that this type of cheating should result in automatic failure of the exam, no questions asked. Likewise, if the student tries to cheat again then he or she should fail the whole course. Looking at someone else's exam is extremely unfair because you're putting forth no effort to complete the work, and you're benefitting from someone else's hard work. Students generally do this when they're not confident in their own answers and they want confirmation of the correct answer, but that doesn't make it acceptable. Not enforcing consequences for this type of cheating will result in the student feeling as if he or she never has to study or do work, because there will always be someone to copy off. One possible way to solve this problem is to have the exam questions in different orders so that a student would have to really try in order to steal someone's answers, and it would make it more noticeable for the teacher.",
      "3. Using restricted material is another common form of cheating. Students find ways to sneak in note-cards, write answers on their hands, peek at a textbook, or store information in electronic devices. Students usually do this to ensure that they don't forget any information while taking the test. The best way to prevent any of these actions from happening is for the teacher to walk around the room and make sure that there is no material present. Unfortunately, technology makes this difficult. If a student is taking a math test then oftentimes a graphing calculator is needed, but these calculators have the capabilities to store material. I feel that if a student tries to cheat in this manner then the consequences should be that they are no longer able to use a calculator in future exams and they will fail the current test. Not allowing calculators during future exams would be a drastic consequence because many algebra and geometry tests require calculators. Obviously, if this type of cheating occurred again then the student should fail the course. If this type of cheating is not stopped, then students will see no need to study or read their textbooks because they can just record the information.",
      "4. Although many students do not realize that unapproved collaboration is a form of cheating, it actually is. Sometimes the teacher will walk out of the room or the classroom is so big that it's impossible to hear whispering. Collaborating with classmates during an exam that is supposed to be done by each individual is dishonest. The consequence for this type of cheating should be failing the test, being separated from the class for future tests, and failing the class if it happens again. Collaborating with classmates gives some students an advantage over the ones that are not doing so, and it fails to reflect the skills of each individual. Obviously cheating in this way is a huge disadvantage to the student because they are not always going to have someone there to help.",
      "5. Lastly, failing to report someone else's cheating or allowing someone to copy cheat off you is a form of cheating. Most students are not willing to report a cheater because they are concerned about the reactions they will get from their classmates. There are ways to anonymously report a cheater. While you may feel like you are throwing someone under the bus, you will actually be harming a lot more people if you don't tell. If someone in the class gets a perfect score because they cheated, then the curve of the test might be higher, and the expectations for high scores will also be higher. People that are not cheating do not have the same advantage as the ones that are, they did the hard work, and they are going to be the ones that get the short end of the stick. The consequences for not reporting a cheater should not be as severe as the ones for cheating. In fact, the consequences are mostly personal because it's nearly impossible to tell if someone knows someone else cheated. The consequences are that you put in a lot of time and effort to study and you have less of a chance of getting a good grade."
    ],
    "images": [],
    "choices": [
      {
        "id": 8972,
        "content": [
          "Cheaters should, by any means, face the consequences of their action."
        ],
        "isCorrect": false
      },
      {
        "id": 8973,
        "content": [
          "How a student cheated should be the main factor for the measure taken."
        ],
        "isCorrect": true
      },
      {
        "id": 8974,
        "content": [
          "It is not surprising that some students evade punishment after cheating."
        ],
        "isCorrect": false
      },
      {
        "id": 8975,
        "content": [
          "The measure taken for cheating should consider why a student cheated."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2242,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which one of the following sentences best summarizes Paragraph 2?"
    ],
    "explanation": [
      "Paragraph 2 describes copying from another student as \"extremely unfair\" and argues that not enforcing consequences is unacceptable. It proposes solutions like automatic failure for the exam or the course, showing a zero-tolerance stance towards this form of cheating."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 77,
    "groupIndex": 6,
    "sharedContentId": 19,
    "sharedContent": [
      "**Reasons and Solutions to Student Exam and Essay Cheating**",
      "1. Cheating comes in many variations. Just because you are not leaning over and peaking at somebody else's exam, it does not mean that you are not cheating. Cheating includes any dishonest action used by a student to complete an assignment without actually having to complete it themselves. Some of the most common forms of cheating are looking at someone else's exam, using materials without permission, collaborating with other students without permission, and not reporting another student if you see that he or she is cheating. Students cheat for all types of reasons: pressure to succeed, lack of time to study, peer pressure, laziness, and the list goes on. While schools claim that a student can be expelled for cheating, many cheating students escape the consequences. I do not think that it's possible to set consequences based on the reason why a person cheated because the severity of a reason can be relative, but it's more logical to base consequences on the method in which the cheating was done.",
      "2. Perhaps the most classic form of cheating on an exam is taking a quick peek at the exam of the person sitting next to you or in front of you. Oftentimes it's easy to see answers in the corner of your eye and the teacher seldom notices. I believe that this type of cheating should result in automatic failure of the exam, no questions asked. Likewise, if the student tries to cheat again then he or she should fail the whole course. Looking at someone else's exam is extremely unfair because you're putting forth no effort to complete the work, and you're benefitting from someone else's hard work. Students generally do this when they're not confident in their own answers and they want confirmation of the correct answer, but that doesn't make it acceptable. Not enforcing consequences for this type of cheating will result in the student feeling as if he or she never has to study or do work, because there will always be someone to copy off. One possible way to solve this problem is to have the exam questions in different orders so that a student would have to really try in order to steal someone's answers, and it would make it more noticeable for the teacher.",
      "3. Using restricted material is another common form of cheating. Students find ways to sneak in note-cards, write answers on their hands, peek at a textbook, or store information in electronic devices. Students usually do this to ensure that they don't forget any information while taking the test. The best way to prevent any of these actions from happening is for the teacher to walk around the room and make sure that there is no material present. Unfortunately, technology makes this difficult. If a student is taking a math test then oftentimes a graphing calculator is needed, but these calculators have the capabilities to store material. I feel that if a student tries to cheat in this manner then the consequences should be that they are no longer able to use a calculator in future exams and they will fail the current test. Not allowing calculators during future exams would be a drastic consequence because many algebra and geometry tests require calculators. Obviously, if this type of cheating occurred again then the student should fail the course. If this type of cheating is not stopped, then students will see no need to study or read their textbooks because they can just record the information.",
      "4. Although many students do not realize that unapproved collaboration is a form of cheating, it actually is. Sometimes the teacher will walk out of the room or the classroom is so big that it's impossible to hear whispering. Collaborating with classmates during an exam that is supposed to be done by each individual is dishonest. The consequence for this type of cheating should be failing the test, being separated from the class for future tests, and failing the class if it happens again. Collaborating with classmates gives some students an advantage over the ones that are not doing so, and it fails to reflect the skills of each individual. Obviously cheating in this way is a huge disadvantage to the student because they are not always going to have someone there to help.",
      "5. Lastly, failing to report someone else's cheating or allowing someone to copy cheat off you is a form of cheating. Most students are not willing to report a cheater because they are concerned about the reactions they will get from their classmates. There are ways to anonymously report a cheater. While you may feel like you are throwing someone under the bus, you will actually be harming a lot more people if you don't tell. If someone in the class gets a perfect score because they cheated, then the curve of the test might be higher, and the expectations for high scores will also be higher. People that are not cheating do not have the same advantage as the ones that are, they did the hard work, and they are going to be the ones that get the short end of the stick. The consequences for not reporting a cheater should not be as severe as the ones for cheating. In fact, the consequences are mostly personal because it's nearly impossible to tell if someone knows someone else cheated. The consequences are that you put in a lot of time and effort to study and you have less of a chance of getting a good grade."
    ],
    "images": [],
    "choices": [
      {
        "id": 8976,
        "content": [
          "Cheating should not be tolerated at all."
        ],
        "isCorrect": true
      },
      {
        "id": 8977,
        "content": [
          "Cheating creates lazy students."
        ],
        "isCorrect": false
      },
      {
        "id": 8978,
        "content": [
          "Cheating discourages hardworking students."
        ],
        "isCorrect": false
      },
      {
        "id": 8979,
        "content": [
          "Students cheat only to confirm their answers."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2243,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which one of the paragraphs below emphasizes the need for showing one's own competence in tests?"
    ],
    "explanation": [
      "Paragraph 4 discusses unapproved collaboration and states that it \"fails to reflect the skills of each individual.\" This directly addresses the idea that tests are meant to show an individual's competence and that collaboration undermines this purpose."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 77,
    "groupIndex": 7,
    "sharedContentId": 19,
    "sharedContent": [
      "**Reasons and Solutions to Student Exam and Essay Cheating**",
      "1. Cheating comes in many variations. Just because you are not leaning over and peaking at somebody else's exam, it does not mean that you are not cheating. Cheating includes any dishonest action used by a student to complete an assignment without actually having to complete it themselves. Some of the most common forms of cheating are looking at someone else's exam, using materials without permission, collaborating with other students without permission, and not reporting another student if you see that he or she is cheating. Students cheat for all types of reasons: pressure to succeed, lack of time to study, peer pressure, laziness, and the list goes on. While schools claim that a student can be expelled for cheating, many cheating students escape the consequences. I do not think that it's possible to set consequences based on the reason why a person cheated because the severity of a reason can be relative, but it's more logical to base consequences on the method in which the cheating was done.",
      "2. Perhaps the most classic form of cheating on an exam is taking a quick peek at the exam of the person sitting next to you or in front of you. Oftentimes it's easy to see answers in the corner of your eye and the teacher seldom notices. I believe that this type of cheating should result in automatic failure of the exam, no questions asked. Likewise, if the student tries to cheat again then he or she should fail the whole course. Looking at someone else's exam is extremely unfair because you're putting forth no effort to complete the work, and you're benefitting from someone else's hard work. Students generally do this when they're not confident in their own answers and they want confirmation of the correct answer, but that doesn't make it acceptable. Not enforcing consequences for this type of cheating will result in the student feeling as if he or she never has to study or do work, because there will always be someone to copy off. One possible way to solve this problem is to have the exam questions in different orders so that a student would have to really try in order to steal someone's answers, and it would make it more noticeable for the teacher.",
      "3. Using restricted material is another common form of cheating. Students find ways to sneak in note-cards, write answers on their hands, peek at a textbook, or store information in electronic devices. Students usually do this to ensure that they don't forget any information while taking the test. The best way to prevent any of these actions from happening is for the teacher to walk around the room and make sure that there is no material present. Unfortunately, technology makes this difficult. If a student is taking a math test then oftentimes a graphing calculator is needed, but these calculators have the capabilities to store material. I feel that if a student tries to cheat in this manner then the consequences should be that they are no longer able to use a calculator in future exams and they will fail the current test. Not allowing calculators during future exams would be a drastic consequence because many algebra and geometry tests require calculators. Obviously, if this type of cheating occurred again then the student should fail the course. If this type of cheating is not stopped, then students will see no need to study or read their textbooks because they can just record the information.",
      "4. Although many students do not realize that unapproved collaboration is a form of cheating, it actually is. Sometimes the teacher will walk out of the room or the classroom is so big that it's impossible to hear whispering. Collaborating with classmates during an exam that is supposed to be done by each individual is dishonest. The consequence for this type of cheating should be failing the test, being separated from the class for future tests, and failing the class if it happens again. Collaborating with classmates gives some students an advantage over the ones that are not doing so, and it fails to reflect the skills of each individual. Obviously cheating in this way is a huge disadvantage to the student because they are not always going to have someone there to help.",
      "5. Lastly, failing to report someone else's cheating or allowing someone to copy cheat off you is a form of cheating. Most students are not willing to report a cheater because they are concerned about the reactions they will get from their classmates. There are ways to anonymously report a cheater. While you may feel like you are throwing someone under the bus, you will actually be harming a lot more people if you don't tell. If someone in the class gets a perfect score because they cheated, then the curve of the test might be higher, and the expectations for high scores will also be higher. People that are not cheating do not have the same advantage as the ones that are, they did the hard work, and they are going to be the ones that get the short end of the stick. The consequences for not reporting a cheater should not be as severe as the ones for cheating. In fact, the consequences are mostly personal because it's nearly impossible to tell if someone knows someone else cheated. The consequences are that you put in a lot of time and effort to study and you have less of a chance of getting a good grade."
    ],
    "images": [],
    "choices": [
      {
        "id": 8980,
        "content": [
          "Paragraph 2"
        ],
        "isCorrect": false
      },
      {
        "id": 8981,
        "content": [
          "Paragraph 3"
        ],
        "isCorrect": false
      },
      {
        "id": 8982,
        "content": [
          "Paragraph 5"
        ],
        "isCorrect": false
      },
      {
        "id": 8983,
        "content": [
          "Paragraph 4"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2244,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What does the phrase checking out (Para. 8) mean?"
    ],
    "explanation": [
      "In the context of paragraph 8, \"seven out of nine dogs kept checking out the person\" describes the action of the dogs repeatedly looking at the researchers for help. This is best interpreted as taking brief looks at them."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 78,
    "groupIndex": 1,
    "sharedContentId": 20,
    "sharedContent": [
      "**Our Dogs Are Watching Us**",
      "1. A few months ago, I reported a study of the ability of dogs to read the minds of their owners. Well, not exactly. They were not really reading minds; they were reading human body language to figure out which of two containers actually had food hidden in it. Now, experimenters have conducted more research on an attempt to identify the single skill that dogs have but other animals lack.",
      "2. In experiments reported in November 2002, scientists compared dogs, wolves, and chimpanzees. The tests involved hiding food in one of two containers, then pointing at, looking at, and tapping on the container with the food.",
      "3. While dogs were quick to figure out which container held what they were looking for, neither the wolves nor the chimps understood what the experimenters were trying to communicate. The inability of the chimps to perform better than the dogs was surprising, considering the overall intelligence of chimpanzees. But the differences between dogs and wolves were fascinating because of the relationship between the two.",
      "4. Wolves gave rise to dogs several thousand years ago, and while the physical differences between the two are the most obvious, there are clearly mental differences, too. This experiment suggested those differences are in the areas of social interaction with humans. A team of Hungarian scientists has found what they think is the key: Dogs look at people's faces. It sounds simple, but there are experiments to back up the claim.",
      "5. The Hungarian team made sure that the wolves were socialized to humans by having them live with people 24 hours a day from the time they were four days old. This meant that the dogs and wolves were equally used to human voices and gestures. By familiarizing the wolves and dogs to humans, the researchers hoped to eliminate the effect that the animals' anxiety might have on the experiment. The socialization seems to have worked. Some of the wolves were able to understand some of the human gestures, although overall they still were not as good as the dogs.",
      "6. It was a second experiment that revealed the key difference between the two animals. Both dogs and wolves were trained to get a piece of meat in two ways. They were taught how to lift the lid of a container to get at the meat inside and how to pull a rope (tied around a piece of meat) out of a cage. When the animals had figured out how to do both, the scientists tricked them: The lid was fastened down and the rope was tied to the cage. It was now impossible for them to get at the food.",
      "7. What happened? I'm sorry I can't report that the dogs learned to untie the rope or use a screwdriver to open the container, but they did do something the wolves didn't do – they kept looking at the people in the room, apparently waiting for some sort of sign to help them get the meat.",
      "8. The differences between the two animals were striking. In both tests, seven out of nine dogs kept checking out the person, while only two out of seven wolves did. The researchers claim that this act of looking at human faces is a \"genetic predisposition\" in dogs. It is one of the innate differences between the two species and therefore must have been one of the first steps in the process of domestication thousands of years ago.",
      "9. I would like to see this new piece of evidence applied to previous observations and theories about how dogs were domesticated. Some researchers have theorized that as dogs evolved, from wolves, their behavior became more immature. For instance, dogs exhibit submissive behavior that wolves do not, as if adult dogs are more like baby wolves. But the tests conducted by the Hungarian researchers were done when the animals were only a few months old, so you would think that if dog behavior is basically the same as that of young wolves, the wolves in this experiment might have looked at their owners, too.",
      "10. I can add to this research from my own experience. My dog also looks at people to get food: He makes sure I'm not looking at him, then steals my sandwich. That's what I call highly evolved behavior."
    ],
    "images": [],
    "choices": [
      {
        "id": 8984,
        "content": [
          "taking a brief look at"
        ],
        "isCorrect": true
      },
      {
        "id": 8985,
        "content": [
          "expecting food from"
        ],
        "isCorrect": false
      },
      {
        "id": 8986,
        "content": [
          "investigating"
        ],
        "isCorrect": false
      },
      {
        "id": 8987,
        "content": [
          "going for a walk with"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2245,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What do paragraphs 6 and 7 imply about wolves and dogs?"
    ],
    "explanation": [
      "Paragraph 6 describes an impossible task set for both dogs and wolves. Paragraph 7 reveals that when faced with this problem, the dogs looked at the people for help, while the wolves did not. This implies that dogs have a better ability or inclination to communicate with humans to solve problems."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 78,
    "groupIndex": 2,
    "sharedContentId": 20,
    "sharedContent": [
      "**Our Dogs Are Watching Us**",
      "1. A few months ago, I reported a study of the ability of dogs to read the minds of their owners. Well, not exactly. They were not really reading minds; they were reading human body language to figure out which of two containers actually had food hidden in it. Now, experimenters have conducted more research on an attempt to identify the single skill that dogs have but other animals lack.",
      "2. In experiments reported in November 2002, scientists compared dogs, wolves, and chimpanzees. The tests involved hiding food in one of two containers, then pointing at, looking at, and tapping on the container with the food.",
      "3. While dogs were quick to figure out which container held what they were looking for, neither the wolves nor the chimps understood what the experimenters were trying to communicate. The inability of the chimps to perform better than the dogs was surprising, considering the overall intelligence of chimpanzees. But the differences between dogs and wolves were fascinating because of the relationship between the two.",
      "4. Wolves gave rise to dogs several thousand years ago, and while the physical differences between the two are the most obvious, there are clearly mental differences, too. This experiment suggested those differences are in the areas of social interaction with humans. A team of Hungarian scientists has found what they think is the key: Dogs look at people's faces. It sounds simple, but there are experiments to back up the claim.",
      "5. The Hungarian team made sure that the wolves were socialized to humans by having them live with people 24 hours a day from the time they were four days old. This meant that the dogs and wolves were equally used to human voices and gestures. By familiarizing the wolves and dogs to humans, the researchers hoped to eliminate the effect that the animals' anxiety might have on the experiment. The socialization seems to have worked. Some of the wolves were able to understand some of the human gestures, although overall they still were not as good as the dogs.",
      "6. It was a second experiment that revealed the key difference between the two animals. Both dogs and wolves were trained to get a piece of meat in two ways. They were taught how to lift the lid of a container to get at the meat inside and how to pull a rope (tied around a piece of meat) out of a cage. When the animals had figured out how to do both, the scientists tricked them: The lid was fastened down and the rope was tied to the cage. It was now impossible for them to get at the food.",
      "7. What happened? I'm sorry I can't report that the dogs learned to untie the rope or use a screwdriver to open the container, but they did do something the wolves didn't do – they kept looking at the people in the room, apparently waiting for some sort of sign to help them get the meat.",
      "8. The differences between the two animals were striking. In both tests, seven out of nine dogs kept checking out the person, while only two out of seven wolves did. The researchers claim that this act of looking at human faces is a \"genetic predisposition\" in dogs. It is one of the innate differences between the two species and therefore must have been one of the first steps in the process of domestication thousands of years ago.",
      "9. I would like to see this new piece of evidence applied to previous observations and theories about how dogs were domesticated. Some researchers have theorized that as dogs evolved, from wolves, their behavior became more immature. For instance, dogs exhibit submissive behavior that wolves do not, as if adult dogs are more like baby wolves. But the tests conducted by the Hungarian researchers were done when the animals were only a few months old, so you would think that if dog behavior is basically the same as that of young wolves, the wolves in this experiment might have looked at their owners, too.",
      "10. I can add to this research from my own experience. My dog also looks at people to get food: He makes sure I'm not looking at him, then steals my sandwich. That's what I call highly evolved behavior."
    ],
    "images": [],
    "choices": [
      {
        "id": 8988,
        "content": [
          "Dogs communicate with people better than do wolves."
        ],
        "isCorrect": true
      },
      {
        "id": 8989,
        "content": [
          "Wolves and dogs are equally intelligent."
        ],
        "isCorrect": false
      },
      {
        "id": 8990,
        "content": [
          "One can train wolves and dogs to do anything."
        ],
        "isCorrect": false
      },
      {
        "id": 8991,
        "content": [
          "Dogs are more intelligent than wolves."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2246,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What did the writer in his study want to find out (Para.1)?"
    ],
    "explanation": [
      "The last sentence of paragraph 1 states, \"Now, experimenters have conducted more research on an attempt to identify the single skill that dogs have but other animals lack.\" This is the central goal of the study described."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 78,
    "groupIndex": 3,
    "sharedContentId": 20,
    "sharedContent": [
      "**Our Dogs Are Watching Us**",
      "1. A few months ago, I reported a study of the ability of dogs to read the minds of their owners. Well, not exactly. They were not really reading minds; they were reading human body language to figure out which of two containers actually had food hidden in it. Now, experimenters have conducted more research on an attempt to identify the single skill that dogs have but other animals lack.",
      "2. In experiments reported in November 2002, scientists compared dogs, wolves, and chimpanzees. The tests involved hiding food in one of two containers, then pointing at, looking at, and tapping on the container with the food.",
      "3. While dogs were quick to figure out which container held what they were looking for, neither the wolves nor the chimps understood what the experimenters were trying to communicate. The inability of the chimps to perform better than the dogs was surprising, considering the overall intelligence of chimpanzees. But the differences between dogs and wolves were fascinating because of the relationship between the two.",
      "4. Wolves gave rise to dogs several thousand years ago, and while the physical differences between the two are the most obvious, there are clearly mental differences, too. This experiment suggested those differences are in the areas of social interaction with humans. A team of Hungarian scientists has found what they think is the key: Dogs look at people's faces. It sounds simple, but there are experiments to back up the claim.",
      "5. The Hungarian team made sure that the wolves were socialized to humans by having them live with people 24 hours a day from the time they were four days old. This meant that the dogs and wolves were equally used to human voices and gestures. By familiarizing the wolves and dogs to humans, the researchers hoped to eliminate the effect that the animals' anxiety might have on the experiment. The socialization seems to have worked. Some of the wolves were able to understand some of the human gestures, although overall they still were not as good as the dogs.",
      "6. It was a second experiment that revealed the key difference between the two animals. Both dogs and wolves were trained to get a piece of meat in two ways. They were taught how to lift the lid of a container to get at the meat inside and how to pull a rope (tied around a piece of meat) out of a cage. When the animals had figured out how to do both, the scientists tricked them: The lid was fastened down and the rope was tied to the cage. It was now impossible for them to get at the food.",
      "7. What happened? I'm sorry I can't report that the dogs learned to untie the rope or use a screwdriver to open the container, but they did do something the wolves didn't do – they kept looking at the people in the room, apparently waiting for some sort of sign to help them get the meat.",
      "8. The differences between the two animals were striking. In both tests, seven out of nine dogs kept checking out the person, while only two out of seven wolves did. The researchers claim that this act of looking at human faces is a \"genetic predisposition\" in dogs. It is one of the innate differences between the two species and therefore must have been one of the first steps in the process of domestication thousands of years ago.",
      "9. I would like to see this new piece of evidence applied to previous observations and theories about how dogs were domesticated. Some researchers have theorized that as dogs evolved, from wolves, their behavior became more immature. For instance, dogs exhibit submissive behavior that wolves do not, as if adult dogs are more like baby wolves. But the tests conducted by the Hungarian researchers were done when the animals were only a few months old, so you would think that if dog behavior is basically the same as that of young wolves, the wolves in this experiment might have looked at their owners, too.",
      "10. I can add to this research from my own experience. My dog also looks at people to get food: He makes sure I'm not looking at him, then steals my sandwich. That's what I call highly evolved behavior."
    ],
    "images": [],
    "choices": [
      {
        "id": 8992,
        "content": [
          "Dogs' ability to find hidden things"
        ],
        "isCorrect": false
      },
      {
        "id": 8993,
        "content": [
          "Dogs' ability to read human body language"
        ],
        "isCorrect": false
      },
      {
        "id": 8994,
        "content": [
          "Dogs' ability to read the human mind"
        ],
        "isCorrect": false
      },
      {
        "id": 8995,
        "content": [
          "Dogs' single skill that makes them different"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2247,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "In Paragraph 5, what variable were the Hungarian scientists trying to control?"
    ],
    "explanation": [
      "Paragraph 5 explains that wolves were socialized with humans from a very young age to ensure \"dogs and wolves were equally used to human voices and gestures.\" This was done to \"eliminate the effect that the animals' anxiety might have on the experiment.\" They were controlling for the level of familiarity or exposure to humans."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 78,
    "groupIndex": 4,
    "sharedContentId": 20,
    "sharedContent": [
      "**Our Dogs Are Watching Us**",
      "1. A few months ago, I reported a study of the ability of dogs to read the minds of their owners. Well, not exactly. They were not really reading minds; they were reading human body language to figure out which of two containers actually had food hidden in it. Now, experimenters have conducted more research on an attempt to identify the single skill that dogs have but other animals lack.",
      "2. In experiments reported in November 2002, scientists compared dogs, wolves, and chimpanzees. The tests involved hiding food in one of two containers, then pointing at, looking at, and tapping on the container with the food.",
      "3. While dogs were quick to figure out which container held what they were looking for, neither the wolves nor the chimps understood what the experimenters were trying to communicate. The inability of the chimps to perform better than the dogs was surprising, considering the overall intelligence of chimpanzees. But the differences between dogs and wolves were fascinating because of the relationship between the two.",
      "4. Wolves gave rise to dogs several thousand years ago, and while the physical differences between the two are the most obvious, there are clearly mental differences, too. This experiment suggested those differences are in the areas of social interaction with humans. A team of Hungarian scientists has found what they think is the key: Dogs look at people's faces. It sounds simple, but there are experiments to back up the claim.",
      "5. The Hungarian team made sure that the wolves were socialized to humans by having them live with people 24 hours a day from the time they were four days old. This meant that the dogs and wolves were equally used to human voices and gestures. By familiarizing the wolves and dogs to humans, the researchers hoped to eliminate the effect that the animals' anxiety might have on the experiment. The socialization seems to have worked. Some of the wolves were able to understand some of the human gestures, although overall they still were not as good as the dogs.",
      "6. It was a second experiment that revealed the key difference between the two animals. Both dogs and wolves were trained to get a piece of meat in two ways. They were taught how to lift the lid of a container to get at the meat inside and how to pull a rope (tied around a piece of meat) out of a cage. When the animals had figured out how to do both, the scientists tricked them: The lid was fastened down and the rope was tied to the cage. It was now impossible for them to get at the food.",
      "7. What happened? I'm sorry I can't report that the dogs learned to untie the rope or use a screwdriver to open the container, but they did do something the wolves didn't do – they kept looking at the people in the room, apparently waiting for some sort of sign to help them get the meat.",
      "8. The differences between the two animals were striking. In both tests, seven out of nine dogs kept checking out the person, while only two out of seven wolves did. The researchers claim that this act of looking at human faces is a \"genetic predisposition\" in dogs. It is one of the innate differences between the two species and therefore must have been one of the first steps in the process of domestication thousands of years ago.",
      "9. I would like to see this new piece of evidence applied to previous observations and theories about how dogs were domesticated. Some researchers have theorized that as dogs evolved, from wolves, their behavior became more immature. For instance, dogs exhibit submissive behavior that wolves do not, as if adult dogs are more like baby wolves. But the tests conducted by the Hungarian researchers were done when the animals were only a few months old, so you would think that if dog behavior is basically the same as that of young wolves, the wolves in this experiment might have looked at their owners, too.",
      "10. I can add to this research from my own experience. My dog also looks at people to get food: He makes sure I'm not looking at him, then steals my sandwich. That's what I call highly evolved behavior."
    ],
    "images": [],
    "choices": [
      {
        "id": 8996,
        "content": [
          "The difference in age of both the wolves and the dogs"
        ],
        "isCorrect": false
      },
      {
        "id": 8997,
        "content": [
          "The amount of time both animals can stay with humans in a day"
        ],
        "isCorrect": false
      },
      {
        "id": 8998,
        "content": [
          "The extent of anxiety both animals show as they grow up"
        ],
        "isCorrect": false
      },
      {
        "id": 8999,
        "content": [
          "The degree of exposure of both animals to human beings"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2248,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which one of the following sentences is true about wolves and dogs?"
    ],
    "explanation": [
      "Paragraph 4 states that the key difference is that \"Dogs look at people's faces.\" Paragraphs 7 and 8 provide experimental evidence showing dogs repeatedly looked at humans while wolves did not, effectively avoiding their faces as a source of help."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 78,
    "groupIndex": 5,
    "sharedContentId": 20,
    "sharedContent": [
      "**Our Dogs Are Watching Us**",
      "1. A few months ago, I reported a study of the ability of dogs to read the minds of their owners. Well, not exactly. They were not really reading minds; they were reading human body language to figure out which of two containers actually had food hidden in it. Now, experimenters have conducted more research on an attempt to identify the single skill that dogs have but other animals lack.",
      "2. In experiments reported in November 2002, scientists compared dogs, wolves, and chimpanzees. The tests involved hiding food in one of two containers, then pointing at, looking at, and tapping on the container with the food.",
      "3. While dogs were quick to figure out which container held what they were looking for, neither the wolves nor the chimps understood what the experimenters were trying to communicate. The inability of the chimps to perform better than the dogs was surprising, considering the overall intelligence of chimpanzees. But the differences between dogs and wolves were fascinating because of the relationship between the two.",
      "4. Wolves gave rise to dogs several thousand years ago, and while the physical differences between the two are the most obvious, there are clearly mental differences, too. This experiment suggested those differences are in the areas of social interaction with humans. A team of Hungarian scientists has found what they think is the key: Dogs look at people's faces. It sounds simple, but there are experiments to back up the claim.",
      "5. The Hungarian team made sure that the wolves were socialized to humans by having them live with people 24 hours a day from the time they were four days old. This meant that the dogs and wolves were equally used to human voices and gestures. By familiarizing the wolves and dogs to humans, the researchers hoped to eliminate the effect that the animals' anxiety might have on the experiment. The socialization seems to have worked. Some of the wolves were able to understand some of the human gestures, although overall they still were not as good as the dogs.",
      "6. It was a second experiment that revealed the key difference between the two animals. Both dogs and wolves were trained to get a piece of meat in two ways. They were taught how to lift the lid of a container to get at the meat inside and how to pull a rope (tied around a piece of meat) out of a cage. When the animals had figured out how to do both, the scientists tricked them: The lid was fastened down and the rope was tied to the cage. It was now impossible for them to get at the food.",
      "7. What happened? I'm sorry I can't report that the dogs learned to untie the rope or use a screwdriver to open the container, but they did do something the wolves didn't do – they kept looking at the people in the room, apparently waiting for some sort of sign to help them get the meat.",
      "8. The differences between the two animals were striking. In both tests, seven out of nine dogs kept checking out the person, while only two out of seven wolves did. The researchers claim that this act of looking at human faces is a \"genetic predisposition\" in dogs. It is one of the innate differences between the two species and therefore must have been one of the first steps in the process of domestication thousands of years ago.",
      "9. I would like to see this new piece of evidence applied to previous observations and theories about how dogs were domesticated. Some researchers have theorized that as dogs evolved, from wolves, their behavior became more immature. For instance, dogs exhibit submissive behavior that wolves do not, as if adult dogs are more like baby wolves. But the tests conducted by the Hungarian researchers were done when the animals were only a few months old, so you would think that if dog behavior is basically the same as that of young wolves, the wolves in this experiment might have looked at their owners, too.",
      "10. I can add to this research from my own experience. My dog also looks at people to get food: He makes sure I'm not looking at him, then steals my sandwich. That's what I call highly evolved behavior."
    ],
    "images": [],
    "choices": [
      {
        "id": 9000,
        "content": [
          "They equally interact with human beings."
        ],
        "isCorrect": false
      },
      {
        "id": 9001,
        "content": [
          "Wolves avoid people's faces while dogs don't."
        ],
        "isCorrect": true
      },
      {
        "id": 9002,
        "content": [
          "Their difference is less vivid in mind than in physique."
        ],
        "isCorrect": false
      },
      {
        "id": 9003,
        "content": [
          "Wolves emerged from dogs thousands of years ago."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2249,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What is the idea that the writer of this article doesn't seem to agree to (Para. 9)?"
    ],
    "explanation": [
      "In paragraph 9, the writer questions the theory that \"as dogs evolved, from wolves, their behavior became more immature... as if adult dogs are more like baby wolves.\" He presents a counterargument based on the experiment, suggesting that if this theory were true, the young wolves in the study should have behaved like the dogs, but they didn't. This indicates his disagreement."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 78,
    "groupIndex": 6,
    "sharedContentId": 20,
    "sharedContent": [
      "**Our Dogs Are Watching Us**",
      "1. A few months ago, I reported a study of the ability of dogs to read the minds of their owners. Well, not exactly. They were not really reading minds; they were reading human body language to figure out which of two containers actually had food hidden in it. Now, experimenters have conducted more research on an attempt to identify the single skill that dogs have but other animals lack.",
      "2. In experiments reported in November 2002, scientists compared dogs, wolves, and chimpanzees. The tests involved hiding food in one of two containers, then pointing at, looking at, and tapping on the container with the food.",
      "3. While dogs were quick to figure out which container held what they were looking for, neither the wolves nor the chimps understood what the experimenters were trying to communicate. The inability of the chimps to perform better than the dogs was surprising, considering the overall intelligence of chimpanzees. But the differences between dogs and wolves were fascinating because of the relationship between the two.",
      "4. Wolves gave rise to dogs several thousand years ago, and while the physical differences between the two are the most obvious, there are clearly mental differences, too. This experiment suggested those differences are in the areas of social interaction with humans. A team of Hungarian scientists has found what they think is the key: Dogs look at people's faces. It sounds simple, but there are experiments to back up the claim.",
      "5. The Hungarian team made sure that the wolves were socialized to humans by having them live with people 24 hours a day from the time they were four days old. This meant that the dogs and wolves were equally used to human voices and gestures. By familiarizing the wolves and dogs to humans, the researchers hoped to eliminate the effect that the animals' anxiety might have on the experiment. The socialization seems to have worked. Some of the wolves were able to understand some of the human gestures, although overall they still were not as good as the dogs.",
      "6. It was a second experiment that revealed the key difference between the two animals. Both dogs and wolves were trained to get a piece of meat in two ways. They were taught how to lift the lid of a container to get at the meat inside and how to pull a rope (tied around a piece of meat) out of a cage. When the animals had figured out how to do both, the scientists tricked them: The lid was fastened down and the rope was tied to the cage. It was now impossible for them to get at the food.",
      "7. What happened? I'm sorry I can't report that the dogs learned to untie the rope or use a screwdriver to open the container, but they did do something the wolves didn't do – they kept looking at the people in the room, apparently waiting for some sort of sign to help them get the meat.",
      "8. The differences between the two animals were striking. In both tests, seven out of nine dogs kept checking out the person, while only two out of seven wolves did. The researchers claim that this act of looking at human faces is a \"genetic predisposition\" in dogs. It is one of the innate differences between the two species and therefore must have been one of the first steps in the process of domestication thousands of years ago.",
      "9. I would like to see this new piece of evidence applied to previous observations and theories about how dogs were domesticated. Some researchers have theorized that as dogs evolved, from wolves, their behavior became more immature. For instance, dogs exhibit submissive behavior that wolves do not, as if adult dogs are more like baby wolves. But the tests conducted by the Hungarian researchers were done when the animals were only a few months old, so you would think that if dog behavior is basically the same as that of young wolves, the wolves in this experiment might have looked at their owners, too.",
      "10. I can add to this research from my own experience. My dog also looks at people to get food: He makes sure I'm not looking at him, then steals my sandwich. That's what I call highly evolved behavior."
    ],
    "images": [],
    "choices": [
      {
        "id": 9004,
        "content": [
          "Adult dogs are more like baby wolves."
        ],
        "isCorrect": true
      },
      {
        "id": 9005,
        "content": [
          "Wolves are more aggressive than dogs."
        ],
        "isCorrect": false
      },
      {
        "id": 9006,
        "content": [
          "Dogs exhibit submissive behavior."
        ],
        "isCorrect": false
      },
      {
        "id": 9007,
        "content": [
          "The wolves do not look at their owners."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2250,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which one of the following was an unexpected finding in the experiments reported in November 2002?"
    ],
    "explanation": [
      "Paragraph 3 states, \"The inability of the chimps to perform better than the dogs was surprising, considering the overall intelligence of chimpanzees.\" This highlights that the dogs' superior performance over the generally more intelligent chimps was an unexpected outcome."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 78,
    "groupIndex": 7,
    "sharedContentId": 20,
    "sharedContent": [
      "**Our Dogs Are Watching Us**",
      "1. A few months ago, I reported a study of the ability of dogs to read the minds of their owners. Well, not exactly. They were not really reading minds; they were reading human body language to figure out which of two containers actually had food hidden in it. Now, experimenters have conducted more research on an attempt to identify the single skill that dogs have but other animals lack.",
      "2. In experiments reported in November 2002, scientists compared dogs, wolves, and chimpanzees. The tests involved hiding food in one of two containers, then pointing at, looking at, and tapping on the container with the food.",
      "3. While dogs were quick to figure out which container held what they were looking for, neither the wolves nor the chimps understood what the experimenters were trying to communicate. The inability of the chimps to perform better than the dogs was surprising, considering the overall intelligence of chimpanzees. But the differences between dogs and wolves were fascinating because of the relationship between the two.",
      "4. Wolves gave rise to dogs several thousand years ago, and while the physical differences between the two are the most obvious, there are clearly mental differences, too. This experiment suggested those differences are in the areas of social interaction with humans. A team of Hungarian scientists has found what they think is the key: Dogs look at people's faces. It sounds simple, but there are experiments to back up the claim.",
      "5. The Hungarian team made sure that the wolves were socialized to humans by having them live with people 24 hours a day from the time they were four days old. This meant that the dogs and wolves were equally used to human voices and gestures. By familiarizing the wolves and dogs to humans, the researchers hoped to eliminate the effect that the animals' anxiety might have on the experiment. The socialization seems to have worked. Some of the wolves were able to understand some of the human gestures, although overall they still were not as good as the dogs.",
      "6. It was a second experiment that revealed the key difference between the two animals. Both dogs and wolves were trained to get a piece of meat in two ways. They were taught how to lift the lid of a container to get at the meat inside and how to pull a rope (tied around a piece of meat) out of a cage. When the animals had figured out how to do both, the scientists tricked them: The lid was fastened down and the rope was tied to the cage. It was now impossible for them to get at the food.",
      "7. What happened? I'm sorry I can't report that the dogs learned to untie the rope or use a screwdriver to open the container, but they did do something the wolves didn't do – they kept looking at the people in the room, apparently waiting for some sort of sign to help them get the meat.",
      "8. The differences between the two animals were striking. In both tests, seven out of nine dogs kept checking out the person, while only two out of seven wolves did. The researchers claim that this act of looking at human faces is a \"genetic predisposition\" in dogs. It is one of the innate differences between the two species and therefore must have been one of the first steps in the process of domestication thousands of years ago.",
      "9. I would like to see this new piece of evidence applied to previous observations and theories about how dogs were domesticated. Some researchers have theorized that as dogs evolved, from wolves, their behavior became more immature. For instance, dogs exhibit submissive behavior that wolves do not, as if adult dogs are more like baby wolves. But the tests conducted by the Hungarian researchers were done when the animals were only a few months old, so you would think that if dog behavior is basically the same as that of young wolves, the wolves in this experiment might have looked at their owners, too.",
      "10. I can add to this research from my own experience. My dog also looks at people to get food: He makes sure I'm not looking at him, then steals my sandwich. That's what I call highly evolved behavior."
    ],
    "images": [],
    "choices": [
      {
        "id": 9008,
        "content": [
          "That both the wolves and the dogs exhibited similar abilities"
        ],
        "isCorrect": false
      },
      {
        "id": 9009,
        "content": [
          "That the dogs outperformed the chimps in the experiment"
        ],
        "isCorrect": true
      },
      {
        "id": 9010,
        "content": [
          "That both the wolves and the chimps seemed to have similar abilities"
        ],
        "isCorrect": false
      },
      {
        "id": 9011,
        "content": [
          "That both the wolves and the chimps failed to understand the experimenters"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2327,
    "content": [
      "The following questions relate to different aspects of writing. Choose the best answer.",
      "---",
      "Which one of the following sentences is WRONGLY punctuated?"
    ],
    "explanation": [
      "This sentence incorrectly mixes double and single quotation marks for nested quotes. Also, a single quoted word usually has a specific purpose that isn't clear here. The most significant error is likely the inconsistent quoting style and the period after 'year' should be inside the single quote. A simple statement would be '\"Sodere,\" I replied, \"I was there for a year.\"' The given punctuation is awkward and incorrect."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 83,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9316,
        "content": [
          "We uttered, \"Just calm down!\""
        ],
        "isCorrect": false
      },
      {
        "id": 9317,
        "content": [
          "I asked, \"Why don't you pick her up?\""
        ],
        "isCorrect": false
      },
      {
        "id": 9318,
        "content": [
          "\"Sodere\", I replied. 'I was there for a year.'"
        ],
        "isCorrect": true
      },
      {
        "id": 9319,
        "content": [
          "She said, \"We'll be there in five minutes.\""
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2330,
    "content": [
      "The following questions relate to different aspects of writing. Choose the best answer.",
      "---",
      "Which one of the following sentences is correctly punctuated?"
    ],
    "explanation": [
      "Correct Answer: Last week—I think it was Monday—I sent them a complete report.\n\nThe sentence uses uses **em dashes** correctly to set off the parenthetical phrase “I think it was Monday”. Em dashes are often used to insert a break or interruption in thought, which fits the tone of the sentence. The rest of the sentence is grammatically sound and flows well."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9328,
        "content": [
          "Last week-I think it was Monday-I sent them a complete report."
        ],
        "isCorrect": true
      },
      {
        "id": 9329,
        "content": [
          "Last week, I think, it was Monday-I sent them a complete report."
        ],
        "isCorrect": false
      },
      {
        "id": 9330,
        "content": [
          "Last week; I think it was Monday, I sent them a complete report."
        ],
        "isCorrect": false
      },
      {
        "id": 9331,
        "content": [
          "Last week-I think, it was Monday, I sent them a complete report."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2334,
    "content": [
      "The following questions relate to different aspects of writing. Choose the best answer.",
      "---",
      "Which one of the following sentences has a correct punctuation?"
    ],
    "explanation": [
      "When a dialogue tag (like \"Buli remarked politely\") follows a question, the question mark goes inside the quotation marks, and the tag is followed by a period to start the next sentence. The next sentence of dialogue starts with a capital letter. Option D follows all these rules correctly."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 83,
    "groupIndex": 8,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9344,
        "content": [
          "\"Is that so?\", Buli remarked politely. \"Just to save you!\""
        ],
        "isCorrect": false
      },
      {
        "id": 9345,
        "content": [
          "\"Is that so?\" Buli remarked politely; \"Just to save you!\""
        ],
        "isCorrect": false
      },
      {
        "id": 9346,
        "content": [
          "\"Is that so\" Buli remarked politely? \"Just to save you!\""
        ],
        "isCorrect": false
      },
      {
        "id": 9347,
        "content": [
          "\"Is that so?\" Buli remarked politely. \"Just to save you!\""
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2338,
    "content": [
      "Answer the following questions based on the information provided.",
      "---",
      "What is the range of the distribution?"
    ],
    "explanation": [
      "The range is the difference between the highest and lowest values in a data set. The oldest student is 19 and the youngest is 14. The range is 19 - 14 = 5."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 84,
    "groupIndex": 1,
    "sharedContentId": 21,
    "sharedContent": [
      "Suppose there are 18 other students than you in your class. The youngest is Eldana, 14, and the oldest is Biruk, 19. The breakdown in age of the remaining students is that six are 15, four are 16, three are 17 and four are 18."
    ],
    "images": [],
    "choices": [
      {
        "id": 9360,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 9361,
        "content": [
          "5"
        ],
        "isCorrect": true
      },
      {
        "id": 9362,
        "content": [
          "4"
        ],
        "isCorrect": false
      },
      {
        "id": 9363,
        "content": [
          "6"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2339,
    "content": [
      "Answer the following questions based on the information provided.",
      "---",
      "What is the mode of the distribution?"
    ],
    "explanation": [
      "The mode is the value that appears most frequently in a data set. The ages are: 14 (1 student), 15 (6 students), 16 (4 students), 17 (3 students), 18 (4 students), 19 (1 student). The age 15 appears most often (6 times), so it is the mode."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 84,
    "groupIndex": 2,
    "sharedContentId": 21,
    "sharedContent": [
      "Suppose there are 18 other students than you in your class. The youngest is Eldana, 14, and the oldest is Biruk, 19. The breakdown in age of the remaining students is that six are 15, four are 16, three are 17 and four are 18."
    ],
    "images": [],
    "choices": [
      {
        "id": 9364,
        "content": [
          "18"
        ],
        "isCorrect": false
      },
      {
        "id": 9365,
        "content": [
          "16"
        ],
        "isCorrect": false
      },
      {
        "id": 9366,
        "content": [
          "17"
        ],
        "isCorrect": false
      },
      {
        "id": 9367,
        "content": [
          "15"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2340,
    "content": [
      "Answer the following questions based on the information provided.",
      "---",
      "What is the median of the age distribution?"
    ],
    "explanation": [
      "The total number of students is 1 (age 14) + 6 (age 15) + 4 (age 16) + 3 (age 17) + 4 (age 18) + 1 (age 19) = 19 students.\n\nThe median is the middle value. For 19 students, the middle value is the 10th student when arranged in order. The first student is 14.\n\nThe next 6 students (positions 2 to 7) are 15. The next 4 students (positions 8 to 11) are 16. The 10th student falls in the group of 16-year-olds. Therefore, the median is 16."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 84,
    "groupIndex": 3,
    "sharedContentId": 21,
    "sharedContent": [
      "Suppose there are 18 other students than you in your class. The youngest is Eldana, 14, and the oldest is Biruk, 19. The breakdown in age of the remaining students is that six are 15, four are 16, three are 17 and four are 18."
    ],
    "images": [],
    "choices": [
      {
        "id": 9368,
        "content": [
          "16"
        ],
        "isCorrect": true
      },
      {
        "id": 9369,
        "content": [
          "15"
        ],
        "isCorrect": false
      },
      {
        "id": 9370,
        "content": [
          "17"
        ],
        "isCorrect": false
      },
      {
        "id": 9371,
        "content": [
          "18"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2341,
    "content": [
      "Answer the following questions based on the information provided.",
      "---",
      "What is the class size?"
    ],
    "explanation": [
      "The question says there are \"18 other students than you\". This means the total number of students in the class, including \"you\", is 18 + 1 = 19."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 84,
    "groupIndex": 4,
    "sharedContentId": 21,
    "sharedContent": [
      "Suppose there are 18 other students than you in your class. The youngest is Eldana, 14, and the oldest is Biruk, 19. The breakdown in age of the remaining students is that six are 15, four are 16, three are 17 and four are 18."
    ],
    "images": [],
    "choices": [
      {
        "id": 9372,
        "content": [
          "17"
        ],
        "isCorrect": false
      },
      {
        "id": 9373,
        "content": [
          "18"
        ],
        "isCorrect": false
      },
      {
        "id": 9374,
        "content": [
          "20"
        ],
        "isCorrect": false
      },
      {
        "id": 9375,
        "content": [
          "19"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2342,
    "content": [
      "Answer the following questions based on the information provided.",
      "---",
      "What conclusion can we draw from the age distribution of these students?"
    ],
    "explanation": [
      "The data shows students in the same class have a range of ages from 14 to 19. This directly supports the conclusion that children do not all start school at the same age, leading to age variation within a single class. The data is only about one class, so we cannot make conclusions about the whole country (A, B, D)."
    ],
    "year": "YEAR_2011",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 84,
    "groupIndex": 5,
    "sharedContentId": 21,
    "sharedContent": [
      "Suppose there are 18 other students than you in your class. The youngest is Eldana, 14, and the oldest is Biruk, 19. The breakdown in age of the remaining students is that six are 15, four are 16, three are 17 and four are 18."
    ],
    "images": [],
    "choices": [
      {
        "id": 9376,
        "content": [
          "Most children in the country begin school at early age."
        ],
        "isCorrect": false
      },
      {
        "id": 9377,
        "content": [
          "Female children in the country start school earlier than the males."
        ],
        "isCorrect": false
      },
      {
        "id": 9378,
        "content": [
          "Children in the country do not seem to start school at the same age."
        ],
        "isCorrect": true
      },
      {
        "id": 9379,
        "content": [
          "The age of the child is an important variable to start primary school."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3108,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which one of the following statements is true according to paragraph 4?"
    ],
    "explanation": [
      "Paragraph 4 explicitly states that some homeless people are victims of tragic circumstances like layoffs or abuse and that \"These people deserve every effort to help them back on their feet.\" This directly supports the idea that they deserve help to reorganize their lives."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 97,
    "groupIndex": null,
    "sharedContentId": 28,
    "sharedContent": [
      "1. Homeless people are everywhere-on the street, in public buildings, on the evening news and at the corner parking lot. You can hardly step out of your house these days without meeting some haggard character who asks you for a cigarette or begs for \"a little change\". The homeless are not just constant symbols of wasted lives and social programs-they have become a danger to public safety.",
      "2. What is the root of the homeless problem? Everyone seems to have a scapegoat. Advocates of the homeless blame government policy; politicians blame the legal system; the courts blame the bureaucratic infrastructure; the Democrats blame the Republicans and the Republicans blame the Democrats. The public also blames the economy, drugs, the \"poverty cycle\", and \"the breakdown of society\". With all this finger-pointing, the group most responsible for the homeless being the way they are received the least blame. That group is the homeless themselves.",
      "3. How can I say this? For the past two years I have worked with the homeless, volunteering at the Salvation Army and at a soup kitchen in Austin, Texas. I have led a weekly chapel service, served food, listened, counseled, given time and money, and shared their struggles. I have seen their response to troubles, and though I would rather report otherwise, many of them seem to have chosen the life styles they lead. They are unwilling to do the things necessary to overcome their circumstances. They must bear the greatest part of the blame for their manifold troubles.",
      "4. Let me qualify what I just said. Not everyone who finds himself out of a job and in the street is there because he/she wants to be. Some are victims of tragic circumstances. I met many exhausted, sensible people during my time working with Austin's homeless: the single father struggling to earn his working his Austin's homeless: the single father struggling to earn his bread and be a role model for his children; the woman who fled a good job in another city to escape an abusive husband; the well- educated young man who had his world turned upside down by divorce and a layoff. These people deserve every effort to help them back on their feet.",
      "5. But they are not the real problem. They are usually off the streets and resuming normal lives within a period of weeks or months. Even while \"down on their luck\", they are responsible citizens, working in the shelters and applying for jobs. They are homeless, true but only temporarily, because they are eager to reorganize their lives.",
      "6. For every person temporarily homeless, though there are many who are chronically so. Whether because of mental illness, alcoholism, poor education, drug addiction, or simply laziness, these homeless are content to remain as they are. In many cases they choose the streets. They enjoy the freedom and consider begging a minor inconvenience. They know they can always get a job for a day or two for food, cigarettes and alcohol. The sophisticated among them have learned to use the system for what it is worth and figure out that a trip through the welfare line is less trouble than a steady job. In a society that has mastered a dodging responsibility, these homeless prefer a life of no responsibility at all."
    ],
    "images": [],
    "choices": [
      {
        "id": 12440,
        "content": [
          "Some homeless who are victims of circumstances deserve help to recognize their lives again."
        ],
        "isCorrect": true
      },
      {
        "id": 12441,
        "content": [
          "None of those in the street deserves any effort to help them back on their feet."
        ],
        "isCorrect": false
      },
      {
        "id": 12442,
        "content": [
          "A woman fleeing an abusive husband is right away homeless."
        ],
        "isCorrect": false
      },
      {
        "id": 12443,
        "content": [
          "Everyone who finds themselves out of a job is homeless."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3109,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which of the following best describes this passage writer's tone?"
    ],
    "explanation": [
      "The writer's tone is critical, especially towards the chronically homeless. He uses phrases like \"unwilling to do the things necessary,\" \"content to remain as they are,\" and \"prefer a life of no responsibility at all\" to blame them for their situation, which demonstrates a clear tone of criticism."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 97,
    "groupIndex": null,
    "sharedContentId": 28,
    "sharedContent": [
      "1. Homeless people are everywhere-on the street, in public buildings, on the evening news and at the corner parking lot. You can hardly step out of your house these days without meeting some haggard character who asks you for a cigarette or begs for \"a little change\". The homeless are not just constant symbols of wasted lives and social programs-they have become a danger to public safety.",
      "2. What is the root of the homeless problem? Everyone seems to have a scapegoat. Advocates of the homeless blame government policy; politicians blame the legal system; the courts blame the bureaucratic infrastructure; the Democrats blame the Republicans and the Republicans blame the Democrats. The public also blames the economy, drugs, the \"poverty cycle\", and \"the breakdown of society\". With all this finger-pointing, the group most responsible for the homeless being the way they are received the least blame. That group is the homeless themselves.",
      "3. How can I say this? For the past two years I have worked with the homeless, volunteering at the Salvation Army and at a soup kitchen in Austin, Texas. I have led a weekly chapel service, served food, listened, counseled, given time and money, and shared their struggles. I have seen their response to troubles, and though I would rather report otherwise, many of them seem to have chosen the life styles they lead. They are unwilling to do the things necessary to overcome their circumstances. They must bear the greatest part of the blame for their manifold troubles.",
      "4. Let me qualify what I just said. Not everyone who finds himself out of a job and in the street is there because he/she wants to be. Some are victims of tragic circumstances. I met many exhausted, sensible people during my time working with Austin's homeless: the single father struggling to earn his working his Austin's homeless: the single father struggling to earn his bread and be a role model for his children; the woman who fled a good job in another city to escape an abusive husband; the well- educated young man who had his world turned upside down by divorce and a layoff. These people deserve every effort to help them back on their feet.",
      "5. But they are not the real problem. They are usually off the streets and resuming normal lives within a period of weeks or months. Even while \"down on their luck\", they are responsible citizens, working in the shelters and applying for jobs. They are homeless, true but only temporarily, because they are eager to reorganize their lives.",
      "6. For every person temporarily homeless, though there are many who are chronically so. Whether because of mental illness, alcoholism, poor education, drug addiction, or simply laziness, these homeless are content to remain as they are. In many cases they choose the streets. They enjoy the freedom and consider begging a minor inconvenience. They know they can always get a job for a day or two for food, cigarettes and alcohol. The sophisticated among them have learned to use the system for what it is worth and figure out that a trip through the welfare line is less trouble than a steady job. In a society that has mastered a dodging responsibility, these homeless prefer a life of no responsibility at all."
    ],
    "images": [],
    "choices": [
      {
        "id": 12444,
        "content": [
          "Appreciation"
        ],
        "isCorrect": false
      },
      {
        "id": 12445,
        "content": [
          "Appeasement"
        ],
        "isCorrect": false
      },
      {
        "id": 12446,
        "content": [
          "Praise"
        ],
        "isCorrect": false
      },
      {
        "id": 12447,
        "content": [
          "Criticism"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3110,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What does the expression 'I would rather report otherwise' indicate in the context it is used in paragraph 3?"
    ],
    "explanation": [
      "The phrase \"I would rather report otherwise\" expresses the writer's reluctance to share an unpleasant truth he has observed: that many homeless people have \"chosen the life styles they lead.\" This implies a fear or discomfort in revealing what he believes to be the true, yet unpopular, cause of their situation."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 97,
    "groupIndex": null,
    "sharedContentId": 28,
    "sharedContent": [
      "1. Homeless people are everywhere-on the street, in public buildings, on the evening news and at the corner parking lot. You can hardly step out of your house these days without meeting some haggard character who asks you for a cigarette or begs for \"a little change\". The homeless are not just constant symbols of wasted lives and social programs-they have become a danger to public safety.",
      "2. What is the root of the homeless problem? Everyone seems to have a scapegoat. Advocates of the homeless blame government policy; politicians blame the legal system; the courts blame the bureaucratic infrastructure; the Democrats blame the Republicans and the Republicans blame the Democrats. The public also blames the economy, drugs, the \"poverty cycle\", and \"the breakdown of society\". With all this finger-pointing, the group most responsible for the homeless being the way they are received the least blame. That group is the homeless themselves.",
      "3. How can I say this? For the past two years I have worked with the homeless, volunteering at the Salvation Army and at a soup kitchen in Austin, Texas. I have led a weekly chapel service, served food, listened, counseled, given time and money, and shared their struggles. I have seen their response to troubles, and though I would rather report otherwise, many of them seem to have chosen the life styles they lead. They are unwilling to do the things necessary to overcome their circumstances. They must bear the greatest part of the blame for their manifold troubles.",
      "4. Let me qualify what I just said. Not everyone who finds himself out of a job and in the street is there because he/she wants to be. Some are victims of tragic circumstances. I met many exhausted, sensible people during my time working with Austin's homeless: the single father struggling to earn his working his Austin's homeless: the single father struggling to earn his bread and be a role model for his children; the woman who fled a good job in another city to escape an abusive husband; the well- educated young man who had his world turned upside down by divorce and a layoff. These people deserve every effort to help them back on their feet.",
      "5. But they are not the real problem. They are usually off the streets and resuming normal lives within a period of weeks or months. Even while \"down on their luck\", they are responsible citizens, working in the shelters and applying for jobs. They are homeless, true but only temporarily, because they are eager to reorganize their lives.",
      "6. For every person temporarily homeless, though there are many who are chronically so. Whether because of mental illness, alcoholism, poor education, drug addiction, or simply laziness, these homeless are content to remain as they are. In many cases they choose the streets. They enjoy the freedom and consider begging a minor inconvenience. They know they can always get a job for a day or two for food, cigarettes and alcohol. The sophisticated among them have learned to use the system for what it is worth and figure out that a trip through the welfare line is less trouble than a steady job. In a society that has mastered a dodging responsibility, these homeless prefer a life of no responsibility at all."
    ],
    "images": [],
    "choices": [
      {
        "id": 12448,
        "content": [
          "The need to tell the public about the homeless"
        ],
        "isCorrect": false
      },
      {
        "id": 12449,
        "content": [
          "The fear to hide the true cause of homelessness"
        ],
        "isCorrect": true
      },
      {
        "id": 12450,
        "content": [
          "The need to explain the troubles facing the homeless"
        ],
        "isCorrect": false
      },
      {
        "id": 12451,
        "content": [
          "The fear to condemn the government for the problem"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3111,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What purpose does the writer's reference to personal experience in paragraph 3 serve?"
    ],
    "explanation": [
      "The writer describes his two years of volunteer work at the Salvation Army and a soup kitchen to establish his credibility and support his main argument. This personal experience is presented as evidence for his claim that the homeless themselves are the primary cause of their condition."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 97,
    "groupIndex": null,
    "sharedContentId": 28,
    "sharedContent": [
      "1. Homeless people are everywhere-on the street, in public buildings, on the evening news and at the corner parking lot. You can hardly step out of your house these days without meeting some haggard character who asks you for a cigarette or begs for \"a little change\". The homeless are not just constant symbols of wasted lives and social programs-they have become a danger to public safety.",
      "2. What is the root of the homeless problem? Everyone seems to have a scapegoat. Advocates of the homeless blame government policy; politicians blame the legal system; the courts blame the bureaucratic infrastructure; the Democrats blame the Republicans and the Republicans blame the Democrats. The public also blames the economy, drugs, the \"poverty cycle\", and \"the breakdown of society\". With all this finger-pointing, the group most responsible for the homeless being the way they are received the least blame. That group is the homeless themselves.",
      "3. How can I say this? For the past two years I have worked with the homeless, volunteering at the Salvation Army and at a soup kitchen in Austin, Texas. I have led a weekly chapel service, served food, listened, counseled, given time and money, and shared their struggles. I have seen their response to troubles, and though I would rather report otherwise, many of them seem to have chosen the life styles they lead. They are unwilling to do the things necessary to overcome their circumstances. They must bear the greatest part of the blame for their manifold troubles.",
      "4. Let me qualify what I just said. Not everyone who finds himself out of a job and in the street is there because he/she wants to be. Some are victims of tragic circumstances. I met many exhausted, sensible people during my time working with Austin's homeless: the single father struggling to earn his working his Austin's homeless: the single father struggling to earn his bread and be a role model for his children; the woman who fled a good job in another city to escape an abusive husband; the well- educated young man who had his world turned upside down by divorce and a layoff. These people deserve every effort to help them back on their feet.",
      "5. But they are not the real problem. They are usually off the streets and resuming normal lives within a period of weeks or months. Even while \"down on their luck\", they are responsible citizens, working in the shelters and applying for jobs. They are homeless, true but only temporarily, because they are eager to reorganize their lives.",
      "6. For every person temporarily homeless, though there are many who are chronically so. Whether because of mental illness, alcoholism, poor education, drug addiction, or simply laziness, these homeless are content to remain as they are. In many cases they choose the streets. They enjoy the freedom and consider begging a minor inconvenience. They know they can always get a job for a day or two for food, cigarettes and alcohol. The sophisticated among them have learned to use the system for what it is worth and figure out that a trip through the welfare line is less trouble than a steady job. In a society that has mastered a dodging responsibility, these homeless prefer a life of no responsibility at all."
    ],
    "images": [],
    "choices": [
      {
        "id": 12452,
        "content": [
          "It served as evidence for political involvement."
        ],
        "isCorrect": false
      },
      {
        "id": 12453,
        "content": [
          "It clarified the actual cause of homelessness."
        ],
        "isCorrect": true
      },
      {
        "id": 12454,
        "content": [
          "It served as evidence of social disintegration."
        ],
        "isCorrect": false
      },
      {
        "id": 12455,
        "content": [
          "It showed the ugly lifestyle of the homeless."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3112,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which of the following words is closest in meaning to haggard as used in paragraph 1?"
    ],
    "explanation": [
      "In paragraph 1, \"haggard character\" describes someone who begs on the street. \"Haggard\" means looking exhausted and unwell, which can often make a person appear suspicious or untrustworthy to others, fitting the context of being a \"danger to public safety.\""
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 97,
    "groupIndex": null,
    "sharedContentId": 28,
    "sharedContent": [
      "1. Homeless people are everywhere-on the street, in public buildings, on the evening news and at the corner parking lot. You can hardly step out of your house these days without meeting some haggard character who asks you for a cigarette or begs for \"a little change\". The homeless are not just constant symbols of wasted lives and social programs-they have become a danger to public safety.",
      "2. What is the root of the homeless problem? Everyone seems to have a scapegoat. Advocates of the homeless blame government policy; politicians blame the legal system; the courts blame the bureaucratic infrastructure; the Democrats blame the Republicans and the Republicans blame the Democrats. The public also blames the economy, drugs, the \"poverty cycle\", and \"the breakdown of society\". With all this finger-pointing, the group most responsible for the homeless being the way they are received the least blame. That group is the homeless themselves.",
      "3. How can I say this? For the past two years I have worked with the homeless, volunteering at the Salvation Army and at a soup kitchen in Austin, Texas. I have led a weekly chapel service, served food, listened, counseled, given time and money, and shared their struggles. I have seen their response to troubles, and though I would rather report otherwise, many of them seem to have chosen the life styles they lead. They are unwilling to do the things necessary to overcome their circumstances. They must bear the greatest part of the blame for their manifold troubles.",
      "4. Let me qualify what I just said. Not everyone who finds himself out of a job and in the street is there because he/she wants to be. Some are victims of tragic circumstances. I met many exhausted, sensible people during my time working with Austin's homeless: the single father struggling to earn his working his Austin's homeless: the single father struggling to earn his bread and be a role model for his children; the woman who fled a good job in another city to escape an abusive husband; the well- educated young man who had his world turned upside down by divorce and a layoff. These people deserve every effort to help them back on their feet.",
      "5. But they are not the real problem. They are usually off the streets and resuming normal lives within a period of weeks or months. Even while \"down on their luck\", they are responsible citizens, working in the shelters and applying for jobs. They are homeless, true but only temporarily, because they are eager to reorganize their lives.",
      "6. For every person temporarily homeless, though there are many who are chronically so. Whether because of mental illness, alcoholism, poor education, drug addiction, or simply laziness, these homeless are content to remain as they are. In many cases they choose the streets. They enjoy the freedom and consider begging a minor inconvenience. They know they can always get a job for a day or two for food, cigarettes and alcohol. The sophisticated among them have learned to use the system for what it is worth and figure out that a trip through the welfare line is less trouble than a steady job. In a society that has mastered a dodging responsibility, these homeless prefer a life of no responsibility at all."
    ],
    "images": [],
    "choices": [
      {
        "id": 12456,
        "content": [
          "a person who looks trustful"
        ],
        "isCorrect": false
      },
      {
        "id": 12457,
        "content": [
          "a person who commits crime"
        ],
        "isCorrect": false
      },
      {
        "id": 12458,
        "content": [
          "a person with no home"
        ],
        "isCorrect": false
      },
      {
        "id": 12459,
        "content": [
          "a person who looks suspicious"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3113,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which of the following words can be synonymous with the word content as used in paragraph 6?"
    ],
    "explanation": [
      "In paragraph 6, the passage states that some homeless individuals are \"content to remain as they are.\" In this context, \"content\" means being satisfied or accepting of their current situation, rather than seeking to change it."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 97,
    "groupIndex": null,
    "sharedContentId": 28,
    "sharedContent": [
      "1. Homeless people are everywhere-on the street, in public buildings, on the evening news and at the corner parking lot. You can hardly step out of your house these days without meeting some haggard character who asks you for a cigarette or begs for \"a little change\". The homeless are not just constant symbols of wasted lives and social programs-they have become a danger to public safety.",
      "2. What is the root of the homeless problem? Everyone seems to have a scapegoat. Advocates of the homeless blame government policy; politicians blame the legal system; the courts blame the bureaucratic infrastructure; the Democrats blame the Republicans and the Republicans blame the Democrats. The public also blames the economy, drugs, the \"poverty cycle\", and \"the breakdown of society\". With all this finger-pointing, the group most responsible for the homeless being the way they are received the least blame. That group is the homeless themselves.",
      "3. How can I say this? For the past two years I have worked with the homeless, volunteering at the Salvation Army and at a soup kitchen in Austin, Texas. I have led a weekly chapel service, served food, listened, counseled, given time and money, and shared their struggles. I have seen their response to troubles, and though I would rather report otherwise, many of them seem to have chosen the life styles they lead. They are unwilling to do the things necessary to overcome their circumstances. They must bear the greatest part of the blame for their manifold troubles.",
      "4. Let me qualify what I just said. Not everyone who finds himself out of a job and in the street is there because he/she wants to be. Some are victims of tragic circumstances. I met many exhausted, sensible people during my time working with Austin's homeless: the single father struggling to earn his working his Austin's homeless: the single father struggling to earn his bread and be a role model for his children; the woman who fled a good job in another city to escape an abusive husband; the well- educated young man who had his world turned upside down by divorce and a layoff. These people deserve every effort to help them back on their feet.",
      "5. But they are not the real problem. They are usually off the streets and resuming normal lives within a period of weeks or months. Even while \"down on their luck\", they are responsible citizens, working in the shelters and applying for jobs. They are homeless, true but only temporarily, because they are eager to reorganize their lives.",
      "6. For every person temporarily homeless, though there are many who are chronically so. Whether because of mental illness, alcoholism, poor education, drug addiction, or simply laziness, these homeless are content to remain as they are. In many cases they choose the streets. They enjoy the freedom and consider begging a minor inconvenience. They know they can always get a job for a day or two for food, cigarettes and alcohol. The sophisticated among them have learned to use the system for what it is worth and figure out that a trip through the welfare line is less trouble than a steady job. In a society that has mastered a dodging responsibility, these homeless prefer a life of no responsibility at all."
    ],
    "images": [],
    "choices": [
      {
        "id": 12460,
        "content": [
          "satisfied"
        ],
        "isCorrect": true
      },
      {
        "id": 12461,
        "content": [
          "outrageous"
        ],
        "isCorrect": false
      },
      {
        "id": 12462,
        "content": [
          "naked"
        ],
        "isCorrect": false
      },
      {
        "id": 12463,
        "content": [
          "confident"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3114,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What does the word there in paragraph 4, refer to?"
    ],
    "explanation": [
      "Paragraph 4 begins, \"Not everyone who finds himself out of a job and in the street is there because he/she wants to be.\" The word \"there\" directly refers to the location mentioned just before it, which is \"in the street.\""
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 97,
    "groupIndex": null,
    "sharedContentId": 28,
    "sharedContent": [
      "1. Homeless people are everywhere-on the street, in public buildings, on the evening news and at the corner parking lot. You can hardly step out of your house these days without meeting some haggard character who asks you for a cigarette or begs for \"a little change\". The homeless are not just constant symbols of wasted lives and social programs-they have become a danger to public safety.",
      "2. What is the root of the homeless problem? Everyone seems to have a scapegoat. Advocates of the homeless blame government policy; politicians blame the legal system; the courts blame the bureaucratic infrastructure; the Democrats blame the Republicans and the Republicans blame the Democrats. The public also blames the economy, drugs, the \"poverty cycle\", and \"the breakdown of society\". With all this finger-pointing, the group most responsible for the homeless being the way they are received the least blame. That group is the homeless themselves.",
      "3. How can I say this? For the past two years I have worked with the homeless, volunteering at the Salvation Army and at a soup kitchen in Austin, Texas. I have led a weekly chapel service, served food, listened, counseled, given time and money, and shared their struggles. I have seen their response to troubles, and though I would rather report otherwise, many of them seem to have chosen the life styles they lead. They are unwilling to do the things necessary to overcome their circumstances. They must bear the greatest part of the blame for their manifold troubles.",
      "4. Let me qualify what I just said. Not everyone who finds himself out of a job and in the street is there because he/she wants to be. Some are victims of tragic circumstances. I met many exhausted, sensible people during my time working with Austin's homeless: the single father struggling to earn his working his Austin's homeless: the single father struggling to earn his bread and be a role model for his children; the woman who fled a good job in another city to escape an abusive husband; the well- educated young man who had his world turned upside down by divorce and a layoff. These people deserve every effort to help them back on their feet.",
      "5. But they are not the real problem. They are usually off the streets and resuming normal lives within a period of weeks or months. Even while \"down on their luck\", they are responsible citizens, working in the shelters and applying for jobs. They are homeless, true but only temporarily, because they are eager to reorganize their lives.",
      "6. For every person temporarily homeless, though there are many who are chronically so. Whether because of mental illness, alcoholism, poor education, drug addiction, or simply laziness, these homeless are content to remain as they are. In many cases they choose the streets. They enjoy the freedom and consider begging a minor inconvenience. They know they can always get a job for a day or two for food, cigarettes and alcohol. The sophisticated among them have learned to use the system for what it is worth and figure out that a trip through the welfare line is less trouble than a steady job. In a society that has mastered a dodging responsibility, these homeless prefer a life of no responsibility at all."
    ],
    "images": [],
    "choices": [
      {
        "id": 12464,
        "content": [
          "at a soup kitchen"
        ],
        "isCorrect": false
      },
      {
        "id": 12465,
        "content": [
          "in the street"
        ],
        "isCorrect": true
      },
      {
        "id": 12466,
        "content": [
          "at the Salvation Army"
        ],
        "isCorrect": false
      },
      {
        "id": 12467,
        "content": [
          "in the court"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3115,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What does the word 'so' in paragraph 6, refer to?"
    ],
    "explanation": [
      "The sentence in paragraph 6 reads: \"For every person temporarily homeless, though there are many who are chronically so.\" The word \"so\" is used as a substitute for the adjective mentioned earlier in the sentence, which is \"homeless.\" Thus, it means \"chronically homeless.\""
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 97,
    "groupIndex": null,
    "sharedContentId": 28,
    "sharedContent": [
      "1. Homeless people are everywhere-on the street, in public buildings, on the evening news and at the corner parking lot. You can hardly step out of your house these days without meeting some haggard character who asks you for a cigarette or begs for \"a little change\". The homeless are not just constant symbols of wasted lives and social programs-they have become a danger to public safety.",
      "2. What is the root of the homeless problem? Everyone seems to have a scapegoat. Advocates of the homeless blame government policy; politicians blame the legal system; the courts blame the bureaucratic infrastructure; the Democrats blame the Republicans and the Republicans blame the Democrats. The public also blames the economy, drugs, the \"poverty cycle\", and \"the breakdown of society\". With all this finger-pointing, the group most responsible for the homeless being the way they are received the least blame. That group is the homeless themselves.",
      "3. How can I say this? For the past two years I have worked with the homeless, volunteering at the Salvation Army and at a soup kitchen in Austin, Texas. I have led a weekly chapel service, served food, listened, counseled, given time and money, and shared their struggles. I have seen their response to troubles, and though I would rather report otherwise, many of them seem to have chosen the life styles they lead. They are unwilling to do the things necessary to overcome their circumstances. They must bear the greatest part of the blame for their manifold troubles.",
      "4. Let me qualify what I just said. Not everyone who finds himself out of a job and in the street is there because he/she wants to be. Some are victims of tragic circumstances. I met many exhausted, sensible people during my time working with Austin's homeless: the single father struggling to earn his working his Austin's homeless: the single father struggling to earn his bread and be a role model for his children; the woman who fled a good job in another city to escape an abusive husband; the well- educated young man who had his world turned upside down by divorce and a layoff. These people deserve every effort to help them back on their feet.",
      "5. But they are not the real problem. They are usually off the streets and resuming normal lives within a period of weeks or months. Even while \"down on their luck\", they are responsible citizens, working in the shelters and applying for jobs. They are homeless, true but only temporarily, because they are eager to reorganize their lives.",
      "6. For every person temporarily homeless, though there are many who are chronically so. Whether because of mental illness, alcoholism, poor education, drug addiction, or simply laziness, these homeless are content to remain as they are. In many cases they choose the streets. They enjoy the freedom and consider begging a minor inconvenience. They know they can always get a job for a day or two for food, cigarettes and alcohol. The sophisticated among them have learned to use the system for what it is worth and figure out that a trip through the welfare line is less trouble than a steady job. In a society that has mastered a dodging responsibility, these homeless prefer a life of no responsibility at all."
    ],
    "images": [],
    "choices": [
      {
        "id": 12468,
        "content": [
          "beggar"
        ],
        "isCorrect": false
      },
      {
        "id": 12469,
        "content": [
          "every person"
        ],
        "isCorrect": false
      },
      {
        "id": 12470,
        "content": [
          "drug addict"
        ],
        "isCorrect": false
      },
      {
        "id": 12471,
        "content": [
          "homeless"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3116,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "According to the passage, which of the following is to blame for the life of a homeless person?"
    ],
    "explanation": [
      "The central argument of the passage, stated in paragraphs 2 and 3, is that after considering all other scapegoats, \"the group most responsible\" is \"the homeless themselves.\" The writer claims they \"must bear the greatest part of the blame.\""
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 97,
    "groupIndex": null,
    "sharedContentId": 28,
    "sharedContent": [
      "1. Homeless people are everywhere-on the street, in public buildings, on the evening news and at the corner parking lot. You can hardly step out of your house these days without meeting some haggard character who asks you for a cigarette or begs for \"a little change\". The homeless are not just constant symbols of wasted lives and social programs-they have become a danger to public safety.",
      "2. What is the root of the homeless problem? Everyone seems to have a scapegoat. Advocates of the homeless blame government policy; politicians blame the legal system; the courts blame the bureaucratic infrastructure; the Democrats blame the Republicans and the Republicans blame the Democrats. The public also blames the economy, drugs, the \"poverty cycle\", and \"the breakdown of society\". With all this finger-pointing, the group most responsible for the homeless being the way they are received the least blame. That group is the homeless themselves.",
      "3. How can I say this? For the past two years I have worked with the homeless, volunteering at the Salvation Army and at a soup kitchen in Austin, Texas. I have led a weekly chapel service, served food, listened, counseled, given time and money, and shared their struggles. I have seen their response to troubles, and though I would rather report otherwise, many of them seem to have chosen the life styles they lead. They are unwilling to do the things necessary to overcome their circumstances. They must bear the greatest part of the blame for their manifold troubles.",
      "4. Let me qualify what I just said. Not everyone who finds himself out of a job and in the street is there because he/she wants to be. Some are victims of tragic circumstances. I met many exhausted, sensible people during my time working with Austin's homeless: the single father struggling to earn his working his Austin's homeless: the single father struggling to earn his bread and be a role model for his children; the woman who fled a good job in another city to escape an abusive husband; the well- educated young man who had his world turned upside down by divorce and a layoff. These people deserve every effort to help them back on their feet.",
      "5. But they are not the real problem. They are usually off the streets and resuming normal lives within a period of weeks or months. Even while \"down on their luck\", they are responsible citizens, working in the shelters and applying for jobs. They are homeless, true but only temporarily, because they are eager to reorganize their lives.",
      "6. For every person temporarily homeless, though there are many who are chronically so. Whether because of mental illness, alcoholism, poor education, drug addiction, or simply laziness, these homeless are content to remain as they are. In many cases they choose the streets. They enjoy the freedom and consider begging a minor inconvenience. They know they can always get a job for a day or two for food, cigarettes and alcohol. The sophisticated among them have learned to use the system for what it is worth and figure out that a trip through the welfare line is less trouble than a steady job. In a society that has mastered a dodging responsibility, these homeless prefer a life of no responsibility at all."
    ],
    "images": [],
    "choices": [
      {
        "id": 12472,
        "content": [
          "The homeless themselves"
        ],
        "isCorrect": true
      },
      {
        "id": 12473,
        "content": [
          "The Republicans"
        ],
        "isCorrect": false
      },
      {
        "id": 12474,
        "content": [
          "The bureaucratic infrastructure"
        ],
        "isCorrect": false
      },
      {
        "id": 12475,
        "content": [
          "The government policy"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3117,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What does 'These' in paragraph 2 refer to?"
    ],
    "explanation": [
      "The first sentence of paragraph 2 introduces the topic: \"Soil degradation has been aggravated by poor agricultural practices.\" The next sentence begins with \"These include...\" and then lists examples like improper terracing and cultivating steep hillsides. Therefore, \"These\" refers back to \"poor agricultural practices.\""
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 98,
    "groupIndex": null,
    "sharedContentId": 29,
    "sharedContent": [
      "1. The preservation of forest areas, wildlife and soil should be of a vital concern to all Ethiopians, since its neglect means a destruction of replaceable natural resources, a serious loss of revenue and then gradual desolation of the land until it becomes unfit for cultivation. According to a UNESCO survey in 1963, the consequences will be disastrous unless drastic measures are adopted. An example of this neglect is the present and past treatments of forests. In the good old days, the Ethiopian highlands were covered with virgin forests, which have since been largely used for construction and fuel. Along with the introduction of the eucalyptus tree, this has prevented the country from becoming a desert; however, the few remaining forest areas are not being preserved. The Ethiopian custom grants a man ownership of any land he clears off trees, and he is presented with forested tracts as a reward for his service to the government. The next twenty or thirty years will see the last remnants of virgin forests destroyed unless strong measures are taken.",
      "2. Soil degradation has been aggravated by poor agricultural practices. These include improper terracing, the cultivation of steep and easily eroded hillsides, failure to rotate crops (with the consequent loss of valuable nutrients), and the burning of manure instead of returning it to the soil as fertilizer. The destruction of trees and the lack of modern farming methods are not themselves as bad as the erosion of the soil which may follow them. Several generations may be able to live off the land, but gradually the soil is washed away to Egypt, making the land increasingly poor in quality and yielding less and less. Unfortunately, it is almost impossible to reclaim land that has deteriorated beyond a certain point. Trees cannot be planted to suck up water and hold the soil, because the earth is no longer deep enough to support long roots."
    ],
    "images": [],
    "choices": [
      {
        "id": 12476,
        "content": [
          "soil conservation"
        ],
        "isCorrect": false
      },
      {
        "id": 12477,
        "content": [
          "improper terracing"
        ],
        "isCorrect": false
      },
      {
        "id": 12478,
        "content": [
          "preservation of forests"
        ],
        "isCorrect": false
      },
      {
        "id": 12479,
        "content": [
          "poor agricultural practices"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3118,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What does the word 'desolation' mean in paragraph 1?"
    ],
    "explanation": [
      "In the context of paragraph 1, \"desolation of the land until it becomes unfit for cultivation\" describes a process of the land becoming barren and empty. \"Desertion\" implies abandonment and barrenness, which aligns with the land being rendered useless for farming."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 98,
    "groupIndex": null,
    "sharedContentId": 29,
    "sharedContent": [
      "1. The preservation of forest areas, wildlife and soil should be of a vital concern to all Ethiopians, since its neglect means a destruction of replaceable natural resources, a serious loss of revenue and then gradual desolation of the land until it becomes unfit for cultivation. According to a UNESCO survey in 1963, the consequences will be disastrous unless drastic measures are adopted. An example of this neglect is the present and past treatments of forests. In the good old days, the Ethiopian highlands were covered with virgin forests, which have since been largely used for construction and fuel. Along with the introduction of the eucalyptus tree, this has prevented the country from becoming a desert; however, the few remaining forest areas are not being preserved. The Ethiopian custom grants a man ownership of any land he clears off trees, and he is presented with forested tracts as a reward for his service to the government. The next twenty or thirty years will see the last remnants of virgin forests destroyed unless strong measures are taken.",
      "2. Soil degradation has been aggravated by poor agricultural practices. These include improper terracing, the cultivation of steep and easily eroded hillsides, failure to rotate crops (with the consequent loss of valuable nutrients), and the burning of manure instead of returning it to the soil as fertilizer. The destruction of trees and the lack of modern farming methods are not themselves as bad as the erosion of the soil which may follow them. Several generations may be able to live off the land, but gradually the soil is washed away to Egypt, making the land increasingly poor in quality and yielding less and less. Unfortunately, it is almost impossible to reclaim land that has deteriorated beyond a certain point. Trees cannot be planted to suck up water and hold the soil, because the earth is no longer deep enough to support long roots."
    ],
    "images": [],
    "choices": [
      {
        "id": 12480,
        "content": [
          "disappearance"
        ],
        "isCorrect": false
      },
      {
        "id": 12481,
        "content": [
          "destruction"
        ],
        "isCorrect": false
      },
      {
        "id": 12482,
        "content": [
          "desertion"
        ],
        "isCorrect": true
      },
      {
        "id": 12483,
        "content": [
          "enrichment"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3119,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which of the following best replaces the word 'aggravated' in paragraph 2?"
    ],
    "explanation": [
      "Paragraph 2 states that soil degradation has been \"aggravated by poor agricultural practices.\" The word \"aggravated\" means to make a problem or situation worse. Therefore, \"worsened\" is the best replacement."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 98,
    "groupIndex": null,
    "sharedContentId": 29,
    "sharedContent": [
      "1. The preservation of forest areas, wildlife and soil should be of a vital concern to all Ethiopians, since its neglect means a destruction of replaceable natural resources, a serious loss of revenue and then gradual desolation of the land until it becomes unfit for cultivation. According to a UNESCO survey in 1963, the consequences will be disastrous unless drastic measures are adopted. An example of this neglect is the present and past treatments of forests. In the good old days, the Ethiopian highlands were covered with virgin forests, which have since been largely used for construction and fuel. Along with the introduction of the eucalyptus tree, this has prevented the country from becoming a desert; however, the few remaining forest areas are not being preserved. The Ethiopian custom grants a man ownership of any land he clears off trees, and he is presented with forested tracts as a reward for his service to the government. The next twenty or thirty years will see the last remnants of virgin forests destroyed unless strong measures are taken.",
      "2. Soil degradation has been aggravated by poor agricultural practices. These include improper terracing, the cultivation of steep and easily eroded hillsides, failure to rotate crops (with the consequent loss of valuable nutrients), and the burning of manure instead of returning it to the soil as fertilizer. The destruction of trees and the lack of modern farming methods are not themselves as bad as the erosion of the soil which may follow them. Several generations may be able to live off the land, but gradually the soil is washed away to Egypt, making the land increasingly poor in quality and yielding less and less. Unfortunately, it is almost impossible to reclaim land that has deteriorated beyond a certain point. Trees cannot be planted to suck up water and hold the soil, because the earth is no longer deep enough to support long roots."
    ],
    "images": [],
    "choices": [
      {
        "id": 12484,
        "content": [
          "worsened"
        ],
        "isCorrect": true
      },
      {
        "id": 12485,
        "content": [
          "supplemented"
        ],
        "isCorrect": false
      },
      {
        "id": 12486,
        "content": [
          "regulated"
        ],
        "isCorrect": false
      },
      {
        "id": 12487,
        "content": [
          "improved"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3120,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "The prolonged erosion of the soil is followed by"
    ],
    "explanation": [
      "Paragraph 2 explains that as soil erodes and becomes shallow, \"Trees cannot be planted... because the earth is no longer deep enough to support long roots.\" This leads to a situation where the land cannot sustain plant life, resulting in the total absence of plants."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 98,
    "groupIndex": null,
    "sharedContentId": 29,
    "sharedContent": [
      "1. The preservation of forest areas, wildlife and soil should be of a vital concern to all Ethiopians, since its neglect means a destruction of replaceable natural resources, a serious loss of revenue and then gradual desolation of the land until it becomes unfit for cultivation. According to a UNESCO survey in 1963, the consequences will be disastrous unless drastic measures are adopted. An example of this neglect is the present and past treatments of forests. In the good old days, the Ethiopian highlands were covered with virgin forests, which have since been largely used for construction and fuel. Along with the introduction of the eucalyptus tree, this has prevented the country from becoming a desert; however, the few remaining forest areas are not being preserved. The Ethiopian custom grants a man ownership of any land he clears off trees, and he is presented with forested tracts as a reward for his service to the government. The next twenty or thirty years will see the last remnants of virgin forests destroyed unless strong measures are taken.",
      "2. Soil degradation has been aggravated by poor agricultural practices. These include improper terracing, the cultivation of steep and easily eroded hillsides, failure to rotate crops (with the consequent loss of valuable nutrients), and the burning of manure instead of returning it to the soil as fertilizer. The destruction of trees and the lack of modern farming methods are not themselves as bad as the erosion of the soil which may follow them. Several generations may be able to live off the land, but gradually the soil is washed away to Egypt, making the land increasingly poor in quality and yielding less and less. Unfortunately, it is almost impossible to reclaim land that has deteriorated beyond a certain point. Trees cannot be planted to suck up water and hold the soil, because the earth is no longer deep enough to support long roots."
    ],
    "images": [],
    "choices": [
      {
        "id": 12488,
        "content": [
          "rapid reproduction of wild animals."
        ],
        "isCorrect": false
      },
      {
        "id": 12489,
        "content": [
          "enrichment of the soil by various nutrients."
        ],
        "isCorrect": false
      },
      {
        "id": 12490,
        "content": [
          "the total absence of plants."
        ],
        "isCorrect": true
      },
      {
        "id": 12491,
        "content": [
          "the leveling of the mountains."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3121,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "In highly eroded and desolated areas, trees fail to survive because"
    ],
    "explanation": [
      "Paragraph 2 explicitly states the reason trees cannot survive is that \"the earth is no longer deep enough to support long roots.\" The shallow soil prevents the roots from anchoring and accessing water."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 98,
    "groupIndex": null,
    "sharedContentId": 29,
    "sharedContent": [
      "1. The preservation of forest areas, wildlife and soil should be of a vital concern to all Ethiopians, since its neglect means a destruction of replaceable natural resources, a serious loss of revenue and then gradual desolation of the land until it becomes unfit for cultivation. According to a UNESCO survey in 1963, the consequences will be disastrous unless drastic measures are adopted. An example of this neglect is the present and past treatments of forests. In the good old days, the Ethiopian highlands were covered with virgin forests, which have since been largely used for construction and fuel. Along with the introduction of the eucalyptus tree, this has prevented the country from becoming a desert; however, the few remaining forest areas are not being preserved. The Ethiopian custom grants a man ownership of any land he clears off trees, and he is presented with forested tracts as a reward for his service to the government. The next twenty or thirty years will see the last remnants of virgin forests destroyed unless strong measures are taken.",
      "2. Soil degradation has been aggravated by poor agricultural practices. These include improper terracing, the cultivation of steep and easily eroded hillsides, failure to rotate crops (with the consequent loss of valuable nutrients), and the burning of manure instead of returning it to the soil as fertilizer. The destruction of trees and the lack of modern farming methods are not themselves as bad as the erosion of the soil which may follow them. Several generations may be able to live off the land, but gradually the soil is washed away to Egypt, making the land increasingly poor in quality and yielding less and less. Unfortunately, it is almost impossible to reclaim land that has deteriorated beyond a certain point. Trees cannot be planted to suck up water and hold the soil, because the earth is no longer deep enough to support long roots."
    ],
    "images": [],
    "choices": [
      {
        "id": 12492,
        "content": [
          "their roots are too short to suck up water from the ground."
        ],
        "isCorrect": true
      },
      {
        "id": 12493,
        "content": [
          "the sun will be too scorching for them to survive."
        ],
        "isCorrect": false
      },
      {
        "id": 12494,
        "content": [
          "they do not get nutrients from the soil."
        ],
        "isCorrect": false
      },
      {
        "id": 12495,
        "content": [
          "they do not get sufficient sunshine."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3122,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which of the following, according to paragraph 1, is a result of preserving forest areas?"
    ],
    "explanation": [
      "Paragraph 1 states that the \"preservation of forest areas, wildlife and soil\" is a vital concern. The opposite of this, neglect, leads to the \"destruction of replaceable natural resources.\" Therefore, preservation supports natural resources, which includes the habitats necessary for the reproduction of wildlife."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 98,
    "groupIndex": null,
    "sharedContentId": 29,
    "sharedContent": [
      "1. The preservation of forest areas, wildlife and soil should be of a vital concern to all Ethiopians, since its neglect means a destruction of replaceable natural resources, a serious loss of revenue and then gradual desolation of the land until it becomes unfit for cultivation. According to a UNESCO survey in 1963, the consequences will be disastrous unless drastic measures are adopted. An example of this neglect is the present and past treatments of forests. In the good old days, the Ethiopian highlands were covered with virgin forests, which have since been largely used for construction and fuel. Along with the introduction of the eucalyptus tree, this has prevented the country from becoming a desert; however, the few remaining forest areas are not being preserved. The Ethiopian custom grants a man ownership of any land he clears off trees, and he is presented with forested tracts as a reward for his service to the government. The next twenty or thirty years will see the last remnants of virgin forests destroyed unless strong measures are taken.",
      "2. Soil degradation has been aggravated by poor agricultural practices. These include improper terracing, the cultivation of steep and easily eroded hillsides, failure to rotate crops (with the consequent loss of valuable nutrients), and the burning of manure instead of returning it to the soil as fertilizer. The destruction of trees and the lack of modern farming methods are not themselves as bad as the erosion of the soil which may follow them. Several generations may be able to live off the land, but gradually the soil is washed away to Egypt, making the land increasingly poor in quality and yielding less and less. Unfortunately, it is almost impossible to reclaim land that has deteriorated beyond a certain point. Trees cannot be planted to suck up water and hold the soil, because the earth is no longer deep enough to support long roots."
    ],
    "images": [],
    "choices": [
      {
        "id": 12496,
        "content": [
          "Devastation of irreplaceable natural resources"
        ],
        "isCorrect": false
      },
      {
        "id": 12497,
        "content": [
          "Ruins of the land through processes"
        ],
        "isCorrect": false
      },
      {
        "id": 12498,
        "content": [
          "Reproduction of wildlife"
        ],
        "isCorrect": true
      },
      {
        "id": 12499,
        "content": [
          "Serious loss of income"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3123,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which of the following, according to paragraph 2, can be a cause of soil erosion?"
    ],
    "explanation": [
      "Paragraph 2 lists several \"poor agricultural practices\" that aggravate soil degradation. One of these is \"the cultivation of steep and easily eroded hillsides,\" which is a direct cause of soil erosion."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 98,
    "groupIndex": null,
    "sharedContentId": 29,
    "sharedContent": [
      "1. The preservation of forest areas, wildlife and soil should be of a vital concern to all Ethiopians, since its neglect means a destruction of replaceable natural resources, a serious loss of revenue and then gradual desolation of the land until it becomes unfit for cultivation. According to a UNESCO survey in 1963, the consequences will be disastrous unless drastic measures are adopted. An example of this neglect is the present and past treatments of forests. In the good old days, the Ethiopian highlands were covered with virgin forests, which have since been largely used for construction and fuel. Along with the introduction of the eucalyptus tree, this has prevented the country from becoming a desert; however, the few remaining forest areas are not being preserved. The Ethiopian custom grants a man ownership of any land he clears off trees, and he is presented with forested tracts as a reward for his service to the government. The next twenty or thirty years will see the last remnants of virgin forests destroyed unless strong measures are taken.",
      "2. Soil degradation has been aggravated by poor agricultural practices. These include improper terracing, the cultivation of steep and easily eroded hillsides, failure to rotate crops (with the consequent loss of valuable nutrients), and the burning of manure instead of returning it to the soil as fertilizer. The destruction of trees and the lack of modern farming methods are not themselves as bad as the erosion of the soil which may follow them. Several generations may be able to live off the land, but gradually the soil is washed away to Egypt, making the land increasingly poor in quality and yielding less and less. Unfortunately, it is almost impossible to reclaim land that has deteriorated beyond a certain point. Trees cannot be planted to suck up water and hold the soil, because the earth is no longer deep enough to support long roots."
    ],
    "images": [],
    "choices": [
      {
        "id": 12500,
        "content": [
          "Planting trees and using modern farming"
        ],
        "isCorrect": false
      },
      {
        "id": 12501,
        "content": [
          "Cultivating easily eroded hillsides"
        ],
        "isCorrect": true
      },
      {
        "id": 12502,
        "content": [
          "Using poor quality of fertilizer"
        ],
        "isCorrect": false
      },
      {
        "id": 12503,
        "content": [
          "Losing valuable nutrients"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3124,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "According to paragraph 2, which of the following is true?"
    ],
    "explanation": [
      "Paragraph 2 makes a direct comparison, stating: \"The destruction of trees and the lack of modern farming methods are not themselves as bad as the erosion of the soil which may follow them.\" This explicitly indicates that soil erosion is considered a worse problem than the destruction of trees alone."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 98,
    "groupIndex": null,
    "sharedContentId": 29,
    "sharedContent": [
      "1. The preservation of forest areas, wildlife and soil should be of a vital concern to all Ethiopians, since its neglect means a destruction of replaceable natural resources, a serious loss of revenue and then gradual desolation of the land until it becomes unfit for cultivation. According to a UNESCO survey in 1963, the consequences will be disastrous unless drastic measures are adopted. An example of this neglect is the present and past treatments of forests. In the good old days, the Ethiopian highlands were covered with virgin forests, which have since been largely used for construction and fuel. Along with the introduction of the eucalyptus tree, this has prevented the country from becoming a desert; however, the few remaining forest areas are not being preserved. The Ethiopian custom grants a man ownership of any land he clears off trees, and he is presented with forested tracts as a reward for his service to the government. The next twenty or thirty years will see the last remnants of virgin forests destroyed unless strong measures are taken.",
      "2. Soil degradation has been aggravated by poor agricultural practices. These include improper terracing, the cultivation of steep and easily eroded hillsides, failure to rotate crops (with the consequent loss of valuable nutrients), and the burning of manure instead of returning it to the soil as fertilizer. The destruction of trees and the lack of modern farming methods are not themselves as bad as the erosion of the soil which may follow them. Several generations may be able to live off the land, but gradually the soil is washed away to Egypt, making the land increasingly poor in quality and yielding less and less. Unfortunately, it is almost impossible to reclaim land that has deteriorated beyond a certain point. Trees cannot be planted to suck up water and hold the soil, because the earth is no longer deep enough to support long roots."
    ],
    "images": [],
    "choices": [
      {
        "id": 12504,
        "content": [
          "Plants can be planted to suck up water and hold soil even if the earth is too shallow to support long roots."
        ],
        "isCorrect": false
      },
      {
        "id": 12505,
        "content": [
          "When the soil is washed away to neighboring countries, land productivity increases."
        ],
        "isCorrect": false
      },
      {
        "id": 12506,
        "content": [
          "The preservation of forest areas is not the concern of Ethiopians."
        ],
        "isCorrect": false
      },
      {
        "id": 12507,
        "content": [
          "Erosion of the soil is worse than destruction of trees."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3125,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What does 'its' in paragraph 1 refer to?"
    ],
    "explanation": [
      "The sentence in paragraph 1 says, \"The preservation of forest areas, wildlife and soil should be of a vital concern to all Ethiopians, since its neglect means a destruction...\". The possessive pronoun \"its\" refers to the entire preceding noun phrase: \"The preservation of forest areas, wildlife and soil,\" which can be summarized as the preservation of natural resources."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 98,
    "groupIndex": null,
    "sharedContentId": 29,
    "sharedContent": [
      "1. The preservation of forest areas, wildlife and soil should be of a vital concern to all Ethiopians, since its neglect means a destruction of replaceable natural resources, a serious loss of revenue and then gradual desolation of the land until it becomes unfit for cultivation. According to a UNESCO survey in 1963, the consequences will be disastrous unless drastic measures are adopted. An example of this neglect is the present and past treatments of forests. In the good old days, the Ethiopian highlands were covered with virgin forests, which have since been largely used for construction and fuel. Along with the introduction of the eucalyptus tree, this has prevented the country from becoming a desert; however, the few remaining forest areas are not being preserved. The Ethiopian custom grants a man ownership of any land he clears off trees, and he is presented with forested tracts as a reward for his service to the government. The next twenty or thirty years will see the last remnants of virgin forests destroyed unless strong measures are taken.",
      "2. Soil degradation has been aggravated by poor agricultural practices. These include improper terracing, the cultivation of steep and easily eroded hillsides, failure to rotate crops (with the consequent loss of valuable nutrients), and the burning of manure instead of returning it to the soil as fertilizer. The destruction of trees and the lack of modern farming methods are not themselves as bad as the erosion of the soil which may follow them. Several generations may be able to live off the land, but gradually the soil is washed away to Egypt, making the land increasingly poor in quality and yielding less and less. Unfortunately, it is almost impossible to reclaim land that has deteriorated beyond a certain point. Trees cannot be planted to suck up water and hold the soil, because the earth is no longer deep enough to support long roots."
    ],
    "images": [],
    "choices": [
      {
        "id": 12508,
        "content": [
          "preservation of natural resources"
        ],
        "isCorrect": true
      },
      {
        "id": 12509,
        "content": [
          "destruction of natural resources"
        ],
        "isCorrect": false
      },
      {
        "id": 12510,
        "content": [
          "the wild life and soil"
        ],
        "isCorrect": false
      },
      {
        "id": 12511,
        "content": [
          "the forest areas"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3172,
    "content": [
      "Choose the statement which is correctly punctuated and capitalized."
    ],
    "explanation": [
      "This option correctly joins two independent clauses with a period. The second sentence starts with a capital letter \"They.\" Option B incorrectly capitalizes \"They\" after a semicolon. Option C is a comma splice. Option D is a run-on sentence."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 102,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12696,
        "content": [
          "Tadesse and Fanuel are good friends. They study their lessons together and help each other."
        ],
        "isCorrect": true
      },
      {
        "id": 12697,
        "content": [
          "Tadesse and Fanuel are good friends; They study their lessons together and help each other."
        ],
        "isCorrect": false
      },
      {
        "id": 12698,
        "content": [
          "Tadesse and Fanuel are good friends, they study their lessons together and help each other."
        ],
        "isCorrect": false
      },
      {
        "id": 12699,
        "content": [
          "Tadesse and Fanuel are good friends They study their lessons together and help each other!"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3173,
    "content": [
      "Choose the statement which is correctly punctuated and capitalized."
    ],
    "explanation": [
      "This option correctly places a comma after the introductory phrase \"In addition\" and ends the sentence with a period. Option A is missing the comma. Option B is missing the final period. Option C incorrectly uses a lowercase 'i' for \"in\"."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 102,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12700,
        "content": [
          "Ethiopia is a rich country endowed with many natural resources. In addition it has many diversified cultures and very friendly people."
        ],
        "isCorrect": false
      },
      {
        "id": 12701,
        "content": [
          "Ethiopia is a rich country endowed with many natural resources. In addition, it has many diversified cultures and very friendly people"
        ],
        "isCorrect": false
      },
      {
        "id": 12702,
        "content": [
          "Ethiopia is a rich country endowed with many natural resources. in addition, it has many diversified cultures and very friendly people."
        ],
        "isCorrect": false
      },
      {
        "id": 12703,
        "content": [
          "Ethiopia is a rich country endowed with many natural resources. In addition, it has many diversified cultures and very friendly people."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3174,
    "content": [
      "Choose the statement which is correctly punctuated and capitalized."
    ],
    "explanation": [
      "This option correctly uses a comma after the interjection \"Hello\" and an exclamation mark to separate the greeting from the question. The question \"Can I help you?\" correctly starts with a capital letter."
    ],
    "year": "YEAR_2017",
    "subject": "ENGLISH_NATURAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 102,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12704,
        "content": [
          "Hello Kenyan National Hotel, can I help you?"
        ],
        "isCorrect": false
      },
      {
        "id": 12705,
        "content": [
          "Hello, Kenyan National Hotel. can I help you?"
        ],
        "isCorrect": false
      },
      {
        "id": 12706,
        "content": [
          "Hello Kenyan National Hotel. Can I help you?"
        ],
        "isCorrect": false
      },
      {
        "id": 12707,
        "content": [
          "Hello, Kenyan National Hotel! Can I help you?"
        ],
        "isCorrect": true
      }
    ]
  }
];
export default questions;
