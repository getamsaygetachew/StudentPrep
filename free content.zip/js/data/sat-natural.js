// StudentPrep Free Content — only the first 2 non-empty curriculum units/categories per grade/subject.
const questions = [
  {
    "id": 1460,
    "content": [
      "Choose the word that is nearly similar in meaning to the word that is capitalized.",
      "---",
      "The **DIFFUSION** of the virus had reached an epidemic proportion."
    ],
    "explanation": [
      "Diffusion means the spreading of something more widely. 'Spread' means to extend over a large or increasing area. In the context of a virus becoming widespread, 'spread' is the most fitting synonym for diffusion."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 2,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5841,
        "content": [
          "dissemination"
        ],
        "isCorrect": false
      },
      {
        "id": 5842,
        "content": [
          "spread"
        ],
        "isCorrect": true
      },
      {
        "id": 5843,
        "content": [
          "diagnosis"
        ],
        "isCorrect": false
      },
      {
        "id": 5844,
        "content": [
          "vulnerability"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1461,
    "content": [
      "Choose the word that is nearly similar in meaning to the word that is capitalized.",
      "---",
      "The electric poles were **IMPREGNATED** with chemical solutions for durability."
    ],
    "explanation": [
      "Impregnated means to soak or saturate something thoroughly with a substance. 'Saturated' means thoroughly soaked, which closely matches the meaning of impregnating the poles with chemical solutions."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 2,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5845,
        "content": [
          "saturated"
        ],
        "isCorrect": true
      },
      {
        "id": 5846,
        "content": [
          "varnished"
        ],
        "isCorrect": false
      },
      {
        "id": 5847,
        "content": [
          "erected"
        ],
        "isCorrect": false
      },
      {
        "id": 5848,
        "content": [
          "washed"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1462,
    "content": [
      "Choose the word that is nearly similar in meaning to the word that is capitalized.",
      "---",
      "The sense of **ANIMOSITY** between the rival groups was resolved peacefully."
    ],
    "explanation": [
      "Animosity refers to strong hostility or ill will. 'Hatred' is intense dislike or ill will, making it the closest synonym among the given options."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 2,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5849,
        "content": [
          "grievance"
        ],
        "isCorrect": false
      },
      {
        "id": 5850,
        "content": [
          "hatred"
        ],
        "isCorrect": true
      },
      {
        "id": 5851,
        "content": [
          "exposure"
        ],
        "isCorrect": false
      },
      {
        "id": 5852,
        "content": [
          "revenge"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1463,
    "content": [
      "Choose the word that is nearly similar in meaning to the word that is capitalized.",
      "---",
      "The practice of tax **EVASION** is harmful to the development of a nation."
    ],
    "explanation": [
      "Evasion means the act of escaping or avoiding something, often implies illegality or deceit (as in tax evasion). 'Avoidance' means keeping away from or preventing something from happening. While tax evasion has a specific illegal connotation distinct from legal tax avoidance, 'avoidance' is the closest general meaning provided in the options."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 2,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5853,
        "content": [
          "avoidance"
        ],
        "isCorrect": true
      },
      {
        "id": 5854,
        "content": [
          "endorsement"
        ],
        "isCorrect": false
      },
      {
        "id": 5855,
        "content": [
          "conviction"
        ],
        "isCorrect": false
      },
      {
        "id": 5856,
        "content": [
          "resilience"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1464,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "GUNPOWDER: EXPLOSION;",
      "Volcano:______________."
    ],
    "explanation": [
      "The relationship is Cause: Effect or Object: Characteristic Action. Gunpowder is a substance whose characteristic action or result is an explosion. Similarly, a volcano is a geological feature whose characteristic action or result is an eruption."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 3,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5857,
        "content": [
          "Landslide"
        ],
        "isCorrect": false
      },
      {
        "id": 5858,
        "content": [
          "Concentration"
        ],
        "isCorrect": false
      },
      {
        "id": 5859,
        "content": [
          "Eruption"
        ],
        "isCorrect": true
      },
      {
        "id": 5860,
        "content": [
          "Pasteurization"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1465,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "CARAVAN: DESERT;",
      "Perch:______________."
    ],
    "explanation": [
      "The relationship is Entity: Typical Environment/Medium. A caravan (a group traveling together) is typically associated with traveling through a desert. A perch is a type of fish, and fish live in an aquatic environment."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 3,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5861,
        "content": [
          "Aquatic"
        ],
        "isCorrect": true
      },
      {
        "id": 5862,
        "content": [
          "Terrestrial"
        ],
        "isCorrect": false
      },
      {
        "id": 5863,
        "content": [
          "Aerial"
        ],
        "isCorrect": false
      },
      {
        "id": 5864,
        "content": [
          "Tropical"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1466,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "HISTORY: CHRONOLOGICAL;",
      "Topography:______________."
    ],
    "explanation": [
      "History is the study of past events, typically arranged in chronological order (time sequence). Topography is the arrangement or description of the physical features of an area, which relates to space. Therefore, topography is concerned with spatial arrangement."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 3,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5865,
        "content": [
          "Temperature"
        ],
        "isCorrect": false
      },
      {
        "id": 5866,
        "content": [
          "Spatial"
        ],
        "isCorrect": true
      },
      {
        "id": 5867,
        "content": [
          "Climate"
        ],
        "isCorrect": false
      },
      {
        "id": 5868,
        "content": [
          "Travel"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1467,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "DREAM: SHATTERED;",
      "Promises:______________."
    ],
    "explanation": [
      "A dream (an aspiration or hope) can be shattered, meaning it fails or is destroyed. Similarly, promises can be broken, meaning they are not kept or fulfilled. 'Broken' is the common term used when promises fail."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 3,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5869,
        "content": [
          "Broken"
        ],
        "isCorrect": true
      },
      {
        "id": 5870,
        "content": [
          "Denied"
        ],
        "isCorrect": false
      },
      {
        "id": 5871,
        "content": [
          "Cancelled"
        ],
        "isCorrect": false
      },
      {
        "id": 5872,
        "content": [
          "fulfilled"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1468,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "BROADCAST: VERBAL;",
      "Paralanguage:______________."
    ],
    "explanation": [
      "A broadcast (like radio) is primarily a form of verbal communication. Paralanguage refers to non-verbal elements of communication used to modify meaning and convey emotion, such as pitch, volume, and, importantly, gestures and facial expressions, which relate to the body. Therefore, paralanguage is often expressed through the body."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 3,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5873,
        "content": [
          "Audio-visual"
        ],
        "isCorrect": false
      },
      {
        "id": 5874,
        "content": [
          "Imagery"
        ],
        "isCorrect": false
      },
      {
        "id": 5875,
        "content": [
          "Body"
        ],
        "isCorrect": true
      },
      {
        "id": 5876,
        "content": [
          "Multimodal"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1850,
    "content": [
      "Choose the word that is nearly similar in meaning to the word below.",
      "---",
      "**CONDONE**"
    ],
    "explanation": [
      "'Condone' means to accept or overlook behavior that is considered wrong. 'Forgive' means to stop feeling angry or resentful towards someone for an offense.."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 32,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7408,
        "content": [
          "Forgive"
        ],
        "isCorrect": true
      },
      {
        "id": 7409,
        "content": [
          "Complicate"
        ],
        "isCorrect": false
      },
      {
        "id": 7410,
        "content": [
          "Confuse"
        ],
        "isCorrect": false
      },
      {
        "id": 7411,
        "content": [
          "Discourage"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1851,
    "content": [
      "Choose the word that is nearly similar in meaning to the word below.",
      "---",
      "**ADHERE**"
    ],
    "explanation": [
      "'Adhere' means to stick to something physically, or to follow rules, beliefs, or instructions. 'Obey' means to comply with commands or laws."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 32,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7412,
        "content": [
          "Decline"
        ],
        "isCorrect": false
      },
      {
        "id": 7413,
        "content": [
          "Drop"
        ],
        "isCorrect": false
      },
      {
        "id": 7414,
        "content": [
          "Abandon"
        ],
        "isCorrect": false
      },
      {
        "id": 7415,
        "content": [
          "Obey"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1852,
    "content": [
      "Choose the word that is nearly similar in meaning to the word below.",
      "---",
      "**FEASIBLE**"
    ],
    "explanation": [
      "'Feasible' means possible to do easily or conveniently; likely. 'Achievable' means able to be brought about or reached successfully."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 32,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7416,
        "content": [
          "Unrealistic"
        ],
        "isCorrect": false
      },
      {
        "id": 7417,
        "content": [
          "Impractical"
        ],
        "isCorrect": false
      },
      {
        "id": 7418,
        "content": [
          "Achievable"
        ],
        "isCorrect": true
      },
      {
        "id": 7419,
        "content": [
          "Ambitious"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1853,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "**BOTANY: PLANTS;**",
      "__________ : Soil"
    ],
    "explanation": [
      "The relationship is \"field of study : subject studied\". Botany is the scientific study of plants. Pedology is the scientific study of soil."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 33,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7420,
        "content": [
          "Sociology"
        ],
        "isCorrect": false
      },
      {
        "id": 7421,
        "content": [
          "Pedagogy"
        ],
        "isCorrect": false
      },
      {
        "id": 7422,
        "content": [
          "Pedology"
        ],
        "isCorrect": true
      },
      {
        "id": 7423,
        "content": [
          "Biology"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1854,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "**WONDERFUL: SATISFACTORY;**",
      "Gigantic: __________"
    ],
    "explanation": [
      "The relationship is \"extreme degree : moderate degree\". Wonderful is an extreme degree of satisfactory. Gigantic is an extreme degree of large."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 33,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7424,
        "content": [
          "Broad"
        ],
        "isCorrect": false
      },
      {
        "id": 7425,
        "content": [
          "Large"
        ],
        "isCorrect": true
      },
      {
        "id": 7426,
        "content": [
          "Comprehensive"
        ],
        "isCorrect": false
      },
      {
        "id": 7427,
        "content": [
          "Spacious"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1855,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "**JUSTICE: FAIRNESS;**",
      "_________ : Bias"
    ],
    "explanation": [
      "The relationship is \"concept : defining characteristic/synonym\" or potentially \"ideal : its opposite's defining characteristic\". Justice is characterized by fairness. Prejudice is characterized by bias."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 33,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7428,
        "content": [
          "Rational"
        ],
        "isCorrect": false
      },
      {
        "id": 7429,
        "content": [
          "Prejudice"
        ],
        "isCorrect": true
      },
      {
        "id": 7430,
        "content": [
          "Compassion"
        ],
        "isCorrect": false
      },
      {
        "id": 7431,
        "content": [
          "Just"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1856,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "**TEAM: PLAYER;**",
      "__________ : Member"
    ],
    "explanation": [
      "The relationship is \"group : individual component\". A player is an individual component of a team. A member is an individual component of a crew."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 33,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7432,
        "content": [
          "Crew"
        ],
        "isCorrect": true
      },
      {
        "id": 7433,
        "content": [
          "Musician"
        ],
        "isCorrect": false
      },
      {
        "id": 7434,
        "content": [
          "Vocalist"
        ],
        "isCorrect": false
      },
      {
        "id": 7435,
        "content": [
          "Trainer"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3056,
    "content": [
      "Choose the word that correctly completes the analogy.",
      "---",
      "EXERCISE is to GYM as EATING is to:"
    ],
    "explanation": [
      "The relationship is between an activity and the typical place where it is performed. One goes to a GYM to EXERCISE, and one goes to a RESTAURANT to EAT."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 90,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12232,
        "content": [
          "Dieting"
        ],
        "isCorrect": false
      },
      {
        "id": 12233,
        "content": [
          "Food"
        ],
        "isCorrect": false
      },
      {
        "id": 12234,
        "content": [
          "Restaurant"
        ],
        "isCorrect": true
      },
      {
        "id": 12235,
        "content": [
          "Drink"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3057,
    "content": [
      "Choose the word that correctly completes the analogy.",
      "---",
      "The EVENING is to MORNING as DINNER is to:"
    ],
    "explanation": [
      "The analogy relates a time of day to the main meal eaten during that time. DINNER is the meal for the EVENING, and BREAKFAST is the meal for the MORNING."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 90,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12236,
        "content": [
          "Breakfast"
        ],
        "isCorrect": true
      },
      {
        "id": 12237,
        "content": [
          "Supper"
        ],
        "isCorrect": false
      },
      {
        "id": 12238,
        "content": [
          "Brunch"
        ],
        "isCorrect": false
      },
      {
        "id": 12239,
        "content": [
          "Lunch"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3058,
    "content": [
      "Choose the word that correctly completes the analogy.",
      "---",
      "GUN is to BULLET as a BOW is to:"
    ],
    "explanation": [
      "The relationship is between a weapon and its projectile. A GUN shoots a BULLET, and a BOW shoots an ARROW."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 90,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12240,
        "content": [
          "Wood"
        ],
        "isCorrect": false
      },
      {
        "id": 12241,
        "content": [
          "Arrow"
        ],
        "isCorrect": true
      },
      {
        "id": 12242,
        "content": [
          "Sky"
        ],
        "isCorrect": false
      },
      {
        "id": 12243,
        "content": [
          "Fly"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3059,
    "content": [
      "Choose the word that correctly completes the analogy.",
      "---",
      "PEN is to POET as NEEDLE is to:"
    ],
    "explanation": [
      "The relationship is between a tool and the professional who uses it. A POET uses a PEN, and a TAILOR uses a NEEDLE."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 90,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12244,
        "content": [
          "Button"
        ],
        "isCorrect": false
      },
      {
        "id": 12245,
        "content": [
          "Thread"
        ],
        "isCorrect": false
      },
      {
        "id": 12246,
        "content": [
          "Tailor"
        ],
        "isCorrect": true
      },
      {
        "id": 12247,
        "content": [
          "Sewing"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3060,
    "content": [
      "Choose the word that correctly completes the analogy.",
      "---",
      "PLAY is to ACTOR as CONCERT is to:"
    ],
    "explanation": [
      "The relationship is between a performance and the performer. An ACTOR performs in a PLAY, and a MUSICIAN performs in a CONCERT."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 90,
    "groupIndex": 5,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12248,
        "content": [
          "Musician"
        ],
        "isCorrect": true
      },
      {
        "id": 12249,
        "content": [
          "Symphony"
        ],
        "isCorrect": false
      },
      {
        "id": 12250,
        "content": [
          "Persuasion"
        ],
        "isCorrect": false
      },
      {
        "id": 12251,
        "content": [
          "Piano"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3066,
    "content": [
      "Choose the word that is most nearly similar in meaning to the bolded and capitalized word.",
      "---",
      "The special TV report **DISRUPTED** regular programming due to the day's special events."
    ],
    "explanation": [
      "To \"disrupt\" something means to interrupt an event, activity, or process by causing a disturbance or problem. \"Interrupted\" is the closest synonym."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 92,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12272,
        "content": [
          "Complemented"
        ],
        "isCorrect": false
      },
      {
        "id": 12273,
        "content": [
          "Satisfied"
        ],
        "isCorrect": false
      },
      {
        "id": 12274,
        "content": [
          "Continued"
        ],
        "isCorrect": false
      },
      {
        "id": 12275,
        "content": [
          "Interrupted"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3067,
    "content": [
      "Choose the word that is most nearly similar in meaning to the bolded and capitalized word.",
      "---",
      "He **DISSIPATED** his inheritance in less than six months and he is now back to where he was."
    ],
    "explanation": [
      "To \"dissipate\" resources like money means to squander or waste them away. \"Wasted\" is the most direct synonym."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 92,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12276,
        "content": [
          "Accumulated"
        ],
        "isCorrect": false
      },
      {
        "id": 12277,
        "content": [
          "Wasted"
        ],
        "isCorrect": true
      },
      {
        "id": 12278,
        "content": [
          "Hoarded"
        ],
        "isCorrect": false
      },
      {
        "id": 12279,
        "content": [
          "Saved"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3068,
    "content": [
      "Choose the word that is most nearly similar in meaning to the bolded and capitalized word.",
      "---",
      "If enough members of parliament **DISSENT**, the new law will not be approved."
    ],
    "explanation": [
      "To \"dissent\" means to hold or express opinions that are different from those commonly or officially held. \"Disagree\" is the best synonym."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 92,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12280,
        "content": [
          "Support"
        ],
        "isCorrect": false
      },
      {
        "id": 12281,
        "content": [
          "Agree"
        ],
        "isCorrect": false
      },
      {
        "id": 12282,
        "content": [
          "Disagree"
        ],
        "isCorrect": true
      },
      {
        "id": 12283,
        "content": [
          "Question"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3069,
    "content": [
      "Choose the word that is most nearly similar in meaning to the bolded and capitalized word.",
      "---",
      "During the riot, some of the demonstrators **LOOTED** shops and supermarkets and took the goods to their home."
    ],
    "explanation": [
      "\"Looted\" means to steal goods from a place, typically during a riot or war. \"Robbed\" is the most fitting synonym in this context."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 92,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12284,
        "content": [
          "wasted"
        ],
        "isCorrect": false
      },
      {
        "id": 12285,
        "content": [
          "robbed"
        ],
        "isCorrect": true
      },
      {
        "id": 12286,
        "content": [
          "shot"
        ],
        "isCorrect": false
      },
      {
        "id": 12287,
        "content": [
          "burned"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3226,
    "content": [
      "Read each of the following pair of words written in capital letter carefully and choose the word that correctly has a similar relationship with the given word.",
      "---",
      "AUTOMOBILE: GARAGE:: Hanger"
    ],
    "explanation": [
      "The relationship is that an AUTOMOBILE is stored or housed in a GARAGE. Similarly, an Airplane is stored or housed in a hangar."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 112,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12912,
        "content": [
          "Deck"
        ],
        "isCorrect": false
      },
      {
        "id": 12913,
        "content": [
          "Truck"
        ],
        "isCorrect": false
      },
      {
        "id": 12914,
        "content": [
          "Train"
        ],
        "isCorrect": false
      },
      {
        "id": 12915,
        "content": [
          "Airplane"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3227,
    "content": [
      "Read each of the following pair of words written in capital letter carefully and choose the word that correctly has a similar relationship with the given word.",
      "---",
      "KEY: LOCK:: Computer"
    ],
    "explanation": [
      "A KEY is used to gain access to or unlock a LOCK. Similarly, a Password is used to gain access to or unlock a Computer."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 112,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12916,
        "content": [
          "Server"
        ],
        "isCorrect": false
      },
      {
        "id": 12917,
        "content": [
          "Screen"
        ],
        "isCorrect": false
      },
      {
        "id": 12918,
        "content": [
          "Monitor"
        ],
        "isCorrect": false
      },
      {
        "id": 12919,
        "content": [
          "Password"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3228,
    "content": [
      "Read each of the following pair of words written in capital letter carefully and choose the word that correctly has a similar relationship with the given word.",
      "---",
      "NEST: BIRD:: Lion"
    ],
    "explanation": [
      "A NEST is the home or dwelling of a BIRD. Similarly, a Den is the home or dwelling of a Lion."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 112,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12920,
        "content": [
          "Backyard"
        ],
        "isCorrect": false
      },
      {
        "id": 12921,
        "content": [
          "Den"
        ],
        "isCorrect": true
      },
      {
        "id": 12922,
        "content": [
          "Hive"
        ],
        "isCorrect": false
      },
      {
        "id": 12923,
        "content": [
          "Cave"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3229,
    "content": [
      "Read each of the following pair of words written in capital letter carefully and choose the word that correctly has a similar relationship with the given word.",
      "---",
      "PHYSICIAN: HOSPITAL:: School"
    ],
    "explanation": [
      "A PHYSICIAN is a professional who works in a HOSPITAL. Similarly, a Teacher is a professional who works in a School."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 112,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12924,
        "content": [
          "Administrator"
        ],
        "isCorrect": false
      },
      {
        "id": 12925,
        "content": [
          "Student"
        ],
        "isCorrect": false
      },
      {
        "id": 12926,
        "content": [
          "Supervisor"
        ],
        "isCorrect": false
      },
      {
        "id": 12927,
        "content": [
          "Teacher"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3230,
    "content": [
      "Choose the word that is most nearly similar in meaning to the word in capital.",
      "---",
      "PHONEY"
    ],
    "explanation": [
      "The word \"phoney\" means not genuine or fraudulent. \"Fake\" is the closest synonym."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 113,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12928,
        "content": [
          "Fake"
        ],
        "isCorrect": true
      },
      {
        "id": 12929,
        "content": [
          "Funny"
        ],
        "isCorrect": false
      },
      {
        "id": 12930,
        "content": [
          "Genuine"
        ],
        "isCorrect": false
      },
      {
        "id": 12931,
        "content": [
          "Authentic"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3231,
    "content": [
      "Choose the word that is most nearly similar in meaning to the word in capital.",
      "---",
      "HUMOROUS"
    ],
    "explanation": [
      "The word \"humorous\" means causing laughter and amusement. \"Amusing\" is the best synonym."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 113,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12932,
        "content": [
          "Satiating"
        ],
        "isCorrect": false
      },
      {
        "id": 12933,
        "content": [
          "Satisfying"
        ],
        "isCorrect": false
      },
      {
        "id": 12934,
        "content": [
          "Amusing"
        ],
        "isCorrect": true
      },
      {
        "id": 12935,
        "content": [
          "Doubting"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3232,
    "content": [
      "Choose the word that is most nearly similar in meaning to the word in capital.",
      "---",
      "THEFT"
    ],
    "explanation": [
      "\"Theft\" is the act of stealing. \"Burglary,\" which is the illegal entry into a building to commit a theft, is the most similar term."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 113,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12936,
        "content": [
          "Burglary"
        ],
        "isCorrect": true
      },
      {
        "id": 12937,
        "content": [
          "Hypocrisy"
        ],
        "isCorrect": false
      },
      {
        "id": 12938,
        "content": [
          "Gossip"
        ],
        "isCorrect": false
      },
      {
        "id": 12939,
        "content": [
          "Suspicion"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3240,
    "content": [
      "Choose the word which could be interchangeably used with the bolded and capitalized word in the sentence.",
      "---",
      "The man was killed in a car accident. His **BODY** was dragged from the burning wreckage of his car."
    ],
    "explanation": [
      "In the context of a fatal accident, the word \"remains\" is a common and appropriate synonym for a dead \"body\"."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 116,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12968,
        "content": [
          "remains"
        ],
        "isCorrect": true
      },
      {
        "id": 12969,
        "content": [
          "fire"
        ],
        "isCorrect": false
      },
      {
        "id": 12970,
        "content": [
          "backseats"
        ],
        "isCorrect": false
      },
      {
        "id": 12971,
        "content": [
          "wheels"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3241,
    "content": [
      "Choose the word which could be interchangeably used with the bolded and capitalized word in the sentence.",
      "---",
      "Harvard is one of the most **PRESTIGIOUS** universities in the USA."
    ],
    "explanation": [
      "A \"prestigious\" institution is one that is respected and admired. Therefore, \"admired\" is the best substitute."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 116,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12972,
        "content": [
          "privileged"
        ],
        "isCorrect": false
      },
      {
        "id": 12973,
        "content": [
          "admired"
        ],
        "isCorrect": true
      },
      {
        "id": 12974,
        "content": [
          "furnished"
        ],
        "isCorrect": false
      },
      {
        "id": 12975,
        "content": [
          "expensive"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3242,
    "content": [
      "Choose the word which could be interchangeably used with the bolded and capitalized word in the sentence.",
      "---",
      "The government has just **REPEALED** the law segregating public facilities so that there will be no longer discrimination."
    ],
    "explanation": [
      "To \"repeal\" a law means to revoke or annul it officially. \"Cancelled\" is the closest synonym for this action."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 116,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12976,
        "content": [
          "approved"
        ],
        "isCorrect": false
      },
      {
        "id": 12977,
        "content": [
          "renewed"
        ],
        "isCorrect": false
      },
      {
        "id": 12978,
        "content": [
          "signed"
        ],
        "isCorrect": false
      },
      {
        "id": 12979,
        "content": [
          "cancelled"
        ],
        "isCorrect": true
      }
    ]
  }
];
export default questions;
