// StudentPrep Free Content — only the first 2 non-empty curriculum units/categories per grade/subject.
const questions = [
  {
    "id": 1677,
    "content": [
      "Which one of the following represents the increase in the quantity supplied of real GDP due to the increase in the price level?"
    ],
    "explanation": [
      "An increase in the price level, holding other factors constant, leads to an increase in the quantity of real GDP supplied in the short run.\n\nThis relationship is depicted as an upward movement along a given short-run aggregate supply (SRAS) curve.\n\nShifts in the aggregate supply curve are caused by factors other than the overall price level, such as changes in input prices, technology, or expectations."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_AGGREGATE_DEMAND_SUPPLY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6709,
        "content": [
          "The right wards shifts of the aggregate supply curve"
        ],
        "isCorrect": false
      },
      {
        "id": 6710,
        "content": [
          "The left wards shifts of the aggregate supply curve"
        ],
        "isCorrect": false
      },
      {
        "id": 6711,
        "content": [
          "The downwards movements along the aggregate supply curve"
        ],
        "isCorrect": false
      },
      {
        "id": 6712,
        "content": [
          "The upwards movements along the aggregate supply curve"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1678,
    "content": [
      "When the economy is in the long run, which of the following is correct?"
    ],
    "explanation": [
      "In the long run, the economy is assumed to operate at its potential output level, which corresponds to the natural rate of unemployment. This level of output is often referred to as full employment real GDP.\n\nIn the long run, wages and prices are fully flexible, and misperceptions are corrected, distinguishing it from the short run where stickiness and misperceptions can exist.\n\nTherefore, the defining characteristic of the long-run equilibrium is that the economy produces at the full employment (or natural) level of real GDP."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MACROECONOMIC_PRINCIPLES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6713,
        "content": [
          "Sticky wages and workers misperception still holds true."
        ],
        "isCorrect": false
      },
      {
        "id": 6714,
        "content": [
          "What the economy produces is the full employment real GDP."
        ],
        "isCorrect": true
      },
      {
        "id": 6715,
        "content": [
          "The short run and the long run real GDP will be the same."
        ],
        "isCorrect": false
      },
      {
        "id": 6716,
        "content": [
          "The level of real GDP the economy produces is less than the natural real GDP."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1679,
    "content": [
      "What is the pressure on price when the quantity demanded of real GDP is greater than the quantity supplied of real GDP during the short run?"
    ],
    "explanation": [
      "When the aggregate quantity demanded exceeds the aggregate quantity supplied at the current price level in the short run, there is excess demand (or a shortage) in the economy.\n\nThis situation puts upward pressure on the overall price level as buyers compete for the limited goods and services available, and producers may raise prices in response to strong demand."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_AGGREGATE_DEMAND_SUPPLY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6717,
        "content": [
          "The price level rises"
        ],
        "isCorrect": true
      },
      {
        "id": 6718,
        "content": [
          "The price level drops"
        ],
        "isCorrect": false
      },
      {
        "id": 6719,
        "content": [
          "No pressure at all"
        ],
        "isCorrect": false
      },
      {
        "id": 6720,
        "content": [
          "Initially downwards"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1680,
    "content": [
      "Which one of the following is correct about the economy when it is in long run equilibrium?"
    ],
    "explanation": [
      "Long-run equilibrium occurs when the aggregate demand curve (AD), the short-run aggregate supply curve (SRAS), and the long-run aggregate supply curve (LRAS) all intersect at the same point.\n\nThe LRAS curve is vertical at the natural level of real GDP (also known as potential output or full-employment output). Therefore, in long-run equilibrium, the economy produces its natural level of real GDP."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MACROECONOMIC_PRINCIPLES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6721,
        "content": [
          "The economy produces the real GDP which is called the natural real GDP."
        ],
        "isCorrect": true
      },
      {
        "id": 6722,
        "content": [
          "The short run aggregate demand curve intersects the short run aggregate supply curve."
        ],
        "isCorrect": false
      },
      {
        "id": 6723,
        "content": [
          "The long run aggregate demand curve intersects the short run aggregate supply curve."
        ],
        "isCorrect": false
      },
      {
        "id": 6724,
        "content": [
          "Price temporarily deviates from equilibrium even if aggregate demand and aggregate supply remain unchanged."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1681,
    "content": [
      "Which of the following represents an economic situation where there is an inefficient distribution of goods and services in the free market?"
    ],
    "explanation": [
      "Market failure is the general term used to describe situations where the free market, left to itself, fails to allocate resources efficiently.\n\nThis inefficiency can manifest as an overproduction, underproduction, or inequitable distribution of goods and services.\n\nExternalities, asymmetric information, public goods (which lead to free-riding), and market power are all specific causes or examples of market failure.\n\nTherefore, \"market failure\" is the broad category representing the inefficient outcome described."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MICROECONOMIC_THEORY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6725,
        "content": [
          "Externalities"
        ],
        "isCorrect": false
      },
      {
        "id": 6726,
        "content": [
          "Asymmetric information"
        ],
        "isCorrect": false
      },
      {
        "id": 6727,
        "content": [
          "Market failure"
        ],
        "isCorrect": true
      },
      {
        "id": 6728,
        "content": [
          "Free riding"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1682,
    "content": [
      "What impacts on our aggregate demand do you expect if the level of economic activities in other countries increase?"
    ],
    "explanation": [
      "An increase in the level of economic activities (like income and production) in other countries typically leads to an increase in their demand for goods and services, including imports.\n\nIf \"our\" country exports goods and services to these countries, then an increase in foreign economic activity will lead to an increase in demand for our exports.\n\nSince net exports (Exports - Imports) are a component of aggregate demand (AD), an increase in exports will increase our aggregate demand, shifting the AD curve to the right."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_AGGREGATE_DEMAND_SUPPLY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6729,
        "content": [
          "Aggregate demand will increase."
        ],
        "isCorrect": true
      },
      {
        "id": 6730,
        "content": [
          "Aggregate demand will decrease."
        ],
        "isCorrect": false
      },
      {
        "id": 6731,
        "content": [
          "Aggregate demand remains unaffected."
        ],
        "isCorrect": false
      },
      {
        "id": 6732,
        "content": [
          "Aggregate demand first declines and then rises."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1683,
    "content": [
      "Among the following, which one differentiates change in quantity demanded from change in aggregate demand?"
    ],
    "explanation": [
      "A change in the quantity of real GDP demanded results from a change in the overall price level and is represented by a movement along a given aggregate demand (AD) curve, *ceteris paribus* (all else being equal).\n\nCorrect option describes exactly this: a change in the price level causing a change in the quantity demanded along the curve. In contrast, a change in aggregate demand is caused by changes in non-price determinants (like consumer confidence, investment, government spending, net exports) and results in a shift of the entire AD curve (as described in options C and D).\n\nCorrect option uniquely describes the phenomenon associated with a \"change in quantity demanded.\""
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_AGGREGATE_DEMAND_SUPPLY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6733,
        "content": [
          "As the price level falls, the quantity demanded of real GDP rises, ceteris paribus."
        ],
        "isCorrect": true
      },
      {
        "id": 6734,
        "content": [
          "It is represented as a movement from one point to another along different demand curve."
        ],
        "isCorrect": false
      },
      {
        "id": 6735,
        "content": [
          "A positive change in any factors causes a rightward shift in the AD curve."
        ],
        "isCorrect": false
      },
      {
        "id": 6736,
        "content": [
          "It is a shift in aggregate demand curve from AD1 to AD2 on different curve."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1684,
    "content": [
      "Which of the following is correct about aggregate demand curve?"
    ],
    "explanation": [
      "The aggregate demand (AD) curve illustrates the relationship between the overall price level in an economy and the total quantity of goods and services (real GDP) that all buyers (households, firms, government, and foreign sector) are willing and able to purchase, holding other factors constant (*ceteris paribus*).\n\nThis relationship is inverse: as the price level falls, the quantity of real GDP demanded increases, and vice versa.\n\nOption C accurately describes this inverse relationship between the price level and the quantity of real output buyers desire to purchase.\n\nOptions B and D describe the aggregate supply curve.\n\nOption A incorrectly relates real GDP demanded to only consumption expenditure instead of the overall price level."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_AGGREGATE_DEMAND_SUPPLY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6737,
        "content": [
          "It represents the inverse relationship between the real GDP demanded and consumption expenditure, all else being equal."
        ],
        "isCorrect": false
      },
      {
        "id": 6738,
        "content": [
          "It is a schedule that represents the amount of real output that sellers collectively desire to sell at each price, ceteris paribus."
        ],
        "isCorrect": false
      },
      {
        "id": 6739,
        "content": [
          "It shows the inverse relationship between the amount of real output buyers desire to buy at each price, all else being equal."
        ],
        "isCorrect": true
      },
      {
        "id": 6740,
        "content": [
          "It shows the inverse relationship between the amount of real output sellers desire to sell at each price, all else being equal."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1685,
    "content": [
      "What is the implication of the Keynesian horizontal aggregate supply curve?"
    ],
    "explanation": [
      "The Keynesian range of the aggregate supply curve is horizontal (or nearly so) at low levels of output, far below potential GDP.\n\nThis flatness implies that there are significant unemployed resources (labor, capital) in the economy.\n\nConsequently, firms can increase their production levels in response to increased demand without needing to raise prices, as they can hire idle labor and utilize unused capacity at the prevailing wage and input price levels.\n\nOption A correctly states this implication: firms can meet the demand at the existing price level due to the presence of unemployment and idle resources."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_AGGREGATE_DEMAND_SUPPLY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6741,
        "content": [
          "Firms can supply whatever amount demanded at the existing price because of unemployment."
        ],
        "isCorrect": true
      },
      {
        "id": 6742,
        "content": [
          "Firms can obtain much labour as they want as long as they pay more."
        ],
        "isCorrect": false
      },
      {
        "id": 6743,
        "content": [
          "As output level changes, the average cost of production increases."
        ],
        "isCorrect": false
      },
      {
        "id": 6744,
        "content": [
          "The labour market is in equilibrium with full employment of the labour force."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1686,
    "content": [
      "Which one of the following is the main factor that affects the amount of output firms are willing to supply?"
    ],
    "explanation": [
      "The law of supply states that, ceteris paribus, the quantity of a good supplied by firms increases as the price they receive for that good increases.\n\nWhile other factors (like input costs, technology, expectations, and prices of related goods) can shift the entire supply curve, the primary factor determining the specific quantity supplied at any given moment along the supply curve is the current market price of the good itself."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MICROECONOMIC_THEORY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6745,
        "content": [
          "The price of related goods produced by other firms"
        ],
        "isCorrect": false
      },
      {
        "id": 6746,
        "content": [
          "The price they receive for their goods"
        ],
        "isCorrect": true
      },
      {
        "id": 6747,
        "content": [
          "The level of economic activity in other countries"
        ],
        "isCorrect": false
      },
      {
        "id": 6748,
        "content": [
          "The price they anticipate to prevail in the future"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1687,
    "content": [
      "Which of the following is NOT the cause of market failure?"
    ],
    "explanation": [
      "Market failure occurs when the free market fails to allocate resources efficiently.\n\nCommon causes include externalities (costs or benefits imposed on third parties), market power (like monopolies), information asymmetries, public goods, and factor immobility.\n\nPrivate goods, characterized by rivalry and excludability, are typically allocated efficiently by markets.\n\nTherefore, the existence of private goods is not considered a cause of market failure; rather, market failure often arises with goods that deviate from these private good characteristics."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MICROECONOMIC_THEORY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6749,
        "content": [
          "Monopoly"
        ],
        "isCorrect": false
      },
      {
        "id": 6750,
        "content": [
          "Externalities"
        ],
        "isCorrect": false
      },
      {
        "id": 6751,
        "content": [
          "Factor immobility"
        ],
        "isCorrect": false
      },
      {
        "id": 6752,
        "content": [
          "Private goods"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1688,
    "content": [
      "Suppose Sol-ech company receives positive externalities from COMP educated graduates subsidize computer education through scholarships. Which of the following group is this type of solution for market failure listed?"
    ],
    "explanation": [
      "The scenario describes a private company (Sol-ech) taking action (providing scholarships) to address a positive externality (benefits from educated graduates).\n\nSince this action is undertaken by a private entity without government mandate, it falls under the category of private market solutions to externalities.\n\nThese solutions aim to internalize the externality through private negotiation or action, like the Coase theorem or, as in this case, private subsidies."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MICROECONOMIC_THEORY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6753,
        "content": [
          "Voluntary collective action solutions"
        ],
        "isCorrect": false
      },
      {
        "id": 6754,
        "content": [
          "Government-imposed solutions"
        ],
        "isCorrect": false
      },
      {
        "id": 6755,
        "content": [
          "Private market solutions"
        ],
        "isCorrect": true
      },
      {
        "id": 6756,
        "content": [
          "Non-excludability"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1689,
    "content": [
      "Which one of the following is an example of public goods?"
    ],
    "explanation": [
      "Public goods are characterized by non-rivalry (one person's use does not diminish another's ability to use it) and non-excludability (it is difficult or impossible to prevent people from using the good, even if they don't pay).\n\nHouses, food, and clothes are rivalrous and excludable (private goods). Wilderness areas or national parks often exhibit characteristics of public goods; one person enjoying the view doesn't prevent others (non-rivalrous, up to congestion points), and excluding non-payers can be difficult (non-excludable)."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MICROECONOMIC_THEORY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6757,
        "content": [
          "Houses"
        ],
        "isCorrect": false
      },
      {
        "id": 6758,
        "content": [
          "Food items"
        ],
        "isCorrect": false
      },
      {
        "id": 6759,
        "content": [
          "Wilderness"
        ],
        "isCorrect": true
      },
      {
        "id": 6760,
        "content": [
          "Clothes"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1690,
    "content": [
      "Which of the following characterize Public goods?"
    ],
    "explanation": [
      "Public goods are defined by two key characteristics: non-rivalry in consumption (meaning one person's consumption of the good does not reduce the amount available for others) and non-excludability (meaning it is costly or impossible to prevent individuals who do not pay for the good from consuming it).\n\nOption D correctly identifies these two defining features."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MICROECONOMIC_THEORY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6761,
        "content": [
          "Rivalry and excludability"
        ],
        "isCorrect": false
      },
      {
        "id": 6762,
        "content": [
          "Rivalry and non-excludability"
        ],
        "isCorrect": false
      },
      {
        "id": 6763,
        "content": [
          "Non-rivalry and excludability"
        ],
        "isCorrect": false
      },
      {
        "id": 6764,
        "content": [
          "Non-rivalry and non-excludability"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1691,
    "content": [
      "Which one of the following factor is the reason for market inefficiency in the provision of public goods?"
    ],
    "explanation": [
      "Public goods are non-excludable, meaning it's impossible or very costly to prevent anyone from consuming the good, even if they don't pay.\n\nThis leads to the free-rider problem, where individuals have an incentive to use the good without contributing to its provision.\n\nConsequently, private markets tend to under-supply public goods, leading to market inefficiency."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MICROECONOMIC_THEORY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6765,
        "content": [
          "Externality"
        ],
        "isCorrect": false
      },
      {
        "id": 6766,
        "content": [
          "Free riding"
        ],
        "isCorrect": true
      },
      {
        "id": 6767,
        "content": [
          "Divisibility"
        ],
        "isCorrect": false
      },
      {
        "id": 6768,
        "content": [
          "High marginal cost"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1696,
    "content": [
      "Which of the following exchange rate regime is the one that is determined by the government political and economic decisions?"
    ],
    "explanation": [
      "A fixed exchange rate regime is directly determined by government policy.\n\nThe government or central bank sets a specific value for its currency against another currency (or a basket of currencies or gold) and commits to intervening in the foreign exchange market to maintain that rate.\n\nThis requires active political and economic decisions regarding the target rate and the means to defend it. Floating rates are market-determined, while managed floating and crawling pegs involve some government intervention but are not solely fixed by government decree."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_TRADE_GLOBAL_ECONOMY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6785,
        "content": [
          "Floating exchange rate regime"
        ],
        "isCorrect": false
      },
      {
        "id": 6786,
        "content": [
          "Fixed exchange rate regime"
        ],
        "isCorrect": true
      },
      {
        "id": 6787,
        "content": [
          "Managed floating"
        ],
        "isCorrect": false
      },
      {
        "id": 6788,
        "content": [
          "Crawling peg regime"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1697,
    "content": [
      "Which one of the following difference is the cause for efficiency loss in the presence of negative externality?"
    ],
    "explanation": [
      "A negative externality occurs when the production or consumption of a good imposes a cost on third parties.\n\nThis means the cost to society (marginal social cost, MSC) is greater than the cost incurred by the producer/consumer (marginal private cost, MPC).\n\nThe difference is the marginal external cost (MSC = MPC + MEC). Market equilibrium typically occurs where marginal private benefit equals marginal private cost (MPB=MPC).\n\nHowever, social efficiency requires marginal social benefit to equal marginal social cost (MSB=MSC).\n\nBecause MSC > MPC in the presence of a negative externality, the market outcome results in overproduction compared to the socially efficient level, leading to an efficiency loss (deadweight loss).\n\nThis loss arises directly from the divergence between social and private costs."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MICROECONOMIC_THEORY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6789,
        "content": [
          "Between marginal social benefit and marginal private benefit"
        ],
        "isCorrect": false
      },
      {
        "id": 6790,
        "content": [
          "Between marginal social cost and marginal private cost"
        ],
        "isCorrect": true
      },
      {
        "id": 6791,
        "content": [
          "Between private marginal cost and marginal external cost"
        ],
        "isCorrect": false
      },
      {
        "id": 6792,
        "content": [
          "Between private marginal benefit and marginal external benefit"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1698,
    "content": [
      "When an insurance company provides fringe benefits on the basis of an average rate over a set of employees and guarantee them to participate in the program, then this can be seen as a solution for which one of the following problem?"
    ],
    "explanation": [
      "Adverse selection in insurance occurs when individuals with higher risks are more likely to purchase insurance, while those with lower risks may not, leading to a pool of insured individuals that is riskier than the general population.\n\nBy insuring an entire group (like all employees of a company) and guaranteeing participation, the insurance company gets a mix of high-risk and low-risk individuals, reflecting the group's average risk rather than just attracting the high-risk ones.\n\nThis pooling mechanism effectively mitigates the adverse selection problem."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MICROECONOMIC_THEORY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6793,
        "content": [
          "Adverse selection"
        ],
        "isCorrect": true
      },
      {
        "id": 6794,
        "content": [
          "Moral hazard"
        ],
        "isCorrect": false
      },
      {
        "id": 6795,
        "content": [
          "Signalling"
        ],
        "isCorrect": false
      },
      {
        "id": 6796,
        "content": [
          "Screening"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1700,
    "content": [
      "Which one of the following is the monetary policy tool that involves the purchase and sale of securities by the nation's central bank?"
    ],
    "explanation": [
      "Open market operations (OMOs) refer to the central bank's practice of buying and selling government securities (like bonds) in the open financial market.\n\nBuying securities injects money into the banking system, increasing the money supply, while selling securities withdraws money, decreasing the money supply.\n\nThis is a primary tool used to control the money supply and influence short-term interest rates. Government spending is part of fiscal policy."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MONEY_BANKING_FINANCE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6801,
        "content": [
          "Discount rate"
        ],
        "isCorrect": false
      },
      {
        "id": 6802,
        "content": [
          "Open market operation"
        ],
        "isCorrect": true
      },
      {
        "id": 6803,
        "content": [
          "Required reserve ratio"
        ],
        "isCorrect": false
      },
      {
        "id": 6804,
        "content": [
          "Government spending"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1702,
    "content": [
      "Which one of the following is correct about price ceilings?"
    ],
    "explanation": [
      "A price ceiling is a government-imposed legal maximum price that can be charged for a good or service. It is typically implemented to make essential items more affordable, especially for low-income consumers.\n\nTo be effective (binding), a price ceiling must be set below the market equilibrium price."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_GOVERNMENT_INTERVENTION",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6809,
        "content": [
          "It is one of the income policies that keeps a price from declining from certain limit."
        ],
        "isCorrect": false
      },
      {
        "id": 6810,
        "content": [
          "It is a maximum price set by law to make basic consumption goods affordable to buyers."
        ],
        "isCorrect": true
      },
      {
        "id": 6811,
        "content": [
          "It should be set above the equilibrium price to make it more effective."
        ],
        "isCorrect": false
      },
      {
        "id": 6812,
        "content": [
          "It discourages consumers from buying goods and services since they are now paying higher price."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1703,
    "content": [
      "Suppose the value of an Ethiopian birr in terms of Kenyan Shilling is getting higher. What is the impact of this on the Ethiopian export to Kenya?"
    ],
    "explanation": [
      "If the value of the Ethiopian birr increases relative to the Kenyan shilling (birr appreciates), it means that one birr can buy more shillings.\n\nConsequently, Ethiopian goods become more expensive for Kenyans (they need more shillings to buy the same amount of birr-priced goods).\n\nThis higher price will likely reduce the quantity demanded of Ethiopian exports by Kenyans, leading to a reduction in Ethiopia's total export earnings from Kenya, assuming demand is somewhat elastic."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_TRADE_GLOBAL_ECONOMY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6813,
        "content": [
          "It will make the price of Ethiopian goods in the Kenyan market cheaper."
        ],
        "isCorrect": false
      },
      {
        "id": 6814,
        "content": [
          "It will make the price of Kenyan import in the Ethiopian market expensive."
        ],
        "isCorrect": false
      },
      {
        "id": 6815,
        "content": [
          "It will increase Ethiopia's export earnings."
        ],
        "isCorrect": false
      },
      {
        "id": 6816,
        "content": [
          "It will reduce Ethiopia's export earnings."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1704,
    "content": [
      "Which one of the following clearly defines taxation?"
    ],
    "explanation": [
      "Taxation is a compulsory levy imposed by a government authority on individuals or entities.\n\nWhile taxes fund public services, the payment of tax by an individual does not entitle them to a specific, directly corresponding benefit or service in return (no direct quid pro quo). This differentiates taxes from fees or charges for specific services.\n\nTaxes are not voluntary, usually not the *only* source of revenue, and fund government existence, not encourage its inexistence."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_FUNDAMENTALS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6817,
        "content": [
          "It is a voluntary payment."
        ],
        "isCorrect": false
      },
      {
        "id": 6818,
        "content": [
          "It is the only source of government revenue."
        ],
        "isCorrect": false
      },
      {
        "id": 6819,
        "content": [
          "It is levied without anything in direct return."
        ],
        "isCorrect": true
      },
      {
        "id": 6820,
        "content": [
          "It encourages inexistence of government."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1705,
    "content": [
      "Which one of the following explains the tax principles called \"canon of economy\"?"
    ],
    "explanation": [
      "The \"canon of economy,\" one of Adam Smith's principles of good taxation, states that the cost of collecting a tax should be kept to a minimum relative to the amount of revenue it generates. It emphasizes administrative efficiency in the tax system."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_GOVERNMENT_INTERVENTION",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6821,
        "content": [
          "Everyone should pay tax according to his ability"
        ],
        "isCorrect": false
      },
      {
        "id": 6822,
        "content": [
          "The amount of tax that we are supposed to pay should be known in advance."
        ],
        "isCorrect": false
      },
      {
        "id": 6823,
        "content": [
          "Every tax payer should pay the tax in his own convenient time."
        ],
        "isCorrect": false
      },
      {
        "id": 6824,
        "content": [
          "The cost of tax collection should be as minimum as possible."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1706,
    "content": [
      "Which of the following is the implication of one of a good tax system that is referred to as broad based?"
    ],
    "explanation": [
      "A broad-based tax system is one that levies taxes on a wide range of economic activities or bases, such as income, property, and consumption (commodities).\n\nBy spreading the tax burden across multiple areas, it can potentially raise significant revenue with lower rates on each base compared to a narrow-based system."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_GOVERNMENT_INTERVENTION",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6825,
        "content": [
          "The system should impose tax on all people without discrimination."
        ],
        "isCorrect": false
      },
      {
        "id": 6826,
        "content": [
          "The system should ensure that an income inequality is reduced."
        ],
        "isCorrect": false
      },
      {
        "id": 6827,
        "content": [
          "The system should impose tax on income and properties and commodities."
        ],
        "isCorrect": true
      },
      {
        "id": 6828,
        "content": [
          "The system should ascertain that national income and living standard is increasing."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1707,
    "content": [
      "Which one of the following is the advantage of fiscal decentralization?"
    ],
    "explanation": [
      "Fiscal decentralization transfers some fiscal powers (spending, and sometimes taxing) from the central government to sub-national levels (regional, local).\n\nA primary advantage is that local governments are often better positioned to understand and respond to the specific needs and preferences of their residents, leading to the provision of public goods and services that are more closely aligned with local desires."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_GOVERNMENT_INTERVENTION",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6829,
        "content": [
          "Provide scale economies in the collection of taxes"
        ],
        "isCorrect": false
      },
      {
        "id": 6830,
        "content": [
          "Provide scale economies in the provision of public goods"
        ],
        "isCorrect": false
      },
      {
        "id": 6831,
        "content": [
          "Provision of public goods and services desired by local residents."
        ],
        "isCorrect": true
      },
      {
        "id": 6832,
        "content": [
          "Effective to implement equity measures."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1708,
    "content": [
      "One of the following is considered to be the aim of fiscal decentralization. Which one is it?"
    ],
    "explanation": [
      "Fiscal decentralization often aims to improve both efficiency and equity in the public sector.\n\nEfficiency can be enhanced by tailoring services to local needs and increasing accountability.\n\nEquity can potentially be improved by allowing local governments to address specific local inequalities, although the actual equity outcomes can be complex and depend on the design of the decentralization."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_GOVERNMENT_INTERVENTION",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6833,
        "content": [
          "Promoting regional partnership"
        ],
        "isCorrect": false
      },
      {
        "id": 6834,
        "content": [
          "Enhancing the role of private sector"
        ],
        "isCorrect": false
      },
      {
        "id": 6835,
        "content": [
          "Encouraging free movement of labour"
        ],
        "isCorrect": false
      },
      {
        "id": 6836,
        "content": [
          "Ensuring equity and efficiency"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1709,
    "content": [
      "Which one of the following is the reason for the federal government to make fiscal equalization payments to local governments?"
    ],
    "explanation": [
      "Fiscal equalization payments are transfers from a central government to sub-national (state, provincial, local) governments designed to offset differences in revenue-raising capacity or the cost of providing services.\n\nThe primary goal is to ensure that citizens receive comparable levels of public services across different regions, regardless of the wealth or tax base of their specific locality, thereby narrowing regional gaps."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_GOVERNMENT_INTERVENTION",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6837,
        "content": [
          "To enhance intergovernmental competition"
        ],
        "isCorrect": false
      },
      {
        "id": 6838,
        "content": [
          "To discourage fiscal centralization"
        ],
        "isCorrect": false
      },
      {
        "id": 6839,
        "content": [
          "To encourage innovation in those goods and services provided locally"
        ],
        "isCorrect": false
      },
      {
        "id": 6840,
        "content": [
          "To narrow regional gaps in the provision of basic public services"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1712,
    "content": [
      "Among the following direct taxes, which one is a tax that is imposed on the land and buildings?"
    ],
    "explanation": [
      "Property tax is a direct tax levied on the ownership of real property, which includes land and buildings.\n\nThe tax amount is typically based on the assessed value of the property.\n\nIncome tax is on earnings, transfer tax on specific transactions, and capital gains tax on profits from asset sales."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_GOVERNMENT_INTERVENTION",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6849,
        "content": [
          "Income tax"
        ],
        "isCorrect": false
      },
      {
        "id": 6850,
        "content": [
          "Property tax"
        ],
        "isCorrect": true
      },
      {
        "id": 6851,
        "content": [
          "Transfer tax"
        ],
        "isCorrect": false
      },
      {
        "id": 6852,
        "content": [
          "Capital gain tax"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1713,
    "content": [
      "Which one of the following is an objective of taxation?"
    ],
    "explanation": [
      "Besides raising revenue, taxation is often used to achieve social and economic objectives. One key objective, particularly through progressive tax systems (where higher incomes are taxed at higher rates), is to redistribute income and reduce income disparity within a society.\n\nTaxes are usually used to discourage, not promote, consumption of harmful products, reduce, not widen, regional imbalances, and often discourage, not encourage, imports through tariffs."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_GOVERNMENT_INTERVENTION",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6853,
        "content": [
          "Reducing income disparity"
        ],
        "isCorrect": true
      },
      {
        "id": 6854,
        "content": [
          "Promoting consumption of harmful products"
        ],
        "isCorrect": false
      },
      {
        "id": 6855,
        "content": [
          "Widening regional imbalance"
        ],
        "isCorrect": false
      },
      {
        "id": 6856,
        "content": [
          "Encouraging import"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1714,
    "content": [
      "The burden and incidence is imposed by one of the following tax categories on different individuals. Which one is it?"
    ],
    "explanation": [
      "Value Added Tax (VAT) is a consumption tax. While collected at various stages of production, the ultimate economic burden (incidence) typically falls on the final consumer.\n\nSince consumption patterns vary greatly among individuals based on income and preferences, the burden of VAT is spread across many different individuals in society, impacting them differently relative to their consumption levels."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_GOVERNMENT_INTERVENTION",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6857,
        "content": [
          "Payroll tax"
        ],
        "isCorrect": false
      },
      {
        "id": 6858,
        "content": [
          "Corporate income tax"
        ],
        "isCorrect": false
      },
      {
        "id": 6859,
        "content": [
          "Value added tax"
        ],
        "isCorrect": true
      },
      {
        "id": 6860,
        "content": [
          "Rental income tax"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1716,
    "content": [
      "Which one is the type of indirect tax imposed on luxury items and other goods that are demand inelastic when the goods is imported?"
    ],
    "explanation": [
      "Excise taxes are levied on specific goods, often those considered luxuries (like cars, perfumes) or goods with negative externalities (like alcohol, tobacco) or goods with inelastic demand where the tax burden can be easily passed on.\n\nThey can be applied to both domestically produced and imported goods. VAT is a broad consumption tax, not specific to luxury/inelastic items."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_GOVERNMENT_INTERVENTION",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6865,
        "content": [
          "Value added tax"
        ],
        "isCorrect": false
      },
      {
        "id": 6866,
        "content": [
          "Turnover tax"
        ],
        "isCorrect": false
      },
      {
        "id": 6867,
        "content": [
          "Excise tax"
        ],
        "isCorrect": true
      },
      {
        "id": 6868,
        "content": [
          "Withholding tax"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1720,
    "content": [
      "The effort that poor developing economies exerts to bring growth and development is jeopardized due to"
    ],
    "explanation": [
      "Developing countries often face significant challenges in addressing climate change due to limited financial, technological, and institutional capacities.\n\nThe absence of robust mechanisms for both mitigation (reducing greenhouse gas emissions) and adaptation (adjusting to current and future climate impacts) makes their economies and development progress highly vulnerable to the adverse effects of climate change, thus jeopardizing growth efforts."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_ECONOMIC_GROWTH_DEVELOPMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6881,
        "content": [
          "lack of support for adaptation from the developed countries."
        ],
        "isCorrect": false
      },
      {
        "id": 6882,
        "content": [
          "allocation of a good proportion of their budget to finance adaptation."
        ],
        "isCorrect": false
      },
      {
        "id": 6883,
        "content": [
          "high dependence on climate insensitive resources."
        ],
        "isCorrect": false
      },
      {
        "id": 6884,
        "content": [
          "absence of mitigation and adaptation mechanisms."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1727,
    "content": [
      "Which of the following indicates the rank of Ethiopia in its human development despite the effort made to reduce the headcount poverty over the past twenty years?"
    ],
    "explanation": [
      "Despite significant progress in reducing poverty (lowering the headcount ratio and poverty gap) and improvements in health and education over the past two decades, Ethiopia's overall Human Development Index (HDI) score and ranking remain in the lower tier globally.\n\nThe HDI provides a composite measure of human development, and Ethiopia consistently ranked in the \"Low human development\" category by the UNDP during much of this period, reflecting that challenges remain across multiple dimensions beyond just income poverty."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_ECONOMIC_GROWTH_DEVELOPMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6909,
        "content": [
          "Low human development index"
        ],
        "isCorrect": true
      },
      {
        "id": 6910,
        "content": [
          "Low Gini coefficient"
        ],
        "isCorrect": false
      },
      {
        "id": 6911,
        "content": [
          "Low poverty gap"
        ],
        "isCorrect": false
      },
      {
        "id": 6912,
        "content": [
          "Low headcount ratio"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1732,
    "content": [
      "What does the Gini coefficient of 1 represent?"
    ],
    "explanation": [
      "The Gini coefficient measures income or wealth inequality within a population, ranging from 0 to 1.\n\nA Gini coefficient of 0 signifies perfect equality (everyone has the same income/wealth).\n\nConversely, a Gini coefficient of 1 represents perfect inequality, a theoretical extreme where a single individual holds all the income or wealth, and everyone else has zero."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_FUNDAMENTALS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6929,
        "content": [
          "Perfect equality of income"
        ],
        "isCorrect": false
      },
      {
        "id": 6930,
        "content": [
          "Moderate inequality of income"
        ],
        "isCorrect": false
      },
      {
        "id": 6931,
        "content": [
          "Moderate equality of income"
        ],
        "isCorrect": false
      },
      {
        "id": 6932,
        "content": [
          "All income owned by one person"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1733,
    "content": [
      "Which one of the following country has made great success in lifting millions of people out of poverty in the past three decades?"
    ],
    "explanation": [
      "China's economic reforms and rapid industrialization since the late 1970s have resulted in sustained high economic growth, lifting hundreds of millions of its citizens out of extreme poverty, a feat unparalleled in recent history."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_ECONOMIC_GROWTH_DEVELOPMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6933,
        "content": [
          "Brazil"
        ],
        "isCorrect": false
      },
      {
        "id": 6934,
        "content": [
          "Russia"
        ],
        "isCorrect": false
      },
      {
        "id": 6935,
        "content": [
          "China"
        ],
        "isCorrect": true
      },
      {
        "id": 6936,
        "content": [
          "Ethiopia"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1734,
    "content": [
      "What is the reason for extreme poverty to remain a challenge in Sub Saharan African countries?"
    ],
    "explanation": [
      "While multiple factors contribute to poverty, a significant challenge in many Sub-Saharan African countries is the lack of comprehensive, effectively implemented, and sustained growth and development plans.\n\nSuch plans are crucial for addressing structural issues, promoting diversification, creating jobs, and building infrastructure needed for long-term poverty reduction."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_ECONOMIC_GROWTH_DEVELOPMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6937,
        "content": [
          "Existence of efficient institutions"
        ],
        "isCorrect": false
      },
      {
        "id": 6938,
        "content": [
          "Absence of mitigation policies"
        ],
        "isCorrect": false
      },
      {
        "id": 6939,
        "content": [
          "Lack of growth and development plans"
        ],
        "isCorrect": true
      },
      {
        "id": 6940,
        "content": [
          "Lack of using indigenous knowledge"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1735,
    "content": [
      "What is the reason for women to experience extreme poverty in the developing world?"
    ],
    "explanation": [
      "Limited control over household resources and income, including income generated by spouses or even their own activities, restricts women's economic agency and decision-making power.\n\nThis lack of control makes it harder for women to invest, save, or manage resources effectively, contributing significantly to their vulnerability to poverty in many developing contexts."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_ECONOMIC_GROWTH_DEVELOPMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6941,
        "content": [
          "Dominance of male-headed households"
        ],
        "isCorrect": false
      },
      {
        "id": 6942,
        "content": [
          "The earning capacity of women is high"
        ],
        "isCorrect": false
      },
      {
        "id": 6943,
        "content": [
          "Their control over their spouses' income is limited."
        ],
        "isCorrect": true
      },
      {
        "id": 6944,
        "content": [
          "Their access to the formal sector employment is high."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1736,
    "content": [
      "Which one of the following is among the measures that should **not** be considered to alleviate the problem of poverty facing women?"
    ],
    "explanation": [
      "Discouraging women's participation in agricultural extension programs would be counterproductive to poverty alleviation efforts.\n\nIn many developing economies, agriculture is a key source of livelihood for women, and extension programs provide vital information, training, and resources to improve productivity and income. Therefore, encouraging, not discouraging, participation is a necessary measure."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_ECONOMIC_GROWTH_DEVELOPMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6945,
        "content": [
          "Adoption of policy that integrates women in various programs and influences their welfare"
        ],
        "isCorrect": false
      },
      {
        "id": 6946,
        "content": [
          "Increasing female participation in education and other training programs"
        ],
        "isCorrect": false
      },
      {
        "id": 6947,
        "content": [
          "Enhancing female participation in formal sector employment"
        ],
        "isCorrect": false
      },
      {
        "id": 6948,
        "content": [
          "Discouraging women activity in agricultural extension programmes"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1737,
    "content": [
      "Which one of the following expresses the classical view?"
    ],
    "explanation": [
      "The classical view in economics posits that economies possess strong self-correcting mechanisms, primarily through flexible wages and prices.\n\nThis flexibility ensures that any deviations from full employment are temporary, and the economy naturally tends to return to its potential output level where all resources, including labor, are fully employed."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MACROECONOMIC_PRINCIPLES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6949,
        "content": [
          "The economy will move towards full employment of GDP."
        ],
        "isCorrect": true
      },
      {
        "id": 6950,
        "content": [
          "Expansionary fiscal or monetary policy is necessary."
        ],
        "isCorrect": false
      },
      {
        "id": 6951,
        "content": [
          "Demand side policies only affect the real wage, employment and output."
        ],
        "isCorrect": false
      },
      {
        "id": 6952,
        "content": [
          "Monetary policy has effects on the real sphere of the economy."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1738,
    "content": [
      "What is the important lesson the world has learnt from the 1930's Great Depression?"
    ],
    "explanation": [
      "The severity and prolonged nature of the Great Depression demonstrated that economies might not self-correct quickly or effectively from major downturns.\n\nIt highlighted the potential for significant and persistent gaps between actual and potential GDP, leading to widespread unemployment.\n\nThis experience spurred the development of Keynesian economics, which emphasized the need for active government intervention through fiscal and monetary policies (stabilization policies) to manage aggregate demand and mitigate economic fluctuations."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MACROECONOMIC_PRINCIPLES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6953,
        "content": [
          "The self-correcting feature of the market works"
        ],
        "isCorrect": false
      },
      {
        "id": 6954,
        "content": [
          "The additional government spending will stimulate unemployment."
        ],
        "isCorrect": false
      },
      {
        "id": 6955,
        "content": [
          "The possibility of real GDP to fall below the potential GDP is nil."
        ],
        "isCorrect": false
      },
      {
        "id": 6956,
        "content": [
          "The importance of active stabilization policies"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1740,
    "content": [
      "Which one of the following is the component of aggregate demand that includes private purchases of structures, equipment's and accumulation of inventories?"
    ],
    "explanation": [
      "Aggregate demand (AD) represents the total demand for goods and services in an economy.\n\nIt is composed of Consumption (C), Investment (I), Government Purchases (G), and Net Exports (NX).\n\nInvestment (I), specifically Gross Private Domestic Investment, includes spending by businesses on fixed assets like structures (factories, offices) and equipment (machinery, computers), residential construction, and changes in business inventories (accumulation or depletion of unsold goods)."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_AGGREGATE_DEMAND_SUPPLY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6961,
        "content": [
          "Consumption"
        ],
        "isCorrect": false
      },
      {
        "id": 6962,
        "content": [
          "Investment"
        ],
        "isCorrect": true
      },
      {
        "id": 6963,
        "content": [
          "Government Purchases"
        ],
        "isCorrect": false
      },
      {
        "id": 6964,
        "content": [
          "Net Exports"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1741,
    "content": [
      "In macroeconomics, the current consumption expenditure is likely increase due to"
    ],
    "explanation": [
      "According to theories like the Permanent Income Hypothesis and the Life-Cycle Hypothesis, individuals base their current consumption decisions not just on current income but also on their expectations of future income.\n\nIf people expect their income to be higher in the future, they feel wealthier and are more likely to increase their consumption spending today, smoothing consumption over their lifetime."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MACROECONOMIC_PRINCIPLES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6965,
        "content": [
          "expectation of lower price in the future."
        ],
        "isCorrect": false
      },
      {
        "id": 6966,
        "content": [
          "increase in income tax."
        ],
        "isCorrect": false
      },
      {
        "id": 6967,
        "content": [
          "increase in interest rate."
        ],
        "isCorrect": false
      },
      {
        "id": 6968,
        "content": [
          "expectation of higher future income."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1742,
    "content": [
      "Which one of the following is a branch of economics that studies about the aggregate behavior of the economy?"
    ],
    "explanation": [
      "Macroeconomics is the branch of economics concerned with the performance, structure, behavior, and decision-making of an economy as a whole.\n\nIt focuses on aggregate changes in the economy such as unemployment, growth rate, gross domestic product, and inflation."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_FUNDAMENTALS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6969,
        "content": [
          "Microeconomics"
        ],
        "isCorrect": false
      },
      {
        "id": 6970,
        "content": [
          "Macroeconomics"
        ],
        "isCorrect": true
      },
      {
        "id": 6971,
        "content": [
          "International economics"
        ],
        "isCorrect": false
      },
      {
        "id": 6972,
        "content": [
          "Development economics"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1743,
    "content": [
      "Among the following, which one is a macroeconomic issue?"
    ],
    "explanation": [
      "Macroeconomics deals with economy-wide phenomena. Issues concerning the overall structure (e.g., national output composition) and performance (e.g., GDP growth, inflation, unemployment) of the entire economy fall under the purview of macroeconomics, distinguishing it from microeconomics which focuses on individual units and markets."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_FUNDAMENTALS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6973,
        "content": [
          "Actions of an individual agent within an economy"
        ],
        "isCorrect": false
      },
      {
        "id": 6974,
        "content": [
          "The economic activities of a consumer, a producer or industry"
        ],
        "isCorrect": false
      },
      {
        "id": 6975,
        "content": [
          "Resource allocation or price determination as central problem"
        ],
        "isCorrect": false
      },
      {
        "id": 6976,
        "content": [
          "Structure and performance of the economy as a whole"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1744,
    "content": [
      "Which of the following is used to calculate GDP by adding all the incomes accruing to all factors of production used in producing the national output?"
    ],
    "explanation": [
      "The income approach calculates Gross Domestic Product (GDP) by summing all the incomes earned by households and firms in the country during a period.\n\nThis includes wages and salaries, profits, rent, and interest earned by the factors of production (labor, capital, land, entrepreneurship)."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MACROECONOMIC_PRINCIPLES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6977,
        "content": [
          "Product approach"
        ],
        "isCorrect": false
      },
      {
        "id": 6978,
        "content": [
          "Expenditure approach"
        ],
        "isCorrect": false
      },
      {
        "id": 6979,
        "content": [
          "Income approach"
        ],
        "isCorrect": true
      },
      {
        "id": 6980,
        "content": [
          "Value added approach"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1745,
    "content": [
      "Which one of the following characterizes period of expansion in the business cycle?"
    ],
    "explanation": [
      "During an economic expansion, aggregate demand increases, leading to higher production and employment.\n\nAs the economy approaches its potential output, resources become scarcer, and the increased demand puts upward pressure on the price level, leading to inflation or accelerating inflation. While unemployment falls and growth is positive (not slowing down), and full employment might be reached near the peak, rising price pressure is a characteristic feature of the expansion phase itself."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MACROECONOMIC_PRINCIPLES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6981,
        "content": [
          "Unemployment rises at this stage."
        ],
        "isCorrect": false
      },
      {
        "id": 6982,
        "content": [
          "The pressure on prices is upward."
        ],
        "isCorrect": true
      },
      {
        "id": 6983,
        "content": [
          "Economic growth slows down."
        ],
        "isCorrect": false
      },
      {
        "id": 6984,
        "content": [
          "Full employment occurs at this stage."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1746,
    "content": [
      "In which of the following is the market values of country's exports and imports of goods and services are shown?"
    ],
    "explanation": [
      "The current account is a component of the balance of payments that records a country's transactions with the rest of the world, specifically its net trade in goods and services, its net earnings on cross-border investments (primary income), and its net transfer payments (secondary income).\n\nExports and imports of goods and services are the primary components recorded here."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_TRADE_GLOBAL_ECONOMY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6985,
        "content": [
          "Capital account"
        ],
        "isCorrect": false
      },
      {
        "id": 6986,
        "content": [
          "Terms of trade"
        ],
        "isCorrect": false
      },
      {
        "id": 6987,
        "content": [
          "Current account"
        ],
        "isCorrect": true
      },
      {
        "id": 6988,
        "content": [
          "Budget surplus"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1747,
    "content": [
      "Which one of the following is the problem of taxation in Ethiopia that is considered to be legal from the point of view of law but poses problems on the tax administration?"
    ],
    "explanation": [
      "Tax avoidance involves using legal methods and interpretations of the tax code to reduce the amount of tax owed.\n\nWhile technically legal, complex avoidance strategies can exploit loopholes, undermine the fairness of the tax system, reduce government revenue significantly, and create challenges for tax authorities in terms of monitoring and ensuring the spirit of the law is followed."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_GOVERNMENT_INTERVENTION",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6989,
        "content": [
          "Tax evasion"
        ],
        "isCorrect": false
      },
      {
        "id": 6990,
        "content": [
          "Tax avoidance"
        ],
        "isCorrect": true
      },
      {
        "id": 6991,
        "content": [
          "Tax compliance"
        ],
        "isCorrect": false
      },
      {
        "id": 6992,
        "content": [
          "Unreported transaction"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1748,
    "content": [
      "What remedial solutions do you think should be put in place to alleviate tax collection problem in Ethiopia?"
    ],
    "explanation": [
      "Implementing a broad-based tax system typically involves widening the tax net (taxing more types of income or consumption) while potentially lowering rates and minimizing exemptions and deductions.\n\nThis approach simplifies the tax code, reduces loopholes for avoidance, makes the system potentially fairer, and can improve the efficiency and effectiveness of tax collection by making it harder to evade taxes and less complex to administer."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_GOVERNMENT_INTERVENTION",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6993,
        "content": [
          "Provide client oriented service to tax payers"
        ],
        "isCorrect": false
      },
      {
        "id": 6994,
        "content": [
          "Lowering the tax rate far below the current rate"
        ],
        "isCorrect": false
      },
      {
        "id": 6995,
        "content": [
          "Following broad based tax system"
        ],
        "isCorrect": true
      },
      {
        "id": 6996,
        "content": [
          "Adopting expansionary fiscal policy"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1749,
    "content": [
      "The World Bank defines poverty as \"the pronounced deprivation in wellbeing\". Which one of the following is NOT the implication of wellbeing?"
    ],
    "explanation": [
      "The concept of \"wellbeing\" used in defining poverty is multidimensional, encompassing not just income or consumption but also health, education, security, empowerment, and capabilities (the ability to function and achieve desired states of being).\n\nStating that poverty is *only* about the lack of food is a very narrow definition that ignores these other critical dimensions captured by the broader concept of wellbeing."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_ECONOMIC_GROWTH_DEVELOPMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6997,
        "content": [
          "The poor are those who do not have any control over commodities."
        ],
        "isCorrect": false
      },
      {
        "id": 6998,
        "content": [
          "It relates poverty with some specific types of consumption."
        ],
        "isCorrect": false
      },
      {
        "id": 6999,
        "content": [
          "It relates to lack of key capability to function in the society."
        ],
        "isCorrect": false
      },
      {
        "id": 7000,
        "content": [
          "Poverty is only about the lack of one thing, food."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1750,
    "content": [
      "Which one of the following is a Uni-dimensional measure of poverty that helps to understand the degree of income inequality among the poor?"
    ],
    "explanation": [
      "The Foster-Greer-Thorbecke (FGT) class of poverty measures allows for different sensitivities to the depth and severity of poverty.\n\nSpecifically, the FGT index with parameter α=2 (the squared poverty gap index) is sensitive to inequality among the poor because it gives greater weight to individuals who are further below the poverty line.\n\nWhile uni-dimensional (usually based on income or consumption), it captures the severity of poverty, which inherently reflects inequality among those below the poverty line."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_ECONOMIC_GROWTH_DEVELOPMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7001,
        "content": [
          "Total poverty gap"
        ],
        "isCorrect": false
      },
      {
        "id": 7002,
        "content": [
          "The Foster – Greer – Thorbecke Index"
        ],
        "isCorrect": true
      },
      {
        "id": 7003,
        "content": [
          "Multidimensional poverty index"
        ],
        "isCorrect": false
      },
      {
        "id": 7004,
        "content": [
          "Poverty headcount ratio"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1751,
    "content": [
      "One of the following shows the proportion of total national income that factors of production receives. Which one is it?"
    ],
    "explanation": [
      "The functional distribution of income explains how national income is divided among the different factors of production – typically labor (wages), capital (interest and profits), and land (rent).\n\nIt focuses on the income shares received by these functional inputs in the production process."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MACROECONOMIC_PRINCIPLES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7005,
        "content": [
          "Personal distribution of income"
        ],
        "isCorrect": false
      },
      {
        "id": 7006,
        "content": [
          "Size distribution of income"
        ],
        "isCorrect": false
      },
      {
        "id": 7007,
        "content": [
          "Functional distribution of income"
        ],
        "isCorrect": true
      },
      {
        "id": 7008,
        "content": [
          "Income distribution"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1752,
    "content": [
      "Consider a hypothetical economy in which a consumer buys 2kg of apples and 5kg of oranges at the price of birr 150 and 70 per kilogram respectively in 2016 E.C. If in 2015 E.C. the prices of these two goods, apple and orange, were birr 125 and 55 per kilogram respectively, then what is the rate of inflation during the year 2016 E.C. assuming that 2015 E.C. is base year?"
    ],
    "explanation": [
      "To calculate the inflation rate (IF) using a fixed basket, we first find the cost of the basket in each year.\n\nCost in 2015 E.C. (Base Year) = $$(2 \\text{ kg} \\times 125 \\text{ birr/kg})$$ + $$(5 \\text{ kg} \\times 55 \\text{ birr/kg})$$ = $$525 \\text{ birr}$$\n\nCost in 2016 E.C. = $$(2 \\text{ kg} \\times 150 \\text{ birr/kg})$$ + $$(5 \\text{ kg} \\times 70 \\text{ birr/kg})$$ = $$650 \\text{ birr}$$\n$$\n\\text{IF}= \\frac{\\text{Cost in 2016} - \\text{Cost in 2015}}{\\text{Cost in 2015}} \\times 100\\%\n$$\n$$\n\\text{IF} = \\frac{650 - 525}{525} \\times 100\\%\n$$\n$$\n\\text{IF} = 23.80\\%\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MACROECONOMIC_PRINCIPLES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7009,
        "content": [
          "$$10.28\\%$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7010,
        "content": [
          "$$17.65\\%$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7011,
        "content": [
          "$$23.80\\%$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7012,
        "content": [
          "$$21.33\\%$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1753,
    "content": [
      "Suppose that the nominal wage that the firm has agreed to pay for worker is birr 60 per hour. What is the change in the real wage rate if the price level as measured by the price index increases from 2.50 to 3.00?"
    ],
    "explanation": [
      "The real wage is calculated by dividing the nominal wage by the price level index.\n$$\n\\text{Initial Real Wage} = \\frac{\\text{Nominal Wage}}{\\text{Initial Price Index}}\n$$\n$$\n= \\frac{60}{2.50} = 24 \\text{ birr}\n$$\n$$\n\\text{Final Real Wage} = \\frac{\\text{Nominal Wage}}{\\text{Final Price Index}}\n$$\n$$\n= \\frac{60}{3.00} = 20 \\text{ birr}\n$$\nChange in Real Wage = Final Real Wage - Initial Real Wage = 20 - 24 = -4  birr.\n\nTherefore, the real wage declined by 4 birr."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MACROECONOMIC_PRINCIPLES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7013,
        "content": [
          "The real wage rises by 4 birr."
        ],
        "isCorrect": false
      },
      {
        "id": 7014,
        "content": [
          "The real wage declined by 4 birr."
        ],
        "isCorrect": true
      },
      {
        "id": 7015,
        "content": [
          "The real wage declined by 6 birr."
        ],
        "isCorrect": false
      },
      {
        "id": 7016,
        "content": [
          "The real wage rises by 6 birr."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1755,
    "content": [
      "Suppose in a given economy the population who are willing and able to work is 5 million and out of this the total number of employed are 2 million. What is the unemployment rate?"
    ],
    "explanation": [
      "The labor force consists of those willing and able to work (employed + unemployed), which is given as 5 million. The number employed is 2 million. Therefore, the number unemployed is\n\nLabor Force - Employed = 5 million - 2 million = 3 million.\n\nThe unemployment rate is calculated as (Number Unemployed / Labor Force) X 100%.\n\nUnemployment Rate = (3 million / 5 million) X 100% = 0.6 X 100% = 60%."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MACROECONOMIC_PRINCIPLES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7021,
        "content": [
          "40%"
        ],
        "isCorrect": false
      },
      {
        "id": 7022,
        "content": [
          "70%"
        ],
        "isCorrect": false
      },
      {
        "id": 7023,
        "content": [
          "30%"
        ],
        "isCorrect": false
      },
      {
        "id": 7024,
        "content": [
          "60%"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1756,
    "content": [
      "A census that was conducted in a particular economy shows that the total adult population is 27 million and those who are willing and able to work is 6 million. What is the labour force participation rate in this economy?"
    ],
    "explanation": [
      "The labor force participation rate is the percentage of the total adult population that is in the labor force (i.e., willing and able to work, either employed or actively seeking employment).\n\nLabor Force Participation Rate = (Labor Force / Total Adult Population) x 100%.\n\nRate = (6 million / 27 million) x 100% = (6/27) X 100% ≈ 0.2222 x 100% = 22.22%."
    ],
    "year": "YEAR_2016",
    "subject": "ECONOMICS",
    "chapter": "ECO_MACROECONOMIC_PRINCIPLES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7025,
        "content": [
          "12.18%"
        ],
        "isCorrect": false
      },
      {
        "id": 7026,
        "content": [
          "15.73%"
        ],
        "isCorrect": false
      },
      {
        "id": 7027,
        "content": [
          "22.22%"
        ],
        "isCorrect": true
      },
      {
        "id": 7028,
        "content": [
          "25.37%"
        ],
        "isCorrect": false
      }
    ]
  }
];
export default questions;
