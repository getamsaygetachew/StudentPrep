// StudentPrep Free Content — guide-selected units, maximum 25 questions per unit.
const questions = [
  {
    "id": 306,
    "content": [
      "What is the acceleration due to gravity at an altitude twice the radius of the Earth? ($$g_E$$ is the gravitational acceleration on the surface of the Earth)."
    ],
    "explanation": [
      "The formula for gravitational acceleration at a distance (r) from the center of a planet is given by:\n\n$$\ng_r = \\frac{g_E}{\\left( \\frac{r}{R_E} \\right)^2}\n$$\n\nwhere:\n\n- $$g_E$$ is the gravitational acceleration at the Earth's surface,\n- $$R_E$$ is the radius of the Earth,\n- r is the distance from the center of the Earth.\n\nAt an altitude twice the radius of the Earth, the distance from the center of the Earth is:\n\n$$\nr = 2R_E + R_E = 3R_E\n$$\n\nNow, using the formula for gravitational acceleration:\n$$\ng_r = \\frac{g_E}{(3)^2} = \\frac{g_E}{9}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1221,
        "content": [
          "$$\\frac{g_E}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1222,
        "content": [
          "$$\\frac{g_E}{9}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1223,
        "content": [
          "$$3 \\ g_E$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1224,
        "content": [
          "$$\\frac{g_E}{4}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Uniformly Accelerated Motion"
  },
  {
    "id": 309,
    "content": [
      "A solenoid with 5000 turns and length 1m carries 15A of current. If no iron core is inserted in the solenoid, what is the magnetic field strength at the center of the solenoid?"
    ],
    "explanation": [
      "The formula for the magnetic field of a solenoid is:\n$$\nB = \\mu_0 \\cdot \\frac{N}{L} \\cdot I\n$$\n\nWhere:\n- $$\\mu_0 = 4\\pi \\times 10^{-7} \\, T \\cdot m / A$$ (permeability of free space)\n- N = 5000\n- L = 1 m\n- I = 15 A\n\n$$\nB = (4\\pi \\times 10^{-7}) \\cdot \\frac{5000}{1} \\cdot 15\n$$\n$$\nB = 4\\pi \\times 10^{-7} \\cdot 75000 = 3\\pi \\times 10^{-2} \\, T\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1233,
        "content": [
          "$$20 \\pi \\times 10^{-2} \\ \\text{T}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1234,
        "content": [
          "$$3 \\pi \\times 10^{-2} \\ \\text{T}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1235,
        "content": [
          "$$6 \\pi \\times 10^{-2} \\ \\text{T}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1236,
        "content": [
          "$$4 \\pi \\times 10^{-2} \\ \\text{T}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 311,
    "content": [
      "A fluid travelling over an objects surface exerts less pressure than if the fluid was static. This is a statement of"
    ],
    "explanation": [
      "Bernoulli's principle states that as the speed of a fluid increases, the pressure within the fluid decreases. This principle is often used to explain how airplanes fly: the shape of an airplane wing causes air to move faster over the top of the wing than the bottom, which creates a difference in pressure that lifts the plane."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_PRESSURE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1241,
        "content": [
          "Bernoulli's principle."
        ],
        "isCorrect": true
      },
      {
        "id": 1242,
        "content": [
          "principle of continuity."
        ],
        "isCorrect": false
      },
      {
        "id": 1243,
        "content": [
          "Pascal's principle."
        ],
        "isCorrect": false
      },
      {
        "id": 1244,
        "content": [
          "Archimedes' principle."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 316,
    "content": [
      "Water flows at the rate of $$500.0 \\ \\text{cm}^3/ \\text{s}$$ at small cross-section $$5 \\ \\text{cm}^2$$. The larger cross-section is $$25 \\ \\text{cm}^2$$. What is the ratio of the speed of the water at $$A_1$$ to $$A_2$$.",
      "images/physics/year_2015/q16_1.png"
    ],
    "explanation": [
      "The flow rate (Q) of water is given by:\n\n$$\nQ = A \\times v\n$$\n\nSince the flow rate remains constant, we can apply the continuity equation:\n$$\nA_1 \\times v_1 = A_2 \\times v_2\n$$\n\nWe are asked to find the ratio $$\\frac{v_1}{v_2}$$\n\nRearranging the continuity equation to find the ratio:\n\n$$\n\\frac{v_1}{v_2} = \\frac{A_2}{A_1}\n$$\n\n$$\n\\frac{v_1}{v_2} = \\frac{25 \\, \\text{cm}^2}{5 \\, \\text{cm}^2} = 5\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2015/q16_1.png"
    ],
    "choices": [
      {
        "id": 1261,
        "content": [
          "5"
        ],
        "isCorrect": true
      },
      {
        "id": 1262,
        "content": [
          "100"
        ],
        "isCorrect": false
      },
      {
        "id": 1263,
        "content": [
          "0.2"
        ],
        "isCorrect": false
      },
      {
        "id": 1264,
        "content": [
          "20"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 318,
    "content": [
      "Consider a particle performing a circular motion around a circle of radius r, with an angular velocity ω and the particle's projection on the horizontal diameter of the circle (between points Q and R) as shown in the figure below?",
      "images/physics/year_2015/q18_1.png",
      "Which one of the following statements is correct about the motion of the particle and its projection on $$\\overline{QR}$$"
    ],
    "explanation": [
      "The projection of a particle in uniform circular motion exhibits simple harmonic motion because it oscillates around an equilibrium position (the midpoint of $$\\overline{QR}$$) with maximum displacement at points Q and R. The motion is sinusoidal in nature, where the displacement of the projection from the center varies with time as $$x(t) = r \\cos(\\omega t)$$ demonstrating the characteristics of simple harmonic motion."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2015/q18_1.png"
    ],
    "choices": [
      {
        "id": 1269,
        "content": [
          "The projection of the particle on $$\\overline{QR}$$ swings between points Q and R with constant speed."
        ],
        "isCorrect": false
      },
      {
        "id": 1270,
        "content": [
          "The circular motion of the particle can be taken as a simple harmonic motion."
        ],
        "isCorrect": false
      },
      {
        "id": 1271,
        "content": [
          "The projection of the particle on $$\\overline{QR}$$ demonstrates simple harmonic motion."
        ],
        "isCorrect": true
      },
      {
        "id": 1272,
        "content": [
          "The projection of the particle on $$\\overline{QR}$$ demonstrates motion with constant acceleration."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 324,
    "content": [
      "A boy in a journey covers his route by travelling 3.0 km east and 4.0 km north. What is the magnitude of his resultant displacement?"
    ],
    "explanation": [
      "We can use the Pythagorean theorem. The boy's journey forms a right-angled triangle with the legs being 3.0 km and 4.0 km.\n$$\n\\sqrt{(3.0 \\ km)^2 + (4.0 \\ km)^2} = 5.0 km\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1293,
        "content": [
          "5.0 km"
        ],
        "isCorrect": true
      },
      {
        "id": 1294,
        "content": [
          "1.0 km"
        ],
        "isCorrect": false
      },
      {
        "id": 1295,
        "content": [
          "7.0 km"
        ],
        "isCorrect": false
      },
      {
        "id": 1296,
        "content": [
          "2.7 km"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 325,
    "content": [
      "The graph given below shows the velocity of a man travelling on a motorcycle as a function of time.",
      "images/physics/year_2015/q25_1.png",
      "Which one of the following statements is correct about the velocity-time graph?"
    ],
    "explanation": [
      "- **Displacement from t = 0 to t = 6 s**: This is the area under the graph in this interval, which is a rectangle. The area (displacement) is $$\\text{velocity} \\times \\text{time} = 120 \\text{m}$$.\n- **Displacement from t = 6 s to t = 14 s**: This is the sum of the areas of regions II and III. Both regions are above the time axis, so their areas add up to give the total displacement.\n- **Acceleration from t = 6 s to t = 10 s**: This is the gradient (slope) of the line in this interval. Since the velocity increases, the gradient is positive.\n- **Acceleration in the first 6 s**: The velocity is constant, so the gradient (acceleration) is zero.\n\nSo the correct statement is: **The displacement during the time intervals t = 0 to t = 6 s is equal to the area under the velocity-time graph in the given interval.**"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2015/q25_1.png"
    ],
    "choices": [
      {
        "id": 1297,
        "content": [
          "The displacement during the time interval from t = 6 s to t = 14 s is equal to the area of region II minus the area of region III."
        ],
        "isCorrect": false
      },
      {
        "id": 1298,
        "content": [
          "The displacement during the time intervals t = 0 to t = 6 s is equal to the area under the velocity-time graph in the given interval."
        ],
        "isCorrect": true
      },
      {
        "id": 1299,
        "content": [
          "The acceleration during the time interval from t = 6 s to t = 10 s is equal to the gradient of the curve in the given interval and it is negative."
        ],
        "isCorrect": false
      },
      {
        "id": 1300,
        "content": [
          "The acceleration in the first 6 s is equal to the gradient of the curve in the given interval and it is positive."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 329,
    "content": [
      "A wooden block of volume $$5.00 \\times 10^{-4} \\ m^3$$ floats partially submerged in water, and a small steel object of mass m is placed on top of the block. When m = 0.25 kg, the system is in equilibrium and the top of the wooden block is at the level of the water. What is the density of the wood?"
    ],
    "explanation": [
      "When the system is in equilibrium, the buoyant force acting on the wooden block is equal to the weight of the wooden block plus the weight of the steel object.\n\n$$\n\\rho_{water} \\cdot V_{block} \\cdot g = \\rho_{wood} \\cdot V_{block} \\cdot g + m_{steel} \\cdot g\n$$\n\nWe are given that $$V_{block}$$ = $$5.00 \\times 10^{-4} \\ m^3$$ and $$m_{steel}$$ =$$0.25 \\ kg$$.\n\nAdditionally, the density of water is $$\\rho_{water}$$ = $$1000 \\ kg \\cdot m^{-3}$$.\n\nSolving for $$\\rho_{wood}$$, we get:\n\n$$\n\\rho_{wood} = \\frac{0.25 \\ kg}{5.00 \\times 10^{-4} \\ m^3}= 500 \\ kg \\cdot m^{-3}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_DENSITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1313,
        "content": [
          "$$1000 \\ kg \\cdot m^{-3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1314,
        "content": [
          "$$1500 \\ kg \\cdot m^{-3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1315,
        "content": [
          "$$500 \\ kg \\cdot m^{-3}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1316,
        "content": [
          "$$800 \\ kg \\cdot m^{-3}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 337,
    "content": [
      "An electron moving with a speed of $$2.2 \\times 10^7 \\ \\text{m/s}$$ east enters in the region of magnetic field strength of $$5 \\times 10^{-4} \\ \\text{T}$$ directed north. What is the magnetic force experienced by the electron?"
    ],
    "explanation": [
      "$$\nF = qvB \\sin \\theta\n$$\n\nGiven:\n\n- q = $$-1.6 \\times 10^{-19} \\ \\text{C}$$\n- v = $$2.2 \\times 10^7 \\ \\text{m/s}$$\n- B = $$5 \\times 10^{-4} \\ \\text{T}$$\n- $$\\theta = 90^\\circ$$ (since velocity is east and magnetic field is north, they are perpendicular)\n\n$$\nF = (1.6 \\times 10^{-19} \\ \\text{C}) \\times (2.2 \\times 10^7 \\ \\text{m/s}) \\times (5 \\times 10^{-4} \\ \\text{T})\n$$\n\n$$\nF = 1.76 \\times 10^{-15} \\ \\text{N}\n$$\n\nThe direction of the force is perpendicular to both the velocity (east) and the magnetic field (north).\n\nSo, the correct answer is: $$1.76 \\times 10^{-15} \\ \\text{N}$$, perpendicular to north and east directions."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1345,
        "content": [
          "$$1.76 \\times 10^{-15} \\ \\text{N}$$, perpendicular to north and east directions."
        ],
        "isCorrect": true
      },
      {
        "id": 1346,
        "content": [
          "$$8 \\times 10^{-15} \\ \\text{N}$$, perpendicular to north and east directions."
        ],
        "isCorrect": false
      },
      {
        "id": 1347,
        "content": [
          "$$3.64 \\times 10^{-30} \\ \\text{N}$$, towards east direction"
        ],
        "isCorrect": false
      },
      {
        "id": 1348,
        "content": [
          "$$1.76 \\times 10^{-15} \\ \\text{N}$$, towards north direction."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 338,
    "content": [
      "A magnetic field intensity of $$4 \\times 10^{-4} \\ \\text{T}$$ crosses a coil having face area $$100 \\ \\text{cm}^2$$ and $$5 \\times 10^{4}$$ turns perpendicular to the face of the coil. If the magnetic flux in the coil set to zero within 2 ms. What is the magnitude of the induced emf in the coil?"
    ],
    "explanation": [
      "To find the induced emf, we use Faraday's Law of Induction:\n\n$$\n\\varepsilon = -N \\frac{\\Delta \\Phi}{\\Delta t}\n$$\n\nCalculate the initial magnetic flux:\n\n$$\n\\Phi = B \\cdot A\n$$\n\n$$\n\\Phi = 4 \\times 10^{-6} \\ \\text{Wb}\n$$\n\nChange in magnetic flux:\n\n$$\n\\Delta \\Phi = \\Phi - 0 = 4 \\times 10^{-6} \\ \\text{Wb}\n$$\n\nCalculate Induced emf:\n\n$$\n\\varepsilon = -5 \\times 10^4 \\frac{4 \\times 10^{-6} \\ \\text{Wb}}{2 \\times 10^{-3} \\ \\text{s}}\n$$\n\n$$\n\\varepsilon = -100 \\ \\text{V}\n$$\n\nThe magnitude of the induced emf is 100 V"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1349,
        "content": [
          "$$4\\times 10^{-4} \\ \\text{V}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1350,
        "content": [
          "$$100 \\ \\text{V}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1351,
        "content": [
          "$$10 \\ \\text{V}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1352,
        "content": [
          "$$2 \\times 10^{-5} \\ \\text{V}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 342,
    "content": [
      "Which one of the following groups of physical quantities contains only vectors?"
    ],
    "explanation": [
      "**Displacement**, **Velocity**, **Magnetic field**, and **Momentum** are all vector quantities because they have both magnitude and direction."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1365,
        "content": [
          "Work, Electric field, Displacement and Force"
        ],
        "isCorrect": false
      },
      {
        "id": 1366,
        "content": [
          "Acceleration, Speed, Force and Electric field"
        ],
        "isCorrect": false
      },
      {
        "id": 1367,
        "content": [
          "Momentum, Energy, Magnetic field and Force"
        ],
        "isCorrect": false
      },
      {
        "id": 1368,
        "content": [
          "Displacement, Velocity, Magnetic field and Momentum"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 343,
    "content": [
      "Which rule about the number of significant figures is correct? Zeros in the number"
    ],
    "explanation": [
      "- **450.0**: The trailing zero after the decimal point is significant.\n- **0.0023**: The leading zeros are not significant; only 2 and 3 are significant.\n- **1.1000**: All zeros after the decimal point are significant.\n- **2.70018**: All digits, including zeros, are significant."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1369,
        "content": [
          "450.0 are significant figures."
        ],
        "isCorrect": true
      },
      {
        "id": 1370,
        "content": [
          "0.0023 are significant figures."
        ],
        "isCorrect": false
      },
      {
        "id": 1371,
        "content": [
          "1.1000 are not significant figures."
        ],
        "isCorrect": false
      },
      {
        "id": 1372,
        "content": [
          "2.70018 are not significant figures."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 344,
    "content": [
      "Given two vectors $$v_1 = 10$$ units along the positive y-axis and $$v_2 = 6$$ units at an angle of 37° above the positive x-axis. What is the scalar product of the vectors in square of units?"
    ],
    "explanation": [
      "The scalar product (dot product) of two vectors is given by the formula:\n\n$$\nv_1 \\cdot v_2 = |v_1||v_2|\\cos(\\theta)\n$$\n\nWhere:\n\n- θ = 90° - 37° = 53° (the angle between the two vectors, since one is along the y-axis and the other is 37° above the x-axis).\n\nNow, calculate the dot product:\n$$\nv_1 \\cdot v_2 = 10 \\times 6 \\times \\cos(53^\\circ)\n$$\n$$\n\\cos(53^\\circ) \\approx 0.6\n$$\n$$\nv_1 \\cdot v_2 = 10 \\times 6 \\times 0.6 = 36\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1373,
        "content": [
          "45"
        ],
        "isCorrect": false
      },
      {
        "id": 1374,
        "content": [
          "36"
        ],
        "isCorrect": true
      },
      {
        "id": 1375,
        "content": [
          "48"
        ],
        "isCorrect": false
      },
      {
        "id": 1376,
        "content": [
          "60"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Vectors"
  },
  {
    "id": 345,
    "content": [
      "An airplane takes-off at airport A and travels 500 km due east within one hour and then turning to south it flies for 20 minutes to land on airport B which is 100 km away from the turning point. The magnitude average velocity of the plane during its flight between the two airports is"
    ],
    "explanation": [
      "The plane travels 500 km east and then 100 km south. The displacement is the straight-line distance between the starting and ending points, which can be found using the Pythagorean theorem:\n\n$$\n\\text{d} = \\sqrt{(500 \\ \\text{km})^2 + (100 \\ \\text{km})^2} = 100 \\sqrt{26} \\ \\text{km}\n$$\n\nThe plane travels 500 km in 1 hour and 100 km in 20 minutes (which is $$\\frac{1}{3}$$ hour.\n$$\nt_{total} = 1 \\ \\text{hr} + \\frac{1}{3} \\ \\text{hrs} = \\frac{4}{3} \\ \\text{hrs}\n$$\n\nAverage velocity is the total displacement divided by the total time:\n\n$$\nv_{avg} = \\frac{\\text{d}}{t_{total}}\n$$\n$$\nv_{avg} =\\frac{100 \\sqrt{26} \\ \\text{km}}{\\frac{4}{3} \\ \\text{hours}} = 75 \\sqrt{26} \\ \\text{km/h}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1377,
        "content": [
          "$$75 \\sqrt {24} \\ \\text{km/h}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1378,
        "content": [
          "$$100  \\sqrt {34} \\ \\text{km/h}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1379,
        "content": [
          "$$450 \\ \\text{km/h}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1380,
        "content": [
          "$$75 \\sqrt {26} \\ \\text{km/h}$$."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 346,
    "content": [
      "A bullet is fired with an initial speed v at an angle θ with the horizontal. It takes a time to reach its maximum vertical displacement $$h_{max}$$. It hits the target point a distance R away and exactly in the horizontal level to the point where it was fired. Which one of the following statement is NOT correct about the motion of the bullet?"
    ],
    "explanation": [
      "**Option 1:** The bullet hits the target at a time 2T after it was fired (**is correct**)\n\n- The total time of flight $$T_f$$ for projectile motion is given by:\n\n$$\nT_f = \\frac{2v \\sin \\theta}{g}\n$$\n\n- Since the bullet reaches its maximum height at time $$T = \\frac{v \\sin \\theta}{g}$$, the total time of flight is indeed 2T.\n\n**Option 2**: $$h_{max}$$ is directly proportional to the initial speed v (**is NOT correct**)\n\n- The maximum height $$h_{max}$$ is given by:\n\n$$\nh_{max} = \\frac{v^2 \\sin^2 \\theta}{2g}\n$$\n\n- This equation shows that $$h_{max}$$ is proportional to $$v^2$$, not v.\n\n**Option 3**: R will be maximum if $$\\cos \\theta = \\frac{\\sqrt{2}}{2}$$ (**is correct**)\n\n- The range R of the projectile is given by:\n\n$$\nR = \\frac{v^2 \\sin 2\\theta}{g}\n$$\n\n- For the range to be maximum, $$\\sin 2\\theta$$ must be maximized, which happens when $$2\\theta = 90^\\circ$$, or $$\\theta = 45^\\circ$$. At $$\\theta = 45^\\circ$$, $$\\cos \\theta$$ = $$\\frac{\\sqrt{2}}{2}$$.\n\n**Option 4**: θ should be different from 90° to hit the target at a distance R (**is correct**)\n\n- If θ = 90°, the bullet would only move vertically and fall back to the starting point. To hit the target at a distance R, θ must indeed be different from 90°."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1381,
        "content": [
          "The bullet hits the target at a time 2T after it was fired."
        ],
        "isCorrect": false
      },
      {
        "id": 1382,
        "content": [
          "$$h_{max}$$ is directly proportional to the initial speed v."
        ],
        "isCorrect": true
      },
      {
        "id": 1383,
        "content": [
          "R will be maximum if $$\\cos {\\theta}$$= $$\\sqrt{2}/2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1384,
        "content": [
          "θ should be different from 90° to hit the target at a distance R."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 353,
    "content": [
      "Which of the following statements distinguishes between random and systematic errors?"
    ],
    "explanation": [
      "Systematic errors cause measurements to be consistently off in one direction (always above or below the true value), while random errors cause measurements to vary unpredictably around the true value (sometimes above, sometimes below)."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1409,
        "content": [
          "Systematic error can be minimized by taking several readings and averaging; whereas random error cannot be minimized."
        ],
        "isCorrect": false
      },
      {
        "id": 1410,
        "content": [
          "Systematic error makes measured values to be always above or always below the true value; whereas random error causes measured values to be sometimes above and sometimes below the true value."
        ],
        "isCorrect": true
      },
      {
        "id": 1411,
        "content": [
          "Random error makes measured values to be always above or always below the true value; whereas systematic error causes measured values to be sometimes above and sometimes below the true value."
        ],
        "isCorrect": false
      },
      {
        "id": 1412,
        "content": [
          "Random error is biased, whereas systematic error does not show bias."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 354,
    "content": [
      "The unit vector in the direction of $$\\vec{A}$$ = $$3\\hat{i}+4\\hat{j}$$ is"
    ],
    "explanation": [
      "First, calculate the magnitude of $$\\vec{A}$$:\n\n$$\n|\\vec{A}| = \\sqrt{(3)^2 + (4)^2} = 5\n$$\n\nNow, divide each component of $$\\vec{A}$$ by its magnitude:\n\n$$\n\\text{Unit vector} = \\frac{\\vec{A}}{|\\vec{A}|} = \\frac{3\\hat{i} + 4\\hat{j}}{5} = \\frac{3}{5}\\hat{i} + \\frac{4}{5}\\hat{j}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1413,
        "content": [
          "$$\\frac{3}{5} \\hat{i} + \\frac{4}{5} \\hat{j}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1414,
        "content": [
          "$$2\\hat{i} - \\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1415,
        "content": [
          "$$\\frac{3}{2} \\hat{i} + \\frac{4}{2} \\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1416,
        "content": [
          "$$\\hat{i} + \\hat{j}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Vectors"
  },
  {
    "id": 355,
    "content": [
      "Which of the following pair of vectors are collinear?"
    ],
    "explanation": [
      "To determine if two vectors are collinear, we need to check if one vector is a scalar multiple of the other.\n\n**Option 1**:$$2\\hat{i} - 3\\hat{j}$$ and $$-4\\hat{i} - 6\\hat{j}$$:\n\n- $$\\frac{-4}{2}$$ = -2 and $$\\frac{-6}{-3}$$ = 2 (**not collinear**)\n\n**Option 2**:$$\\hat{i} + \\hat{j}$$ and $$-\\hat{i} + \\hat{j}$$:\n\n- $$\\frac{-1}{1} = -1$$ and $$\\frac{1}{1} = 1$$ (**not collinear**)\n\n**Option 3**:$$2\\hat{i} + 3\\hat{j}$$ and $$-4\\hat{i} + 6\\hat{j}$$:\n\n- $$\\frac{-4}{2} = -2$$ and $$\\frac{6}{3} = 2$$ (**not collinear**)\n\n**Option 4**:$$2\\hat{i} + 3\\hat{j}$$ and $$-4\\hat{i} - 6\\hat{j}$$:\n\n- $$\\frac{-4}{2} = -2$$ and $$\\frac{-6}{3} = -2$$ (**collinear**)"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1417,
        "content": [
          "$$2\\hat{i}-3\\hat{j}$$ and $$-4\\hat{i}-6\\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1418,
        "content": [
          "$$\\hat{i}+\\hat{j}$$ and $$-\\hat{i}+\\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1419,
        "content": [
          "$$2\\hat{i}+3\\hat{j}$$ and $$-4\\hat{i}+6\\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1420,
        "content": [
          "$$2\\hat{i}+3\\hat{j}$$ and $$-4\\hat{i}-6\\hat{j}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 356,
    "content": [
      "For an object moving in straight line,"
    ],
    "explanation": [
      "A constant increase in velocity indicates constant acceleration, resulting in a straight line with a positive slope on the velocity-time graph and a horizontal line on the acceleration-time graph."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1421,
        "content": [
          "if the velocity increases by equal amount in equal time interval, the velocity-time graph is straight line with positive slope and the acceleration-time graph is horizontal."
        ],
        "isCorrect": true
      },
      {
        "id": 1422,
        "content": [
          "the slope of displacement-time graph and the area of the region under acceleration-time graph are, respectively, the acceleration and velocity of the object."
        ],
        "isCorrect": false
      },
      {
        "id": 1423,
        "content": [
          "if the displacement changes by equal amount in equal time interval, the displacement-time graph is horizontal line."
        ],
        "isCorrect": false
      },
      {
        "id": 1424,
        "content": [
          "the area of the region under the displacement-time graph and the slope of velocity-time graph are, respectively, the acceleration and displacement of the object."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Uniformly Accelerated Motion"
  },
  {
    "id": 357,
    "content": [
      "Which of the following is true about satellite motion?"
    ],
    "explanation": [
      "The formula for the orbital speed v of a satellite is:\n\n$$\nv = \\sqrt{\\frac{GM}{r}}\n$$\n\nWhere:\n\n- G is the gravitational constant ($$6.67430 \\times 10^{-11}$$ $$\\text{m}^3 \\text{kg}^{-1} \\text{s}^{-2}$$),\n- M is the mass of the Earth,\n- r is the distance from the center of the Earth to the satellite.\n\nFrom this formula, you can see that as the distance r decreases (i.e., the satellite is closer to Earth), the speed v increases. This explains why a satellite closer to Earth moves faster than one farther away."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1425,
        "content": [
          "For equal orbital radius, a satellite moving around the Earth has smaller speed than a satellite moving about Moon."
        ],
        "isCorrect": false
      },
      {
        "id": 1426,
        "content": [
          "A satellite closer to Earth is faster than a satellite farther from the Earth."
        ],
        "isCorrect": true
      },
      {
        "id": 1427,
        "content": [
          "A satellite moving closer to the Earth takes longer time to complete one revolution than a satellite farther from Earth."
        ],
        "isCorrect": false
      },
      {
        "id": 1428,
        "content": [
          "For two satellites moving around the Earth at equal orbital radius, a heavier satellite has larger speed than a lighter one."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 366,
    "content": [
      "Consider a long and tightly wound solenoid carrying current I, having length L and N turns of winding. If n is the number of turns per unit length, which of the following describes the magnetic field produced by the solenoid?"
    ],
    "explanation": [
      "Inside the solenoid the magnetic field is uniform, parallel to the axis of the solenoid. The field inside a long solenoid is constant and directed along its length (parallel to the solenoid's axis). Outside the solenoid the magnetic field outside is negligible because the fields produced by different turns cancel each other out. Thus, the magnetic field outside is very weak."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1461,
        "content": [
          "The magnetic field inside the solenoid is zero, whereas the field outside is perpendicular to the length of the solenoid."
        ],
        "isCorrect": false
      },
      {
        "id": 1462,
        "content": [
          "The magnetic field inside the solenoid is constant and is parallel to the solenoid's axis, whereas the field outside is negligible."
        ],
        "isCorrect": true
      },
      {
        "id": 1463,
        "content": [
          "The magnetic field inside the solenoid is uniform and perpendicular to the axis of the solenoid."
        ],
        "isCorrect": false
      },
      {
        "id": 1464,
        "content": [
          "The magnetic field outside the solenoid is as strong as the field inside it."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 367,
    "content": [
      "According to the law of electromagnetic induction,"
    ],
    "explanation": [
      "Faraday's law, states that the induced electromotive force (emf) in any closed circuit is directly proportional to the rate of change of the magnetic flux through the circuit."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1465,
        "content": [
          "the magnitude of emf induced in a circuit is directly proportional to the rate of change the magnetic flux crossing any surface bounded by the circuit."
        ],
        "isCorrect": true
      },
      {
        "id": 1466,
        "content": [
          "a changing magnetic field parallel to the plane of a circuit induces an emf in it."
        ],
        "isCorrect": false
      },
      {
        "id": 1467,
        "content": [
          "a constant magnetic flux crossing the surface of a circuit induced an emf in the circuit."
        ],
        "isCorrect": false
      },
      {
        "id": 1468,
        "content": [
          "an emf is induced in a circuit when a constant magnetic field crosses its surface."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 373,
    "content": [
      "A satellite revolves around the Earth in a circular orbit of radius r = $$4 \\times 10^{16} \\ \\text{m}$$. The period of the satellite is"
    ],
    "explanation": [
      "To find the period of a satellite in circular orbit around the Earth, we can use Kepler's third law:\n\n$$\nT = 2 \\pi \\sqrt{\\frac{r^3}{GM} }\n$$\n\nWhere:\n\n- T = period of the satellite,\n- G = gravitational constant ($$6.674 \\times 10^{-11}$$ $$\\text{m}^3\\, \\text{kg}^{-1}\\, \\text{s}^{-2}$$),\n- M = mass of the Earth $$5.972 \\times 10^{24} \\, \\text{kg}$$,\n- r = radius of the orbit ($$4 \\times 10^{16} \\, \\text{m}$$).\n\nSolving for T:\n$$\nT \\approx 2.52 \\times 10^{18} \\ \\text{s}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1489,
        "content": [
          "$$2.5 \\times 10^{19} \\ \\text{s}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1490,
        "content": [
          "$$3.7 \\times 10^{27} \\ \\text{s}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1491,
        "content": [
          "$$3.7 \\times 10^{26} \\ \\text{s}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1492,
        "content": [
          "$$2.5 \\times 10^{18} \\ \\text{s}$$."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 378,
    "content": [
      "Circular paths followed by two charges $$q_1$$ and $$q_2$$ moving with the same speed in uniform magnetic field directed into the page (x) are shown in the figure below.",
      "images/physics/year_2014/q28_1.png",
      "If the two charges have the same mass, which of the following is correct about the sign and the magnitude of charges?"
    ],
    "explanation": [
      "When a charged particle moves in a uniform magnetic field, it experiences a force perpendicular to both its velocity and the magnetic field. This force causes the particle to move in a circular path. The radius of this path is given by:\n\n$$\nr = \\frac{mv}{|q|B}\n$$\n\nGiven that both charges $$q_1$$ and $$q_2$$ have the same mass and speed, the radius of their paths depends on the magnitude of their charges. A larger charge magnitude results in a smaller radius.\n\nAdditionally, the direction of the force (and thus the direction of the circular motion) depends on the sign of the charge. Using the right-hand rule, if the magnetic field is directed into the page (represented by 'x'), a positive charge will move in a counterclockwise direction, while a negative charge will move in a clockwise direction.\n\n- If $$q_1$$ is negative and $$q_2$$ is positive, they will move in opposite directions (one clockwise and the other counterclockwise).\n- The charge with the smaller radius has a larger magnitude.\n\nTherefore, the correct answer is: $$q_1$$ is negative, $$q_2$$ is positive and | $$q_1$$ | > | $$q_2$$ |.\n\nThis means $$q_1$$ has a larger magnitude than $$q_2$$, resulting in a smaller radius for $$q_1$$ path compared to $$q_2$$ path."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2014/q28_1.png"
    ],
    "choices": [
      {
        "id": 1509,
        "content": [
          "$$q_1$$ is negative, $$q_2$$ is positive and |$$q_1$$|<|$$q_2$$|·"
        ],
        "isCorrect": true
      },
      {
        "id": 1510,
        "content": [
          "$$q_1$$ is negative, $$q_2$$ is positive and |$$q_1$$|>|$$q_2$$|."
        ],
        "isCorrect": false
      },
      {
        "id": 1511,
        "content": [
          "$$q_1$$ is positive, $$q_2$$ is negative and |$$q_1$$|<|$$q_2$$|."
        ],
        "isCorrect": false
      },
      {
        "id": 1512,
        "content": [
          "$$q_1$$ is positive, $$q_2$$ is negative and |$$q_1$$|>|$$q_2$$|."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 382,
    "content": [
      "A student throws a ball vertically upward with a speed of 20 m/s. The maximum height reached by the ball and its velocity 3.0 s after it was thrown are, respectively"
    ],
    "explanation": [
      "The formula to calculate the maximum height is:\n$$\nv_f^2 = v_i^2 - 2gh\n$$\n\nSolving for h:\n$$\n0 = 20^2 - 2 \\times 10 \\times h\n$$\n$$\n400 = 20h\n$$\n$$\nh = 20 \\, \\text{m}\n$$\nFinding the velocity 3.0 seconds after the ball was thrown:\n$$\nv_f = v_i - gt\n$$\n$$\nv_f = 20 - 10 \\times 3 = -10 \\, \\text{m/s}\n$$\n\nThe negative sign indicates that the ball is moving downward after 3 seconds."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1525,
        "content": [
          "20 m and 30 m/s upward."
        ],
        "isCorrect": false
      },
      {
        "id": 1526,
        "content": [
          "15 m and 10 m/s downward."
        ],
        "isCorrect": false
      },
      {
        "id": 1527,
        "content": [
          "105 m and 50 m/s upward."
        ],
        "isCorrect": false
      },
      {
        "id": 1528,
        "content": [
          "20 m and 10 m/s downward."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 387,
    "content": [
      "According to the law of floatation, an object must displaces a volume of fluid"
    ],
    "explanation": [
      "According to the law of floatation, an object floating in a fluid displaces a volume of the fluid such that the weight of the displaced fluid is equal to the weight of the object. This principle is derived from Archimedes' principle, which states that the buoyant force acting on the object is equal to the weight of the fluid displaced. Therefore, for an object to float, the weight of the displaced fluid must equal the weight of the object."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1545,
        "content": [
          "equal to the weight of undisplaced fluid."
        ],
        "isCorrect": false
      },
      {
        "id": 1546,
        "content": [
          "equal to its apparent weight."
        ],
        "isCorrect": false
      },
      {
        "id": 1547,
        "content": [
          "less than its own weight."
        ],
        "isCorrect": false
      },
      {
        "id": 1548,
        "content": [
          "equals to its own weight."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 392,
    "content": [
      "A wheel rotating at angular speed of 20 rev/s is brought to rest after 40 rev under a constant angular acceleration. The angular acceleration of a point on the wheel is"
    ],
    "explanation": [
      "To find the angular acceleration, we can use the following kinematic equation for rotational motion:\n\n$$\n\\omega_f^2 = \\omega_i^2 + 2\\alpha\\theta\n$$\n\nPlugging in the values:\n\n$$\n0 = (20)^2 + 2\\alpha(40)\n$$\n\n$$\n0 = 400 + 80\\alpha\n$$\n\n$$\n\\alpha = -5 \\ \\text{rev/s}^2\n$$\n\nThe wheel's angular acceleration is negative because it is decelerating."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1565,
        "content": [
          "$$5 \\ rev/s^2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1566,
        "content": [
          "$$-0.5 \\ rev/s^2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1567,
        "content": [
          "$$-5 \\ rev/s^2$$."
        ],
        "isCorrect": true
      },
      {
        "id": 1568,
        "content": [
          "$$0.25 \\ rev/s^2$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 396,
    "content": [
      "A certain fluid has a density of $$1080 \\ kg/m^3$$ and is observed to rise to a height of 2.1 cm in a 1.0 mm diameter tube. If the contact angle between the wall and the surface is zero, the surface tension of the fluid is"
    ],
    "explanation": [
      "To find the surface tension of the fluid, we can use this formula:\n$$\nh = \\frac{2 \\gamma \\cos(\\theta)}{\\rho g r}\n$$\n\nGiven values:\n\n- $$\\rho$$ = $$1080 \\ kg/m^3$$\n- h = 2.1 cm = 0.021 m\n- d = 1.0 mm = 0.001 m, thus radius r = 0.0005 m\n- θ = 0 (cos(0) = 1))\n\nRearranging the formula for surface tension ($$\\gamma$$):\n$$\n\\gamma = \\frac{h \\rho g r}{2 \\cos(\\theta)}\n$$\n$$\n\\gamma \\approx 0.0567 \\, N/m\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_DENSITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1581,
        "content": [
          "5670 N/m."
        ],
        "isCorrect": false
      },
      {
        "id": 1582,
        "content": [
          "0.02835 N/m."
        ],
        "isCorrect": false
      },
      {
        "id": 1583,
        "content": [
          "0.1134 N/m,"
        ],
        "isCorrect": false
      },
      {
        "id": 1584,
        "content": [
          "0.0567 N/m."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 886,
    "content": [
      "Lenz's law states that the direction of the induced current in a loop is in such a way that the current"
    ],
    "explanation": [
      "According to Lenz's law, the direction of the induced current in a loop creates a magnetic field that opposes the change in magnetic flux that induced the current."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3544,
        "content": [
          "is in opposite direction to that of the applied magnetic field that is causing it."
        ],
        "isCorrect": false
      },
      {
        "id": 3545,
        "content": [
          "creates a magnetic field that reinforces the change in magnetic flux through the loop."
        ],
        "isCorrect": false
      },
      {
        "id": 3546,
        "content": [
          "is in the same direction as that of the applied magnetic field that is causing it."
        ],
        "isCorrect": false
      },
      {
        "id": 3547,
        "content": [
          "creates a magnetic field that opposes the change in magnetic flux through the loop."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 888,
    "content": [
      "Consider an ideal transformer having $$N_p$$ and $$N_s$$ turns, and voltages $$V_p$$ and $$V_s$$ in its primary and secondary coils, respectively. Which one of the following is the correct ideal transformer equation?"
    ],
    "explanation": [
      "The ideal transformer equation relates the voltages and number of turns in the primary and secondary coils.\n\nThe correct relationship is $$\\frac{V_s}{V_p} = \\frac{N_s}{N_p}$$, which shows that the ratio of the secondary voltage to the primary voltage is equal to the ratio of the number of turns in the secondary coil to the number of turns in the primary coil."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3552,
        "content": [
          "$$V_p = (\\frac{N_s}{N_p})^2 V_s$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3553,
        "content": [
          "$$\\frac{V_s}{V_p} = \\frac{N_s}{N_p}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3554,
        "content": [
          "$$\\frac{N_s}{N_p} = (\\frac{V_s}{V_p})^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3555,
        "content": [
          "$$\\frac{V_s}{V_p} = \\frac{N_p}{N_s}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 890,
    "content": [
      "Which one of the following statements distinguishes precision from accuracy?"
    ],
    "explanation": [
      "Precision refers to how close repeated measurements are to each other. Accuracy refers to how close a measured value is to the true or accepted value."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3560,
        "content": [
          "Accuracy measures how exact a value is whereas precision indicates how close a measured value is to the true value."
        ],
        "isCorrect": false
      },
      {
        "id": 3561,
        "content": [
          "Precision indicates how close a measured value is to the true value, whereas accuracy refers to the closeness of repeatedly measured values to each other."
        ],
        "isCorrect": false
      },
      {
        "id": 3562,
        "content": [
          "Precision is a measure of the closeness of repeatedly measured values to each other, whereas accuracy refers to the closeness of measured values to the true value."
        ],
        "isCorrect": true
      },
      {
        "id": 3563,
        "content": [
          "Precision is a measure of the closeness of repeatedly measured values to each other, whereas accuracy is related to the number of significant figures."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 894,
    "content": [
      "In an experiment to determine the direction of the magnetic field around a long straight current-carrying wire, a student placed a small compass at point P, as shown in the diagram.",
      "images/physics/year_2016/q9_1.png",
      "If the direction of the current in the wire is directed out-of the page, then the magnetic needle of the compass will point"
    ],
    "explanation": [
      "By the right‐hand rule (thumb pointing out of the page), the magnetic field circles counterclockwise.  At point P (to the left of the wire), the field is directed downward, so the compass needle points downward."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2016/q9_1.png"
    ],
    "choices": [
      {
        "id": 3576,
        "content": [
          "downward."
        ],
        "isCorrect": true
      },
      {
        "id": 3577,
        "content": [
          "to the right."
        ],
        "isCorrect": false
      },
      {
        "id": 3578,
        "content": [
          "upward."
        ],
        "isCorrect": false
      },
      {
        "id": 3579,
        "content": [
          "to the left."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 901,
    "content": [
      "Which one of the following statements does NOT describe the relationship of physics with biology?"
    ],
    "explanation": [
      "While physics deals with the interactions of large numbers of particles, biology is more focused on the study of living organisms, their functions, and processes. The relationship between the two involves specific applications rather than a general concern with the interaction of large numbers of particles as a primary focus."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3604,
        "content": [
          "Both physics and biology are mainly concerned in the interaction of large number of particles."
        ],
        "isCorrect": true
      },
      {
        "id": 3605,
        "content": [
          "Newtonian mechanics and biology are used to explain why cheetah is fastest animal."
        ],
        "isCorrect": false
      },
      {
        "id": 3606,
        "content": [
          "Physics and biology are interrelated to each other in the study of vision and color detection."
        ],
        "isCorrect": false
      },
      {
        "id": 3607,
        "content": [
          "Physics and biology used to study how air vibrates in vocal cords."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 902,
    "content": [
      "Which one of the following is a correct relation of physics with medicine?"
    ],
    "explanation": [
      "Medical physics is a discipline that applies the principles of physics to medicine. It involves the use of physics concepts and techniques in medical diagnosis, treatment, and research."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3608,
        "content": [
          "Physics is a branch of medicine that sets standards during medical diagnosis."
        ],
        "isCorrect": false
      },
      {
        "id": 3609,
        "content": [
          "A discipline called medical physics deals with principles of physics in medical diagnosis."
        ],
        "isCorrect": true
      },
      {
        "id": 3610,
        "content": [
          "Modern medical imaging instrument are developed with knowledge of medicine and later used by physics."
        ],
        "isCorrect": false
      },
      {
        "id": 3611,
        "content": [
          "Medicine is a branch of physics dealing with nuclear reaction."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 904,
    "content": [
      "A glass tube of radius 30 mm is inserted in a bowl which contains methyl iodide of density 2.28 kg/m³. If the contact angle of the methyl iodide in the tube is 30⁰ and the surface tension is 0.26 N/m, how much height does the methyl iodide rises through the tube?"
    ],
    "explanation": [
      "Using the capillary‐rise formula for a fluid wetting the tube (contact angle < 90°)\n$$\nh=\\frac{2\\,\\gamma\\cos\\theta}{\\rho\\,g\\,r}\n$$\nWith\n- $$\\gamma=0.26\\rm\\ N/m$$\n- $$\\theta=30°$$ $$\\implies$$ $$\\cos\\theta$$ = $$\\tfrac{\\sqrt3}{2}\\approx0.866$$\n- $$\\rho=2.28\\rm\\ kg/m^3$$\n- $$g=9.81\\rm\\ m/s^2$$\n- $$r=30\\rm\\ mm=0.03\\ m$$\n\n$$\nh =\\frac{2(0.26)(0.866)}{(2.28)(9.81)(0.03)} \\approx0.66\\rm\\ m\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3616,
        "content": [
          "6.6 m"
        ],
        "isCorrect": false
      },
      {
        "id": 3617,
        "content": [
          "0.066 m"
        ],
        "isCorrect": false
      },
      {
        "id": 3618,
        "content": [
          "0.52 m"
        ],
        "isCorrect": false
      },
      {
        "id": 3619,
        "content": [
          "0.66 m"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 906,
    "content": [
      "A pressure applied to one point in an enclosed incompressible fluid is transmitted to all parts of the fluid without reducing in value. This is the principle of"
    ],
    "explanation": [
      "Pascal's principle states that pressure applied to an enclosed fluid is transmitted undiminished to every portion of the fluid and to the walls of the containing vessel."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3624,
        "content": [
          "Archimedes."
        ],
        "isCorrect": false
      },
      {
        "id": 3625,
        "content": [
          "Pascal."
        ],
        "isCorrect": true
      },
      {
        "id": 3626,
        "content": [
          "Continuity."
        ],
        "isCorrect": false
      },
      {
        "id": 3627,
        "content": [
          "Bernoulli."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 907,
    "content": [
      "Which of the following statement describes uniform motion?"
    ],
    "explanation": [
      "Uniform motion is defined as motion with constant speed in a straight line. An object moving with constant speed in a straight line maintains the same velocity over time, which is the definition of uniform motion."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3628,
        "content": [
          "An object moving at 30 m/s toward East and then 30 m/s toward North"
        ],
        "isCorrect": false
      },
      {
        "id": 3629,
        "content": [
          "An object moving around a circular track with constant speed of 30 m/s"
        ],
        "isCorrect": false
      },
      {
        "id": 3630,
        "content": [
          "An object moving with constant speed of 30 m/s in a straight line"
        ],
        "isCorrect": true
      },
      {
        "id": 3631,
        "content": [
          "An object, starting from rest, moving, on a straight line to attain a velocity of 30 m/s"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 910,
    "content": [
      "A car travels 60 m north and then 80 m west. What is the magnitude of the resultant displacement of the car from its starting point?"
    ],
    "explanation": [
      "The car's displacement can be found using the Pythagorean theorem, as the north and west movements are perpendicular to each other.\n$$\nd = \\sqrt{(60)^2 + (80)^2}\n$$\n$$\nd = \\sqrt{10000}\n$$\n$$\nd = 100 \\, m\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3640,
        "content": [
          "100 m"
        ],
        "isCorrect": true
      },
      {
        "id": 3641,
        "content": [
          "140 m"
        ],
        "isCorrect": false
      },
      {
        "id": 3642,
        "content": [
          "20 m"
        ],
        "isCorrect": false
      },
      {
        "id": 3643,
        "content": [
          "4800 m"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 911,
    "content": [
      "The velocity-time graph of an object moving along a straight line toward east is described by the figure shown below.",
      "images/physics/year_2016/q26_1.png",
      "What is the total displacement moved by the object?"
    ],
    "explanation": [
      "The total displacement is the area under the velocity-time graph. The graph can be divided into two sections: a rectangle from 0 to 15 seconds and a triangle from 15 to 20 seconds.\n\nArea of rectangle (0 to 15 s):\n$$\nA_1 = v \\times t\n$$\n$$\nA_1 = 30 \\frac{m}{s} \\times 15 s = 450 \\, m\n$$\nArea of triangle (15 to 20 s):\n$$\nA_2 = \\frac{1}{2} \\times base \\times height\n$$\n$$\nA_2 = \\frac{1}{2} \\times (20 - 15) s \\times 30 \\frac{m}{s} = 75 \\, m\n$$\nTotal displacement:\n$$\nD_{total} = A_1 + A_2 = 450 \\, m + 75 \\, m = 525 \\, m\n$$\nThe total displacement moved by the object is 525 m East."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2016/q26_1.png"
    ],
    "choices": [
      {
        "id": 3644,
        "content": [
          "450 m East"
        ],
        "isCorrect": false
      },
      {
        "id": 3645,
        "content": [
          "375 m East"
        ],
        "isCorrect": false
      },
      {
        "id": 3646,
        "content": [
          "525 m East"
        ],
        "isCorrect": true
      },
      {
        "id": 3647,
        "content": [
          "600 m East"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 915,
    "content": [
      "A substance with a mass of 2kg has a volume of $$2.5 \\times 10^{-3} m^3$$. What is the relative density of the substance?"
    ],
    "explanation": [
      "The density of the substance is:\n$$\n\\rho = \\frac{m}{V} = \\frac{2 kg}{2.5 \\times 10^{-3} m^3} = 800 kg/m^3\n$$\nRelative density (RD) is:\n$$\nRD = \\frac{\\text{Density of substance}}{\\text{Density of water}} = \\frac{800 kg/m^3}{1000 kg/m^3} = 0.8\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_DENSITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3660,
        "content": [
          "1.25"
        ],
        "isCorrect": false
      },
      {
        "id": 3661,
        "content": [
          "0.8"
        ],
        "isCorrect": true
      },
      {
        "id": 3662,
        "content": [
          "8.0"
        ],
        "isCorrect": false
      },
      {
        "id": 3663,
        "content": [
          "80"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 916,
    "content": [
      "The gauge pressure at a point in a fluid at rest is defined as"
    ],
    "explanation": [
      "Gauge pressure is the difference between the absolute pressure and the atmospheric pressure."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_PRESSURE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3664,
        "content": [
          "the actual pressure at a given point relative to absolute vacuum."
        ],
        "isCorrect": false
      },
      {
        "id": 3665,
        "content": [
          "the sum of absolute pressure and atmospheric pressure."
        ],
        "isCorrect": false
      },
      {
        "id": 3666,
        "content": [
          "the pressure difference between the absolute pressure and the atmospheric pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 3667,
        "content": [
          "the atmospheric pressure difference between sea level and the local area at which the fluid exists."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 917,
    "content": [
      "How do we use manometer to measure pressure of a given gas? We use in such a way that"
    ],
    "explanation": [
      "A manometer measures pressure based on the principle of hydrostatic equilibrium, where the pressure difference is related to the height difference of the fluid column."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_PRESSURE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3668,
        "content": [
          "the principle of the hydrostatic equilibrium is considered to measure the pressure of unknown gas."
        ],
        "isCorrect": true
      },
      {
        "id": 3669,
        "content": [
          "the pressure at the surface of open end manometer is the same as the gas pressure in closed tube."
        ],
        "isCorrect": false
      },
      {
        "id": 3670,
        "content": [
          "the gauge pressure equals the atmospheric pressure."
        ],
        "isCorrect": false
      },
      {
        "id": 3671,
        "content": [
          "the gauge pressure in a fluid in the open end equals the gas pressure in closed tube."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 918,
    "content": [
      "Consider two balls A and B are projected with the same velocity, $$v_0$$ at angles $$\\theta_1$$ and $$\\theta_2$$, respectively, $$0 < \\theta_1 < 45^\\circ$$ and $$45^\\circ < \\theta_2 < 90^\\circ$$. Which one of the following statements is correct about the motion of the balls?"
    ],
    "explanation": [
      "For a projectile launched with an initial velocity $$v_0$$ at an angle $$\\theta$$, the range $$R$$ is given by $$R$$ = $$\\frac{v_0^2 \\sin(2\\theta)}{g}$$.\n\nThe ranges of two projectiles are equal if their launch angles are complementary, i.e., $$\\theta_1 + \\theta_2$$ = $$90^\\circ$$, because $$\\sin(2\\theta)$$ = $$\\sin(180^\\circ - 2\\theta)$$. So, $$\\sin(2\\theta_1)$$ = $$\\sin(2(90^\\circ - \\theta_2))$$ = $$\\sin(180^\\circ - 2\\theta_2)$$ = $$\\sin(2\\theta_2)$$."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3672,
        "content": [
          "The range of ball A is smaller than its maximum height."
        ],
        "isCorrect": false
      },
      {
        "id": 3673,
        "content": [
          "Ball A takes longer time than ball B to reach its maximum height."
        ],
        "isCorrect": false
      },
      {
        "id": 3674,
        "content": [
          "Both balls have equal speed at their respective maximum height."
        ],
        "isCorrect": false
      },
      {
        "id": 3675,
        "content": [
          "The two balls cover equal ranges when $$\\theta_1 + \\theta_2$$ = $$90^\\circ$$."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 919,
    "content": [
      "A car initially traveling at speed of 20 m/s undergoes a constant deceleration of magnitude 1.5 m/s². If the radius of each tire is 0.3 m, how many revolutions does each tire make, without slipping, before the car comes to rest?"
    ],
    "explanation": [
      "First, find the distance $$d$$ the car travels using\n$$\nv_f^2 = v_i^2 + 2ad\n$$\nWhere $$v_f = 0 \\ m/s$$ , $$v_i = 20 \\ m/s$$, and $$a = -1.5 \\ m/s^2$$. Thus,\n$$\n0 = 20^2 + 2(-1.5)d\n$$\n$$\nd = \\frac{400}{3} \\ m\n$$\nNext, find the circumference of the tire:\n$$\nC = 2\\pi r = 2\\pi (0.3) = 0.6\\pi \\ m\n$$\nThen, the number of revolutions is:\n$$\nN = \\frac{d}{C}\n$$\n$$\nN = \\frac{400/3}{0.6\\pi}\n$$\n$$\nN \\approx 70.77 \\ revolutions\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3676,
        "content": [
          "444.4 rev"
        ],
        "isCorrect": false
      },
      {
        "id": 3677,
        "content": [
          "70.77 rev"
        ],
        "isCorrect": true
      },
      {
        "id": 3678,
        "content": [
          "44.44 rev"
        ],
        "isCorrect": false
      },
      {
        "id": 3679,
        "content": [
          "133.33 rev"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 921,
    "content": [
      "A loop of 0.1 m wide in diameter is placed in xy-plane in uniform magnetic field of 0.6 T that is perpendicular to the plane of the loop. What is the net magnetic flux through the coil?"
    ],
    "explanation": [
      "The magnetic flux $$\\Phi$$ = $$B \\cdot A$$ = $$B \\cdot \\pi r^2$$, where $$B$$ = $$0.6 \\ T$$ and $$r$$ = $$\\frac{0.1}{2}$$ = $$0.05 \\ m$$.\n\nSo, $$\\Phi$$ = $$0.6 \\cdot \\pi (0.05)^2$$ $$\\approx$$ $$0.00471 \\ Wb$$ or $$4.71 \\times 10^{-3} \\ Wb$$."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3684,
        "content": [
          "$$1.9 \\times 10^{-2} \\ Wb$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3685,
        "content": [
          "$$5.6 \\times 10^{-2} \\ Wb$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3686,
        "content": [
          "$$4.7 \\times 10^{-3} \\ Wb$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3687,
        "content": [
          "$$9.4 \\times 10^{-3} \\ Wb$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 922,
    "content": [
      "A 12 V voltage source is connected across the primary coil of a transformer having 600 turns. If the secondary coil of a transformer has 1000 turns, what voltage appears across the secondary coil?"
    ],
    "explanation": [
      "The transformer equation is\n$$\n\\frac{V_p}{N_p} = \\frac{V_s}{N_s}\n$$\nWhere $$V_p$$ is the primary voltage, $$N_p$$ is the number of turns in the primary coil, $$V_s$$ is the secondary voltage, and $$N_s$$ is the number of turns in the secondary coil.\n\nGiven $$V_p = 12 \\ V$$, $$N_p = 600$$, and $$N_s = 1000$$, we have\n$$\n\\frac{12}{600} = \\frac{V_s}{1000}\n$$\n$$\nV_s = \\frac{12 \\cdot 1000}{600} = 20 \\ V\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3688,
        "content": [
          "72.0 V"
        ],
        "isCorrect": false
      },
      {
        "id": 3689,
        "content": [
          "7.2 V"
        ],
        "isCorrect": false
      },
      {
        "id": 3690,
        "content": [
          "12.0 V"
        ],
        "isCorrect": false
      },
      {
        "id": 3691,
        "content": [
          "20.0 V"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 923,
    "content": [
      "The following table shows the density of different objects at 20°C.",
      "images/physics/year_2016/q38_1.png",
      "Based on the information given in the table, if we identify substances that sink and float with respect to other substance,"
    ],
    "explanation": [
      "Bone (1800 kg/m³), iron (7860 kg/m³), and seawater (1025 kg/m³) all have densities greater than that of water (1000 kg/m³). Since a substance sinks in another if its density is greater than the fluid’s density, all three substances—bone, iron, and seawater—will sink in water."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_DENSITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2016/q38_1.png"
    ],
    "choices": [
      {
        "id": 3692,
        "content": [
          "bone, iron and seawater will sink in water."
        ],
        "isCorrect": true
      },
      {
        "id": 3693,
        "content": [
          "water, gasoline and ice will sink into seawater."
        ],
        "isCorrect": false
      },
      {
        "id": 3694,
        "content": [
          "gasoline, ice and blood floats on the surface of water."
        ],
        "isCorrect": false
      },
      {
        "id": 3695,
        "content": [
          "gold, blood and copper floats in gasoline."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 929,
    "content": [
      "Which of the following statements is correct about the components of the velocity of a ball projected up at an angle of $$\\theta$$ with the horizontal? Neglecting the air resistance,"
    ],
    "explanation": [
      "In projectile motion without air resistance, the horizontal component of velocity remains constant because there is no horizontal acceleration."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3716,
        "content": [
          "the vertical component of velocity increases while the horizontal component of velocity decreases."
        ],
        "isCorrect": false
      },
      {
        "id": 3717,
        "content": [
          "the vertical component of the velocity remains constant throughout its journey."
        ],
        "isCorrect": false
      },
      {
        "id": 3718,
        "content": [
          "the horizontal velocity of the ball is equal to zero at the maximum height."
        ],
        "isCorrect": false
      },
      {
        "id": 3719,
        "content": [
          "the horizontal component of the velocity remains constant throughout its journey."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 933,
    "content": [
      "The orbital speed of a satellite at a height of 780 km from the surface of the earth is 7,465 m/s. what is the period of the satellite?"
    ],
    "explanation": [
      "The Earth's radius is approximately 6400 km.\n\nTherefore, the orbital radius is r = 6400 + 780 = 7180 km or $$7.180 \\times 10^6$$ m.\n\nThe period T is related to the orbital speed v and the circumference by\n$$\nT = \\frac{2\\pi r}{v}\n$$\n$$\nT = \\frac{2\\pi (7.180 \\times 10^6)}{7465}\n$$\n$$\nT \\approx 6.043 \\times 10^3 s\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3732,
        "content": [
          "$$6.04 \\times 10^3$$ s"
        ],
        "isCorrect": true
      },
      {
        "id": 3733,
        "content": [
          "$$6.04 \\times 10^2$$ s"
        ],
        "isCorrect": false
      },
      {
        "id": 3734,
        "content": [
          "$$6.60 \\times 10^2$$ s"
        ],
        "isCorrect": false
      },
      {
        "id": 3735,
        "content": [
          "$$6.60 \\times 10^3$$ s"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 938,
    "content": [
      "A person walked 10 m in a direction 53° North of East, 10 m North, and finally 20 m in a direction 37° North of West. The magnitude of the person's displacement is"
    ],
    "explanation": [
      "**Break movements into components:**\n\n- 10 m at 53° North of East: $$x_1$$ = 6 m (East), $$y_1$$ = 8 m (North)\n- 10 m North: $$x_2$$ = 0, $$y_2$$ = 10 m (North)\n- 20 m at 37° North of West: $$x_3$$ = 16 m (West), $$y_3$$ = 12 m (North)\n\n**Sum components:**\n\n- x = 6 + 0 - 16 = -10 m (West)\n- y = 8 + 10 + 12 = 30 m (North)\n\n**Calculate displacement:**\n$$\nD = \\sqrt{(-10)^2 + (30)^2} = \\sqrt{1000} \\approx 31.6 \\, \\text{m}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3752,
        "content": [
          "30.0 m."
        ],
        "isCorrect": false
      },
      {
        "id": 3753,
        "content": [
          "31.6 m."
        ],
        "isCorrect": true
      },
      {
        "id": 3754,
        "content": [
          "40.0 m."
        ],
        "isCorrect": false
      },
      {
        "id": 3755,
        "content": [
          "20.0 m."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 939,
    "content": [
      "Which of the following pair of vectors is collinear?"
    ],
    "explanation": [
      "Two vectors are collinear if one is a scalar multiple of the other.\n- Option 1: $$\\vec{C} = \\hat{i} + \\hat{j}$$ and $$\\vec{D} = \\hat{i} - \\hat{j}$$\n    - These vectors are not scalar multiples of each other.\n- Option 2: $$\\vec{A} = 2\\hat{i} + 3\\hat{j}$$ and $$\\vec{B} = -4\\hat{i} + 6\\hat{j}$$\n    - $$\\frac{-4}{2} = -2$$ and $$\\frac{6}{3} = 2$$, so $$\\vec{B}$$ is not a scalar multiple of $$\\vec{A}$$.\n- Option 3: $$\\vec{E} = -\\hat{i} + \\hat{j}$$ and $$\\vec{F} = 3\\hat{i} - 3\\hat{j}$$\n    - $$-3(-\\hat{i} + \\hat{j}) = 3\\hat{i} - 3\\hat{j}$$, so $$\\vec{F} = -3\\vec{E}$$. These vectors are collinear.\n- Option 4 : $$\\vec{G} = 2\\hat{i} + 3\\hat{j}$$ and $$\\vec{F} = 3\\hat{i} + 2\\hat{j}$$\n    - These vectors are not scalar multiples of each other."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3756,
        "content": [
          "$$\\vec{C}$$ = $$\\hat{i}$$ + $$\\hat{j}$$ and $$\\vec{D}$$ = $$\\hat{i}$$ - $$\\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3757,
        "content": [
          "$$\\vec{A}$$ = $$2\\hat{i}$$ + $$3\\hat{j}$$ and $$\\vec{B}$$ = $$-4\\hat{i}$$ + $$6\\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3758,
        "content": [
          "$$\\vec{E}$$ = $$-\\hat{i}$$ + $$\\hat{j}$$ and $$\\vec{F}$$ = $$3\\hat{i}$$ - $$3\\hat{j}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3759,
        "content": [
          "$$\\vec{G}$$ = $$2\\hat{i}$$ +$$ 3\\hat{j}$$ and $$\\vec{F}$$ = $$3\\hat{i}$$ + $$2\\hat{j}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 940,
    "content": [
      "A ball is thrown vertically upward with 12 m/s from the ground. Its speed when the ball is 4.0 m above the ground is"
    ],
    "explanation": [
      "Using the kinematic equation $$v_f^2$$ = $$v_i^2$$ + $$2ad$$, where $$v_i = 12 m/s$$, $$a = -10 m/s^2$$, and $$d = 4.0 m$$\n\n$$v_f^2$$ = $$(12)^2 + 2(-10)(4)$$ = $$144 - 80$$ = $$64$$.\n\nTherefore, $$v_f$$ = $$\\sqrt{64}$$ = $$8 m/s$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3760,
        "content": [
          "8 m/s."
        ],
        "isCorrect": true
      },
      {
        "id": 3761,
        "content": [
          "15 m/s."
        ],
        "isCorrect": false
      },
      {
        "id": 3762,
        "content": [
          "10 m/s."
        ],
        "isCorrect": false
      },
      {
        "id": 3763,
        "content": [
          "12 m/s."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 941,
    "content": [
      "An object is projected at angle $$\\theta$$ from the horizontal with initial velocity $$v_0$$. Which one of the following expressions represents the relationship between maximum height, $$h_{max}$$, and range of the projectile, R?"
    ],
    "explanation": [
      "The range $$R$$ = $$\\frac{v_0^2 \\sin(2\\theta)}{g}$$ = $$\\frac{2v_0^2 \\sin(\\theta) \\cos(\\theta)}{g}$$ and the maximum height $$h_{max}$$ = $$\\frac{v_0^2 \\sin^2(\\theta)}{2g}$$.\n\nThen $$R$$ = $$\\frac{2 v_0^2 \\sin(\\theta) \\cos(\\theta)}{g}$$ = $$\\frac{4 (\\frac{v_0^2 \\sin^2(\\theta)}{2g})}{\\frac{\\sin(\\theta)}{\\cos(\\theta)}}$$ = $$\\frac{4h_{max}}{\\tan(\\theta)}$$."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3764,
        "content": [
          "$$R = h_{max} \\frac{\\tan \\theta}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3765,
        "content": [
          "$$R = 4 h_{max} \\tan \\theta$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3766,
        "content": [
          "$$R = \\frac{2 h_{max}}{\\tan \\theta}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3767,
        "content": [
          "$$R = \\frac{4 h_{max}}{\\tan \\theta}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 943,
    "content": [
      "A 0.2 kg ball is kicked from the ground at 16 m/s in a direction making an angle $$\\theta$$ above the horizontal. Neglecting air resistance, the magnitude of velocity of the ball when it is 3.0 m from the ground is"
    ],
    "explanation": [
      "Using conservation of energy, we have\n$$\nKE_i + PE_i = KE_f + PE_f\n$$\nThe initial kinetic energy is\n\n$$\nKE_i = \\frac{1}{2} m v_i^2 = \\frac{1}{2} (0.2) (16)^2 = 25.6 J\n$$\n\n- The initial potential energy is $$PE_i$$ = $$0 J$$ (at ground level).\n- The final potential energy is $$PE_f$$ = $$mgh$$ = $$(0.2)(9.8)(3.0)$$ = $$5.88 J$$.\n- The final kinetic energy is $$KE_f$$ = $$\\frac{1}{2} m v_f^2$$.\n\n$$\n25.6 + 0 = \\frac{1}{2} (0.2) v_f^2 + 5.88\n$$\n\n$$\n25.6 - 5.88 = 0.1 v_f^2\n$$\n\n$$\n19.72 = 0.1 v_f^2\n$$\n$$\nv_f^2 = 197.2\n$$\n\n$$\nv_f = \\sqrt{197.2} \\approx 14.04 m/s\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3772,
        "content": [
          "7 m/s."
        ],
        "isCorrect": false
      },
      {
        "id": 3773,
        "content": [
          "2 m/s."
        ],
        "isCorrect": false
      },
      {
        "id": 3774,
        "content": [
          "14 m/s."
        ],
        "isCorrect": true
      },
      {
        "id": 3775,
        "content": [
          "16 m/s."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 2408,
    "content": [
      "Vector quantities are represented by"
    ],
    "explanation": [
      "Vector quantities, such as force and velocity, are defined by having both a magnitude (size) and a direction. Scalar quantities, like mass and time, only have magnitude."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9640,
        "content": [
          "magnitude and direction."
        ],
        "isCorrect": true
      },
      {
        "id": 9641,
        "content": [
          "direction only."
        ],
        "isCorrect": false
      },
      {
        "id": 9642,
        "content": [
          "magnitude only."
        ],
        "isCorrect": false
      },
      {
        "id": 9643,
        "content": [
          "dimensionless values."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 2410,
    "content": [
      "Which of the following correctly describes the difference between distance and displacement?"
    ],
    "explanation": [
      "Distance is a scalar quantity representing the total path length traveled. Displacement is a vector quantity representing the shortest straight-line distance from the initial to the final point. Because displacement is the shortest path, its magnitude can never be greater than the distance traveled."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9648,
        "content": [
          "Distance can be described both in magnitude and direction, while displacement is described only by magnitude."
        ],
        "isCorrect": false
      },
      {
        "id": 9649,
        "content": [
          "Distance depends on the initial and final points, while displacement depends on the path followed by a moving body."
        ],
        "isCorrect": false
      },
      {
        "id": 9650,
        "content": [
          "Distance is always greater than or equal to the magnitude of displacement, while the magnitude of the displacement is always less than or equal to distance."
        ],
        "isCorrect": true
      },
      {
        "id": 9651,
        "content": [
          "Distance has either positive or negative values, while displacement has only positive value."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 2411,
    "content": [
      "Which of the following statements is correct about a uniformly accelerated motion?"
    ],
    "explanation": [
      "The definition of uniformly accelerated motion is that the rate of change of velocity, which is acceleration, is constant over time."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9652,
        "content": [
          "The velocity is constant."
        ],
        "isCorrect": false
      },
      {
        "id": 9653,
        "content": [
          "The acceleration is constant."
        ],
        "isCorrect": true
      },
      {
        "id": 9654,
        "content": [
          "The speed is constant but the direction is changing."
        ],
        "isCorrect": false
      },
      {
        "id": 9655,
        "content": [
          "The displacement increases at a uniform rate."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Uniformly Accelerated Motion"
  },
  {
    "id": 2412,
    "content": [
      "Two displacement vectors have magnitudes 4 m and 3 m. Which one of the following is NOT the possible value of the magnitude of their resultant vector?"
    ],
    "explanation": [
      "The magnitude of the resultant vector R of two vectors A and B must lie in the range |A - B| ≤ R ≤ A + B. For vectors of magnitude 4 m and 3 m, the range is |4 - 3| ≤ R ≤ 4 + 3, which simplifies to 1 m ≤ R ≤ 7 m. The value 12 m is outside this possible range."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9656,
        "content": [
          "1 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9657,
        "content": [
          "7 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9658,
        "content": [
          "5 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9659,
        "content": [
          "12 m"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 2413,
    "content": [
      "A train is moving along a straight line with a constant acceleration of 5 m/s² when it passes by a traffic light point. From there on, if the time taken by the train to reach a velocity of 30 m/s is 4 seconds, then what is the distance of the train from the traffic point after 8 seconds?"
    ],
    "explanation": [
      "First, find the initial velocity (u) when the train passes the traffic light using the formula $$v = u + at$$.\n$$\n30 \\text{ m/s} = u + (5 \\text{ m/s}^2)(4 \\text{ s})\n$$\n$$\nu = 30 - 20 = 10 \\text{ m/s}\n$$",
      "Now, calculate the distance (s) traveled after 8 seconds using the formula $$s = ut + \\frac{1}{2}at^2$$.\n$$\ns = (10 \\text{ m/s})(8 \\text{ s}) + \\frac{1}{2}(5 \\text{ m/s}^2)(8 \\text{ s})^2\n$$\n$$\ns = 80 + \\frac{1}{2}(5)(64)\n$$\n$$\ns = 80 + 160 = 240 \\text{ m}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9660,
        "content": [
          "80 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9661,
        "content": [
          "160 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9662,
        "content": [
          "240 m"
        ],
        "isCorrect": true
      },
      {
        "id": 9663,
        "content": [
          "320 m"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Uniformly Accelerated Motion"
  },
  {
    "id": 2422,
    "content": [
      "An object that is partially or fully submerged in a fluid experiences an upward force from the fluid. The apparent weight of the object is the weight of the"
    ],
    "explanation": [
      "The apparent weight of a submerged object is its actual weight (often called weight in air) reduced by the upward buoyant force exerted by the fluid. Apparent Weight = True Weight - Buoyant Force."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9696,
        "content": [
          "fluid it displaces."
        ],
        "isCorrect": false
      },
      {
        "id": 9697,
        "content": [
          "object in air minus the buoyant force."
        ],
        "isCorrect": true
      },
      {
        "id": 9698,
        "content": [
          "object in air."
        ],
        "isCorrect": false
      },
      {
        "id": 9699,
        "content": [
          "fluid it displaces minus the buoyant force."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2429,
    "content": [
      "The atmospheric pressure in a certain area is determined to be 103.36 kPa, using a mercury barometer shown in the figure below. (Acceleration due to gravity, g = 10 m/s², and density of mercury, ρₘ = 13.6 × 10³ kg/m³)",
      "images/physics/year_2017/q22_1_background.png",
      "The height to which the mercury column rises is about"
    ],
    "explanation": [
      "The atmospheric pressure supports the column of mercury. The pressure exerted by the mercury column is given by $$P = \\rho gh$$. We can solve for the height, h.\n$$\nP = 103.36 \\text{ kPa} = 103360 \\text{ Pa}\n$$\n$$\nh = \\frac{P}{\\rho g}\n$$\n$$\nh = \\frac{103360 \\text{ Pa}}{(13.6 \\times 10^3 \\text{ kg/m}^3)(10 \\text{ m/s}^2)}\n$$\n$$\nh = \\frac{103360}{136000} \\text{ m} = 0.76 \\text{ m}\n$$",
      "Converting meters to centimeters: 0.76 m = 76 cm."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_PRESSURE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2017/q22_1_background.png"
    ],
    "choices": [
      {
        "id": 9724,
        "content": [
          "7.6 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9725,
        "content": [
          "760 cm"
        ],
        "isCorrect": false
      },
      {
        "id": 9726,
        "content": [
          "76 mm"
        ],
        "isCorrect": false
      },
      {
        "id": 9727,
        "content": [
          "76 cm"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2430,
    "content": [
      "An object dropped into a sea sinks to a depth of 100 m. Which of the following is correct about the pressure the object experiences? (Assume the density of seawater is 1030 kg/m³ and the air above the see exerts a pressure of $$P_{atmospheric}$$ = 1.00 × 10⁵ Pa, g = 10 m/s²)"
    ],
    "explanation": [
      "First, calculate the gauge pressure (pressure due to the water column) using $$P_{gauge} = \\rho gh$$.\n$$\nP_{gauge} = (1030 \\text{ kg/m}^3)(10 \\text{ m/s}^2)(100 \\text{ m})\n$$\n$$\nP_{gauge} = 1,030,000 \\text{ Pa} = 1.03 \\times 10^6 \\text{ Pa}\n$$",
      "The absolute pressure is the sum of the atmospheric pressure and the gauge pressure.\n$$\nP_{absolute} = P_{atmospheric} + P_{gauge}\n$$\n$$\nP_{absolute} = 1.00 \\times 10^5 \\text{ Pa} + 1.03 \\times 10^6 \\text{ Pa}\n$$\n$$\nP_{absolute} = 0.1 \\times 10^6 \\text{ Pa} + 1.03 \\times 10^6 \\text{ Pa} = 1.13 \\times 10^6 \\text{ Pa}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_PRESSURE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9728,
        "content": [
          "The absolute pressure exerted on it is $$P_{absolute}$$ = 1.13 × 10⁶ Pa."
        ],
        "isCorrect": true
      },
      {
        "id": 9729,
        "content": [
          "The gauge pressure exerted on it is $$P_{gauge}$$ = 1.03 × 10⁷ Pa."
        ],
        "isCorrect": false
      },
      {
        "id": 9730,
        "content": [
          "The gauge pressure exerted on it is $$P_{gauge}$$ = 1.01 × 10⁵ Pa."
        ],
        "isCorrect": false
      },
      {
        "id": 9731,
        "content": [
          "The absolute pressure exerted on it is $$P_{absolute}$$ = 9.30 × 10⁵ Pa."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2437,
    "content": [
      "A long straight wire carries a current of 5.0 A. What is the magnetic field strength produced by the current at a distance of 2.0 cm from the wire? (Magnetic permeability free space µ₀ = 4π × 10⁻⁷ Tm/A)"
    ],
    "explanation": [
      "The magnetic field (B) at a distance (r) from a long, straight wire carrying current (I) is given by the formula $$B = (\\mu_0I) / (2\\pi r)$$.\n$$\nB = \\frac{(4\\pi \\times 10^{-7} \\text{ Tm/A})(5.0 \\text{ A})}{2\\pi(0.02 \\text{ m})}\n$$\n$$\nB = \\frac{2 \\times 10^{-7} \\times 5.0}{0.02}\n$$\n$$\nB = \\frac{10 \\times 10^{-7}}{0.02}\n$$\n$$\nB = 500 \\times 10^{-7} \\text{ T} = 5 \\times 10^{-5} \\text{ T}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9756,
        "content": [
          "20 × 10⁻⁵ T"
        ],
        "isCorrect": false
      },
      {
        "id": 9757,
        "content": [
          "5 × 10⁻⁵ T"
        ],
        "isCorrect": true
      },
      {
        "id": 9758,
        "content": [
          "5π × 10⁻⁵ T"
        ],
        "isCorrect": false
      },
      {
        "id": 9759,
        "content": [
          "20π × 10⁻⁵ T"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2438,
    "content": [
      "If two vectors a and b, with respective magnitudes of a and b, form an angle α between them when they are connected tail to tail, then the expression ab cos α defines the value of"
    ],
    "explanation": [
      "The expression ab cos(α) is the definition of the scalar product (or dot product) of two vectors a and b."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9760,
        "content": [
          "scalar product of a and b."
        ],
        "isCorrect": true
      },
      {
        "id": 9761,
        "content": [
          "resultant of a and b."
        ],
        "isCorrect": false
      },
      {
        "id": 9762,
        "content": [
          "projection of a on b."
        ],
        "isCorrect": false
      },
      {
        "id": 9763,
        "content": [
          "vector product of a and b."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Vectors"
  },
  {
    "id": 2440,
    "content": [
      "An object moving in one dimension with constant acceleration a travels through a displacement s in a time interval t. If its velocity at the initial time t = 0 is vᵢ and its velocity at a later time t is vբ, which of the following is a correct relation between the given quantities?"
    ],
    "explanation": [
      "We can derive this kinematic equation. Start with the standard equation $$s = v_i t + \\frac{1}{2}at^2$$. We also know that $$v_f = v_i + at$$, which can be rearranged to $$v_i = v_f - at$$. Substituting this expression for $$v_i$$ into the first equation:\n$$\ns = (v_f - at)t + \\frac{1}{2}at^2\n$$\n$$\ns = v_f t - at^2 + \\frac{1}{2}at^2\n$$\n$$\ns = v_f t - \\frac{1}{2}at^2\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9768,
        "content": [
          "$$s = \\frac{(v_f - v_i)}{2} t$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9769,
        "content": [
          "$$s = v_i t + \\frac{1}{2} at^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9770,
        "content": [
          "$$s = \\frac{v_f^2 - v_i^2}{a}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9771,
        "content": [
          "$$s = v_f t - \\frac{1}{2} at^2$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Uniformly Accelerated Motion"
  },
  {
    "id": 2442,
    "content": [
      "Given the displacement vector A = (3 î - 4 ĵ) m, what is the unit vector in the direction of A?"
    ],
    "explanation": [
      "To find the unit vector, first calculate the magnitude of vector A.\n$$\n|A| = \\sqrt{3^2 + (-4)^2} = \\sqrt{9 + 16} = \\sqrt{25} = 5 \\text{ m}\n$$",
      "Then, divide the vector A by its magnitude.\n$$\n\\hat{A} = \\frac{A}{|A|} = \\frac{3 \\hat{i} - 4 \\hat{j}}{5}\n$$\n$$\n\\hat{A} = \\frac{3}{5}\\hat{i} - \\frac{4}{5}\\hat{j} = 0.6 \\hat{i} - 0.8 \\hat{j}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9776,
        "content": [
          "0.6 î + 0.8 ĵ"
        ],
        "isCorrect": false
      },
      {
        "id": 9777,
        "content": [
          "0.8 î - 0.6 ĵ"
        ],
        "isCorrect": false
      },
      {
        "id": 9778,
        "content": [
          "0.6 î - 0.8 ĵ"
        ],
        "isCorrect": true
      },
      {
        "id": 9779,
        "content": [
          "- 0.6 î + 0.8 ĵ"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Vectors"
  },
  {
    "id": 2443,
    "content": [
      "Suppose that you are given two forces with F₁ = 75 N in the direction of 53° west of north and F₂ = 100 N in the direction of 37° east of north. If you add the two forces using analytical and graphical methods and represent using graphical scale of 1 cm for 10 N force, what are the possible length and direction of the arrow line for the resultant vector?"
    ],
    "explanation": [
      "Resolve each force into its x (East-West) and y (North-South) components. Let North be the positive y-axis and East be the positive x-axis.",
      "For F₁ (53° West of North):\n$$\nF_{1x} = -75 \\sin(53^\\circ) = -75(0.8) = -60 \\text{ N}\n$$\n$$\nF_{1y} = +75 \\cos(53^\\circ) = +75(0.6) = 45 \\text{ N}\n$$",
      "For F₂ (37° East of North):\n$$\nF_{2x} = +100 \\sin(37^\\circ) = +100(0.6) = 60 \\text{ N}\n$$\n$$\nF_{2y} = +100 \\cos(37^\\circ) = +100(0.8) = 80 \\text{ N}\n$$",
      "Sum the components to find the resultant force R:\n$$\nR_x = F_{1x} + F_{2x} = -60 + 60 = 0 \\text{ N}\n$$\n$$\nR_y = F_{1y} + F_{2y} = 45 + 80 = 125 \\text{ N}\n$$",
      "The resultant force is 125 N in the positive y-direction (due North). Using the scale 1 cm = 10 N, the length is 125 N / (10 N/cm) = 12.5 cm."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9780,
        "content": [
          "1.73 cm to 45° North of East"
        ],
        "isCorrect": false
      },
      {
        "id": 9781,
        "content": [
          "1.25 cm to the North"
        ],
        "isCorrect": false
      },
      {
        "id": 9782,
        "content": [
          "17.3 cm to 45° North of East"
        ],
        "isCorrect": false
      },
      {
        "id": 9783,
        "content": [
          "12.5 cm to the North"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 2447,
    "content": [
      "The velocity-time graph of an object moving in a straight line is shown in the figure below.",
      "images/physics/year_2017/q40_1.png",
      "What is the magnitude of the total displacement covered by the object in the time interval of 14 seconds?"
    ],
    "explanation": [
      "The total displacement (∆x) is the net signed area under the velocity-time graph. We calculate the area below the axis (t=0 to t=2s) and the area above the axis (t=2 to t=14 s).\n$$\n\\text{Area}_{\\text{Negative}} = \\frac{1}{2} \\times 2 \\times (-6) = -6 \\text{ m}\n$$\n$$\n\\text{Area}{\\text{Positive}} = \\text{Area}{\\text{Trapezoid } (2-14)}\n$$\n$$\n\\text{Area}_{\\text{Positive}} = \\frac{1}{2} \\times [(14-2) + (10-6)] \\times 12\n$$\n$$\n\\text{Area}_{\\text{Positive}} = \\frac{1}{2} \\times [16] \\times 12 = 96 \\text{ m}\n$$\n$$\n\\text{Total Displacement } (\\Delta x) = -6 \\text{ m} + 96 \\text{ m}\n$$\n$$\n\\Delta x = 90 \\text{ m}\n$$\nThe magnitude of the total displacement is:\n$$\n|\\Delta x| = 90 \\text{ m}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2017/q40_1.png"
    ],
    "choices": [
      {
        "id": 9796,
        "content": [
          "102 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9797,
        "content": [
          "90 m"
        ],
        "isCorrect": true
      },
      {
        "id": 9798,
        "content": [
          "54 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9799,
        "content": [
          "42 m"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 2453,
    "content": [
      "Assume that a ball is thrown horizontally from a building of height h above the ground with initial speed v₀. Which one of the following statements is correct about the motion of the object?"
    ],
    "explanation": [
      "For projectile motion, assuming negligible air resistance, the only force acting on the object is gravity, which acts vertically downwards. Since there is no horizontal force, there is no horizontal acceleration. Consequently, the horizontal component of velocity remains constant throughout the motion."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9820,
        "content": [
          "Its vertical component velocity remains constant."
        ],
        "isCorrect": false
      },
      {
        "id": 9821,
        "content": [
          "Its horizontal component acceleration is zero."
        ],
        "isCorrect": true
      },
      {
        "id": 9822,
        "content": [
          "Its horizontal component velocity uniformly increases."
        ],
        "isCorrect": false
      },
      {
        "id": 9823,
        "content": [
          "Its vertical component acceleration is zero."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 2454,
    "content": [
      "A projectile is thrown from a level ground with an initial velocity $$v_0$$ making an angle of θ above the horizontal. If the maximum height covered by the projectile is H, what is the horizontal range of the projectile in terms of H and θ?"
    ],
    "explanation": [
      "The formulas for maximum height (H) and horizontal range (R) are:\n$$\nH = \\frac{v_0^2 \\sin^2\\theta}{2g}\n$$\n$$\nR = \\frac{v_0^2 \\sin(2\\theta)}{g} = \\frac{2v_0^2 \\sin\\theta \\cos\\theta}{g}\n$$",
      "From the height equation, we can express $$v_0^2$$:\n$$\nv_0^2 = \\frac{2gH}{\\sin^2\\theta}\n$$",
      "Substitute this into the range equation:\n$$\nR = \\frac{2 \\left(\\frac{2gH}{\\sin^2\\theta}\\right) \\sin\\theta \\cos\\theta}{g}\n$$\n$$\nR = \\frac{4gH \\sin\\theta \\cos\\theta}{g \\sin^2\\theta}\n$$\n$$\nR = 4H \\frac{\\cos\\theta}{\\sin\\theta} = \\frac{4H}{\\tan\\theta}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9824,
        "content": [
          "H tanθ"
        ],
        "isCorrect": false
      },
      {
        "id": 9825,
        "content": [
          "$$\\frac{H}{\\tan\\theta}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9826,
        "content": [
          "$$\\frac{H}{4 \\tan\\theta}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9827,
        "content": [
          "$$\\frac{4H}{\\tan\\theta}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 2456,
    "content": [
      "The flow rate of a fluid is defined as"
    ],
    "explanation": [
      "Volumetric flow rate (often just called flow rate) is the volume of fluid that passes through a given surface per unit time. It is a fundamental quantity in fluid dynamics. Mass flow rate is the mass per unit time."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9832,
        "content": [
          "the speed with which the fluid flowing through a pipe."
        ],
        "isCorrect": false
      },
      {
        "id": 9833,
        "content": [
          "the volume of the fluid crossing an area per unit time taken."
        ],
        "isCorrect": true
      },
      {
        "id": 9834,
        "content": [
          "the rate of change of the speed with which fluid flowing through a pipe."
        ],
        "isCorrect": false
      },
      {
        "id": 9835,
        "content": [
          "the mass of the fluid crossing an area per unit time taken."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2457,
    "content": [
      "At normal condition, solids are almost incompressible compared to liquids and gases. The reason is that"
    ],
    "explanation": [
      "In the solid state, particles (atoms or molecules) are tightly packed in a fixed, often crystalline, structure. The strong intermolecular forces hold them in place, allowing only for vibrations about their fixed positions. This rigid structure strongly resists changes in volume, making solids nearly incompressible."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_DENSITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9836,
        "content": [
          "their atoms are relatively fixed distance apart and held together."
        ],
        "isCorrect": true
      },
      {
        "id": 9837,
        "content": [
          "their atoms are free to slide about and interact with neighbors."
        ],
        "isCorrect": false
      },
      {
        "id": 9838,
        "content": [
          "there is much space and little force between atoms."
        ],
        "isCorrect": false
      },
      {
        "id": 9839,
        "content": [
          "their atoms vibrate and free to move."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2459,
    "content": [
      "A wheel of radius, r = 50 cm, rotates about a fixed perpendicular axis that passes through its center. If the angular speed is ω = 200 rad/s, how much is the tangential speed of a point on the rim of the wheel?"
    ],
    "explanation": [
      "The tangential speed (v) of a point in circular motion is related to its angular speed (ω) and the radius (r) of the circle by the equation $$v = r\\omega$$. Remember to convert the radius to meters.\n$$\nr = 50 \\text{ cm} = 0.5 \\text{ m}\n$$\n$$\nv = (0.5 \\text{ m})(200 \\text{ rad/s}) = 100 \\text{ m/s}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9844,
        "content": [
          "800 m/s"
        ],
        "isCorrect": false
      },
      {
        "id": 9845,
        "content": [
          "10,000 m/s"
        ],
        "isCorrect": false
      },
      {
        "id": 9846,
        "content": [
          "100 m/s"
        ],
        "isCorrect": true
      },
      {
        "id": 9847,
        "content": [
          "80,000 m/s"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 2461,
    "content": [
      "A 10 N force is applied to the smaller circular piston of a hydraulic lift of radius 0.1 m to lift a 2500 N load placed on the larger piston. What is the area of the larger piston?"
    ],
    "explanation": [
      "According to Pascal's principle for a hydraulic lift, the pressure is transmitted equally throughout the fluid, so $$P_1 = P_2$$. This means $$F_1/A_1 = F_2/A_2$$. We can solve for the area of the larger piston, A₂.",
      "First, find the area of the smaller piston, A₁:\n$$\nA_1 = \\pi r^2 = (3.14)(0.1 \\text{ m})^2 = 0.0314 \\text{ m}^2\n$$",
      "Now, solve for A₂:\n$$\nA_2 = A_1 \\frac{F_2}{F_1} = (0.0314 \\text{ m}^2) \\frac{2500 \\text{ N}}{10 \\text{ N}}\n$$\n$$\nA_2 = 0.0314 \\times 250 = 7.85 \\text{ m}^2\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_PRESSURE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9852,
        "content": [
          "0.25 m²"
        ],
        "isCorrect": false
      },
      {
        "id": 9853,
        "content": [
          "2.50 m²"
        ],
        "isCorrect": false
      },
      {
        "id": 9854,
        "content": [
          "7.85 m²"
        ],
        "isCorrect": true
      },
      {
        "id": 9855,
        "content": [
          "3.14 m²"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2462,
    "content": [
      "The magnetic field created by a long straight current carrying wire"
    ],
    "explanation": [
      "The magnetic field lines produced by a current in a long, straight wire form concentric circles around the wire. The direction of the field is given by the right-hand grip rule, and its strength is inversely proportional to the distance from the wire."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9856,
        "content": [
          "is directly proportional to the distance from the wire."
        ],
        "isCorrect": false
      },
      {
        "id": 9857,
        "content": [
          "is inversely proportional to the current in the wire."
        ],
        "isCorrect": false
      },
      {
        "id": 9858,
        "content": [
          "is directed in the same direction as the current."
        ],
        "isCorrect": false
      },
      {
        "id": 9859,
        "content": [
          "forms circular pattern around the wire."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2467,
    "content": [
      "A circular coil is located in a uniform magnetic field of magnitude 0.50 T directed perpendicular to the plane of the coil. If the area of the coil changes with uniform rate, in such a way that it increases by 4.0 × 10⁻³ m² in 2 s, what is the magnitude of the induced electromotive force (emf) in the coil?"
    ],
    "explanation": [
      "According to Faraday's law of electromagnetic induction, the magnitude of the induced emf (ε) is equal to the rate of change of magnetic flux ($$\\Phi_B$$).\n$$\n|\\epsilon| = \\left| \\frac{\\Delta \\Phi_B}{\\Delta t} \\right|\n$$",
      "Since the magnetic field B is uniform and perpendicular to the coil's area A, the flux is $$\\Phi_B = BA$$. The change in flux is due to the change in area: $$\\Delta\\Phi_B = B(\\Delta A)$$.\n$$\n|\\epsilon| = \\frac{B \\Delta A}{\\Delta t}\n$$\n$$\n|\\epsilon| = \\frac{(0.50 \\text{ T})(4.0 \\times 10^{-3} \\text{ m}^2)}{2 \\text{ s}}\n$$\n$$\n|\\epsilon| = \\frac{2.0 \\times 10^{-3}}{2} \\text{ V}\n$$\n$$\n|\\epsilon| = 1.0 \\times 10^{-3} \\text{ V}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9876,
        "content": [
          "1.0 × 10⁻³ V"
        ],
        "isCorrect": true
      },
      {
        "id": 9877,
        "content": [
          "4.0 × 10⁻³ V"
        ],
        "isCorrect": false
      },
      {
        "id": 9878,
        "content": [
          "1.0 × 10³ V"
        ],
        "isCorrect": false
      },
      {
        "id": 9879,
        "content": [
          "2.5 × 10² V"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2469,
    "content": [
      "Which one of the following statement is NOT correct about the magnetic properties of matter?"
    ],
    "explanation": [
      "Diamagnetic materials do not have unpaired electrons. Their magnetic effect arises from the orbital motion of electrons, which creates magnetic dipoles that oppose the external magnetic field.",
      "The statement that they have unpaired electrons that align with the field is incorrect.",
      "Paramagnetic and ferromagnetic materials have unpaired electrons that align with an external magnetic field."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9884,
        "content": [
          "There is a tendency to oppose the applied magnetic field in a diamagnetic substance."
        ],
        "isCorrect": false
      },
      {
        "id": 9885,
        "content": [
          "The unpaired electrons in diamagnetic materials will align with the applied magnetic field and parallel to each other."
        ],
        "isCorrect": true
      },
      {
        "id": 9886,
        "content": [
          "The unpaired electrons in ferromagnetic materials will align with the applied magnetic field and parallel to each other."
        ],
        "isCorrect": false
      },
      {
        "id": 9887,
        "content": [
          "The unpaired electrons in paramagnetic substance which will tend to align themselves in the same direction as the applied magnetic field."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2470,
    "content": [
      "Suppose a conductor of length l carrying a current I placed in a uniform magnetic field of magnitude B. When the conductor is making an angle θ with that of the magnetic field then the force experienced by the conductor due to the magnetic field is given by"
    ],
    "explanation": [
      "The magnetic force experienced by a straight conductor of length vector $$\\vec{l}$$ carrying a current I in a uniform magnetic field $$\\vec{B}$$ is given by the vector cross product formula:\n$$\n\\vec{F} = I(\\vec{l} \\times \\vec{B})\n$$",
      "The magnitude of this force is $$F = BIl \\sin \\theta$$."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9888,
        "content": [
          "$$\n\\vec{F} = I(\\vec{B} \\times \\vec{l})\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9889,
        "content": [
          "$$\nF = BIl \\cos \\theta\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9890,
        "content": [
          "$$\nF = BIl \\tan \\theta\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9891,
        "content": [
          "$$\n\\vec{F} = I(\\vec{l} \\times \\vec{B})\n$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2471,
    "content": [
      "Which one of the following statement is correct about tangent galvanometer?"
    ],
    "explanation": [
      "A tangent galvanometer works on the principle that a current flowing through its coil produces a magnetic field at the center. This field is perpendicular to the horizontal component of the Earth's magnetic field and causes a compass needle to deflect. The current is directly proportional to the tangent of the deflection angle."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9892,
        "content": [
          "The current through a coil of the wire generates a magnetic field at the center of the coil"
        ],
        "isCorrect": true
      },
      {
        "id": 9893,
        "content": [
          "It consists of a coil of insulated copper wire on a circular magnetic frame."
        ],
        "isCorrect": false
      },
      {
        "id": 9894,
        "content": [
          "The current is inversely proportional to the tangent of the angle of the needle's deflection."
        ],
        "isCorrect": false
      },
      {
        "id": 9895,
        "content": [
          "It is a device used to measure the electric current in terms of the electric field it produces."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2472,
    "content": [
      "A long conductor shown in the figure carries a current I in the direction indicated by the arrow.",
      "images/physics/year_2013/q5_1.png",
      "Which statement is NOT correct about the magnetic field produced by this current carrying conductor?"
    ],
    "explanation": [
      "The magnetic field strength (B) around a long, straight current-carrying wire is given by the formula:\n$$\nB = \\frac{\\mu_0 I}{2\\pi r}\n$$",
      "This shows that the field strength is inversely proportional to the distance (r) from the conductor, not directly proportional."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2013/q5_1.png"
    ],
    "choices": [
      {
        "id": 9896,
        "content": [
          "Doubling the current through the conductor doubles the field strength."
        ],
        "isCorrect": false
      },
      {
        "id": 9897,
        "content": [
          "Reversing the current direction will reverse the direction of the magnetic field."
        ],
        "isCorrect": false
      },
      {
        "id": 9898,
        "content": [
          "The magnetic field encircles the conductor."
        ],
        "isCorrect": false
      },
      {
        "id": 9899,
        "content": [
          "The field strength is directly proportional to the distance from the conductor."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2473,
    "content": [
      "A coiled copper has 50 turns and coil cross-sectional area of 9 × 10⁻⁴ m². This coil is initially placed in a uniform magnetic field 0.02 T and pulled out of a field completely (where the field is zero) in 0.5 seconds. What is the magnitude of the induced electromotive force?"
    ],
    "explanation": [
      "According to Faraday's law of induction, the induced EMF is:\n$$\n\\mathcal{E} = -N \\frac{\\Delta \\Phi_B}{\\Delta t}\n$$",
      "The change in magnetic flux is the final flux minus the initial flux.\n$$\n\\Delta \\Phi_B = \\Phi_{final} - \\Phi_{initial}\n$$\n$$\n\\Delta \\Phi_B = 0 - (B \\cdot A) = -(0.02 \\text{ T})(9 \\times 10^{-4} \\text{ m}^2)\n$$\n$$\n\\Delta \\Phi_B = -1.8 \\times 10^{-5} \\text{ Wb}\n$$",
      "The induced EMF is then calculated as:\n$$\n\\mathcal{E} = -50 \\frac{-1.8 \\times 10^{-5} \\text{ Wb}}{0.5 \\text{ s}}\n$$\n$$\n\\mathcal{E} = 1.8 \\times 10^{-3} \\text{ V}\n$$",
      "This is equal to 1.8 mV."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9900,
        "content": [
          "3.2 mV"
        ],
        "isCorrect": false
      },
      {
        "id": 9901,
        "content": [
          "9.0 mV"
        ],
        "isCorrect": false
      },
      {
        "id": 9902,
        "content": [
          "18 mV"
        ],
        "isCorrect": false
      },
      {
        "id": 9903,
        "content": [
          "1.8 mV"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2475,
    "content": [
      "A coil and a permanent magnet are set in relative motion. Which one of the following statement is NOT correct about induced electromotive force?"
    ],
    "explanation": [
      "The induced EMF depends on the rate of change of magnetic flux, given by\n$$\n\\frac{\\Delta \\Phi_B}{\\Delta t}\n$$",
      "The direction of motion is critical because it determines how the magnetic flux through the coil changes. For example, moving a coil parallel to the magnetic field lines will not change the flux and will induce no EMF, whereas moving it perpendicular to the lines will induce an EMF. Therefore, the direction of motion has a significant effect."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9908,
        "content": [
          "Coil with larger number of turns produce greater induced electromotive forces."
        ],
        "isCorrect": false
      },
      {
        "id": 9909,
        "content": [
          "Moving a magnet relative to the coil and the coil relative to the magnet with equal speed will produce the same electromotive force."
        ],
        "isCorrect": false
      },
      {
        "id": 9910,
        "content": [
          "The magnitude of the induced electromotive force is directly proportional to the relative velocity between the two."
        ],
        "isCorrect": false
      },
      {
        "id": 9911,
        "content": [
          "The direction in which the coil moves relative to the magnetic field does not have any effect on the induced electromotive force."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2488,
    "content": [
      "A student wants to measure the length and height of the school laboratory. There are Vernier calipers, meter stick, micrometer screw gauge and meter tape measuring instruments in the laboratory. Which one of the following measuring instrument and unit is appropriate for the measurement?"
    ],
    "explanation": [
      "To measure large distances like the dimensions of a room, a meter tape is the most appropriate and convenient tool. Vernier calipers and micrometers are used for very small and precise measurements. A meter stick could be used but is less practical than a tape for room-sized lengths. The standard unit for architectural dimensions is the meter."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9960,
        "content": [
          "Meter tape and meter"
        ],
        "isCorrect": true
      },
      {
        "id": 9961,
        "content": [
          "Vernier calipers and millimeter"
        ],
        "isCorrect": false
      },
      {
        "id": 9962,
        "content": [
          "Micrometer screw gauge and millimeter"
        ],
        "isCorrect": false
      },
      {
        "id": 9963,
        "content": [
          "Meter stick and centimeter"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 2489,
    "content": [
      "In reporting an experimental result the collected data has to be clearly tabulated with appropriate units. Which of the following table correctly represents a data collected during an experiment?"
    ],
    "explanation": [
      "A correctly formatted data table should have clear headings for each column that include the name of the quantity and its unit in parentheses, for example, \"Voltage (V)\". The data entries in the columns should be numerical values only, without repeating the units in each cell. Table C follows these conventions correctly, using Volts (V) for voltage and Amperes (A) for current."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9964,
        "content": [
          "images/physics/year_2013/q22c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 9965,
        "content": [
          "images/physics/year_2013/q22c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 9966,
        "content": [
          "images/physics/year_2013/q22c3_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 9967,
        "content": [
          "images/physics/year_2013/q22c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 2490,
    "content": [
      "A 10 N force is applied in the direction of North-East, which of the following graphical representation of the force is correct? (Assume the lengths of all arrows are equal and the paper head points towards North)"
    ],
    "explanation": [
      "With North being the top of the page and East being the right, the North-East direction is diagonally upwards and to the right, at a 45-degree angle between North and East. The arrow in option A correctly points in this direction."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9968,
        "content": [
          "images/physics/year_2013/q23c1_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 9969,
        "content": [
          "images/physics/year_2013/q23c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 9970,
        "content": [
          "images/physics/year_2013/q23c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 9971,
        "content": [
          "images/physics/year_2013/q23c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 2491,
    "content": [
      "Two vectors of magnitude 8 units in the direction of East and the second vector of magnitude 6 units in the direction of North are given. If you add the two vectors using graphical method, which graph represents the resultant of the two vectors?"
    ],
    "explanation": [
      "To add vectors graphically, the \"head-to-tail\" method is used. First, draw the 8-unit vector pointing East (to the right). Then, from the head (tip) of this first vector, draw the 6-unit vector pointing North (upwards). The resultant vector is drawn from the tail (start) of the first vector to the head of the second vector. Graph A correctly illustrates this process and the resulting vector."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9972,
        "content": [
          "images/physics/year_2013/q24c1_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 9973,
        "content": [
          "images/physics/year_2013/q24c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 9974,
        "content": [
          "images/physics/year_2013/q24c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 9975,
        "content": [
          "images/physics/year_2013/q24c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Vectors"
  },
  {
    "id": 2492,
    "content": [
      "Which of the following pair of vectors are collinear?"
    ],
    "explanation": [
      "Two vectors are collinear if one is a scalar multiple of the other. In option A, the second vector $$\\begin{bmatrix} -4 \\\\ -2 \\end{bmatrix}$$ can be obtained by multiplying the first vector $$\\begin{bmatrix} 4 \\\\ 2 \\end{bmatrix}$$ by the scalar -1. Since they are scalar multiples, they are collinear (they lie on the same line but point in opposite directions)."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9976,
        "content": [
          "$$\n\\begin{bmatrix} 4 \\\\ 2 \\end{bmatrix}, \\begin{bmatrix} -4 \\\\ -2 \\end{bmatrix}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 9977,
        "content": [
          "$$\n\\begin{bmatrix} 4 \\\\ 2 \\end{bmatrix}, \\begin{bmatrix} -4 \\\\ 2 \\end{bmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9978,
        "content": [
          "$$\n\\begin{bmatrix} 4 \\\\ 2 \\end{bmatrix}, \\begin{bmatrix} 4 \\\\ -2 \\end{bmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9979,
        "content": [
          "$$\n\\begin{bmatrix} -4 \\\\ 2 \\end{bmatrix}, \\begin{bmatrix} 4 \\\\ 2 \\end{bmatrix}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 2493,
    "content": [
      "Instantaneous velocity is different from average velocity in that; instantaneous velocity is"
    ],
    "explanation": [
      "Average velocity is the total displacement divided by the total time interval. Instantaneous velocity, by contrast, is the velocity of an object at a single, specific point in time. It is the limit of the average velocity as the time interval approaches zero."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9980,
        "content": [
          "the velocity at a particular instant of time."
        ],
        "isCorrect": true
      },
      {
        "id": 9981,
        "content": [
          "in opposite direction to the displacement of the moving object."
        ],
        "isCorrect": false
      },
      {
        "id": 9982,
        "content": [
          "the total displacement to the time taken."
        ],
        "isCorrect": false
      },
      {
        "id": 9983,
        "content": [
          "the average velocity during the time of acceleration."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 2494,
    "content": [
      "A car travelling at 20 m/s starts to speedup. After 5 minutes its speed is 144 m/s. What is the acceleration of the car?"
    ],
    "explanation": [
      "Acceleration is the rate of change of velocity, calculated as:\n$$\na = \\frac{\\Delta v}{\\Delta t} = \\frac{v_f - v_i}{t}\n$$",
      "First, convert the time to seconds:\n$$\nt = 5 \\text{ minutes} \\times 60 \\text{ s/min} = 300 \\text{ s}\n$$",
      "Now, calculate the acceleration:\n$$\na = \\frac{144 \\text{ m/s} - 20 \\text{ m/s}}{300 \\text{ s}}\n$$\n$$\na = \\frac{124 \\text{ m/s}}{300 \\text{ s}} \\approx 0.413 \\text{ m/s}^2\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9984,
        "content": [
          "28.8 m/s²"
        ],
        "isCorrect": false
      },
      {
        "id": 9985,
        "content": [
          "0.41 m/s²"
        ],
        "isCorrect": true
      },
      {
        "id": 9986,
        "content": [
          "24.8 m/s²"
        ],
        "isCorrect": false
      },
      {
        "id": 9987,
        "content": [
          "0.55 m/s²"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 2495,
    "content": [
      "A bullet of 200 g mass fired from a 30.0 m high building, horizontally. At the same time a bullet of the same mass fired vertically down from the same height. What can be concluded about the motion of the two bullets?"
    ],
    "explanation": [
      "The time it takes for an object to fall depends only on its initial vertical velocity and vertical displacement.",
      "The bullet fired horizontally has an initial vertical velocity of zero. The bullet \"fired vertically down\" is given an initial downward velocity.",
      "Since the second bullet starts with a downward velocity while the first one starts with none, the second bullet will reach the ground in less time. Therefore, the bullet fired horizontally takes more time to strike the ground."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9988,
        "content": [
          "A bullet fired vertically takes more time to strike the ground."
        ],
        "isCorrect": false
      },
      {
        "id": 9989,
        "content": [
          "Both bullets move with the same horizontal velocity"
        ],
        "isCorrect": false
      },
      {
        "id": 9990,
        "content": [
          "Both bullets strike the ground at the same time."
        ],
        "isCorrect": false
      },
      {
        "id": 9991,
        "content": [
          "A bullet fired horizontally takes more time to strike the ground."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 2496,
    "content": [
      "A bird flies at speed of 10m/s to south relative to the Earth. A wind blows at speed of 4m/s to East relative to the Earth. What is the speed of the bird relative to the wind?"
    ],
    "explanation": [
      "Let $$\\vec{v}{bE}$$ be the velocity of the bird relative to the Earth, and $$\\vec{v}{wE}$$ be the velocity of the wind relative to the Earth. We want to find $$\\vec{v}{bW}$$, the velocity of the bird relative to the wind.",
      "The relationship is:\n$$\n\\vec{v}{bW} = \\vec{v}{bE} - \\vec{v}{wE}\n$$",
      "Let South be the -y direction and East be the +x direction. So, $$\\vec{v}{bE} = -10 \\hat{j} \\text{ m/s}$$ and $$\\vec{v}{wE} = 4 \\hat{i} \\text{ m/s}$$.\n$$\n\\vec{v}{bW} = (-10 \\hat{j}) - (4 \\hat{i}) = -4 \\hat{i} - 10 \\hat{j} \\text{ m/s}\n$$",
      "This vector has a westward component (-x) and a southward component (-y), so the direction is South-West. The speed is the magnitude:\n$$\n|\\vec{v}{bW}| = \\sqrt{(-4)^2 + (-10)^2}\n$$\n$$\n|\\vec{v}_{bW}| = \\sqrt{16 + 100} = \\sqrt{116} \\approx 10.8 \\text{ m/s}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9992,
        "content": [
          "6m/s in the direction of North-East"
        ],
        "isCorrect": false
      },
      {
        "id": 9993,
        "content": [
          "10.8m/s in the direction of North-West"
        ],
        "isCorrect": false
      },
      {
        "id": 9994,
        "content": [
          "6m/s in the direction of South-East"
        ],
        "isCorrect": false
      },
      {
        "id": 9995,
        "content": [
          "10.8m/s in the direction of South-West"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 2501,
    "content": [
      "Ethanol has a surface tension of 22x 10⁻³ N/m and its density is of 0.789 g/cm³. The radius of the capillary tube is 15 mm, and the contact angle is 30°. Determine the height rise in the column of the capillary tube."
    ],
    "explanation": [
      "The height (h) of capillary rise is given by the formula:\n$$\nh = \\frac{2T \\cos\\theta}{\\rho g r}\n$$",
      "We must use consistent SI units. T = 22 × 10⁻³ N/m, θ = 30°, r = 15 mm = 0.015 m, g ≈ 9.8 m/s².\n$$\n\\rho = 0.789 \\text{ g/cm}^3 = 789 \\text{ kg/m}^3\n$$",
      "Substituting the values:\n$$\nh = \\frac{2 \\times (22 \\times 10^{-3} \\text{ N/m}) \\times \\cos(30^{\\circ})}{(789 \\text{ kg/m}^3) \\times (9.8 \\text{ m/s}^2) \\times (0.015 \\text{ m})}\n$$\n$$\nh \\approx \\frac{0.0381}{115.983} \\approx 0.000328 \\text{ m}\n$$",
      "Converting to millimeters: $$0.000328 \\text{ m} \\times 1000 \\text{ mm/m} \\approx 0.33 \\text{ mm}$$. The closest option is 0.32 mm."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10012,
        "content": [
          "0.32 mm"
        ],
        "isCorrect": true
      },
      {
        "id": 10013,
        "content": [
          "0.16 mm"
        ],
        "isCorrect": false
      },
      {
        "id": 10014,
        "content": [
          "3.2 mm"
        ],
        "isCorrect": false
      },
      {
        "id": 10015,
        "content": [
          "1.6 mm"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2502,
    "content": [
      "Suppose a stream of fluid flows past a solid object, which one of the following does NOT affect the laminar flow of the fluid?"
    ],
    "explanation": [
      "The nature of fluid flow (whether it is laminar or turbulent) is determined by properties of the fluid (viscosity, density) and the conditions of the flow (velocity, shape, and size of the object). The density of the solid object itself does not affect the flow pattern of the fluid around it."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10016,
        "content": [
          "Viscosity of the fluid"
        ],
        "isCorrect": false
      },
      {
        "id": 10017,
        "content": [
          "The density of the solid object"
        ],
        "isCorrect": true
      },
      {
        "id": 10018,
        "content": [
          "The shape of the solid object"
        ],
        "isCorrect": false
      },
      {
        "id": 10019,
        "content": [
          "The speed of the solid object"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2503,
    "content": [
      "Water enters a tube of non-uniform diameter. The speed of the force at the entry of area A₁ is 12 m/s and the speed becomes 4 m/s at the exit opening of area A₂. Which one is correct about the ratio of $$A_1/A_2$$?"
    ],
    "explanation": [
      "The principle of continuity for an incompressible fluid states that the product of the cross-sectional area and the fluid speed is constant:\n$$\nA_1 v_1 = A_2 v_2\n$$",
      "To find the ratio $$\\frac{A_1}{A_2}$$, we rearrange the equation:\n$$\n\\frac{A_1}{A_2} = \\frac{v_2}{v_1}\n$$",
      "Substituting the given values:\n$$\n\\frac{A_1}{A_2} = \\frac{4 \\text{ m/s}}{12 \\text{ m/s}} = \\frac{1}{3}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10020,
        "content": [
          "1/4"
        ],
        "isCorrect": false
      },
      {
        "id": 10021,
        "content": [
          "4"
        ],
        "isCorrect": false
      },
      {
        "id": 10022,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 10023,
        "content": [
          "1/3"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2507,
    "content": [
      "A sample mixture of gas contains 72% of hydrogen and 28% of Helium. What is the partial pressure of helium at an atmospheric pressure of 76 cm of mercury (Hg)?"
    ],
    "explanation": [
      "According to Dalton's Law of Partial Pressures, the partial pressure of a gas in a mixture is equal to its mole fraction (or percentage by volume) multiplied by the total pressure.",
      "Partial Pressure of Helium = (Percentage of Helium) × (Total Pressure)\n$$\nP_{He} = 0.28 \\times 76 \\text{ cm of Hg}\n$$\n$$\nP_{He} = 21.28 \\text{ cm of Hg}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_PRESSURE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10036,
        "content": [
          "33.44 cm of Hg"
        ],
        "isCorrect": false
      },
      {
        "id": 10037,
        "content": [
          "76.0 cm of Hg"
        ],
        "isCorrect": false
      },
      {
        "id": 10038,
        "content": [
          "54.72 cm of Hg"
        ],
        "isCorrect": false
      },
      {
        "id": 10039,
        "content": [
          "21.28 cm of Hg"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2509,
    "content": [
      "A car is traveling at constant velocity along a straight line. Which, statement is correct?"
    ],
    "explanation": [
      "If a car travels at a constant velocity, its acceleration is zero. According to Newton's first law, this means the net force acting on it is also zero.",
      "The displacement ($$\\Delta x$$) is given by $$ \\Delta x = v \\cdot t $$. Since v is constant, displacement increases linearly with time."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10044,
        "content": [
          "The displacement of the car increase linearly with time."
        ],
        "isCorrect": true
      },
      {
        "id": 10045,
        "content": [
          "The displacement of the car is in opposite direction."
        ],
        "isCorrect": false
      },
      {
        "id": 10046,
        "content": [
          "The net force on the car is different from zero."
        ],
        "isCorrect": false
      },
      {
        "id": 10047,
        "content": [
          "The acceleration of the car is in opposite direction."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 2516,
    "content": [
      "A wheel starts rotating at 1.2 Hz and reaches 1.8 Hz in 5 seconds. Calculate the angular displacement it covers within 5 seconds?"
    ],
    "explanation": [
      "For constant angular acceleration, the angular displacement is the average angular velocity multiplied by time:\n$$\n\\Delta\\theta = \\left(\\frac{\\omega_i + \\omega_f}{2}\\right)t\n$$",
      "First, convert the frequencies (f) to angular velocities (ω) using $$\\omega = 2\\pi f$$.\n$$\n\\omega_i = 2\\pi(1.2 \\text{ Hz}) = 2.4\\pi \\text{ rad/s}\n$$\n$$\n\\omega_f = 2\\pi(1.8 \\text{ Hz}) = 3.6\\pi \\text{ rad/s}\n$$",
      "Now, calculate the displacement:\n$$\n\\Delta\\theta = \\left(\\frac{2.4\\pi + 3.6\\pi}{2}\\right) \\times 5\\text{ s}\n$$\n$$\n\\Delta\\theta = \\left(\\frac{6.0\\pi}{2}\\right) \\times 5 = 3\\pi \\times 5 = 15\\pi \\text{ rad}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10072,
        "content": [
          "10π rad"
        ],
        "isCorrect": false
      },
      {
        "id": 10073,
        "content": [
          "3π rad"
        ],
        "isCorrect": false
      },
      {
        "id": 10074,
        "content": [
          "30π rad"
        ],
        "isCorrect": false
      },
      {
        "id": 10075,
        "content": [
          "15π rad"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  }
];

export default questions;
