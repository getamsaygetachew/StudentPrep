// StudentPrep Premium Content — complete question bank.
const questions = [
  {
    "id": 1357,
    "content": [
      "Question is based on the climate data of a hypothetical region given in the table.",
      "---",
      "What is the annual range of temperature at station \"G\"?"
    ],
    "explanation": [
      "The annual temperature range for Station \"G\" is 4°C, calculated as the difference between the highest (20°C) and lowest (16°C) monthly average temperatures."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 22,
    "groupIndex": null,
    "sharedContentId": 6,
    "sharedContent": [
      "### Climate data of a hypothetical region",
      "images/geography/year_2016/shared_1.png"
    ],
    "images": [
      "images/geography/year_2016/shared_1.png"
    ],
    "choices": [
      {
        "id": 5429,
        "content": [
          "4°C"
        ],
        "isCorrect": true
      },
      {
        "id": 5430,
        "content": [
          "2°C"
        ],
        "isCorrect": false
      },
      {
        "id": 5431,
        "content": [
          "1°C"
        ],
        "isCorrect": false
      },
      {
        "id": 5432,
        "content": [
          "3°C"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1358,
    "content": [
      "Question is based on the climate data of a hypothetical region given in the table.",
      "---",
      "Which one of the following wild animal is dominantly found in station \"Y\"?"
    ],
    "explanation": [
      "To determine which wild animal is dominantly found in station \"Y,\" we need to consider the climate data provided for station \"Y\":\n- **Temperature**: Ranges from 25°C to 33°C, indicating a warm to hot climate.\n- **Rainfall**: Significant rainfall, especially from May to October, with a peak in August (276 mm).\n\nGiven this climate:\n\n- **Crocodiles** are typically found in warm, tropical regions with abundant water sources, which matches the climate of station \"Y.\"\n- **Apes** also inhabit tropical regions but are more associated with forested areas.\n- **Zebras** are found in savannas and grasslands, which could also be a possibility given the climate.\n- **Polar bears** are found in Arctic regions with cold climates, which does not match the climate of station \"Y.\"\n\nConsidering the high rainfall and warm temperatures, **crocodiles** are the most likely dominant wild animal in station \"Y.\""
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 22,
    "groupIndex": null,
    "sharedContentId": 6,
    "sharedContent": [
      "### Climate data of a hypothetical region",
      "images/geography/year_2016/shared_1.png"
    ],
    "images": [
      "images/geography/year_2016/shared_1.png"
    ],
    "choices": [
      {
        "id": 5433,
        "content": [
          "Crocodiles"
        ],
        "isCorrect": true
      },
      {
        "id": 5434,
        "content": [
          "Apes"
        ],
        "isCorrect": false
      },
      {
        "id": 5435,
        "content": [
          "Zebras"
        ],
        "isCorrect": false
      },
      {
        "id": 5436,
        "content": [
          "Polar bears"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1359,
    "content": [
      "Question is based on the climate data of a hypothetical region given in the table.",
      "---",
      "Based on the temperature distribution, in which global pressure belt shall station 'F' be found?"
    ],
    "explanation": [
      "With relatively stable temperatures and low rainfall compared to equatorial regions, station \"F\" is most likely located in the horse latitudes, a region of high pressure."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 22,
    "groupIndex": null,
    "sharedContentId": 6,
    "sharedContent": [
      "### Climate data of a hypothetical region",
      "images/geography/year_2016/shared_1.png"
    ],
    "images": [
      "images/geography/year_2016/shared_1.png"
    ],
    "choices": [
      {
        "id": 5437,
        "content": [
          "Equatorial low"
        ],
        "isCorrect": false
      },
      {
        "id": 5438,
        "content": [
          "Polar highs"
        ],
        "isCorrect": false
      },
      {
        "id": 5439,
        "content": [
          "Horse latitude"
        ],
        "isCorrect": true
      },
      {
        "id": 5440,
        "content": [
          "Sub-tropical low"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1360,
    "content": [
      "Question is based on the climate data of a hypothetical region given in the table.",
      "---",
      "In which climate zone is station \"G\" found?"
    ],
    "explanation": [
      "Station \"G\" has cool, stable temperatures (16°C to 20°C) and significant\n rainfall, peaking in August (560 mm). These conditions are typical of a **Highland** climate, which is characterized by cooler temperatures due to higher elevation and variable rainfall patterns."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 22,
    "groupIndex": null,
    "sharedContentId": 6,
    "sharedContent": [
      "### Climate data of a hypothetical region",
      "images/geography/year_2016/shared_1.png"
    ],
    "images": [
      "images/geography/year_2016/shared_1.png"
    ],
    "choices": [
      {
        "id": 5441,
        "content": [
          "Equatorial"
        ],
        "isCorrect": false
      },
      {
        "id": 5442,
        "content": [
          "Highland"
        ],
        "isCorrect": true
      },
      {
        "id": 5443,
        "content": [
          "Tropical desert"
        ],
        "isCorrect": false
      },
      {
        "id": 5444,
        "content": [
          "Mediterranean"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1361,
    "content": [
      "Question is based on the demographic data of a hypothetical region given in the table.",
      "---",
      "What is the population growth rate of country 'R'?"
    ],
    "explanation": [
      "To calculate the population growth rate of country 'R', we can use the formula:\n$$\n\\text{Population Growth Rate} = \\left( \\frac{\\text{Birth Rate} - \\text{Death Rate} + \\text{Net Migration Rate}}{1000} \\right) \\times 100\n$$\nGiven:\n- Birth Rate (per 1000) = 31\n- Number of Deaths = 45,899\n- Total Population = 5,193,416\n- Net Migration = 113,779\n\nFirst, calculate the Death Rate (per 1000):\n$$\n\\text{Death Rate} = \\left( \\frac{45,899}{5,193,416} \\right) \\times 1000 \\approx 8.83\n$$\n\nNext, calculate the Net Migration Rate (per 1000):\n\n$$\n\\text{Net Migration Rate} = \\left( \\frac{113,779}{5,193,416} \\right) \\times 1000 \\approx 21.91\n$$\n\nNow, plug these values into the population growth rate formula:\n\n$$\n\\text{Population Growth Rate} = \\left( \\frac{31 - 8.83 + 21.91}{1000} \\right) \\times 100 \\approx 4.4\\%\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 23,
    "groupIndex": null,
    "sharedContentId": 7,
    "sharedContent": [
      "### Demographic data of a hypothetical region",
      "images/geography/year_2016/shared_2.png"
    ],
    "images": [
      "images/geography/year_2016/shared_2.png"
    ],
    "choices": [
      {
        "id": 5445,
        "content": [
          "2.6%"
        ],
        "isCorrect": false
      },
      {
        "id": 5446,
        "content": [
          "1.8%"
        ],
        "isCorrect": false
      },
      {
        "id": 5447,
        "content": [
          "3.4%"
        ],
        "isCorrect": false
      },
      {
        "id": 5448,
        "content": [
          "4.4%"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1362,
    "content": [
      "Question is based on the demographic data of a hypothetical region given in the table.",
      "---",
      "What is the sex ratio in country 'R'?"
    ],
    "explanation": [
      "To calculate the sex ratio in country 'R', we use the formula:\n\n$$\n\\text{Sex Ratio} = \\left( \\frac{\\text{Male Population}}{\\text{Female Population}} \\right) \\times 100\n$$\n\nGiven:\n\n- Male Population = 2,585,173\n- Female Population = 2,608,243\n\nPlug these values into the formula:\n\n$$\n\\text{Sex Ratio} = \\left( \\frac{2,585,173}{2,608,243} \\right) \\times 100 \\approx 99.12\n$$\n\nThis means there are approximately 99 males for every 100 females. Therefore, the correct answer is: 99/100 females"
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 23,
    "groupIndex": null,
    "sharedContentId": 7,
    "sharedContent": [
      "### Demographic data of a hypothetical region",
      "images/geography/year_2016/shared_2.png"
    ],
    "images": [
      "images/geography/year_2016/shared_2.png"
    ],
    "choices": [
      {
        "id": 5449,
        "content": [
          "99/100 females"
        ],
        "isCorrect": true
      },
      {
        "id": 5450,
        "content": [
          "95/100 females"
        ],
        "isCorrect": false
      },
      {
        "id": 5451,
        "content": [
          "101/100 females"
        ],
        "isCorrect": false
      },
      {
        "id": 5452,
        "content": [
          "100/100 females"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1363,
    "content": [
      "Question is based on the demographic data of a hypothetical region given in the table.",
      "---",
      "What is the crude death rate of country 'P'?"
    ],
    "explanation": [
      "To calculate the crude death rate of country 'P', we use the formula:\n$$\n\\text{Crude Death Rate} = \\left( \\frac{\\text{Number of Deaths}}{\\text{Total Population}} \\right) \\times 1000\n$$\n\nGiven:\n\n- Number of Deaths = 1,023,311\n- Total Population = 83,196,078\n\nPlug these values into the formula:\n$$\n\\text{Crude Death Rate} = \\left( \\frac{1,023,311}{83,196,078} \\right) \\times 1000 \\approx 12.3\n$$\n\nThis means the crude death rate is approximately 12 per 1000 people."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 23,
    "groupIndex": null,
    "sharedContentId": 7,
    "sharedContent": [
      "### Demographic data of a hypothetical region",
      "images/geography/year_2016/shared_2.png"
    ],
    "images": [
      "images/geography/year_2016/shared_2.png"
    ],
    "choices": [
      {
        "id": 5453,
        "content": [
          "9/1000"
        ],
        "isCorrect": false
      },
      {
        "id": 5454,
        "content": [
          "10/1000"
        ],
        "isCorrect": false
      },
      {
        "id": 5455,
        "content": [
          "12/1000"
        ],
        "isCorrect": true
      },
      {
        "id": 5456,
        "content": [
          "7/1000"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1364,
    "content": [
      "Question is based on the demographic data of a hypothetical region given in the table.",
      "---",
      "What is the rate of emigration in country 'Z'?"
    ],
    "explanation": [
      "To calculate the rate of emigration in country 'Z', we need to determine the proportion of emigrants relative to the total population. However, the provided data does not directly give the number of emigrants. Instead, it provides the number of immigrants and net migration.\n\nGiven:\n\n- Net Migration = 1,639,771\n- Number of Immigrants = 3,749,692\n- Total Population = 10,415,811\n\nNet migration is calculated as:\n\n- Net Migration = Number of Immigrants - Number of Emigrants\n\nRearranging to find the number of emigrants:\n\n- Number of Emigrants = Number of Immigrants - Net Migration\n- Number of Emigrants = 3,749,692 - 1,639,771 = 2,109,921\n\nNow, calculate the emigration rate:\n\n$$\n\\text{Emigration Rate} = \\left( \\frac{\\text{Number of Emigrants}}{\\text{Total Population}} \\right) \\times 100\n$$\n$$\n\\text{Emigration Rate} = \\left( \\frac{2,109,921}{10,415,811} \\right) \\times 100 \\approx 20.26\\%\n$$\n\nTherefore, the answer is: 20%"
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 23,
    "groupIndex": null,
    "sharedContentId": 7,
    "sharedContent": [
      "### Demographic data of a hypothetical region",
      "images/geography/year_2016/shared_2.png"
    ],
    "images": [
      "images/geography/year_2016/shared_2.png"
    ],
    "choices": [
      {
        "id": 5457,
        "content": [
          "24%"
        ],
        "isCorrect": false
      },
      {
        "id": 5458,
        "content": [
          "20%"
        ],
        "isCorrect": false
      },
      {
        "id": 5459,
        "content": [
          "18%"
        ],
        "isCorrect": false
      },
      {
        "id": 5460,
        "content": [
          "22%"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1365,
    "content": [
      "Question is based on the map.",
      "---",
      "If the map distance between points 'P' and 'W' is 10 cm, what is the corresponding field distance between them?"
    ],
    "explanation": [
      "The scale of the map is given as 1 cm to 2 km. This means that every 1 cm on the map corresponds to 2 km in the real world. If the distance between points 'P' and 'W' on the map is 10 cm, then the corresponding field distance is:\n$$\n10 \\, \\text{cm} \\times 2 \\, \\text{km/cm} = 20 \\, \\text{km}\n$$\nSo, the field distance between points 'P' and 'W' is 20 km."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 24,
    "groupIndex": null,
    "sharedContentId": 8,
    "sharedContent": [
      "images/geography/year_2016/shared_3_background.png"
    ],
    "images": [
      "images/geography/year_2016/shared_3_background.png"
    ],
    "choices": [
      {
        "id": 5461,
        "content": [
          "2 km"
        ],
        "isCorrect": false
      },
      {
        "id": 5462,
        "content": [
          "10 km"
        ],
        "isCorrect": false
      },
      {
        "id": 5463,
        "content": [
          "20 km"
        ],
        "isCorrect": true
      },
      {
        "id": 5464,
        "content": [
          "1 km"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1366,
    "content": [
      "Question is based on the map.",
      "---",
      "What represents the symbol indicated by the letter 'M'?"
    ],
    "explanation": [
      "The symbol at location 'M' appears to be a small square with a flag-like mark, which is a conventional map symbol for a **school**."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 24,
    "groupIndex": null,
    "sharedContentId": 8,
    "sharedContent": [
      "images/geography/year_2016/shared_3_background.png"
    ],
    "images": [
      "images/geography/year_2016/shared_3_background.png"
    ],
    "choices": [
      {
        "id": 5465,
        "content": [
          "Bridge"
        ],
        "isCorrect": false
      },
      {
        "id": 5466,
        "content": [
          "Lake"
        ],
        "isCorrect": false
      },
      {
        "id": 5467,
        "content": [
          "Plantation"
        ],
        "isCorrect": false
      },
      {
        "id": 5468,
        "content": [
          "School"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1367,
    "content": [
      "Question is based on the map.",
      "---",
      "What is the landform represented by the letter 'K'?"
    ],
    "explanation": [
      "The topographic map provided indicates contour lines and elevation values. To interpret the landform at 'K', we examine the pattern of these contours:\n- If the contour lines are close together and form a linear shape with high elevation, it likely represents a **ridge**.\n- If they form a circular pattern with increasing elevation toward the center, it signifies a **hill** or **mountain**, depending on the elevation.\n- If the lines form a U or V shape pointing uphill, it represents a **valley**.\n\nGiven the details in the map, 'K' corresponds to **Ridge**."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 24,
    "groupIndex": null,
    "sharedContentId": 8,
    "sharedContent": [
      "images/geography/year_2016/shared_3_background.png"
    ],
    "images": [
      "images/geography/year_2016/shared_3_background.png"
    ],
    "choices": [
      {
        "id": 5469,
        "content": [
          "Valley"
        ],
        "isCorrect": false
      },
      {
        "id": 5470,
        "content": [
          "Ridge"
        ],
        "isCorrect": true
      },
      {
        "id": 5471,
        "content": [
          "Hill"
        ],
        "isCorrect": false
      },
      {
        "id": 5472,
        "content": [
          "Mountain"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1368,
    "content": [
      "Question is based on the map.",
      "---",
      "What is the areal scale of the map?"
    ],
    "explanation": [
      "The linear scale is 1 cm to 2 km. Therefore, the areal scale is derived by squaring both sides, yielding $$1 \\, \\text{cm}^2$$ to $$4 \\, \\text{km}^2$$ ($$(2 \\, \\text{km})^2 = 4 \\, \\text{km}^2$$)."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 24,
    "groupIndex": null,
    "sharedContentId": 8,
    "sharedContent": [
      "images/geography/year_2016/shared_3_background.png"
    ],
    "images": [
      "images/geography/year_2016/shared_3_background.png"
    ],
    "choices": [
      {
        "id": 5473,
        "content": [
          "$$1 \\, \\text{cm}^2$$ to $$2 \\, \\text{cm}^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 5474,
        "content": [
          "$$1 \\, \\text{cm}$$ to $$4 \\, \\text{km}^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 5475,
        "content": [
          "$$1 \\, \\text{cm}^2$$ to $$4 \\, \\text{km}^2$$"
        ],
        "isCorrect": true
      },
      {
        "id": 5476,
        "content": [
          "$$1 \\, \\text{cm}$$ to $$2 \\, \\text{cm}^2$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1369,
    "content": [
      "Question is based on the map.",
      "---",
      "The type of contour line represented by the letter 'H' is:"
    ],
    "explanation": [
      "- **Index Contour:** Index contours are typically darker or thicker lines that are labeled with their elevation. They are used to make it easier to read the map.\n- **Intermediate Contour:** Intermediate contours are the regular lines between the index contours. They are thinner and usually not labeled.\n- **Supplementary Contour:** Supplementary contours are dashed or dotted lines used to show areas of relatively flat terrain where the standard contour interval would not provide enough detail.\n- **Normal Contour:** Normal contour is a general term and could refer to either index or intermediate contours.\n\n**In the map, the contour line at 'H' is a dashed line.** This indicates it's a **supplementary contour.**"
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 24,
    "groupIndex": null,
    "sharedContentId": 8,
    "sharedContent": [
      "images/geography/year_2016/shared_3_background.png"
    ],
    "images": [
      "images/geography/year_2016/shared_3_background.png"
    ],
    "choices": [
      {
        "id": 5477,
        "content": [
          "index contour."
        ],
        "isCorrect": false
      },
      {
        "id": 5478,
        "content": [
          "intermediate contour."
        ],
        "isCorrect": false
      },
      {
        "id": 5479,
        "content": [
          "supplementary contour."
        ],
        "isCorrect": true
      },
      {
        "id": 5480,
        "content": [
          "normal contour."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1370,
    "content": [
      "Question is based on the map.",
      "---",
      "What is the direction of point 'Z' from point 'X' in degrees?"
    ],
    "explanation": [
      "To determine the direction of point 'Z' from point 'X' in degrees, we need to consider the relative positions of these points on the map and relate them to compass directions.\n- Looking at the map, point 'Z' is located to the southwest of point 'X'.\n- If we consider the standard compass directions, southwest falls between south and west.\n\n**Degrees:**\n\n- North is 0 degrees or 360 degrees.\n- East is 90 degrees.\n- South is 180 degrees.\n- West is 270 degrees.\n\nSouthwest, being midway between south and west, would be approximately 225 degrees.\n$$\n\\frac{180^\\circ + 270^\\circ}{2} = 225^\\circ\n$$\nTherefore, the direction of point 'Z' from point 'X' is approximately 225 degrees."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 24,
    "groupIndex": null,
    "sharedContentId": 8,
    "sharedContent": [
      "images/geography/year_2016/shared_3_background.png"
    ],
    "images": [
      "images/geography/year_2016/shared_3_background.png"
    ],
    "choices": [
      {
        "id": 5481,
        "content": [
          "$$270^\\circ$$"
        ],
        "isCorrect": false
      },
      {
        "id": 5482,
        "content": [
          "$$225^\\circ$$"
        ],
        "isCorrect": true
      },
      {
        "id": 5483,
        "content": [
          "$$135^\\circ$$"
        ],
        "isCorrect": false
      },
      {
        "id": 5484,
        "content": [
          "$$315^\\circ$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1371,
    "content": [
      "Which soil types of Africa have high humus content?"
    ],
    "explanation": [
      "Nitosols are known for their high humus content due to their formation processes and mineral composition, which favor organic matter accumulation."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5485,
        "content": [
          "Ferrasols"
        ],
        "isCorrect": false
      },
      {
        "id": 5486,
        "content": [
          "Lixisols"
        ],
        "isCorrect": false
      },
      {
        "id": 5487,
        "content": [
          "Luvisols"
        ],
        "isCorrect": false
      },
      {
        "id": 5488,
        "content": [
          "Nitosols"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1372,
    "content": [
      "Which statement explains the size of the African population? The continent"
    ],
    "explanation": [
      "The population of the African continent is larger than that of North America."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5489,
        "content": [
          "is more populous than North America."
        ],
        "isCorrect": true
      },
      {
        "id": 5490,
        "content": [
          "is the third populous continent."
        ],
        "isCorrect": false
      },
      {
        "id": 5491,
        "content": [
          "has two-thirds of the world's population"
        ],
        "isCorrect": false
      },
      {
        "id": 5492,
        "content": [
          "has half of the population of Oceania"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1373,
    "content": [
      "Which one describes a population characteristic of southern African as compared to other regions?"
    ],
    "explanation": [
      "For the year 2020, Southern Africa had the highest crude death rate at 11 per 1000 population compared to other regions in Africa: Northern Africa (6/1000), Western Africa (10/1000), Eastern Africa (6/1000), and Central Africa (9/1000). The average for Africa overall was 8 per 1000 population."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5493,
        "content": [
          "Lowest life expectancy"
        ],
        "isCorrect": false
      },
      {
        "id": 5494,
        "content": [
          "Highest natural increase"
        ],
        "isCorrect": false
      },
      {
        "id": 5495,
        "content": [
          "Lowest immigration rate"
        ],
        "isCorrect": false
      },
      {
        "id": 5496,
        "content": [
          "Highest crude death rate"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1374,
    "content": [
      "Which one of the following describes the sex structure of the African population?"
    ],
    "explanation": [
      "The sex ratio in Sub-Saharan Africa is generally lower than the global average. This is due to factors such as higher male mortality rates (from conflict, labor migration, and health conditions) and slightly higher female birth rates in some regions. Globally, the average sex ratio at birth is around **105 male births per 100 female births.**"
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5497,
        "content": [
          "In the Sub-Saharan Africa, the sex ratio is below the world's mean."
        ],
        "isCorrect": true
      },
      {
        "id": 5498,
        "content": [
          "In Uganda, there is a balanced number of males and females."
        ],
        "isCorrect": false
      },
      {
        "id": 5499,
        "content": [
          "In the Sub-Saharan Africa, there are more males than females."
        ],
        "isCorrect": false
      },
      {
        "id": 5500,
        "content": [
          "In Guinea, the number of female births exceeds that of male births."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1375,
    "content": [
      "Which one of the following is the main disadvantage of migration in the receiving country?"
    ],
    "explanation": [
      "While diversity can be beneficial, it can also, unfortunately, result in ethnic tension if different groups struggle to integrate or if there is competition for resources or jobs."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5501,
        "content": [
          "Cultural integration"
        ],
        "isCorrect": false
      },
      {
        "id": 5502,
        "content": [
          "Reduced labor shortage"
        ],
        "isCorrect": false
      },
      {
        "id": 5503,
        "content": [
          "Ethnic tension"
        ],
        "isCorrect": true
      },
      {
        "id": 5504,
        "content": [
          "Racial interaction"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1376,
    "content": [
      "Which statement describes the concept of economic development?"
    ],
    "explanation": [
      "Economic development refers to the sustained development of the material well-being of society. This goes beyond just an increase in the quantity of goods produced.\n\nIt focuses on both qualitative and quantitative development of a country’s economy. Economic development enables people to be more educated, healthier, and endowed with good access to quality housing, better sanitation, and employment opportunities. This directly translates to an improvement in their living conditions."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5505,
        "content": [
          "Increase in the amount of total agricultural production"
        ],
        "isCorrect": false
      },
      {
        "id": 5506,
        "content": [
          "Improvement in the living condition of the people"
        ],
        "isCorrect": true
      },
      {
        "id": 5507,
        "content": [
          "Increase in the total amount of manufactured goods"
        ],
        "isCorrect": false
      },
      {
        "id": 5508,
        "content": [
          "Progress in the process of industrial domestic product"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1377,
    "content": [
      "Which one of the following is a good opportunity for the development of the African continent? The availability of"
    ],
    "explanation": [
      "Africa is described as a resourceful region in the world. The continent possesses huge mineral wealth due to its long geological history, including resources like petroleum, natural gas, coal, uranium, iron, copper, zinc, tin, phosphates, platinum, and cobalt."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5509,
        "content": [
          "skilled labor force"
        ],
        "isCorrect": false
      },
      {
        "id": 5510,
        "content": [
          "political stability"
        ],
        "isCorrect": false
      },
      {
        "id": 5511,
        "content": [
          "foreign aid and loan"
        ],
        "isCorrect": false
      },
      {
        "id": 5512,
        "content": [
          "abundant natural resources"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1378,
    "content": [
      "Which one shows the agricultural production of Africa?"
    ],
    "explanation": [
      "Africa is described as lying mainly within the tropical zone, which naturally lends itself to the production of tropical crops.\n\nSeveral agricultural exports from Africa that are often tropical or grown in warm climates, including coffee, tea, palm oil and cotton products, as well as flowers and chat. These are often demanded in world markets."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ECONOMIC_AND_CULTURAL_ACTIVITIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5513,
        "content": [
          "Africa is rich in tropical crops demanded in world markets."
        ],
        "isCorrect": true
      },
      {
        "id": 5514,
        "content": [
          "The continent produces huge amounts of temperate zone crops."
        ],
        "isCorrect": false
      },
      {
        "id": 5515,
        "content": [
          "It is dominated by the production of commercial crops."
        ],
        "isCorrect": false
      },
      {
        "id": 5516,
        "content": [
          "It is mainly carried out through irrigation systems."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1379,
    "content": [
      "What is the effect of latitude on ecosystem diversity? Ecosystem diversity"
    ],
    "explanation": [
      "Regions near the equator receive more direct solar radiation throughout the year, resulting in higher temperatures and generally higher rainfall in some zones like the tropical wet regions. These conditions support highly diverse ecosystems such as tropical rainforests with a large number of plant and animal species.\n\nAs we move away from the equator towards higher latitudes, the angle of the sun's rays becomes more oblique, leading to lower average temperatures and significant seasonal variations in temperature and daylight hours.\n\nIn the high-latitude zones like the polar regions and the tundra, there are extremely cold winters and cool summers with limited growing seasons. These harsh conditions support less diverse ecosystems with specialized plant and animal life adapted to the cold."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5517,
        "content": [
          "increases as we go from the equator to the poles."
        ],
        "isCorrect": false
      },
      {
        "id": 5518,
        "content": [
          "decreases from the poles towards the equator."
        ],
        "isCorrect": false
      },
      {
        "id": 5519,
        "content": [
          "remains similar wherever we go mainly due to the effect of altitude."
        ],
        "isCorrect": false
      },
      {
        "id": 5520,
        "content": [
          "decreases gradually when we travel from the equator to Tundra."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1380,
    "content": [
      "Which statement refers to the trends of population growth of the world?"
    ],
    "explanation": [
      "Historically, the domestication of animals—along with the broader agricultural revolution—was a turning point for human societies.\n\nBefore this shift, human populations remained relatively small and stable due to the limitations of hunter‐gatherer lifestyles. With domestication, people could settle, produce surplus food, and support larger communities, leading to an increase in population."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5521,
        "content": [
          "The total number of human population was about 4 billion at the beginning of the 1900s."
        ],
        "isCorrect": false
      },
      {
        "id": 5522,
        "content": [
          "Population growth was quite low before 5000BC mainly because of war and use of contraceptives."
        ],
        "isCorrect": false
      },
      {
        "id": 5523,
        "content": [
          "Rapid population growth was recorded for the first time when humans started to domesticate animals."
        ],
        "isCorrect": true
      },
      {
        "id": 5524,
        "content": [
          "Population growth has been constantly increasing since 5000BC because of economic diversification."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1381,
    "content": [
      "Which physical factor positively influences the distribution of human population?"
    ],
    "explanation": [
      "Optimum temperature and rainfall conditions support agriculture and water availability, leading to higher population densities."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5525,
        "content": [
          "Expansion of industrial development"
        ],
        "isCorrect": false
      },
      {
        "id": 5526,
        "content": [
          "Optimum temperature and rainfall"
        ],
        "isCorrect": true
      },
      {
        "id": 5527,
        "content": [
          "High natural increase of human population"
        ],
        "isCorrect": false
      },
      {
        "id": 5528,
        "content": [
          "High relief with very high humidity"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1382,
    "content": [
      "Which one of the following describes the level of urbanization in the world?"
    ],
    "explanation": [
      "North America has the highest percentage of urban population, followed by Europe."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5529,
        "content": [
          "Africa has higher urban population than other developing regions."
        ],
        "isCorrect": false
      },
      {
        "id": 5530,
        "content": [
          "Developing regions have higher urban population than the world's average."
        ],
        "isCorrect": false
      },
      {
        "id": 5531,
        "content": [
          "Japan has the highest percentage of urban population."
        ],
        "isCorrect": false
      },
      {
        "id": 5532,
        "content": [
          "Europe has the second highest percentage of urban population."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1383,
    "content": [
      "Among the following zones of Ethiopia, which one is densely populated?"
    ],
    "explanation": [
      "When population densities are considered in terms of zones, the variation of population density in Ethiopia is generally greater than the differences among the regions.\n\nSome of the zones with very high densities are Gedeo, Kambata, Guraghe, Wolayta and Hadiya; where densities exceed 300 persons per km².\n\nOn the other hand, peripheral zones such as Kamashi, and Metekel have population densities of less than 20 persons/ km²."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5533,
        "content": [
          "East Hararge"
        ],
        "isCorrect": false
      },
      {
        "id": 5534,
        "content": [
          "Gedeo"
        ],
        "isCorrect": true
      },
      {
        "id": 5535,
        "content": [
          "Asossa"
        ],
        "isCorrect": false
      },
      {
        "id": 5536,
        "content": [
          "Agnewak"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1384,
    "content": [
      "What will happen by 2030 if the current population growth rate of Ethiopia continues in the same trend?"
    ],
    "explanation": [
      "Ethiopia's population in 2020 was estimated to be 114.9 million with a growth rate of about 2.6 percent. This is one of the fastest-growing populations in the world.\n\nContinuing this rapid population growth will lead to a significant increase in the total population size by 2030.\n\nRapid population growth in Ethiopia leads to many challenges, including increased demand for food, environmental degradation, increasing scarcity of freshwater, and the need to provide adequate education and healthcare."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5537,
        "content": [
          "The size of the population will be quadrupled."
        ],
        "isCorrect": false
      },
      {
        "id": 5538,
        "content": [
          "The population density will remain the same."
        ],
        "isCorrect": false
      },
      {
        "id": 5539,
        "content": [
          "The population will be evenly distributed across the country."
        ],
        "isCorrect": false
      },
      {
        "id": 5540,
        "content": [
          "The population will exert pressure on the available infrastructure."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1385,
    "content": [
      "Which economic system is criticized for allowing some groups to accumulate huge wealth and play a decisive role in the economy?"
    ],
    "explanation": [
      "The free market economic system is criticized for allowing some groups to accumulate huge wealth and play a decisive role in the economy.\n\nKarl Marx argued that in the capitalist economic system, which is closely related to the free market, production is aimed at the accumulation of capital, not necessarily at meeting people's needs. This system can lead to an unequal distribution of resources where a capitalist or landowning class holds significant control, potentially resulting in poverty and hunger for others."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ECONOMIC_AND_CULTURAL_ACTIVITIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5541,
        "content": [
          "Command"
        ],
        "isCorrect": false
      },
      {
        "id": 5542,
        "content": [
          "Free market"
        ],
        "isCorrect": true
      },
      {
        "id": 5543,
        "content": [
          "Mixed"
        ],
        "isCorrect": false
      },
      {
        "id": 5544,
        "content": [
          "Traditional"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1386,
    "content": [
      "What is the main task of the World Trade Organization?"
    ],
    "explanation": [
      "The **World Trade Organization (WTO)** is an international body that regulates global trade by ensuring that trade flows as smoothly, predictably, and freely as possible.\n\nIt provides a **framework for negotiating trade agreements**, enforces rules, and resolves disputes between member countries. Its main role is to oversee and enforce the rules established in international trade agreements to promote free trade and reduce barriers such as tariffs and quotas."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ECONOMIC_AND_CULTURAL_ACTIVITIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5545,
        "content": [
          "It enforces regulations related to free trade agreements."
        ],
        "isCorrect": true
      },
      {
        "id": 5546,
        "content": [
          "It provides a framework on how to produce exportable items."
        ],
        "isCorrect": false
      },
      {
        "id": 5547,
        "content": [
          "It practically protects professional workers' rights."
        ],
        "isCorrect": false
      },
      {
        "id": 5548,
        "content": [
          "It directly puts sanctions in a sovereign country when it violates laws"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1387,
    "content": [
      "What is the method of extracting metallic minerals from soil called?"
    ],
    "explanation": [
      "**Surface mining** is the method of extracting metallic minerals from the soil by removing the top layers of earth. It is commonly used for minerals like gold, copper, and iron that are located near the surface.\n\nOther mining methods, such as **quarrying**, are mainly used for non-metallic materials like limestone, while **placer mining** is used for extracting minerals from riverbeds, and **strip mining** is mainly used for coal extraction."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5549,
        "content": [
          "Quarrying"
        ],
        "isCorrect": false
      },
      {
        "id": 5550,
        "content": [
          "Placer mining"
        ],
        "isCorrect": false
      },
      {
        "id": 5551,
        "content": [
          "Strip mining"
        ],
        "isCorrect": false
      },
      {
        "id": 5552,
        "content": [
          "Surface mining"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1388,
    "content": [
      "What is the major cause of Africa being unable to exploit its potential resources?"
    ],
    "explanation": [
      "Conflicts over resources, which hinder exploitation and development, are frequently are often linked to political instability.\n\nExamples include conflicts over land, water, and minerals in various parts of Africa. These conflicts can escalate into violence, causing environmental degradation and deterioration of livelihoods."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5553,
        "content": [
          "Inappropriate allocation of resources"
        ],
        "isCorrect": false
      },
      {
        "id": 5554,
        "content": [
          "Unfavorable climate"
        ],
        "isCorrect": false
      },
      {
        "id": 5555,
        "content": [
          "Inadequate revenue from resources"
        ],
        "isCorrect": false
      },
      {
        "id": 5556,
        "content": [
          "Political instability"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1389,
    "content": [
      "Which continent is included in the Eurasian plate?"
    ],
    "explanation": [
      "The Eurasian plate includes Europe and most of Asia."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5557,
        "content": [
          "North Africa"
        ],
        "isCorrect": false
      },
      {
        "id": 5558,
        "content": [
          "Australia"
        ],
        "isCorrect": false
      },
      {
        "id": 5559,
        "content": [
          "Part of Asia"
        ],
        "isCorrect": true
      },
      {
        "id": 5560,
        "content": [
          "Part of South America"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1390,
    "content": [
      "Which landmass is formed through the convergence of two oceanic plates?"
    ],
    "explanation": [
      "Convergent plate boundaries, where two plates move towards each other, the denser plate is forced under the less dense one (subduction). This occurs when oceanic crust meets continental crust and when oceanic crust meets another oceanic crust.\n\nIf two oceanic plates converge, subduction of one under the other may produce an arc of volcanic islands. The Mariana Islands of the western Pacific Ocean were formed this way."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5561,
        "content": [
          "The Mariana volcanic feature"
        ],
        "isCorrect": true
      },
      {
        "id": 5562,
        "content": [
          "The Himalayas mountain"
        ],
        "isCorrect": false
      },
      {
        "id": 5563,
        "content": [
          "The East African rift valley"
        ],
        "isCorrect": false
      },
      {
        "id": 5564,
        "content": [
          "The San Andreas Fault"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1391,
    "content": [
      "What is the principal agent for the chemical weathering of rocks?"
    ],
    "explanation": [
      "Water is the most important agent of chemical weathering. Rainwater is not pure and dissolves substances like oxygen and carbon dioxide as it falls through the atmosphere.\n\nThis dissolved oxygen can cause minerals like iron to rust, making them weak. Rainwater containing carbonic acid can dissolve minerals with carbonates, such as limestone."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5565,
        "content": [
          "Glacier"
        ],
        "isCorrect": false
      },
      {
        "id": 5566,
        "content": [
          "Rain water"
        ],
        "isCorrect": true
      },
      {
        "id": 5567,
        "content": [
          "Thermal expansion"
        ],
        "isCorrect": false
      },
      {
        "id": 5568,
        "content": [
          "Cold temperature"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1392,
    "content": [
      "Which one of the following country is found in the 'ring of fire' zone?"
    ],
    "explanation": [
      "Earthquake belt circles the Pacific Ocean along the mountainous west coasts of North and South America and runs through the island areas of Asia. This belt is also called the Circum-Pacific Belt or the Ring of Fire.\n\nPeru is located on the west coast of South America, which is part of the mountainous region identified within the Ring of Fire."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5569,
        "content": [
          "Norway"
        ],
        "isCorrect": false
      },
      {
        "id": 5570,
        "content": [
          "Brazil"
        ],
        "isCorrect": false
      },
      {
        "id": 5571,
        "content": [
          "United Kingdom"
        ],
        "isCorrect": false
      },
      {
        "id": 5572,
        "content": [
          "Peru"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1393,
    "content": [
      "Which statement shows the trend of world climate change?"
    ],
    "explanation": [
      "The average temperature of the Earth has been increasing for many years, and this is called global warming.\n\nThe average global surface temperature has warmed 0.80°C in the past century and 0.60°C in the past three decades. The IPCC has also projected further increases in mean global temperatures if greenhouse gas emissions continue to rise."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_CHANGE_IMPACTS_AND_SOLUTIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5573,
        "content": [
          "Temperature has declined in temperate regions since the 1970s."
        ],
        "isCorrect": false
      },
      {
        "id": 5574,
        "content": [
          "Precipitation has increased all over the globe since the 1980s."
        ],
        "isCorrect": false
      },
      {
        "id": 5575,
        "content": [
          "The average global temperature has increased over the past century."
        ],
        "isCorrect": true
      },
      {
        "id": 5576,
        "content": [
          "The global climate fluctuates at the same rate."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1394,
    "content": [
      "Which one is the effect of climate change in the tropical parts of the world? Increasing"
    ],
    "explanation": [
      "Climate change is associated with decreasing rainfall trends in tropical and sub-tropical areas, which can lead to extreme climatic events such as droughts. Tropical areas are experiencing the largest comparative extreme climatic changes."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_CHANGE_IMPACTS_AND_SOLUTIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5577,
        "content": [
          "predictable rainfall"
        ],
        "isCorrect": false
      },
      {
        "id": 5578,
        "content": [
          "crop yield"
        ],
        "isCorrect": false
      },
      {
        "id": 5579,
        "content": [
          "snow covers"
        ],
        "isCorrect": false
      },
      {
        "id": 5580,
        "content": [
          "frequency of drought"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1395,
    "content": [
      "What are non-renewable resources? They are"
    ],
    "explanation": [
      "Non-renewable resources are finite and will eventually deplete over time as they are used, such as fossil fuels."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5581,
        "content": [
          "replaceable resources if human beings utilize them properly."
        ],
        "isCorrect": false
      },
      {
        "id": 5582,
        "content": [
          "resources that replenish themselves quickly."
        ],
        "isCorrect": false
      },
      {
        "id": 5583,
        "content": [
          "resources evenly distributed across the earth’s surface."
        ],
        "isCorrect": false
      },
      {
        "id": 5584,
        "content": [
          "rare resources that will end at some time in the future."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1396,
    "content": [
      "Which one of the following relates to the economic policies of Ethiopia?"
    ],
    "explanation": [
      "Ethiopia employs a system of governance known as **ethnic federalism**, which divides the country into regional states based on ethnic composition. Each regional state has autonomy over legislative, administrative, and fiscal affairs, allowing for decentralized economic management at the regional level."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ECONOMIC_AND_CULTURAL_ACTIVITIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5585,
        "content": [
          "Encouraging over-exploitation of fossil fuels"
        ],
        "isCorrect": false
      },
      {
        "id": 5586,
        "content": [
          "Promoting regional administration in economic management"
        ],
        "isCorrect": true
      },
      {
        "id": 5587,
        "content": [
          "Focusing on shifting urban labor force to rural-based economy"
        ],
        "isCorrect": false
      },
      {
        "id": 5588,
        "content": [
          "Emphasizing on an economic system fully controlled by the state"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1397,
    "content": [
      "In which geological Era is the rift valley of Ethiopia formed?"
    ],
    "explanation": [
      "In the Tertiary Period, the uplifting that began in the Cretaceous Period of the Mesozoic Era continued and reached its maximum height.\n\nIn Ethiopia and the Horn it formed huge blocks of dome over the greater part of the region. As the uplifting continued through time, great cracks opened in the crust and resulted in the pouring out of extensive basaltic lava (known as the Trappean lava series).\n\nAs the cracking and faulting continued during the period, it formed the Great East African Rift Valley System – of which the Ethiopian Rift Valley System is part."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5589,
        "content": [
          "The Paleozoic Era"
        ],
        "isCorrect": false
      },
      {
        "id": 5590,
        "content": [
          "The Mesozoic Era"
        ],
        "isCorrect": false
      },
      {
        "id": 5591,
        "content": [
          "The Cenozoic Era"
        ],
        "isCorrect": true
      },
      {
        "id": 5592,
        "content": [
          "The Precambrian Era"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1398,
    "content": [
      "Which part of the earth's physical environment is referred to as the 'life zone'?"
    ],
    "explanation": [
      "The biosphere includes all living organisms and their interactions with the environment."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5593,
        "content": [
          "The atmosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 5594,
        "content": [
          "The biosphere"
        ],
        "isCorrect": true
      },
      {
        "id": 5595,
        "content": [
          "The lithosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 5596,
        "content": [
          "The hydrosphere"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1399,
    "content": [
      "Which one of the following is the basic characteristic of metamorphic rock?"
    ],
    "explanation": [
      "The basic characteristic of metamorphic rock is that it is formed from existing rocks that have been transformed by heat or pressure."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5597,
        "content": [
          "It is produced from igneous rock through pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 5598,
        "content": [
          "It is mostly created when lava freezes."
        ],
        "isCorrect": false
      },
      {
        "id": 5599,
        "content": [
          "It is composed of newly-deposited soil particles."
        ],
        "isCorrect": false
      },
      {
        "id": 5600,
        "content": [
          "It is produced from sedimentary rock through cooling."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1400,
    "content": [
      "Which soil type is found in an area where evaporation is high?"
    ],
    "explanation": [
      "Solonchaks are soils that develop in areas with high evaporation and low precipitation, leading to the accumulation of salts near the surface.\n\nThese soils are typically found in arid and semi-arid regions where evaporation exceeds precipitation, causing capillary rise of groundwater that deposits salts as the water evaporates."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5601,
        "content": [
          "Nitosols"
        ],
        "isCorrect": false
      },
      {
        "id": 5602,
        "content": [
          "Solanchaks"
        ],
        "isCorrect": true
      },
      {
        "id": 5603,
        "content": [
          "Vertisols"
        ],
        "isCorrect": false
      },
      {
        "id": 5604,
        "content": [
          "Cambisols"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1401,
    "content": [
      "Where is the highest mean annual temperature recorded?"
    ],
    "explanation": [
      "The highest temperature i.e. over 45⁰C is recorded in the Danakil Depression, the hottest place of Ethiopia."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5605,
        "content": [
          "The Dallol depression"
        ],
        "isCorrect": true
      },
      {
        "id": 5606,
        "content": [
          "The Baro lowlands"
        ],
        "isCorrect": false
      },
      {
        "id": 5607,
        "content": [
          "The Elkeri plains"
        ],
        "isCorrect": false
      },
      {
        "id": 5608,
        "content": [
          "The Ghibe lowlands"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1402,
    "content": [
      "Which part of Ethiopia is in high drought probability zone?"
    ],
    "explanation": [
      "The Bereha-zone areas, which include the Afar lowlands (Danakil depression), are characterized by a hot arid climate with average annual rainfall of less than 400 mm and average annual temperature over 30°C. Evapotranspiration tends to exceed precipitation in such dry environments."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5609,
        "content": [
          "Gojjam"
        ],
        "isCorrect": false
      },
      {
        "id": 5610,
        "content": [
          "Wellega"
        ],
        "isCorrect": false
      },
      {
        "id": 5611,
        "content": [
          "Afar"
        ],
        "isCorrect": true
      },
      {
        "id": 5612,
        "content": [
          "Guji"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1403,
    "content": [
      "Which physical element is the base to conduct a regional study?"
    ],
    "explanation": [
      "Climate is a crucial physical factor that influences various aspects of a region. It plays a significant role in the distribution of flora and fauna, agricultural activities, and the availability of materials for shelter and clothing."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5613,
        "content": [
          "Religion"
        ],
        "isCorrect": false
      },
      {
        "id": 5614,
        "content": [
          "Culture"
        ],
        "isCorrect": false
      },
      {
        "id": 5615,
        "content": [
          "Climate"
        ],
        "isCorrect": true
      },
      {
        "id": 5616,
        "content": [
          "Language"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1404,
    "content": [
      "Which statement describes the equatorial rainforest region?"
    ],
    "explanation": [
      "The equatorial rainforest is characterized by consistently high rainfall throughout the year, supporting its dense vegetation."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5617,
        "content": [
          "It forms a continuous belt around the world."
        ],
        "isCorrect": false
      },
      {
        "id": 5618,
        "content": [
          "It receives high amount of rainfall throughout the year."
        ],
        "isCorrect": true
      },
      {
        "id": 5619,
        "content": [
          "Its annual range of temperature exceeds the daily range."
        ],
        "isCorrect": false
      },
      {
        "id": 5620,
        "content": [
          "It is dominated by deciduous forests."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1405,
    "content": [
      "Which one explains about the lowlands of Ethiopia?"
    ],
    "explanation": [
      "Kobar sink, located in the Afar region, represents the lowest point in Ethiopia's landscape.\n\nAltitude varies from about 116 meters below mean sea level at the Dallol depression (Kobar sink) to 4620 m above mean sea level (a.m.s.l.) at Ras Dashen in the Semein mountain system."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5621,
        "content": [
          "They are found in between 1000-2000 m heights."
        ],
        "isCorrect": false
      },
      {
        "id": 5622,
        "content": [
          "Lowlands are situated at the center of the country."
        ],
        "isCorrect": false
      },
      {
        "id": 5623,
        "content": [
          "Tekeze occupies the floor of the rift valley."
        ],
        "isCorrect": false
      },
      {
        "id": 5624,
        "content": [
          "Kobar sink is the lowest place in the country."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1406,
    "content": [
      "What characterizes the physical environment of the Tundra Region?"
    ],
    "explanation": [
      "The tundra region is characterized by extremely low temperatures, a short growing season, and minimal precipitation, which mostly falls as snow.\n\nThe soil remains frozen for most of the year (permafrost), and vegetation is limited to low-growing plants like mosses, lichens, and shrubs."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5625,
        "content": [
          "It is known for its low temperature and rainfall throughout the year."
        ],
        "isCorrect": true
      },
      {
        "id": 5626,
        "content": [
          "It is a densely populated region where Eskimos and Lapps are found."
        ],
        "isCorrect": false
      },
      {
        "id": 5627,
        "content": [
          "In area of low snow cover, tall plants grow during the summer season."
        ],
        "isCorrect": false
      },
      {
        "id": 5628,
        "content": [
          "It is found both in the northern and southern hemispheres."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1407,
    "content": [
      "What is the effect of advancement in transport and communication on the location of economic activities?"
    ],
    "explanation": [
      "Efficient transportation networks and communication systems reduce the friction of distance, allowing for the timely delivery of perishable goods to wider markets.\n\nThis overcomes a significant geographical constraint that previously dictated the location of certain economic activities, particularly agriculture and related industries, closer to consumption centers."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ECONOMIC_AND_CULTURAL_ACTIVITIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5629,
        "content": [
          "It encourages people to deliver their goods and services in person."
        ],
        "isCorrect": false
      },
      {
        "id": 5630,
        "content": [
          "It enables delivery and sale of perishable goods at a reasonable time."
        ],
        "isCorrect": true
      },
      {
        "id": 5631,
        "content": [
          "It enforces the establishment of industries where raw materials found."
        ],
        "isCorrect": false
      },
      {
        "id": 5632,
        "content": [
          "It shows how distance and time impact on the production of goods."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1408,
    "content": [
      "Which area of the world is sparsely populated mainly due to physical factor?"
    ],
    "explanation": [
      "Central Africa is sparsely populated mainly due to physical factors such as dense tropical rainforests, harsh climatic conditions (high humidity and heavy rainfall), poor soil fertility, and the presence of diseases like malaria.\n\nThese factors make large-scale human settlement and agriculture difficult, leading to low population density in many areas."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5633,
        "content": [
          "Central Africa"
        ],
        "isCorrect": true
      },
      {
        "id": 5634,
        "content": [
          "Peninsular Europe"
        ],
        "isCorrect": false
      },
      {
        "id": 5635,
        "content": [
          "East Asia"
        ],
        "isCorrect": false
      },
      {
        "id": 5636,
        "content": [
          "South Asia"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1409,
    "content": [
      "Which type of economic activities involve top-level decision making?"
    ],
    "explanation": [
      "Economic activities are grouped into five categories: primary, secondary, tertiary, quaternary, and quinary.\n\nQuinary economic activities are generally considered a subset of quaternary activities and involve high-level decision-making and scientific research skills."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ECONOMIC_AND_CULTURAL_ACTIVITIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5637,
        "content": [
          "Primary activities"
        ],
        "isCorrect": false
      },
      {
        "id": 5638,
        "content": [
          "Quinary activities"
        ],
        "isCorrect": true
      },
      {
        "id": 5639,
        "content": [
          "Tertiary activities"
        ],
        "isCorrect": false
      },
      {
        "id": 5640,
        "content": [
          "Secondary activities"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1410,
    "content": [
      "Which statement describes the concept of land use?"
    ],
    "explanation": [
      "Land management is defined as the \"proper use and protection of land resources to provide optimal benefit to growing populations\".\n\nThe functions of land are described in terms of production, waste disposal, economic asset, and cultural asset, all of which involve human activities."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ECONOMIC_AND_CULTURAL_ACTIVITIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5641,
        "content": [
          "Human activities related to land"
        ],
        "isCorrect": true
      },
      {
        "id": 5642,
        "content": [
          "Biophysical factors associated with land"
        ],
        "isCorrect": false
      },
      {
        "id": 5643,
        "content": [
          "The intensity of land in the rural areas"
        ],
        "isCorrect": false
      },
      {
        "id": 5644,
        "content": [
          "Natural factors affecting land form"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1411,
    "content": [
      "When a new global pandemic occur, less developed countries can respond by"
    ],
    "explanation": [
      "In response to a global pandemic, less developed countries often face challenges due to limited healthcare resources. One effective strategy is to allocate a significant portion of their healthcare budget to combat the crisis."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5645,
        "content": [
          "letting their people resolve the crisis by themselves."
        ],
        "isCorrect": false
      },
      {
        "id": 5646,
        "content": [
          "allocating a large proportion of their health care budget to the crisis."
        ],
        "isCorrect": true
      },
      {
        "id": 5647,
        "content": [
          "establishing modernized health centers in a short period of time."
        ],
        "isCorrect": false
      },
      {
        "id": 5648,
        "content": [
          "penalizing the people who are caught by the disease."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1412,
    "content": [
      "Which of the following is a challenge to environmental sustainability?"
    ],
    "explanation": [
      "Rapid urbanization is identified as a factor that can result in severe socioeconomic and environmental challenges. This includes rapid environmental change like land degradation, resource depletion, and air pollution."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5649,
        "content": [
          "Use of renewable energy"
        ],
        "isCorrect": false
      },
      {
        "id": 5650,
        "content": [
          "Slow growth of population"
        ],
        "isCorrect": false
      },
      {
        "id": 5651,
        "content": [
          "Environmental movements"
        ],
        "isCorrect": false
      },
      {
        "id": 5652,
        "content": [
          "Rapid urbanization"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1413,
    "content": [
      "Which environmental movement focuses on preventing human-induced damage to the natural environment?"
    ],
    "explanation": [
      "Environmental preservation is specifically defined as the strict setting aside of natural resources to prevent damage caused by contact with humans or by certain human activities such as logging, mining, hunting, and fishing.\n\nEnvironmental conservation, while allowing for some degree of industrial growth, emphasizes keeping it within sustainable bounds."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5653,
        "content": [
          "Free market environmentalism"
        ],
        "isCorrect": false
      },
      {
        "id": 5654,
        "content": [
          "Preservation and conservation"
        ],
        "isCorrect": true
      },
      {
        "id": 5655,
        "content": [
          "Light Greens"
        ],
        "isCorrect": false
      },
      {
        "id": 5656,
        "content": [
          "Popular environmentalism"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1414,
    "content": [
      "Which one is a good practice to minimize the effects of drought?"
    ],
    "explanation": [
      "Water harvesting is an effective practice to minimize the effects of drought. It involves collecting and storing rainwater for use during dry periods, helping to ensure a reliable water supply for agriculture, drinking, and other needs."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5657,
        "content": [
          "Water harvesting"
        ],
        "isCorrect": true
      },
      {
        "id": 5658,
        "content": [
          "Intercropping"
        ],
        "isCorrect": false
      },
      {
        "id": 5659,
        "content": [
          "Reducing overgrazing"
        ],
        "isCorrect": false
      },
      {
        "id": 5660,
        "content": [
          "Fallowing"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1415,
    "content": [
      "What is the importance of conducting research on an environmental problem?"
    ],
    "explanation": [
      "Research is defined as a scientific approach to study a problem and a systematic inquiry into causes or the discovery of new facts through planned and organized effort.\n\nOne of the main motivations for conducting research is explanation, which includes explaining why forces created the phenomenon in question and identifying why the phenomenon is shaped as it is."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5661,
        "content": [
          "To document the types of problems"
        ],
        "isCorrect": false
      },
      {
        "id": 5662,
        "content": [
          "To create awareness about research"
        ],
        "isCorrect": false
      },
      {
        "id": 5663,
        "content": [
          "To address varied ecological settings"
        ],
        "isCorrect": false
      },
      {
        "id": 5664,
        "content": [
          "To investigate causes of the problem"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1416,
    "content": [
      "Which sub-section of the quantitative research approaches are used to test a given geographical theory?"
    ],
    "explanation": [
      "Correlational analysis is a sub-section of quantitative research used to test a given geographical theory.\n\nIt involves analyzing the relationship between two or more variables to determine if and how they are related. This method is commonly used to test hypotheses or theories in geography, such as the relationship between climate factors and agricultural productivity."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5665,
        "content": [
          "Action research"
        ],
        "isCorrect": false
      },
      {
        "id": 5666,
        "content": [
          "Ethnographic research"
        ],
        "isCorrect": false
      },
      {
        "id": 5667,
        "content": [
          "Correlational analysis"
        ],
        "isCorrect": true
      },
      {
        "id": 5668,
        "content": [
          "Case study"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1417,
    "content": [
      "Which sphere of the earth contains important minerals?"
    ],
    "explanation": [
      "The lithosphere, consisting of the Earth's crust and upper mantle, is the primary source of minerals.\n\nThe Lithosphere is defined as the solid layer of rocks that covers the entire surface of the planet. Minerals are found within the Earth's crust, and mining is the extraction of mineral-bearing substances from the Earth's crust."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5669,
        "content": [
          "Hydrosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 5670,
        "content": [
          "Lithosphere"
        ],
        "isCorrect": true
      },
      {
        "id": 5671,
        "content": [
          "Biosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 5672,
        "content": [
          "Atmosphere"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1418,
    "content": [
      "Which type of extrusive land feature is formed by volcanism?"
    ],
    "explanation": [
      "Craters are also formed by volcanic activity, through explosions or collapse.\n\nA caldera is a large, basin-shaped depression formed after a magma chamber drains and the overlying volcanic cone collapses inward. This is a direct result of volcanic processes occurring at the Earth's surface."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5673,
        "content": [
          "Batholith"
        ],
        "isCorrect": false
      },
      {
        "id": 5674,
        "content": [
          "Sill"
        ],
        "isCorrect": false
      },
      {
        "id": 5675,
        "content": [
          "Dike"
        ],
        "isCorrect": false
      },
      {
        "id": 5676,
        "content": [
          "Caldera"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1419,
    "content": [
      "Which statement describes the process of faulting?"
    ],
    "explanation": [
      "Normal faults occur when the Earth's crust is subjected to tensional forces, which cause the crust to stretch and pull apart. This results in the hanging wall moving downward relative to the footwall. Tensional forces are typically associated with divergent plate boundaries or regions experiencing stretching of the crust."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5677,
        "content": [
          "Reverse-fault is normally associated with strong tensional forces."
        ],
        "isCorrect": false
      },
      {
        "id": 5678,
        "content": [
          "Compressional crack results in the formation of normal faulting."
        ],
        "isCorrect": false
      },
      {
        "id": 5679,
        "content": [
          "Normal faults develop under the predominant tensional forces."
        ],
        "isCorrect": true
      },
      {
        "id": 5680,
        "content": [
          "Faulting is a process which is mainly caused by human activities."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1420,
    "content": [
      "What is the type of land feature cut off from the sea by sand banks?"
    ],
    "explanation": [
      "Lagoon is defined an area of salt water separated from the sea by loose sand banks"
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5681,
        "content": [
          "Beach"
        ],
        "isCorrect": false
      },
      {
        "id": 5682,
        "content": [
          "Tombolo"
        ],
        "isCorrect": false
      },
      {
        "id": 5683,
        "content": [
          "Spit"
        ],
        "isCorrect": false
      },
      {
        "id": 5684,
        "content": [
          "Lagoon"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1421,
    "content": [
      "How is conventional rainfall formed?"
    ],
    "explanation": [
      "Conventional rainfall is formed when the ground surface is heated by the sun, causing the air above it to warm up, become less dense, and rise.\n\nAs this warm, moist air rises, it cools and condenses, forming clouds and resulting in rainfall. This type of rainfall is common in tropical regions where intense daytime heating occurs."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5685,
        "content": [
          "When moist and less dense air is forced to rise upward."
        ],
        "isCorrect": true
      },
      {
        "id": 5686,
        "content": [
          "When dry air forced to rise above a mountain."
        ],
        "isCorrect": false
      },
      {
        "id": 5687,
        "content": [
          "When cold and warm air masses meet at the front."
        ],
        "isCorrect": false
      },
      {
        "id": 5688,
        "content": [
          "When warm and dry air descend a mountain."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1422,
    "content": [
      "What is the effect of Coriolis force on wind direction? It causes"
    ],
    "explanation": [
      "The **Coriolis force** is caused by Earth's rotation and affects the movement of winds and ocean currents. It **deflects winds to the right in the Northern Hemisphere and to the left in the Southern Hemisphere**.\n- In the **Southern Hemisphere**, high-pressure systems (**anti-cyclones**) rotate **clockwise** due to this deflection.\n- Low-pressure systems (**cyclones**) rotate **counterclockwise** in the Southern Hemisphere."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5689,
        "content": [
          "winds to bend to the left in the northern hemisphere."
        ],
        "isCorrect": false
      },
      {
        "id": 5690,
        "content": [
          "winds to turn to the right in the southern hemisphere."
        ],
        "isCorrect": false
      },
      {
        "id": 5691,
        "content": [
          "anti-cyclones to move clockwise direction in the southern hemisphere."
        ],
        "isCorrect": true
      },
      {
        "id": 5692,
        "content": [
          "cyclones to move in clock wise direction in the southern hemisphere."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1423,
    "content": [
      "Which one of the following ocean current has a cooling effect on the southwestern part of Africa?"
    ],
    "explanation": [
      "Cool Benguela Currents affect the western coast of the Kalahari Desert in Africa, leading to dry conditions.\n\nCool ocean currents generally cause moisture in winds blowing over them to condense, depriving the adjacent coasts of moisture and leading to dry conditions."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5693,
        "content": [
          "The Mexican Gulf stream"
        ],
        "isCorrect": false
      },
      {
        "id": 5694,
        "content": [
          "The Benguela current"
        ],
        "isCorrect": true
      },
      {
        "id": 5695,
        "content": [
          "The Canary current"
        ],
        "isCorrect": false
      },
      {
        "id": 5696,
        "content": [
          "The Mozambique current"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1424,
    "content": [
      "Which statement explains about the pressure belts of the world?"
    ],
    "explanation": [
      "Horse latitudes or subtropical High Pressure (STH) belts are located around 30 degrees latitude. These subtropical high-pressure zones are areas of high air pressure."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5697,
        "content": [
          "Horse latitude is an area of high air pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 5698,
        "content": [
          "Doldrums is a high pressure belt."
        ],
        "isCorrect": false
      },
      {
        "id": 5699,
        "content": [
          "Sub polar is an area of high air pressure."
        ],
        "isCorrect": false
      },
      {
        "id": 5700,
        "content": [
          "Polar high is known as 'belt of calm'."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1425,
    "content": [
      "Which statement relates to theories on population growth and development?"
    ],
    "explanation": [
      "Neo-Malthusianism, derived from Malthus's arguments, considers population growth as the main cause of poverty.\n\nNeo-Malthusians see birth control as a means of checking this growth. They believe that a reduction in population will reduce social problems and alleviate human suffering, and can also lead to economic growth and improved living conditions.\n\nMalthus argued that population grows geometrically while food production increases only arithmetically, leading to population growth tending to outstrip food supply and resulting in poverty and hunger.\n\nEster Boserup offered a contrasting view. She believed that population growth is a major factor determining agricultural developments, stimulating innovation and leading to increased food production. Her hypothesis suggests that population growth can lead to development rather than being a hindrance.\n\nAccording to Marx, poverty occurs not due to overpopulation, but rather through a lack of access to the means of gaining subsistence within the capitalist system."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5701,
        "content": [
          "Malthusian theory stresses that food production exceeds population growth."
        ],
        "isCorrect": false
      },
      {
        "id": 5702,
        "content": [
          "Neo-Malthusianism asserts that socio-economic problems are solved by reducing birth rate."
        ],
        "isCorrect": true
      },
      {
        "id": 5703,
        "content": [
          "Ester Boserup believes that there is a strong linkage between poverty and population growth."
        ],
        "isCorrect": false
      },
      {
        "id": 5704,
        "content": [
          "Marxians believe that population growth causes technological development."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1426,
    "content": [
      "Which statement is about population growth control practices?"
    ],
    "explanation": [
      "Kenya was the first country in sub-Saharan Africa to view runaway population growth as a serious impediment to economic prosperity, and it became the first, in the late 1960s, to begin developing a national family-planning campaign."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5705,
        "content": [
          "India ratified a child-tax policy."
        ],
        "isCorrect": false
      },
      {
        "id": 5706,
        "content": [
          "China supports women to have large families."
        ],
        "isCorrect": false
      },
      {
        "id": 5707,
        "content": [
          "Most African countries have a one-child policy."
        ],
        "isCorrect": false
      },
      {
        "id": 5708,
        "content": [
          "Kenya encourages a national family planning policy."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1427,
    "content": [
      "Which one of the following is an indicator of social development?"
    ],
    "explanation": [
      "Female and male literacy rate are commonly used indicator of social development. Access to knowledge, measured by literacy rates, is also highlighted as a dimension in the calculation of the Human Development Index (HDI), which is a measure of human well-being and development.\n\nGross Domestic Product (GDP) and Per-capita income are defined and used as indicators of economic growth and development. They primarily focus on the quantitative increase in goods and services or average income.\n\nInfant mortality rate is presented as a measure of mortality and a widely used indicator of the general health situation in a country."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5709,
        "content": [
          "Gross Domestic Product"
        ],
        "isCorrect": false
      },
      {
        "id": 5710,
        "content": [
          "Per-capita income"
        ],
        "isCorrect": false
      },
      {
        "id": 5711,
        "content": [
          "Literacy rate"
        ],
        "isCorrect": true
      },
      {
        "id": 5712,
        "content": [
          "Infant mortality rate"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1428,
    "content": [
      "What is the effect of rapid population growth on the socio-economic progress of developing countries?"
    ],
    "explanation": [
      "Rapid population increase in developing countries puts a significant strain on resources, including the ability to provide an adequate food supply.\n\nThis can lead to inadequate food supply and combatting hunger and malnutrition becomes more difficult."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5713,
        "content": [
          "Expansion of economic choices"
        ],
        "isCorrect": false
      },
      {
        "id": 5714,
        "content": [
          "Formation of a healthy environment"
        ],
        "isCorrect": false
      },
      {
        "id": 5715,
        "content": [
          "Abundance of life sustaining goods"
        ],
        "isCorrect": false
      },
      {
        "id": 5716,
        "content": [
          "Incidence of widespread food insecurity"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1429,
    "content": [
      "According to the behavioral approach, which one is the cause of poverty?"
    ],
    "explanation": [
      "Behavioral or cultural approach to poverty emphasizes culture, behavior, and personal differences as significant sources of poverty.\n\nThis approach suggests the existence of a \"poverty culture,\" which includes a set of attitudes and behaviors that are passed down through generations and perpetuate poverty.\n\nAmong the attitudes of this poverty culture is fatalism. A weakness to change the sense of inability directly aligns with the concept of fatalism, where individuals may feel powerless to alter their circumstances and thus do not take actions that could lead to improvement."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5717,
        "content": [
          "Good performance in the work place"
        ],
        "isCorrect": false
      },
      {
        "id": 5718,
        "content": [
          "Rational attitude towards wealth"
        ],
        "isCorrect": false
      },
      {
        "id": 5719,
        "content": [
          "Weakness to change the sense of inability"
        ],
        "isCorrect": true
      },
      {
        "id": 5720,
        "content": [
          "Non-violent dispute resolution"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1430,
    "content": [
      "Globalization contributes to the economic development of developing countries mainly through"
    ],
    "explanation": [
      "Globalization fosters economic development in developing countries primarily by encouraging investment in various sectors that help reduce poverty. This includes foreign direct investment (FDI), job creation, improved infrastructure, and access to international markets, which enhance economic growth and improve living standards."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ECONOMIC_AND_CULTURAL_ACTIVITIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5721,
        "content": [
          "providing loan."
        ],
        "isCorrect": false
      },
      {
        "id": 5722,
        "content": [
          "creating high tax rates."
        ],
        "isCorrect": false
      },
      {
        "id": 5723,
        "content": [
          "extracting raw materials."
        ],
        "isCorrect": false
      },
      {
        "id": 5724,
        "content": [
          "investing on poverty reduction."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1431,
    "content": [
      "Trade imbalance occurs in developing countries when"
    ],
    "explanation": [
      "Trade imbalance occurs when the cost of a country's imports exceeds the cost of its exports. This is also known as a negative trade balance or a trade deficit.\n\nA trade imbalance happens when a country does not produce what it requires and must borrow from other countries to pay for imports."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ECONOMIC_AND_CULTURAL_ACTIVITIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5725,
        "content": [
          "the amount of import item is less than that of export item."
        ],
        "isCorrect": false
      },
      {
        "id": 5726,
        "content": [
          "the value of goods of a country's export is higher than its import."
        ],
        "isCorrect": false
      },
      {
        "id": 5727,
        "content": [
          "a country borrows money to import goods for its population."
        ],
        "isCorrect": true
      },
      {
        "id": 5728,
        "content": [
          "a country has industries owned by foreigners."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1432,
    "content": [
      "What is the type of corruption committed by a public official to make decisions by receiving money?"
    ],
    "explanation": [
      "Bribery consists of payments by individuals or firms to public officials in order to influence administrative decisions under their responsibility."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5729,
        "content": [
          "Burglary"
        ],
        "isCorrect": false
      },
      {
        "id": 5730,
        "content": [
          "Stealing"
        ],
        "isCorrect": false
      },
      {
        "id": 5731,
        "content": [
          "Theft"
        ],
        "isCorrect": false
      },
      {
        "id": 5732,
        "content": [
          "Bribery"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1433,
    "content": [
      "Which one describes the elements of weather and climate in Africa?"
    ],
    "explanation": [
      "Africa's temperature varies due to geographical features such as mountains and plateaus.\n\nHigh-altitude areas like the Ethiopian Highlands, the Atlas Mountains, and Mount Kilimanjaro experience cooler temperatures compared to lowland regions.\n\nElevation significantly affects climate by reducing temperatures as altitude increases, making it a key factor in Africa’s weather and climate patterns."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5733,
        "content": [
          "Its northern part is characterized by high rainfall throughout the year."
        ],
        "isCorrect": false
      },
      {
        "id": 5734,
        "content": [
          "Its northern part has maritime climate due to the influence of the sea."
        ],
        "isCorrect": false
      },
      {
        "id": 5735,
        "content": [
          "Its latitudinal position is the factor for the low income solar radiation."
        ],
        "isCorrect": false
      },
      {
        "id": 5736,
        "content": [
          "Its temperature is influenced by the presence of mountain and plateau."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1434,
    "content": [
      "What is the effect of the Mozambique Ocean current on the south eastern coastal areas of Africa?"
    ],
    "explanation": [
      "The south eastern coastal areas of Africa, particularly Natal and Cape Provinces in South Africa, as well as Mozambique, experience the influence of the warm Mozambique current.\n\nWarm ocean currents supply moisture to winds blowing over them, leading to rainfall on the adjacent coasts."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5737,
        "content": [
          "Freezing"
        ],
        "isCorrect": false
      },
      {
        "id": 5738,
        "content": [
          "Drying"
        ],
        "isCorrect": false
      },
      {
        "id": 5739,
        "content": [
          "Moisturizing"
        ],
        "isCorrect": true
      },
      {
        "id": 5740,
        "content": [
          "Cooling"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1435,
    "content": [
      "In which coastal areas of Africa is the tropical maritime climate located?"
    ],
    "explanation": [
      "The south eastern coastal areas of Africa experience conditions indicative of a tropical maritime influence.\n\nSpecifically, the eastern coast of South Africa, especially in Natal and Cape Provinces, as well as Mozambique, are under the strong influence of the warm Mozambique current and the warm southeast trade winds.\n\nThese factors contribute to generally high summer temperatures and significant annual rainfall in the region. Warm"
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5741,
        "content": [
          "North western"
        ],
        "isCorrect": false
      },
      {
        "id": 5742,
        "content": [
          "South western"
        ],
        "isCorrect": false
      },
      {
        "id": 5743,
        "content": [
          "North eastern"
        ],
        "isCorrect": false
      },
      {
        "id": 5744,
        "content": [
          "South eastern"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1436,
    "content": [
      "As compared to others, which climatic region of Africa shows lower seasonality?"
    ],
    "explanation": [
      "The Equatorial climate region, found in areas like the Congo Basin, experiences very high temperatures throughout the year with an average of around 26°C.\n\nThe diurnal temperature range is very low, about 3°C, and variations in monthly and daily temperatures are less pronounced compared to other tropical regions."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5745,
        "content": [
          "The Equatorial"
        ],
        "isCorrect": true
      },
      {
        "id": 5746,
        "content": [
          "The Mediterranean"
        ],
        "isCorrect": false
      },
      {
        "id": 5747,
        "content": [
          "The Tropical desert"
        ],
        "isCorrect": false
      },
      {
        "id": 5748,
        "content": [
          "The Tropical continental"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1437,
    "content": [
      "Which one of the following artificial lakes is found in Ghana?"
    ],
    "explanation": [
      "- Lake Volta is an artificial lake located in Ghana.\n- Lake Kariba is associated with the Kariba Dam on the border between Zambia and Zimbabwe.\n- Lake Nasser is formed by the Aswan High Dam in Egypt.\n- Lake Kainji is located on the Niger River in Nigeria."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5749,
        "content": [
          "Lake Kariba"
        ],
        "isCorrect": false
      },
      {
        "id": 5750,
        "content": [
          "Lake Volta"
        ],
        "isCorrect": true
      },
      {
        "id": 5751,
        "content": [
          "Lake Nasser"
        ],
        "isCorrect": false
      },
      {
        "id": 5752,
        "content": [
          "Lake Kainji"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1438,
    "content": [
      "Which type of vegetation is available in the desert areas?"
    ],
    "explanation": [
      "Deserts are characterized by a lack of precipitation for the majority of the year, which limits vegetation growth.\n\nXerophytes, or drought-resisting plants, dominate desert environments. The rainfall in tropical deserts is generally lower than 200 mm and does not allow for continuous vegetation cover.\n\nIn semi-desert and desert regions, the dominant vegetation includes short acacia, thorn bushes, succulent plants, and a few rough grasses, all of which are xerophytic.\n\nSmall leaves are an adaptation to the dry environment that helps reduce water loss through transpiration."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5753,
        "content": [
          "Vegetation having wide leaves"
        ],
        "isCorrect": false
      },
      {
        "id": 5754,
        "content": [
          "Thick and dense canopy vegetation"
        ],
        "isCorrect": false
      },
      {
        "id": 5755,
        "content": [
          "Vegetation having small-sized leaves"
        ],
        "isCorrect": true
      },
      {
        "id": 5756,
        "content": [
          "Broad-leaved evergreen trees"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1439,
    "content": [
      "In which climate region is the Gorilla typically found?"
    ],
    "explanation": [
      "Gorillas are typically found in the Equatorial rainforest. This region near the equator has high temperatures and consistent, heavy rainfall.\n\nThese conditions support dense rainforests with a great variety of plants. Gorillas live in these forests because they provide the necessary food and shelter."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5757,
        "content": [
          "The Equatorial rainforest"
        ],
        "isCorrect": true
      },
      {
        "id": 5758,
        "content": [
          "The Mediterranean climate zone"
        ],
        "isCorrect": false
      },
      {
        "id": 5759,
        "content": [
          "The Desert climate region"
        ],
        "isCorrect": false
      },
      {
        "id": 5760,
        "content": [
          "The Savanna climate zone"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1440,
    "content": [
      "Which factor significantly contributes for the African elephant to be on the verge of extinction?"
    ],
    "explanation": [
      "Poaching is the most significant factor driving African elephants toward extinction.\n\nThey are hunted illegally for their ivory tusks, which are highly valued in the black market. Despite conservation efforts and international bans on the ivory trade, poaching remains a severe threat to elephant populations in Africa."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5761,
        "content": [
          "Deforestation"
        ],
        "isCorrect": false
      },
      {
        "id": 5762,
        "content": [
          "Poaching"
        ],
        "isCorrect": true
      },
      {
        "id": 5763,
        "content": [
          "Drought"
        ],
        "isCorrect": false
      },
      {
        "id": 5764,
        "content": [
          "Wildfire"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1441,
    "content": [
      "Which one of the following geographic study is addressed by the Topical Approach?"
    ],
    "explanation": [
      "The Topical Approach in geographic study involves focusing on specific themes or categories of geographic phenomena, rather than studying all aspects of a particular region.\n\nStudying the distribution of rainfall patterns worldwide is a clear example of a topical approach, as it examines a specific element across various regions."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5765,
        "content": [
          "Studying the physical characteristics of the rift valley of Ethiopia"
        ],
        "isCorrect": false
      },
      {
        "id": 5766,
        "content": [
          "Identify the major socio-economic characteristics of African countries"
        ],
        "isCorrect": false
      },
      {
        "id": 5767,
        "content": [
          "Investigating the spatial distribution of rainfall in the world"
        ],
        "isCorrect": true
      },
      {
        "id": 5768,
        "content": [
          "Studying the economic activities and climatic conditions of Ethiopia"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1442,
    "content": [
      "Which one of the following states about Applied Geography?"
    ],
    "explanation": [
      "Applied Geography is the field of geography that focuses on using geographic knowledge, tools, and techniques to address real-world problems, particularly in socio-economic and environmental contexts.\n\nIt applies spatial analysis, geographic information systems (GIS), and other methods to tackle issues such as urban planning, transportation, public health, disaster management, and economic development."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5769,
        "content": [
          "It emphasizes on developing mathematical equations and models."
        ],
        "isCorrect": false
      },
      {
        "id": 5770,
        "content": [
          "It employs geographic knowledge to solve socio-economic problems."
        ],
        "isCorrect": true
      },
      {
        "id": 5771,
        "content": [
          "It solves geographic problems primarily using qualitative techniques."
        ],
        "isCorrect": false
      },
      {
        "id": 5772,
        "content": [
          "It focuses mainly on statistical techniques in geographical research."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1443,
    "content": [
      "What is the common area of study between geography and sociology?"
    ],
    "explanation": [
      "Geography and sociology intersect in the study of **population distribution and growth** because both fields examine how human populations are structured, how they change over time, and how they interact with the environment."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5773,
        "content": [
          "Distribution and interaction of cultures"
        ],
        "isCorrect": false
      },
      {
        "id": 5774,
        "content": [
          "Past economic activities of a society"
        ],
        "isCorrect": false
      },
      {
        "id": 5775,
        "content": [
          "Expansion of urban areas and cities"
        ],
        "isCorrect": false
      },
      {
        "id": 5776,
        "content": [
          "Distribution and growth of the population"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1444,
    "content": [
      "Which kind of town serves as a center of financial services?"
    ],
    "explanation": [
      "A **commercial town** serves as a hub for financial services, trade, and business activities. These towns are characterized by:\n\n- Presence of **banks, stock exchanges, and financial institutions**\n- Major **corporate headquarters and business centers**\n- A strong emphasis on **commerce, trade, and economic transactions**\n\nIn contrast:\n\n- **Industrial towns** focus on manufacturing and production.\n- **Mining towns** are centered around resource extraction.\n- **Market towns** primarily facilitate local trade of goods and agricultural products."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ECONOMIC_AND_CULTURAL_ACTIVITIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5777,
        "content": [
          "Industrial town"
        ],
        "isCorrect": false
      },
      {
        "id": 5778,
        "content": [
          "Mining towns"
        ],
        "isCorrect": false
      },
      {
        "id": 5779,
        "content": [
          "Market town"
        ],
        "isCorrect": false
      },
      {
        "id": 5780,
        "content": [
          "Commercial town"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1445,
    "content": [
      "Which statement describes the size of Africa?"
    ],
    "explanation": [
      "Africa is the **second-largest continent** in the world, after Asia, covering about **30.37 million km²**.\n- **Europe's area** is approximately **10.18 million km²**.\n- **Antarctica's area** is around **14 million km²**.\n\nCombined, **Europe and Antarctica** cover about **24.18 million km²**, which is smaller than Africa."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5781,
        "content": [
          "It covers about one-fourth of the world's area."
        ],
        "isCorrect": false
      },
      {
        "id": 5782,
        "content": [
          "It is the largest continent of the world."
        ],
        "isCorrect": false
      },
      {
        "id": 5783,
        "content": [
          "It is larger than Europe and Antarctica put together."
        ],
        "isCorrect": true
      },
      {
        "id": 5784,
        "content": [
          "It is about two-thirds of South America."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1446,
    "content": [
      "What makes the regions of Africa similar from the socio-economic and geopolitical points of view?"
    ],
    "explanation": [
      "African regions share similarities in **socio-economic and geopolitical aspects**, primarily due to political cooperation and integration efforts through **regional organizations** such as:\n- **African Union (AU)**: Promotes political unity and economic collaboration across Africa.\n- **Regional Economic Communities (RECs)**: Includes organizations like ECOWAS (West Africa), SADC (Southern Africa), and EAC (East Africa), which foster trade, security, and political stability."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ECONOMIC_AND_CULTURAL_ACTIVITIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5785,
        "content": [
          "They depend mainly on mechanized agriculture."
        ],
        "isCorrect": false
      },
      {
        "id": 5786,
        "content": [
          "Each region has direct access to the sea."
        ],
        "isCorrect": false
      },
      {
        "id": 5787,
        "content": [
          "In each region, about two-thirds of the population lives in urban areas."
        ],
        "isCorrect": false
      },
      {
        "id": 5788,
        "content": [
          "There is a strong political integration among the regions."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1447,
    "content": [
      "What is the major geological event that occurred during the Cenozoic Era in Africa?"
    ],
    "explanation": [
      "The Cenozoic Era is the most recent geological era, and it was a time of very significant structural, climatic, and biological events in Africa.\n\nThese events greatly resulted in the development of the very recent landforms in the Horn of Africa and Africa in general.\n\nExample in Ethiopia, the landforms are largely the result of the Cenozoic Era's tectonic and volcanic activities. These activities led to the formation of diverse highlands, plateaus, ambas, and rugged mountains, deep river gorges, and lowlands, contributing to the present-day landscape."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5789,
        "content": [
          "The formation of the present landscape of Africa"
        ],
        "isCorrect": true
      },
      {
        "id": 5790,
        "content": [
          "The formation of crystalline basement complex rocks"
        ],
        "isCorrect": false
      },
      {
        "id": 5791,
        "content": [
          "The recording of a series of denudation and peneplanation"
        ],
        "isCorrect": false
      },
      {
        "id": 5792,
        "content": [
          "The split of the super continent Pangaea"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1448,
    "content": [
      "Which typical relief feature is more dominantly found in Africa than in Europe?"
    ],
    "explanation": [
      "Plateaus are more dominantly found in Africa than in Europe.\n\nFor example, the Ethiopian Highlands are characterized as a high plateau with a central highland complex.\n\nThe Southern Africa Platform is mentioned as a major landform region that includes the Highveld, which is a portion of the South African inland plateau."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5793,
        "content": [
          "Plains"
        ],
        "isCorrect": false
      },
      {
        "id": 5794,
        "content": [
          "Plateaus"
        ],
        "isCorrect": true
      },
      {
        "id": 5795,
        "content": [
          "Mountains"
        ],
        "isCorrect": false
      },
      {
        "id": 5796,
        "content": [
          "Hills"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1449,
    "content": [
      "Which one of the following has widely been practiced as a climate change adaptation strategy in Ethiopia?"
    ],
    "explanation": [
      "Planting trees (afforestation and reforestation) is a key climate change adaptation strategy in Ethiopia.\n\nThe \"Green Legacy\" Initiative, a large-scale, government-led program in Ethiopia, is a major effort focused on tree planting to curb the effects of climate change and deforestation. This initiative aims to plant billions of seedlings across the country."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_CHANGE_IMPACTS_AND_SOLUTIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5797,
        "content": [
          "Use of mass transportation"
        ],
        "isCorrect": false
      },
      {
        "id": 5798,
        "content": [
          "Dam construction"
        ],
        "isCorrect": false
      },
      {
        "id": 5799,
        "content": [
          "Tree plantation"
        ],
        "isCorrect": true
      },
      {
        "id": 5800,
        "content": [
          "Electric car utilization"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1450,
    "content": [
      "Which statement describes the Kyoto protocol adopted in 1997?"
    ],
    "explanation": [
      "The Kyoto Protocol, adopted in 1997 and put into force in February 2005, set mandatory targets for reducing greenhouse gas emissions in countries that adopted the plan.\n\nThe overall goal was to reduce greenhouse gas emissions in developed countries by at least 5 percent below existing 1990 levels during the five-year period of 2008 through 2012."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_CHANGE_IMPACTS_AND_SOLUTIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5801,
        "content": [
          "It set compulsory goal to reduce greenhouse emission."
        ],
        "isCorrect": true
      },
      {
        "id": 5802,
        "content": [
          "It was successful in reducing global greenhouse gases."
        ],
        "isCorrect": false
      },
      {
        "id": 5803,
        "content": [
          "The USA took the lead in ratifying the agreement."
        ],
        "isCorrect": false
      },
      {
        "id": 5804,
        "content": [
          "It was ratified by every nation of the world."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1451,
    "content": [
      "On which issues of climate change have the world leaders agreed?"
    ],
    "explanation": [
      "The United Nations Framework Convention on Climate Change (UNFCCC) emphasizes mitigation, which seeks to limit climate change by reducing the emissions of greenhouse gases.\n\nThe Kyoto Protocol (1997, enforced in 2005) set mandatory targets for reducing greenhouse gas emissions for countries that adopted the plan. The overall goal was to reduce greenhouse gas emissions in developed countries by at least 5 percent below 1990 levels during 2008-2012.\n\nThe Paris Agreement (2015), adopted by virtually every nation, involved each nation setting voluntary targets for reducing emissions and reporting their progress. Participants pledged to curb emissions to minimize the rise in temperatures."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_CHANGE_IMPACTS_AND_SOLUTIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5805,
        "content": [
          "To encourage natural gas and fuel consumption"
        ],
        "isCorrect": false
      },
      {
        "id": 5806,
        "content": [
          "To conduct social forestry activities"
        ],
        "isCorrect": false
      },
      {
        "id": 5807,
        "content": [
          "To penalize countries that depends on fossil fuel"
        ],
        "isCorrect": false
      },
      {
        "id": 5808,
        "content": [
          "To reduce emission of greenhouse gases"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1452,
    "content": [
      "Which one describes the concept of sustainable development?"
    ],
    "explanation": [
      "Sustainable development is about meeting the needs of the present without compromising the ability of future generations to meet their own needs.\n\nThis concept is rooted in balancing economic development, social development, and environmental sustainability."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5809,
        "content": [
          "Realizing environmental-friendly socio-economic development"
        ],
        "isCorrect": true
      },
      {
        "id": 5810,
        "content": [
          "Improving human welfare at the expense of the environment"
        ],
        "isCorrect": false
      },
      {
        "id": 5811,
        "content": [
          "Prioritizing good governance regardless of economic development"
        ],
        "isCorrect": false
      },
      {
        "id": 5812,
        "content": [
          "Promoting a male-controlled socio-economic development"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1453,
    "content": [
      "Which of the following is categorized as a non-renewable resource?"
    ],
    "explanation": [
      "Non-renewable resources are natural resources that exist in fixed amounts and do not replace or regenerate by natural processes after use. They diminish in size and quality with excessive use.\n\nExamples of non-renewable resources include minerals and fossil fuels like petroleum and coal.\n\nThe rate of formation of these resources is very slow, so they cannot be replenished quickly once depleted."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5813,
        "content": [
          "Solar energy"
        ],
        "isCorrect": false
      },
      {
        "id": 5814,
        "content": [
          "Coal"
        ],
        "isCorrect": true
      },
      {
        "id": 5815,
        "content": [
          "Air"
        ],
        "isCorrect": false
      },
      {
        "id": 5816,
        "content": [
          "Soil"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1454,
    "content": [
      "What is the main cause of conflict over natural resources such as the River Nile?"
    ],
    "explanation": [
      "Political issues, such as disagreements over water rights and resource allocation, are the main cause of conflict over natural resources like the River Nile.\n\nCompeting interests and power dynamics among different individuals, groups, or countries are central to conflicts over renewable resources like water.\n\nThe Nile River, shared by eleven riparian countries, sees contention arising from the differing priorities and intentions of these nations."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5817,
        "content": [
          "Political"
        ],
        "isCorrect": true
      },
      {
        "id": 5818,
        "content": [
          "Administrative"
        ],
        "isCorrect": false
      },
      {
        "id": 5819,
        "content": [
          "Social"
        ],
        "isCorrect": false
      },
      {
        "id": 5820,
        "content": [
          "Legal"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1455,
    "content": [
      "Which one of the following plays a decisive role to govern natural resources sustainably?"
    ],
    "explanation": [
      "Indigenous resource management systems are effective because they understand the local environmental dynamics and encourage community involvement in sustainability.\n\nThe Gumuz people, for example, possess traditional beliefs and knowledge that guide their sustainable use and management of natural resources, viewing them as a communal heritage and the responsibility of present generations as trustees.\n\nTheir belief in \"Missa\" (poly-spirits) associated with resources ensures proper use through traditional norms and consequences for violations."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5821,
        "content": [
          "Giving exclusive rights to the government in managing resources"
        ],
        "isCorrect": false
      },
      {
        "id": 5822,
        "content": [
          "Fostering top-down decision making in resource management"
        ],
        "isCorrect": false
      },
      {
        "id": 5823,
        "content": [
          "Prioritizing the participation of males in resource management"
        ],
        "isCorrect": false
      },
      {
        "id": 5824,
        "content": [
          "Encouraging indigenous resource management systems"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1456,
    "content": [
      "What is the main characteristic of indigenous conflict resolution practices in Ethiopia?"
    ],
    "explanation": [
      "In Ethiopia, indigenous conflict resolution practices emphasize **reconciliation and harmony**.\n\nThese traditional methods focus on resolving disputes through peaceful dialogue, mediation, and the restoration of relationships rather than punitive measures.\n\nThe goal is to bring the conflicting parties back together, ensuring social cohesion and maintaining community stability."
    ],
    "year": "YEAR_2016",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5825,
        "content": [
          "Most of them are mainly based on written laws."
        ],
        "isCorrect": false
      },
      {
        "id": 5826,
        "content": [
          "Pastoralists use identical resolution mechanisms."
        ],
        "isCorrect": false
      },
      {
        "id": 5827,
        "content": [
          "The issue is concluded in reconciliation and harmony."
        ],
        "isCorrect": true
      },
      {
        "id": 5828,
        "content": [
          "It passes lengthy processes to bring about reconciliation."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2518,
    "content": [
      "Which of the following is the southern limit of the Western lowlands?"
    ],
    "explanation": [
      "The southern limit of the Western Lowlands is the **Omo-Ghibe lowlands**.\n\nThe **Western Lowlands** of Ethiopia extend geographically from western Tigray in the north up to southern Gamo and Goffa in the south, bordering Sudan and South Sudan.\n\nThis physiographic region is subdivided into four lowland units:\n2. The **Tekezze and Angereb Lowlands**, which are identified as the **most northerly lowlands**.\n3. The **Abbay Dinder Lowlands**.\n4. The **Baro-Akobo Lowlands**.\n5. The **Omo-Gibe Lowlands**.\n\nThe Omo-Gibe River drains the Southwestern Highlands southwards and ends in Lake Turkana, marking the southern extent of the Western Lowlands region."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10080,
        "content": [
          "Baro-Akobo lowlands"
        ],
        "isCorrect": false
      },
      {
        "id": 10081,
        "content": [
          "Abay-Dinder lowlands"
        ],
        "isCorrect": false
      },
      {
        "id": 10082,
        "content": [
          "Omo-Ghibe lowlands"
        ],
        "isCorrect": true
      },
      {
        "id": 10083,
        "content": [
          "Tekezze-Angereb lowlands"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2519,
    "content": [
      "Which one describes the general characteristics of Ethiopian rivers?"
    ],
    "explanation": [
      "One of the most important characteristics of Ethiopian rivers: they often **serve as boundaries, both international and domestic**.\n\nMany major rivers originate in the high central plateaus and flow toward the peripheral lowlands (contradicting Option B, which suggests origins in lowlands).\n\nDue to the rugged topography, Ethiopian rivers are characterized by **steep profiles, rapids, and waterfalls**, which means they typically experience **seasonal fluctuation in water volume** (contradicting Option C) and their use for **water transportation is extremely limited** (contradicting Option A).\n\nFor example, the Baro is cited as the only navigable river in Ethiopia, but this is not a general characteristic for the entire system."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10084,
        "content": [
          "They are very suitable for water transportation."
        ],
        "isCorrect": false
      },
      {
        "id": 10085,
        "content": [
          "Most rivers originate from lowland areas."
        ],
        "isCorrect": false
      },
      {
        "id": 10086,
        "content": [
          "They are perennial with steady volume of water."
        ],
        "isCorrect": false
      },
      {
        "id": 10087,
        "content": [
          "They serve as domestic and international boundaries."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2520,
    "content": [
      "What characterizes the inland drainage system of Ethiopia?"
    ],
    "explanation": [
      "The inland drainage system of Ethiopia consists of rivers and lakes in the Rift Valley that do not reach the sea. The Omo-Ghibe basin, which terminates in the endorheic Lake Turkana, is a major component of this system."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10088,
        "content": [
          "It drains most parts of the northwestern Ethiopia."
        ],
        "isCorrect": false
      },
      {
        "id": 10089,
        "content": [
          "It includes the river basins of the Omo-Ghibe."
        ],
        "isCorrect": true
      },
      {
        "id": 10090,
        "content": [
          "Its rivers join the Red sea during the summer season."
        ],
        "isCorrect": false
      },
      {
        "id": 10091,
        "content": [
          "It is the largest in terms of the discharge of water."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2521,
    "content": [
      "Which one of the following explains the temporal variation of rainfall in Ethiopia?"
    ],
    "explanation": [
      "Ethiopia’s rainfall varies greatly over time, divided into four main seasons: *Kiremt* (summer, June–August), *Belg* (spring, March–May), *Meher* (autumn, September–November), and *Bega* (winter, December–February).\n\n**Spring (*Belg*) is one of the two main rainy seasons**, providing significant rain along with *Kiremt*. Together, these two seasons supply **over 90% of Ethiopia’s total rainfall**, showing a clear **temporal variation** in the country’s climate."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10092,
        "content": [
          "Spring is the rainy season in most parts of Ethiopia."
        ],
        "isCorrect": true
      },
      {
        "id": 10093,
        "content": [
          "In Autumn, many places in Ethiopia receive the highest rainfall."
        ],
        "isCorrect": false
      },
      {
        "id": 10094,
        "content": [
          "There is little seasonal variation in the amount of rain in Ethiopia."
        ],
        "isCorrect": false
      },
      {
        "id": 10095,
        "content": [
          "The lowlands of Afar typically receive rain in summer."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2522,
    "content": [
      "Which one is correct about the Ethiopian Woodland Savanna vegetation?"
    ],
    "explanation": [
      "The Woodland Savanna in Ethiopia is a transitional vegetation zone that typically occurs at intermediate altitudes, acting as a bridge between the higher-elevation forests and the lower-elevation grasslands and semi-deserts. Therefore, it is found in the peripheries of both highlands and lowlands."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10096,
        "content": [
          "It is very similar to European Alpine vegetation."
        ],
        "isCorrect": false
      },
      {
        "id": 10097,
        "content": [
          "It is known for dense acacia trees."
        ],
        "isCorrect": false
      },
      {
        "id": 10098,
        "content": [
          "It grows mainly along the river banks."
        ],
        "isCorrect": false
      },
      {
        "id": 10099,
        "content": [
          "It is found both in the highlands and lowlands."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2523,
    "content": [
      "If you were asked by a tourist who wanted to see 'Chelada' baboon in Ethiopia, which specific national park would be your recommendation?"
    ],
    "explanation": [
      "The Chelada (or Gelada) baboon is a species endemic to the Ethiopian highlands. The largest populations are found in the Simien Mountains, making the Simien Mountains National Park (Semen Highlands) the correct location to see them."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10100,
        "content": [
          "The Bale Mountains"
        ],
        "isCorrect": false
      },
      {
        "id": 10101,
        "content": [
          "The Nechsar Park"
        ],
        "isCorrect": false
      },
      {
        "id": 10102,
        "content": [
          "The Semen Highlands"
        ],
        "isCorrect": true
      },
      {
        "id": 10103,
        "content": [
          "The Awash Park"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2524,
    "content": [
      "If you are asked to propose a strategy for conservation of wildlife where hunting is strictly forbidden, what would be your suggestion as conservation area?"
    ],
    "explanation": [
      "**National parks** are areas established to **protect wildlife from human impact**, emphasizing conservation, research, education, and recreation. Hunting is **strictly prohibited** to preserve natural habitats and species.\n\nWhile **sanctuaries** also protect endangered animals, **game reserves** may permit regulated hunting, and **zoological gardens** involve captive animals. Thus, national parks best represent strict conservation areas."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10104,
        "content": [
          "National parks"
        ],
        "isCorrect": true
      },
      {
        "id": 10105,
        "content": [
          "Sanctuaries"
        ],
        "isCorrect": false
      },
      {
        "id": 10106,
        "content": [
          "Game reserves"
        ],
        "isCorrect": false
      },
      {
        "id": 10107,
        "content": [
          "Zoological gardens"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2525,
    "content": [
      "Which measure of soil conservation should be widely used against soil erosion in arid and semi-arid areas of the Horn?"
    ],
    "explanation": [
      "In arid and semi-arid regions, wind erosion is a major cause of soil degradation. Shelter belts, which are rows of trees and shrubs planted along the edges of fields, are highly effective at reducing wind speed and preventing topsoil from being blown away."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10108,
        "content": [
          "Terracing"
        ],
        "isCorrect": false
      },
      {
        "id": 10109,
        "content": [
          "Intercropping"
        ],
        "isCorrect": false
      },
      {
        "id": 10110,
        "content": [
          "Check dams"
        ],
        "isCorrect": false
      },
      {
        "id": 10111,
        "content": [
          "Shelter belts"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2526,
    "content": [
      "Which of the following igneous rock has clearly observed crystals and coarse grain?"
    ],
    "explanation": [
      "Coarse grains and clearly visible crystals are characteristic of intrusive (or plutonic) igneous rocks, which cool slowly deep beneath the Earth's surface. Granite is a classic example of such a rock. Basalt and obsidian are extrusive (cool quickly on the surface), and marble is a metamorphic rock."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10112,
        "content": [
          "Obsidian"
        ],
        "isCorrect": false
      },
      {
        "id": 10113,
        "content": [
          "Granite"
        ],
        "isCorrect": true
      },
      {
        "id": 10114,
        "content": [
          "Marble"
        ],
        "isCorrect": false
      },
      {
        "id": 10115,
        "content": [
          "Basalt"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2527,
    "content": [
      "One of the following is a poorly drained and aerated soil type. Which one is it?"
    ],
    "explanation": [
      "Clay soils are composed of very fine particles. These particles pack tightly together, leaving very small pore spaces. This structure causes them to retain a large amount of water and restricts the movement of air, leading to poor drainage and aeration."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10116,
        "content": [
          "Loam soils"
        ],
        "isCorrect": false
      },
      {
        "id": 10117,
        "content": [
          "Silt soils"
        ],
        "isCorrect": false
      },
      {
        "id": 10118,
        "content": [
          "Clay soils"
        ],
        "isCorrect": true
      },
      {
        "id": 10119,
        "content": [
          "Sandy soils"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2528,
    "content": [
      "Which of the following is correct about natural causes of climate change?"
    ],
    "explanation": [
      "Over millions of years, the movement of continents (continental drift) alters the shape and size of ocean basins. This directly influences the patterns of ocean currents and global wind systems, which are key components in distributing heat around the planet and thus affect long-term climate."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_CHANGE_IMPACTS_AND_SOLUTIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10120,
        "content": [
          "Continental drift changes the flow of ocean currents and winds."
        ],
        "isCorrect": true
      },
      {
        "id": 10121,
        "content": [
          "Volcanic eruption leads to atmospheric heating."
        ],
        "isCorrect": false
      },
      {
        "id": 10122,
        "content": [
          "Natural causes are becoming the major causes of climate change."
        ],
        "isCorrect": false
      },
      {
        "id": 10123,
        "content": [
          "Ocean currents via releasing water vapor have a net cooling effect."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2529,
    "content": [
      "How do you explain the spatio-temporal distribution of temperature in Ethiopia?"
    ],
    "explanation": [
      "In Ethiopia, particularly in the highlands, the winter season (Bega) is characterized by dry, clear skies. This lack of cloud cover allows for significant solar radiation during the day (leading to higher temperatures) and rapid heat loss at night (leading to lower temperatures), resulting in the largest diurnal (daily) temperature range."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10124,
        "content": [
          "Annual range of temperature is greater than the daily range."
        ],
        "isCorrect": false
      },
      {
        "id": 10125,
        "content": [
          "Temperature decreases from the center to the peripheries."
        ],
        "isCorrect": false
      },
      {
        "id": 10126,
        "content": [
          "Daily range of temperature is the highest during winter season."
        ],
        "isCorrect": true
      },
      {
        "id": 10127,
        "content": [
          "Highlands exhibit the highest annual range of temperature."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2530,
    "content": [
      "Which climatic zone of Ethiopia experiences hot temperature, small cloud cover and very windy conditions throughout the year?"
    ],
    "explanation": [
      "The 'Bereha' zone is the hot, arid (desert) climate of Ethiopia, typically found at altitudes below 500 meters. It is characterized by consistently high temperatures, minimal cloud cover, low rainfall, and often windy conditions."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10128,
        "content": [
          "Woina Dega"
        ],
        "isCorrect": false
      },
      {
        "id": 10129,
        "content": [
          "Bereha"
        ],
        "isCorrect": true
      },
      {
        "id": 10130,
        "content": [
          "Dega"
        ],
        "isCorrect": false
      },
      {
        "id": 10131,
        "content": [
          "Wurch"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2531,
    "content": [
      "Why are some regions of the world more sparsely populated than others? This is because of the"
    ],
    "explanation": [
      "Rugged topography, such as steep mountains and deeply dissected plateaus, makes areas difficult for human settlement. It hinders agriculture, construction, and the development of transportation networks, leading to sparse populations in such regions. The other options are factors that encourage, rather than limit, population density."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10132,
        "content": [
          "availability of fertile soil."
        ],
        "isCorrect": false
      },
      {
        "id": 10133,
        "content": [
          "presence of a favorable climate."
        ],
        "isCorrect": false
      },
      {
        "id": 10134,
        "content": [
          "practice of farm economic activity."
        ],
        "isCorrect": false
      },
      {
        "id": 10135,
        "content": [
          "existence of rugged topography."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2532,
    "content": [
      "What type of migration results when governments move war and natural disaster-affected people to new places?"
    ],
    "explanation": [
      "Resettlement is the planned and organized movement of people by a government or other authority from one area to another. This often occurs in response to large-scale crises like wars, natural disasters, or development projects."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10136,
        "content": [
          "Evacuee"
        ],
        "isCorrect": false
      },
      {
        "id": 10137,
        "content": [
          "Resettlement"
        ],
        "isCorrect": true
      },
      {
        "id": 10138,
        "content": [
          "Transhumance"
        ],
        "isCorrect": false
      },
      {
        "id": 10139,
        "content": [
          "Refugee"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2533,
    "content": [
      "How do we generalize the level of the world's urbanization across continents?"
    ],
    "explanation": [
      "North America has one of the highest proportions of its population living in urban areas, typically over 80%. This makes it the most urbanized continent when compared to others like Africa, Asia, and even Europe."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10140,
        "content": [
          "Africa has the highest level of urbanization."
        ],
        "isCorrect": false
      },
      {
        "id": 10141,
        "content": [
          "Asia has a higher level of urbanization than Latin America."
        ],
        "isCorrect": false
      },
      {
        "id": 10142,
        "content": [
          "North America is the most urbanized continent."
        ],
        "isCorrect": true
      },
      {
        "id": 10143,
        "content": [
          "There is a high level of urbanization in the developing world."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2534,
    "content": [
      "How do we describe rural and urban settlements?"
    ],
    "explanation": [
      "A key characteristic of many urban settlements, especially modern ones, is the presence of a planned street system or grid. This facilitates transport, organization, and the provision of services, distinguishing them from often organically grown rural settlements."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10144,
        "content": [
          "Rural settlements have defined shapes."
        ],
        "isCorrect": false
      },
      {
        "id": 10145,
        "content": [
          "Rural areas are known by dense population."
        ],
        "isCorrect": false
      },
      {
        "id": 10146,
        "content": [
          "Urban settlements have planned streets."
        ],
        "isCorrect": true
      },
      {
        "id": 10147,
        "content": [
          "Urban areas have a low division of labor."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2535,
    "content": [
      "Why was hilltops mainly preferred for the establishment of old urban centers of Ethiopia? This was due to their"
    ],
    "explanation": [
      "Historically, many of Ethiopia's old urban centers and capitals were established on hilltops (ambas) or other elevated areas. These locations provided a strategic advantage, making them easier to defend against attacks and offering a commanding view of the surrounding territory."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10148,
        "content": [
          "water resources."
        ],
        "isCorrect": false
      },
      {
        "id": 10149,
        "content": [
          "defensive locations."
        ],
        "isCorrect": true
      },
      {
        "id": 10150,
        "content": [
          "fertile alluvial soil."
        ],
        "isCorrect": false
      },
      {
        "id": 10151,
        "content": [
          "natural beauty."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2536,
    "content": [
      "What is the size of Africa compared to the sizes of other continents?"
    ],
    "explanation": [
      "Africa is the world's second-largest continent in terms of both land area (about 30.37 million sq km) and population. Only Asia is larger."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10152,
        "content": [
          "It is the largest continent next to the Asian continent."
        ],
        "isCorrect": true
      },
      {
        "id": 10153,
        "content": [
          "It constitutes half of the total land surface of the earth."
        ],
        "isCorrect": false
      },
      {
        "id": 10154,
        "content": [
          "It nearly doubles the total size of North America."
        ],
        "isCorrect": false
      },
      {
        "id": 10155,
        "content": [
          "It is four times larger than the size of Antarctica."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2537,
    "content": [
      "How do the relative compact shape and unbroken coastline of Africa impact its development?"
    ],
    "explanation": [
      "A compact shape, where the distance from the center to any boundary is relatively similar, can make a country or continent easier to govern, administer, and defend because it simplifies internal transportation and communication lines and reduces the length of borders to be managed. Africa's unbroken coastline, however, limits natural harbors."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10156,
        "content": [
          "Its compact shape discourages intra-continental movements."
        ],
        "isCorrect": false
      },
      {
        "id": 10157,
        "content": [
          "Its unbroken coastline makes the continent rich in natural harbors."
        ],
        "isCorrect": false
      },
      {
        "id": 10158,
        "content": [
          "Its unbroken coastline encourages external communications."
        ],
        "isCorrect": false
      },
      {
        "id": 10159,
        "content": [
          "Its compact shape relatively eases administration and defense."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2538,
    "content": [
      "Which of the following distinguishes the regions of Africa?"
    ],
    "explanation": [
      "Central Africa is dominated by the vast and dense Congo Rainforest. This challenging physical environment, with its limited infrastructure, contributes to it being the most sparsely populated region on the continent."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10160,
        "content": [
          "Eastern Africa is the smallest in terms of area."
        ],
        "isCorrect": false
      },
      {
        "id": 10161,
        "content": [
          "Western Africa has the highest urban population."
        ],
        "isCorrect": false
      },
      {
        "id": 10162,
        "content": [
          "Central Africa is the most sparsely populated."
        ],
        "isCorrect": true
      },
      {
        "id": 10163,
        "content": [
          "Northern Africa has the highest number of countries."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2539,
    "content": [
      "Which region of Africa lies both in the northern and southern hemispheres?"
    ],
    "explanation": [
      "Eastern Africa is bisected by the Equator. Countries like Kenya, Uganda, and Somalia have territory in both the Northern and Southern Hemispheres."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10164,
        "content": [
          "Northern Africa"
        ],
        "isCorrect": false
      },
      {
        "id": 10165,
        "content": [
          "Southern Africa"
        ],
        "isCorrect": false
      },
      {
        "id": 10166,
        "content": [
          "Western Africa"
        ],
        "isCorrect": false
      },
      {
        "id": 10167,
        "content": [
          "Eastern Africa"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2540,
    "content": [
      "Among the following geological events, which one happened during the Cenozoic Era?"
    ],
    "explanation": [
      "The Cenozoic Era, particularly in Africa, was marked by significant tectonic activity related to the formation of the Great Rift Valley. This activity led to extensive volcanism and the uplift of large plateaus and volcanic mountains, such as the Ethiopian Highlands and Mount Kilimanjaro."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10168,
        "content": [
          "Formation of Laurasia and Gondwanaland"
        ],
        "isCorrect": false
      },
      {
        "id": 10169,
        "content": [
          "Formation of plateau and volcanic mountains"
        ],
        "isCorrect": true
      },
      {
        "id": 10170,
        "content": [
          "The slow sinking and rising of landmass"
        ],
        "isCorrect": false
      },
      {
        "id": 10171,
        "content": [
          "Transgression and regression of the sea"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2541,
    "content": [
      "Which of the following is correct about the African plateaus?"
    ],
    "explanation": [
      "Africa is often called the \"plateau continent\" because a vast portion of its landmass consists of a series of extensive plateaus. These plateaus are a dominant feature of its topography, covering well over half of its total area."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10172,
        "content": [
          "Plateaus account for more than half of the landscape of the continent."
        ],
        "isCorrect": true
      },
      {
        "id": 10173,
        "content": [
          "The Bihe plateau is an example of low plateaus."
        ],
        "isCorrect": false
      },
      {
        "id": 10174,
        "content": [
          "Eastern Africa is largely areas of low plateaus."
        ],
        "isCorrect": false
      },
      {
        "id": 10175,
        "content": [
          "High plateaus are abundantly found in Northern and Western Africa."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2542,
    "content": [
      "Which wind type is dominantly affecting the tropical climate of Africa?"
    ],
    "explanation": [
      "The tropical regions of Africa are located within the belt of the Trade Winds. The Northeast Trade Winds and Southeast Trade Winds converge near the equator at the Intertropical Convergence Zone (ITCZ), and their movement and interaction are the primary drivers of rainfall and seasons in tropical Africa."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10176,
        "content": [
          "Polar easterlies"
        ],
        "isCorrect": false
      },
      {
        "id": 10177,
        "content": [
          "Guinea Monsoon"
        ],
        "isCorrect": false
      },
      {
        "id": 10178,
        "content": [
          "Westerly winds"
        ],
        "isCorrect": false
      },
      {
        "id": 10179,
        "content": [
          "Trade winds"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2543,
    "content": [
      "How do you describe the seasonal temperature condition of Africa?"
    ],
    "explanation": [
      "June to August corresponds to summer in the Northern Hemisphere. During this time, the sun is directly overhead at or near the Tropic of Cancer, leading to intensely high temperatures across the Sahara Desert."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10180,
        "content": [
          "Months from March to May exhibit low temperature in the most parts of the northern Africa."
        ],
        "isCorrect": false
      },
      {
        "id": 10181,
        "content": [
          "The Sahara Desert experiences a relatively high temperature between June to August."
        ],
        "isCorrect": true
      },
      {
        "id": 10182,
        "content": [
          "Southern Africa experiences low temperature from December to February."
        ],
        "isCorrect": false
      },
      {
        "id": 10183,
        "content": [
          "When the sun is overhead at the Tropic of Capricorn, northern parts of Africa experience the highest temperature."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2544,
    "content": [
      "One of the following is the main feature of warm temperate continental climatic region of Africa. Which one is it?"
    ],
    "explanation": [
      "The warm temperate continental climate (found for instance in the highveld of South Africa) receives a significant portion of its moisture from air masses originating over the ocean. The westerlies from the Atlantic bring rainfall to these regions."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10184,
        "content": [
          "Its main source of rainfall is from the Atlantic Ocean."
        ],
        "isCorrect": true
      },
      {
        "id": 10185,
        "content": [
          "It is mostly found in the northern parts of Africa."
        ],
        "isCorrect": false
      },
      {
        "id": 10186,
        "content": [
          "It occupies the largest climatic region of Africa."
        ],
        "isCorrect": false
      },
      {
        "id": 10187,
        "content": [
          "It has a high rainfall and low air temperature."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2545,
    "content": [
      "Which part of Africa is highly prone to drought?"
    ],
    "explanation": [
      "The region just north of the wetter tropics is the Sahel, a vast semi-arid transitional zone between the Sahara Desert to the north and the savanna to the south. This region is characterized by highly variable and unreliable rainfall, making it extremely prone to recurrent and severe droughts."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_CHANGE_IMPACTS_AND_SOLUTIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10188,
        "content": [
          "The Northern tip of Africa"
        ],
        "isCorrect": false
      },
      {
        "id": 10189,
        "content": [
          "The Southern tip of Africa"
        ],
        "isCorrect": false
      },
      {
        "id": 10190,
        "content": [
          "North of wetter tropics"
        ],
        "isCorrect": true
      },
      {
        "id": 10191,
        "content": [
          "The Central Africa"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2546,
    "content": [
      "Which drainage system of Africa has only one major river and flows northwards?"
    ],
    "explanation": [
      "The Mediterranean Sea drainage system is dominated by a single, massive river: the Nile. The Nile is unique among the world's great rivers for its northward flow from the highlands of central Africa to its delta on the Mediterranean Sea."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10192,
        "content": [
          "The Mediterranean Sea drainage system"
        ],
        "isCorrect": true
      },
      {
        "id": 10193,
        "content": [
          "The Indian Ocean drainage system"
        ],
        "isCorrect": false
      },
      {
        "id": 10194,
        "content": [
          "The inland drainage system"
        ],
        "isCorrect": false
      },
      {
        "id": 10195,
        "content": [
          "The Atlantic Ocean drainage system"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2547,
    "content": [
      "Among the following lakes of Africa, which one is a non-rift valley lake?"
    ],
    "explanation": [
      "Lake Victoria is the largest lake in Africa but is not a Rift Valley lake. It occupies a shallow depression between the eastern and western branches of the Great Rift Valley. Lakes Tanganyika, Kivu, and Turkana are all classic examples of deep, elongated lakes formed within the rift valley itself."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10196,
        "content": [
          "Kivu"
        ],
        "isCorrect": false
      },
      {
        "id": 10197,
        "content": [
          "Victoria"
        ],
        "isCorrect": true
      },
      {
        "id": 10198,
        "content": [
          "Tanganyika"
        ],
        "isCorrect": false
      },
      {
        "id": 10199,
        "content": [
          "Turkana"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2548,
    "content": [
      "In what ways does the presence of many waterfalls, rapids and steep courses of African rivers tend to mainly benefit the socioeconomic development of the continent?"
    ],
    "explanation": [
      "While waterfalls and rapids hinder water transport, their steep gradients and large volumes of water create immense potential for generating hydroelectric power. This is a major renewable energy resource that can significantly benefit socioeconomic development."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10200,
        "content": [
          "By generating hydroelectric power"
        ],
        "isCorrect": true
      },
      {
        "id": 10201,
        "content": [
          "By creating conducive environment for fishing"
        ],
        "isCorrect": false
      },
      {
        "id": 10202,
        "content": [
          "By encouraging irrigation"
        ],
        "isCorrect": false
      },
      {
        "id": 10203,
        "content": [
          "By facilitating water transport"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2549,
    "content": [
      "How do you analyze the hydro politics of the Nile River?"
    ],
    "explanation": [
      "While primarily designed for Ethiopia's electricity needs, the Great Ethiopian Renaissance Dam (GERD) is expected to provide benefits to neighboring downstream countries, such as Sudan and Egypt, through regulated water flow (reducing flooding and sedimentation) and the potential to purchase cheap electricity."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10204,
        "content": [
          "Lower course countries are the least beneficiary of the River water."
        ],
        "isCorrect": false
      },
      {
        "id": 10205,
        "content": [
          "The Great Ethiopian Renaissance Dam will benefit the neighboring countries."
        ],
        "isCorrect": true
      },
      {
        "id": 10206,
        "content": [
          "White Nile is the largest supplier of water to the Nile River."
        ],
        "isCorrect": false
      },
      {
        "id": 10207,
        "content": [
          "Historically, Nile basin countries have been fairly utilizing the River water."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2550,
    "content": [
      "Which of the following is an example of human influence on land use?"
    ],
    "explanation": [
      "Agricultural programs are deliberate plans and actions created by humans to cultivate crops and raise livestock. This directly transforms natural landscapes into farmland, making it a prime example of human influence on land use. The other options are natural factors that influence land use."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10208,
        "content": [
          "Agricultural programs"
        ],
        "isCorrect": true
      },
      {
        "id": 10209,
        "content": [
          "Soil quality"
        ],
        "isCorrect": false
      },
      {
        "id": 10210,
        "content": [
          "Moisture availability"
        ],
        "isCorrect": false
      },
      {
        "id": 10211,
        "content": [
          "Environmental conditions"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2551,
    "content": [
      "If carefully and scientifically managed, which of the following resources tends to regenerate?"
    ],
    "explanation": [
      "Soil is considered a renewable or regenerable resource. Although it forms very slowly in nature, its fertility and structure can be maintained and even improved through careful and scientific management practices like crop rotation, conservation tillage, and adding organic matter. Petroleum, coal, and natural gas are non-renewable fossil fuels."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10212,
        "content": [
          "Petroleum"
        ],
        "isCorrect": false
      },
      {
        "id": 10213,
        "content": [
          "Soil"
        ],
        "isCorrect": true
      },
      {
        "id": 10214,
        "content": [
          "Natural gas"
        ],
        "isCorrect": false
      },
      {
        "id": 10215,
        "content": [
          "Coal"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2552,
    "content": [
      "Among the most common woods of Ethiopia, which one has been traditionally used for making water pipes and baskets?"
    ],
    "explanation": [
      "Bamboo is a highly versatile plant with a hollow, segmented structure. This natural form makes it ideal for use as water pipes with minimal processing. Its flexible yet strong fibers are also excellent for weaving baskets."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ECONOMIC_AND_CULTURAL_ACTIVITIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10216,
        "content": [
          "Bamboo"
        ],
        "isCorrect": true
      },
      {
        "id": 10217,
        "content": [
          "Olea"
        ],
        "isCorrect": false
      },
      {
        "id": 10218,
        "content": [
          "Kerero"
        ],
        "isCorrect": false
      },
      {
        "id": 10219,
        "content": [
          "Zigba"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2553,
    "content": [
      "What is the main environmental policy focus area of the Ethiopian green legacy program?"
    ],
    "explanation": [
      "The Green Legacy Initiative is a large-scale afforestation and reforestation program in Ethiopia. Its primary focus is on planting billions of trees to combat deforestation, land degradation, and climate change, directly aligning with policies for forest, woodland, and tree resources."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10220,
        "content": [
          "Policy associated with energy resources"
        ],
        "isCorrect": false
      },
      {
        "id": 10221,
        "content": [
          "Policy related to soil and agriculture"
        ],
        "isCorrect": false
      },
      {
        "id": 10222,
        "content": [
          "Policy linked to water resources"
        ],
        "isCorrect": false
      },
      {
        "id": 10223,
        "content": [
          "Policy allied to forest, woodland and tree resources"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2554,
    "content": [
      "Which of the following planet is situated very close to the Sun?"
    ],
    "explanation": [
      "Among the options provided, Earth is the closest planet to the Sun. The order of the listed planets from the Sun is Earth, Jupiter, Saturn, and Uranus. (The actual closest planet is Mercury, but it is not an option)."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10224,
        "content": [
          "Jupiter"
        ],
        "isCorrect": false
      },
      {
        "id": 10225,
        "content": [
          "Saturn"
        ],
        "isCorrect": false
      },
      {
        "id": 10226,
        "content": [
          "Uranus"
        ],
        "isCorrect": false
      },
      {
        "id": 10227,
        "content": [
          "Earth"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2555,
    "content": [
      "Which of the following describes the core structure of the earth?"
    ],
    "explanation": [
      "The Earth's core, particularly the inner core, has temperatures estimated to be around 5,000 to 6,000 degrees Celsius. This temperature range is comparable to the temperature of the surface of the Sun (the photosphere)."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10228,
        "content": [
          "It is mainly composed of silicate minerals."
        ],
        "isCorrect": false
      },
      {
        "id": 10229,
        "content": [
          "It is as hot as the surface of the sun."
        ],
        "isCorrect": true
      },
      {
        "id": 10230,
        "content": [
          "Its inner section is liquid."
        ],
        "isCorrect": false
      },
      {
        "id": 10231,
        "content": [
          "It accounts for the largest volume of the earth."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2556,
    "content": [
      "One of the following explains the Continental Drift Theory. Which one is it?"
    ],
    "explanation": [
      "According to Alfred Wegener's theory of Continental Drift, the ancient supercontinent Pangaea first broke into two large landmasses. The northern supercontinent was named Laurasia (comprising future North America, Europe, and Asia), and the southern one was Gondwanaland."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10232,
        "content": [
          "Laurasia was the northern part of the supercontinent."
        ],
        "isCorrect": true
      },
      {
        "id": 10233,
        "content": [
          "The theory was developed by Thomas Robert Malthus."
        ],
        "isCorrect": false
      },
      {
        "id": 10234,
        "content": [
          "Gondwanaland was once a single super continent."
        ],
        "isCorrect": false
      },
      {
        "id": 10235,
        "content": [
          "The drifting of continents was centered upon Europe."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2557,
    "content": [
      "On which of the earth sub-systems listed below, can human cultural imprints be found?"
    ],
    "explanation": [
      "The Anthroposphere is the part of the environment **made or modified by humans**, where human cultural imprints are found.\n\nWhile humans affect the Atmosphere, Lithosphere, and Hydrosphere, only the Anthroposphere specifically captures human influence. Examples include land attributes and cultural landscapes, like the Konso terraces, reflecting the results of human activities and cultural values."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10236,
        "content": [
          "Atmosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 10237,
        "content": [
          "Lithosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 10238,
        "content": [
          "Anthroposphere"
        ],
        "isCorrect": true
      },
      {
        "id": 10239,
        "content": [
          "Hydrosphere"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2558,
    "content": [
      "If you find a large number of herbivore and carnivore animals in a certain geographical area in Africa, what can you generalize about the type of the climate of the area?"
    ],
    "explanation": [
      "The Tropical Savanna biome, with its vast grasslands dotted with trees, supports large herds of grazing herbivores (like zebras, wildebeest). This abundance of prey, in turn, supports a significant population of carnivores (like lions, cheetahs). This ecosystem is famous for its high biomass of large mammals."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10240,
        "content": [
          "Tropical desert and semi-desert"
        ],
        "isCorrect": false
      },
      {
        "id": 10241,
        "content": [
          "Highland climate"
        ],
        "isCorrect": false
      },
      {
        "id": 10242,
        "content": [
          "Tropical Savanna climate"
        ],
        "isCorrect": true
      },
      {
        "id": 10243,
        "content": [
          "Equatorial climate"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2559,
    "content": [
      "Despite many efforts, wild life resources of Africa are deteriorating from time to time. If you are asked to prioritize and implement conservation measures, which one is the most important one?"
    ],
    "explanation": [
      "Preserving the natural vegetation is the most fundamental conservation measure because vegetation forms the base of the ecosystem. It provides habitat, food, and shelter for all wildlife. Without a healthy habitat, no other conservation effort can be successful in the long term."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10244,
        "content": [
          "Preserving the natural vegetation"
        ],
        "isCorrect": true
      },
      {
        "id": 10245,
        "content": [
          "Establishing national parks and game reserves"
        ],
        "isCorrect": false
      },
      {
        "id": 10246,
        "content": [
          "Raising awareness of the community"
        ],
        "isCorrect": false
      },
      {
        "id": 10247,
        "content": [
          "Regulating the practice of illegal hunting"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2560,
    "content": [
      "Which soil type is mainly located in the tropical monsoon climatic region of Africa?"
    ],
    "explanation": [
      "Lixisols are soils that are common in seasonally dry tropical regions, such as those with a monsoon climate. They are characterized by weathering and leaching but have a higher base saturation than more intensely leached tropical soils, making them suitable for agriculture in these climatic zones."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10248,
        "content": [
          "Acrisols"
        ],
        "isCorrect": false
      },
      {
        "id": 10249,
        "content": [
          "Calcisols"
        ],
        "isCorrect": false
      },
      {
        "id": 10250,
        "content": [
          "Lixisols"
        ],
        "isCorrect": true
      },
      {
        "id": 10251,
        "content": [
          "Luvisols"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2561,
    "content": [
      "How do you describe the population size and growth of Africa?"
    ],
    "explanation": [
      "Historically and currently, more people emigrate from African countries to other continents than immigrate to Africa. This results in a negative net migration rate for the continent as a whole. Africa has the highest population growth rate and the shortest doubling time."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10252,
        "content": [
          "It has the lowest rate of population growth rate."
        ],
        "isCorrect": false
      },
      {
        "id": 10253,
        "content": [
          "Its population doubling time is the longest."
        ],
        "isCorrect": false
      },
      {
        "id": 10254,
        "content": [
          "It is the least populated continent."
        ],
        "isCorrect": false
      },
      {
        "id": 10255,
        "content": [
          "It has a negative net migration rate."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2562,
    "content": [
      "Among the following, which one describes the international migration in Africa?"
    ],
    "explanation": [
      "North Africa has been a crossroads for migration for centuries, particularly between sub-Saharan Africa, the Middle East, and Europe. These extensive migration flows have significantly influenced and modified the region's languages, religions, customs, and social structures over time."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10256,
        "content": [
          "Brain drain is bringing more opportunities than challenges."
        ],
        "isCorrect": false
      },
      {
        "id": 10257,
        "content": [
          "It has modified the sociocultural assets of North Africa."
        ],
        "isCorrect": true
      },
      {
        "id": 10258,
        "content": [
          "Its practice has a short history in the continent."
        ],
        "isCorrect": false
      },
      {
        "id": 10259,
        "content": [
          "Currently, there is the highest number of immigrants to the continent."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2563,
    "content": [
      "Let's say your birth place has a rapid rate population growth which pushes the residents of the area to permanently leave their place of living. What do you think might your place of birth benefit from these permanent migrants?"
    ],
    "explanation": [
      "Out-migration (emigration) from an area with rapid population growth directly reduces the total number of people living there. This, in turn, lessens the demand and pressure on local resources such as land, water, food, and social services."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10260,
        "content": [
          "It solves the problem of labor shortage"
        ],
        "isCorrect": false
      },
      {
        "id": 10261,
        "content": [
          "It results in high concentrations of elders"
        ],
        "isCorrect": false
      },
      {
        "id": 10262,
        "content": [
          "It decreases pressure on natural resources"
        ],
        "isCorrect": true
      },
      {
        "id": 10263,
        "content": [
          "It increases the rate of population growth"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2564,
    "content": [
      "What could be generalized about the economic growth and development trend of Africa?"
    ],
    "explanation": [
      "A common characteristic of many African economies is a reliance on exporting raw primary commodities (like oil, minerals, and agricultural products) which have relatively low prices, while importing expensive manufactured and high-tech goods. This often leads to a situation where the value of imports exceeds the value of exports, resulting in a negative trade balance."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10264,
        "content": [
          "Rapid population growth acts as an engine to many African economies."
        ],
        "isCorrect": false
      },
      {
        "id": 10265,
        "content": [
          "Different economic sectors of the continent are being integrated."
        ],
        "isCorrect": false
      },
      {
        "id": 10266,
        "content": [
          "Manufactured products dominated the export items of the continent."
        ],
        "isCorrect": false
      },
      {
        "id": 10267,
        "content": [
          "Most African countries exhibit a negative trade balance."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2565,
    "content": [
      "Which feature best explains the socioeconomic condition of developed countries?"
    ],
    "explanation": [
      "Developed countries are characterized by advanced, industrialized economies where the majority of the population is engaged in service and industrial sectors. These activities are concentrated in cities, leading to a very high level of urbanization, with most of the population residing in urban areas."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10268,
        "content": [
          "High proportion of children"
        ],
        "isCorrect": false
      },
      {
        "id": 10269,
        "content": [
          "High level of urbanization"
        ],
        "isCorrect": true
      },
      {
        "id": 10270,
        "content": [
          "Dominant primary industries"
        ],
        "isCorrect": false
      },
      {
        "id": 10271,
        "content": [
          "Labor-intensive investments"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2566,
    "content": [
      "What is the main implication of the large size of young population in Ethiopia?"
    ],
    "explanation": [
      "A large young population (a high youth dependency ratio) means that a significant portion of the national budget must be allocated to providing essential social services for this group, such as education (schools), healthcare (clinics, vaccinations), and basic infrastructure. This can strain government finances."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10272,
        "content": [
          "The country has the smallest proportion of non-productive population."
        ],
        "isCorrect": false
      },
      {
        "id": 10273,
        "content": [
          "The country needs a high expenditure for the provision of basic social services."
        ],
        "isCorrect": true
      },
      {
        "id": 10274,
        "content": [
          "It has a low potential to increase the momentum of population growth."
        ],
        "isCorrect": false
      },
      {
        "id": 10275,
        "content": [
          "There is a rapid socio-economic and technological development of the country."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2567,
    "content": [
      "What motivated the government of Ethiopia to develop anti-natalist population policy? The need to"
    ],
    "explanation": [
      "Ethiopia's 1993 population policy was fundamentally linked to development goals. A key component of anti-natalist policies is empowering women through education and access to family planning. Raising the economic and social status of women gives them more control over their reproductive choices, which typically leads to lower fertility rates and contributes to overall development."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10276,
        "content": [
          "reduce the rate of urban-rural migration"
        ],
        "isCorrect": false
      },
      {
        "id": 10277,
        "content": [
          "encourage population growth"
        ],
        "isCorrect": false
      },
      {
        "id": 10278,
        "content": [
          "balance the number of male and female population"
        ],
        "isCorrect": false
      },
      {
        "id": 10279,
        "content": [
          "raise the economic and social status of women"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2568,
    "content": [
      "How does the International Monetary Fund (IMF) contribute to the economic development of nations?"
    ],
    "explanation": [
      "A core mandate of the IMF is to ensure the stability of the international monetary system. It does this by monitoring exchange rates and balance of payments. Stable exchange rates are crucial for predictable and reliable international trade and investment, which are essential for economic development."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10280,
        "content": [
          "By promoting countries to set tariffs and quotas"
        ],
        "isCorrect": false
      },
      {
        "id": 10281,
        "content": [
          "By supporting green campaigns"
        ],
        "isCorrect": false
      },
      {
        "id": 10282,
        "content": [
          "By stabilizing exchange rates"
        ],
        "isCorrect": true
      },
      {
        "id": 10283,
        "content": [
          "By encouraging state ownership of enterprises"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2569,
    "content": [
      "As a citizen of Ethiopia, what is your view about the advantage your country gained as a result of globalization?"
    ],
    "explanation": [
      "Globalization facilitates the movement of people across borders for work. Many Ethiopians work abroad and send money back to their families. These financial inflows, known as remittances, are a significant source of foreign currency for the country and provide crucial economic support to many households."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10284,
        "content": [
          "It marks the domination of imported products."
        ],
        "isCorrect": false
      },
      {
        "id": 10285,
        "content": [
          "It increases the flow of remittance."
        ],
        "isCorrect": true
      },
      {
        "id": 10286,
        "content": [
          "It helps to exercise the western cultures."
        ],
        "isCorrect": false
      },
      {
        "id": 10287,
        "content": [
          "It encourages a high consumption of domestic products."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2570,
    "content": [
      "Which one of the following is correct about the scope of Geography?"
    ],
    "explanation": [
      "The scope of geography is the study of the Earth's surface, which encompasses the various geospheres: the lithosphere (land), hydrosphere (water), atmosphere (air), and biosphere (life). Geography studies the features within these spheres and the interactions between them."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10288,
        "content": [
          "It is delimited to the geospheres of the earth."
        ],
        "isCorrect": true
      },
      {
        "id": 10289,
        "content": [
          "It is limited to describing the capital cities of countries."
        ],
        "isCorrect": false
      },
      {
        "id": 10290,
        "content": [
          "It is merely focused on the distribution of physical features."
        ],
        "isCorrect": false
      },
      {
        "id": 10291,
        "content": [
          "It emphasizes the physical arrangements of the universe."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2571,
    "content": [
      "Why has the quantitative revolution been introduced to the subject matter of Geography?"
    ],
    "explanation": [
      "The quantitative revolution in the 1950s and 1960s was a major paradigm shift in geography. It introduced statistical methods, mathematical modeling, and a more scientific approach with the goal of moving beyond mere description (idiographic approach) towards developing general laws and theories (nomothetic approach) to explain spatial patterns."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_SPATIAL_INFORMATION_AND_DATA_PROCESSING",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10292,
        "content": [
          "To change the empirical nature of geography to a descriptive one"
        ],
        "isCorrect": false
      },
      {
        "id": 10293,
        "content": [
          "To explain and interpret spatial phenomena in a subjective manner"
        ],
        "isCorrect": false
      },
      {
        "id": 10294,
        "content": [
          "To enable geography to become law making science"
        ],
        "isCorrect": true
      },
      {
        "id": 10295,
        "content": [
          "To use the language of literature instead of mathematical language"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2572,
    "content": [
      "How does Geography tend to bridge natural and social sciences?"
    ],
    "explanation": [
      "Geography is unique in its focus on the spatial relationships and interactions between human societies (social science) and the natural environment (natural science). It investigates how physical landscapes influence human activities and how humans, in turn, modify the environment, thus naturally bridging the two broad fields of study."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10296,
        "content": [
          "By offering different mathematical equations to natural sciences"
        ],
        "isCorrect": false
      },
      {
        "id": 10297,
        "content": [
          "By borrowing spatial models from natural and social sciences"
        ],
        "isCorrect": false
      },
      {
        "id": 10298,
        "content": [
          "By investigating how different fields of study are interrelated"
        ],
        "isCorrect": true
      },
      {
        "id": 10299,
        "content": [
          "By sharing methods and contents with different fields of studies"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2573,
    "content": [
      "If you observe a point where a strong river cuts in to the course of a weaker river in your locality, which of the features listed below represents the observed case?"
    ],
    "explanation": [
      "This scenario describes river capture (or piracy). When a more powerful, erosive river (the pirate stream) erodes through a drainage divide and intercepts the course of a weaker river, it diverts the weaker river's flow into its own channel. The point of interception is marked by a sharp, right-angled bend, which is known as the elbow of capture."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10300,
        "content": [
          "Misfit stream"
        ],
        "isCorrect": false
      },
      {
        "id": 10301,
        "content": [
          "Elbow of capture"
        ],
        "isCorrect": true
      },
      {
        "id": 10302,
        "content": [
          "Reverse drainage"
        ],
        "isCorrect": false
      },
      {
        "id": 10303,
        "content": [
          "Wind gap"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2574,
    "content": [
      "Which branch of human geography is concerned with the dynamic nature of places over time?"
    ],
    "explanation": [
      "Historical geography is the study of how geographical phenomena, including landscapes, human settlements, and spatial patterns, have changed and evolved over time. It essentially studies the geography of the past and its influence on the present."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10304,
        "content": [
          "Historical geography"
        ],
        "isCorrect": true
      },
      {
        "id": 10305,
        "content": [
          "Political geography"
        ],
        "isCorrect": false
      },
      {
        "id": 10306,
        "content": [
          "Urban geography"
        ],
        "isCorrect": false
      },
      {
        "id": 10307,
        "content": [
          "Cultural geography"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2575,
    "content": [
      "In which of the following conditions does folding happen?"
    ],
    "explanation": [
      "Folding of rock strata occurs under compressional stress. This happens when tectonic forces cause two plates or parts of a plate to push towards each other, squeezing the rock layers and causing them to buckle and bend into folds (anticlines and synclines)."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10308,
        "content": [
          "When two forces move away from one another."
        ],
        "isCorrect": false
      },
      {
        "id": 10309,
        "content": [
          "When molten materials are forced out to the surface."
        ],
        "isCorrect": false
      },
      {
        "id": 10310,
        "content": [
          "When two plates move in parallel directions."
        ],
        "isCorrect": false
      },
      {
        "id": 10311,
        "content": [
          "When two different forces act towards each other."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2576,
    "content": [
      "What type of erosion is commonly found in coastal areas?"
    ],
    "explanation": [
      "Coastal areas are, by definition, where the land meets the sea. The primary agent of erosion and landform shaping in these environments is the constant action of sea waves, which erode, transport, and deposit sediment along the coastline."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10312,
        "content": [
          "Erosion through glaciation"
        ],
        "isCorrect": false
      },
      {
        "id": 10313,
        "content": [
          "Erosion by sea waves"
        ],
        "isCorrect": true
      },
      {
        "id": 10314,
        "content": [
          "Wind erosion"
        ],
        "isCorrect": false
      },
      {
        "id": 10315,
        "content": [
          "Stream erosion"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2577,
    "content": [
      "What is a crescent-moon shaped small hill of sediments that is formed by the action of wind called?"
    ],
    "explanation": [
      "A barchan is a specific type of sand dune characterized by its distinct crescent shape. It forms in areas with a consistent wind direction and a limited supply of sand. The \"horns\" of the crescent point downwind. While it is a type of sand dune, \"barchan\" is the precise term for this shape."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10316,
        "content": [
          "Beach"
        ],
        "isCorrect": false
      },
      {
        "id": 10317,
        "content": [
          "Loess deposit"
        ],
        "isCorrect": false
      },
      {
        "id": 10318,
        "content": [
          "Barchan"
        ],
        "isCorrect": true
      },
      {
        "id": 10319,
        "content": [
          "Sand dune"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2578,
    "content": [
      "Which structure of the atmosphere is known by containing the lowest percentage of atmospheric mass?"
    ],
    "explanation": [
      "The thermosphere is the outermost layer of the atmosphere before the exosphere. The air here is extremely thin, with gas molecules being very far apart. Although temperatures can be very high, the density is incredibly low, meaning it contains a minuscule fraction (less than 0.01%) of the total atmospheric mass."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10320,
        "content": [
          "Stratosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 10321,
        "content": [
          "Troposphere"
        ],
        "isCorrect": false
      },
      {
        "id": 10322,
        "content": [
          "Mesosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 10323,
        "content": [
          "Thermosphere"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2579,
    "content": [
      "Which of the following refers to how energy from the sun is transmitted to the surface of the earth?"
    ],
    "explanation": [
      "Solar energy travels through the vacuum of space to reach Earth. The only method of heat transfer that does not require a medium is electromagnetic radiation. The Sun radiates energy in the form of electromagnetic waves, including visible light, which heat the Earth's surface."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10324,
        "content": [
          "Radiation"
        ],
        "isCorrect": true
      },
      {
        "id": 10325,
        "content": [
          "Advection"
        ],
        "isCorrect": false
      },
      {
        "id": 10326,
        "content": [
          "Convection"
        ],
        "isCorrect": false
      },
      {
        "id": 10327,
        "content": [
          "Conduction"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2580,
    "content": [
      "What is the common feature of planetary winds?"
    ],
    "explanation": [
      "Planetary winds, also known as prevailing winds (like the Trade Winds, Westerlies, and Polar Easterlies), are large-scale wind systems that blow over vast areas of the globe. They are driven by the uneven heating of the Earth and its rotation, covering extensive belts of latitude."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10328,
        "content": [
          "They change their directions on a daily basis."
        ],
        "isCorrect": false
      },
      {
        "id": 10329,
        "content": [
          "They affect small areas for short periods of time."
        ],
        "isCorrect": false
      },
      {
        "id": 10330,
        "content": [
          "They cover a wide area of the earth."
        ],
        "isCorrect": true
      },
      {
        "id": 10331,
        "content": [
          "They are common along the coastal areas."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2581,
    "content": [
      "Which of the following is correct about ocean currents?"
    ],
    "explanation": [
      "Warm ocean currents heat the air above them, increasing the air's capacity to hold moisture through evaporation. When this warm, moist air moves over a cooler landmass, it cools, condenses, and forms clouds, often leading to increased precipitation in coastal areas."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10332,
        "content": [
          "Ocean current is the vertical movement of ocean water."
        ],
        "isCorrect": false
      },
      {
        "id": 10333,
        "content": [
          "Warm ocean currents cause precipitation to the surrounding areas."
        ],
        "isCorrect": true
      },
      {
        "id": 10334,
        "content": [
          "Cold ocean currents increase the temperature of the nearby areas."
        ],
        "isCorrect": false
      },
      {
        "id": 10335,
        "content": [
          "Warm ocean currents tend to reduce the surrounding temperature."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2582,
    "content": [
      "What was the central argument of Malthusian Population Theory?"
    ],
    "explanation": [
      "The core argument of Thomas Malthus's theory is that population, when unchecked, grows at a geometric rate (e.g., 2, 4, 8, 16), while food production (subsistence) increases only at an arithmetic rate (e.g., 1, 2, 3, 4). This disparity means that rapid population growth will inevitably outstrip the food supply, leading to poverty, famine, and underdevelopment."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10336,
        "content": [
          "Positive checks reduce birth rates"
        ],
        "isCorrect": false
      },
      {
        "id": 10337,
        "content": [
          "Food production increases geometrically"
        ],
        "isCorrect": false
      },
      {
        "id": 10338,
        "content": [
          "Recommendation of Manmade birth controls"
        ],
        "isCorrect": false
      },
      {
        "id": 10339,
        "content": [
          "Rapid population growth leads to underdevelopment"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2583,
    "content": [
      "How do you explain the settlement pattern of the Ethiopian population?"
    ],
    "explanation": [
      "The development and location of urban centers are strongly linked to accessibility. In Ethiopia, many major towns and cities, including Addis Ababa, Adama, and Dire Dawa, are situated along major roads and the railway line, which facilitate trade, transport, and communication."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10340,
        "content": [
          "The Shewa and Harerghe plateaus host fewer urban populations."
        ],
        "isCorrect": false
      },
      {
        "id": 10341,
        "content": [
          "Many urban areas in Ethiopia lie along major transport routes."
        ],
        "isCorrect": true
      },
      {
        "id": 10342,
        "content": [
          "Peripheral areas are mainly associated with permanent settlement."
        ],
        "isCorrect": false
      },
      {
        "id": 10343,
        "content": [
          "Most highland areas in northern Ethiopia have temporary settlements."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2584,
    "content": [
      "Which one of the following is the main impact of rapid population growth in Ethiopia?"
    ],
    "explanation": [
      "In a largely agrarian country like Ethiopia, rapid population growth puts immense pressure on land resources. It leads to the clearing of forests for farming, overgrazing of pastures, and cultivation of steep slopes, all of which are major causes of soil erosion and degradation."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10344,
        "content": [
          "Air pollution"
        ],
        "isCorrect": false
      },
      {
        "id": 10345,
        "content": [
          "Water pollution"
        ],
        "isCorrect": false
      },
      {
        "id": 10346,
        "content": [
          "Soil degradation"
        ],
        "isCorrect": true
      },
      {
        "id": 10347,
        "content": [
          "Traffic congestion"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2585,
    "content": [
      "How do you describe the economic growth and development trend of Ethiopia?"
    ],
    "explanation": [
      "In recent decades, Ethiopia has invested heavily in infrastructure development, particularly road construction. This has significantly increased the network of all-weather roads, improving connectivity between rural and urban areas and facilitating economic activity."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10348,
        "content": [
          "Many settlements have access to all-weather roads."
        ],
        "isCorrect": true
      },
      {
        "id": 10349,
        "content": [
          "The country has the highest literacy rates in Africa."
        ],
        "isCorrect": false
      },
      {
        "id": 10350,
        "content": [
          "Malnutrition is a serious problem in urban areas than it is in rural areas."
        ],
        "isCorrect": false
      },
      {
        "id": 10351,
        "content": [
          "School dropouts are higher in urban areas than in rural areas."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2586,
    "content": [
      "What should policy makers in Ethiopia do to boost the economy?"
    ],
    "explanation": [
      "A key strategy for sustainable economic growth is export diversification. Relying on a few primary commodities makes an economy vulnerable to price fluctuations. By promoting a wider variety of export goods, including manufactured products and services, a country can create more stable revenue streams and boost its economy."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10352,
        "content": [
          "Encouraging state control of the economy"
        ],
        "isCorrect": false
      },
      {
        "id": 10353,
        "content": [
          "Encouraging population growth of the country"
        ],
        "isCorrect": false
      },
      {
        "id": 10354,
        "content": [
          "Promoting import of luxury items"
        ],
        "isCorrect": false
      },
      {
        "id": 10355,
        "content": [
          "Promoting diversification of export items"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2587,
    "content": [
      "Why was the Plan for Accelerated and Sustained Development to End Poverty (PASDEP) not successful as planned in Ethiopia?"
    ],
    "explanation": [
      "PASDEP was implemented from 2005 to 2010. Its later years coincided with the global financial crisis of 2008-2009. This crisis led to reduced foreign direct investment, lower export earnings, and decreased development aid, which significantly hampered the achievement of the ambitious goals set out in the plan."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10356,
        "content": [
          "Because of a lack of study support from experts"
        ],
        "isCorrect": false
      },
      {
        "id": 10357,
        "content": [
          "Due to the then global financial crisis"
        ],
        "isCorrect": true
      },
      {
        "id": 10358,
        "content": [
          "Because of the recurrent flooding in the country"
        ],
        "isCorrect": false
      },
      {
        "id": 10359,
        "content": [
          "Due to shortage of working labor force"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2588,
    "content": [
      "Which one the following describes the distribution of pressure over the surface of the earth?"
    ],
    "explanation": [
      "The global pressure belts (like the ITCZ and subtropical highs) follow the seasonal migration of the sun's direct rays. When the sun is overhead at the Tropic of Capricorn (during the Southern Hemisphere's summer, around December), the zone of maximum heating shifts south. This causes the entire system of pressure belts to also shift southward."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10360,
        "content": [
          "When the sun is overhead north of the equator, pressure belts shift southward."
        ],
        "isCorrect": false
      },
      {
        "id": 10361,
        "content": [
          "When the sun is overhead at the equator, pressure belts move northward by small degrees."
        ],
        "isCorrect": false
      },
      {
        "id": 10362,
        "content": [
          "When the sun is overhead at the Tropic of Cancer, pressure belts shift southward."
        ],
        "isCorrect": false
      },
      {
        "id": 10363,
        "content": [
          "When the sun is overhead at the Tropic of Capricorn, pressure belts shift southward."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2589,
    "content": [
      "Which one of the statements below explains the characteristics of a region?"
    ],
    "explanation": [
      "A climatic region refers to a continuous geographic area in which similar climate characteristics are observed. Climate classifications, such as Köppen’s, identify climatic zones based on criteria like temperature and precipitation, and they show a strong alignment with natural vegetation and soil types. These shared (or distinct) characteristics define the nature of the region."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10364,
        "content": [
          "A region has distinct physical elements."
        ],
        "isCorrect": true
      },
      {
        "id": 10365,
        "content": [
          "A region can be either artificial or natural."
        ],
        "isCorrect": false
      },
      {
        "id": 10366,
        "content": [
          "To be a region an area needs to be large."
        ],
        "isCorrect": false
      },
      {
        "id": 10367,
        "content": [
          "A region has a clear boundary."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2590,
    "content": [
      "One of the following describes the tropical zone of the earth. Which one is it?"
    ],
    "explanation": [
      "The tropical zone, or the tropics, is the region of the Earth surrounding the Equator. It is geographically defined as the area lying between the Tropic of Cancer in the Northern Hemisphere and the Tropic of Capricorn in the Southern Hemisphere."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10368,
        "content": [
          "It is found between the Tropic of Cancer and the Tropic of Capricorn."
        ],
        "isCorrect": true
      },
      {
        "id": 10369,
        "content": [
          "It is mostly covered by semi-desert and desert vegetation."
        ],
        "isCorrect": false
      },
      {
        "id": 10370,
        "content": [
          "It is characterized by low temperature year round."
        ],
        "isCorrect": false
      },
      {
        "id": 10371,
        "content": [
          "It is dominated by manufacturing economic activity."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2591,
    "content": [
      "Which of the following best explains the Tundra region?"
    ],
    "explanation": [
      "The Tundra is located in high latitudes (Arctic and Antarctic regions). Due to the tilt of the Earth's axis, these regions experience extreme seasonal variations in daylight. During the short summer, the sun remains above the horizon for very long periods, leading to a long duration of daily sunlight, sometimes for 24 hours a day (the \"midnight sun\")."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10372,
        "content": [
          "It has the highest daily range of temperature."
        ],
        "isCorrect": false
      },
      {
        "id": 10373,
        "content": [
          "It is mostly located in the southern hemisphere."
        ],
        "isCorrect": false
      },
      {
        "id": 10374,
        "content": [
          "It receives a long daily duration of sunlight in summer."
        ],
        "isCorrect": true
      },
      {
        "id": 10375,
        "content": [
          "It is inhabited by people whose life style is advanced."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2592,
    "content": [
      "What change is mainly brought due to the development of transport and communication technologies?"
    ],
    "explanation": [
      "Advanced communication technologies, particularly the internet, have enabled remote work or telecommuting. This allows individuals to be employed by and work for companies located far away, without needing to be physically present at an office, fundamentally changing the relationship between work and location."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ECONOMIC_AND_CULTURAL_ACTIVITIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10376,
        "content": [
          "Distance and time have got great impact on the production"
        ],
        "isCorrect": false
      },
      {
        "id": 10377,
        "content": [
          "Production of perishable products near major urban centers"
        ],
        "isCorrect": false
      },
      {
        "id": 10378,
        "content": [
          "Location of industries near resources and energy supplies"
        ],
        "isCorrect": false
      },
      {
        "id": 10379,
        "content": [
          "Working for companies without physically being there"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2593,
    "content": [
      "Among the following, which one is primarily used to gather population data from a segment of the whole population?"
    ],
    "explanation": [
      "A sample survey is a statistical method that involves collecting data from a representative subset, or segment, of a population. The results from this sample are then used to make inferences or generalizations about the entire population. A census, by contrast, attempts to collect data from every member of the population."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_SPATIAL_INFORMATION_AND_DATA_PROCESSING",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10380,
        "content": [
          "Divorce records"
        ],
        "isCorrect": false
      },
      {
        "id": 10381,
        "content": [
          "Vital registration"
        ],
        "isCorrect": false
      },
      {
        "id": 10382,
        "content": [
          "Sample survey"
        ],
        "isCorrect": true
      },
      {
        "id": 10383,
        "content": [
          "Census"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2594,
    "content": [
      "Which one of the following is the sparsely populated part of the world?"
    ],
    "explanation": [
      "Sparse population in Indonesian basins is a result of **physical geography**, primarily consisting of **dense tropical rainforests** and difficult terrain (swamps or mountains), which severely restrict agriculture, infrastructure development, and overall human settlement, unlike the high-density areas of Asia, North America, and Europe."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10384,
        "content": [
          "Indonesia basins"
        ],
        "isCorrect": true
      },
      {
        "id": 10385,
        "content": [
          "East and south Asia"
        ],
        "isCorrect": false
      },
      {
        "id": 10386,
        "content": [
          "Northeastern North America"
        ],
        "isCorrect": false
      },
      {
        "id": 10387,
        "content": [
          "Peninsular Europe"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2595,
    "content": [
      "What is the main role of the tertiary economic activities in a given country's development?"
    ],
    "explanation": [
      "The tertiary sector of the economy is also known as the service sector. Its main role is to provide services to consumers and other businesses, rather than producing raw materials (primary sector) or manufactured goods (secondary sector). Examples include retail, healthcare, education, finance, and transportation."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_DEVELOPMENT_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10388,
        "content": [
          "Making high-level decisions"
        ],
        "isCorrect": false
      },
      {
        "id": 10389,
        "content": [
          "Providing services"
        ],
        "isCorrect": true
      },
      {
        "id": 10390,
        "content": [
          "Producing agricultural crops"
        ],
        "isCorrect": false
      },
      {
        "id": 10391,
        "content": [
          "Processing raw materials"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2596,
    "content": [
      "Which of the following country is the leading in fish processing industry in Africa?"
    ],
    "explanation": [
      "Morocco has a very long coastline on both the Atlantic Ocean and the Mediterranean Sea, with rich fishing grounds. It has developed a large and modern fish processing industry, particularly for sardines and tuna, making it one of the leading exporters of processed fish products in Africa and the world."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ECONOMIC_AND_CULTURAL_ACTIVITIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10392,
        "content": [
          "Morocco"
        ],
        "isCorrect": true
      },
      {
        "id": 10393,
        "content": [
          "Nigeria"
        ],
        "isCorrect": false
      },
      {
        "id": 10394,
        "content": [
          "South Africa"
        ],
        "isCorrect": false
      },
      {
        "id": 10395,
        "content": [
          "Egypt"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2597,
    "content": [
      "Which statement best explains the practice of placer mining in Africa?"
    ],
    "explanation": [
      "Placer mining is a method of extracting valuable minerals (like gold, diamonds, tin) from placer deposits, which are accumulations of sediment, typically sand and gravel, in riverbeds, floodplains, or ancient stream beds. The process involves washing or sifting through this excavated soil and sediment to separate the denser minerals."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_NATURAL_RESOURCES_AND_MANAGEMENT",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10396,
        "content": [
          "It is one of the modern and highly productive ways of mining."
        ],
        "isCorrect": false
      },
      {
        "id": 10397,
        "content": [
          "It is a process of quarrying useful stones for construction purpose."
        ],
        "isCorrect": false
      },
      {
        "id": 10398,
        "content": [
          "It is commonly practiced in areas situated far from river valleys."
        ],
        "isCorrect": false
      },
      {
        "id": 10399,
        "content": [
          "It is a process of extracting mineral deposits from excavated soils."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2598,
    "content": [
      "In which of the following contexts can the qualitative research be the preferred approach?"
    ],
    "explanation": [
      "Qualitative research is often exploratory in nature. It aims to understand underlying reasons, opinions, and motivations. Unlike quantitative research, which starts with a specific hypothesis to test, qualitative research often begins with a broad question and allows themes and theories to emerge from the data, sometimes without a pre-defined hypothesis."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10400,
        "content": [
          "If the association among variables is to be quantified."
        ],
        "isCorrect": false
      },
      {
        "id": 10401,
        "content": [
          "If continuous variables are to be analyzed."
        ],
        "isCorrect": false
      },
      {
        "id": 10402,
        "content": [
          "If there is no need of hypothesis testing."
        ],
        "isCorrect": true
      },
      {
        "id": 10403,
        "content": [
          "If a given theory is to be verified."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2599,
    "content": [
      "Which of the following is correct about research method and methodology?"
    ],
    "explanation": [
      "Research methodology is the broad, systematic, and theoretical approach to a research study. It encompasses the principles and procedures that guide the research process, including how a problem is studied, the logic behind the chosen methods, and how the results are interpreted. It provides the overall framework for conducting scientific research. Methods are the specific tools within that framework."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10404,
        "content": [
          "Research method justifies the philosophical foundation of the research."
        ],
        "isCorrect": false
      },
      {
        "id": 10405,
        "content": [
          "Research methodology is limited to collecting and organizing data to solve problems."
        ],
        "isCorrect": false
      },
      {
        "id": 10406,
        "content": [
          "Research method has a wider scope than research methodology."
        ],
        "isCorrect": false
      },
      {
        "id": 10407,
        "content": [
          "Research methodology guides to conduct scientific research."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2600,
    "content": [
      "If you were commissioned to conduct an empirical study, which basic element of research might enable you to identify gaps to be filled by your study?"
    ],
    "explanation": [
      "A literature review is a critical evaluation of existing research on a topic. By systematically reviewing what is already known, a researcher can identify unanswered questions, unresolved issues, or areas that have not been adequately studied. This process is essential for identifying the \"gap\" in knowledge that the new study aims to fill."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10408,
        "content": [
          "Developing a hypothesis"
        ],
        "isCorrect": false
      },
      {
        "id": 10409,
        "content": [
          "Reviewing related literature"
        ],
        "isCorrect": true
      },
      {
        "id": 10410,
        "content": [
          "Delineating the scope of the study"
        ],
        "isCorrect": false
      },
      {
        "id": 10411,
        "content": [
          "Defining a sampling design"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2601,
    "content": [
      "How is the relative location of the Horn of Africa described?"
    ],
    "explanation": [
      "The Horn of Africa is a peninsula in Northeast Africa. Its relative location is defined by the major bodies of water surrounding it. To its northeast lies the Red Sea, which separates it from the Arabian Peninsula."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10412,
        "content": [
          "It is adjoined by the Red Sea in the northeast."
        ],
        "isCorrect": true
      },
      {
        "id": 10413,
        "content": [
          "It is bounded in the northwest by the Indian Ocean."
        ],
        "isCorrect": false
      },
      {
        "id": 10414,
        "content": [
          "It is situated to the southeast of Asia."
        ],
        "isCorrect": false
      },
      {
        "id": 10415,
        "content": [
          "It is bordered by the Sudan in the southwest."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2602,
    "content": [
      "What would be the challenge of a country with a large areal size?"
    ],
    "explanation": [
      "A country with a large areal size typically has very long international borders. Managing, monitoring, and securing these extensive borders against illegal crossings, smuggling, and other threats is a significant logistical, financial, and security challenge."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10416,
        "content": [
          "Ethnic and language diversities"
        ],
        "isCorrect": false
      },
      {
        "id": 10417,
        "content": [
          "Shortage of arable land"
        ],
        "isCorrect": false
      },
      {
        "id": 10418,
        "content": [
          "Difficulty of border control"
        ],
        "isCorrect": true
      },
      {
        "id": 10419,
        "content": [
          "Varied agro-ecological zones"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2603,
    "content": [
      "What major event took place in the Horn during the Paleozoic Era?"
    ],
    "explanation": [
      "The Paleozoic Era (≈600–250 million years ago) is known as the **age of ancient life**, marked by the predominance of **invertebrates** like trilobites and shelled animals. In the Horn of Africa, this era saw mainly **denudation and peneplanation**, with **no major structural formations**, making the appearance of invertebrate marine life the defining global feature."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_EARTH_FORMATION_AND_STRUCTURE",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10420,
        "content": [
          "Climatic change with a massive deposition"
        ],
        "isCorrect": false
      },
      {
        "id": 10421,
        "content": [
          "Appearance of invertebrate marine creatures"
        ],
        "isCorrect": true
      },
      {
        "id": 10422,
        "content": [
          "Significant structural formation in the Horn"
        ],
        "isCorrect": false
      },
      {
        "id": 10423,
        "content": [
          "A continued and massive orogenic movement"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2604,
    "content": [
      "These questions are based on the table given.",
      "---",
      "Which station has the highest annual range of temperature?"
    ],
    "explanation": [
      "The annual range of temperature is the difference between the highest and lowest monthly average temperatures.",
      "Station I: 27°C - 26°C = 1°C.",
      "Station II: 35°C - 25°C = 10°C.",
      "Station III: 23°C - 11°C = 12°C.",
      "Station IV: 34°C - 24°C = 10°C.",
      "Station III has the highest range of 12°C."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_SPATIAL_INFORMATION_AND_DATA_PROCESSING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 86,
    "groupIndex": 1,
    "sharedContentId": 22,
    "sharedContent": [
      "The table below shows climatic data of a hypothetical region.",
      "images/geography/year_2015/shared_content_1.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_1.png"
    ],
    "choices": [
      {
        "id": 10424,
        "content": [
          "Station III"
        ],
        "isCorrect": true
      },
      {
        "id": 10425,
        "content": [
          "Station I"
        ],
        "isCorrect": false
      },
      {
        "id": 10426,
        "content": [
          "Station IV"
        ],
        "isCorrect": false
      },
      {
        "id": 10427,
        "content": [
          "Station II"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2605,
    "content": [
      "These questions are based on the table given.",
      "---",
      "What type of natural vegetation is predominant at station II?"
    ],
    "explanation": [
      "Station II has consistently high temperatures (25°C to 35°C) and extremely low rainfall throughout the year. This combination describes a hot desert or arid climate. The vegetation adapted to survive in such dry conditions is known as xerophytes."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 86,
    "groupIndex": 2,
    "sharedContentId": 22,
    "sharedContent": [
      "The table below shows climatic data of a hypothetical region.",
      "images/geography/year_2015/shared_content_1.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_1.png"
    ],
    "choices": [
      {
        "id": 10428,
        "content": [
          "Conifers"
        ],
        "isCorrect": false
      },
      {
        "id": 10429,
        "content": [
          "Maquis"
        ],
        "isCorrect": false
      },
      {
        "id": 10430,
        "content": [
          "Xerophytes"
        ],
        "isCorrect": true
      },
      {
        "id": 10431,
        "content": [
          "Alpine"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2606,
    "content": [
      "These questions are based on the table given.",
      "---",
      "What type of ecosystem is represented by station I?"
    ],
    "explanation": [
      "Station I exhibits consistently high temperatures (around 26-27°C) and very high rainfall in every month of the year. This climate pattern, with no dry season, is characteristic of a tropical rainforest ecosystem."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_HUMAN_ENVIRONMENT_INTERACTIONS_AND_ISSUES",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 86,
    "groupIndex": 3,
    "sharedContentId": 22,
    "sharedContent": [
      "The table below shows climatic data of a hypothetical region.",
      "images/geography/year_2015/shared_content_1.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_1.png"
    ],
    "choices": [
      {
        "id": 10432,
        "content": [
          "Grass lands"
        ],
        "isCorrect": false
      },
      {
        "id": 10433,
        "content": [
          "Tropical rainforest"
        ],
        "isCorrect": true
      },
      {
        "id": 10434,
        "content": [
          "Deciduous forest"
        ],
        "isCorrect": false
      },
      {
        "id": 10435,
        "content": [
          "Coniferous forest"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2607,
    "content": [
      "These questions are based on the table given.",
      "---",
      "Which station best represents the winter rainfall region of Ethiopia?"
    ],
    "explanation": [
      "Station IV is the best representation of a winter rainfall region. In the context of Ethiopia, winter rainfall occurs during December, January, and February, while the summer months of June to August are dry.\n\nStation I has high rainfall year-round, characteristic of a tropical rainforest climate, and Station II has very low rainfall, typical of an arid or desert climate.\n\nStation III shows a clear summer rainfall pattern, with peaks in June, July, and August.\n\nOnly Station IV exhibits the defining pattern of wet winters and dry summers, with rainfall highest in December (37 mm), January (41 mm), and February (39 mm), and lowest in June (1 mm) and July (4 mm)."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_CLIMATE_AND_CLIMATIC_REGIONS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 86,
    "groupIndex": 4,
    "sharedContentId": 22,
    "sharedContent": [
      "The table below shows climatic data of a hypothetical region.",
      "images/geography/year_2015/shared_content_1.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_1.png"
    ],
    "choices": [
      {
        "id": 10436,
        "content": [
          "Station I"
        ],
        "isCorrect": false
      },
      {
        "id": 10437,
        "content": [
          "Station II"
        ],
        "isCorrect": false
      },
      {
        "id": 10438,
        "content": [
          "Station III"
        ],
        "isCorrect": false
      },
      {
        "id": 10439,
        "content": [
          "Station IV"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2608,
    "content": [
      "These questions are based on the data in the table.",
      "---",
      "What can be generalized about the population structure of the region?"
    ],
    "explanation": [
      "The region has 16% children, 65% working-age, and 19% elderly, with more males than females. Compared to developing countries, where the old population is typically around 3%, this region’s 19% elderly indicates an unusually high proportion of older people, making the most accurate generalization that it has a higher percentage of old population.",
      "IsGrouped: true\nGroupId: 87\nGroupIndex: 1\nSharedItemId: 23"
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 87,
    "groupIndex": 1,
    "sharedContentId": 23,
    "sharedContent": [
      "The table below shows demographic data of a hypothetical region.",
      "images/geography/year_2015/shared_content_2.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_2.png"
    ],
    "choices": [
      {
        "id": 10440,
        "content": [
          "The region has higher percentage of economically dependent child population."
        ],
        "isCorrect": false
      },
      {
        "id": 10441,
        "content": [
          "The number of economically active population of the region is lower than the Sub-Saharan Africa."
        ],
        "isCorrect": false
      },
      {
        "id": 10442,
        "content": [
          "As compared to developing countries the region has higher percentage of old population."
        ],
        "isCorrect": true
      },
      {
        "id": 10443,
        "content": [
          "The region has higher number of female population than male."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2609,
    "content": [
      "These questions are based on the data in the table.",
      "---",
      "What is the crude birth rate of the population?"
    ],
    "explanation": [
      "The crude birth rate (CBR) is calculated as (Total Live Births / Total Population) × 1000.",
      "CBR = (380,139 / 37,742,154) × 1000 ≈ 10.07 per 1000.",
      "This is approximately 10/1000."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 87,
    "groupIndex": 2,
    "sharedContentId": 23,
    "sharedContent": [
      "The table below shows demographic data of a hypothetical region.",
      "images/geography/year_2015/shared_content_2.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_2.png"
    ],
    "choices": [
      {
        "id": 10444,
        "content": [
          "5/1000"
        ],
        "isCorrect": false
      },
      {
        "id": 10445,
        "content": [
          "10/1000"
        ],
        "isCorrect": true
      },
      {
        "id": 10446,
        "content": [
          "15/1000"
        ],
        "isCorrect": false
      },
      {
        "id": 10447,
        "content": [
          "25/1000"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2610,
    "content": [
      "These questions are based on the data in the table.",
      "---",
      "What is the population growth rate of the region?"
    ],
    "explanation": [
      "Population Growth Rate = Rate of Natural Increase + Net Migration Rate.",
      "Crude Birth Rate (CBR) ≈ 10.07/1000.",
      "Crude Death Rate (CDR) = (323,220 / 37,742,154) × 1000 ≈ 8.56/1000.",
      "Rate of Natural Increase (RNI) = CBR - CDR = 10.07 - 8.56 = 1.51/1000.",
      "Net Migration Rate (NMR) = 10/1000.",
      "Population Growth Rate = 1.51/1000 + 10/1000 = 11.51/1000.",
      "In percentage, this is 11.51 / 10 = 1.151%. The closest answer is 1.14%."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 87,
    "groupIndex": 3,
    "sharedContentId": 23,
    "sharedContent": [
      "The table below shows demographic data of a hypothetical region.",
      "images/geography/year_2015/shared_content_2.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_2.png"
    ],
    "choices": [
      {
        "id": 10448,
        "content": [
          "2.4%"
        ],
        "isCorrect": false
      },
      {
        "id": 10449,
        "content": [
          "2.5%"
        ],
        "isCorrect": false
      },
      {
        "id": 10450,
        "content": [
          "1.74%"
        ],
        "isCorrect": false
      },
      {
        "id": 10451,
        "content": [
          "1.14%"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2611,
    "content": [
      "These questions are based on the data in the table.",
      "---",
      "The maternal mortality rate of the region is"
    ],
    "explanation": [
      "Standard Maternal Mortality Rate is calculated per 100,000 live births.\n\nIf we calculate the number of maternal deaths per 1000 reproductive women, we get:",
      "(Death of Mothers / Reproductive Women Population) × 1000 = (9,619 / 9,061,821) × 1000 ≈ 1.06 per 1000.",
      "This value is close to 1/1000."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_POPULATION_STUDIES",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 87,
    "groupIndex": 4,
    "sharedContentId": 23,
    "sharedContent": [
      "The table below shows demographic data of a hypothetical region.",
      "images/geography/year_2015/shared_content_2.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_2.png"
    ],
    "choices": [
      {
        "id": 10452,
        "content": [
          "1/1000."
        ],
        "isCorrect": true
      },
      {
        "id": 10453,
        "content": [
          "5/1000."
        ],
        "isCorrect": false
      },
      {
        "id": 10454,
        "content": [
          "4/1000."
        ],
        "isCorrect": false
      },
      {
        "id": 10455,
        "content": [
          "3/1000."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2612,
    "content": [
      "These questions are based on the map given.",
      "---",
      "What is the areal scale of the map?"
    ],
    "explanation": [
      "First, find the linear scale. The map scale is 1:150,000. This means 1 cm on the map represents 150,000 cm in reality.",
      "To convert to kilometers: 150,000 cm = 1,500 m = 1.5 km. So, 1 cm = 1.5 km.",
      "To find the areal scale, square both sides: (1 cm)² = (1.5 km)².",
      "1 cm² = 2.25 km². The closest option is 2.3 km²."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 88,
    "groupIndex": 1,
    "sharedContentId": 24,
    "sharedContent": [
      "Below is a topographic map.",
      "images/geography/year_2015/shared_content_3_background.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_3_background.png"
    ],
    "choices": [
      {
        "id": 10456,
        "content": [
          "1cm² to 1.5 km²"
        ],
        "isCorrect": false
      },
      {
        "id": 10457,
        "content": [
          "1cm² to 3 km²"
        ],
        "isCorrect": false
      },
      {
        "id": 10458,
        "content": [
          "1cm² to 2.3 km²"
        ],
        "isCorrect": true
      },
      {
        "id": 10459,
        "content": [
          "1cm² to 4.5 km²"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2613,
    "content": [
      "These questions are based on the map given.",
      "---",
      "What is the geographic grid of point 'V'?"
    ],
    "explanation": [
      "To find the coordinates of point 'V', follow the grid lines. The horizontal line passing through 'V' is labeled 9°6'0\"S (latitude). The vertical line passing through 'V' is labeled 33°42'0\"E (longitude). Therefore, the geographic grid is 9°6'0\"S 33°42'0\"E."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 88,
    "groupIndex": 2,
    "sharedContentId": 24,
    "sharedContent": [
      "Below is a topographic map.",
      "images/geography/year_2015/shared_content_3_background.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_3_background.png"
    ],
    "choices": [
      {
        "id": 10460,
        "content": [
          "9°6'0\"S 33°42'0\"E"
        ],
        "isCorrect": true
      },
      {
        "id": 10461,
        "content": [
          "9°12'0\"S 33°36'0\"E"
        ],
        "isCorrect": false
      },
      {
        "id": 10462,
        "content": [
          "33°42'0\"E 9°6'0\"S"
        ],
        "isCorrect": false
      },
      {
        "id": 10463,
        "content": [
          "9°12'0\"N 33°36'0\"W"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2614,
    "content": [
      "These questions are based on the map given.",
      "---",
      "What is the altitude of point 'N'? (Distance between upper and lower contours is 8mm and distance of the point 'N' from upper contour is 5mm)"
    ],
    "explanation": [
      "The labeled contours are 1000, 1500, etc. There are four unlabeled lines between them, so the contour interval is 100m. Point 'N' is between the 1400m and 1500m contours.",
      "The vertical interval between these two contours is 100m. The point is 5/8 of the horizontal distance down from the upper contour (1500m).",
      "Drop in elevation = (5/8) × 100m = 62.5m.",
      "Altitude of N = Upper Contour - Drop = 1500m - 62.5m = 1437.5m."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 88,
    "groupIndex": 3,
    "sharedContentId": 24,
    "sharedContent": [
      "Below is a topographic map.",
      "images/geography/year_2015/shared_content_3_background.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_3_background.png"
    ],
    "choices": [
      {
        "id": 10464,
        "content": [
          "1462.5 m"
        ],
        "isCorrect": false
      },
      {
        "id": 10465,
        "content": [
          "1437.5 m"
        ],
        "isCorrect": true
      },
      {
        "id": 10466,
        "content": [
          "1452.5 m"
        ],
        "isCorrect": false
      },
      {
        "id": 10467,
        "content": [
          "1447.5 m"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2615,
    "content": [
      "These questions are based on the map given.",
      "---",
      "Which of the following marginal information is depicted on the map?"
    ],
    "explanation": [
      "Marginal information refers to details provided in the map's margin. Looking at the map, there is a clear north direction arrow in the upper right corner. The scale is also present at the bottom, but the title, projection, and publication year are not shown."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 88,
    "groupIndex": 4,
    "sharedContentId": 24,
    "sharedContent": [
      "Below is a topographic map.",
      "images/geography/year_2015/shared_content_3_background.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_3_background.png"
    ],
    "choices": [
      {
        "id": 10468,
        "content": [
          "Direction arrow"
        ],
        "isCorrect": true
      },
      {
        "id": 10469,
        "content": [
          "Type of projection"
        ],
        "isCorrect": false
      },
      {
        "id": 10470,
        "content": [
          "Title of the map"
        ],
        "isCorrect": false
      },
      {
        "id": 10471,
        "content": [
          "Year of publication"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 2616,
    "content": [
      "These questions are based on the map given.",
      "---",
      "Which type of slope is shown by line 'KL'?"
    ],
    "explanation": [
      "Along line **KL**, the contour lines are **widely spaced near K** (gentle lower part) and **closer together toward L** (steeper upper part). This pattern of gentle at the base, steep at the top defines a **concave slope**."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_MAP_SKILLS_AND_GEOGRAPHICAL_ENQUIRY",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 88,
    "groupIndex": 5,
    "sharedContentId": 24,
    "sharedContent": [
      "Below is a topographic map.",
      "images/geography/year_2015/shared_content_3_background.png"
    ],
    "images": [
      "images/geography/year_2015/shared_content_3_background.png"
    ],
    "choices": [
      {
        "id": 10472,
        "content": [
          "Even"
        ],
        "isCorrect": false
      },
      {
        "id": 10473,
        "content": [
          "Terraced"
        ],
        "isCorrect": false
      },
      {
        "id": 10474,
        "content": [
          "Convex"
        ],
        "isCorrect": false
      },
      {
        "id": 10475,
        "content": [
          "Concave"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 2617,
    "content": [
      "What is the most appropriate technique to display statistical data of portion of parts in relation to a single whole?"
    ],
    "explanation": [
      "A pie chart is specifically designed to represent proportions. The entire circle (the \"pie\") represents the total amount (100%), and the different sized \"slices\" represent the various parts or percentages that make up that whole."
    ],
    "year": "YEAR_2015",
    "subject": "GEOGRAPHY",
    "chapter": "GEO_SPATIAL_INFORMATION_AND_DATA_PROCESSING",
    "field": "SOCIAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10476,
        "content": [
          "Bar graph"
        ],
        "isCorrect": false
      },
      {
        "id": 10477,
        "content": [
          "Line graph"
        ],
        "isCorrect": false
      },
      {
        "id": 10478,
        "content": [
          "Pie chart"
        ],
        "isCorrect": true
      },
      {
        "id": 10479,
        "content": [
          "Histogram"
        ],
        "isCorrect": false
      }
    ]
  }
];
export default questions;
