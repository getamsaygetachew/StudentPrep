// StudentPrep Premium Content — complete question bank.
const questions = [
  {
    "id": 1026,
    "content": [
      "Given two vectors u = (1, 3) and v = (-3, 5) in the plane. Then 6u + 2v is equal to"
    ],
    "explanation": [
      "To find $$6\\mathbf{u} + 2\\mathbf{v}$$, we first compute the scalar multiples of the vectors $$\\mathbf{u}$$ and $$\\mathbf{v}$$, and then add the resulting vectors.\n- Compute $$6\\mathbf{u}$$: $$6\\mathbf{u}$$ = $$6 \\cdot (1, 3)$$ = $$(6 \\cdot 1, 6 \\cdot 3)$$ = $$(6, 18)$$\n- Compute $$2\\mathbf{v}$$: $$2\\mathbf{v}$$ = $$2 \\cdot (-3, 5)$$ = $$(2 \\cdot -3, 2 \\cdot 5)$$ = $$(-6, 10)$$\n- Add the results: $$6\\mathbf{u}$$ + $$2\\mathbf{v}$$ = $$(6, 18)$$ + $$(-6, 10)$$ = $$(6 + (-6), 18 + 10)$$ = $$(0, 28)$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_VECTORS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4105,
        "content": [
          "(0, 18)"
        ],
        "isCorrect": false
      },
      {
        "id": 4106,
        "content": [
          "(3, 3)"
        ],
        "isCorrect": false
      },
      {
        "id": 4107,
        "content": [
          "(2, 28)"
        ],
        "isCorrect": false
      },
      {
        "id": 4108,
        "content": [
          "(0, 28)"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 8,
    "unitName": "Vectors in 2D"
  },
  {
    "id": 1027,
    "content": [
      "Which one of the following is the standard form of the equation of the circle centered at (2, -3) and radius 5?"
    ],
    "explanation": [
      "Standard form of a circle: $$(x - h)^2 + (y - k)^2$$ = $$r^2$$, where $$(h, k)$$ is the center and $$r$$ is the radius.\n- Given center (2, -3) and radius 5:\n$$\n(x - 2)^2 + (y + 3)^2 = 25\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4109,
        "content": [
          "$$(x - 2)^2 + (y - 3)^2$$ = $$25$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4110,
        "content": [
          "$$(x - 2)^2 + (y + 3)^2$$ = $$25$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4111,
        "content": [
          "$$(x - 2)^2 + (y + 3)^2$$ = $$5$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4112,
        "content": [
          "$$(x + 2)^2 + (y - 3)^2$$ = $$25$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1028,
    "content": [
      "If f is a continuous function on [a, b] and F is its anti-derivative, then which of the following is true?"
    ],
    "explanation": [
      "If F is an antiderivative of f, then:\n$$\n\\int_{a}^{b} f(x)dx = F(b) - F(a)\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4113,
        "content": [
          "$$\\int_{a}^{b} F(x)dx$$ = $$f(b) - f(a)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4114,
        "content": [
          "$$\\int_{a}^{b} F'(x)dx$$ = $$f(b) - f(a)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4115,
        "content": [
          "$$\\int_{a}^{b} f(x)dx$$ = $$F(b) - F(a)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4116,
        "content": [
          "$$\\int_{a}^{b} f'(x)dx$$ = $$F(b) - F(a)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1029,
    "content": [
      "Which of the following defines the equation of a sphere whose center is at (0, -1, 2) and radius 6 units?"
    ],
    "explanation": [
      "Standard form of a sphere: $$(x - h)^2$$ + $$(y - k)^2$$ + $$(z - l)^2$$ = $$r^2$$, where $$(h, k, l)$$ is the center and $$r$$ is the radius.\n\nGiven center (0, -1, 2) and radius 6:\n$$\nx^2 + (y + 1)^2 + (z - 2)^2 = 36\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4117,
        "content": [
          "$$x^2 + (y + 1)^2 + (z - 2)^2 = 36$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4118,
        "content": [
          "$$x^2 + (y - 1)^2 + (z - 2)^2 = 36$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4119,
        "content": [
          "$$x^2 + (y + 1)^2 + (z - 2)^2 = 12$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4120,
        "content": [
          "$$x^2 + (y + 1)^2 + (z + 2)^2 = 36$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1030,
    "content": [
      "Which of the following represents the vector $$(3, -5, 7)$$ in the space using the standard unit vectors $$i, j$$ and $$k$$?"
    ],
    "explanation": [
      "The vector (3, -5, 7) in standard unit vectors is:\n$$\n3i - 5j + 7k\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_VECTORS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4121,
        "content": [
          "$$3i - 5j - 7k$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4122,
        "content": [
          "$$3i + 5j + 7k$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4123,
        "content": [
          "$$3i - 5j + 7k$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4124,
        "content": [
          "$$-3i - 5j - 7k$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 8,
    "unitName": "Vectors in 2D"
  },
  {
    "id": 1031,
    "content": [
      "Which one of the following is the scalar (dot) product of the vectors (2, -4, 6) and (-2, -1, 0)?"
    ],
    "explanation": [
      "The scalar (dot) product of (2, -4, 6) and (-2, -1, 0) is calculated as:\n$$\n(2)(-2) + (-4)(-1) + (6)(0)\n$$\n$$\n-4 + 4 + 0 = 0\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_VECTORS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4125,
        "content": [
          "0"
        ],
        "isCorrect": true
      },
      {
        "id": 4126,
        "content": [
          "-8"
        ],
        "isCorrect": false
      },
      {
        "id": 4127,
        "content": [
          "8"
        ],
        "isCorrect": false
      },
      {
        "id": 4128,
        "content": [
          "6"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 8,
    "unitName": "Vectors in 2D"
  },
  {
    "id": 1032,
    "content": [
      "What are the domain and range of the function $$f(x) = 2x^{\\frac{3}{4}}$$ respectively?"
    ],
    "explanation": [
      "The function $$f(x)$$ = $$2x^{\\frac{3}{4}}$$ is defined only for $$x \\geq 0$$ because of the fractional exponent. Thus, the domain is $$[0, \\infty)$$.\n\nSince $$x^{\\frac{3}{4}} \\geq 0$$ for all $$x \\geq 0$$, the range is also $$[0, \\infty)$$.\n\nTherefore, the correct answer is $$[0, \\infty)$$ and $$[0, \\infty)$$."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4129,
        "content": [
          "$$\\mathbb{R}$$ and $$[0, \\infty)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4130,
        "content": [
          "$$[0, \\infty)$$ and $$[0, \\infty)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4131,
        "content": [
          "$$[0, \\infty)$$ and $$\\mathbb{R}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4132,
        "content": [
          "$$[0, \\infty)$$ and $$[0, \\infty)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1033,
    "content": [
      "Which one of the following defines a one-to-one function?"
    ],
    "explanation": [
      "A function is **one-to-one** if each output corresponds to exactly one input.\n- $$f = \\{(x, y): x$$ is a sister of $$y\\}$$: Not a function (one person can have multiple sisters).\n- $$f = \\{(x, y): y = 3x - 1\\}$$: y = 3x - 1 is a linear function with a unique output for each input, so it is one-to-one.\n- $$f = \\{(x, y): y = x^2 + 1\\}$$: $$y$$ = $$x^2 + 1$$ is not one-to-one (e.g., x = 1 and x = -1 give the same output).\n- $$f = \\{(x, y): y$$ is a father of $$x\\}$$: Not a function (one person can have only one father, but a father can have multiple children)."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4133,
        "content": [
          "$$f = \\{(x, y): x$$ is a sister of $$y\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4134,
        "content": [
          "$$f = \\{(x, y): y = 3x - 1\\}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4135,
        "content": [
          "$$f = \\{(x, y): y = x^2 + 1\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4136,
        "content": [
          "$$f = \\{(x, y): y$$ is a father of $$x\\}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1034,
    "content": [
      "The equation of a circle is given by $$(x - 3)^2 + (y + 2)^2 = 9$$. What are the center and the radius of the circle respectively?"
    ],
    "explanation": [
      "The standard form of a circle's equation is $$(x - h)^2$$ + $$(y - k)^2$$ = $$r^2$$, where $$(h, k)$$ is the center and $$r$$ is the radius.\n\nFor the given equation $$(x - 3)^2$$ + $$(y + 2)^2$$ = $$9$$:\n- Center: $$(h, k)$$ = $$(3, -2)$$\n- Radius: $$r$$ = $$\\sqrt{9}$$ = $$3$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4137,
        "content": [
          "$$(3, -2)$$ and $$3$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4138,
        "content": [
          "$$(3, 2)$$ and $$3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4139,
        "content": [
          "$$(3, -2)$$ and $$9$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4140,
        "content": [
          "$$(3, 2)$$ and $$9$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1035,
    "content": [
      "Which one of the following sentences has a truth value?"
    ],
    "explanation": [
      "- **Truth value** requires a statement to be objectively true/false.\n- “Man is mortal!” asserts a factual, universal claim (all humans die), making it **true**.\n- “Man is selfish.” is debatable (subjective), “We shall win!” is a future prediction/opinion, ”Tomorrow is a beautiful day.” is subjective (\"beautiful\")."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4141,
        "content": [
          "Man is selfish."
        ],
        "isCorrect": false
      },
      {
        "id": 4142,
        "content": [
          "We shall win!"
        ],
        "isCorrect": false
      },
      {
        "id": 4143,
        "content": [
          "Man is mortal!"
        ],
        "isCorrect": true
      },
      {
        "id": 4144,
        "content": [
          "Tomorrow is a beautiful day."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1036,
    "content": [
      "What is the determinant of the matrix $$\\begin{bmatrix} 1 & -7 \\\\ 6 & 5 \\end{bmatrix}$$?"
    ],
    "explanation": [
      "1. **Determinant formula for 2x2 matrix** $$\\begin{bmatrix} a & b \\\\ c & d \\end{bmatrix}$$ is **ad - bc**.\n\nFor $$\\begin{bmatrix} 1 & -7 \\\\ 6 & 5 \\end{bmatrix}$$:\n- a = 1, b = -7, c = 6, d = 5.\n- Determinant = (1)(5) - (-7)(6) = 5 + 42 = 47."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4145,
        "content": [
          "-37"
        ],
        "isCorrect": false
      },
      {
        "id": 4146,
        "content": [
          "-47"
        ],
        "isCorrect": false
      },
      {
        "id": 4147,
        "content": [
          "47"
        ],
        "isCorrect": true
      },
      {
        "id": 4148,
        "content": [
          "37"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Determinants and Their Properties"
  },
  {
    "id": 1037,
    "content": [
      "The additive inverse of the complex number 3 - 4i is"
    ],
    "explanation": [
      "**Additive inverse** of a complex number a + bi is -a - bi.\n\nFor 3 - 4i:\n- Additive inverse = -3 + 4i."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4149,
        "content": [
          "3 + 4i"
        ],
        "isCorrect": false
      },
      {
        "id": 4150,
        "content": [
          "-3 - 4i"
        ],
        "isCorrect": false
      },
      {
        "id": 4151,
        "content": [
          "3 - 4i"
        ],
        "isCorrect": false
      },
      {
        "id": 4152,
        "content": [
          "-3 + 4i"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1038,
    "content": [
      "What is the modulus of the complex number -6 + 8i?"
    ],
    "explanation": [
      "**Modulus formula** for a complex number a + bi is $$\\sqrt{a^2 + b^2}$$.\n\nFor -6 + 8i:\n- a = -6, b = 8.\n- Modulus = $$\\sqrt{(-6)^2 + 8^2}$$ = $$\\sqrt{36 + 64}$$ = $$10$$."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4153,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 4154,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 4155,
        "content": [
          "10"
        ],
        "isCorrect": true
      },
      {
        "id": 4156,
        "content": [
          "8"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1039,
    "content": [
      "What are the modulus and argument of the complex number $$2 + 2i$$ respectively?"
    ],
    "explanation": [
      "- **Modulus**: $$\\sqrt{a^2 + b^2}$$.\n- **Argument**: $$\\tan^{-1}\\left(\\frac{b}{a}\\right)$$.\n\nFor 2 + 2i:\n\n- a = 2, b = 2.\n- Modulus = $$\\sqrt{2^2 + 2^2}$$ = $$\\sqrt{8}$$ = $$2\\sqrt{2}$$.\n- Argument = $$\\tan^{-1}\\left(\\frac{2}{2}\\right)$$ = $$\\tan^{-1}(1)$$ = $$\\frac{\\pi}{4}$$."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4157,
        "content": [
          "$$2\\sqrt{2}$$ and $$\\frac{\\pi}{4}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4158,
        "content": [
          "$$2$$ and $$\\frac{\\pi}{4}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4159,
        "content": [
          "$$2\\sqrt{2}$$ and $$-\\frac{\\pi}{4}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4160,
        "content": [
          "$$4$$ and $$\\frac{\\pi}{4}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1040,
    "content": [
      "Consider the following frequency distribution table.",
      "images/maths/year_2013_na/q15_1.png",
      "What is the sixth decile?"
    ],
    "explanation": [
      "To find the sixth decile (D₆) first organize the data in ascending order of value:\n\n| Value | f | CF |\n| --- | --- | --- |\n| 3 | 4 | 4 |\n| 5 | 3 | 7 |\n| 6 | 3 | 10 |\n| 7 | 5 | 15 |\n| 8 | 5 | 20 |\n\nWhere \n\n- Cumulative Frequency (CF)\n- Frequency (f)\n\nNext find position of D₆\n\n$$\nD_6 = \\frac{6}{10} \\times N = 0.6 \\times 20 = 12\n$$\n\nSo, we look for the 12th item in the cumulative frequency. From the CF column:\n\n- CF up to 6 is 10\n- CF up to 7 is 15 → the 12th item lies in this group\n\nThe **6th decile** lies in the class where value = 7."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2013_na/q15_1.png"
    ],
    "choices": [
      {
        "id": 4161,
        "content": [
          "6.5"
        ],
        "isCorrect": false
      },
      {
        "id": 4162,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 4163,
        "content": [
          "7.5"
        ],
        "isCorrect": false
      },
      {
        "id": 4164,
        "content": [
          "7"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 1041,
    "content": [
      "In a certain health center there are 3 doctors, 8 nurses and 2 physicians. In how many ways one can form a group of 5 members consisting of 1 doctor, 3 nurses and 1 physician?"
    ],
    "explanation": [
      "We can calculate the number of ways to form the group by multiplying the number of ways to choose each category:\n- Choose 1 doctor from 3: $$\\binom{3}{1} = 3$$\n- Choose 3 nurses from 8: $$\\binom{8}{3}$$ = $$\\frac{8 \\times 7 \\times 6}{3 \\times 2 \\times 1}$$ = $$56$$\n- Choose 1 physician from 2: $$\\binom{2}{1} = 2$$\n\nThe total number of ways is:\n\n- $$\\binom{3}{1} \\times \\binom{8}{3} \\times \\binom{2}{1}$$ = $$3 \\times 56 \\times 2$$ = $$336$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_PROBABILITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4165,
        "content": [
          "168"
        ],
        "isCorrect": false
      },
      {
        "id": 4166,
        "content": [
          "112"
        ],
        "isCorrect": false
      },
      {
        "id": 4167,
        "content": [
          "336"
        ],
        "isCorrect": true
      },
      {
        "id": 4168,
        "content": [
          "330"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 8,
    "unitName": "Probability"
  },
  {
    "id": 1042,
    "content": [
      "Which one of the following forms represents an exhaustive set of events if a die is thrown once?"
    ],
    "explanation": [
      "For a set of events to be **exhaustive**, it must include all possible outcomes without any overlap or omission.\n- {(1, 2, 3), (4, 5), (6)}, subsets include all possible outcomes (1, 2, 3, 4, 5, 6) without any overlap or missing numbers."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SETS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4169,
        "content": [
          "{(1, 2), (4), (4, 5, 6)}"
        ],
        "isCorrect": false
      },
      {
        "id": 4170,
        "content": [
          "{(1, 2, 3), (4, 5), (6)}"
        ],
        "isCorrect": true
      },
      {
        "id": 4171,
        "content": [
          "{(1, 2), (2), (4, 5), (5, 6)}"
        ],
        "isCorrect": false
      },
      {
        "id": 4172,
        "content": [
          "{(1, 2, 3), (3, 4), (6)}"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1043,
    "content": [
      "A bag contains 2 red, 3 yellow and 5 green balls. One ball is drawn at random. What is the probability that the drawn ball is NOT yellow?"
    ],
    "explanation": [
      "- Total balls = 2 red + 3 yellow + 5 green = **10**\n- Balls that are **not yellow** = 2 red + 5 green = **7**\n- Probability = $$\\frac{\\text{Not yellow}}{\\text{Total}}$$ = $$\\frac{7}{10}$$."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_PROBABILITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4173,
        "content": [
          "$$\\frac{3}{10}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4174,
        "content": [
          "$$\\frac{1}{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4175,
        "content": [
          "$$\\frac{4}{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4176,
        "content": [
          "$$\\frac{7}{10}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 8,
    "unitName": "Probability"
  },
  {
    "id": 1044,
    "content": [
      "Which of the following is the product $$AB$$ of the two matrices $$A$$ = $$\\begin{bmatrix} -2 & 3 \\\\ 1 & 4 \\end{bmatrix}$$ and $$B$$ = $$\\begin{bmatrix} -1 & 5 \\\\ 3 & 0 \\end{bmatrix}$$?"
    ],
    "explanation": [
      "$$\nAB = \\begin{bmatrix} (-2)(-1) + (3)(3) & (-2)(5) + (3)(0) \\\\ (1)(-1) + (4)(3) & (1)(5) + (4)(0) \\end{bmatrix}\n$$\n$$\nAB = \\begin{bmatrix} 11 & -10 \\\\ 11 & 5 \\end{bmatrix}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4177,
        "content": [
          "$$\n\\begin{bmatrix} 11 & -10 \\\\ 11 & 5 \\end{bmatrix}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4178,
        "content": [
          "$$\n\\begin{bmatrix} -11 & 10 \\\\ 11 & 5 \\end{bmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4179,
        "content": [
          "$$\n\\begin{bmatrix} 11 & -10 \\\\ 11 & -5 \\end{bmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4180,
        "content": [
          "$$\n\\begin{bmatrix} -11 & 10 \\\\ 11 & -5 \\end{bmatrix}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Matrices"
  },
  {
    "id": 1045,
    "content": [
      "Which one of the following is **NOT** true about the determinant of a given square matrix $$A$$?"
    ],
    "explanation": [
      "Interchanging two rows of a matrix changes the sign of the determinant, so the determinant does not remain the same. if A' is obtained by swapping two rows of  A.\n$$\n\\det(A') = -\\det(A)\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4181,
        "content": [
          "If $$A$$ contains a row of zeros, then its determinant is zero."
        ],
        "isCorrect": false
      },
      {
        "id": 4182,
        "content": [
          "If $$A$$ has identical rows, then its determinant is zero."
        ],
        "isCorrect": false
      },
      {
        "id": 4183,
        "content": [
          "The determinant of $$A$$ is equal to the determinant of its transpose."
        ],
        "isCorrect": false
      },
      {
        "id": 4184,
        "content": [
          "Interchanging two rows of $$A$$ gives the same determinant."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Determinants and Their Properties"
  },
  {
    "id": 1046,
    "content": [
      "Which of the following is the inverse of the matrix $$\\begin{bmatrix} 2 & 3 \\\\ 3 & 4 \\end{bmatrix}$$?"
    ],
    "explanation": [
      "- **Determinant**: $$\\text{det}$$ = $$(2)(4) - (3)(3)$$ = $$-1$$.\n- For $$\\begin{bmatrix} a & b \\\\ c & d \\end{bmatrix}$$, the inverse is\n$$\n\\frac{1}{\\text{det}} \\begin{bmatrix} d & -b \\\\ -c & a \\end{bmatrix}\n$$\n\nInverse = $$\\frac{1}{-1} \\begin{bmatrix} 4 & -3 \\\\ -3 & 2 \\end{bmatrix}$$ = $$\\begin{bmatrix} -4 & 3 \\\\ 3 & -2 \\end{bmatrix}$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4185,
        "content": [
          "$$\\begin{bmatrix} -4 & 3 \\\\ 3 & -2 \\end{bmatrix}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4186,
        "content": [
          "$$\\begin{bmatrix} -2 & 3 \\\\ 3 & -4 \\end{bmatrix}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4187,
        "content": [
          "$$\\begin{bmatrix} 4 & -3 \\\\ -3 & 2 \\end{bmatrix}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4188,
        "content": [
          "$$\\begin{bmatrix} -4 & -3 \\\\ -3 & -2 \\end{bmatrix}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Determinants and Their Properties"
  },
  {
    "id": 1047,
    "content": [
      "Consider the system of linear equation $$\\begin{cases} 3x-ay=1 \\\\ 6x+4y=5 \\end{cases}$$. Then which of the following is true?"
    ],
    "explanation": [
      "**Write the system in matrix form:**\n$$\n\\begin{pmatrix}\n3 & -a \\\\\n6 & 4\n\\end{pmatrix}\n\\begin{pmatrix} x \\\\ y\n\\end{pmatrix}\n\\begin{pmatrix}\n1 \\\\ 5\n\\end{pmatrix}\n$$\n\n**Compute the determinant:**\n$$\n\\text{det} = 3 \\cdot 4 - (-a) \\cdot 6 = 12 + 6a\n$$\n\n- If $$\\text{det} \\neq \\ 0  \\ (i.e., a \\neq -2)$$, the system has a **unique solution**.\n- If $$\\text{det} = 0 \\ (i.e., (a = -2)$$, check for consistency:\n\nSubstitute a = -2 into the system:\n\n$$\n\\begin{cases}\n3x + 2y = 1 \\\\\n6x + 4y = 5\n\\end{cases}\n$$\n\nThe second equation is $$2 \\times$$ the first, but $$2 \\cdot 1 \\neq 5$$, so the system is **inconsistent** (no solution).\n\n**Evaluate the options:**\n\n- If a > -2, $$\\text{det} \\neq 0$$, so the system has a **unique solution**. **True**.\n- If a = -2, the system has **no solution**. **False**.\n- If a = 2, $$\\text{det} \\neq 0$$, so the system has a **unique solution**. **False**.\n- If a > 2, $$\\text{det} \\neq 0$$, so the system has a **unique solution**. **False**."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4189,
        "content": [
          "If a > -2, then the system has a unique solution."
        ],
        "isCorrect": true
      },
      {
        "id": 4190,
        "content": [
          "If a = -2, then the system has a unique solution."
        ],
        "isCorrect": false
      },
      {
        "id": 4191,
        "content": [
          "If a = 2, then the system has no solution."
        ],
        "isCorrect": false
      },
      {
        "id": 4192,
        "content": [
          "If a > 2, then the system has infinitely many solutions."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 1048,
    "content": [
      "What is the magnitude of the vector whose initial point is at (1, -3) and terminal point is at (4, 1)?"
    ],
    "explanation": [
      "Compute the vector components:\n$$\n(4 - 1, 1 - (-3)) = (3, 4)\n$$\nCalculate the magnitude:\n$$\n\\sqrt{3^2 + 4^2} = \\sqrt{9 + 16} = \\sqrt{25} = 5\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_VECTORS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4193,
        "content": [
          "5"
        ],
        "isCorrect": true
      },
      {
        "id": 4194,
        "content": [
          "6"
        ],
        "isCorrect": false
      },
      {
        "id": 4195,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 4196,
        "content": [
          "4"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 8,
    "unitName": "Vectors in 2D"
  },
  {
    "id": 1049,
    "content": [
      "Let T be a translation that takes the origin into (2, 3). Then which of the following is true about the translation T?"
    ],
    "explanation": [
      "Translation T shifts points by (2, 3). Check which equation is shifted by (2, 3):\n- For $$(x - 2)^2 + (y + 6)^2 = 9$$, the center (2, -6) translates to (4, -3).\n- This matches $$(x - 4)^2 + (y + 3)^2 = 9$$."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRANSFORMATION_PLANE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4197,
        "content": [
          "$$(x - 4)^2 + (y - 3)^2 = 9$$ is the translation of $$(x - 2)^2 + (y + 6)^2 = 9$$."
        ],
        "isCorrect": true
      },
      {
        "id": 4198,
        "content": [
          "$$(x - 5)^2 + (y - 6)^2 = 9$$ is the translation of $$(x - 3)^2 + (y - 3)^2 = 9$$."
        ],
        "isCorrect": false
      },
      {
        "id": 4199,
        "content": [
          "$$(x - 4)^2 + (y + 3)^2 = 12$$ is the translation of $$(x - 2)^2 + (y + 6)^2 = 12$$."
        ],
        "isCorrect": false
      },
      {
        "id": 4200,
        "content": [
          "$$(x + 4)^2 + (y - 3)^2 = 12$$ is the translation of $$(x - 2)^2 + (y + 6)^2 = 12$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Transformation of the Plane"
  },
  {
    "id": 1050,
    "content": [
      "Which of the following functions represents, the graph shown in Figure?",
      "images/maths/year_2013_na/q25_1.png"
    ],
    "explanation": [
      "The graph shown in Figure has vertical asymptotes at:\n$$\nx = -2\\pi, -\\pi, 0, \\pi, 2\\pi, \\ldots\n$$\n\nAnd the function is undefined at these points. Between asymptotes, the graph decreases and approaches negative infinity to the left and positive infinity to the right — characteristic of the **cotangent** function.\n$$\nf(x) = \\cot x\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2013_na/q25_1.png"
    ],
    "choices": [
      {
        "id": 4201,
        "content": [
          "$$f(x) = \\tan{x}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4202,
        "content": [
          "$$f(x) = \\sec{x}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4203,
        "content": [
          "$$f(x) = \\csc{x}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4204,
        "content": [
          "$$f(x) = \\cot{x}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 5,
    "unitName": "Introduction to Trigonometry"
  },
  {
    "id": 1051,
    "content": [
      "Which of the following is true?"
    ],
    "explanation": [
      "The domain of $$y = \\tan^{-1}x$$ is $$(-\\infty, \\infty)$$, since the inverse tangent function is defined for all real numbers without restrictions. This function is continuous and smooth across its entire domain.\n- **Option B:** The domain of $$y = \\cos^{-1}x$$ is [-1, 1], because for real values, $$\\cos^{-1}x$$ only accepts inputs within this range, as the cosine function's range is [-1, 1].\n- **Option C:** $$\\sin^{-1}(0) = 0$$, not $$\\frac{\\pi}{2}$$, because the inverse sine of 0 corresponds to an angle of 0 radians.\n- **Option D:** $$\\tan^{-1}(0) = 0$$, as the inverse tangent of 0 is 0, corresponding to the angle whose tangent is 0."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4205,
        "content": [
          "The domain of $$y=\\tan^{-1}{x}$$ is $$(-\\infty, \\infty)$$."
        ],
        "isCorrect": true
      },
      {
        "id": 4206,
        "content": [
          "The domain of $$y=\\cos^{-1}{x}$$ is $$(-1, 1)$$."
        ],
        "isCorrect": false
      },
      {
        "id": 4207,
        "content": [
          "$$\\sin^{-1}(0)=\\frac{\\pi}{2}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 4208,
        "content": [
          "$$\\tan^{-1}(0)=1$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1052,
    "content": [
      "Which one of the following is the fourth term of the sequence $$\\left\\{cos\\left(\\frac{n\\pi}{2}\\right)\\right\\}$$?"
    ],
    "explanation": [
      "The sequence is $$\\left\\{ \\cos\\left(\\frac{n\\pi}{2}\\right) \\right\\}$$.\n\nTo find the fourth term n = 4:\n$$\n\\cos\\left(\\frac{4\\pi}{2}\\right) = \\cos(2\\pi) = 1\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4209,
        "content": [
          "0"
        ],
        "isCorrect": false
      },
      {
        "id": 4210,
        "content": [
          "-1"
        ],
        "isCorrect": false
      },
      {
        "id": 4211,
        "content": [
          "1"
        ],
        "isCorrect": true
      },
      {
        "id": 4212,
        "content": [
          "0.5"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1053,
    "content": [
      "Which of the following is a geometric sequence?"
    ],
    "explanation": [
      "8, -4, 2, -1, ... is a geometric sequence because the ratio between consecutive terms is constant:\n- $$\\frac{-4}{8} = -0.5$$\n- $$\\frac{2}{-4} = -0.5$$\n- $$\\frac{-1}{2} = -0.5$$\n\nThe common ratio is -0.5, so it is geometric."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4213,
        "content": [
          "1, 1.5, 2.5, 3.5, ..."
        ],
        "isCorrect": false
      },
      {
        "id": 4214,
        "content": [
          "0.1, 0.01, 0.0011, 0.000111, ..."
        ],
        "isCorrect": false
      },
      {
        "id": 4215,
        "content": [
          "8,-4, 2, -1 ..."
        ],
        "isCorrect": true
      },
      {
        "id": 4216,
        "content": [
          "0.1, 0.11, 0.12, 0.13,..."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1054,
    "content": [
      "A factory that produces electric cable had sales Birr 1,000,000 the first day. During each successive days the sales increased by Birr 10,000 every day. What is the total sales of the factory in the first 10 days?"
    ],
    "explanation": [
      "This is an arithmetic sequence where:\n- First term $$a_1$$ = Birr 1,000,000\n- Common difference $$d$$ = Birr 10,000\n- Number of days $$n$$ = 10\n\nThe total sales (sum of the first $$n$$ terms) is calculated using the formula for the sum of an arithmetic sequence:\n$$\nS_n = \\frac{n}{2} \\left( 2a_1 + (n-1)d \\right)\n$$\n\nSubstitute the values:\n\n$$\nS_{10} = \\frac{10}{2} \\left( 2(1,000,000) + (10-1)(10,000) \\right)\n$$\n$$\nS_{10} = 5 \\left( 2,000,000 + 90,000 \\right)\n$$\n$$\nS_{10} = 5 \\left( 2,090,000 \\right)\n$$\n$$\nS_{10} = 10,450,000\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4217,
        "content": [
          "Birr 10,000,000"
        ],
        "isCorrect": false
      },
      {
        "id": 4218,
        "content": [
          "Birr 1,090,000"
        ],
        "isCorrect": false
      },
      {
        "id": 4219,
        "content": [
          "Birr 20,900,000"
        ],
        "isCorrect": false
      },
      {
        "id": 4220,
        "content": [
          "Birr 10,450,000"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1055,
    "content": [
      "What is the least upper bound of the sequence $$\\left\\{2 + \\frac{n}{n+1}\\right\\}_{n=1}^{\\infty}$$?"
    ],
    "explanation": [
      "As $$n \\to \\infty$$, $$\\frac{n}{n+1} \\to 1$$, so the sequence approaches 2 + 1 = 3. This is the least upper bound."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4221,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 4222,
        "content": [
          "0"
        ],
        "isCorrect": false
      },
      {
        "id": 4223,
        "content": [
          "3"
        ],
        "isCorrect": true
      },
      {
        "id": 4224,
        "content": [
          "2"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1056,
    "content": [
      "Which one of the following sequences is a null sequence?"
    ],
    "explanation": [
      "A null sequence converges to 0. $$\\left\\{ \\frac{\\cos n}{n} \\right\\}$$ is a null sequence because:\n- $$\\cos n$$ is bounded $$1 \\leq \\cos n \\leq 1$$, and\n- $$\\frac{1}{n} \\to 0 \\ as \\ n \\to \\infty$$.\n\nThus, $$\\frac{\\cos n}{n} \\to 0$$, making it a null sequence."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4225,
        "content": [
          "$$\\left\\{nsin\\left(\\frac{1}{n}\\right)\\right\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4226,
        "content": [
          "$$\\left\\{\\left(1-\\frac{1}{n}\\right)\\right\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4227,
        "content": [
          "$$\\left\\{\\frac{n}{n+1}\\right\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4228,
        "content": [
          "$$\\left\\{\\frac{cos n}{n}\\right\\}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1057,
    "content": [
      "Suppose $$\\{a_n\\}$$ and $$\\{b_n\\}$$ are sequences with $$\\lim_{n \\to \\infty}a_n = L$$ and $$\\lim_{n \\to \\infty}b_n = M$$. Then which of the following is **NOT** necessarily true?"
    ],
    "explanation": [
      "The limit $$\\lim_{n \\to \\infty} \\left(\\frac{a_n}{b_n}\\right)$$ = $$\\frac{L}{M}$$ is not necessarily true unless M ≠ 0. If M = 0, the limit may not exist or may be undefined due to division by zero."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4229,
        "content": [
          "$$\\lim_{n \\to \\infty} (3a_n + 2b_n) = 3L + 2M$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4230,
        "content": [
          "$$\\lim_{n \\to \\infty}(a_n - b_n) = L - M$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4231,
        "content": [
          "$$\\lim_{n \\to \\infty} \\left(\\frac{a_n}{b_n}\\right) = \\frac{L}{M}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4232,
        "content": [
          "$$\\lim_{n \\to \\infty}a_nb_n = LM$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1058,
    "content": [
      "$$\\lim_{x \\to \\infty}\\frac{3x^2+2x}{5x-x^2}$$ is equal to"
    ],
    "explanation": [
      "To evaluate $$\\lim_{x \\to \\infty} \\frac{3x^2 + 2x}{5x - x^2}$$, divide the numerator and denominator by the highest power of $$x ( x^2 )$$:\n$$\n\\lim_{x \\to \\infty} \\frac{3x^2 + 2x}{5x - x^2} = \\lim_{x \\to \\infty} \\frac{3 + \\frac{2}{x}}{\\frac{5}{x} - 1}\n$$\nAs $$x \\to \\infty$$, $$\\frac{2}{x} \\to 0$$ and $$\\frac{5}{x} \\to 0$$, so the limit simplifies to:\n$$\n\\frac{3 + 0}{0 - 1} = \\frac{3}{-1} = -3\n$$."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4233,
        "content": [
          "-1"
        ],
        "isCorrect": false
      },
      {
        "id": 4234,
        "content": [
          "-3"
        ],
        "isCorrect": true
      },
      {
        "id": 4235,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 4236,
        "content": [
          "0"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1059,
    "content": [
      "Which of the following is the same as the derivative of a function f at a point P, where P is on the graph of f?"
    ],
    "explanation": [
      "The derivative of a function f at a point P represents the **slope of the tangent line** to the graph of f at P."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4237,
        "content": [
          "The continuity of the function at P."
        ],
        "isCorrect": false
      },
      {
        "id": 4238,
        "content": [
          "The slope of a secant line through P."
        ],
        "isCorrect": false
      },
      {
        "id": 4239,
        "content": [
          "The slope of the tangent line through P."
        ],
        "isCorrect": true
      },
      {
        "id": 4240,
        "content": [
          "The graph of $$f$$ has no jump at P."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1060,
    "content": [
      "What is the derivative of the function $$f(x) = 3x^2 + 2\\sqrt{x} - 4x$$ at $$x = 1$$?"
    ],
    "explanation": [
      "First, find the derivative of $$f(x) = 3x^2 + 2\\sqrt{x} - 4x$$:\n$$\nf'(x) = \\frac{d}{dx}(3x^2) + \\frac{d}{dx}(2\\sqrt{x}) - \\frac{d}{dx}(4x)\n$$\nUsing differentiation rules:\n$$\nf'(x) = 6x + \\frac{1}{\\sqrt{x}} - 4\n$$\nNow, evaluate $$f'(x)$$ at $$x = 1$$:\n$$\nf'(1) = 6(1) + \\frac{1}{\\sqrt{1}} - 4 = 6 + 1 - 4 = 3\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4241,
        "content": [
          "-1"
        ],
        "isCorrect": false
      },
      {
        "id": 4242,
        "content": [
          "-3"
        ],
        "isCorrect": false
      },
      {
        "id": 4243,
        "content": [
          "3"
        ],
        "isCorrect": true
      },
      {
        "id": 4244,
        "content": [
          "1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1061,
    "content": [
      "What are the 2nd and the nth derivative of $$f(x) = e^{3x}$$ respectively?"
    ],
    "explanation": [
      "For $$f(x) = e^{3x}$$, the derivatives are:\n\nFirst derivative:\n$$\nf'(x) = 3e^{3x} = 3f(x)\n$$\nSecond derivative:\n$$\nf''(x) = 3 \\cdot 3e^{3x} = 9e^{3x} = 9f(x)\n$$\n$$n^{th}$$ derivative:\n$$\nf^{(n)}(x) = 3^n e^{3x} = 3^n f(x)\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4245,
        "content": [
          "$$4f(x)$$ and $$2^nf(x)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4246,
        "content": [
          "$$2f(x)$$ and $$nf(x)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4247,
        "content": [
          "$$9f(x)$$ and $$3^nf(x)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4248,
        "content": [
          "$$9f(x)$$ and $$n^2f(x)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1062,
    "content": [
      "Which of the following is true about the zero of a function?"
    ],
    "explanation": [
      "The zero of a function is the value of x for which f(x) = 0. This corresponds to the x-intercept of the graph of the function."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4249,
        "content": [
          "It is the y-intercept of the function."
        ],
        "isCorrect": false
      },
      {
        "id": 4250,
        "content": [
          "It is the x-intercept of the function."
        ],
        "isCorrect": true
      },
      {
        "id": 4251,
        "content": [
          "It is the concavity point of the function."
        ],
        "isCorrect": false
      },
      {
        "id": 4252,
        "content": [
          "It is the critical point of the function."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1063,
    "content": [
      "Which of the following is true about the function defined by $$f(x) = x^3 - 3x^2$$ on [-1,3]?"
    ],
    "explanation": [
      "**Find critical numbers:**\n- $$f(x) = x^3 - 3x^2$$\n- $$f'(x) = 3x^2 - 6x$$\n\nSet $$f'(x) = 0$$:\n$$\n3x^2 - 6x = 0 \\implies x(x - 2) = 0 \\implies x = 0, 2\n$$\n\nCritical numbers: (0, 2)\n\n**Evaluate f(x) at critical points and endpoints:**\n\n- $$f(-1)$$ = $$(-1)^3 - 3(-1)^2$$ = $$-1 - 3$$ = $$-4$$\n- $$f(0)$$ = $$0^3 - 3(0)^2$$ = $$0$$\n- $$f(2)$$ = $$2^3 - 3(2)^2$$ = $$8 - 12$$ = $$-4$$\n- $$f(3)$$ = $$3^3 - 3(3)^2$$ = $$27 - 27$$ = $$0$$\n\nMaximum value: 0"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4253,
        "content": [
          "Its critical numbers are 0 and 2 and its maximum value is 15."
        ],
        "isCorrect": false
      },
      {
        "id": 4254,
        "content": [
          "Its critical numbers are 0, 2, 3 and its maximum value is 0."
        ],
        "isCorrect": false
      },
      {
        "id": 4255,
        "content": [
          "It has critical numbers at 0 and 2 and its maximum value is 0."
        ],
        "isCorrect": true
      },
      {
        "id": 4256,
        "content": [
          "Its critical numbers are 0 and 2 and its maximum value is -4."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1064,
    "content": [
      "What is the number that satisfies Rolle's Theorem for $$f(x) = x^2 - 3x + 1$$ on [0, 3]?"
    ],
    "explanation": [
      "Rolle's Theorem requires:\n\n- f(x) is continuous on [0, 3]\n- f(x) is differentiable on (0, 3)\n- f(0) = f(3)\n\nCheck f(0) and f(3):\n\n- $$f(0)$$ = $$0^2 - 3(0) + 1$$ = $$1$$\n- $$f(3)$$ = $$3^2 - 3(3) + 1$$ = $$9 - 9 + 1$$ = $$1$$\n\nNow, find $$f'(x)$$:\n$$\nf'(x) = 2x - 3\n$$\n\nSet $$f'(x) = 0$$ to find the critical number:\n$$\n2x - 3 = 0 \\implies x = \\frac{3}{2}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4257,
        "content": [
          "$$1$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4258,
        "content": [
          "$$-\\frac{3}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4259,
        "content": [
          "$$2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4260,
        "content": [
          "$$\\frac{3}{2}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1065,
    "content": [
      "What are the length L and width W of a rectangle with perimeter 10,000m that maximizes the area?"
    ],
    "explanation": [
      "To maximize the area of a rectangle with a fixed perimeter:\n- Let the perimeter P = 2L + 2W = 10,000. Simplify: L + W = 5,000\n- Express W in terms of L: W = 5,000 - L\n- The area $$A$$ = $$L \\cdot W$$ = $$L(5,000 - L)$$ = $$5,000L - L^2$$\n- To maximize A, take the derivative and set it to 0:\n\n$$\n\\frac{dA}{dL} = 5,000 - 2L = 0 \\implies L = 2,500\n$$\n\nSubstitute L = 2,500 into W = 5,000 - L: W = 2,500"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4261,
        "content": [
          "$$L=2,500 m$$ and $$W = 3,000 m$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4262,
        "content": [
          "$$L= 2,500 m$$ and $$W= 2,500 m$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4263,
        "content": [
          "$$L= 5,000 m$$ and $$W = 5,000 m$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4264,
        "content": [
          "$$L = 3,000 m$$ and $$W = 2,500 m$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1066,
    "content": [
      "If the radius $$r$$ of a sphere is increasing at the rate of 2 cm/min, then the rate of change of the volume when $$r = 1$$ cm is"
    ],
    "explanation": [
      "The volume of a sphere is $$V = \\frac{4}{3}\\pi r^3$$. Differentiate with respect to time t:\n$$\n\\frac{dV}{dt} = 4\\pi r^2 \\frac{dr}{dt}\n$$\nGiven $$\\frac{dr}{dt}$$ = $$2 \\, \\text{cm/min}$$ and r = 1 cm:\n$$\n\\frac{dV}{dt} = 4\\pi (1)^2 (2) = 8\\pi \\, \\text{cm}^3/\\text{min}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4265,
        "content": [
          "$$6\\pi cm^3/min$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4266,
        "content": [
          "$$4\\pi cm^3/min$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4267,
        "content": [
          "$$12\\pi cm^3/min$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4268,
        "content": [
          "$$8\\pi cm^3/min$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1067,
    "content": [
      "Which of the following is equal to $$\\int (cosx - 2x)dx$$ where c is a constant?"
    ],
    "explanation": [
      "Integrate term by term:\n$$\n\\int \\cos x \\, dx = \\sin x\n$$\n$$\n\\int -2x \\, dx = -x^2\n$$\nAdd the constant (c):\n$$\n\\int (\\cos x - 2x) \\, dx = \\sin x - x^2 + c\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4269,
        "content": [
          "$$sinx + x^2 + c.$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4270,
        "content": [
          "$$-sinx - x^2 + c.$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4271,
        "content": [
          "$$sinx - x^2 + c.$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4272,
        "content": [
          "$$-sinx + x^2 + c.$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1068,
    "content": [
      "What is the area of the region bounded by y = 0 and the graph of $$f(x) = 4 - x^2$$ on the interval [-1, 1]?"
    ],
    "explanation": [
      "$$\nA = \\int_{-1}^{1} (4 - x^2) \\, dx\n$$\nCompute the integral:\n$$\nA = \\left[ 4x - \\frac{x^3}{3} \\right]_{-1}^{1}\n$$\nEvaluate at the bounds:\n$$\nA = \\left( 4(1) - \\frac{1^3}{3} \\right) - \\left( 4(-1) - \\frac{(-1)^3}{3} \\right)\n$$\n$$\nA = \\left( 4 - \\frac{1}{3} \\right) - \\left( -4 + \\frac{1}{3} \\right)\n$$\n$$\nA = \\frac{11}{3} + \\frac{11}{3} = \\frac{22}{3}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4273,
        "content": [
          "$$\\frac{22}{3}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4274,
        "content": [
          "$$\\frac{2}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4275,
        "content": [
          "$$\\frac{26}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4276,
        "content": [
          "$$8$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1069,
    "content": [
      "Suppose $$\\int_1^2 f(x)dx = 6$$ and $$\\int_1^3 f(x)dx = 10$$, what is the value of $$\\int_2^3 f(x)dx$$ ?"
    ],
    "explanation": [
      "Given:\n\n- $$\\int_1^2 f(x)dx = 6$$\n- $$\\int_1^3 f(x)dx = 10$$\n\nSubtract the first integral from the second:\n$$\n\\int_2^3 f(x)dx = \\int_1^3 f(x)dx - \\int_1^2 f(x)dx = 10 - 6 = 4\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4277,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 4278,
        "content": [
          "-4"
        ],
        "isCorrect": false
      },
      {
        "id": 4279,
        "content": [
          "16"
        ],
        "isCorrect": false
      },
      {
        "id": 4280,
        "content": [
          "4"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1070,
    "content": [
      "Which of the following statements has a truth value T?"
    ],
    "explanation": [
      "$$\n(p \\land q) \\implies (p \\lor q)\n$$\nThis is always true (Tautology). If both p and q are true, then at least one of them is true, so the implication holds.\n\nOther statements are not tautologies and can be false for some combinations of p and q."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4281,
        "content": [
          "$$(p \\land q) \\implies (p \\lor q)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4282,
        "content": [
          "$$(p \\land q) \\implies \\lnot (p \\lor q)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4283,
        "content": [
          "$$(p \\lor q) \\implies (p \\land q)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4284,
        "content": [
          "$$(p \\implies q) \\implies (p \\lor q)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1071,
    "content": [
      "The inverse of the function $$y= 3x-5$$ is equal to"
    ],
    "explanation": [
      "**Swap x and y:**\n$$\nx = 3y - 5\n$$\n**Solve for y:**\n$$\ny = \\frac{x + 5}{3}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4285,
        "content": [
          "$$y = \\frac{x+5}{3}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4286,
        "content": [
          "$$y = \\frac{x+3}{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4287,
        "content": [
          "$$y = \\frac{x-5}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4288,
        "content": [
          "$$y = -5x+3$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1072,
    "content": [
      "Which of the following is the universal set of the expression $$\\frac{1}{x^2} + \\frac{x+1}{x^2+x}$$?"
    ],
    "explanation": [
      "The expression is defined when the denominators are not zero:\n$$\nx^2 \\neq 0 \\Rightarrow x \\neq 0\n$$\n$$\nx^2 + x \\neq 0 \\Rightarrow x(x + 1) \\neq 0 \\Rightarrow x \\neq 0, -1\n$$\nThus, the universal set excludes 0 and -1"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4289,
        "content": [
          "$$\\mathbb{R} \\backslash \\{0, 1\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4290,
        "content": [
          "$$\\mathbb{R} \\backslash \\{0\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4291,
        "content": [
          "$$\\mathbb{R} \\backslash \\{0, 1, -1\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4292,
        "content": [
          "$$\\mathbb{R} \\backslash \\{0, -1\\}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1073,
    "content": [
      "The graph of a rational function is given as in the Figure below.",
      "images/maths/year_2013_na/q48_1.png",
      "Which of the following is NOT true about the graph?"
    ],
    "explanation": [
      "The graph has:\n- A vertical asymptote at x = 1 (the function approaches $$\\pm \\infty$$ as $$x \\to 1$$)\n- A horizontal asymptote at y = 0 (the function approaches y = 0 as $$x \\to \\pm \\infty$$)\n\nChecking monotonicity:\n\n- On $$(-\\infty, 1)$$, the function is increasing.\n- On $$(1, \\infty)$$, the function is also increasing.\n\nSo the function is increasing on $$(1, \\infty)$$, not decreasing."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2013_na/q48_1.png"
    ],
    "choices": [
      {
        "id": 4293,
        "content": [
          "$$x=1$$ is its vertical asymptote."
        ],
        "isCorrect": false
      },
      {
        "id": 4294,
        "content": [
          "$$y=0$$ is its horizontal asymptote."
        ],
        "isCorrect": false
      },
      {
        "id": 4295,
        "content": [
          "It is decreasing on $$(1, \\infty)$$."
        ],
        "isCorrect": true
      },
      {
        "id": 4296,
        "content": [
          "It is increasing on $$(-\\infty, 1)$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1074,
    "content": [
      "The equation of a line is given by $$3x - 2y + 6 = 0.$$ Then which of the following is true about the line?"
    ],
    "explanation": [
      "Rewrite in slope-intercept form y = mx + b:\n$$\n3x - 2y + 6 = 0 \\Rightarrow y = \\frac{3}{2}x + 3\n$$\n- Slope m = $$\\frac{3}{2}$$\n- y-intercept b = 3\n\nCheck x-intercept (y = 0):\n$$\n3x + 6 = 0 \\Rightarrow x = -2\n$$\nCheck if (2, 5) lies on the line:\n$$\n3(2) - 2(5) + 6 = 6 - 10 + 6 = 2 \\neq 0\n$$\nNot on the line."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4297,
        "content": [
          "Its y-intercept is -3."
        ],
        "isCorrect": false
      },
      {
        "id": 4298,
        "content": [
          "Its slope is $$\\frac{3}{2}$$."
        ],
        "isCorrect": true
      },
      {
        "id": 4299,
        "content": [
          "$$(2, 5)$$ lies on the line."
        ],
        "isCorrect": false
      },
      {
        "id": 4300,
        "content": [
          "Its x-intercept is 2."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1075,
    "content": [
      "Which one of the following is the standard form of the equation of the parabola with vertex (4, 6) and focus (-8, 6)?"
    ],
    "explanation": [
      "**Identify the orientation:**\n\n- Vertex: (4, 6)\n- Focus: (-8, 6)\n- Both have the same y-coordinate, so the parabola opens **horizontally**\n\n**Determine the direction:**\n\n- Focus (-8, 6) is to the **left** of the vertex (4, 6), so it opens **left**\n\n**Find the standard form:**\n\n- Horizontal parabola opening left: $$(y - k)^2$$ = $$-4p(x - h)$$\n- Vertex (h, k) = (4, 6)\n- Distance p = 4 - (-8) = 12\n\n**Plug in the values:**\n$$\n(y - 6)^2 = -4 \\times 12 \\times (x - 4)\n$$\n$$\n(y - 6)^2 = -48(x - 4)\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4301,
        "content": [
          "$$(x-4)^2=-12(y-6)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4302,
        "content": [
          "$$(x-4)^2=12(y-6)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4303,
        "content": [
          "$$(y-6)^2=48(x-4)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4304,
        "content": [
          "$$(y-6)^2=-48(x-4)$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1076,
    "content": [
      "Which of the following is true about the hyperbola given by $$\\frac{x^2}{4} - y^2$$ = $$1$$?"
    ],
    "explanation": [
      "Given the hyperbola:\n\n$$\n\\frac{x^2}{4} - y^2 = 1\n$$\nThis is a **horizontal hyperbola** centered at the origin (0,0)(0, 0), with the standard form:\n\n$$\n\\frac{x^2}{a^2} - \\frac{y^2}{b^2} = 1\n$$\nHere, $$a^2 = 4$$ → $$a=2$$, and $$b^2 = 1$$ → $$b = 1$$\n\n- **Vertices** are at $$(\\pm a, 0) = (\\pm 2, 0)$$\n- **Foci** are at $$(\\pm c, 0)$$, where $$c$$ = $$\\sqrt{a^2 + b^2}$$ = $$\\sqrt{4 + 1}$$ = $$\\sqrt{5}$$\n- **Asymptotes**: $$y$$ = $$\\pm \\frac{b}{a} x$$ = $$\\pm \\frac{1}{2}x$$\n\n**Correct option is B**: Its vertices are at (-2, 0) and (2, 0)."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4305,
        "content": [
          "Its foci are at $$(-5, 0)$$ and $$(5, 0)$$."
        ],
        "isCorrect": false
      },
      {
        "id": 4306,
        "content": [
          "Its vertices are at $$(-2, 0)$$ and $$(2, 0)$$."
        ],
        "isCorrect": true
      },
      {
        "id": 4307,
        "content": [
          "Its center is at $$(2, 1)$$."
        ],
        "isCorrect": false
      },
      {
        "id": 4308,
        "content": [
          "An asymptote to the hyperbola is $$y = 2x$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1077,
    "content": [
      "Two statements p and q are given by:",
      "p: $$\\frac{22}{7}$$ is an irrational number.",
      "q: The sum of two odd integers is odd.",
      "Then which of the following has a truth value T?"
    ],
    "explanation": [
      "Evaluate the truth values:\n- p: $$\\frac{22}{7}$$ is not irrational → **False**\n- q: sum of two odd integers is **even** → q is **False**\n\nNow evaluate the options:\n\n- Option A: $$p \\land \\lnot q$$ = $$F \\land T$$ = $$F$$\n- Option B: $$p \\lor \\lnot q$$ = $$F \\lor T$$ = $$T$$\n- Option C: $$\\lnot p \\land q$$ = $$T \\land F$$ = $$F$$\n- Option D:  $$p \\land q$$ = $$F \\land F$$ = $$F$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4309,
        "content": [
          "$$p \\land \\lnot q$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4310,
        "content": [
          "$$p \\lor \\lnot q$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4311,
        "content": [
          "$$\\lnot p \\land q$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4312,
        "content": [
          "$$p \\land q$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1078,
    "content": [
      "Which one of the following is the contrapositive of the statement: If 21 is a prime number, then 4 is an odd number?"
    ],
    "explanation": [
      "The contrapositive of a statement $$p \\rightarrow q$$ is $$\\lnot q \\rightarrow \\lnot p$$.\n\n- Original statement: If 21 is a prime number, then 4 is an odd number.\n- Contrapositive: If 4 is **not** an odd number, then 21 is **not** a prime number."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4313,
        "content": [
          "If 4 is an odd number, then 21 is not a prime number."
        ],
        "isCorrect": false
      },
      {
        "id": 4314,
        "content": [
          "If 4 is an odd number, then 21 is a prime number."
        ],
        "isCorrect": false
      },
      {
        "id": 4315,
        "content": [
          "If 4 is not an odd number, then 21 is not a prime number."
        ],
        "isCorrect": true
      },
      {
        "id": 4316,
        "content": [
          "If 21 is not a prime number, then 4 is an even number."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1079,
    "content": [
      "Which of the following is true where c is a constant?"
    ],
    "explanation": [
      "- $$\\int \\frac{sin\\sqrt{x}}{\\sqrt{x}}dx$$ = $$-2cos\\sqrt{x} + c$$: Let u = $$\\sqrt{x}$$. Then $$du$$ = $$\\frac{1}{2\\sqrt{x}} dx$$, so $$\\int \\frac{\\sin \\sqrt{x}}{\\sqrt{x}} dx$$ = $$2 \\int \\sin u$$, $$du$$ = $$-2 \\cos u + c$$ = $$-2 \\cos \\sqrt{x}$$ + $$c$$. **True**\n- $$\\int(3x + 5)^6 dx$$ = $$\\frac{(3x+5)^7}{7}+c$$: Missing the factor $$\\frac{1}{3}$$ from the chain rule. Correct integral: $$\\frac{(3x+5)^7}{21} + c$$. **False**\n- $$\\int lnx dx$$ = $$\\frac{1}{x} + c$$: The integral of $$\\ln x$$ is $$x \\ln x - x + c$$, not $$\\frac{1}{x} + c$$. **False**\n- $$\\int xe^{x^2} dx$$ = $$\\frac{x^2}{2}e^{x^2} + c$$: The correct integral is $$\\frac{1}{2} e^{x^2}$$ + $$c$$, not $$\\frac{x^2}{2} e^{x^2} + c$$. **False**"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4317,
        "content": [
          "$$\\int \\frac{sin\\sqrt{x}}{\\sqrt{x}}dx$$ = $$-2cos\\sqrt{x} + c$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4318,
        "content": [
          "$$\\int(3x + 5)^6 dx$$ = $$\\frac{(3x+5)^7}{7}+c$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4319,
        "content": [
          "$$\\int lnx dx$$ = $$\\frac{1}{x} + c$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4320,
        "content": [
          "$$\\int xe^{x^2} dx$$ = $$\\frac{x^2}{2}e^{x^2} + c$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1080,
    "content": [
      "The acceleration of a body at any time t is given by $$a(t) = 4 - 2t + 3t^2$$ with initial velocity $$v(0) = 5.$$ Then what is the velocity $$v$$ of the body as a function of time?"
    ],
    "explanation": [
      "We integrate the acceleration function:\n$$\na(t) = 4 - 2t + 3t^2\n$$\nIntegrate to get velocity:\n$$\nv(t) = ∫(4 - 2t + 3t^2) dt = 4t - t^2 + t^3 + C\n$$\nUse initial condition $$v(0)$$ = $$5v(0)$$ = $$5$$:\n$$\nv(0) = 0 + 0 + 0 + C = 5 → C = 5\n$$\nFinal velocity function:\n$$\nv(t) = 4t - t^2 + t^3 + 5\n$$\n$$\nv(t) = 5 + 4t - t^2 + t^3\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4321,
        "content": [
          "$$v(t) = 1 + 4t - t^2 + t^3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4322,
        "content": [
          "$$v(t) = 5 + 4t - t^2 + t^3$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4323,
        "content": [
          "$$v(t) = -2 + 6t$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4324,
        "content": [
          "$$v(t) = 9 - t^2 + t^3$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1081,
    "content": [
      "Which of the following argument is valid?"
    ],
    "explanation": [
      "**Option 1:** $$p, \\lnot q \\vdash p \\implies q$$\n\n- **Invalid.** $$p \\implies q$$ is false when p is true and q is false.\n\n**Option 2:** $$\\lnot p, q \\vdash p \\implies q$$\n\n- **Valid.** $$p \\implies q$$ is true when p is false or q is true.\n\n**Option 3:** $$p, q \\vdash p \\implies \\lnot q$$\n\n- **Invalid.** $$p \\implies \\lnot q$$ is false when both p and q are true.\n\n**Option 4:** $$p, \\lnot q \\vdash p \\land q$$\n\n- **Invalid.** $$p \\land q$$ is false when q is false."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4325,
        "content": [
          "$$p, \\lnot q \\vdash p \\implies q$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4326,
        "content": [
          "$$\\lnot p, q \\vdash p \\implies q$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4327,
        "content": [
          "$$p, q \\vdash p \\implies \\lnot q$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4328,
        "content": [
          "$$p, \\lnot q \\vdash p \\land q$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1082,
    "content": [
      "Which of the following proof is more suitable to prove the assertion: $$1+2^3 + 3^3 + ... + n^3$$ = $$(1+2+3+ ... +n)^2$$?"
    ],
    "explanation": [
      "**Proof by the principle of mathematical induction** is the most suitable method to prove the assertion. It systematically verifies the statement for all natural numbers n.\n- **Base case**: Verify for n = 1\n- **Inductive step**: Assume true for n = k, then prove for n = k + 1\n\nThis method directly aligns with the structure of the given equation."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4329,
        "content": [
          "Proof by counter example."
        ],
        "isCorrect": false
      },
      {
        "id": 4330,
        "content": [
          "Proof by the principle of mathematical induction."
        ],
        "isCorrect": true
      },
      {
        "id": 4331,
        "content": [
          "Proof by contradiction."
        ],
        "isCorrect": false
      },
      {
        "id": 4332,
        "content": [
          "Proof by indirect proof."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1083,
    "content": [
      "Math test scores distribution of 20 students is given as in Table below?",
      "images/maths/year_2013_na/q58_1.png",
      "What is the standard deviation of the scores ?"
    ],
    "explanation": [
      "**Find the midpoint of each score range:**\n\n| Scores | Midpoint (x) |\n| --- | --- |\n| 1 - 5 | 3 |\n| 6 - 10 | 8 |\n| 11 - 15 | 13 |\n| 16 - 20 | 18 |\n\n**Calculate the mean (μ):**\n$$\\mu = \\frac{\\sum (x \\times f)}{N}$$\n$$\n\\mu = \\frac{3 \\times 4 + 8 \\times 6 + 13 \\times 8 + 18 \\times 2}{20}\n$$\n$$\n\\mu = 10\n$$\n\n**Calculate the variance (σ²):**\n\n$$\n\\sigma^2 = \\frac{\\sum f(x - \\mu)^2}{N}\n$$\n$$\n\\sigma^2 = \\frac{4(3-10)^2 + 6(8-10)^2 + 8(13-10)^2 + 2(18-10)^2}{20}\n$$\n$$\n\\sigma^2 = 21\n$$\n\n**Find the standard deviation (σ):**\n$$\n\\sigma = \\sqrt{\\sigma^2} = \\sqrt{21}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2013_na/q58_1.png"
    ],
    "choices": [
      {
        "id": 4333,
        "content": [
          "$$5$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4334,
        "content": [
          "$$4$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4335,
        "content": [
          "$$\\sqrt{21}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4336,
        "content": [
          "$$\\sqrt{20}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 7,
    "unitName": "Statistics"
  },
  {
    "id": 1084,
    "content": [
      "What is the coefficient of $$x^2$$ in the binomial expansion of $$\\left(2x+\\frac{3}{x^3}\\right)^8$$ ?"
    ],
    "explanation": [
      "**Use the binomial expansion:**\n$$\nT_k = \\binom{8}{k} (2x)^{8-k} \\left(\\frac{3}{x^3}\\right)^k\n$$\n**Simplify the exponents of x**:\n$$\nx^{8 - k} \\cdot x^{-3k} = x^{8 - 4k}\n$$\n**Set the exponent of x to 2**:\n$$\n8 - 4k = 2 \\implies k = \\frac{6}{4} = 1.5\n$$\nSince k must be an integer, there is **no valid k** that satisfies this equation. The coefficient of $$x^2$$ is **0**."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4337,
        "content": [
          "6"
        ],
        "isCorrect": false
      },
      {
        "id": 4338,
        "content": [
          "0"
        ],
        "isCorrect": true
      },
      {
        "id": 4339,
        "content": [
          "576"
        ],
        "isCorrect": false
      },
      {
        "id": 4340,
        "content": [
          "500"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1085,
    "content": [
      "Which of the following is true about the graph of $$y= -4 \\cos \\left( \\frac{2x}{3}\\right)$$?"
    ],
    "explanation": [
      "**Period:**\n\n- General form: $$y = A \\cos(Bx)$$ has period $$\\frac{2\\pi}{|B|}$$\n- Here, $$B = \\frac{2}{3}$$, so period = $$\\frac{2\\pi}{\\frac{2}{3}}$$ = $$3\\pi$$\n\n**Amplitude:**\n\n- Amplitude is | A |\n- Here, A = -4, so amplitude = 4\n\n**Cycle Completion:**\n\n- One cycle is completed over one period, which is $$3\\pi$$\n\n**Correct Answer:** Its period is $$3 \\pi$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4341,
        "content": [
          "Its period is $$3 \\pi$$."
        ],
        "isCorrect": true
      },
      {
        "id": 4342,
        "content": [
          "Its amplitude is -4."
        ],
        "isCorrect": false
      },
      {
        "id": 4343,
        "content": [
          "The graph completes one cycle on the interval $$\\left[0, \\frac{3 \\pi}{2} \\right]$$."
        ],
        "isCorrect": false
      },
      {
        "id": 4344,
        "content": [
          "The graph completes one cycle on the interval $$\\left[0, \\frac{2\\pi}{3} \\right]$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Trigonometric Function"
  },
  {
    "id": 1086,
    "content": [
      "The angle of elevation of the top of a tree is found to be $$60^\\circ$$ as measured from a point on a level ground. What is the height of the tree if the angle of elevation of a point on the tree that is 8m below the top is $$30^\\circ$$ as measured from the same point on the ground?"
    ],
    "explanation": [
      "**From the top of the tree:**\n$$\n\\tan 60^\\circ = \\frac{h}{d} \\Rightarrow d = \\frac{h}{\\sqrt{3}}\n$$\n\n**From a point 8m below the top:**\n$$\n\\tan 30^\\circ = \\frac{h - 8}{d} \\Rightarrow \\frac{1}{\\sqrt{3}} = \\frac{h - 8}{d}\n$$\nSubstitute d:\n$$\n\\frac{1}{\\sqrt{3}} = \\frac{h - 8}{\\frac{h}{\\sqrt{3}}} \\Rightarrow \\frac{1}{\\sqrt{3}} = \\frac{(h - 8)\\sqrt{3}}{h}\n$$\nSimplify:\n$$\n1 = \\frac{3(h - 8)}{h} \\Rightarrow h = 12 \\text{ m}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4345,
        "content": [
          "8m"
        ],
        "isCorrect": false
      },
      {
        "id": 4346,
        "content": [
          "4m"
        ],
        "isCorrect": false
      },
      {
        "id": 4347,
        "content": [
          "14m"
        ],
        "isCorrect": false
      },
      {
        "id": 4348,
        "content": [
          "12m"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 5,
    "unitName": "Introduction to Trigonometry"
  },
  {
    "id": 1087,
    "content": [
      "Which of the following series is convergent?"
    ],
    "explanation": [
      "A geometric series converges if and only if the common ratio r satisfies ∣r∣<1∣.\n\nThe series $$\\sum_{n=1}^\\infty 5^{11-2n}$$ is a geometric series. To determine its convergence, we can rewrite it in the standard geometric form $$\\sum_{n=1}^\\infty ar^{n-1}$$.\n$$\n5^{11-2n} = 5^{11} \\cdot 5^{-2n} = 5^{11} \\cdot \\left(\\frac{1}{25}\\right)^n\n$$\nThis is a geometric series with first term $$a = 5^{11} \\cdot \\left(\\frac{1}{25}\\right)^1$$ = $$\\frac{5^{11}}{25}$$ and common ratio r = $$\\frac{1}{25}$$.\n\nSince |r| < 1, the series converges."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4349,
        "content": [
          "$$\\sum_{n=1}^\\infty 5^{11-2n}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4350,
        "content": [
          "$$\\sum_{n=1}^\\infty \\left(\\frac{2}{5}\\right)^{-n}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4351,
        "content": [
          "$$\\sum_{n=1}^\\infty \\left(\\frac{3}{2}\\right)^n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4352,
        "content": [
          "$$\\sum_{n=1}^\\infty 2^{2n-5}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1088,
    "content": [
      "Let $$f$$ be a function defined on a closed bounded interval $$[a, b].$$ Which of the following describes that $$f$$ is continuous on $$[a, b]$$?"
    ],
    "explanation": [
      "A function f is continuous on a closed bounded interval $$[a, b]$$ if:\n\n- f is continuous on the open interval (a, b),\n- f is continuous from the **right** at a (i.e., $$\\lim_{x \\to a^+} f(x)$$ = $$f(a)$$), and\n- f is continuous from the **left** at b (i.e., $$\\lim_{x \\to b^-} f(x)$$ = $$f(b)$$)."
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4353,
        "content": [
          "$$f$$ is continuous on $$(a, b),$$ $$f$$ is continuous from the right at $$a$$ and from the left at $$b.$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4354,
        "content": [
          "$$f$$ is continuous at each point in $$(a, b)$$ and at both $$a$$ and $$b.$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4355,
        "content": [
          "$$f$$ is continuous on $$(a, b),$$ $$f$$ is continuous from the left at $$a$$ and from the right at $$b.$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4356,
        "content": [
          "$$f$$ is continuous on $$(a, b),$$ $$f$$ is continuous from the left at $$a$$ and from the left at $$b.$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1089,
    "content": [
      "A position of a particle is given by the equation $$S(t) = 4t^4 - 4t + 1$$ where $$t$$ is measured in seconds and $$S$$ in meters. Which of the following is NOT true about the motion of the particle?"
    ],
    "explanation": [
      "**Velocity function:**\n\n- $$v(t)$$ = $$\\frac{dS}{dt}$$ = $$16t^3 - 4$$\n\n**Velocity at t = 2:**\n\n- $$v(2)$$ = $$16(2)^3 - 4$$ = $$124 \\, \\text{m/s}$$\n\n**Acceleration function:**\n\n- $$a(t)$$ = $$\\frac{dv}{dt}$$ = $$48t^2$$\n- At t = 1, $$a(1)$$ = $$48(1)^2$$ = $$48 \\, \\text{m/s}^2$$\n\n**Particle at rest:**\n\n- $$v(t)$$ = $$0$$ $$\\Rightarrow$$ 1$$6t^3 - 4$$ = $$0$\n- $$t^3$$ = $$\\frac{1}{4}$$\n- $$t \\approx 0.63 \\, \\text{s}$$\n\nSo the particle is at rest at t = 0.5 seconds is NOT true"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4357,
        "content": [
          "The velocity at 2 seconds is given by 124 m/sec."
        ],
        "isCorrect": false
      },
      {
        "id": 4358,
        "content": [
          "The velocity $$v$$ at any time $$t$$ is given by $$v(t)= 16t^3 - 4$$."
        ],
        "isCorrect": false
      },
      {
        "id": 4359,
        "content": [
          "The acceleration of the particle at 1 sec is 48 $$m/sec^2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 4360,
        "content": [
          "The particle is at rest at $$t = 0.5$$ seconds."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1090,
    "content": [
      "If $$f'(1) = 4, f(1) = 3$$ and $$g'(3) = 5,$$ then $$(g \\circ f)'(1)$$ is equal to"
    ],
    "explanation": [
      "Using the chain rule:\n$$\n(g \\circ f)'(1) = g'(f(1)) \\cdot f'(1)\n$$\nSubstitute the given values:\n$$\nf(1) = 3, \\quad f'(1) = 4, \\quad g'(3) = 5\n$$\n$$\n(g \\circ f)'(1) = g'(3) \\cdot f'(1) = 5 \\cdot 4 = 20\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4361,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 4362,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 4363,
        "content": [
          "20"
        ],
        "isCorrect": true
      },
      {
        "id": 4364,
        "content": [
          "15"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1517,
    "content": [
      "Let $$f(x)$$ = $$\\frac{x+1}{x-1}$$ and $$g(x)$$ = $$\\sqrt{x+2}$$ be two functions. Which one of the following is true about the combination values of $$f$$ and $$g$$ at $$x=2$$?"
    ],
    "explanation": [
      "To find the correct combination value, first evaluate $$f(2)$$ and $$g(2)$$.\n$$\nf(2) = \\frac{2+1}{2-1} = \\frac{3}{1} = 3\n$$\n$$\ng(2) = \\sqrt{2+2} = \\sqrt{4} = 2\n$$\nNow, evaluate the combination $$(f \\cdot g)(2)$$ which means $$f(2) \\times g(2)$$.\n$$\n(f \\cdot g)(2) = f(2) \\times g(2) = 3 \\times 2 = 6\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6069,
        "content": [
          "$$(f.g)(2)$$ = $$6$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6070,
        "content": [
          "$$(\\frac{f}{g})(2)$$ = $$\\frac{2}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6071,
        "content": [
          "$$(f+g)(2)$$ = $$3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6072,
        "content": [
          "$$(f-g)(2)$$ = $$-1$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1518,
    "content": [
      "Which one of the following defines an exponential function?"
    ],
    "explanation": [
      "An exponential function is defined by the form $$f(x) = b^x$$, where the base $$b$$ is a positive constant ($$b > 0$$) and not equal to $$1$$ ($$b \\neq 1$$), and the variable $$x$$ is the exponent.\n\nThe domain of an exponential function is all real numbers ($$\\mathbb{R}$$), and the range is all positive real numbers ($$(0, \\infty)$$).\n\n- $$f: \\mathbb{R} \\rightarrow (0, \\infty)$$ defined by $$f(x) = b^x$$, where $$b > 0$$ and $$b \\neq 1$$.\n    - This Option correctly states this definition, including the form of the function, the domain, the range, and the conditions on the base $$b$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6073,
        "content": [
          "$$f: \\mathbb{R} \\rightarrow (0, \\infty)$$ defined by $$f(x) = b^x$$, where $$b > 0$$ and $$b \\neq 1$$."
        ],
        "isCorrect": true
      },
      {
        "id": 6074,
        "content": [
          "$$f: \\mathbb{R} \\rightarrow (0, \\infty)$$ defined by $$f(x) = x^b$$, where $$b > 0$$ and $$b \\neq 1$$."
        ],
        "isCorrect": false
      },
      {
        "id": 6075,
        "content": [
          "$$f: (0, \\infty) \\rightarrow \\mathbb{R}$$ defined by $$f(x) = b^x$$, where $$b > 0$$ and $$b \\neq 1$$."
        ],
        "isCorrect": false
      },
      {
        "id": 6076,
        "content": [
          "$$f: (0, \\infty) \\rightarrow \\mathbb{R}$$ defined by $$f(x) = x^b$$, where $$b > 0$$ and $$b \\neq 1$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Polynomial Function"
  },
  {
    "id": 1519,
    "content": [
      "Let f be differentiable function at a number 'a' for a $$\\in$$ Domain f. In the expression $$\\frac{f(a+h)-f(a)}{h}$$ for $$h \\neq 0$$, as h gets closer and closer to zero from both directions, the expression becomes closer to f'(a) which is equal to"
    ],
    "explanation": [
      "The expression $$\\frac{f(a+h)-f(a)}{h}$$ represents the slope of the secant line through the points (a, f(a)) and (a+h, f(a+h)) on the graph of f.\n\nThe derivative $$f'(a)$$ is defined as the limit of this expression as $$h$$ approaches 0:\n$$\nf'(a) = \\lim_{h \\to 0} \\frac{f(a+h)-f(a)}{h}\n$$\nGeometrically, this limit represents the slope (or gradient) of the tangent line to the graph of f at the point (a, f(a)). Therefore, $$f'(a)$$ is equal to the gradient of the tangent line."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6077,
        "content": [
          "The gradient of the normal line to the graph of f at a point (a, f(a))."
        ],
        "isCorrect": false
      },
      {
        "id": 6078,
        "content": [
          "The gradient of the vertical line to the graph of f at a point (a, f(a))."
        ],
        "isCorrect": false
      },
      {
        "id": 6079,
        "content": [
          "The gradient of the secant line to the graph of f at a point (a, f(a))."
        ],
        "isCorrect": false
      },
      {
        "id": 6080,
        "content": [
          "The gradient of the tangent line to the graph of f at a point (a, f(a))."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1520,
    "content": [
      "In the following figure, O is the center of the circle and the line segments $$\\overline{AB}$$ and $$\\overline{AC}$$ are intersecting the circle at D and E respectively. If $$m(\\angle ACD) = 30^\\circ$$ and $$m(\\angle BEC) = 50^\\circ$$, then which one of the following is equal to $$m(\\angle BAC)$$?",
      "images/maths/year_2016_na/q4_1.png"
    ],
    "explanation": [
      "Angles subtended by the same arc at the circumference are equal.\n\nBoth $$\\angle BEC$$ and $$\\angle BDC$$ subtend the arc BC.\n\nTherefore, $$m(\\angle BDC)$$ = $$m(\\angle BEC)$$ = $$50^\\circ$$.\n\nNow, consider the triangle $$\\triangle ADC$$. The exterior angle at vertex D is $$\\angle BDC$$. By the exterior angle theorem, the measure of an exterior angle of a triangle is equal to the sum of the measures of the two opposite interior angles.\n\nThus, $$m(\\angle BDC)$$ = $$m(\\angle DAC)$$ + $$m(\\angle ACD)$$.\n\nSubstituting the known values, we get $$50^\\circ$$ = $$m(\\angle DAC)$$ + $$30^\\circ$$.\n\nSince $$\\angle DAC$$ is the same as $$\\angle BAC$$, we have $$m(\\angle BAC)$$ = $$50^\\circ - 30^\\circ$$ = $$20^\\circ$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2016_na/q4_1.png"
    ],
    "choices": [
      {
        "id": 6081,
        "content": [
          "$$70^\\circ$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6082,
        "content": [
          "$$80^\\circ$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6083,
        "content": [
          "$$20^\\circ$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6084,
        "content": [
          "$$30^\\circ$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1521,
    "content": [
      "Let p and q be propositions. Which one of the following propositions is a tautology?"
    ],
    "explanation": [
      "A tautology is a logical proposition that is true for all possible truth values of its constituent propositions.\n- $$(p \\land q) \\implies (p \\lor q)$$.\n    - An implication $$A \\implies B$$ is false only when A is true and B is false. Here, A is $$(p \\land q)$$ and B is $$(p \\lor q)$$.\n    - If A ($$p \\land q$$) is true, it means both p and q are true. If both p and q are true, then B ($$p \\lor q$$) must also be true.\n    - So, we have the case $$T \\implies T$$, which is true.\n    - If A ($$p \\land q$$) is false, then the implication $$A \\implies B$$ is automatically true, regardless of the truth value of B.\n    - Since the implication $$(p \\land q) \\implies (p \\lor q)$$ is true in all cases, it is a tautology."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6085,
        "content": [
          "$$(p \\implies \\neg q) \\iff (p \\land q)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6086,
        "content": [
          "$$(\\neg p \\implies q) \\iff (p \\land q)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6087,
        "content": [
          "$$(p \\land q) \\implies (p \\lor q)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6088,
        "content": [
          "$$(p \\lor q) \\implies (p \\land q)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1522,
    "content": [
      "If 180 individuals can complete a job in 15 days by working 10 hours a day, how many individuals are needed to complete the job in 10 days if they work 12 hours a day?"
    ],
    "explanation": [
      "The total amount of work required to complete the job is constant. This work can be measured in \"individual-hours\".\n\nThe total work is calculated as (number of individuals) $$\\times$$ (number of days) $$\\times$$ (hours per day).\n\nInitial scenario: Work = $$180 \\times 15 \\times 10$$ = $$27000 \\ \\text{individual-hours}$$.\n\nLet $$x$$ be the number of individuals needed in the second scenario.\n\nSecond scenario: Work = $$x \\times 10 \\times 12$$ = $$120x  \\ \\text{individual-hours}$$\n\nSince the work is the same: $$120x = 27000$$.\n\nSolving for $$x$$: $$x = \\frac{27000}{120}$$ = $$\\frac{2700}{12}$$ = $$225$$.\n\nTherefore, 225 individuals are needed."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_APPLICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6089,
        "content": [
          "200"
        ],
        "isCorrect": false
      },
      {
        "id": 6090,
        "content": [
          "144"
        ],
        "isCorrect": false
      },
      {
        "id": 6091,
        "content": [
          "225"
        ],
        "isCorrect": true
      },
      {
        "id": 6092,
        "content": [
          "220"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Mathematical Application in Business"
  },
  {
    "id": 1523,
    "content": [
      "If the measure of each interior angle of a regular polygon is $$135^\\circ$$, then which one of the following is the number of lines of symmetry of the polygon?"
    ],
    "explanation": [
      "The formula for the measure of an interior angle ($$\\theta$$) of a regular polygon with $$n$$ sides is\n$$\n\\theta = \\frac{(n-2) \\times 180^\\circ}{n}\n$$\nWe are given $$\\theta$$ = $$135^\\circ$$. So, we set up the equation:\n$$\n135 = \\frac{(n-2) \\times 180}{n}\n$$\nMultiply both sides by $$n$$:\n$$\n135n = 180(n-2)\n$$\nDistribute the 180:\n$$\n135n = 180n - 360\n$$\nRearrange the terms to solve for $$n$$:\n$$\nn = \\frac{360}{45} = 8\n$$\nThe polygon has 8 sides, meaning it is a regular octagon. A regular polygon with $$n$$ sides has $$n$$ lines of symmetry. Therefore, the regular octagon has 8 lines of symmetry."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_POLYGONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6093,
        "content": [
          "7"
        ],
        "isCorrect": false
      },
      {
        "id": 6094,
        "content": [
          "6"
        ],
        "isCorrect": false
      },
      {
        "id": 6095,
        "content": [
          "9"
        ],
        "isCorrect": false
      },
      {
        "id": 6096,
        "content": [
          "8"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Regular Polygon"
  },
  {
    "id": 1524,
    "content": [
      "Consider the following graph of a given exponential function f(x).",
      "images/maths/year_2016_na/q8_1.png",
      "Which one of the following functions represents the graph shown above?"
    ],
    "explanation": [
      "The graph passes through several key points, including (0, -1), (1, 0), and (2, 2). We can test these points in the given options.\n- For option $$f(x) = 2^x - 2$$:\n    - When $$x=0$$, $$f(0)$$ = $$2^0 - 2$$ = $$1 - 2$$ = $$-1$$. Matches point (0, -1).\n    - When $$x=1$$, $$f(1)$$ = $$2^1 - 2$$ = $$2 - 2$$ = $$0$$. Matches point (1, 0).\n    - When $$x=2$$, $$f(2)$$ = $$2^2 - 2$$ = $$4 - 2$$ = $$2$$. Matches point (2, 2).\n- Since all tested points lie on the graph of $$f(x)$$ = $$2^x - 2$$, this function represents the given graph."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2016_na/q8_1.png"
    ],
    "choices": [
      {
        "id": 6097,
        "content": [
          "$$f(x)=(2)^{x-2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6098,
        "content": [
          "$$f(x)=(\\frac{1}{2})^{x-2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6099,
        "content": [
          "$$f(x)=(2)^{x}-2$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6100,
        "content": [
          "$$f(x)=(\\frac{1}{2})^{x}-2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Polynomial Function"
  },
  {
    "id": 1525,
    "content": [
      "What is the perimeter of a regular hexagon of radius 6cm?"
    ],
    "explanation": [
      "In a regular hexagon, the distance from the center to any vertex (the radius of the circumscribed circle) is equal to the length of a side of the hexagon.\n\nGiven the radius is 6 cm, the side length of the regular hexagon is also 6 cm. A hexagon has 6 sides. The perimeter is the total length of all sides, calculated as $$6 \\times \\text{side length}$$.\n\nTherefore, the perimeter is\n$$\n6 \\times 6 \\text{ cm} = 36 \\text{ cm}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_POLYGONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6101,
        "content": [
          "$$18\\sqrt{3} \\ \\text{cm}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6102,
        "content": [
          "$$18 \\ \\text{cm}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6103,
        "content": [
          "$$36 \\ \\text{cm}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6104,
        "content": [
          "$$36\\sqrt{3} \\ \\text{cm}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Regular Polygon"
  },
  {
    "id": 1526,
    "content": [
      "Which one of the following is quantitative data?"
    ],
    "explanation": [
      "Quantitative data are measures of values or counts and are expressed as numbers.\n\nMeasuring heights involves numerical values (e.g., 175 cm, 160 cm), making it quantitative.\n\nOther options involve qualitative data, which are descriptive and non-numerical (e.g., taste preference, social category, quality assessment like 'good' or 'bad')."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6105,
        "content": [
          "Measuring the heights of each students in the given class."
        ],
        "isCorrect": true
      },
      {
        "id": 6106,
        "content": [
          "Determining the tastes of foods in a restaurant."
        ],
        "isCorrect": false
      },
      {
        "id": 6107,
        "content": [
          "Identifying the social status of individuals."
        ],
        "isCorrect": false
      },
      {
        "id": 6108,
        "content": [
          "Checking the quality of a new product."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 1527,
    "content": [
      "Which one of the following is true about the integral of a function f(x) with respect to a variable x?"
    ],
    "explanation": [
      "The indefinite integral of a function $$f(x)$$, denoted by $$\\int f(x)dx$$, represents the family of all functions whose derivative is $$f(x)$$.\n\nThese functions are called the antiderivatives of $$f(x)$$.\n\nFor example, if $$F'(x)$$ = $$f(x)$$, then $$\\int f(x)dx$$ = $$F(x) + C$$, where C is the constant of integration, representing the set of all antiderivatives."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6109,
        "content": [
          "$$\\int f'(x)dx$$ is the set of all anti-derivatives of f."
        ],
        "isCorrect": false
      },
      {
        "id": 6110,
        "content": [
          "$$\\int f'(x)dx$$ is the set of all derivatives of f."
        ],
        "isCorrect": false
      },
      {
        "id": 6111,
        "content": [
          "$$\\int f(x)dx$$ is the set of all anti-derivatives of f."
        ],
        "isCorrect": true
      },
      {
        "id": 6112,
        "content": [
          "$$\\int f(x)dx$$ is the set of all derivatives of f."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1528,
    "content": [
      "Which one of the following is NOT a valid reason for saving?"
    ],
    "explanation": [
      "Saving typically involves setting aside money for future goals or needs. Valid reasons include planning for events like vacations or retirement, or for financial growth like maximizing interest.\n\nBetting, however, is a form of gambling involving risk and potential loss, and is generally not considered a sound financial strategy or a valid reason for saving money in a traditional financial planning sense."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_APPLICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6113,
        "content": [
          "For betting in football"
        ],
        "isCorrect": true
      },
      {
        "id": 6114,
        "content": [
          "For vacation"
        ],
        "isCorrect": false
      },
      {
        "id": 6115,
        "content": [
          "To maximize interest"
        ],
        "isCorrect": false
      },
      {
        "id": 6116,
        "content": [
          "For the time of retirement"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Mathematical Application in Business"
  },
  {
    "id": 1529,
    "content": [
      "The shaded region in the following figure is the graph of a relation R.",
      "images/maths/year_2016_na/q13_1_background.png",
      "Which one of the following is the domain and range of R respectively?"
    ],
    "explanation": [
      "First, find the intersection point of the two lines: $$x-y+1=0$$ (or $$y=x+1$$) and $$x+y=0$$ (or $$y=-x$$).\n\nSetting the expressions for y equal: $$x+1 = -x$$, which gives $$2x = -1$$, so $$x = -\\frac{1}{2}$$.\n\nSubstituting back into $$y=-x$$, we get\n$$\ny = -(-\\frac{1}{2}) = \\frac{1}{2}\n$$\nThe intersection point is $$(-\\frac{1}{2}, \\frac{1}{2})$$.\n\nThe shaded region R consists of all points $$(x,y)$$ such that $$y \\le x+1$$ and $$y \\ge -x$$.\n\nThe domain is the set of all possible x-values in the shaded region. From the graph, the region extends infinitely to the left from the intersection point's x-coordinate.\n\nThus, the domain is $$x \\le -\\frac{1}{2}$$, or $$(-\\infty, -\\frac{1}{2}]$$.\n\nThe range is the set of all possible y-values. As x decreases towards $$-\\infty$$, the lower boundary $$y=-x$$ increases towards $$+\\infty$$, and the upper boundary $$y=x+1$$ decreases towards $$-\\infty$$.\n\nThe shaded region extends infinitely both upwards and downwards. Therefore, the range is all real numbers, $$\\mathbb{R}$$.\n\nThe domain is $$(-\\infty, -\\frac{1}{2}]$$ and the range is $$\\mathbb{R}$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_INEQUALTIES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2016_na/q13_1_background.png"
    ],
    "choices": [
      {
        "id": 6117,
        "content": [
          "$$(-\\infty, -\\frac{1}{2}]$$ and $$\\mathbb{R}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6118,
        "content": [
          "$$\\mathbb{R}$$ and $$(-\\infty, \\frac{1}{2})$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6119,
        "content": [
          "$$\\mathbb{R}$$ and $$(-\\infty, -\\frac{1}{2}]$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6120,
        "content": [
          "$$(-\\infty, -\\frac{1}{2})$$ and $$\\mathbb{R}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Solving Inequality"
  },
  {
    "id": 1530,
    "content": [
      "Which one of the following statements is the polynomial division theorem?"
    ],
    "explanation": [
      "The Polynomial Division Theorem (or Algorithm) states that for any two polynomials $$f(x)$$ (the dividend) and $$d(x)$$ (the divisor), where $$d(x)$$ is not the zero polynomial, there exist unique polynomials $$q(x)$$ (the quotient) and $$r(x)$$ (the remainder) such that $$f(x) = d(x)q(x) + r(x)$$, and either $$r(x) = 0$$ or the degree of $$r(x)$$ is strictly less than the degree of $$d(x)$$.\n\nCorrect option B provides this statement accurately, including the condition on the degree of the remainder.\n\nOption A is the Rational Root Theorem, Option C is the Remainder Theorem, and Option D is the Factor Theorem."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6121,
        "content": [
          "Let f be a non-constant polynomial with integer coefficients. If the rational number $$\\frac{c}{d}$$ in its lowest terms is a root of f, then c is a factor of the constant term of f and d is a factor of the leading coefficient."
        ],
        "isCorrect": false
      },
      {
        "id": 6122,
        "content": [
          "If f(x) and d(x) are polynomials such that $$d(x) \\neq 0$$ and $$degree(d(x)) \\le degree(f(x))$$, then there exist unique polynomials q(x) and r(x) such that $$f(x) = d(x)q(x)+r(x)$$, where $$r(x)=0$$ or degree of $$r(x) <$$ degree of d(x)."
        ],
        "isCorrect": true
      },
      {
        "id": 6123,
        "content": [
          "If f is a non-constant polynomial and c is a real number, then the remainder when f(x) divided by x-c is f(c)."
        ],
        "isCorrect": false
      },
      {
        "id": 6124,
        "content": [
          "If f is a non-constant polynomial and c is a real number, then x-c is a factor of f(x) if and only if f(c)=0."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 1531,
    "content": [
      "Which one of the following is equal to $$cot(1755^\\circ)$$?"
    ],
    "explanation": [
      "To find $$cot(1755^\\circ)$$, first find the coterminal angle between $$0^\\circ$$ and $$360^\\circ$$.\n\nDivide 1755 by 360:\n$$\n1755 = 4 \\times 360 + 315\n$$\nSo, $$1755^\\circ$$ is coterminal with $$315^\\circ$$.\n\nTherefore, $$cot(1755^\\circ)$$ = $$cot(315^\\circ)$$.\n\nThe angle $$315^\\circ$$ lies in the fourth quadrant, where cotangent is negative.\n\nThe reference angle is $$360^\\circ$$ - $$315^\\circ$$ = $$45^\\circ$$.\n\nThus, $$cot(315^\\circ)$$ = $$-cot(45^\\circ)$$.\n\nSince $$cot(45^\\circ)$$ = $$1$$, we have $$cot(1755^\\circ)$$ = $$-1$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6125,
        "content": [
          "$$\\sqrt{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6126,
        "content": [
          "$$-\\sqrt{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6127,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 6128,
        "content": [
          "-1"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 5,
    "unitName": "Introduction to Trigonometry"
  },
  {
    "id": 1532,
    "content": [
      "Let p and q be proposition with truth values true and false respectively. Which one of the following statements is NOT correct?"
    ],
    "explanation": [
      "We are given p is True and q is False.\n\nLet's evaluate the truth value of the inner logical expressions and then check if the overall statement is correct.\n- $$p \\implies q$$ is $$T \\implies F$$, which is False. The statement says \"$$p \\implies q$$ is false\", which is a correct statement.\n- $$p \\iff q$$ is $$T \\iff F$$, which is False. The statement says \"$$p \\iff q$$ is true\", which is an incorrect statement.\n- $$p \\land q$$ is $$T \\land F$$, which is False. The statement says \"$$p \\land q$$ is false\", which is a correct statement.\n- $$p \\lor q$$ is $$T \\lor F$$, which is True. The statement says \"$$p \\lor q$$ is true\", which is a correct statement.\n\nThe question asks which statement is NOT correct. The statement in second bullet point is not correct because $$p \\iff q$$ is actually false."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6129,
        "content": [
          "$$p \\implies q$$ is false."
        ],
        "isCorrect": false
      },
      {
        "id": 6130,
        "content": [
          "$$p \\iff q$$ is true."
        ],
        "isCorrect": true
      },
      {
        "id": 6131,
        "content": [
          "$$p \\land q$$ is false."
        ],
        "isCorrect": false
      },
      {
        "id": 6132,
        "content": [
          "$$p \\lor q$$ is true."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1533,
    "content": [
      "Which one of the following is equal to the sum $$\\sum_{n=1}^{5} 2n^2$$?"
    ],
    "explanation": [
      "The sum $$\\sum_{n=1}^{5} 2n^2$$ requires evaluating the term $$2n^2$$ for each integer $$n$$ from 1 to 5 and adding the results.\n- For $$n=1$$: $$2(1^2)$$ = $$2(1)$$ = $$2$$\n- For $$n=2$$: $$2(2^2)$$ = $$2(4)$$ = $$8$$\n- For $$n=3$$: $$2(3^2)$$ = $$2(9)$$ = $$18$$\n- For $$n=4$$: $$2(4^2)$$ = $$2(16)$$ = $$32$$\n- For $$n=5$$: $$2(5^2)$$ = $$2(25)$$ = $$50$$\n\nThe sum is 2 + 8 + 18 + 32 + 50"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6133,
        "content": [
          "2 + 8 + 16 + 32 + 64"
        ],
        "isCorrect": false
      },
      {
        "id": 6134,
        "content": [
          "2 + 4 + 8 + 16 + 32"
        ],
        "isCorrect": false
      },
      {
        "id": 6135,
        "content": [
          "2 + 4 + 6 + 8 + 10"
        ],
        "isCorrect": false
      },
      {
        "id": 6136,
        "content": [
          "2 + 8 + 18 + 32 + 50"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1534,
    "content": [
      "A company produces shirts of black and white colors from polyester and cotton. The company has 6000 units of polyester and 3000 units of cotton in its store. A black shirt requires 5 units of polyester and 4 units of cotton where as a white shirt requires 3 units of polyester and 3 units of cotton. If the factory gets a profit of Birr 120 from each black shirt and Birr 200 from each white shirt, what is the maximum profit of the company?"
    ],
    "explanation": [
      "1. Let $$x$$ be the number of black shirts and $$y$$ be the number of white shirts.\n\nThe objective is to maximize the profit $$P$$ = $$120x + 200y$$.\n\nThe constraints are:\n- Polyester: $$5x + 3y$$ $$\\le$$ $$6000$$\n- Cotton: $$4x + 3y$$ $$\\le$$ $$3000$$\n- Non-negativity: $$x \\ge 0$$, $$y \\ge 0$$\n\nWe need to find the vertices of the feasible region defined by these inequalities.\nThe vertices are the intersections of the boundary lines:\n\n- Intersection of $$x=0$$ and $$y=0$$: (0, 0)\n- Intersection of $$x=0$$ and $$4x+3y$$ = $$3000$$: $$3y$$ = $$3000 \\implies y$$ = $$1000$$. Point (0, 1000). Check constraint $$5x+3y$$ $$\\le$$ $$6000$$: $$5(0)+3(1000)$$ = $$3000 \\le 6000$$. Feasible.\n- Intersection of $$y=0$$ and $$4x+3y$$ = $$3000$$: $$4x$$ = $$3000 \\implies x$$ = $$750$$. Point (750, 0). Check constraint $$5x+3y$$ $$\\le$$ $$6000$$: $$5(750)+3(0)$$ = $$3750 \\le 6000$$. Feasible.\n- Intersection of $$5x+3y$$ = $$6000$$ and $$4x+3y$$ = $$3000$$. Subtracting the second from the first: $$x$$ = $$3000$$. Substituting into $$4x+3y$$ = $$3000$$: $$4(3000)+3y$$ = $$3000$$ $$\\implies$$ $$12000+3y$$ = $$3000 \\implies 3y$$ = $$-9000 \\implies y$$ = $$-3000$$. Point (3000, -3000) is not feasible ($$y \\ge 0$$).\n\nThe feasible region is bounded by the vertices (0, 0), (750, 0), and (0, 1000).\n\nEvaluate the profit at each vertex:\n\n- P(0, 0) = $$120(0) + 200(0)$$ = $$0$$\n- P(750, 0) = $$120(750) + 200(0)$$ = $$90000$$\n- P(0, 1000) = $$120(0) + 200(1000)$$ = $$200000$$\n\nThe maximum profit is Birr 200,000."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_APPLICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6137,
        "content": [
          "Birr 144,000"
        ],
        "isCorrect": false
      },
      {
        "id": 6138,
        "content": [
          "Birr 120,000"
        ],
        "isCorrect": false
      },
      {
        "id": 6139,
        "content": [
          "Birr 344,000"
        ],
        "isCorrect": false
      },
      {
        "id": 6140,
        "content": [
          "Birr 200,000"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Mathematical Application in Business"
  },
  {
    "id": 1535,
    "content": [
      "Let S, R and T be any three sets. Which one of the following is NOT true about the union of the sets?"
    ],
    "explanation": [
      "Let's evaluate the truth of each statement based on the properties of set union.\n- $$(S \\cup R) \\cup T$$ = $$T \\cup (R \\cup S)$$.\n    - The union operation is associative ($$A \\cup (B \\cup C)$$ = $$(A \\cup B) \\cup C$$) and commutative ($$A \\cup B$$ = $$B \\cup A$$). $$(S \\cup R) \\cup T$$ = $$S \\cup R \\cup T$$. $$T \\cup (R \\cup S)$$ = $$T \\cup (S \\cup R)$$ = $$T \\cup S \\cup R$$. Since the order doesn't matter for union, $$S \\cup R \\cup T$$ = $$T \\cup S \\cup R$$. So, statement A is true.\n- $$S \\cup S$$ = $$S$$.\n    - This is the idempotent law for union. It is always true.\n- $$S \\cup R$$ = $$R \\cup S$$.\n    - This is the commutative law for union. It is always true.\n- $$S \\cup T$$ = $$T$$.\n    - This statement is true only if S is a subset of T ($$S \\subseteq T$$). It is not true for any arbitrary sets S and T. For example, if $$S=\\{1,2\\}$$ and $$T=\\{2,3\\}$$, then $$S \\cup T$$ = $$\\{1,2,3\\} \\neq T$$. Therefore, statement D is NOT always true."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SETS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6141,
        "content": [
          "$$(S \\cup R) \\cup T$$ = $$T \\cup (R \\cup S)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6142,
        "content": [
          "$$S \\cup S$$ = $$S$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6143,
        "content": [
          "$$S \\cup R$$ = $$R \\cup S$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6144,
        "content": [
          "$$S \\cup T$$ = $$T$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1536,
    "content": [
      "Which one of the following is equal to the polynomial function $$f(x)$$ = $$x^2 + 4x + 4$$?"
    ],
    "explanation": [
      "The given polynomial is $$f(x)$$ = $$x^2 + 4x + 4$$. We can simplify each option to see which one matches $$f(x)$$.\n- $$k(x)$$ = $$(x-2)(x+2)$$ = $$x^2 - 2^2$$ = $$x^2 - 4$$. This is not equal to $$f(x)$$.\n- $$l(x)$$ = $$(x^2 + 10x + 3)$$ + $$(-6x + 1)$$ = $$x^2 + 4x + 4$$. This is equal to $$f(x)$$.\n- $$g(x)$$ = $$\\frac{x^4 + 4x^2 + 4}{x^2 + 2}$$ = $$\\frac{(x^2 + 2)^2}{x^2 + 2}$$ = $$x^2 + 2$$ (assuming $$x^2+2 \\neq 0$$, which is true for real x). This is not equal to $$f(x)$$.\n- $$h(x)$$ = $$(x^2 + 6x + 8)$$ - $$(2x - 4)$$ = $$x^2 + 4x + 12$$. This is not equal to $$f(x)$$.\n\nTherefore, $$l(x)$$ is equal to $$f(x)$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6145,
        "content": [
          "$$k(x)$$ = $$(x-2)(x+2)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6146,
        "content": [
          "$$l(x)$$ = $$(x^2 + 10x + 3)$$ + $$(-6x + 1)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6147,
        "content": [
          "$$g(x)$$ = $$\\frac{x^4 + 4x^2 + 4}{x^2 + 2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6148,
        "content": [
          "$$h(x)$$ = $$(x^2 + 6x + 8)$$ - $$(2x - 4)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 1537,
    "content": [
      "Which one of the following is true about the function $$f(x) = \\tan x$$?"
    ],
    "explanation": [
      "Let's analyze the properties of $$f(x) = \\tan x$$.\n- Period: The fundamental period of $$\\tan x$$ is $$\\pi$$, not $$\\frac{\\pi}{2}$$. So A is false.\n- Y-intercept: The y-intercept occurs when $$x=0$$. $$f(0)$$ = $$\\tan(0)$$ = $$0$$. The graph intersects the y-axis at (0, 0), not $$(\\frac{\\pi}{2}, 0)$$. So B is false.\n- Domain: The tangent function is undefined at odd multiples of $$\\frac{\\pi}{2}$$, i.e., $$x$$ = $$\\frac{\\pi}{2} + n\\pi$$, where $$n$$ is an integer. The domain is $$\\mathbb{R}$$ $$\\setminus$$ $$\\{$$ $$\\frac{\\pi}{2} + n\\pi$$ $$\\mid n \\in \\mathbb{Z}$$ $$\\}$$. Option C states the domain is $$\\mathbb{R}$$ $$\\setminus$$ $$(-\\frac{\\pi}{2},$$ $$\\frac{\\pi}{2})$$, which is incorrect. So C is false.\n- Range: The tangent function can take any real value. Its range is $$(-\\infty, \\infty)$$, which is the set of all real numbers, $$\\mathbb{R}$$. So D is true."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6149,
        "content": [
          "f is a periodic function with period $$\\frac{\\pi}{2}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 6150,
        "content": [
          "The graph of f intersects y-axis at $$(\\frac{\\pi}{2}, 0)$$."
        ],
        "isCorrect": false
      },
      {
        "id": 6151,
        "content": [
          "The domain of f is $$\\mathbb{R}$$ $$\\setminus$$ $$(-\\frac{\\pi}{2},$$ $$\\frac{\\pi}{2})$$."
        ],
        "isCorrect": false
      },
      {
        "id": 6152,
        "content": [
          "The range of f is the set of real numbers, $$\\mathbb{R}$$."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Trigonometric Function"
  },
  {
    "id": 1538,
    "content": [
      "Which one of the following is an equation of the parabola with vertex V(0, 0) and focus F(2, 0)?"
    ],
    "explanation": [
      "The vertex is at the origin (0, 0) and the focus is at (2, 0).\n\nSince the focus is on the positive x-axis and the vertex is at the origin, the parabola opens to the right.\n\nThe standard equation for a parabola opening to the right with vertex (0, 0) is $$y^2 = 4px$$, where $$p$$ is the distance from the vertex to the focus. In this case, the distance from V(0, 0) to F(2, 0) is $$p = 2$$.\n\nSubstituting $$p=2$$ into the standard equation gives $$y^2 = 4(2)x$$, which simplifies to $$y^2 = 8x$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6153,
        "content": [
          "$$x^2 = 8y$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6154,
        "content": [
          "$$x^2 = \\frac{1}{8}y$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6155,
        "content": [
          "$$y^2 = 8x$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6156,
        "content": [
          "$$y^2 = \\frac{1}{8}x$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1539,
    "content": [
      "Which one of the following is equal to the sum $$\\sum_{k=1}^{7} 729(3^{1-k})$$?"
    ],
    "explanation": [
      "The sum is a geometric series.\n\nLet the $$k^{th}$$ term be $$a_k$$ = $$729(3^{1-k})$$\n\nWe can rewrite this as $$a_k$$ = $$729 \\cdot 3^1 \\cdot 3^{-k}$$ = $$2187 \\cdot (\\frac{1}{3})^k$$.\n\nThe first term (for k=1) is $$a_1$$ = $$2187 \\cdot (\\frac{1}{3})^1$$ = $$729$$.\n\nThe common ratio is $$r$$ = $$\\frac{a_{k+1}}{a_k}$$ = $$\\frac{2187 (\\frac{1}{3})^{k+1}}{2187 (\\frac{1}{3})^k}$$ = $$\\frac{1}{3}$$.\n\nThe number of terms is $$n=7$$.\n\nThe sum of the first n terms of a geometric series is given by\n$$\nS_n = \\frac{a_1(1-r^n)}{1-r}\n$$\n$$\nS_7 = \\frac{729(1 - (\\frac{1}{3})^7)}{1 - \\frac{1}{3}}\n$$\n$$\nS_7 = \\frac{729(\\frac{2187-1}{2187})}{\\frac{2}{3}}\n$$\n$$\nS_7 =  \\frac{729(\\frac{2186}{2187})}{\\frac{2}{3}}\n$$\nSince $$2187$$ = $$3^7$$ and $$729$$ = $$3^6$$, we have $$\\frac{729}{2187}$$ = $$\\frac{1}{3}$$.\n$$\nS_7 = \\frac{\\frac{1}{3} \\times 2186}{\\frac{2}{3}}\n$$\n$$\nS_7 = \\frac{2186}{3} \\times \\frac{3}{2} = 1093\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6157,
        "content": [
          "1088"
        ],
        "isCorrect": false
      },
      {
        "id": 6158,
        "content": [
          "1079"
        ],
        "isCorrect": false
      },
      {
        "id": 6159,
        "content": [
          "1093"
        ],
        "isCorrect": true
      },
      {
        "id": 6160,
        "content": [
          "1092"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1540,
    "content": [
      "What is the maximum value of $$z=2x+3y$$ subjected to the constraints\n$$\n\\begin{cases}\nx + y \\le 6 \\\\\n2x - y \\le 6 \\\\\nx \\ge 0 \\\\\ny \\ge 0\n\\end{cases}\n$$"
    ],
    "explanation": [
      "This is a linear programming problem. We need to find the vertices of the feasible region defined by the constraints and evaluate the objective function $$z = 2x + 3y$$ at these vertices.\nThe vertices are the intersection points of the boundary lines:\n- Intersection of $$x=0$$ and $$y=0$$: (0, 0)\n- Intersection of $$x=0$$ and $$x+y=6$$: (0, 6)\n- Intersection of $$y=0$$ and $$2x-y=6$$: $$2x=6$$ $$\\implies$$ $$x=3$$. Point (3, 0).\n- Intersection of $$x+y=6$$ and $$2x-y=6$$. Add the two equations: $$3x = 12$$ $$\\implies$$ $$x=4$$. Substitute $$x=4$$ into $$x+y=6$$: $$4+y=6$$ $$\\implies$$ $$y=2$$. Point (4, 2).\nWe check if the intersection of $$y=0$$ and $$x+y=6$$ (point (6,0)) is feasible: $$2(6)-0 = 12 \\not\\le 6$$. Not feasible. We check if the intersection of $$x=0$$ and $$2x-y=6$$ (point (0,-6)) is feasible: $$y=-6 \\not\\ge 0$$. Not feasible.\n\nThe feasible vertices are (0, 0), (0, 6), (3, 0), and (4, 2). Now evaluate $$z$$ = $$2x + 3y$$ at these vertices:\n\n- At (0, 0): $$z$$ = $$2(0) + 3(0)$$ = $$0$$\n- At (0, 6): $$z$$ = $$2(0) + 3(6)$$ = $$18$$\n- At (3, 0): $$z$$ = $$2(3) + 3(0)$$ = $$6$$\n- At (4, 2): $$z$$ = $$2(4) + 3(2)$$ = $$14$$\n\nThe maximum value of z is 18, which occurs at the vertex (0, 6)."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_INEQUALTIES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6161,
        "content": [
          "18"
        ],
        "isCorrect": true
      },
      {
        "id": 6162,
        "content": [
          "22"
        ],
        "isCorrect": false
      },
      {
        "id": 6163,
        "content": [
          "12"
        ],
        "isCorrect": false
      },
      {
        "id": 6164,
        "content": [
          "14"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Solving Inequality"
  },
  {
    "id": 1541,
    "content": [
      "Which one of the following numbers is a common multiple of 324 and 1152?"
    ],
    "explanation": [
      "To find a common multiple, we can find the Least Common Multiple (LCM). \n\nFirst, find the prime factorization of each number:\n$$\n324 = 2^2 \\times 3^4\n$$\n$$\n1152 = 2^7 \\times 3^2\n$$\nThe LCM is found by taking the highest power of each prime factor present in either factorization:\n$$\nLCM(324, 1152) = 2^{\\max(2, 7)} \\times 3^{\\max(4, 2)} = 2^7 \\times 3^4= 10368\n$$\nAny common multiple must be a multiple of the LCM. We check the options:\n- 13824 / 10368 = 1.33... (Not a multiple)\n- 20736 / 10368 = 2 (This is a multiple)\n- 5184 / 10368 = 0.5 (Not a multiple)\n- 7776 / 10368 = 0.75 (Not a multiple)\n\nTherefore, 20736 is a common multiple."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_NUMBER_SYSTEM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6165,
        "content": [
          "13824"
        ],
        "isCorrect": false
      },
      {
        "id": 6166,
        "content": [
          "20736"
        ],
        "isCorrect": true
      },
      {
        "id": 6167,
        "content": [
          "5184"
        ],
        "isCorrect": false
      },
      {
        "id": 6168,
        "content": [
          "7776"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "The Number System"
  },
  {
    "id": 1542,
    "content": [
      "Consider a circle with center O and the line segments $$\\overline{AB}$$, $$\\overline{AC}$$ and $$\\overline{BC}$$ are chords of the circle as shown in the figure below. If $$m(\\angle ABC)$$ = $$60^\\circ$$ and $$m(\\angle ACB)$$ = $$40^\\circ$$, then what is $$m(\\angle BOC)$$?",
      "images/maths/year_2016_na/q26_1.png"
    ],
    "explanation": [
      "The sum of angles in triangle ABC is $$180^\\circ$$.\n\nSo, $$m(\\angle BAC)$$ = $$180^\\circ$$ - $$m(\\angle ABC)$$ - $$m(\\angle ACB)$$ = $$180^\\circ$$ - $$60^\\circ$$ - $$40^\\circ$$ = $$80^\\circ$$.\n\nThe angle subtended by an arc at the center is double the angle subtended by the same arc at any point on the remaining part of the circle. Here, the central angle $$\\angle BOC$$ and the inscribed angle $$\\angle BAC$$ subtend the same arc BC.\n\nTherefore, $$m(\\angle BOC)$$ = $$2 \\times m(\\angle BAC)$$ = $$2 \\times 80^\\circ$$ = $$160^\\circ$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2016_na/q26_1.png"
    ],
    "choices": [
      {
        "id": 6169,
        "content": [
          "$$120^\\circ$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6170,
        "content": [
          "$$160^\\circ$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6171,
        "content": [
          "$$100^\\circ$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6172,
        "content": [
          "$$80^\\circ$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1543,
    "content": [
      "Which one of the following is the solution of the equation $$(243)^{2x-3}$$ = $$\\frac{(81)^{-3x+2}}{3}$$ in the set of real numbers?"
    ],
    "explanation": [
      "Make the bases the same: 243, 81, and 3 are all powers of 3 ($$243=3^5$$, $$81=3^4$$, $$3=3^1$$).\n$$\n(3^5)^{2x-3} = \\frac{(3^4)^{-3x+2}}{3^1}\n$$\n$$\n3^{5(2x-3)} = \\frac{3^{4(-3x+2)}}{3^1}\n$$\n$$\n3^{10x-15} = \\frac{3^{-12x+8}}{3^1}\n$$\nWhen dividing powers with the same base, subtract the exponents.\n$$\n3^{10x-15} = 3^{(-12x+8) - 1}\n$$\n$$\n3^{10x-15} = 3^{-12x+7}\n$$\nSince the bases are the same, the exponents must be equal.\n$$\n10x - 15 = -12x + 7\n$$\nSolve for x:\n$$\nx = 1\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6173,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 6174,
        "content": [
          "-2"
        ],
        "isCorrect": false
      },
      {
        "id": 6175,
        "content": [
          "-1"
        ],
        "isCorrect": false
      },
      {
        "id": 6176,
        "content": [
          "1"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 1544,
    "content": [
      "What is the total surface area of a regular square pyramid with slant height 8cm and base area 25 cm²?"
    ],
    "explanation": [
      "The total surface area (TSA) of a pyramid is the sum of the base area -B- and the lateral surface area -LSA-.\n\nWe are given the base area $$B$$ = $$25 \\text{ cm}^2$$. Since it's a regular square pyramid, the base is a square.\n\nLet the side length of the base be $$s$$. Then $$s^2$$ = $$B$$ = $$25 \\text{ cm}^2$$, so $$s$$ = $$\\sqrt{25}$$ = $$5 \\text{ cm}$$.\n\nThe lateral surface area consists of four identical triangular faces. The area of one triangular face is given by\n$$\n(1/2) \\times \\text{base} \\times \\text{slant height}\n$$\nThe base of each triangle is the side length $$s=5 \\text{ cm}$$, and the slant height $$l=8 \\text{ cm}$$.\n\nSo, the area of one triangle is\n$$\n(1/2) \\times 5 \\times 8 = 20 \\text{ cm}^2\n$$\nThe total lateral surface area is\n$$\nLSA = 4 \\times 20 = 80 \\text{ cm}^2\n$$\nThe total surface area is\n$$\nTSA = B + LSA = 25 + 80 = 105 \\text{ cm}^2\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6177,
        "content": [
          "80 cm²"
        ],
        "isCorrect": false
      },
      {
        "id": 6178,
        "content": [
          "65 cm²"
        ],
        "isCorrect": false
      },
      {
        "id": 6179,
        "content": [
          "105 cm²"
        ],
        "isCorrect": true
      },
      {
        "id": 6180,
        "content": [
          "90 cm²"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1545,
    "content": [
      "The following table presents the scores of Grade 11 students of a certain school in a Mathematics Examination.",
      "images/maths/year_2016_na/q29_1.png",
      "What is the median of the data given in the above table?"
    ],
    "explanation": [
      "First, calculate the total number of students (N) and the cumulative frequencies (CF).\n\nN = 10+9+15+12+10+4+2 = 62.\n\nThe median position is N/2 = 62/2 = 31.\n\nWe find the cumulative frequencies: 10, 19 (10+9), 34 (19+15), 46 (34+12), 56 (46+10), 60 (56+4), 62 (60+2).\n\nThe median class is the class containing the $$31^{\\text{st}}$$ student.\n\nSince the CF up to the class 41-50 is 19 and the CF up to the class 51-60 is 34, the 31st student falls in the 51-60 class.\n\nUse the formula for the median of grouped data:\n$$\nM = L + \\frac{\\frac{N}{2} - CF}{f} \\times w\n$$\n- L = Lower class boundary of the median class = 50.5\n- N = Total frequency = 62\n- CF = Cumulative frequency of the class preceding the median class = 19\n- f = Frequency of the median class = 15\n- w = Class width = 10 (e.g., 60.5 - 50.5 = 10)\n\n$$\nM = 50.5 + \\frac{31 - 19}{15} \\times 10 = 58.5\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2016_na/q29_1.png"
    ],
    "choices": [
      {
        "id": 6181,
        "content": [
          "58.5"
        ],
        "isCorrect": true
      },
      {
        "id": 6182,
        "content": [
          "60.5"
        ],
        "isCorrect": false
      },
      {
        "id": 6183,
        "content": [
          "50.5"
        ],
        "isCorrect": false
      },
      {
        "id": 6184,
        "content": [
          "55.5"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 1546,
    "content": [
      "What is the area of the region bounded by the graph of $$f(x) = x^3$$ and the x-axis on the interval [-4, 2]?"
    ],
    "explanation": [
      "The area is calculated by integrating the absolute value of the function over the interval. Since $$f(x)=x^3$$ is negative for $$x<0$$ and positive for $$x>0$$, we split the integral:\n\nArea = $$\\int_{-4}^{2} |x^3| dx$$ = $$\\int_{-4}^{0} |x^3| dx$$ + $$\\int_{0}^{2} |x^3| dx$$\n\nArea = $$\\int_{-4}^{0} (-x^3) dx$$ + $$\\int_{0}^{2} x^3 dx$$\n\nArea = $$[-\\frac{x^4}{4}]{-4}^{0}$$ + $$[\\frac{x^4}{4}]{0}^{2}$$\n\nArea = $$(-\\frac{0^4}{4}$$ $$-$$ $$(-\\frac{(-4)^4}{4}))$$ + $$(\\frac{2^4}{4}$$ $$-$$ $$\\frac{0^4}{4})$$\n\nArea = $$-(0 - \\frac{256}{4})$$ + $$(\\frac{16}{4} - 0)$$\n\nArea = $$-(-\\frac{256}{4})$$ + $$\\frac{16}{4}$$ = $$68 \\ \\text{square units}$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6185,
        "content": [
          "120 Square units"
        ],
        "isCorrect": false
      },
      {
        "id": 6186,
        "content": [
          "136 Square units"
        ],
        "isCorrect": false
      },
      {
        "id": 6187,
        "content": [
          "60 Square units"
        ],
        "isCorrect": false
      },
      {
        "id": 6188,
        "content": [
          "68 Square units"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1547,
    "content": [
      "If $$a$$ = $$2 - 3\\sqrt{5}$$ and $$b$$ = $$3 + 2\\sqrt{5}$$, then which one of the following is true?"
    ],
    "explanation": [
      "Let's evaluate each option:\n- Option 1: $$ab$$ = $$36$$ (false)\n\n$$\nab = (2 - 3\\sqrt{5})(3 + 2\\sqrt{5})\n$$\n\n$$\n= 6 + 4\\sqrt{5} - 9\\sqrt{5} - 30\n$$\n$$\n= -24 - 5\\sqrt{5} \\neq 36\n$$\n\n- Option 2: $$11a \\div b$$ = $$-36 + 13\\sqrt{5}$$ (true)\n\n$$\n\\frac{11a}{b} = \\frac{11(2 - 3\\sqrt{5})}{3 + 2\\sqrt{5}} \\cdot \\frac{3 - 2\\sqrt{5}}{3 - 2\\sqrt{5}}\n$$\n$$\n= \\frac{11(6 - 4\\sqrt{5} - 9\\sqrt{5} + 30)}{9 - 20}\n$$\n$$\n= \\frac{11(36 - 13\\sqrt{5})}{-11}\n$$\n$$\n11a \\div b = -36 + 13\\sqrt{5}\n$$\n\n- Option 3: $$a + b$$ = $$5$$ (false)\n\n$$\na + b = (2 - 3\\sqrt{5}) + (3 + 2\\sqrt{5})\n$$\n$$\n= 5 - \\sqrt{5} \\neq 5\n$$\n\n- Option 4: $$a - b$$ = $$-1 - \\sqrt{5}$$ (false)\n\n$$\na - b = (2 - 3\\sqrt{5}) - (3 + 2\\sqrt{5})\n$$\n$$\n= -1 - 5\\sqrt{5} \\neq -1 - \\sqrt{5}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_NUMBER_SYSTEM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6189,
        "content": [
          "$$ab$$ = $$36$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6190,
        "content": [
          "$$11a \\div b$$ = $$-36 + 13\\sqrt{5}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6191,
        "content": [
          "$$a + b$$ = $$5$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6192,
        "content": [
          "$$a - b = -1 - \\sqrt{5}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "The Number System"
  },
  {
    "id": 1548,
    "content": [
      "A sector of a circle of diameter 8cm is formed by a central angle of $$45^\\circ$$. What is the area of the sector?"
    ],
    "explanation": [
      "The diameter is 8 cm, so the radius is $$r$$ = $$\\frac{8}{2}$$ = $$4 \\ \\text{cm}$$. The central angle is $$\\theta = 45^\\circ$$. The area of a sector is given by the formula\n$$\nA = \\frac{\\theta}{360^\\circ} \\times \\pi r^2\n$$\nSubstituting the values:\n$$\nA = \\frac{45^\\circ}{360^\\circ} \\times \\pi (4)^2\n$$\n$$\nA = \\frac{1}{8} \\times \\pi (16)\n$$\n$$\nA = \\frac{16\\pi}{8} = 2\\pi \\text{ cm}^2\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6193,
        "content": [
          "$$8\\pi \\text{ cm}^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6194,
        "content": [
          "$$2\\pi \\text{ cm}^2$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6195,
        "content": [
          "$$\\pi \\text{ cm}^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6196,
        "content": [
          "$$(2\\pi+8) \\text{ cm}^2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1549,
    "content": [
      "Which one of the following intervals is the solution set of the inequality $$|3 - \\frac{1}{2}x| < 5$$?"
    ],
    "explanation": [
      "The inequality $$|3 - \\frac{1}{2}x| < 5$$ is equivalent to\n$$\n-5 < 3 - \\frac{1}{2}x < 5\n$$\nSubtract 3 from all parts: $$-5 - 3$$ $$<$$ $$-\\frac{1}{2}x < 5 - 3$$, which simplifies to\n$$\n-8 < -\\frac{1}{2}x < 2\n$$\nMultiply all parts by -2 and reverse the inequality signs:\n$$\n(-8)(-2) > (-\\frac{1}{2}x)(-2) > (2)(-2)\n$$\nWhich gives\n$$\n16 > x > -4\n$$\nRewriting this in the standard order gives\n$$\n-4 < x < 16\n$$\nThe solution set is the interval (-4, 16)"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_INEQUALTIES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6197,
        "content": [
          "(-16, 4)"
        ],
        "isCorrect": false
      },
      {
        "id": 6198,
        "content": [
          "(-4, 16)"
        ],
        "isCorrect": true
      },
      {
        "id": 6199,
        "content": [
          "(-8, 2)"
        ],
        "isCorrect": false
      },
      {
        "id": 6200,
        "content": [
          "(-2, 8)"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Solving Inequality"
  },
  {
    "id": 1550,
    "content": [
      "The altitude of a frustum of a regular square pyramid is 9 cm. What is the volume of the frustum if the side length of the upper base is 6 cm and the side length of the lower base is 10 cm?"
    ],
    "explanation": [
      "The volume V of a frustum of a pyramid is given by the formula\n$$\nV = \\frac{1}{3}h(B_1 + B_2 + \\sqrt{B_1 B_2})\n$$\nWhere $$h$$ is the altitude, $$B_1$$ is the area of the lower base, and $$B_2$$ is the area of the upper base.\n\nFor a regular square pyramid, the bases are squares.\nGiven: h = 9 cm, side length of lower base = 10 cm, side length of upper base = 6 cm.\n\nArea of lower base\n$$\nB_1 = (10)^2 = 100 \\text{ cm}^2\n$$\nArea of upper base\n$$\nB_2 = (6)^2 = 36 \\text{ cm}^2\n$$\nSubstitute these values into the volume formula:\n$$\nV = \\frac{1}{3}(9)(100 + 36 + \\sqrt{100 \\times 36})\n$$\n$$\nV = 3(136 + \\sqrt{3600})\n$$\n$$\nV = 3(136 + 60)\n$$\n$$\nV = 3(196) = 588 \\text{ cm}^3\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6201,
        "content": [
          "$$108 \\text{ cm}^3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6202,
        "content": [
          "$$324 \\text{ cm}^3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6203,
        "content": [
          "$$588 \\text{ cm}^3$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6204,
        "content": [
          "$$196 \\text{ cm}^3$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1551,
    "content": [
      "Which one of the following numbers is the coefficient of $$x^6y^4$$ in the expansion of $$(x+y)^{10}$$?"
    ],
    "explanation": [
      "According to the Binomial Theorem, the term containing $$x^{n-k}y^k$$ in the expansion of $$(x+y)^n$$ is given by\n$$\n\\binom{n}{k}x^{n-k}y^k\n$$\nIn this case, n = 10. We are looking for the coefficient of the term $$x^6y^4$$.\n\nHere, k=4 (the power of y) and n - k = 10 - 4 = 6 (the power of x).\n\nThe coefficient is\n$$\n\\binom{n}{k} = \\binom{10}{4}\n$$\nCalculating the binomial coefficient:\n$$\n\\binom{10}{4} = \\frac{10!}{4!(10-4)!}\n$$\n$$\n= \\frac{10!}{4!6!}\n$$\n$$\n= \\frac{10 \\times 9 \\times 8 \\times 7}{4 \\times 3 \\times 2 \\times 1}\n$$\n$$\n= \\frac{5040}{24} = 210\n$$\nThus, the coefficient of $$x^6y^4$$ is 210."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6205,
        "content": [
          "4860"
        ],
        "isCorrect": false
      },
      {
        "id": 6206,
        "content": [
          "1260"
        ],
        "isCorrect": false
      },
      {
        "id": 6207,
        "content": [
          "210"
        ],
        "isCorrect": true
      },
      {
        "id": 6208,
        "content": [
          "240"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1552,
    "content": [
      "Which one of the following is true about the Range and Interquartile Range (IQR) of a given data?"
    ],
    "explanation": [
      "Both the Range (Maximum value - Minimum value) and the Interquartile Range (Q3 - Q1) are used to measure the spread or dispersion of data, meaning they are both measures of variation.\n\nOption A is incorrect because the range uses the entire spread, not just the middle 50%.\n\nOption C is incorrect because while the range is highly affected by extreme values, the IQR is designed to be robust (less affected) by extreme values as it focuses on the middle 50% of the data.\n\nOption D is incorrect; these measures describe the overall variability of the dataset, not the variability of individual data points.\n\nTherefore, the statement that both are measures of variation is the most accurate and true statement among the choices."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6209,
        "content": [
          "Both are considering only the middle 50% of the data."
        ],
        "isCorrect": false
      },
      {
        "id": 6210,
        "content": [
          "Both are measures of variation of the data."
        ],
        "isCorrect": true
      },
      {
        "id": 6211,
        "content": [
          "Both are affected by extreme values in the data."
        ],
        "isCorrect": false
      },
      {
        "id": 6212,
        "content": [
          "Both are measures of the variability of each item in the data."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 1553,
    "content": [
      "Which one of the following is equal to the expression\n$$\n\\frac{(125)^{\\frac{2}{3}} (81)^{-\\frac{3}{4}}}{(27)^{-\\frac{2}{3}} (625)^{\\frac{3}{4}}} \\ \\text{?}\n$$"
    ],
    "explanation": [
      "Rewrite the bases as powers of prime numbers: $$125$$ = $$5^3$$, $$81$$ = $$3^4$$, $$27$$ = $$3^3$$, $$625$$ = $$5^4$$.\n\nSubstitute these into the expression:\n$$\n\\frac{((5^3))^{\\frac{2}{3}} ((3^4))^{-\\frac{3}{4}}}{((3^3))^{-\\frac{2}{3}} ((5^4))^{\\frac{3}{4}}}\n$$\nApply the power rule $$(a^m)^n$$ = $$a^{mn}$$:\n$$\n\\frac{5^{3 \\times \\frac{2}{3}} 3^{4 \\times (-\\frac{3}{4})}}{3^{3 \\times (-\\frac{2}{3})} 5^{4 \\times \\frac{3}{4}}} = \\frac{5^2 \\cdot 3^{-3}}{3^{-2} \\cdot 5^3}\n$$\nApply exponent rules $$\\frac{a^m}{a^n}$$ = $$a^{m-n}$$ and $$a^{-p}$$ = $$\\frac{1}{a^p}$$:\n$$\n5^{2-3} \\cdot 3^{-3 - (-2)}\n$$\n$$\n5^{-1} \\cdot 3^{-1}\n$$\n$$\n(5 \\cdot 3)^{-1} = 15^{-1} = \\frac{1}{15}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_NUMBER_SYSTEM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6213,
        "content": [
          "$$\\frac{1}{15}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6214,
        "content": [
          "$$15$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6215,
        "content": [
          "$$\\frac{3}{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6216,
        "content": [
          "$$\\frac{5}{3}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "The Number System"
  },
  {
    "id": 1554,
    "content": [
      "If the length of the sides of a triangle are 8cm, 6cm and 4cm, then which one of the following is the area of the triangle?"
    ],
    "explanation": [
      "Use Heron's formula to find the area of a triangle given its side lengths a=8, b=6, c=4. First, calculate the semi-perimeter s:\n$$\ns = \\frac{a+b+c}{2} = \\frac{8+6+4}{2} = 9\n$$\nHeron's formula for the area A is\n$$\nA = \\sqrt{s(s-a)(s-b)(s-c)}\n$$\n$$\nA = \\sqrt{9(9-8)(9-6)(9-4)}\n$$\n$$\n= \\sqrt{9(1)(3)(5)}\n$$\n$$\n= \\sqrt{9 \\times 15}\n$$\n$$\n= \\sqrt{9} \\sqrt{15}\n$$\n$$\nA = 3\\sqrt{15}\\,\\text{cm}^2\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6217,
        "content": [
          "$$3\\sqrt{15}\\,\\text{cm}^2$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6218,
        "content": [
          "$$1.5\\sqrt{15}\\,\\text{cm}^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6219,
        "content": [
          "$$24\\,\\text{cm}^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6220,
        "content": [
          "$$12\\,\\text{cm}^2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1555,
    "content": [
      "The following figure is the graph of a quadratic function $$f(x)$$ = $$ax^2 + bx + c$$ in the set of real numbers.",
      "images/maths/year_2016_na/q39_1.png",
      "Which one of the following is the solution set of the inequality $$f(x) \\le 0$$?"
    ],
    "explanation": [
      "The inequality $$f(x) \\le 0$$ asks for the x-values where the graph of the function is on or below the x-axis.\n\nThe graph shows a parabola opening downwards, intersecting the x-axis at $$x=2$$ and $$x=6$$. The function $$f(x)$$ is equal to 0 at these intercepts.\n\nThe function $$f(x)$$ is negative (below the x-axis) when x is less than 2 or when x is greater than 6.\n\nTherefore, the solution set for $$f(x) \\le 0$$ is $$x \\le 2$$ or $$x \\ge 6$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_INEQUALTIES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2016_na/q39_1.png"
    ],
    "choices": [
      {
        "id": 6221,
        "content": [
          "$$\\{x: x \\le 0 \\text{ and } x \\ge -4\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6222,
        "content": [
          "$$\\{x: x \\le -4 \\text{ or } x \\ge 0\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6223,
        "content": [
          "$$\\{x: x \\le 2 \\text{ or } x \\ge 6\\}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6224,
        "content": [
          "$$\\{x: x \\ge 2 \\text{ and } x \\le 6\\}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Solving Inequality"
  },
  {
    "id": 1556,
    "content": [
      "Which one of the following is an onto function from $$\\mathbb{R}$$ onto $$\\mathbb{R}$$?"
    ],
    "explanation": [
      "An onto (surjective) function from $$\\mathbb{R}$$ to $$\\mathbb{R}$$ must have its range equal to $$\\mathbb{R}$$. Let's examine the ranges of the given functions:\n- $$f(x)$$ = $$-3x^2 + 2x$$ is a quadratic function representing a downward-opening parabola. Its range is limited to $$(-\\infty, y_{max}]$$ and is not $$\\mathbb{R}$$.\n- $$f(x)$$ = $$5x^3 + 1$$ is a cubic function. As $$x$$ takes all real values from $$-\\infty$$ to $$+\\infty$$, $$x^3$$ also takes all real values. Therefore, $$5x^3+1$$ covers all real numbers. Its range is $$\\mathbb{R}$$, so it is onto.\n- $$f(x)$$ = $$|x - 1|$$ is an absolute value function. Its range is $$[0, \\infty)$$, which is not $$\\mathbb{R}$$.\n- $$f(x)$$ = $$\\sqrt{x^2+1}$$. Since $$x^2 \\ge 0$$, $$x^2+1 \\ge 1$$. Thus, $$\\sqrt{x^2+1} \\ge 1$$. Its range is $$[1, \\infty)$$, which is not $$\\mathbb{R}$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6225,
        "content": [
          "$$f(x)$$ = $$2x - 3x^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6226,
        "content": [
          "$$f(x)$$ = $$5x^3 + 1$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6227,
        "content": [
          "$$f(x)$$ = $$|x - 1|$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6228,
        "content": [
          "$$f(x)$$ = $$\\sqrt{x^2+1}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Polynomial Function"
  },
  {
    "id": 1557,
    "content": [
      "Let M be a matrix such that $$M = \\begin{pmatrix} 9 & 24 & 6 \\\\ -12 & 18 & 15 \\\\ 0 & 27 & 3 \\end{pmatrix}$$. Which one of the following matrices is equal to $$\\frac{2}{3}M$$?"
    ],
    "explanation": [
      "To find $$\\frac{2}{3}M$$, multiply each element of matrix M by the scalar $$\\frac{2}{3}$$.\n$$\n\\frac{2}{3}M = \\frac{2}{3} \\begin{pmatrix} 9 & 24 & 6 \\\\ -12 & 18 & 15 \\\\ 0 & 27 & 3 \\end{pmatrix}\n= \\begin{pmatrix}\n6 & 16 & 4 \\\\\n-8 & 12 & 10 \\\\\n0 & 18 & 2\n\\end{pmatrix}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6229,
        "content": [
          "$$\n\\begin{pmatrix} 6 & 16 & 2 \\\\ -8 & 12 & 10 \\\\ 0 & 18 & 2 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6230,
        "content": [
          "$$\n\\begin{pmatrix} 6 & 16 & 4 \\\\ -8 & 12 & 10 \\\\ 0 & 18 & 2 \\end{pmatrix}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6231,
        "content": [
          "$$\n\\begin{pmatrix} 3 & 8 & 2 \\\\ -4 & 6 & 5 \\\\ 0 & 9 & 1 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6232,
        "content": [
          "$$\n\\begin{pmatrix} 6 & 8 & 4 \\\\ -8 & 6 & 10 \\\\ 0 & 9 & 2 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Matrices"
  },
  {
    "id": 1558,
    "content": [
      "Consider that a data set given below:",
      "10, 8, 10, 2, 12, 6, 12, 18, 3, 7, 10, 8, 8",
      "Which one of the following is the coefficient of range of the data?"
    ],
    "explanation": [
      "First, identify the maximum (Max) and minimum (Min) values in the data set.\n- Max = 18\n- Min = 2\n\nThe Range is Max - Min = 18 - 2 = 16.\n\nThe coefficient of range (CR) is calculated as\n$$\nCR = \\frac{\\text{Max} - \\text{Min}}{\\text{Max} + \\text{Min}}\n$$\n$$\nCR = $$\\frac{18 - 2}{18 + 2} = \\frac{4}{5}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6233,
        "content": [
          "$$\\frac{5}{4}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6234,
        "content": [
          "$$20$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6235,
        "content": [
          "$$16$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6236,
        "content": [
          "$$\\frac{4}{5}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 1559,
    "content": [
      "Let $$r_1$$ and $$r_2$$ be the roots of a quadratic equation $$ax^2 + bx + c = 0$$, such that $$r_1 + r_2 = -2.5$$ and $$r_1 r_2 = 1.5$$, for a, b and c are real numbers and $$a \\ne 0$$. Which one of the following can be the values of a, b and c respectively?"
    ],
    "explanation": [
      "According to Vieta's formulas for a quadratic equation $$ax^2$$ + $$bx$$ + $$c$$ = $$0$$, the sum of the roots is $$r_1 + r_2$$ = $$-\\frac{b}{a}$$ and the product of the roots is $$r_1 r_2$$ = $$\\frac{c}{a}$$.\n\nWe are given $$r_1 + r_2$$ = $$-2.5$$ and $$r_1 r_2$$ = $$1.5$$.\n\nSo, $$-\\frac{b}{a}$$ = $$-2.5$$ = $$-\\frac{5}{2}$$ which implies $$\\frac{b}{a}$$ = $$\\frac{5}{2}$$\n\nAnd $$\\frac{c}{a}$$ = $$1.5$$ = $$\\frac{3}{2}$$\n\nWe need to find a set (a, b, c) that satisfies these ratios. Let's check the options:\n- a=1, b=6, c=5. $$\\frac{b}{a}$$ = $$\\frac{6}{1}$$ = $$6 \\ne \\frac{5}{2}$$\n- a=2, b=3, c=5. $$\\frac{b}{a}$$ = $$\\frac{3}{2}$$ $$\\ne \\frac{5}{2}$$\n- a=1, b=5, c=6. $$\\frac{b}{a}$$ = $$\\frac{5}{1}$$ = $$5 \\ne$$ $$\\frac{5}{2}$$\n- a=2, b=5, c=3. $$\\frac{b}{a}$$ = $$\\frac{5}{2}$$ (Correct). $$\\frac{c}{a}$$ = $$\\frac{3}{2}$$ (Correct).\n\nThus, the values a=2, b=5, and c=3 satisfy the conditions."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6237,
        "content": [
          "1, 6 and 5"
        ],
        "isCorrect": false
      },
      {
        "id": 6238,
        "content": [
          "2, 3 and 5"
        ],
        "isCorrect": false
      },
      {
        "id": 6239,
        "content": [
          "1, 5, and 6"
        ],
        "isCorrect": false
      },
      {
        "id": 6240,
        "content": [
          "2, 5 and 3"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 1560,
    "content": [
      "The following data gives the scores of 10 students in a Mathematics examination: 6, 10, 8, 5, 9, 8, 5, 10, 10, 9. Which one of the following is the standard deviation of the given data?"
    ],
    "explanation": [
      "First, calculate the mean ($$\\mu$$) of the data:\n$$\n\\mu = \\frac{6+10+8+5+9+8+5+10+10+9}{10} = 8\n$$\nNext, calculate the variance ($$\\sigma^2$$), which is the average of the squared differences from the mean:\n\nSquared differences: $$(6-8)^2=4$$, $$(10-8)^2=4$$, $$(8-8)^2=0$$, $$(5-8)^2=9$$, $$(9-8)^2=1$$, $$(8-8)^2=0$$, $$(5-8)^2=9$$, $$(10-8)^2=4$$, $$(10-8)^2=4$$, $$(9-8)^2=1$$\n\nSum of squared differences = 4+4+0+9+1+0+9+4+4+1 = 36\n\n$$\n\\sigma^2 = \\frac{\\text{Sum of squared differences}}{N} = \\frac{36}{10} = 3.6\n$$\nThe standard deviation ($$\\sigma$$) is the square root of the variance:\n$$\n\\sigma = \\sqrt{3.6}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6241,
        "content": [
          "$$3.6$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6242,
        "content": [
          "$$\\sqrt{3.6}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6243,
        "content": [
          "$$5.8$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6244,
        "content": [
          "$$\\sqrt{5.8}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 7,
    "unitName": "Statistics"
  },
  {
    "id": 1561,
    "content": [
      "Which of the following pairs of lines with the given equations are parallel?"
    ],
    "explanation": [
      "Two lines are parallel if they have the same slope. We find the slope (m) for each line by rewriting the equation in slope-intercept form (y = mx + c).\n- $$l_1: x-y+3=0$$ $$\\implies$$ $$y = x+3$$. Slope $$m_1 =1$$. $$l_2: -x+y-9=0$$ $$\\implies$$ $$y = x+9$$. Slope $$m_2 = 1$$. Since $$m_1 = m_2$$, the lines are parallel.\n- $$l_1: 4x-y=2$$ $$\\implies$$ $$y = 4x-2$$. Slope $$m_1 = 4$$. $$l_2: -x+4y-3=0$$ $$\\implies$$ $$y = \\frac{1}{4}x + \\frac{3}{4}$$. Slope $$m_2 = \\frac{1}{4}$$. Slopes are not equal.\n- $$l_1: 2x+3y=5$$ $$\\implies$$ $$y = -\\frac{2}{3}x + \\frac{5}{3}$$. Slope $$m_1 = -\\frac{2}{3}$$. $$l_2: 3x+2y=4$$ $$\\implies$$ $$y = -\\frac{3}{2}x + 2$$. Slope $$m_2 = -\\frac{3}{2}$$. Slopes are not equal.\n- $$l_1: x-2y+1=0$$ $$\\implies$$ $$y = \\frac{1}{2}x + \\frac{1}{2}$$. Slope $$m_1 = \\frac{1}{2}$$. $$l_2: x+2y-1=0$$ $$\\implies$$ $$\\implies$$ $$y = -\\frac{1}{2}x + \\frac{1}{2}$$. Slope $$m_2 = -\\frac{1}{2}$$. Slopes are not equal."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6245,
        "content": [
          "$$l_1: x-y+3=0$$ and $$l_2: -x+y-9=0$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6246,
        "content": [
          "$$l_1: 4x-y=2$$ and $$l_2: -x+4y-3=0$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6247,
        "content": [
          "$$l_1: 2x+3y=5$$ and $$l_2: 3x+2y=4$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6248,
        "content": [
          "$$l_1: x-2y+1=0$$ and $$l_2: x+2y-1=0$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1562,
    "content": [
      "Which one of the following is the range of the function $$f(x)$$ = $$\\frac{2x-1}{x+3}$$?"
    ],
    "explanation": [
      "To find the range of the rational function $$f(x)$$ = $$\\frac{2x-1}{x+3}$$, we look for the horizontal asymptote.\n\nSince the degree of the numerator (1) is equal to the degree of the denominator (1), the horizontal asymptote is given by the ratio of the leading coefficients, which is $$y$$ = $$\\frac{2}{1}$$ = $$2$$.\n\nThe function can take any real value except the value of the horizontal asymptote. Therefore, the range is all real numbers except 2, which is written as $$\\mathbb{R} \\setminus \\{2\\}$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6249,
        "content": [
          "$$\\mathbb{R} \\setminus \\{-3\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6250,
        "content": [
          "$$\\mathbb{R} \\setminus \\{2\\}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6251,
        "content": [
          "$$\\mathbb{R} \\setminus \\{-\\frac{1}{3}\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6252,
        "content": [
          "$$\\mathbb{R} \\setminus \\{\\frac{1}{2}\\}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1563,
    "content": [
      "Let $$z=-a+2i$$ and $$w=5-bi$$ be two complex numbers, where a and b are real numbers. If $$z=w$$, then which one of the following pairs of numbers are equal to a and b respectively?"
    ],
    "explanation": [
      "For two complex numbers to be equal, their real parts must be equal and their imaginary parts must be equal.\n\nGiven $$z = -a + 2i$$ and $$w = 5 - bi$$.\n\nEquating the real parts: $$-a = 5$$ $$\\implies$$ $$a = -5$$.\n\nEquating the imaginary parts: $$2 = -b$$ $$\\implies$$ $$b = -2$$.\n\nTherefore, a = -5 and b = -2."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6253,
        "content": [
          "5 and -2"
        ],
        "isCorrect": false
      },
      {
        "id": 6254,
        "content": [
          "-5 and -2"
        ],
        "isCorrect": true
      },
      {
        "id": 6255,
        "content": [
          "5 and 2"
        ],
        "isCorrect": false
      },
      {
        "id": 6256,
        "content": [
          "-5 and 2"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1564,
    "content": [
      "The following table presents the number of traffic accidents in a certain city per year for five consecutive years from 2019 to 2023.",
      "images/maths/year_2016_na/q48_1.png",
      "What is the average number of accidents per year for the given five years?"
    ],
    "explanation": [
      "To find the average number of accidents, sum the number of accidents for each year and divide by the number of years (5).\n\nTotal accidents = 3500 + 2750 + 2850 + 3500 + 3750 = 16350\n$$\n\\text{Average} = \\frac{16350}{5} = 3270\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2016_na/q48_1.png"
    ],
    "choices": [
      {
        "id": 6257,
        "content": [
          "3250"
        ],
        "isCorrect": false
      },
      {
        "id": 6258,
        "content": [
          "3270"
        ],
        "isCorrect": true
      },
      {
        "id": 6259,
        "content": [
          "3200"
        ],
        "isCorrect": false
      },
      {
        "id": 6260,
        "content": [
          "3210"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 1565,
    "content": [
      "Which one of the following is the solution set of the equation\n$$\n(\\sqrt{16})^{2x+1} = (\\sqrt[3]{4096})^{3x-5} \\ \\text{?}\n$$"
    ],
    "explanation": [
      "Simplify the bases of the exponential equation.\n$$\n\\sqrt{16} = 4\n$$\n$$\n4096 = 4^6\n$$\nSo, $$\\sqrt[3]{4096}$$ = $$\\sqrt[3]{4^6}$$ = $$(4^6)^{\\frac{1}{3}}$$ = $$4^{6/3}$$ = $$4^2$$\n\nSubstitute the simplified bases back into the equation:\n$$\n(4)^{2x+1} = (4^2)^{3x-5}\n$$\nApply the power rule $$(a^m)^n$$ = $$a^{mn}$$ to the right side:\n$$\n4^{2x+1} = 4^{2(3x-5)} = 4^{6x-10}\n$$\nSince the bases are equal, equate the exponents:\n$$\n2x + 1 = 6x - 10\n$$\nSolve for x:\n$$\nx = \\frac{11}{4}\n$$\nThe solution set is $$\\{\\frac{11}{4}\\}$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6261,
        "content": [
          "$$\\{\\frac{9}{4}\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6262,
        "content": [
          "$$\\{\\frac{9}{2}\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6263,
        "content": [
          "$$\\{\\frac{11}{2}\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6264,
        "content": [
          "$$\\{\\frac{11}{4}\\}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 1566,
    "content": [
      "Which one of the following is primary data?"
    ],
    "explanation": [
      "Primary data is data collected firsthand by the researcher for a specific purpose. Secondary data is data collected by someone else that the researcher uses.\n- A, B, and D describe data collected by other entities (Ministry of Health, journal authors, MOE). Using this existing data makes it secondary.\n- C describes data collected directly by the researcher (or their team) through measurement. This is primary data collection."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6265,
        "content": [
          "The data obtained from a chart prepared by Ministry of Health regarding the spread of HIV/AIDS."
        ],
        "isCorrect": false
      },
      {
        "id": 6266,
        "content": [
          "The data obtained by reading a journal regarding the opinion of the society about holidays."
        ],
        "isCorrect": false
      },
      {
        "id": 6267,
        "content": [
          "The data obtained by measuring the weights of students in a certain school."
        ],
        "isCorrect": true
      },
      {
        "id": 6268,
        "content": [
          "The data obtained from a document prepared by the MOE regarding the achievements of students in National Examination."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 1567,
    "content": [
      "Which one of the following ordered pairs of numbers gives the coordinates of the point that divides a line segment with end points A(1, 1) and B(-6, 8) in the ratio of 3:4?"
    ],
    "explanation": [
      "Use the section formula for internal division. If a point P(x, y) divides the line segment joining $$A(x_1, y_1)$$ and $$B(x_2, y_2)$$ in the ratio m:n, then the coordinates of P are given by:\n$$\nx = \\frac{mx_2 + nx_1}{m+n}\n$$\n$$\ny = \\frac{my_2 + ny_1}{m+n}\n$$\nHere, $$(x_1, y_1)$$ = $$(1, 1)$$, $$(x_2, y_2)$$ = $$(-6, 8)$$, $$m=3$$, and $$n=4$$\n$$\nx = \\frac{3(-6) + 4(1)}{3+4} = -2\n$$\n$$\ny = \\frac{3(8) + 4(1)}{3+4} = 4\n$$\nThe coordinates of the point are (-2, 4)"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6269,
        "content": [
          "(2, -4)"
        ],
        "isCorrect": false
      },
      {
        "id": 6270,
        "content": [
          "(-2, -4)"
        ],
        "isCorrect": false
      },
      {
        "id": 6271,
        "content": [
          "(2, 4)"
        ],
        "isCorrect": false
      },
      {
        "id": 6272,
        "content": [
          "(-2, 4)"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1568,
    "content": [
      "Which one of the following pairs of functions is an inverse of each other in their respective domains?"
    ],
    "explanation": [
      "To check if two functions f and g are inverses, we can find the inverse of f, denoted $$f^{-1}$$, and see if it equals g. Let $$y = f(x)$$. To find the inverse, swap x and y and solve for y.\n$$\ny = x^3-1\n$$\nSwap x and y:\n$$\nx = y^3-1\n$$\nSolve for y:\n$$\nx+1 = y^3 \\implies y = \\sqrt[3]{x+1}\n$$\nSo, $$f^{-1}(x)$$ = $$\\sqrt[3]{x+1}$$\n\nThis is equal to the given $$g(x)$$. Therefore, f and g are inverses of each other."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6273,
        "content": [
          "$$f(x)$$ = $$\\sqrt{x+3}$$ and $$g(x)$$ = $$x^2-9$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6274,
        "content": [
          "$$f(x)$$ = $$x^5$$ and $$g(x)$$ = $$\\frac{1}{x^5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6275,
        "content": [
          "$$f(x)$$ = $$x^3-1$$ and $$g(x)$$ = $$\\sqrt[3]{x+1}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6276,
        "content": [
          "$$f(x)$$ = $$\\frac{x+1}{x-1}$$ and $$g(x)$$ = $$\\frac{x-1}{x+1}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1569,
    "content": [
      "Which one of the following numbers is the determinant of the matrix\n$$\nM = \\begin{pmatrix} 1 & 2 & 3 \\\\ 4 & 5 & 6 \\\\ 7 & 8 & 10 \\end{pmatrix} \\ \\text{?}\n$$"
    ],
    "explanation": [
      "The determinant of a 3x3 matrix\n$$\n\\begin{pmatrix} a & b & c \\\\ d & e & f \\\\ g & h & i \\end{pmatrix}\n$$\nIs calculated as\n$$\na(ei-fh) - b(di-fg) + c(dh-eg)\n$$\nFor matrix M:\n\n$$det(M)$$ = $$1(5 \\times 10 - 6 \\times 8)$$ - $$2(4 \\times 10 - 6 \\times 7)$$ + $$3(4 \\times 8 - 5 \\times 7)$$\n\n$$det(M)$$ = $$2$$ + $$4$$ - $$9$$ = $$-3$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6277,
        "content": [
          "-3"
        ],
        "isCorrect": true
      },
      {
        "id": 6278,
        "content": [
          "6"
        ],
        "isCorrect": false
      },
      {
        "id": 6279,
        "content": [
          "-6"
        ],
        "isCorrect": false
      },
      {
        "id": 6280,
        "content": [
          "3"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Determinants and Their Properties"
  },
  {
    "id": 1570,
    "content": [
      "Which one of the following is a simple random sampling?"
    ],
    "explanation": [
      "Simple Random Sampling (SRS) is a method where each individual in the population has an equal and independent chance of being selected for the sample.\n- Option A describes Stratified Sampling.\n- Option B describes Multistage Sampling (likely involving cluster sampling first).\n- Option D describes Cluster Sampling (selecting entire groups).\n- Option C describes selecting individuals (students) randomly from a defined population (Grade 12 students of that school). This fits the definition of simple random sampling applied to that specific population frame."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6281,
        "content": [
          "First the population is divided into homogenous groups and a sample is selected from each homogenous group."
        ],
        "isCorrect": false
      },
      {
        "id": 6282,
        "content": [
          "First divide a city into ten groups and choose the secondary school principals from the randomly selected 3 groups."
        ],
        "isCorrect": false
      },
      {
        "id": 6283,
        "content": [
          "Selecting five students from grade 12 students of the same school randomly."
        ],
        "isCorrect": true
      },
      {
        "id": 6284,
        "content": [
          "Selecting a group randomly from groups formed by dividing the population into groups."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 1571,
    "content": [
      "Let A and B be two sets that contain 15 and 17 elements respectively. If $$A \\cap B$$ contains 10 elements, what is the number of elements in $$A \\cup B$$?"
    ],
    "explanation": [
      "We use the principle of inclusion-exclusion for two sets:\n$$\n|A \\cup B| = |A| + |B| - |A \\cap B|\n$$\nGiven $$|A| = 15$$, $$|B| = 17$$, and $$|A \\cap B| = 10$$\n$$\n|A \\cup B| = 15 + 17 - 10 = 32 - 10 = 22\n$$\nSo, the number of elements in $$A \\cup B$$ is 22"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SETS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6285,
        "content": [
          "22"
        ],
        "isCorrect": true
      },
      {
        "id": 6286,
        "content": [
          "12"
        ],
        "isCorrect": false
      },
      {
        "id": 6287,
        "content": [
          "42"
        ],
        "isCorrect": false
      },
      {
        "id": 6288,
        "content": [
          "32"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1572,
    "content": [
      "Which one of the following is the position vector of the vector with initial point A(1, -1) and terminal point B(2, -3)?"
    ],
    "explanation": [
      "The vector $$\\vec{AB}$$ is found by subtracting the coordinates of the initial point A from the coordinates of the terminal point B.\n$$\n\\vec{AB} = (x_B - x_A, y_B - y_A)\n$$\n$$\n= (2 - 1, -3 - (-1)) = (1, -2)\n$$\nThe position vector corresponding to the point (1, -2) is $$1i + (-2)j$$ = $$i - 2j$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_VECTORS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6289,
        "content": [
          "$$3i+4j$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6290,
        "content": [
          "$$i-4j$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6291,
        "content": [
          "$$3i-4j$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6292,
        "content": [
          "$$i-2j$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 8,
    "unitName": "Vectors in 2D"
  },
  {
    "id": 1573,
    "content": [
      "Let $$\\theta$$ be an angle in standard position and P(-3, 4) be a point on the terminal side of $$\\theta$$. Which one of the following is true about the corresponding trigonometric functions?"
    ],
    "explanation": [
      "For a point P(x, y) on the terminal side of an angle $$\\theta$$ in standard position, the distance from the origin to P is $$r$$ = $$\\sqrt{x^2 + y^2}$$.\n\nThe trigonometric functions are defined as $$\\cos \\theta$$ = $$\\frac{x}{r}$$ and $$\\sin \\theta$$ = $$\\frac{y}{r}$$\n\nGiven P(-3, 4), we have $$x = -3$$ and $$y = 4$$\n$$\nr = \\sqrt{(-3)^2 + 4^2} = 5\n$$\nTherefore, $$\\cos \\theta$$ = $$\\frac{x}{r}$$ = $$\\frac{-3}{5}$$ and $$\\sin \\theta$$ = $$\\frac{y}{r}$$ = $$\\frac{4}{5}$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6293,
        "content": [
          "$$\\cos \\theta$$ = $$-\\frac{3}{5}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6294,
        "content": [
          "$$\\sin \\theta$$ = $$-\\frac{4}{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6295,
        "content": [
          "$$\\sin \\theta$$ = $$\\frac{3}{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6296,
        "content": [
          "$$\\cos \\theta$$ = $$\\frac{4}{5}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Trigonometric Function"
  },
  {
    "id": 1574,
    "content": [
      "Which one of the following conic section is defined by \"the set of points in a plane such that the sum of the distances from two given points is constant\"?"
    ],
    "explanation": [
      "The definition provided is the standard definition of an ellipse. The two given fixed points are called the foci of the ellipse.\n\nFor a hyperbola, it is the absolute difference of the distances that is constant.\n\nFor a parabola, it is the distance to a fixed point (focus) and a fixed line (directrix) that are equal.\n\nFor a circle, it is the distance to a single fixed point (center) that is constant."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6297,
        "content": [
          "Ellipse"
        ],
        "isCorrect": true
      },
      {
        "id": 6298,
        "content": [
          "Hyperbola"
        ],
        "isCorrect": false
      },
      {
        "id": 6299,
        "content": [
          "Parabola"
        ],
        "isCorrect": false
      },
      {
        "id": 6300,
        "content": [
          "Circle"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1575,
    "content": [
      "If the fifth and the tenth terms of a geometric sequence are 640 and 20 respectively, then which of the following numbers are the first term and the common ratio of the given geometric sequence respectively?"
    ],
    "explanation": [
      "Let the first term be $$a_1$$ and the common ratio be $$r$$. The $$n^{th}$$ term of a geometric sequence is given by\n$$\na_n = a_1 r^{n-1}\n$$\nWe are given $$a_5$$ = $$640$$ and $$a_{10}$$ = $$20$$.\n$$\na_5 = a_1 r^{5-1} = a_1 r^4 = 640\n$$\n$$\na_{10} = a_1 r^{10-1} = a_1 r^9 = 20\n$$\nDivide the second equation by the first:\n$$\n\\frac{a_1 r^9}{a_1 r^4} = \\frac{20}{640}\n$$\n$$\nr^5 = \\frac{20}{640} = \\frac{1}{32}\n$$\nSince $$32$$ = $$2^5$$, we have $$r^5$$ = $$(\\frac{1}{2})^5$$. Therefore, the common ratio $$r$$ = $$\\frac{1}{2}$$.\n\nSubstitute $$r$$ = $$\\frac{1}{2}$$ into the equation for $$a_5$$:\n$$\na_1 (\\frac{1}{2})^4 = 640\n$$\n$$\na_1 (\\frac{1}{16}) = 640\n$$\n$$\na_1 = 640 \\times 16 = 10240\n$$\nThe first term is 10240 and the common ratio is $$\\frac{1}{2}$$."
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6301,
        "content": [
          "1024 and 2"
        ],
        "isCorrect": false
      },
      {
        "id": 6302,
        "content": [
          "1024 and $$\\frac{1}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6303,
        "content": [
          "10240 and 2"
        ],
        "isCorrect": false
      },
      {
        "id": 6304,
        "content": [
          "10240 and $$\\frac{1}{2}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1576,
    "content": [
      "Given that a graph of system of linear inequalities as shown below.",
      "images/maths/year_2016_na/q60_1_background.png",
      "Which one of the following system of linear inequalities is represented by the shaded region in the graph?"
    ],
    "explanation": [
      "The first line passes through the points (2, 0) and (0, 4).\n\nThe equation of this line is $$2x + y = 4$$. The shaded region is below this line, so the inequality is $$2x + y \\le 4$$.\n\nThe second line passes through the points (2, 0) and (0, -6). The equation of this line is $$3x - y = 6$$. The shaded region is above this line, so the inequality is $$3x - y \\ge 6$$.\n\nTherefore, the system of linear inequalities represented by the shaded region is:\n$$\n\\begin{cases}\n2x+y \\le 4 \\\\\n3x-y \\ge 6\n\\end{cases}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_INEQUALTIES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2016_na/q60_1_background.png"
    ],
    "choices": [
      {
        "id": 6305,
        "content": [
          "$$\n\\begin{cases}\n2x+y \\le 4 \\\\\n3x-y \\le 6\n\\end{cases}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6306,
        "content": [
          "$$\n\\begin{cases}\n2x+y \\ge 4 \\\\\n3x-y \\le 6\n\\end{cases}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6307,
        "content": [
          "$$\n\\begin{cases}\n2x+y \\ge 4 \\\\\n3x-y \\ge 6\n\\end{cases}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6308,
        "content": [
          "$$\n\\begin{cases}\n2x+y \\le 4 \\\\\n3x-y \\ge 6\n\\end{cases}\n$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Solving Inequality"
  },
  {
    "id": 1757,
    "content": [
      "What is the value of x that satisfies the equation $$5 \\left( \\frac{125}{8} \\right)^{\\frac{1}{3}x^2 - \\frac{2}{3}x}$$ = $$2$$?"
    ],
    "explanation": [
      "To solve the equation, first simplify the base $$\\frac{125}{8}$$ as $$\\left(\\frac{5}{2}\\right)^3$$.\n\nSubstitute this into the equation:\n$$\n5 \\left[ \\left(\\frac{5}{2}\\right)^3 \\right]^{\\frac{1}{3}x^2 - \\frac{2}{3}x} = 2\n$$\nUsing the power of a power rule $$(a^m)^n$$ = $$a^{mn}$$, simplify the exponent:\n$$\n3 \\left(\\frac{1}{3}x^2 - \\frac{2}{3}x\\right) = x^2 - 2x\n$$\nThe equation becomes\n$$\n5 \\left(\\frac{5}{2}\\right)^{x^2 - 2x} = 2\n$$\nDivide by 5:\n$$\n\\left(\\frac{5}{2}\\right)^{x^2 - 2x} = \\frac{2}{5}\n$$\nSince $$\\frac{2}{5}$$ = $$\\left(\\frac{5}{2}\\right)^{-1}$$, we have\n$$\n\\left(\\frac{5}{2}\\right)^{x^2 - 2x} = \\left(\\frac{5}{2}\\right)^{-1}\n$$\nEquating the exponents gives the quadratic equation $$x^2 - 2x$$ = $$-1$$, or $$x^2 - 2x + 1$$ = $$0$$.\n\nFactoring the quadratic yields $$(x - 1)^2 = 0$$, which has the solution $$x = 1$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7029,
        "content": [
          "$$1$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7030,
        "content": [
          "$$-\\frac{3}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7031,
        "content": [
          "$$\\frac{3}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7032,
        "content": [
          "$$4$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 1758,
    "content": [
      "The solution set of the inequality (2x - 3)(x + 5) ≤ 0 is"
    ],
    "explanation": [
      "To solve the inequality, first find the roots of the corresponding equation $$(2x - 3)(x + 5)$$ = $$0$$.\n\nThe roots are $$x$$ = $$\\frac{3}{2}$$ and $$x$$ = $$-5$$.\n\nThese roots divide the number line into three intervals: $$(-\\infty, -5)$$, $$(-5, \\frac{3}{2})$$, and $$(\\frac{3}{2}, \\infty)$$.\n\nWe test a value from each interval to see where the expression (2x - 3)(x + 5) is less than or equal to zero.\n- For x < -5 (e.g., x = -6), (2(-6) - 3)(-6 + 5) = (-15)(-1) = 15 > 0\n- For -5 < x < $$\\frac{3}{2}$$ (e.g., x = 0), (2(0) - 3)(0 + 5) = (-3)(5) = -15 < 0\n- For x > $$\\frac{3}{2}$$ (e.g., x = 2), (2(2) - 3)(2 + 5) = (1)(7) = 7 > 0\n\nThe inequality (2x - 3)(x + 5) ≤ 0 holds for the interval $$(-5, \\frac{3}{2})$$. Since the inequality includes equality (≤), the roots $$x = -5$$ and $$x = \\frac{3}{2}$$ are also part of the solution. Therefore, the solution set is $$[-5, \\frac{3}{2}]$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_INEQUALTIES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7033,
        "content": [
          "$$(-5, \\frac{3}{2})$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7034,
        "content": [
          "$$(-\\infty, -5] \\cup [\\frac{3}{2}, \\infty)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7035,
        "content": [
          "$$(-\\infty, -\\frac{3}{2}] \\cup [5, \\infty)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7036,
        "content": [
          "$$[-5, \\frac{3}{2}]$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Solving Inequality"
  },
  {
    "id": 1759,
    "content": [
      "The histogram below shows the recorded temperature (in °C) of a certain town in Ethiopia for the first 15 days of March 2023.",
      "images/maths/year_2015_na/q3_1.png",
      "Then which one of the following statement is true about the data represented by the histogram?"
    ],
    "explanation": [
      "Option A: The temperature was 24°C for two days.\n\n- Incorrect. The bar from 24–26°C spans 3 days, but that includes more than just 24°C.\n\nOption: B The mode of the data is 22°C.\n\n- Correct. The mode is the most frequent value. The bin 22–24°C has the highest frequency (5 days), so the mode is 22°C.\n\nOption C: The highest frequency is 3.\n\n- Incorrect. The highest frequency is 5.\n\nOption D: For 45% of the days, the temperature was more than 19°C.\n\n- Total days = 15\n- Days with temp > 19°C:\n    - 19–21°C: 2 days\n    - 21–22°C: 1 day\n    - 22–24°C: 5 days\n    - 24–26°C: 3 days\n- Total = 11 days → $$\\frac{11}{15} \\times 100\\%$$ = $$73.3\\%$$. Incorrect."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2015_na/q3_1.png"
    ],
    "choices": [
      {
        "id": 7037,
        "content": [
          "The temperature was 24°C for two days."
        ],
        "isCorrect": false
      },
      {
        "id": 7038,
        "content": [
          "The mode of the data is 22°C."
        ],
        "isCorrect": true
      },
      {
        "id": 7039,
        "content": [
          "The highest frequency is 3."
        ],
        "isCorrect": false
      },
      {
        "id": 7040,
        "content": [
          "For 45% of the days, the temperature was more than 19°C."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 1760,
    "content": [
      "A 20m high building casts a shadow of 4m, at the same time a 35m tree casts a shadow of x m. What is the value of x?"
    ],
    "explanation": [
      "At the same time, the ratio of an object's height to its shadow length is constant due to the sun's rays being parallel, forming similar triangles.\n\nWe can set up a proportion:\n$$\n\\frac{\\text{building height}}{\\text{building shadow}} = \\frac{\\text{tree height}}{\\text{tree shadow}}\n$$\nSubstituting the given values:\n$$\n\\frac{20}{4} = \\frac{35}{x}\n$$\nSimplifying the fraction:\n$$\n5x = 35 \\implies x = 7\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SIMILARITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7041,
        "content": [
          "8m"
        ],
        "isCorrect": false
      },
      {
        "id": 7042,
        "content": [
          "11m"
        ],
        "isCorrect": false
      },
      {
        "id": 7043,
        "content": [
          "7m"
        ],
        "isCorrect": true
      },
      {
        "id": 7044,
        "content": [
          "15m"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Congruency and Similarity"
  },
  {
    "id": 1761,
    "content": [
      "A car started moving 9km to the East then moved 4 km to the North and then 12km towards West to reach its destination. How far the car it travelled from its starting point?"
    ],
    "explanation": [
      "This question asks for the magnitude of the net displacement (the straight-line distance from start to finish).\n- Let the starting point be the origin (0,0).\n- Moving 9 km East results in coordinates (9, 0).\n- Moving 4 km North results in coordinates (9, 4).\n- Moving 12 km West subtracts 12 from the x-coordinate, resulting in final coordinates (9 - 12, 4) = (-3, 4).\n- The distance from the origin (0, 0) to the final point (-3, 4) is calculated using the distance formula (Pythagorean theorem):\n$$\nd = \\sqrt{(-3 - 0)^2 + (4 - 0)^2} = 5 \\ \\text{km}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_VECTORS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7045,
        "content": [
          "25km"
        ],
        "isCorrect": false
      },
      {
        "id": 7046,
        "content": [
          "12km"
        ],
        "isCorrect": false
      },
      {
        "id": 7047,
        "content": [
          "4km"
        ],
        "isCorrect": false
      },
      {
        "id": 7048,
        "content": [
          "5km"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 8,
    "unitName": "Vectors in 2D"
  },
  {
    "id": 1762,
    "content": [
      "When the polynomial $$p(x)$$ = $$3x^6$$ + $$5x^4$$ - $$7x^3$$ + $$2kx^2$$ + $$3$$ is divided by $$x + 1$$ the remainder is 4. What is the value of k?"
    ],
    "explanation": [
      "According to the Remainder Theorem, when a polynomial $$p(x)$$ is divided by $$(x - a)$$, the remainder is $$p(a)$$.\n\nIn this case, the divisor is $$x + 1$$ = $$x - (-1)$$, so $$a = -1$$. We are given that the remainder is 4. Therefore, $$p(-1) = 4$$.\n\nSubstitute $$x = -1$$ into the polynomial:\n$$\np(-1) = 3(-1)^6 + 5(-1)^4 - 7(-1)^3 + 2k(-1)^2 + 3\n$$\n$$\np(-1) = 18 + 2k\n$$\nSince the remainder is 4, we set $$p(-1) = 4$$:\n$$\n18 + 2k = 4\n$$\n$$\nk = -7\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7049,
        "content": [
          "-5"
        ],
        "isCorrect": false
      },
      {
        "id": 7050,
        "content": [
          "-7"
        ],
        "isCorrect": true
      },
      {
        "id": 7051,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 7052,
        "content": [
          "6"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Polynomial Function"
  },
  {
    "id": 1763,
    "content": [
      "The solution set of the equation $$5 \\log_9 x$$ - $$2 \\log_9 (x^2)$$ - $$\\log_4 8$$ = $$-1$$ is"
    ],
    "explanation": [
      "First, simplify the equation using logarithm properties. The domain requires $$x > 0$$.\n$$\n5 \\log_9 x = \\log_9 (x^5)\n$$\n$$\n2 \\log_9 (x^2) = \\log_9 ((x^2)^2) = \\log_9 (x^4)\n$$\n$$\n\\log_4 8 = \\log_{2^2} (2^3) = \\frac{3}{2} \\log_2 2 = \\frac{3}{2}\n$$\nSubstitute these back into the equation:\n$$\n\\log_9 (x^5) - \\log_9 (x^4) - \\frac{3}{2} = -1\n$$\nUse the quotient rule for logarithms: $$\\log_b M$$ - $$\\log_b N$$ = $$\\log_b \\left(\\frac{M}{N}\\right)$$\n$$\n\\log_9 \\left(\\frac{x^5}{x^4}\\right) - \\frac{3}{2} = -1\n$$\n$$\n\\log_9 x - \\frac{3}{2} = -1\n$$\n$$\n\\log_9 x = -1 + \\frac{3}{2}\n$$\n$$\n\\log_9 x = \\frac{1}{2}\n$$\nConvert the logarithmic equation to exponential form: $$x$$ = $$9^{\\frac{1}{2}}$$\n$$\nx = \\sqrt{9}\n$$\n$$\nx = 3\n$$\nSince $$x=3$$ is in the domain ($$x>0$$), the solution set is {3}."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7053,
        "content": [
          "$$\\{4\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7054,
        "content": [
          "$$\\{3\\}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7055,
        "content": [
          "$$\\{9\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7056,
        "content": [
          "{$$ \\frac{3}{2} $$}"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 1764,
    "content": [
      "Which of the following statement is true about $$f(x)$$ = $$x^2$$ - $$6x$$ + $$10$$?"
    ],
    "explanation": [
      "The function $$f(x)$$ = $$x^2$$ - $$6x$$ + $$10$$ is a quadratic function $$ax^2$$ + $$bx$$ + $$c$$ with $$a=1$$, $$b=-6$$, $$c=10$$.\n\nSince $$a=1 > 0$$, the parabola opens upward (eliminating C).\n\nThe axis of symmetry is given by the line $$x$$ = $$-\\frac{b}{2a}$$.\n$$\nx = -\\frac{-6}{2(1)} = \\frac{6}{2} = 3\n$$\nSo the axis of symmetry is $$x=3$$ (eliminating B).\n\nThe vertex occurs at the axis of symmetry. The y-coordinate of the vertex is $$f(3)$$.\n$$\nf(3) = (3)^2 - 6(3) + 10 = 1\n$$\nSo the vertex is (3, 1). This confirms D is true.\n\nSince the minimum value of the function is the y-coordinate of the vertex (which is 1), we have $$f(x) \\ge 1$$ for all x. Statement A, $$f(x) \\ge 2$$, is false because the minimum value is 1."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7057,
        "content": [
          "$$f(x) \\ge 2$$ for all x in the domain of f."
        ],
        "isCorrect": false
      },
      {
        "id": 7058,
        "content": [
          "The line $$x = 1$$ is the axis of symmetry of the graph of f."
        ],
        "isCorrect": false
      },
      {
        "id": 7059,
        "content": [
          "The graph of f opens downward."
        ],
        "isCorrect": false
      },
      {
        "id": 7060,
        "content": [
          "The vertex of the graph of f is (3, 1)."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Polynomial Function"
  },
  {
    "id": 1765,
    "content": [
      "What is the area of a regular hexagon inscribed in a circle of radius 6cm?"
    ],
    "explanation": [
      "A regular hexagon inscribed in a circle can be divided into 6 congruent equilateral triangles, with the center of the circle as a common vertex.\n\nThe side length of each equilateral triangle is equal to the radius of the circle.\n\nGiven radius $$r = 6$$ cm. The side length of the hexagon (and each equilateral triangle) is $$s = 6$$ cm.\n\nThe area of one equilateral triangle with side s is given by the formula\n$$\nA_{triangle} = \\frac{\\sqrt{3}}{4} s^2\n$$\n$$\nA_{triangle} = \\frac{\\sqrt{3}}{4} (6)^2 = 9\\sqrt{3} \\text{ cm}^2\n$$\nThe area of the hexagon is 6 times the area of one equilateral triangle.\n$$\nA_{hexagon} = 6 \\times A_{triangle}\n$$\n$$\nA_{hexagon} = 6 \\times 9\\sqrt{3} = 54\\sqrt{3} \\text{ cm}^2\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7061,
        "content": [
          "$$48\\sqrt{3} \\text{ cm}^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7062,
        "content": [
          "$$54\\sqrt{3} \\text{ cm}^2$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7063,
        "content": [
          "$$48 \\text{ cm}^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7064,
        "content": [
          "$$36\\sqrt{3} \\text{ cm}^2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1766,
    "content": [
      "Which of the following defines a prime number?"
    ],
    "explanation": [
      "A prime number is defined as a natural number greater than 1 that has exactly two distinct positive divisors: 1 and itself."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_NUMBER_SYSTEM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7065,
        "content": [
          "It is a number that has more than two positive factors."
        ],
        "isCorrect": false
      },
      {
        "id": 7066,
        "content": [
          "It is a number whose only factor is 1."
        ],
        "isCorrect": false
      },
      {
        "id": 7067,
        "content": [
          "It is a number that has only two positive factors."
        ],
        "isCorrect": true
      },
      {
        "id": 7068,
        "content": [
          "It is a number whose only factor is itself."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "The Number System"
  },
  {
    "id": 1767,
    "content": [
      "Which of the following rational numbers is written in its standard form?"
    ],
    "explanation": [
      "Standard form (or scientific notation) requires a number to be written as $$a \\times 10^n$$, where $$1 \\le |a| < 10$$ and n is an integer.\n\n5 is greater than or equal to 1 and less than 10. Thus, $$5 \\times 10^5$$ is in standard form."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_NUMBER_SYSTEM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7069,
        "content": [
          "$$10.1 \\times 10^{-2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7070,
        "content": [
          "$$0.8 \\times 10^{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7071,
        "content": [
          "$$0.09 \\times 10^{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7072,
        "content": [
          "$$5 \\times 10^{5}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "The Number System"
  },
  {
    "id": 1768,
    "content": [
      "What is the value of x in the equation $$\\sqrt{125^x \\cdot 5^{2x-1}}$$ = $$25^{3x+1}$$?"
    ],
    "explanation": [
      "To solve the equation, express all bases as powers of 5: $$125 = 5^3$$ and $$25 = 5^2$$.\nThe equation becomes:\n$$\n\\sqrt{(5^3)^x \\cdot 5^{2x-1}} = (5^2)^{3x+1}\n$$\nSimplify using exponent rules:\n$$\n\\sqrt{5^{3x} \\cdot 5^{2x-1}} = 5^{2(3x+1)}\n$$\n$$\n\\sqrt{5^{3x + 2x - 1}} = 5^{6x+2}\n$$\n$$\n\\sqrt{5^{5x-1}} = 5^{6x+2}\n$$\nWrite the square root as a fractional exponent:\n$$\n(5^{5x-1})^{1/2} = 5^{6x+2}\n$$\n$$\n5^{\\frac{5x-1}{2}} = 5^{6x+2}\n$$\nEquate the exponents:\n$$\n\\frac{5x-1}{2} = 6x+2\n$$\n$$\nx = -\\frac{5}{7}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7073,
        "content": [
          "$$-5$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7074,
        "content": [
          "$$-\\frac{5}{7}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7075,
        "content": [
          "$$5$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7076,
        "content": [
          "$$\\frac{5}{7}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 1769,
    "content": [
      "The solution set of the equation 3|2x - 4| = 6 - 2|1 - 5x| is"
    ],
    "explanation": [
      "Simplify the equation:\n$$\n3 \\cdot 2 |x-2| = 6 - 2|5x-1|\n$$\n$$\n6|x-2| = 6 - 2|5x-1|\n$$\n$$\n3|x-2| + |5x-1| = 3\n$$\nWe solve this by considering intervals based on the points where the expressions inside the absolute values are zero: $$x-2=0$$ $$\\implies$$ $$x=2$$ and $$5x-1=0$$ $$\\implies$$ $$x=1/5$$.\n\nCase 1: $$x < 1/5$$. Both $$x-2$$ and $$5x-1$$ are negative.\n$$\n3(-(x-2)) + (-(5x-1)) = 3\n$$\n$$\n-3x+6 - 5x+1 = 3\n$$\n$$\n-8x+7 = 3 \\implies x = 1/2\n$$\nThis solution $$x=1/2$$ is not in the interval $$x < 1/5$$, so it's extraneous.\n\nCase 2: $$1/5 \\le x < 2$$. $$x-2$$ is negative, $$5x-1$$ is non-negative.\n$$\n3(-(x-2)) + (5x-1) = 3\n$$\n$$\n-3x+6 + 5x-1 = 3\n$$\n$$\n2x+5 = 3 \\implies x = -1\n$$\nThis solution $$x=-1$$ is not in the interval $$[1/5, 2)$$, so it's extraneous.\n\nCase 3: $$x \\ge 2$$. Both $$x-2$$ and $$5x-1$$ are non-negative.\n$$\n3(x-2) + (5x-1) = 3\n$$\n$$\n3x-6 + 5x-1 = 3\n$$\n$$\n8x-7 = 3 \\implies x = 5/4\n$$\nThis solution $$x=5/4$$ is not in the interval $$x \\ge 2$$, so it's extraneous.\n\nSince none of the cases yield a valid solution, the solution set is the empty set, $$\\{\\}$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7077,
        "content": [
          "$$\\{\\frac{1}{2}, \\frac{5}{4}\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7078,
        "content": [
          "$$\\{-1, \\frac{1}{2}, \\frac{5}{4}\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7079,
        "content": [
          "$$\\{\\}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7080,
        "content": [
          "$$\\{-1, \\frac{1}{2}\\}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 1770,
    "content": [
      "Given $$A$$ = $$\\{x \\in \\mathbb{N}: x < 3\\}$$ and B is the set of all possible factors of 13. Then which one of the following is equal to $$B \\times A$$?"
    ],
    "explanation": [
      "First, determine the elements of sets A and B.\n\nSet A contains natural numbers less than 3. $$\\mathbb{N} = \\{1, 2, 3, ...\\}$$, $$A = \\{1, 2\\}$$.\n\nSet B contains all factors of 13. Since 13 is prime, its factors are 1 and 13. $$B = \\{1, 13\\}$$.\n\nThe Cartesian product $$B \\times A$$ is the set of all ordered pairs $$(b, a)$$ where $$b \\in B$$ and $$a \\in A$$.\n$$\nB \\times A = \\{(1, 1), (1, 2), (13, 1), (13, 2)\\}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SETS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7081,
        "content": [
          "$$\n\\{(1, 1), (2, 1), (1, 13), (2, 13)\\}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7082,
        "content": [
          "$$\n\\{(1, 1), (1, 2), (13, 1), (13, 2)\\}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7083,
        "content": [
          "$$\n\\{(1, 1), (13, 2)\\}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7084,
        "content": [
          "$$\n\\{(1, 2), (13, 1), (13, 2)\\}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1771,
    "content": [
      "The object shown in the figure below is made of wood. Its top cover is a solid hemisphere and its bottom is a cylinder of base diameter 6cm and height of 12cm. From the bottom of the cylindrical part a right circular cone of height 8cm is cut off.",
      "images/maths/year_2015_na/q15_1_background.png",
      "Thus, what is the volume of the solid in cubic centimeters?"
    ],
    "explanation": [
      "The volume of the solid is the volume of the cylinder plus the volume of the hemisphere minus the volume of the cone.\n\nCylinder: Diameter = 6cm, so radius r=3cm. Height=12 cm.\n$$\nV_{cyl} = \\pi r^2 h_{cyl} = \\pi (3^2)(12) = 108\\pi \\ \\text{cm}^3\n$$\nHemisphere: Radius r=3cm.\n$$\nV_{hemi} = \\frac{2}{3} \\pi r^3 = \\frac{2}{3} \\pi (3^3) = 18\\pi \\ \\text{cm}^3\n$$\nCone: Radius r=3cm. Height=8cm.\n$$\nV_{cone} = \\frac{1}{3} \\pi r^2 h_{cone} = \\frac{1}{3} \\pi (3^2)(8) = 24\\pi \\ \\text{cm}^3\n$$\nTotal Volume\n$$\nV = V_{cyl} + V_{hemi} - V_{cone}\n$$\n$$\nV = 108\\pi + 18\\pi - 24\\pi = 102\\pi \\ \\text{cm}^3\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2015_na/q15_1_background.png"
    ],
    "choices": [
      {
        "id": 7085,
        "content": [
          "$$102 \\pi$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7086,
        "content": [
          "$$72 \\pi$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7087,
        "content": [
          "$$96 \\pi$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7088,
        "content": [
          "$$126 \\pi$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1772,
    "content": [
      "The domain of the function $$f(x) = 2x^{\\frac{2}{3}}$$"
    ],
    "explanation": [
      "The function is $$f(x) = 2x^{2/3}$$, which can be rewritten as $$f(x) = 2 \\sqrt[3]{x^2}$$.\n\nTo find the domain, we identify values of x for which the function is defined. The expression $$x^2$$ is defined for all real numbers x.\n\nThe cube root function, $$\\sqrt[3]{y}$$, is defined for all real numbers y (including negative numbers, zero, and positive numbers).\n\nSince $$x^2$$ produces non-negative results, and the cube root is defined for all real numbers, the function $$f(x)$$ is defined for all real numbers x. Therefore, the domain is $$\\mathbb{R}$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7089,
        "content": [
          "$$\\mathbb{R}\\setminus\\{0\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7090,
        "content": [
          "$$[0, \\infty)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7091,
        "content": [
          "$$\\mathbb{R}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7092,
        "content": [
          "$$(0, 2)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1773,
    "content": [
      "The slope of the line that makes an angle of $$135^\\circ$$ with the positive x-axis is equal to"
    ],
    "explanation": [
      "The slope (m) of a line is given by the tangent of the angle ($$\\theta$$) it makes with the positive x-axis:\n$$m = \\tan(\\theta)$$. Given $$\\theta = 135^\\circ$$.\n\n$$m = \\tan(135^\\circ)$$\n\nSince $$135^\\circ$$ is in the second quadrant, we can use the reference angle $$180^\\circ - 135^\\circ$$ = $$45^\\circ$$.\n\nThe tangent function is negative in the second quadrant.\n$$\nm = \\tan(135^\\circ) = -\\tan(45^\\circ) = -1\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7093,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 7094,
        "content": [
          "-1"
        ],
        "isCorrect": true
      },
      {
        "id": 7095,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 7096,
        "content": [
          "$$\\frac{1}{3}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1774,
    "content": [
      "If $$\\tan 31^\\circ$$ = $$0.81$$ then what is the value of $$\\tan 509^\\circ$$?"
    ],
    "explanation": [
      "The tangent function has a period of $$180^\\circ$$, which means $$\\tan(\\theta + n \\cdot 180^\\circ)$$ = $$\\tan(\\theta)$$ for any integer n. We need to find $$\\tan(509^\\circ)$$.\n\nFirst, find an angle coterminal with $$509^\\circ$$ within the first cycle or relate it to $$31^\\circ$$.\n\n$$509^\\circ$$ = $$2 \\times 180^\\circ$$ + $$149^\\circ$$ = $$360^\\circ + 149^\\circ$$.\n\nSo, $$\\tan(509^\\circ)$$ = $$\\tan(149^\\circ)$$.\n\nNow, relate $$149^\\circ$$ to the given angle $$31^\\circ$$.\n\nNote that $$149^\\circ$$ = $$180^\\circ$$ - $$31^\\circ$$.\n\nUsing the identity $$\\tan(180^\\circ - \\alpha)$$ = $$-\\tan(\\alpha)$$, we have:\n$$\n\\tan(149^\\circ) = \\tan(180^\\circ - 31^\\circ) = -\\tan(31^\\circ)\n$$\nGiven $$\\tan(31^\\circ)$$ = $$0.81$$,\n$$\n\\tan(509^\\circ) = -\\tan(31^\\circ) = -0.81\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7097,
        "content": [
          "0.19"
        ],
        "isCorrect": false
      },
      {
        "id": 7098,
        "content": [
          "-0.81"
        ],
        "isCorrect": true
      },
      {
        "id": 7099,
        "content": [
          "0.81"
        ],
        "isCorrect": false
      },
      {
        "id": 7100,
        "content": [
          "-0.91"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Trigonometric Function"
  },
  {
    "id": 1775,
    "content": [
      "If $$sin \\theta$$ = $$-\\frac{3}{5}$$ and $$\\theta$$ is a $$4^{th}$$ quadrant angle, then what is the value of $$sec \\theta$$?"
    ],
    "explanation": [
      "Given $$sin \\theta = -3/5$$ and $$\\theta$$ is in the 4th quadrant. We use the identity\n$$\nsin^2 \\theta + cos^2 \\theta = 1\n$$\nSubstituting the value of $$sin \\theta$$, we get\n$$\n(-\\frac{3}{5})^2 + cos^2 \\theta = 1\n$$\n$$\n\\frac{9}{25} + cos^2 \\theta = 1\n$$\n$$\ncos^2 \\theta = 1 - \\frac{9}{25} = \\frac{16}{25}\n$$\n$$\ncos \\theta = \\pm \\sqrt{\\frac{16}{25}} = \\pm \\frac{4}{5}\n$$\nSince $$\\theta$$ is in the 4th quadrant, the cosine value is positive. Thus\n$$\ncos \\theta = \\frac{4}{5}\n$$\nThe secant function is the reciprocal of the cosine function, so\n$$\nsec \\theta = \\frac{1}{cos \\theta} = \\frac{1}{4/5} = \\frac{5}{4}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7101,
        "content": [
          "$$-\\frac{5}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7102,
        "content": [
          "$$\\frac{5}{4}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7103,
        "content": [
          "$$\\frac{5}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7104,
        "content": [
          "$$-\\frac{5}{4}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 5,
    "unitName": "Introduction to Trigonometry"
  },
  {
    "id": 1776,
    "content": [
      "If ABCD is a parallelogram with P a mid-point of $$\\overline{AB}$$ and Q a mid-point of $$\\overline{CD}$$. Then which of the following is **NOT** necessarily true?"
    ],
    "explanation": [
      "Since ABCD is a parallelogram, AB is parallel and equal to CD. Since P and Q are midpoints of AB and CD respectively, AP = AB/2 and CQ = CD/2. Thus, AP = CQ.\n\nAlso, since AB || CD, AP || CQ. A quadrilateral (APCQ) with one pair of opposite sides being parallel and equal is a parallelogram. Therefore, APCQ is always a parallelogram, and its opposite sides are equal, meaning AQ = PC. Option B is true.\n\nFor option A, AD = BC (opposite sides of parallelogram ABCD), DQ = CD/2 = AB/2 = BP, and $$\\angle ADQ = \\angle CBP$$ (alternate interior angles if we extend AD and BC to intersect lines AB and CD, or simply opposite angles of the parallelogram $$\\angle D = \\angle B$$). By SAS congruence (or SSS if needed), $$\\triangle ADQ \\cong \\triangle CBP$$ is true.\n\nFor option C, AP is part of AB, and AB || CD. Hence AP || CD. A trapezium requires at least one pair of parallel sides, so APCD is a trapezium.\n\nOption D states APCQ is a rhombus. A rhombus is a parallelogram with all sides equal. While APCQ is a parallelogram (AP=CQ and AQ=PC), it is not necessarily true that adjacent sides are equal (e.g., AP = AQ). This would only hold for specific parallelograms. Thus, APCQ is not necessarily a rhombus."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_POLYGONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7105,
        "content": [
          "$$\\triangle ADQ \\cong \\triangle CBP$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7106,
        "content": [
          "$$\\overline{AQ} \\cong \\overline{PC}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7107,
        "content": [
          "APCD is a trapezium."
        ],
        "isCorrect": false
      },
      {
        "id": 7108,
        "content": [
          "APCQ is a rhombus."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Regular Polygon"
  },
  {
    "id": 1777,
    "content": [
      "A regular pyramid has a hexagonal base whose side length is 12cm. What is the lateral surface area of the pyramid in square centimeters if the length of each lateral edge is 10cm?"
    ],
    "explanation": [
      "The lateral surface area of the pyramid consists of 6 identical isosceles triangles. Each triangle has a base equal to the side length of the hexagon (12 cm) and two equal sides corresponding to the lateral edges (10 cm).\n\nTo find the area of one such triangle, we first need its height (also known as the slant height of the pyramid face).\n\nLet's consider one triangle with sides 10 cm, 10 cm, and 12 cm.\n\nThe height to the base of 12 cm divides the triangle into two right-angled triangles with hypotenuse 10 cm and one leg 12/2 = 6 cm.\n\nUsing the Pythagorean theorem, the height\n$$\nh = \\sqrt{10^2 - 6^2} = \\sqrt{64} = 8 \\ \\text{cm}\n$$\nThe area of one lateral triangle is\n$$\n\\frac{1}{2} \\times b \\times h = \\frac{1}{2} \\times 12 \\times 8 = 48 \\ \\text{cm}^2\n$$\nSince there are 6 such congruent triangles forming the lateral surface, the total lateral surface area is\n$$\n6 \\times 48 = 288 \\ \\text{cm}^2\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7109,
        "content": [
          "360"
        ],
        "isCorrect": false
      },
      {
        "id": 7110,
        "content": [
          "72"
        ],
        "isCorrect": false
      },
      {
        "id": 7111,
        "content": [
          "288"
        ],
        "isCorrect": true
      },
      {
        "id": 7112,
        "content": [
          "720"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1778,
    "content": [
      "If $$\\begin{pmatrix} 2 & -1 \\\\ a & 4 \\end{pmatrix}$$ $$\\begin{pmatrix} 1 & b \\\\ -1 & 3 \\end{pmatrix}$$ = $$\\begin{pmatrix} 3 & 1 \\\\ -1 & 18 \\end{pmatrix}$$. Then what are the values of a and b respectively?"
    ],
    "explanation": [
      "Perform the matrix multiplication on the left-hand side:\n$$\n\\begin{pmatrix} 2 & -1 \\\\ a & 4 \\end{pmatrix} \\begin{pmatrix} 1 & b \\\\ -1 & 3 \\end{pmatrix}\n$$\n$$\n\\begin{pmatrix} (2)(1) + (-1)(-1) & (2)(b) + (-1)(3) \\\\ (a)(1) + (4)(-1) & (a)(b) + (4)(3) \\end{pmatrix}\n$$\n$$\n\\begin{pmatrix} 2+1 & 2b-3 \\\\ a-4 & ab+12 \\end{pmatrix}\n$$\n$$\n\\begin{pmatrix} 3 & 2b-3 \\\\ a-4 & ab+12 \\end{pmatrix}\n$$\nEquate this result to the matrix on the right-hand side:\n$$\n\\begin{pmatrix} 3 & 2b-3 \\\\ a-4 & ab+12 \\end{pmatrix}= \\begin{pmatrix} 3 & 1 \\\\ -1 & 18 \\end{pmatrix}\n$$\nEquating the corresponding elements gives a system of equations:\n- $$3 = 3$$ (Top-left)\n- $$2b - 3 = 1$$ (Top-right) $$\\implies 2b = 4 \\implies b = 2$$\n- $$a - 4 = -1$$ (Bottom-left) $$\\implies a = -1 + 4 \\implies a = 3$$\n- $$ab + 12 = 18$$ (Bottom-right) Check: $$(3)(2) + 12 = 6 + 12$$ = $$18$$. This confirms the values.\n\nTherefore, $$a = 3$$ and $$b = 2$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7113,
        "content": [
          "3, 2"
        ],
        "isCorrect": true
      },
      {
        "id": 7114,
        "content": [
          "2, -2"
        ],
        "isCorrect": false
      },
      {
        "id": 7115,
        "content": [
          "-1, 2"
        ],
        "isCorrect": false
      },
      {
        "id": 7116,
        "content": [
          "0, -1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Matrices"
  },
  {
    "id": 1779,
    "content": [
      "Let $$A$$ = $$\\begin{pmatrix} 1 & -1 \\\\ 0 & 2 \\\\ -3 & 6 \\end{pmatrix}$$. Then $$A^T$$ is"
    ],
    "explanation": [
      "The transpose of a matrix $$A$$, denoted as $$A^T$$, is obtained by interchanging its rows and columns.\n\nFor the given matrix $$A$$ = $$\\begin{pmatrix} 1 & -1 \\\\ 0 & 2 \\\\ -3 & 6 \\end{pmatrix}$$, the first row (1, -1) becomes the first column, the second row (0, 2) becomes the second column, and the third row (-3, 6) becomes the third column of $$A^T$$.\n\nThus, $$A^T$$ = $$\\begin{pmatrix} 1 & 0 & -3 \\\\ -1 & 2 & 6 \\end{pmatrix}$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7117,
        "content": [
          "$$\n\\begin{pmatrix} 1 & 0 & -3 \\\\ -1 & 2 & 6 \\end{pmatrix}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7118,
        "content": [
          "$$\n\\begin{pmatrix} 1 & 0 \\\\ -1 & 2 \\\\ -3 & 6 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7119,
        "content": [
          "$$\n\\begin{pmatrix} -1 & 2 & 6 \\\\ 1 & 0 & -3 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7120,
        "content": [
          "$$\n\\begin{pmatrix} -1 & 1 \\\\ 2 & 0 \\\\ 6 & -3 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Matrices"
  },
  {
    "id": 1780,
    "content": [
      "On the set of Natural numbers $$\\mathbb{N}$$, which one of the following propositions has a truth value True?"
    ],
    "explanation": [
      "We need to check the truth value of each proposition on the set of natural numbers $$\\mathbb{N}$$ = $$\\{1, 2, 3, ...\\}$$.\n\n$$(\\exists x)(\\exists y)(x - y = y - x)$$: This equation simplifies to $$x - y = -(x - y)$$, which implies $$2(x - y) = 0$$, or $$x = y$$. Since there exist natural numbers x and y such that $$x = y$$ (for example, let $$x = 1$$ and $$y = 1$$), this proposition is True.\n\n$$(\\forall x)(\\forall y)(x \\neq y \\Rightarrow x > y)$$: This states that for any two distinct natural numbers, the first is always greater than the second. This is false. Consider $$x = 2$$ and $$y = 3$$. Here $$x \\neq y$$, but $$x < y$$.\n\n$$(\\forall x)(\\exists y)(x - y = 5)$$: This states that for every natural number x, there exists a natural number y such that $$y = x - 5$$. If we take $$x = 1$$, then $$y = 1 - 5 = -4$$, which is not a natural number. So, this proposition is False.\n\n$$(\\forall x)(\\exists y)(xy < x)$$: This states that for every natural number x, there exists a natural number y such that $$xy < x$$. Since x is a natural number, $$x > 0$$. Dividing the inequality by x gives $$y < 1$$. There is no natural number y that is less than 1. So, this proposition is False.\nTherefore, only proposition (A) is True."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7121,
        "content": [
          "$$\n(\\exists x)(\\exists y)(x - y = y - x)\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7122,
        "content": [
          "$$\n(\\forall x)(\\forall y)(x \\neq y \\Rightarrow x > y)\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7123,
        "content": [
          "$$\n(\\forall x)(\\exists y)(x - y = 5)\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7124,
        "content": [
          "$$\n(\\forall x)(\\exists y)(xy < x)\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1781,
    "content": [
      "In a certain month of the year, the temperature of a city was recorded and presented as follows.",
      "images/maths/year_2015_na/q25_1.png",
      "Which one of the following is the cumulative frequency of the fourth class?"
    ],
    "explanation": [
      "The cumulative frequency of a class is the sum of the frequencies of that class and all preceding classes.\n\nThe classes are: 10-14 (1st), 15-19 (2nd), 20-24 (3rd), 25-29 (4th), and 30-34 (5th). The fourth class is 25-29.\n\nTo find its cumulative frequency, we sum the frequencies of the first four classes: 2 + 9 + 11 + 5 = 27"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2015_na/q25_1.png"
    ],
    "choices": [
      {
        "id": 7126,
        "content": [
          "22"
        ],
        "isCorrect": false
      },
      {
        "id": 7127,
        "content": [
          "27"
        ],
        "isCorrect": true
      },
      {
        "id": 7128,
        "content": [
          "18"
        ],
        "isCorrect": false
      },
      {
        "id": 7129,
        "content": [
          "20"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 1782,
    "content": [
      "A fair die is going to be rolled once, and let;",
      "$$E_1$$ be the event that an even number occurs",
      "$$E_2$$ be the event that a prime number occurs",
      "$$E_3$$ be the event that a multiple of 3 occurs",
      "$$E_4$$ be the event that a multiple of 5 occurs",
      "Then which of the following pairs of events are mutually exclusive?"
    ],
    "explanation": [
      "Two events are mutually exclusive if they cannot happen at the same time, meaning their intersection is the empty set. The possible outcomes when rolling a fair die are S = {1, 2, 3, 4, 5, 6}.\nThe events are:\n- $$E_1$$ = {2, 4, 6} (even numbers)\n- $$E_2$$ = {2, 3, 5} (prime numbers\n- $$E_3$$ = {3, 6} (multiples of 3)\n- $$E_4$$ = {5} (multiples of 5)\n\nWe check the intersections for the given pairs:\n\n- $$E_1 \\cap E_3$$ = {6}. Not mutually exclusive.\n- $$E_3 \\cap E_4$$ = $$\\emptyset$$. Mutually exclusive.\n- $$E_1 \\cap E_2$$ = {2}. Not mutually exclusive.\n- $$E_2 \\cap E_4$$ = {5}. Not mutually exclusive.\n\nTherefore, the pair $$E_3$$ and $$E_4$$ are mutually exclusive because there is no outcome that is both a multiple of 3 and a multiple of 5 in the set {1, 2, 3, 4, 5, 6}."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_PROBABILITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7130,
        "content": [
          "$$E_1$$ and $$E_3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7131,
        "content": [
          "$$E_3$$ and $$E_4$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7132,
        "content": [
          "$$E_1$$ and $$E_2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7133,
        "content": [
          "$$E_2$$ and $$E_4$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 8,
    "unitName": "Probability"
  },
  {
    "id": 1783,
    "content": [
      "The following is the distribution of the weight of 40 students in a certain class.",
      "images/maths/year_2015_na/q27_1.png",
      "Then for data given above, what is the median weigh in kg?"
    ],
    "explanation": [
      "To find the median weight, we first calculate the cumulative frequencies (cf) and determine the median class. Total frequency N = 40.\n\n| Class | f | cf | Class Boundaries |\n| --- | --- | --- | --- |\n| 40-48 | 8 | 8 | 39.5 - 48.5 |\n| 49-57 | 18 | 8 + 18 = 26 | 48.5 - 57.5 |\n| 58-66 | 7 | 26 + 7 = 33 | 57.5 - 66.5 |\n| 67-75 | 5 | 33 + 5 = 38 | 66.5 - 75.5 |\n| 76-84 | 2 | 38 + 2 = 40 | 75.5 - 84.5 |\n\nThe median position is $$N/2 = 40/2 = 20$$. The cumulative frequency just greater than 20 is 26, which corresponds to the class 49-57. This is the median class.\n\nThe median formula for grouped data is:\n$$\nM = L + \\frac{\\frac{N}{2} - cf_p}{f_m} \\times h\n$$\nWhere:\n\n- L = Lower class boundary of the median class = 48.5\n- N = Total frequency = 40\n- $$cf_p$$ = Cumulative frequency of the class preceding the median class = 8\n- $$f_m$$ = Frequency of the median class = 18\n- h = Class width = 57.5 - 48.5 = 9\n\n$$\nM = 48.5 + \\frac{20 - 8}{18} \\times 9\n$$\n$$\nM = 48.5 + \\frac{12}{18} \\times 9\n$$\n$$\nM = 54.5\n$$\nThe median weight is 54.5 kg."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2015_na/q27_1.png"
    ],
    "choices": [
      {
        "id": 7134,
        "content": [
          "54.5"
        ],
        "isCorrect": true
      },
      {
        "id": 7135,
        "content": [
          "55"
        ],
        "isCorrect": false
      },
      {
        "id": 7136,
        "content": [
          "53"
        ],
        "isCorrect": false
      },
      {
        "id": 7137,
        "content": [
          "53.8"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 1784,
    "content": [
      "A group of students, 5 from grade 10, 8 from grade 11 and 2 from grade 12 is to be formed. If a student is chosen randomly from this group, what is the probability that the chosen student is either from grade 10 or grade 12?"
    ],
    "explanation": [
      "First, find the total number of students in the group. Total students = (students from grade 10) + (students from grade 11) + (students from grade 12) = 5 + 8 + 2 = 15\n\nNext, find the number of students who are from either grade 10 or grade 12. Number of students (grade 10 or grade 12) = (students from grade 10) + (students from grade 12) = 5 + 2 = 7\n\nThe probability of choosing a student from either grade 10 or grade 12 is the ratio of the number of students from grade 10 or 12 to the total number of students.\n$$\n\\frac{\\text{Number of students from grade 10 or 12}}{\\text{Total number of students}} = \\frac{7}{15}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_PROBABILITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7138,
        "content": [
          "$$\\frac{7}{15}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7139,
        "content": [
          "$$\\frac{5}{15}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7140,
        "content": [
          "$$\\frac{12}{15}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7141,
        "content": [
          "$$\\frac{1}{7}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 8,
    "unitName": "Probability"
  },
  {
    "id": 1785,
    "content": [
      "What is the equation of the hyperbola with foci $$F_1=(-2, 1)$$, $$F_2=(8, 1)$$ and the length of the conjugate axis is 8 units?"
    ],
    "explanation": [
      "**Note: We added the correct choice since the question on the paper has a mistake.**\n\nThe foci are $$F_1(-2, 1)$$ and $$F_2(8, 1)$$. Since the y-coordinates are the same, the transverse axis is horizontal. The center $$(h, k)$$ is the midpoint of the foci: $$h$$ = $$\\frac{-2+8}{2}$$ = $$3$$ and $$k$$ = $$\\frac{1+1}{2}$$ = $$1$$. So the center is $$(3, 1)$$.\n\nThe distance from the center to each focus is $$c$$, and the distance between the foci is $$2c = 8 - (-2) = 10$$, so $$c = 5$$. The length of the conjugate axis is $$2b = 8$$, so $$b = 4$$ and $$b^2 = 16$$.\n\nFor a hyperbola, $$c^2$$ = $$a^2 + b^2$$. Substituting the values, $$5^2$$ = $$a^2 + 4^2$$, which gives $$25 = a^2 + 16$$, so $$a^2 = 9$$.\n\nThe standard equation for a hyperbola with a horizontal transverse axis is\n$$\n\\frac{(x-h)^2}{a^2} - \\frac{(y-k)^2}{b^2} = 1\n$$\nSubstituting the values $$h=3$$, $$k=1$$, $$a^2=9$$, $$b^2=16$$, we get\n$$\n\\frac{(x-3)^2}{9} - \\frac{(y-1)^2}{16} = 1\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7142,
        "content": [
          "$$\n\\frac{(y+1)^2}{16} - \\frac{(x-3)^2}{9} = 1\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7143,
        "content": [
          "$$\n\\frac{(x-3)^2}{16} - \\frac{(y-1)^2}{25} = 1\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7144,
        "content": [
          "$$\n\\frac{(x-3)^2}{9} - \\frac{(y-1)^2}{16} = 1\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7145,
        "content": [
          "$$\n\\frac{(x-5)^2}{9} - \\frac{(y-1)^2}{16} = 1\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7146,
        "content": [
          "$$\n\\frac{(x-3)^2}{25} - \\frac{(y-1)^2}{15} = 1\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1786,
    "content": [
      "If the truth value of p is T, then which of the following compound propositions has a truth value T for any proposition q?"
    ],
    "explanation": [
      "We are given that p is True (T). Therefore, $$\\neg p$$ is False (F).\n\nWe need to find the proposition that is always True regardless of the truth value of q.\n- $$\\neg p \\Leftrightarrow (p \\vee \\neg q)$$ becomes $$F \\Leftrightarrow (T \\vee \\neg q)$$. Since $$T \\vee \\neg q$$ is always T, this becomes $$F \\Leftrightarrow T$$, which is False.\n- $$(\\neg p \\wedge q) \\Rightarrow q$$ becomes $$(F \\wedge q) \\Rightarrow q$$. Since $$F \\wedge q$$ is always F, this becomes $$F \\Rightarrow q$$. An implication with a False antecedent ($$F \\Rightarrow \\dots$$) is always True, regardless of the consequent q.\n- $$(p \\wedge \\neg p) \\wedge q$$ becomes $$(T \\wedge F) \\wedge q$$. Since $$T \\wedge F$$ is F, this becomes $$F \\wedge q$$, which is always False.\n- $$(p \\Leftrightarrow q) \\wedge \\neg p$$ becomes $$(T \\Leftrightarrow q) \\wedge F$$. Since anything AND False is False, this is always False.\n\nTherefore, only proposition of option B is always True when p is T."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7147,
        "content": [
          "$$\\neg p \\Leftrightarrow (p \\vee \\neg q)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7148,
        "content": [
          "$$(\\neg p \\wedge q) \\Rightarrow q$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7149,
        "content": [
          "$$(p \\wedge \\neg p) \\wedge q$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7150,
        "content": [
          "$$(p \\Leftrightarrow q) \\wedge \\neg p$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1787,
    "content": [
      "Which of the following functions is one to one?"
    ],
    "explanation": [
      "A function is one-to-one if every distinct input value maps to a unique output value ($$f(x_1)$$ = $$f(x_2)$$ $$\\implies$$ $$x_1$$ = $$x_2$$).\n\nOption A: The function maps both 1 and 6 to the same output 5 ($$f(1)=5$$, $$f(6)=5$$). Not one-to-one.\n\nOption B: The domain is $$[0, \\infty)$$. For $$x \\ge 0$$, $$|x|$$ = $$x$$. So, $$f(x)$$ = $$x - 1$$. This is a linear function with a positive slope (1) restricted to $$x \\ge 0$$. If $$f(x_1)$$ = $$f(x_2)$$, then $$x_1$$ - $$1$$ = $$x_2$$ - $$1$$, which implies $$x_1$$ = $$x_2$$. It is one-to-one.\n\nOption C: The function $$f(x)$$ = $$x^2 - 1$$ maps different inputs to the same output, e.g., $$f(2)$$ = $$2^2-1$$ = $$3$$ and $$f(-2)$$ = $$(-2)^2-1$$ = $$3$$. Not one-to-one.\n\nOption D: Different individuals (x) can have the same mother (y), e.g., siblings. Not one-to-one.\n\nTherefore, only function of option B is one-to-one."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7151,
        "content": [
          "$$\nf = \\{(1, 5), (2, 3), (5, 4), (6, 5)\\}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7152,
        "content": [
          "$$\nf: [0, \\infty) \\to \\mathbb{R}, f(x) = |x| - 1\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7153,
        "content": [
          "$$\nf: \\mathbb{R} \\to \\mathbb{R}, f(x) = x^2 - 1\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7154,
        "content": [
          "$$\nf = \\{(x, y): y \\text{ is the mother of } x\\}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1788,
    "content": [
      "If $$\\frac{x^2+14}{(x+2)(x-1)^2}$$ = $$\\frac{A}{x+2}$$ + $$\\frac{B}{x-1}$$ + $$\\frac{C}{(x-1)^2}$$, then what are the values of A, B and C respectively?"
    ],
    "explanation": [
      "To find the constants A, B, and C, we multiply both sides by the common denominator $$(x+2)(x-1)^2$$:\n$$\nx^2 + 14 = A(x-1)^2 + B(x+2)(x-1) + C(x+2)\n$$\nSubstitute $$x=1$$:\n$$\n1^2 + 14 = A(1-1)^2 + B(1+2)(1-1) + C(1+2)\n$$\n$$\n15 = A(0) + B(3)(0) + C(3)\n$$\n$$\n15 = 3C \\implies C = 5\n$$\nSubstitute $$x=-2$$:\n$$\n(-2)^2 + 14 = A(-2-1)^2 + B(-2+2)(-2-1) + C(-2+2)\n$$\n$$\n4 + 14 = A(-3)^2 + B(0)(-3) + C(0)\n$$\n$$\n18 = 9A \\implies A = 2\n$$\nTo find B, substitute any other value for x, for example, $$x=0$$:\n$$\n0^2 + 14 = A(0-1)^2 + B(0+2)(0-1) + C(0+2)\n$$\n$$\n14 = A(-1)^2 + B(2)(-1) + C(2)\n$$\n$$\n14 = A - 2B + 2C\n$$\nSubstitute A=2 and C=5:\n$$\n14 = 2 - 2B + 2(5)\n$$\n$$\n14 = 2 - 2B + 10\n$$\n$$\n14 = 12 - 2B\n$$\n$$\n2 = -2B \\implies B = -1\n$$\nThus, A = 2, B = -1, and C = 5"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7155,
        "content": [
          "1, -1, 3"
        ],
        "isCorrect": false
      },
      {
        "id": 7156,
        "content": [
          "3, -2, 6"
        ],
        "isCorrect": false
      },
      {
        "id": 7157,
        "content": [
          "2, -2, -5"
        ],
        "isCorrect": false
      },
      {
        "id": 7158,
        "content": [
          "2, -1, 5"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 1789,
    "content": [
      "Which of the following line is true about the intercept and symmetry of the graph of $$f(x)$$ = $$\\frac{x^3 - 3x}{x^2 - 6}$$?"
    ],
    "explanation": [
      "To determine the symmetry of the function $$f(x)$$ = $$\\frac{x^3 - 3x}{x^2 - 6}$$, we evaluate $$f(-x)$$.\n\n$$f(-x)$$ = $$\\frac{(-x)^3 - 3(-x)}{(-x)^2 - 6}$$ = $$\\frac{-x^3 + 3x}{x^2 - 6}$$ = $$- \\left( \\frac{x^3 - 3x}{x^2 - 6} \\right)$$ = $$-f(x)$$.\n\nSince $$f(-x) = -f(x)$$, the function is odd, and its graph is symmetrical with respect to the origin.\n\nThe y-intercept is $$f(0) = 0/(-6) = 0$$.\n\nThe x-intercepts occur when the numerator is zero: $$x^3 - 3x$$ = $$x(x^2-3)=0$$, so $$x=0$$ or $$x=\\pm\\sqrt{3}$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7159,
        "content": [
          "The graph is symmetrical with respect to the y-axis."
        ],
        "isCorrect": false
      },
      {
        "id": 7160,
        "content": [
          "Its y-intercept is 3."
        ],
        "isCorrect": false
      },
      {
        "id": 7161,
        "content": [
          "Its x-intercepts are $$\\pm \\sqrt{6}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 7162,
        "content": [
          "The graph is symmetrical with respect to the origin."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 1790,
    "content": [
      "Consider the lines $$l_1: y = 2x + 3$$ and $$l_2: y = 1 - 3x$$. Then the angle between $$l_1$$ and $$l_2$$ is"
    ],
    "explanation": [
      "The slope of line $$l_1$$ is $$m_1 = 2$$. The slope of line $$l_2$$ is $$m_2 = -3$$.\n\nThe tangent of the angle $$\\theta$$ between two lines is given by the formula $$\\tan \\theta$$ = $$\\left| \\frac{m_2 - m_1}{1 + m_1 m_2} \\right|$$.\n\nSubstituting the slopes:\n$$\n\\tan \\theta = \\left| \\frac{-3 - 2}{1 + (2)(-3)} \\right|\n$$\n$$\n= \\left| \\frac{-5}{1 - 6} \\right|\n$$\n$$\n= \\left| \\frac{-5}{-5} \\right| = |1| = 1\n$$\nThe angle $$\\theta$$ whose tangent is 1 is $$\\theta$$ = $$\\arctan(1)$$ = $$\\frac{\\pi}{4}$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7163,
        "content": [
          "$$\\frac{\\pi}{4}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7164,
        "content": [
          "$$\\frac{3\\pi}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7165,
        "content": [
          "$$\\frac{\\pi}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7166,
        "content": [
          "$$\\frac{\\pi}{6}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1791,
    "content": [
      "The equation of the parabola with vertex $$V(2, -1)$$ and focus $$F(-1, -1)$$ is"
    ],
    "explanation": [
      "The vertex is $$V(h, k) = (2, -1)$$ and the focus is $$F(-1, -1)$$.\n\nSince the y-coordinates are the same, the axis of symmetry is horizontal ($$y = -1$$), and the parabola opens left or right.\n\nThe standard form is\n$$\n(y-k)^2 = 4p(x-h)\n$$\nThe focus is at $$(h+p, k)$$. We have $$h=2$$ and $$k=-1$$.\n\nComparing the focus $$(-1, -1)$$ with $$(h+p, k)$$, we get $$h+p = -1$$. Substituting $$h=2$$, we find $$2+p = -1$$, so $$p = -3$$. Since $$p$$ is negative, the parabola opens to the left.\n\nThe equation is\n$$\n(y - (-1))^2 = 4(-3)(x - 2)\n$$\nWhich simplifies to\n$$\n(y+1)^2 = -12(x-2)\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7167,
        "content": [
          "$$(x+1)^2 = -12(y+1)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7168,
        "content": [
          "$$(y+1)^2 = -12(x-2)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7169,
        "content": [
          "$$(y+1)^2 = 12(x-2)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7170,
        "content": [
          "$$(x-2)^2 = -12(y+1)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1792,
    "content": [
      "What is the value of $$\\lim_{x \\to -1} \\frac{x^2 - 1}{x^2 + 1}$$?"
    ],
    "explanation": [
      "To find the limit, we can use direct substitution since the function is a rational function and the denominator is not zero at $$x = -1$$.\n$$\n\\lim_{x \\to -1} \\frac{x^2 - 1}{x^2 + 1} = \\frac{(-1)^2 - 1}{(-1)^2 + 1}\n$$\n$$\n= \\frac{1 - 1}{1 + 1} = \\frac{0}{2} = 0\n$$\nThe limit is 0."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7171,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 7172,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 7173,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 7174,
        "content": [
          "0"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1793,
    "content": [
      "Which one of the following is the value of $$a$$ so that the function given by\n$$\nf(x) = \\begin{cases} ax+1 & \\text{for } x \\ge 1 \\\\ x^2-4 & \\text{for } x < 1 \\end{cases}\n$$\nis continuous at 1?"
    ],
    "explanation": [
      "For the function $$f(x)$$ to be continuous at $$x=1$$, the limit from the left must equal the limit from the right, and both must equal the function value at $$x=1$$.\n\nThe limit from the right and the function value is\n$$\n\\lim_{x \\to 1^+} f(x) = f(1) = a(1) + 1 = a+1\n$$\nThe limit from the left is\n$$\n\\lim_{x \\to 1^-} f(x) = \\lim_{x \\to 1^-} (x^2 - 4) = (1)^2 - 4 = -3\n$$\nFor continuity, we must have $$a+1 = -3$$.\n\nSolving for $$a$$, we get $$a = -4$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7175,
        "content": [
          "4"
        ],
        "isCorrect": false
      },
      {
        "id": 7176,
        "content": [
          "-4"
        ],
        "isCorrect": true
      },
      {
        "id": 7177,
        "content": [
          "-1"
        ],
        "isCorrect": false
      },
      {
        "id": 7178,
        "content": [
          "1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1794,
    "content": [
      "Let $$f(x)$$ = $$-\\frac{1}{3}\\cos\\left(\\frac{3}{2}x - \\frac{\\pi}{3}\\right)$$ + $$1$$. Then what is the period and Phase shift of the graph of f respectively?"
    ],
    "explanation": [
      "The function is given by $$f(x)$$ = $$-\\frac{1}{3}\\cos\\left(\\frac{3}{2}x - \\frac{\\pi}{3}\\right)$$ + $$1$$. This is in the form $$A \\cos(Bx - C) + D$$.\n\nThe period $$P$$ is given by the formula $$P$$ = $$\\frac{2\\pi}{|B|}$$.\n\nHere, $$B$$ = $$\\frac{3}{2}$$.\n\nSo, the period is $$P$$ = $$\\frac{2\\pi}{|3/2|}$$ = $$\\frac{2\\pi}{3/2}$$ = $$2\\pi \\times \\frac{2}{3}$$ = $$\\frac{4\\pi}{3}$$\n\nThe phase shift is given by the formula $$PS$$ = $$\\frac{C}{B}$$.\n\nHere, $$C$$ = $$\\frac{\\pi}{3}$$ and $$B$$ = $$\\frac{3}{2}$$. So, the phase shift is $$PS$$ = $$\\frac{\\pi/3}{3/2}$$ = $$\\frac{\\pi}{3} \\times \\frac{2}{3}$$ = $$\\frac{2\\pi}{9}$$.\n\nTherefore, the period is $$\\frac{4\\pi}{3}$$ and the phase shift is $$\\frac{2\\pi}{9}$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7179,
        "content": [
          "$$\\frac{4\\pi}{3}$$ and $$\\frac{2\\pi}{9}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7180,
        "content": [
          "$$\\frac{2\\pi}{3}$$ and $$\\frac{2\\pi}{9}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7181,
        "content": [
          "$$\\frac{3\\pi}{2}$$ and $$\\frac{4\\pi}{9}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7182,
        "content": [
          "$$\\frac{\\pi}{9}$$ and $$\\frac{4\\pi}{9}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Trigonometric Function"
  },
  {
    "id": 1795,
    "content": [
      "What is the fifth term of the sequence $$\\{2^n + 4n - 5\\}_{n=0}^{\\infty}$$?"
    ],
    "explanation": [
      "Let the sequence be denoted by $$\\{a_n\\}_{n=0}^{\\infty}$$, where the general term is given by the formula $$a_n = 2^n + 4n - 5$$.\n\nThe sequence starts with the index $$n=0$$. The terms of the sequence are obtained by substituting $$n=0, 1, 2, 3, \\dots$$ into the formula.\n\nTo find the fifth term, we need to calculate $$a_4$$:\n$$\na_4 = 2^4 + 4(4) - 5\n$$\nThe fifth term of the sequence is 27."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7183,
        "content": [
          "27"
        ],
        "isCorrect": true
      },
      {
        "id": 7184,
        "content": [
          "17"
        ],
        "isCorrect": false
      },
      {
        "id": 7185,
        "content": [
          "47"
        ],
        "isCorrect": false
      },
      {
        "id": 7186,
        "content": [
          "15"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1796,
    "content": [
      "If the $$6^{th}$$ and the $$11^{th}$$ term of an arithmetic sequence are 35 and 75 respectively, then what is the sum of the first 31 terms of the sequence?"
    ],
    "explanation": [
      "**Note: We added the correct choice since the question on the paper has a mistake.**\n\nLet the arithmetic sequence be denoted by $$a_n$$ with first term $$a_1$$ and common difference $$d$$.\n\nWe are given $$a_6 = 35$$ and $$a_{11} = 75$$.\n\nUsing the formula $$a_n = a_1 + (n-1)d$$, we have:\n$$\na_6 = a_1 + 5d = 35\n$$\n$$\na_{11} = a_1 + 10d = 75\n$$\nSubtracting the first equation from the second gives: $$(a_1 + 10d)$$ - $$(a_1 + 5d)$$ = $$75 - 35$$, which simplifies to $$5d = 40$$, so $$d = 8$$.\n\nSubstituting $$d=8$$ into the first equation:\n$$\na_1 + 5(8) = 35 \\implies a_1 = -5\n$$\nThe sum of the first $$n$$ terms is given by\n$$\nS_n = \\frac{n}{2}[2a_1 + (n-1)d]\n$$\nWe need the sum of the first 31 terms, $$S_{31}$$\n$$\nS_{31} = \\frac{31}{2}[2(-5) + (31-1)(8)]\n$$\n$$\n= \\frac{31}{2}[-10 + 30(8)]\n$$\n$$\n= \\frac{31}{2}[-10 + 240]\n$$\n$$\n= \\frac{31}{2}[230]\n$$\n$$\n= 31 \\times 115 = 3565\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7187,
        "content": [
          "3565"
        ],
        "isCorrect": true
      },
      {
        "id": 7188,
        "content": [
          "2145"
        ],
        "isCorrect": false
      },
      {
        "id": 7189,
        "content": [
          "724"
        ],
        "isCorrect": false
      },
      {
        "id": 7190,
        "content": [
          "2635"
        ],
        "isCorrect": false
      },
      {
        "id": 7191,
        "content": [
          "846"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1797,
    "content": [
      "Which one of the following numbers is the upper bounds of the sequence $$\\left\\{\\frac{2n+1}{n+1}\\right\\}_{n=1}^{\\infty}$$?"
    ],
    "explanation": [
      "Let the sequence term be $$a_n$$ = $$\\frac{2n+1}{n+1}$$.\n\nWe can rewrite this as $$a_n$$ = $$\\frac{2(n+1)-1}{n+1}$$ = $$2 - \\frac{1}{n+1}$$.\n\nAs $$n$$ increases starting from 1, $$n+1$$ increases, so $$\\frac{1}{n+1}$$ decreases. Therefore, $$a_n$$ = $$2 - \\frac{1}{n+1}$$ increases.\n\nThe first term is $$a_1$$ = $$2 - \\frac{1}{1+1}$$ = $$2 - \\frac{1}{2}$$ = $$\\frac{3}{2}$$.\n\nAs $$n \\to \\infty$$, $$\\frac{1}{n+1} \\to 0$$, so $$a_n \\to 2$$. Since the sequence is increasing and approaches 2, all terms are less than 2.\n\nThus, 2 is the least upper bound (supremum). Any number greater than or equal to 2 is an upper bound.\n\nAmong the options, only 4 is greater than or equal to 2. Therefore, 4 is an upper bound for the sequence."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7192,
        "content": [
          "$$\\frac{3}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7193,
        "content": [
          "0"
        ],
        "isCorrect": false
      },
      {
        "id": 7194,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 7195,
        "content": [
          "4"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1798,
    "content": [
      "Let the sequence $$\\{a_n\\}$$ converges to 3 while $$\\{b_n\\}$$ converges to -1. Then the sequence $$\\{a_n - b_n\\}$$ converges to"
    ],
    "explanation": [
      "According to the algebra of limits for sequences, if $$\\lim_{n \\to \\infty} a_n$$ = $$L$$ and $$\\lim_{n \\to \\infty} b_n$$ = $$M$$, then the limit of the difference sequence is the difference of the limits:\n$$\n\\lim_{n \\to \\infty} (a_n - b_n) = \\lim_{n \\to \\infty} a_n - \\lim_{n \\to \\infty} b_n = L - M\n$$\nGiven $$\\lim_{n \\to \\infty} a_n$$ = $$3$$ and $$\\lim_{n \\to \\infty} b_n$$ = $$-1$$.\n\nTherefore,\n$$\n\\lim_{n \\to \\infty} (a_n - b_n) = 3 - (-1) = 3 + 1 = 4\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7196,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 7197,
        "content": [
          "4"
        ],
        "isCorrect": true
      },
      {
        "id": 7198,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 7199,
        "content": [
          "$$\\frac{1}{3}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 1799,
    "content": [
      "Which of the following argument is valid?"
    ],
    "explanation": [
      "**Note: We added the correct choice since the question on the paper has a mistake.**\n\nThe argument $$p \\Rightarrow q, p \\vdash q$$ is a fundamental rule of inference known as **Modus Ponens**. It states that if a conditional statement ($$p \\Rightarrow q$$, \"if p then q\") is accepted as true, and the antecedent ($$p$$) is also accepted as true, then the consequent ($$q$$) can be validly inferred as true. This is a universally accepted valid argument form.\n\nThe other options represent invalid argument forms (logical fallacies or incorrect deductions)."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7200,
        "content": [
          "$$p \\lor q, p \\Rightarrow q \\vdash \\neg q$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7201,
        "content": [
          "$$p \\Rightarrow q, p \\vdash q$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7202,
        "content": [
          "$$p, p \\Rightarrow q, r \\lor \\neg q \\vdash p \\land \\neg r$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7203,
        "content": [
          "$$p \\Rightarrow q, q, r \\Rightarrow p \\vdash \\neg r$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7204,
        "content": [
          "$$p \\Rightarrow q, \\neg r \\land q \\vdash p \\lor r$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1800,
    "content": [
      "Which of the following assertions is true applying the Principle of Mathematical Induction?"
    ],
    "explanation": [
      "We check each assertion.\n\nOption A: This is the formula for the sum of a geometric progression $$1, 2, 2^2, ..., 2^n$$. The first term is $$a=1$$, the common ratio is $$r=2$$, and there are $$n+1$$ terms. The sum is\n$$\na\\frac{r^{n+1}-1}{r-1} = 1 \\cdot \\frac{2^{n+1}-1}{2-1}\n$$\n$$\n= 2^{n+1}-1\n$$\nThe formula is correct for $$n \\ge 0$$. It can be proven by induction. Base case $$n=0$$: $$2^0 = 1$$, $$2^{0+1}-1 = 1$$.\n\nAssume true for k: $$S_k = 2^{k+1}-1$$. Then\n$$S_{k+1}$$ = $$S_k + 2^{k+1}$$ = $$(2^{k+1}-1)$$ + $$2^{k+1}$$ = $$2 \\cdot 2^{k+1}$$ - $$1$$ = $$2^{k+2}-1$$.\n\nThis matches the formula for $$n=k+1$$. So, A is true.\n\nOption B: False. Counterexample n=1: $$1! = 1$$, $$2^1 = 2$$. $$1 \\ge 2$$ is false. (True only for n=0 and $$n \\ge 4$$).\n\nOption C: False. The sum $$2+3+...+n$$ = $$(1+2+...+n)$$ - $$1$$ = $$\\frac{n(n+1)}{2}$$ - $$1$$. The assertion states $$\\frac{n(n+1)}{2} + 1$$. Base case n=2: LHS=2, RHS = $$\\frac{2(3)}{2}+1 = 4$$. $$2 \\ne 4$$.\n\nOption D: False. The sum is $$\\sum_{k=1}^{n} (2k+1)$$ = $$2\\sum k$$ + $$\\sum 1$$ = $$2\\frac{n(n+1)}{2}$$ + $$n$$ = $$n(n+1)+n$$ = $$n^2+2n$$. The assertion states $$n^2$$. Base case n=1: LHS=$$2(1)+1=3$$. RHS=$$1^2=1$$. $$3 \\ne 1$$.\n\nTherefore, only assertion A is correct and provable by induction for the specified range of n."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7205,
        "content": [
          "$$1+2+ 2^2+...+ 2^n$$ = $$2^{n+1}$$ - $$1$$ for $$n \\ge 0$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7206,
        "content": [
          "$$n! \\ge 2^n$$ for $$n \\ge 0$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7207,
        "content": [
          "$$2+3+4+...+n$$ = $$\\frac{n(n+1)}{2}$$ + $$1$$ for $$n \\ge 2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7208,
        "content": [
          "$$3+5+7+...+(2n+1)$$ = $$n^2$$ for $$n \\ge 1$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 1801,
    "content": [
      "Which of the following is equal to $$\\int 3 \\cos 3x dx$$?"
    ],
    "explanation": [
      "To evaluate the integral $$\\int 3 \\cos 3x dx$$, we can use the substitution method.\n\nLet $$u = 3x$$. Then, the differential $$du = 3 dx$$. Substituting these into the integral gives $$\\int \\cos u du$$. The integral of $$\\cos u$$ with respect to $$u$$ is $$\\sin u + c$$. Substituting back $$u = 3x$$, we get $$\\sin 3x + c$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7209,
        "content": [
          "$$\\frac{1}{3} \\sin 3x + c$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7210,
        "content": [
          "$$\\sin 3x + c$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7211,
        "content": [
          "$$\\sin x + c$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7212,
        "content": [
          "$$-\\sin x + c$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1802,
    "content": [
      "What is the area of the region bounded by the graph of $$f(x) = x^2 - 4$$ and the x-axis in square units?"
    ],
    "explanation": [
      "To find the area, we first determine the points where the graph intersects the x-axis by setting $$f(x) = 0$$. So, $$x^2 - 4 = 0$$, which gives $$x = -2$$ and $$x = 2$$.\n\nThe area A is the absolute value of the definite integral of $$f(x)$$ from -2 to 2:\n$$\nA = |\\int_{-2}^{2} (x^2 - 4) dx|\n$$\nEvaluating the integral:\n$$\n\\int (x^2 - 4) dx = \\frac{x^3}{3} - 4x\n$$\n$$\nA = |[\\frac{x^3}{3} - 4x]_{-2}^{2}|\n$$\n$$\n= |(\\frac{2^3}{3} - 4(2)) - (\\frac{(-2)^3}{3} - 4(-2))|\n$$\n$$\n= |(\\frac{8}{3} - 8) - (-\\frac{8}{3} + 8)|\n$$\n$$\n= |\\frac{8}{3} - 8 + \\frac{8}{3} - 8|\n$$\n$$\n= \\frac{32}{3}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7213,
        "content": [
          "$$16$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7214,
        "content": [
          "$$32$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7215,
        "content": [
          "$$\\frac{16}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7216,
        "content": [
          "$$\\frac{32}{3}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1803,
    "content": [
      "Let f be a continuous function on [0, 1] and let F be an anti-derivative of f with $$F(1) = -11$$ and $$F(0) = 11$$. Then $$\\int_{0}^{1} f(x) dx$$ is equal to"
    ],
    "explanation": [
      "According to the Fundamental Theorem of Calculus, if F is an antiderivative of a continuous function f on the interval [a, b], then\n$$\n\\int_{a}^{b} f(x) dx = F(b) - F(a)\n$$\nHere, $$a=0$$, $$b=1$$, $$F(1)=-11$$, and $$F(0)=11$$. Therefore,\n$$\n\\int_{0}^{1} f(x) dx = F(1) - F(0) = -11 - 11 = -22\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7217,
        "content": [
          "-22"
        ],
        "isCorrect": true
      },
      {
        "id": 7218,
        "content": [
          "11"
        ],
        "isCorrect": false
      },
      {
        "id": 7219,
        "content": [
          "0"
        ],
        "isCorrect": false
      },
      {
        "id": 7220,
        "content": [
          "22"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1804,
    "content": [
      "Which of the following set of equations define the xz-plane?"
    ],
    "explanation": [
      "The xz-plane in a three-dimensional Cartesian coordinate system is the set of all points $$(x, y, z)$$ for which the y-coordinate is zero ($$y=0$$).\n\nThe x and z coordinates can be any real numbers. Therefore, the set defining the xz-plane is\n$$\n\\{(x, y, z) | x, y, z \\in \\mathbb{R} \\text{ and } y=0\\}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7221,
        "content": [
          "$$\n\\{(x, y, z) | x, y, z \\in \\mathbb{R} \\text{ and } x=z=0\\}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7222,
        "content": [
          "$$\n\\{(x, y, z) | x, y, z \\in \\mathbb{R} \\text{ and } y=0\\}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7223,
        "content": [
          "$$\n\\{(x, y, z) | x, y, z \\in \\mathbb{R} \\text{ and } x=0\\}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7224,
        "content": [
          "$$\n\\{(x, y, z) | x, y, z \\in \\mathbb{R} \\text{ and } z=0\\}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1805,
    "content": [
      "What is the coordinates of the midpoint of the line segment joining $$(-1, -3, 3)$$ and $$(-1, 5, -7)$$ in space?"
    ],
    "explanation": [
      "To find the coordinates of the midpoint of the line segment joining two points $$(x_1, y_1, z_1)$$ and $$(x_2, y_2, z_2)$$ in space, we use the midpoint formula:\n$$\nM = \\left( \\frac{x_1 + x_2}{2}, \\frac{y_1 + y_2}{2}, \\frac{z_1 + z_2}{2} \\right)\n$$\nGiven the points $$(-1, -3, 3)$$ and $$(-1, 5, -7)$$.\n\nLet $$(x_1, y_1, z_1)$$ = $$(-1, -3, 3)$$ and $$(x_2, y_2, z_2)$$ = $$(-1, 5, -7)$$.\n\nThe coordinates of the midpoint are:\n\nx-coordinate:\n$$\n\\frac{-1 + (-1)}{2} = \\frac{-1 - 1}{2} = \\frac{-2}{2} = -1\n$$\ny-coordinate:\n$$\n\\frac{-3 + 5}{2} = \\frac{2}{2} = 1\n$$\nz-coordinate:\n$$\n\\frac{3 + (-7)}{2} = \\frac{3 - 7}{2} = \\frac{-4}{2} = -2\n$$\nThe midpoint is $$(-1, 1, -2)$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7225,
        "content": [
          "$$(-1, 3, \\frac{9}{2})$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7226,
        "content": [
          "$$(1, 4, 3)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7227,
        "content": [
          "$$(-1, 1, -2)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7228,
        "content": [
          "$$(-1, 3, 5)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 1806,
    "content": [
      "Which of the following is true about the graph of $$y = 3 \\sin(4x)$$?"
    ],
    "explanation": [
      "The period of this function is\n$$\nT = \\frac{2\\pi}{|B|} = \\frac{2\\pi}{4} = \\frac{\\pi}{2}\n$$\nOne cycle is completed in an interval of length $$\\frac{\\pi}{2}$$.\n\nOption A is false because the period is $$\\frac{\\pi}{2}$$, not $$\\pi$$.\n\nOption C is false because the interval length is $$\\frac{\\pi}{4}$$, which is half the period.\n\nOption D is false because the function rises on $$[0, \\frac{\\pi}{8}]$$ and falls on $$[\\frac{\\pi}{8}, \\frac{\\pi}{4}]$$.\n\nFor option B, consider the interval $$(\\frac{\\pi}{4}, \\frac{\\pi}{2})$$. As $$x$$ ranges in this interval, the argument $$4x$$ ranges from $$4(\\frac{\\pi}{4}) = \\pi$$ to $$4(\\frac{\\pi}{2}) = 2\\pi$$.\n\nThe sine function is negative in the interval $$(\\pi, 2\\pi)$$. Since the amplitude 3 is positive, $$y = 3\\sin(4x)$$ is negative on $$(\\frac{\\pi}{4}, \\frac{\\pi}{2})$$, meaning the graph lies below the x-axis."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7229,
        "content": [
          "The graph completes one cycle on the interval $$[0, \\pi]$$."
        ],
        "isCorrect": false
      },
      {
        "id": 7230,
        "content": [
          "The graph lies below the x-axis on $$(\\frac{\\pi}{4}, \\frac{\\pi}{2})$$."
        ],
        "isCorrect": true
      },
      {
        "id": 7231,
        "content": [
          "The graph completes one cycle on the interval $$[0, \\frac{\\pi}{4}]$$."
        ],
        "isCorrect": false
      },
      {
        "id": 7232,
        "content": [
          "The graph rises up on $$[0, \\frac{\\pi}{4}]$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Trigonometric Function"
  },
  {
    "id": 1807,
    "content": [
      "Which of the following functions has a graph that completes one full cycle on $$[-\\frac{\\pi}{4}, \\frac{11\\pi}{4}]$$?"
    ],
    "explanation": [
      "The period of a sine function of the form $$f(x) = a\\sin(bx + c)$$ is given by\n$$\nT = \\frac{2\\pi}{|b|}\n$$\nWe check each function:\n- Option A: $$T$$ = $$\\frac{2\\pi}{3}$$\n- Option B: $$T$$ = $$\\frac{2\\pi}{4/3}$$ = $$\\frac{3\\pi}{2}$$\n- Option C: $$T$$ = $$\\frac{2\\pi}{2/3}$$ = $$3\\pi$$\n- Option D: $$T$$ = $$\\frac{2\\pi}{2}$$ = $$\\pi$$\n\nThe interval length is:\n\n$$\n\\frac{11\\pi}{4} - \\left(-\\frac{\\pi}{4}\\right) = \\frac{11\\pi}{4} + \\frac{\\pi}{4} = 3\\pi\n$$\n\nA function completes one full cycle if the interval length equals its period. Thus, option C is correct."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7233,
        "content": [
          "$$f(x)$$ = $$3\\sin(3x + \\frac{\\pi}{6})$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7234,
        "content": [
          "$$f(x)$$ = $$3\\sin(\\frac{4}{3}x + \\frac{\\pi}{2})$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7235,
        "content": [
          "$$f(x)$$ = $$2\\sin(\\frac{2}{3}x + \\frac{\\pi}{6})$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7236,
        "content": [
          "$$f(x)$$ = $$2\\sin(2x + \\frac{\\pi}{6})$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Trigonometric Function"
  },
  {
    "id": 1808,
    "content": [
      "Let A be a square matrix of order n and let B be a matrix obtained by multiplying one row of A by 2 and C be a matrix found by adding one row of A to another row of A. If $$det(A) = 10$$, what are $$det(B)$$ and $$det(C)$$ respectively?"
    ],
    "explanation": [
      "We use the properties of determinants. If a matrix B is obtained from A by multiplying a single row by a scalar k, then $$det(B)$$ = $$k \\cdot det(A)$$. Here, k=2, so $$det(B)$$ = $$2 \\cdot det(A)$$ = $$2 \\cdot 10$$ = $$20$$.\n\nIf a matrix C is obtained from A by adding a multiple of one row to another row, the determinant does not change. Thus, $$det(C)$$ = $$det(A)$$ = $$10$$.\n\nTherefore, $$det(B)$$ = $$20$$ and $$det(C)$$ = $$10$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7240,
        "content": [
          "20 and 10"
        ],
        "isCorrect": true
      },
      {
        "id": 7241,
        "content": [
          "20 and 0"
        ],
        "isCorrect": false
      },
      {
        "id": 7242,
        "content": [
          "10 and 20"
        ],
        "isCorrect": false
      },
      {
        "id": 7243,
        "content": [
          "10 and 10"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Determinants and Their Properties"
  },
  {
    "id": 1809,
    "content": [
      "The solution set of the system\n$$\n\\begin{cases} 2x - y + 3z = 1 \\\\ x + y + 3z = 5 \\\\ x - y + z = -1 \\end{cases} \\ \\text{is}\n$$"
    ],
    "explanation": [
      "To solve the system, we can use elimination or substitution.\n\nAdding the second and third equations yields $$(x + y + 3z)$$ + $$(x - y + z)$$ = $$5$$ + $$(-1)$$, which simplifies to $$2x + 4z$$ = $$4$$, or $$x + 2z$$ = $$2$$.\n\nFrom this, we express $$x$$ in terms of $$z$$: $$x = 2 - 2z$$. Substituting this expression for $$x$$ into the third equation gives $$(2 - 2z) - y + z$$ = $$-1$$.\n\nSimplifying, we get $$2 - z - y$$ = $$-1$$, which leads to $$y$$ = $$3 - z$$.\n\nIf we let the free variable $$z$$ = $$k$$, then $$x$$ = $$2 - 2k$$ and $$y$$ = $$3 - k$$.\n\nThus, the solution set is $$(x, y, z)$$ = $$(2 - 2k, 3 - k, k)$$ for any real number $$k$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7244,
        "content": [
          "$$\n\\{(-4-2k, k, 2-k): k \\in \\mathbb{R}\\}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7245,
        "content": [
          "$$\n\\{(k+1, 2k, k-1): k \\in \\mathbb{R}\\}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7246,
        "content": [
          "$$\n\\{(2-2k, 3-k, k): k \\in \\mathbb{R}\\}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7247,
        "content": [
          "$$\n\\{(k, k+1, k-1): k \\in \\mathbb{R}\\}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 1810,
    "content": [
      "Let $$z_1$$, $$z_2$$, and $$z_3$$ be complex numbers. Then which of the following is **NOT** necessarily true?"
    ],
    "explanation": [
      "Option B simplifies as follows: The left side is\n$$\nz_1 - (z_2 - z_3) = z_1 - z_2 + z_3\n$$\nThe right side is\n$$\n(z_1 - z_2) - z_3 = z_1 - z_2 - z_3\n$$\nThese two expressions, $$z_1 - z_2 + z_3$$ and $$z_1 - z_2 - z_3$$, are not equal unless $$z_3 = -z_3$$, which only happens if $$z_3 = 0$$.\n\nSince the statement must be true for *all* complex numbers $$z_1, z_2, z_3$$, option B is not necessarily true.\n\nOptions A, C, and D represent standard properties of complex number arithmetic (associativity of addition/subtraction, commutativity and associativity of multiplication)."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7248,
        "content": [
          "$$\nz_1 - (z_2 + z_3) = (z_1 - z_2) - z_3\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7249,
        "content": [
          "$$\nz_1 - (z_2 - z_3) = (z_1 - z_2) - z_3\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7250,
        "content": [
          "$$\n(z_1 z_2) z_3 = (z_2 z_1) z_3\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7251,
        "content": [
          "$$\n(z_1 z_2) z_3 = z_1 (z_2 z_3)\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1811,
    "content": [
      "Which of the following complex numbers corresponds to the point $$(-3, -1)$$ in the Argand plane?"
    ],
    "explanation": [
      "In the Argand plane, a point with coordinates $$(x, y)$$ corresponds to the complex number $$z = x + yi$$. For the point $$(-3, -1)$$, we have $$x = -3$$ and $$y = -1$$. Therefore, the corresponding complex number is\n$$\nz = -3 + (-1)i = -3 - i\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7252,
        "content": [
          "$$-3 + i$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7253,
        "content": [
          "$$3 + i$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7254,
        "content": [
          "$$-1 - 3i$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7255,
        "content": [
          "$$-3 - i$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 1812,
    "content": [
      "If a translation T takes a point $$(-1, 1)$$ to a point $$(3, 2)$$, then the image of the circle $$x^2 + y^2 - 2x + 4y + 1 = 0$$ under T is"
    ],
    "explanation": [
      "The translation vector is found by subtracting the initial point from the final point: $$(3 - (-1), 2 - 1)$$ = $$(4, 1)$$.\n\nThus, the translation T adds $$(4, 1)$$ to any point $$(x, y)$$. The equation of the original circle\n$$\nx^2 + y^2 - 2x + 4y + 1 = 0\n$$\nCan be rewritten in standard form by completing the square:\n$$\n(x^2 - 2x + 1) + (y^2 + 4y + 4) + 1 - 1 - 4 = 0\n$$\nWhich gives $$(x-1)^2 + (y+2)^2$$ = $$4$$.\n\nThe center of this circle is $$(1, -2)$$ and the radius is $$r=2$$. The translation T maps the center $$(1, -2)$$ to the new center $$(1+4, -2+1)$$ = $$(5, -1)$$. The radius remains unchanged under translation.\n\nTherefore, the equation of the translated circle is\n$$\n(x-5)^2 + (y-(-1))^2 = 2^2$$, or $$(x-5)^2 + (y+1)^2 = 4\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRANSFORMATION_PLANE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7256,
        "content": [
          "$$\n(x-3)^2 + (y-3)^2 = 4\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7257,
        "content": [
          "$$\n(x-2)^2 + (y+3)^2 = 4\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7258,
        "content": [
          "$$\n(x-5)^2 + (y+1)^2 = 4\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7259,
        "content": [
          "$$\n(x+3)^2 + (y+3)^2 = 4\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Transformation of the Plane"
  },
  {
    "id": 1813,
    "content": [
      "Let $$u = (-1, 6)$$ and $$v = (2, 4)$$ be position vectors. Then the vector $$4u - 3v$$ is"
    ],
    "explanation": [
      "We calculate the scalar multiples of the vectors first:\n$$\n4u = 4(-1, 6) = (-4, 24)\n$$\n$$\n3v = 3(2, 4) = (6, 12)\n$$\nThen we perform the vector subtraction:\n$$\n4u - 3v = (-4, 24) - (6, 12) = (-10, 12)\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_VECTORS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7260,
        "content": [
          "$$(-10, 12)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7261,
        "content": [
          "$$(-10, 11)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7262,
        "content": [
          "$$(-4, 24)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7263,
        "content": [
          "$$(-15, 18)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 8,
    "unitName": "Vectors in 2D"
  },
  {
    "id": 1814,
    "content": [
      "Water is running into a canonical tank which is pointed down at a constant rate of $$6\\pi \\text{ cm}^3/\\text{sec}$$. The cone has height of 10 cm and a base radius 5cm. then how fast is the water level rising when the water reaches 2 cm deep?"
    ],
    "explanation": [
      "Let $$V$$ be the volume of water in the cone, $$h$$ be the depth (height) of the water, and $$r$$ be the radius of the water surface. The volume of a cone is\n$$\nV = \\frac{1}{3}\\pi r^2 h\n$$\nThe cone has total height $$H=10$$ cm and base radius $$R=5$$ cm. By similar triangles, the ratio of the radius to the height is constant:\n$$\n\\frac{r}{h} = \\frac{R}{H} = \\frac{5}{10} = \\frac{1}{2}\n$$\nSo, $$r = \\frac{h}{2}$$. Substituting this into the volume formula gives\n$$\nV = \\frac{1}{3}\\pi (\\frac{h}{2})^2 h = \\frac{\\pi}{12}h^3\n$$\nWe are given that the volume is increasing at a constant rate, $$\\frac{dV}{dt}$$ = $$6\\pi \\text{ cm}^3/\\text{sec}$$. We need to find $$\\frac{dh}{dt}$$ when $$h=2$$ cm.\n\nDifferentiating the volume equation with respect to time $$t$$ gives\n$$\n\\frac{dV}{dt} = \\frac{d}{dt} (\\frac{\\pi}{12}h^3) = \\frac{\\pi}{12} \\cdot 3h^2 \\frac{dh}{dt} = \\frac{\\pi h^2}{4} \\frac{dh}{dt}\n$$\nNow substitute the known values:\n$$\n6\\pi = \\frac{\\pi (2)^2}{4} \\frac{dh}{dt}\n$$\n$$\n6\\pi = \\frac{\\pi \\cdot 4}{4} \\frac{dh}{dt} = \\pi \\frac{dh}{dt}\n$$\nSolving for $$\\frac{dh}{dt}$$, we get\n$$\n\\frac{dh}{dt} = \\frac{6\\pi}{\\pi} = 6 \\ \\text{cm/sec}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_APPLICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7264,
        "content": [
          "$$\\frac{4}{\\pi} \\text{ cm/sec}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7265,
        "content": [
          "$$6 \\text{ cm/sec}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7266,
        "content": [
          "$$4 \\text{ cm/sec}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7267,
        "content": [
          "$$\\frac{6}{\\pi} \\text{ cm/sec}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Mathematical Application in Business"
  },
  {
    "id": 1815,
    "content": [
      "Let F be the anti-derivative of f. Then which of the following is **NOT** true about F and f?"
    ],
    "explanation": [
      "F is the antiderivative of f, which means $$F'(x) = f(x)$$. This confirms option B is true.\n\nOption A states that the derivative of the indefinite integral of F(x) is F(x), which is true by the Fundamental Theorem of Calculus, Part 1 (remove).\n\nOption D states that the indefinite integral of the derivative of f(x) is f(x) + c, which is also true by the definition of the indefinite integral (up to the constant C).\n\nOption C states that the integral of F(x) is f(x) + c. Since $$F'(x) = f(x)$$, integrating F(x) would generally not give f(x).\n\nFor example, if $$f(x) = 2x$$, then $$F(x) = x^2$$. Then $$\\int F(x)dx$$ = $$\\int x^2 dx$$ = $$\\frac{x^3}{3} + c$$, which is not equal to $$f(x)+c$$ = $$2x+c$$.\n\nTherefore, option C is not generally true."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7268,
        "content": [
          "$$\\frac{d}{dx}\\int F(x)dx$$ = $$F(x)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7269,
        "content": [
          "$$F'(x)$$ = $$f(x)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7270,
        "content": [
          "$$\\int F(x)dx$$ = $$f(x) + c$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7271,
        "content": [
          "$$\\int \\frac{d}{dx}f(x)dx$$ = $$f(x) + c$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1816,
    "content": [
      "Let $$f(x)$$ = $$\\frac{1}{\\sqrt{x}}$$ and $$g(x)$$ = $$2 - \\frac{1}{6}x^3$$ be two functions. For what values of x do the graphs of f and g have tangent lines of the same slope?"
    ],
    "explanation": [
      "The slope of the tangent line to a function is given by its derivative.\n\nWe need to find the value(s) of x for which $$f'(x) = g'(x)$$.\n\nFirst, find the derivatives: $$f(x)$$ = $$x^{-1/2}$$, so\n$$\nf'(x) = -\\frac{1}{2}x^{-3/2} = -\\frac{1}{2x\\sqrt{x}}\n$$\n$$g(x)$$ = $$2 - \\frac{1}{6}x^3$$, so\n$$\ng'(x) = 0 - \\frac{1}{6}(3x^2) = -\\frac{1}{2}x^2\n$$\nSet the derivatives equal: $$f'(x) = g'(x)$$.\n$$\n-\\frac{1}{2}x^{-3/2} = -\\frac{1}{2}x^2\n$$\n$$\nx^{-3/2} = x^2\n$$\nSince $$f(x)$$ is defined for $$x>0$$, we can rewrite this as\n$$\n\\frac{1}{x^{3/2}} = x^2\n$$\nMultiply both sides by $$x^{3/2}$$:\n$$\n1 = x^2 \\cdot x^{3/2} = x^{2 + 3/2} = x^{7/2}\n$$\nThe only positive real solution to $$x^{7/2} = 1$$ is $$x = 1$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7272,
        "content": [
          "$$\\frac{\\sqrt{3}}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7273,
        "content": [
          "$$1$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7274,
        "content": [
          "$$4$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7275,
        "content": [
          "$$\\frac{1}{4}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1817,
    "content": [
      "What is the value of a number in the interval $$(0, 1)$$ that satisfies the Mean Value Theorem for the function $$f(x) = 3x^2 - 5x + 1$$?"
    ],
    "explanation": [
      "The Mean Value Theorem states that for a function $$f$$ continuous on $$[a, b]$$ and differentiable on $$(a, b)$$, there exists a number $$c$$ in $$(a, b)$$ such that $$f'(c)$$ = $$\\frac{f(b) - f(a)}{b - a}$$.\n\nHere, $$f(x)$$ = $$3x^2 - 5x + 1$$, $$a=0$$, and $$b=1$$. The function is a polynomial, so it is continuous and differentiable everywhere.\n\nFirst, calculate $$f(a)$$ and $$f(b)$$:\n$$\nf(0) = 3(0)^2 - 5(0) + 1 = 1\n$$\n$$\nf(1) = 3(1)^2 - 5(1) + 1 = 3 - 5 + 1 = -1\n$$\nCalculate the average rate of change:\n$$\n\\frac{f(1) - f(0)}{1 - 0} = \\frac{-1 - 1}{1} = -2\n$$\nNext, find the derivative:\n$$\nf'(x) = 6x - 5\n$$\nAccording to the MVT, we need to find $$c$$ in $$(0, 1)$$ such that $$f'(c) = -2$$.\n$$\n6c - 5 = -2\n$$\n$$\nc = \\frac{3}{6} = \\frac{1}{2}\n$$\nSince $$0 < \\frac{1}{2} < 1$$, the value $$c = \\frac{1}{2}$$ satisfies the Mean Value Theorem in the interval $$(0, 1)$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7276,
        "content": [
          "$$\\frac{1}{2}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7277,
        "content": [
          "$$\\frac{3}{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7278,
        "content": [
          "$$\\frac{5}{6}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7279,
        "content": [
          "$$1$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1818,
    "content": [
      "Let $$f(x)$$ = $$5x^3$$ + $$2x$$ - $$\\sin x + e^x$$. What is the value of $$f'(0)$$?"
    ],
    "explanation": [
      "First, find the derivative of $$f(x)$$ with respect to $$x$$\n$$\nf'(x) = \\frac{d}{dx}(5x^3 + 2x - \\sin x + e^x)\n$$\n$$\n= 15x^2 + 2 - \\cos x + e^x\n$$\nThen, evaluate the derivative at $$x=0$$\n$$\nf'(0) = 15(0)^2 + 2 - \\cos(0) + e^0\n$$\n$$\n= 0 + 2 - 1 + 1 = 2\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7280,
        "content": [
          "2"
        ],
        "isCorrect": true
      },
      {
        "id": 7281,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 7282,
        "content": [
          "-1"
        ],
        "isCorrect": false
      },
      {
        "id": 7283,
        "content": [
          "4"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1819,
    "content": [
      "Let f and g be differentiable functions and $$h(x)$$ = $$g(f(3x + 1))$$. If $$f'(1)$$ = $$f(1)$$ = $$2$$ and $$g'(2)$$ = $$1$$, then what is the value of $$h'(0)$$?"
    ],
    "explanation": [
      "To find $$h'(x)$$, we use the chain rule twice.\n\nLet $$u(x)$$ = $$3x+1$$ and $$v(x)$$ = $$f(u(x))$$ = $$f(3x+1)$$.\n\nThen $$h(x)$$ = $$g(v(x))$$\n$$\nh'(x) = g'(v(x)) \\cdot v'(x)\n$$\nWe also need\n$$\nv'(x) = f'(u(x)) \\cdot u'(x) = f'(3x+1) \\cdot 3\n$$\nCombining these,\n$$\nh'(x) = g'(f(3x+1)) \\cdot f'(3x+1) \\cdot 3\n$$\nNow substitute $$x=0$$:\n$$\nh'(0) = g'(f(3(0)+1)) \\cdot f'(3(0)+1) \\cdot 3 = g'(f(1)) \\cdot f'(1) \\cdot 3\n$$\nWe are given $$f(1)=2$$, $$f'(1)=2$$, and $$g'(2)=1$$.\nSubstitute these values:\n$$\nh'(0) = g'(2) \\cdot 2 \\cdot 3 = 1 \\cdot 2 \\cdot 3 = 6\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7284,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 7285,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 7286,
        "content": [
          "6"
        ],
        "isCorrect": true
      },
      {
        "id": 7287,
        "content": [
          "4"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1820,
    "content": [
      "Which of the following describes the mechanical meaning of derivative?"
    ],
    "explanation": [
      "The derivative of a function $$f(x)$$ with respect to $$x$$ represents the instantaneous rate at which the function's value changes as the variable $$x$$ changes.\n\nWhile it's geometrically interpreted as the slope of the tangent line (option D) or gradient (option A), its fundamental physical or \"mechanical\" interpretation (e.g., velocity as the derivative of position) is the instantaneous rate of change.\n\nArea under the curve (option B) relates to integration, not differentiation."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7288,
        "content": [
          "Gradient of graphs of functions"
        ],
        "isCorrect": false
      },
      {
        "id": 7289,
        "content": [
          "Area under the curve"
        ],
        "isCorrect": false
      },
      {
        "id": 7290,
        "content": [
          "Instantaneous rate of change"
        ],
        "isCorrect": true
      },
      {
        "id": 7291,
        "content": [
          "Slope of tangent line"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 1821,
    "content": [
      "Which of the following is true about the zero(s) of a function $$f(x)$$?"
    ],
    "explanation": [
      "The Factor Theorem states that for a polynomial function $$f(x)$$, if $$f(a) = 0$$, then $$(x - a)$$ is a factor of $$f(x)$$.\n\nOption A correctly states this theorem (assuming $$f(x)$$ is a polynomial or in a context where the theorem applies).\n\nOption B is only true if $$a$$ is a zero of multiplicity at least 2 (remove).\n\nOption C is false; if $$f(a)$$ is defined, $$a$$ must be in the domain.\n\nOption D is false; $$f(a)=0$$ means $$a$$ is an x-intercept (a zero), while the y-intercept is the value of $$f(0)$$."
    ],
    "year": "YEAR_2015",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7292,
        "content": [
          "If $$f(a)=0$$, then $$x - a$$ is a factor for $$f(x)$$."
        ],
        "isCorrect": true
      },
      {
        "id": 7293,
        "content": [
          "If $$f(a)=0$$, then $$(x - a)^2$$ is a factor of $$f(x)$$."
        ],
        "isCorrect": false
      },
      {
        "id": 7294,
        "content": [
          "If $$f(a)=0$$, then a is not necessarily in the domain."
        ],
        "isCorrect": false
      },
      {
        "id": 7295,
        "content": [
          "If $$f(a)=0$$, then $$y=a$$ is the y-intercept."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Polynomial Function"
  },
  {
    "id": 2618,
    "content": [
      "What is the locus all points in the plane in which the sum of the distances from two fixed points is constant?"
    ],
    "explanation": [
      "By definition, an ellipse is the set of all points in a plane, the sum of whose distances from two fixed points, called the foci, is a constant."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10480,
        "content": [
          "Hyperbola"
        ],
        "isCorrect": false
      },
      {
        "id": 10481,
        "content": [
          "Parabola"
        ],
        "isCorrect": false
      },
      {
        "id": 10482,
        "content": [
          "Ellipse"
        ],
        "isCorrect": true
      },
      {
        "id": 10483,
        "content": [
          "Circle"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 2619,
    "content": [
      "The radian measure of an angle of 120° is equal to:"
    ],
    "explanation": [
      "To convert an angle from degrees to radians, you multiply the degree measure by $$\\frac{\\pi}{180°}$$.\n$$\n120° \\times \\frac{\\pi}{180°} = \\frac{120\\pi}{180} = \\frac{2\\pi}{3} \\text{ radians}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10484,
        "content": [
          "$$\\frac{2\\pi}{3}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10485,
        "content": [
          "$$\\frac{\\pi}{4}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10486,
        "content": [
          "$$\\frac{\\pi}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10487,
        "content": [
          "$$\\frac{\\pi}{8}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 5,
    "unitName": "Introduction to Trigonometry"
  },
  {
    "id": 2620,
    "content": [
      "What is the surface area of a sphere with radius 6 cm?"
    ],
    "explanation": [
      "The formula for the surface area (A) of a sphere is $$A = 4\\pi r^2$$, where r is the radius.",
      "Given r = 6 cm:\n$$\nA = 4\\pi (6)^2 = 4\\pi (36) = 144\\pi \\text{ cm}^2\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10488,
        "content": [
          "24π cm²"
        ],
        "isCorrect": false
      },
      {
        "id": 10489,
        "content": [
          "36π cm²"
        ],
        "isCorrect": false
      },
      {
        "id": 10490,
        "content": [
          "48π cm²"
        ],
        "isCorrect": false
      },
      {
        "id": 10491,
        "content": [
          "144π cm²"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 2621,
    "content": [
      "Which of the following is the measure of an exterior angle of a 10 sided regular polygons?"
    ],
    "explanation": [
      "The sum of the exterior angles of any convex polygon is 360°. For a regular n-sided polygon, each exterior angle has the same measure, which is given by the formula\n$$\n\\frac{360°}{n}\n$$",
      "For a 10-sided polygon, n = 10.\n$$\n\\text{Exterior Angle} = \\frac{360°}{10} = 36°\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_POLYGONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10492,
        "content": [
          "72°"
        ],
        "isCorrect": false
      },
      {
        "id": 10493,
        "content": [
          "144°"
        ],
        "isCorrect": false
      },
      {
        "id": 10494,
        "content": [
          "180°"
        ],
        "isCorrect": false
      },
      {
        "id": 10495,
        "content": [
          "36°"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Regular Polygon"
  },
  {
    "id": 2622,
    "content": [
      "If the volume of a right circular cone is 64π cm³ and the diameter of its base is 8cm, what is the height of the cone?"
    ],
    "explanation": [
      "The volume (V) of a cone is given by the formula $$V = \\frac{1}{3}\\pi r^2 h$$, where r is the radius and h is the height.",
      "The diameter is 8 cm, so the radius r is 4 cm. The volume V is 64π cm³.\n$$\n64\\pi = \\frac{1}{3}\\pi (4)^2 h\n$$\n$$\n64\\pi = \\frac{16\\pi}{3} h\n$$\n$$\nh = \\frac{64\\pi \\times 3}{16\\pi} = 4 \\times 3 = 12 \\text{ cm}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10496,
        "content": [
          "4cm"
        ],
        "isCorrect": false
      },
      {
        "id": 10497,
        "content": [
          "12cm"
        ],
        "isCorrect": true
      },
      {
        "id": 10498,
        "content": [
          "8cm"
        ],
        "isCorrect": false
      },
      {
        "id": 10499,
        "content": [
          "3cm"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 2623,
    "content": [
      "What are the quotient and remainder respectively, when 75 is divided by 20?"
    ],
    "explanation": [
      "When we divide 75 by 20, we find how many times 20 fits completely into 75.\n$$\n75 = 20 \\times 3 + 15\n$$\n20 goes into 75 three times (3 × 20 = 60), with 15 left over. Therefore, the quotient is 3 and the remainder is 15."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_NUMBER_SYSTEM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10500,
        "content": [
          "3 and 15"
        ],
        "isCorrect": true
      },
      {
        "id": 10501,
        "content": [
          "4 and 5"
        ],
        "isCorrect": false
      },
      {
        "id": 10502,
        "content": [
          "15 and 3"
        ],
        "isCorrect": false
      },
      {
        "id": 10503,
        "content": [
          "2 and 19"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "The Number System"
  },
  {
    "id": 2624,
    "content": [
      "If f(x) = x² + px + 1 where f(0) and f(1) have opposite signs so that f has a root in (0, 1), then which one of the following number is a possible value p?"
    ],
    "explanation": [
      "According to the Intermediate Value Theorem, if f(0) and f(1) have opposite signs, there must be a root between 0 and 1.",
      "First, evaluate f(0):\n$$\nf(0) = 0^2 + p(0) + 1 = 1\n$$.\nSince f(0) is positive, f(1) must be negative for them to have opposite signs.",
      "Now, evaluate f(1):\n$$\nf(1) = 1^2 + p(1) + 1 = 2 + p\n$$\nSet f(1) < 0:\n$$\n2 + p < 0 \\Rightarrow p < -2\n$$\nAmong the given options, only -3 is less than -2."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10504,
        "content": [
          "-3"
        ],
        "isCorrect": true
      },
      {
        "id": 10505,
        "content": [
          "-2"
        ],
        "isCorrect": false
      },
      {
        "id": 10506,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 10507,
        "content": [
          "3"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2625,
    "content": [
      "In rolling a fair die, what is the probability of obtaining 3 or 5?"
    ],
    "explanation": [
      "A fair die has 6 possible outcomes: {1, 2, 3, 4, 5, 6}. The total number of possible outcomes is 6.",
      "The favorable outcomes are obtaining a 3 or a 5. There are 2 favorable outcomes.",
      "The probability is the ratio of favorable outcomes to the total number of outcomes:\n$$\nP(\\text{3 or 5}) = \\frac{2}{6} = \\frac{1}{3}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_PROBABILITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10508,
        "content": [
          "$$\\frac{1}{3}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10509,
        "content": [
          "$$\\frac{1}{4}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10510,
        "content": [
          "$$\\frac{1}{6}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10511,
        "content": [
          "$$\\frac{1}{2}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 8,
    "unitName": "Probability"
  },
  {
    "id": 2626,
    "content": [
      "Which one of the following is true?"
    ],
    "explanation": [
      "The arccosine function, arccos(x), is the inverse of the cosine function. The domain of an inverse function is the range of the original function. The range of cos(x) is [-1, 1]. Therefore, the domain of arccos(x) is [-1, 1]."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10512,
        "content": [
          "The range of arctangent function is [-π, π]."
        ],
        "isCorrect": false
      },
      {
        "id": 10513,
        "content": [
          "The range of arcsine function is (-∞, ∞)."
        ],
        "isCorrect": false
      },
      {
        "id": 10514,
        "content": [
          "The domain of arccosine function is [-1, 1]."
        ],
        "isCorrect": true
      },
      {
        "id": 10515,
        "content": [
          "The domain of arcsine function is [0, π]."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 5,
    "unitName": "Introduction to Trigonometry"
  },
  {
    "id": 2627,
    "content": [
      "The angle of depression of the top of a flag pole from the top of a building that is 40√3 m away from the flag pole is 30°. If the height of the flag pole is 10m, what is the height of the building?"
    ],
    "explanation": [
      "Let H be the building's height and h be the flagpole's height (10m). The horizontal distance is d = 40√3 m. The angle of depression from the building's top to the flagpole's top is 30°.",
      "This forms a right-angled triangle where the adjacent side is d and the opposite side is the difference in heights, x = H - h.\n$$\n\\tan(30°) = \\frac{\\text{opposite}}{\\text{adjacent}} = \\frac{H - h}{d}\n$$\n$$\n\\frac{1}{\\sqrt{3}} = \\frac{H - 10}{40\\sqrt{3}}\n$$\n$$\nH - 10 = \\frac{40\\sqrt{3}}{\\sqrt{3}} = 40\n$$\n$$\nH = 40 + 10 = 50 \\text{ m}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10516,
        "content": [
          "20√3 m"
        ],
        "isCorrect": false
      },
      {
        "id": 10517,
        "content": [
          "10(4√3 + 1) m"
        ],
        "isCorrect": false
      },
      {
        "id": 10518,
        "content": [
          "50 m"
        ],
        "isCorrect": true
      },
      {
        "id": 10519,
        "content": [
          "40 m"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 5,
    "unitName": "Introduction to Trigonometry"
  },
  {
    "id": 2628,
    "content": [
      "Let R = {(x, y)|y ≥ x² + 1 and y ≤ 5} be a relation. Then which one of the following defines the inverse of R?"
    ],
    "explanation": [
      "To find the inverse relation, R⁻¹, we interchange the roles of x and y in the defining rule of the relation R.",
      "The relation R is defined by the conditions: y ≥ x² + 1 and y ≤ 5.",
      "Interchanging x and y, we get the conditions for R⁻¹: x ≥ y² + 1 and x ≤ 5.",
      "Therefore, the inverse relation is R⁻¹ = {(x, y)|x ≥ y² + 1, x ≤ 5}."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10520,
        "content": [
          "{(x, y)|x ≥ y² + 1, x ≤ 5}"
        ],
        "isCorrect": true
      },
      {
        "id": 10521,
        "content": [
          "{(x, y)|x ≥ y² + 1, x ≥ 5}"
        ],
        "isCorrect": false
      },
      {
        "id": 10522,
        "content": [
          "{(x, y)|x ≤ y² + 1, x ≥ 5}"
        ],
        "isCorrect": false
      },
      {
        "id": 10523,
        "content": [
          "{(x, y)|x > y² - 1, x ≤ 5}"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2629,
    "content": [
      "Given matrices\n$$\nA = \\begin{pmatrix} 2 & 0 & 5 \\\\ 3 & 1 & 4 \\\\ 0 & 6 & -2 \\end{pmatrix}\n$$",
      "and\n$$\nB = \\begin{pmatrix} 1 & 3 & 0 \\\\ 6 & 5 & 2 \\\\ 9 & 7 & 0 \\end{pmatrix}\n$$",
      "Which one of the following is A - B?"
    ],
    "explanation": [
      "To subtract two matrices, we subtract their corresponding elements.\n$$\nA - B = \\begin{pmatrix} 2-1 & 0-3 & 5-0 \\\\ 3-6 & 1-5 & 4-2 \\\\ 0-9 & 6-7 & -2-0 \\end{pmatrix} = \\begin{pmatrix} 1 & -3 & 5 \\\\ -3 & -4 & 2 \\\\ -9 & -1 & -2 \\end{pmatrix}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10524,
        "content": [
          "$$\n\\begin{pmatrix} 1 & 3 & 5 \\\\ -3 & -4 & 2 \\\\ 9 & 1 & 2 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10525,
        "content": [
          "$$\n\\begin{pmatrix} 1 & -3 & -5 \\\\ -3 & -4 & 2 \\\\ 9 & 1 & 2 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10526,
        "content": [
          "$$\n\\begin{pmatrix} 1 & 3 & 5 \\\\ -3 & -4 & -2 \\\\ -9 & 1 & 2 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10527,
        "content": [
          "$$\n\\begin{pmatrix} 1 & -3 & 5 \\\\ -3 & -4 & 2 \\\\ -9 & -1 & -2 \\end{pmatrix}\n$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Matrices"
  },
  {
    "id": 2630,
    "content": [
      "In order to find point P in space one can start from the origin O(0, 0, 0); move 5 units in the direction of negative x-axis, then move 5 units in the direction of positive y-axis and finally move 5 units in the direction of negative z-axis. Which one of the following is the ordered triple of numbers represented by point P?"
    ],
    "explanation": [
      "Starting from the origin (0, 0, 0):",
      "- Moving 5 units in the negative x-axis direction makes the x-coordinate -5.",
      "- Moving 5 units in the positive y-axis direction makes the y-coordinate 5.",
      "- Moving 5 units in the negative z-axis direction makes the z-coordinate -5.",
      "The resulting point P is (-5, 5, -5)."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_VECTORS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10528,
        "content": [
          "(5, 5, 5)"
        ],
        "isCorrect": false
      },
      {
        "id": 10529,
        "content": [
          "(-5, 5, -5)"
        ],
        "isCorrect": true
      },
      {
        "id": 10530,
        "content": [
          "(5, -5, 5)"
        ],
        "isCorrect": false
      },
      {
        "id": 10531,
        "content": [
          "(-5, -5, 5)"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 8,
    "unitName": "Vectors in 2D"
  },
  {
    "id": 2631,
    "content": [
      "Which one of the following quantities represents a vector?"
    ],
    "explanation": [
      "A vector quantity is a physical quantity that has both magnitude and direction. A scalar quantity has only magnitude.",
      "Weight is a force (mass × acceleration due to gravity) and acts in a specific direction (downwards). Speed, volume, and width are all scalar quantities as they are described by magnitude alone."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_VECTORS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10532,
        "content": [
          "Weight of an object"
        ],
        "isCorrect": true
      },
      {
        "id": 10533,
        "content": [
          "Speed of a motorbike"
        ],
        "isCorrect": false
      },
      {
        "id": 10534,
        "content": [
          "Volume of a box"
        ],
        "isCorrect": false
      },
      {
        "id": 10535,
        "content": [
          "The width of your bedroom"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 8,
    "unitName": "Vectors in 2D"
  },
  {
    "id": 2632,
    "content": [
      "Which one of the following is the derivative of f(x) = tanx + 3ˣ?"
    ],
    "explanation": [
      "We find the derivative term by term:\n$$\n\\frac{d}{dx}(\\tan x) = \\sec^2 x\n$$\nBecause the derivative of tan x is sec² x\n$$\n\\frac{d}{dx}(3^x) = 3^x \\ln 3\n$$\nBecause for any base (a>0),\n$$\n\\frac{d}{dx}(a^x) = a^x \\ln a\n$$\nAdding both results:\n$$\nf'(x) = \\sec^2 x + 3^x \\ln 3\n$$\nNOTE: We slightly edited the question given on the paper since there were no answers, option D was sec²x + 3ˣ instead of sec²x + 3ˣIn 3."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10536,
        "content": [
          "sec²x + 3ˣ ln x"
        ],
        "isCorrect": false
      },
      {
        "id": 10537,
        "content": [
          "-csc²x + 3ˣ ln x"
        ],
        "isCorrect": false
      },
      {
        "id": 10538,
        "content": [
          "-tan x + 3ˣ ln x"
        ],
        "isCorrect": false
      },
      {
        "id": 10539,
        "content": [
          "sec²x + 3ˣIn 3"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2633,
    "content": [
      "Which one of the following points is, inside the sphere with equation x² + y² + z² = 5?"
    ],
    "explanation": [
      "A point (x, y, z) is inside the sphere x² + y² + z² = r² if the expression x² + y² + z² is less than r². In this case, r² = 5.",
      "We test each point:",
      "For (1, 1, 1): 1² + 1² + 1² = 1 + 1 + 1 = 3. Since 3 < 5, this point is inside the sphere.",
      "For the other points, the sum of the squares is greater than 5."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10540,
        "content": [
          "(1, -2, 2)"
        ],
        "isCorrect": false
      },
      {
        "id": 10541,
        "content": [
          "(1, 1, 1)"
        ],
        "isCorrect": true
      },
      {
        "id": 10542,
        "content": [
          "(1, 2, 3)"
        ],
        "isCorrect": false
      },
      {
        "id": 10543,
        "content": [
          "(0, -2, 3)"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 2634,
    "content": [
      "Which one of the following gives the polar form of the complex number z = 2 - 2√3i?"
    ],
    "explanation": [
      "For a complex number z = a + bi, the polar form is r(cosθ + i sinθ).",
      "The modulus is\n$$\nr = \\sqrt{a^2 + b^2} = \\sqrt{2^2 + (-2\\sqrt{3})^2} = \\sqrt{4 + 12} = \\sqrt{16} = 4\n$$\nThe argument θ is found from tanθ = b/a = -2√3 / 2 = -√3.",
      "Since the point (2, -2√3) is in the fourth quadrant, the angle is\n$$\n\\theta = \\frac{5\\pi}{3}\n$$\nThus, the polar form is\n$$\nz = 4(\\cos\\frac{5\\pi}{3} + i\\sin\\frac{5\\pi}{3})\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10544,
        "content": [
          "$$\n4(\\cos\\frac{5\\pi}{3} + i\\sin\\frac{5\\pi}{3})\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10545,
        "content": [
          "$$\n4(\\cos\\frac{\\pi}{4} + i\\sin\\frac{\\pi}{4})\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10546,
        "content": [
          "$$\n4(\\cos\\frac{3\\pi}{4} + i\\sin\\frac{3\\pi}{4})\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10547,
        "content": [
          "$$\n4(\\cos\\frac{\\pi}{3} + i\\sin\\frac{\\pi}{3})\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2635,
    "content": [
      "If a = (4, 3, 2) and b = (1, 2, -3) are two vectors in space, then which one of the following is NOT correct?"
    ],
    "explanation": [
      "Let’s evaluate the expression in option D:\n$$\na - 2b = (4, 3, 2) - 2(1, 2, -3)\n$$\n$$\n= (4, 3, 2) - (2, 4, -6)\n$$\n$$\n= (4-2, 3-4, 2-(-6)) = (2, -1, 8)\n$$\nThe statement in option D claims the result is (2, 1, 8), which is incorrect because the y-component should be -1, not 1. The other options are correct."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_VECTORS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10548,
        "content": [
          "a + b = (5, 5, -1)"
        ],
        "isCorrect": false
      },
      {
        "id": 10549,
        "content": [
          "a + 2b = (6, 7, -4)"
        ],
        "isCorrect": false
      },
      {
        "id": 10550,
        "content": [
          "b - a = (-3, -1, -5)"
        ],
        "isCorrect": false
      },
      {
        "id": 10551,
        "content": [
          "a - 2b = (2, 1, 8)"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 8,
    "unitName": "Vectors in 2D"
  },
  {
    "id": 2636,
    "content": [
      "What is the product of the two complex number z = 2 - 3i and w = 5 + 2i?"
    ],
    "explanation": [
      "To find the product, we multiply the complex numbers using the distributive property (like FOIL).\n$$\nzw = (2 - 3i)(5 + 2i) = 2(5) + 2(2i) - 3i(5) - 3i(2i)\n$$\n$$\n= 10 + 4i - 15i - 6i^2\n$$\nSince i² = -1:\n$$\n= 10 - 11i - 6(-1) = 10 - 11i + 6 = 16 - 11i\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10552,
        "content": [
          "16 + 11i"
        ],
        "isCorrect": false
      },
      {
        "id": 10553,
        "content": [
          "4 - 11i"
        ],
        "isCorrect": false
      },
      {
        "id": 10554,
        "content": [
          "16 - 11i"
        ],
        "isCorrect": true
      },
      {
        "id": 10555,
        "content": [
          "29"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2637,
    "content": [
      "Which of the following is true about the Arithmetic Mean of a given data?"
    ],
    "explanation": [
      "The arithmetic mean is calculated by summing all values and dividing by the count of values. Because every value contributes to the sum, an extremely large or small value (an outlier) can significantly alter the result, pulling the mean towards it. Therefore, the mean is sensitive to extreme values."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10556,
        "content": [
          "It is affected by extreme values"
        ],
        "isCorrect": true
      },
      {
        "id": 10557,
        "content": [
          "There can be two means for a given data."
        ],
        "isCorrect": false
      },
      {
        "id": 10558,
        "content": [
          "It can also be used for qualitative data."
        ],
        "isCorrect": false
      },
      {
        "id": 10559,
        "content": [
          "It can be obtained even in the absence of some of the values in the data."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 2638,
    "content": [
      "In ΔABC, if AB = 10 units, BC = 14 units and AC = 8 units, then the area of the triangle is"
    ],
    "explanation": [
      "We can use Heron's formula to find the area of a triangle when all three side lengths are known.",
      "First, calculate the semi-perimeter (s):\n$$\ns = \\frac{a+b+c}{2} = \\frac{14+8+10}{2} = \\frac{32}{2} = 16\n$$\nThen, apply Heron's formula for the area (A):\n$$\nA = \\sqrt{s(s-a)(s-b)(s-c)}\n$$\n$$\nA = \\sqrt{16(16-14)(16-8)(16-10)}\n$$\n$$\nA = \\sqrt{16 \\times 2 \\times 8 \\times 6}\n$$\n$$\nA = \\sqrt{16 \\times 96} = \\sqrt{1536}\n$$\n$$\nA = \\sqrt{256 \\times 6} = 16\\sqrt{6} \\ \\text{square units}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10560,
        "content": [
          "10√6 square unit"
        ],
        "isCorrect": false
      },
      {
        "id": 10561,
        "content": [
          "16√6 square unit"
        ],
        "isCorrect": true
      },
      {
        "id": 10562,
        "content": [
          "16√3 square unit"
        ],
        "isCorrect": false
      },
      {
        "id": 10563,
        "content": [
          "16√2 square unit"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 2639,
    "content": [
      "$$\n\\int(\\frac{1}{\\sqrt{x}} - e^{-3x} + \\frac{5}{x^2}) dx\n$$\nis equal to:"
    ],
    "explanation": [
      "We integrate the function term by term after rewriting it with power notation:\n$$\n\\int(x^{-1/2} - e^{-3x} + 5x^{-2}) dx\n$$\n$$\n\\int x^{-1/2} dx = \\frac{x^{1/2}}{1/2} = 2\\sqrt{x}\n$$\n$$\n\\int -e^{-3x} dx = -(\\frac{e^{-3x}}{-3}) = \\frac{e^{-3x}}{3}\n$$\n$$\n\\int 5x^{-2} dx = 5(\\frac{x^{-1}}{-1}) = -\\frac{5}{x}\n$$\nCombining the results and adding the constant of integration c gives:\n$$\n2\\sqrt{x} + \\frac{e^{-3x}}{3} - \\frac{5}{x} + c\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10564,
        "content": [
          "$$\n2\\sqrt{x} + \\frac{e^{-3x}}{3} - \\frac{5}{x} + c\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10565,
        "content": [
          "$$\n2\\sqrt{x} + \\frac{e^{-3x}}{3} + \\frac{5}{x} + c\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10566,
        "content": [
          "$$\n2\\sqrt{x} - \\frac{e^{-3x}}{3} - \\frac{5}{x} + c\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10567,
        "content": [
          "$$\n2\\sqrt{x} - \\frac{e^{-3x}}{3} + \\frac{5}{x} + c\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2640,
    "content": [
      "The graph of a certain relation R is represented by the shaded region shown on the figure below.",
      "images/maths/year_2014_na/q23_1_background.png",
      "Which one of the following pairs of sets respectively gives the domain and range of this relation?"
    ],
    "explanation": [
      "From the graph:\n- The shaded region extends infinitely to the **left** (x ≤ 2), so the **domain** is {x | x ≤ 2}.\n- The shaded region also extends infinitely **upward and downward**, meaning all y-values are included. So the **range** is ℝ.",
      "**Correct answer:** {x | x ≤ 2} and ℝ"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2014_na/q23_1_background.png"
    ],
    "choices": [
      {
        "id": 10568,
        "content": [
          "{x|x ≤ 2} and {y|y ≤ 6}"
        ],
        "isCorrect": false
      },
      {
        "id": 10569,
        "content": [
          "{x|x ≤ 2} and R"
        ],
        "isCorrect": true
      },
      {
        "id": 10570,
        "content": [
          "R and {y|y ≤ 2}"
        ],
        "isCorrect": false
      },
      {
        "id": 10571,
        "content": [
          "R and R"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2641,
    "content": [
      "Let f be a continuous function on [a, b]. Then which of the following is NOT true?"
    ],
    "explanation": [
      "For a continuous function (f) on ([a, b]), the basic properties of definite integrals are:",
      "**Reversal of limits:**\n$$\n\\int_{a}^{b} f(x),dx = -\\int_{b}^{a} f(x),dx\n$$\n**Constant multiple rule:**\n$$\n\\int_{a}^{b} k f(x),dx = k \\int_{a}^{b} f(x),dx\n$$\n**Additivity over intervals:**",
      "If (a<c<b),\n$$\n\\int_{a}^{b} f(x),dx = \\int_{a}^{c} f(x),dx + \\int_{c}^{b} f(x),dx\n$$\nThe option C uses a minus sign:\n$$\n\\int_{a}^{b} f(x),dx = \\int_{a}^{c} f(x),dx - \\int_{b}^{c} f(x),dx\n$$\nWhich is incorrect because\n$$\n\\int_{b}^{c} f(x),dx = -\\int_{c}^{b} f(x),dx\n$$\nSo the correct form should have a plus sign.",
      "**Zero-width interval:**\n$$\n\\int_{c}^{c} f(x),dx = 0\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10572,
        "content": [
          "$$\n\\int_{a}^{b} f(x)dx = -\\int_{b}^{a} f(x)dx\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10573,
        "content": [
          "$$\n\\int_{a}^{b} kf(x)dx = k\\int_{a}^{b} f(x)dx \\ \\text{for any constant k}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10574,
        "content": [
          "$$\n\\int_{a}^{b} f(x)dx = \\int_{a}^{c} f(x)dx - \\int_{b}^{c} f(x)dx \\ \\text{for any c in (a, b)}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10575,
        "content": [
          "$$\n\\int_{c}^{c} f(x)dx = 0   \\ \\text{for any c in (a, b)}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2642,
    "content": [
      "What is the value of $$\\int_{0}^{1} xe^x dx$$"
    ],
    "explanation": [
      "This integral is solved using integration by parts, where\n$$\n\\int u dv = uv - \\int v du\n$$",
      "Let u = x and dv = eˣ dx. Then du = dx and v = eˣ.\n$$\n\\int xe^x dx = x e^x - \\int e^x dx = x e^x - e^x\n$$\nNow, evaluate the definite integral from 0 to 1:\n$$\n[x e^x - e^x]_{0}^{1} = (1 \\cdot e^1 - e^1) - (0 \\cdot e^0 - e^0)\n$$\n$$\n= (e - e) - (0 - 1) = 0 - (-1) = 1\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10576,
        "content": [
          "-e"
        ],
        "isCorrect": false
      },
      {
        "id": 10577,
        "content": [
          "e"
        ],
        "isCorrect": false
      },
      {
        "id": 10578,
        "content": [
          "1"
        ],
        "isCorrect": true
      },
      {
        "id": 10579,
        "content": [
          "-1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2643,
    "content": [
      "The simplified form of the expression\n$$\n\\frac{6\\sqrt{20} - 3\\sqrt{45}}{3\\sqrt{75}} \\ \\text{is:}\n$$"
    ],
    "explanation": [
      "First, simplify each radical term in the expression.",
      "√20 = √(4⋅5) = 2√5",
      "√45 = √(9⋅5) = 3√5",
      "√75 = √(25⋅3) = 5√3",
      "Substitute these values back into the expression:\n$$\n\\frac{6(2\\sqrt{5}) - 3(3\\sqrt{5})}{3(5\\sqrt{3})} = \\frac{12\\sqrt{5} - 9\\sqrt{5}}{15\\sqrt{3}}\n$$\n$$\n= \\frac{3\\sqrt{5}}{15\\sqrt{3}} = \\frac{\\sqrt{5}}{5\\sqrt{3}}\n$$\nRationalize the denominator by multiplying the numerator and denominator by √3:\n$$\n\\frac{\\sqrt{5} \\cdot \\sqrt{3}}{5\\sqrt{3} \\cdot \\sqrt{3}} = \\frac{\\sqrt{15}}{5 \\cdot 3} = \\frac{\\sqrt{15}}{15}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_NUMBER_SYSTEM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10580,
        "content": [
          "$$\\sqrt{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10581,
        "content": [
          "$$\\frac{\\sqrt{15}}{15}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10582,
        "content": [
          "$$\\frac{1}{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10583,
        "content": [
          "$$5$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "The Number System"
  },
  {
    "id": 2644,
    "content": [
      "Which one of the following sets is the symmetric difference, A Δ B, of the sets A = {1, 3, 5, 6, 8, 10} and B = {2, 5, 8, 11}?"
    ],
    "explanation": [
      "The symmetric difference of two sets A and B, denoted A Δ B, is the set of elements which are in either of the sets, but not in their intersection. It can be calculated as (A ∪ B) \\ (A ∩ B).",
      "A ∪ B = {1, 2, 3, 5, 6, 8, 10, 11}",
      "A ∩ B = {5, 8}",
      "A Δ B = {1, 2, 3, 5, 6, 8, 10, 11} \\ {5, 8} = {1, 2, 3, 6, 10, 11}."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SETS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10584,
        "content": [
          "{1, 2, 3, 5, 6, 8, 10, 11}"
        ],
        "isCorrect": false
      },
      {
        "id": 10585,
        "content": [
          "{2, 11}"
        ],
        "isCorrect": false
      },
      {
        "id": 10586,
        "content": [
          "{1, 2, 3, 6, 10, 11}"
        ],
        "isCorrect": true
      },
      {
        "id": 10587,
        "content": [
          "{1, 3, 6, 10}"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 2645,
    "content": [
      "Which of the following is the variance of the data given as: 2, 3, 4, 5, 7."
    ],
    "explanation": [
      "First, calculate the mean (μ) of the data:\n$$\n\\mu = \\frac{2+3+4+5+7}{5} = \\frac{21}{5} = 4.2\n$$\nNext, calculate the sum of the squared differences from the mean:\n$$\n\\Sigma(x_i - \\mu)^2 = (2-4.2)^2 + (3-4.2)^2 + (4-4.2)^2 + (5-4.2)^2 + (7-4.2)^2\n$$\n$$\n= (-2.2)^2 + (-1.2)^2 + (-0.2)^2 + (0.8)^2 + (2.8)^2\n$$\n$$\n= 4.84 + 1.44 + 0.04 + 0.64 + 7.84 = 14.8\n$$\nThe variance (σ²) is the sum of squared differences divided by the number of data points (N):\n$$\n\\sigma^2 = \\frac{14.8}{5} = 2.96\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10588,
        "content": [
          "2.46"
        ],
        "isCorrect": false
      },
      {
        "id": 10589,
        "content": [
          "2.96"
        ],
        "isCorrect": true
      },
      {
        "id": 10590,
        "content": [
          "3.06"
        ],
        "isCorrect": false
      },
      {
        "id": 10591,
        "content": [
          "3.70"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 7,
    "unitName": "Statistics"
  },
  {
    "id": 2646,
    "content": [
      "Which of the following pairs of events are dependent?"
    ],
    "explanation": [
      "Two events are dependent if the outcome of the first event affects the outcome of the second event.",
      "When drawing two cards without replacement, the outcome of the first draw changes the composition of the deck for the second draw. For example, the probability of drawing a King on the second draw depends on whether a King was drawn on the first draw. This makes the events dependent."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_PROBABILITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10592,
        "content": [
          "Tossing two coins simultaneously and obtaining head from one and tail from the other."
        ],
        "isCorrect": false
      },
      {
        "id": 10593,
        "content": [
          "Drawing two cards one after the other from a well shuffled pack of cards without replacement."
        ],
        "isCorrect": true
      },
      {
        "id": 10594,
        "content": [
          "Drawing two balls successively from a box containing balls having the same size and shape with replacement."
        ],
        "isCorrect": false
      },
      {
        "id": 10595,
        "content": [
          "Any events obtaining from tossing a coin and rolling a die at the same time."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 8,
    "unitName": "Probability"
  },
  {
    "id": 2647,
    "content": [
      "If $$\\lim_{x \\to 2} f(x) = 6$$ and $$\\lim_{x \\to 2} g(x) = -9$$, then $$\\lim_{x \\to 2} (\\frac{f-g}{2f-7})(x)$$ ="
    ],
    "explanation": [
      "We use the properties of limits. The limit of a quotient is the quotient of the limits, provided the denominator's limit is not zero.\n$$\n\\lim_{x \\to 2} (\\frac{f(x)-g(x)}{2f(x)-7}) = \\frac{\\lim_{x \\to 2} f(x) - \\lim_{x \\to 2} g(x)}{2\\lim_{x \\to 2} f(x) - 7}\n$$\n$$\n= \\frac{6 - (-9)}{2(6) - 7} = \\frac{15}{12 - 7} = \\frac{15}{5} = 3\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10596,
        "content": [
          "3"
        ],
        "isCorrect": true
      },
      {
        "id": 10597,
        "content": [
          "-3"
        ],
        "isCorrect": false
      },
      {
        "id": 10598,
        "content": [
          "15"
        ],
        "isCorrect": false
      },
      {
        "id": 10599,
        "content": [
          "-15"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2648,
    "content": [
      "Let f and g be two functions. Which one of the following statements is true about f or g?"
    ],
    "explanation": [
      "This statement is a fundamental theorem in calculus. Differentiability is a stronger condition than continuity. If a function has a derivative at a point, it must be continuous at that point.",
      "The other statements are false: A) f(x)=|x| is not differentiable at x=0; C) the tangent line would be y=f(a); D) f/g is only differentiable if g(a) is not zero."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10600,
        "content": [
          "The line y = 0 is the a tangent line to the graph of f(x) = |x| at (0, 0)."
        ],
        "isCorrect": false
      },
      {
        "id": 10601,
        "content": [
          "If f is differentiable at a, then it is continuous at a."
        ],
        "isCorrect": true
      },
      {
        "id": 10602,
        "content": [
          "If f'(a) = 0, then the tangent line to the graph of f at (a, f(a)) is y = a."
        ],
        "isCorrect": false
      },
      {
        "id": 10603,
        "content": [
          "If f and g are differentiable at a, then f/g is differentiable at a."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2649,
    "content": [
      "What is the value of a for which the function defined by,\n$$\nf(x) = \\begin{cases} ax + 3, & \\text{for } x \\geq 1 \\\\ x^2 - 2x + 3, & \\text{for } x < 1 \\end{cases}\n$$\nis continuous at 1?"
    ],
    "explanation": [
      "For a function to be continuous at a point x=c, the limit as x approaches c from the left must equal the limit as x approaches c from the right, and both must equal the function's value at c.",
      "At x=1:",
      "Value at 1:\n$$\nf(1) = a(1) + 3 = a + 3\n$$\nLimit from the left (x<1):\n$$\n\\lim_{x \\to 1^-} (x^2 - 2x + 3) = 1^2 - 2(1) + 3 = 2\n$$\nFor continuity, f(1) must equal the limit.\n$$\na + 3 = 2 \\implies a = -1\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10604,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 10605,
        "content": [
          "-1"
        ],
        "isCorrect": true
      },
      {
        "id": 10606,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 10607,
        "content": [
          "4"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2650,
    "content": [
      "What is the derivative of the function $$f(x) = \\frac{xe^x}{\\cos x}$$ at x = 0?"
    ],
    "explanation": [
      "We use the quotient rule for derivatives:\n$$\n(\\frac{u}{v})' = \\frac{u'v - uv'}{v^2}\n$$",
      "Let u = xeˣ and v = cos(x).",
      "Using the product rule for u: u' = (1)eˣ + x(eˣ) = eˣ(1+x).",
      "And v' = -sin(x).\n$$\nf'(x) = \\frac{e^x(1+x)\\cos x - xe^x(-\\sin x)}{(\\cos x)^2}\n$$\nNow evaluate at x=0:\n$$\nf'(0) = \\frac{e^0(1+0)\\cos 0 - 0 \\cdot e^0(-\\sin 0)}{(\\cos 0)^2}\n$$\n$$\n= \\frac{1(1)(1) - 0}{1^2} = 1\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10608,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 10609,
        "content": [
          "-1"
        ],
        "isCorrect": false
      },
      {
        "id": 10610,
        "content": [
          "1"
        ],
        "isCorrect": true
      },
      {
        "id": 10611,
        "content": [
          "0"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2651,
    "content": [
      "Which of the following is true about bounded sequence?"
    ],
    "explanation": [
      "This is the Monotone Convergence Theorem, a fundamental result in real analysis. It states that if a sequence is both monotone (either non-decreasing or non-increasing) and bounded, then it must converge to a limit. The other statements are incorrect."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10612,
        "content": [
          "Every bounded sequence is convergent."
        ],
        "isCorrect": false
      },
      {
        "id": 10613,
        "content": [
          "Every increasing bounded sequence converges to the greatest lower bound of the sequence."
        ],
        "isCorrect": false
      },
      {
        "id": 10614,
        "content": [
          "Every decreasing bounded sequence converges to the least upper bound of the sequence."
        ],
        "isCorrect": false
      },
      {
        "id": 10615,
        "content": [
          "Every monotone bounded sequence converges."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2652,
    "content": [
      "Suppose f is a twice continuously differentiable function and f''(3) = 5. If g(x) = f(2x + 3), then the second derivative of g at 0 is equal to:"
    ],
    "explanation": [
      "We need to find g''(0). We use the chain rule twice.",
      "First derivative of g(x):\n$$\ng'(x) = f'(2x+3) \\cdot \\frac{d}{dx}(2x+3)\n$$\n$$\n= 2f'(2x+3)\n$$\nSecond derivative of g(x):\n$$\ng''(x) = 2 \\cdot f''(2x+3) \\cdot \\frac{d}{dx}(2x+3)\n$$\n$$\n= 2 \\cdot f''(2x+3) \\cdot 2 = 4f''(2x+3)\n$$\nNow, we evaluate g''(x) at x=0:\n$$\ng''(0) = 4f''(2(0)+3) = 4f''(3)\n$$\nGiven f''(3) = 5, we have:\n$$\ng''(0) = 4 \\times 5 = 20\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10616,
        "content": [
          "40"
        ],
        "isCorrect": false
      },
      {
        "id": 10617,
        "content": [
          "20"
        ],
        "isCorrect": true
      },
      {
        "id": 10618,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 10619,
        "content": [
          "10"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2653,
    "content": [
      "If f and g are continuous functions at a, then which of the following functions may NOT be continuous at a?"
    ],
    "explanation": [
      "The sum, difference, and product of continuous functions are also continuous.",
      "Therefore, 2f+3g, fg, and f-2g are all continuous at a.",
      "The quotient f/g is continuous at a only if the denominator g(a) is not equal to zero. If g(a) = 0, the function f/g is undefined at a and therefore not continuous."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10620,
        "content": [
          "2f + 3g"
        ],
        "isCorrect": false
      },
      {
        "id": 10621,
        "content": [
          "fg"
        ],
        "isCorrect": false
      },
      {
        "id": 10622,
        "content": [
          "f/g"
        ],
        "isCorrect": true
      },
      {
        "id": 10623,
        "content": [
          "f - 2g"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2654,
    "content": [
      "Let f be a continuous function on R and c be a number in the domain of f. Which one of the following must be true about the function?"
    ],
    "explanation": [
      "According to Fermat's Theorem on local extrema, if a function f has a local minimum or maximum at a point c and is differentiable at c, then its derivative at that point must be zero (f'(c) = 0).",
      "The other statements are not always true: A) is false if the absolute max is at an endpoint; B) requires a change in concavity; D) a critical point could be a saddle point (like f(x)=x³ at c=0)."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10624,
        "content": [
          "An absolute maximum value of f which is attained at a critical number is also a local maximum value of f."
        ],
        "isCorrect": false
      },
      {
        "id": 10625,
        "content": [
          "If f''(c) = 0, then (c, f(c)) is an inflection point of f."
        ],
        "isCorrect": false
      },
      {
        "id": 10626,
        "content": [
          "If f(c) is a local minimum value of f, then f'(c) = 0."
        ],
        "isCorrect": true
      },
      {
        "id": 10627,
        "content": [
          "If c is a critical number of f, then f(c) is a local extreme value of f."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2655,
    "content": [
      "What is the seventh term of an arithmetic sequence whose third term is -4 and common difference is 5?"
    ],
    "explanation": [
      "The formula for the nth term of an arithmetic sequence is aₙ = a₁ + (n-1)d.",
      "Alternatively, we can relate two terms: aₙ = aₘ + (n-m)d.",
      "We are given a₃ = -4, d = 5, and we want to find a₇.",
      "Using the second formula with n=7 and m=3:\n$$\na_7 = a_3 + (7-3)d = -4 + (4)(5) = -4 + 20 = 16\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10628,
        "content": [
          "15"
        ],
        "isCorrect": false
      },
      {
        "id": 10629,
        "content": [
          "-15"
        ],
        "isCorrect": false
      },
      {
        "id": 10630,
        "content": [
          "16"
        ],
        "isCorrect": true
      },
      {
        "id": 10631,
        "content": [
          "-16"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2656,
    "content": [
      "If the perimeter of a rectangle is 120 m, what are the length l and width w of the rectangle that maximizes its area?"
    ],
    "explanation": [
      "For a fixed perimeter, a rectangle has the maximum possible area when it is a square.",
      "Perimeter P = 2(l + w) = 120, which gives l + w = 60.",
      "The area A = l × w. To maximize A, we need l = w.",
      "Substituting l = w into the perimeter equation: w + w = 60, so 2w = 60, and w = 30 m.",
      "Therefore, l = 30 m as well. The dimensions are 30 m by 30 m."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_APPLICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10632,
        "content": [
          "l = 50 m and w = 10 m"
        ],
        "isCorrect": false
      },
      {
        "id": 10633,
        "content": [
          "l = 30 m and w = 30 m"
        ],
        "isCorrect": true
      },
      {
        "id": 10634,
        "content": [
          "l = 35 m and w = 25 m"
        ],
        "isCorrect": false
      },
      {
        "id": 10635,
        "content": [
          "l = 40 m and w = 20 m"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Mathematical Application in Business"
  },
  {
    "id": 2657,
    "content": [
      "The sum of the first 8 terms of a geometric sequence with first term 0.3 and common ratio 1/10 is equal to:"
    ],
    "explanation": [
      "The sum of the first n terms of a geometric sequence is given by the formula\n$$\nS_n = \\frac{a_1(1-r^n)}{1-r}\n$$\nHere, a₁ = 0.3 = 3/10, r = 1/10, and n = 8.\n$$\nS_8 = \\frac{\\frac{3}{10}(1 - (\\frac{1}{10})^8)}{1 - \\frac{1}{10}}\n$$\n$$\n= \\frac{\\frac{3}{10}(1 - \\frac{1}{10^8})}{\\frac{9}{10}}\n$$\n$$\nS_8 = \\frac{3}{10} \\times \\frac{10}{9} \\times (1 - \\frac{1}{10^8})\n$$\n$$\n= \\frac{1}{3} \\times (\\frac{10^8 - 1}{10^8})\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10636,
        "content": [
          "$$\n\\frac{3}{10}(\\frac{10^8 - 1}{10^8})\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10637,
        "content": [
          "$$\n\\frac{1}{3}(\\frac{10^8 - 1}{10^8})\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10638,
        "content": [
          "$$\n\\frac{1}{3}(\\frac{10^8 - 1}{10^7})\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10639,
        "content": [
          "$$\n\\frac{3}{10}(\\frac{10^8 - 1}{10^9})\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2658,
    "content": [
      "Suppose f is a continuous function on an interval [a, b] and differentiable on (a, b) with the property f(a) = f(b). Which one of the following must be true?"
    ],
    "explanation": [
      "The conditions described are the premises for Rolle's Theorem. The conclusion of Rolle's Theorem is that there must be at least one point c in the open interval (a, b) where the derivative of the function is zero, i.e., f'(c) = 0. A point where the derivative is zero corresponds to a horizontal tangent line on the graph of the function."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10640,
        "content": [
          "The function has a zero in (a, b)."
        ],
        "isCorrect": false
      },
      {
        "id": 10641,
        "content": [
          "The function has minimum value in (a, b)."
        ],
        "isCorrect": false
      },
      {
        "id": 10642,
        "content": [
          "The function has maximum value in (a, b)."
        ],
        "isCorrect": false
      },
      {
        "id": 10643,
        "content": [
          "The graph of f has horizontal tangent line at (c, f(c)) for some c ∈ (a, b)."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2659,
    "content": [
      "The distance from the point P(3, 4) to the line L with equation: 3x + 4y - 5 = 0 is"
    ],
    "explanation": [
      "The distance from a point (x₀, y₀) to a line Ax + By + C = 0 is given by the formula:\n$$\nd = \\frac{|Ax_0 + By_0 + C|}{\\sqrt{A^2 + B^2}}\n$$\nHere, (x₀, y₀) = (3, 4) and the line is 3x + 4y - 5 = 0, so A=3, B=4, C=-5.\n$$\nd = \\frac{|3(3) + 4(4) - 5|}{\\sqrt{3^2 + 4^2}}\n$$\n$$\n= \\frac{|9 + 16 - 5|}{\\sqrt{9 + 16}} = \\frac{|20|}{\\sqrt{25}}\n$$\n$$\n= \\frac{20}{5} = 4 \\ \\text{units}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10644,
        "content": [
          "5 units"
        ],
        "isCorrect": false
      },
      {
        "id": 10645,
        "content": [
          "6 units"
        ],
        "isCorrect": false
      },
      {
        "id": 10646,
        "content": [
          "4 units"
        ],
        "isCorrect": true
      },
      {
        "id": 10647,
        "content": [
          "7 units"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 2660,
    "content": [
      "A line segment chord in an ellipse which passes through the center and perpendicular to the major axis is called:"
    ],
    "explanation": [
      "By definition, the minor axis of an ellipse is the line segment that passes through the center of the ellipse, is perpendicular to the major axis, and has its endpoints on the ellipse."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10648,
        "content": [
          "Semi-major axis"
        ],
        "isCorrect": false
      },
      {
        "id": 10649,
        "content": [
          "Minor axis"
        ],
        "isCorrect": true
      },
      {
        "id": 10650,
        "content": [
          "Eccentricity"
        ],
        "isCorrect": false
      },
      {
        "id": 10651,
        "content": [
          "Latus rectum"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 2661,
    "content": [
      "If A is a 3 × 3 matrix with det(A) = 5, then what is the determinant of 2Aᵀ?"
    ],
    "explanation": [
      "We use two properties of determinants:",
      "1. det(kA) = kⁿ det(A), where n is the dimension of the square matrix A.",
      "2. det(Aᵀ) = det(A), the determinant of a matrix is equal to the determinant of its transpose.",
      "Given A is a 3x3 matrix, so n=3.\n$$\n\\det(2A^T) = 2^3 \\det(A^T) = 8 \\det(A) = 8 \\times 5 = 40\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10652,
        "content": [
          "10"
        ],
        "isCorrect": false
      },
      {
        "id": 10653,
        "content": [
          "2/5"
        ],
        "isCorrect": false
      },
      {
        "id": 10654,
        "content": [
          "40"
        ],
        "isCorrect": true
      },
      {
        "id": 10655,
        "content": [
          "30"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Determinants and Their Properties"
  },
  {
    "id": 2662,
    "content": [
      "Which one of the following is the augmented matrix associated to the system of equations\n$$\n\\begin{cases}\n2x + y + 3z = 4 \\\\\nx - z = 1 \\\\\n-4x + y - 3 = 0\n\\end{cases}\n$$"
    ],
    "explanation": [
      "First, rewrite each equation in the standard form Ax + By + Cz = D.",
      "1. 2x + y + 3z = 4",
      "2. x + 0y - z = 1",
      "3. -4x + y + 0z = 3",
      "The augmented matrix consists of the coefficients of the variables and the constant terms. Each row represents an equation.\n$$\n\\begin{pmatrix} 2 & 1 & 3 & | & 4 \\\\ 1 & 0 & -1 & | & 1 \\\\ -4 & 1 & 0 & | & 3 \\end{pmatrix}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10656,
        "content": [
          "$$\n\\begin{pmatrix} 3 & 2 & 1 & 1 \\\\ -1 & 1 & -1 & 3 \\\\ -1 & -4 & 1 & 4 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10657,
        "content": [
          "$$\n\\begin{pmatrix} 3 & 1 & 2 & 4 \\\\ -1 & 0 & 1 & 1 \\\\ -4 & 1 & -3 & 0 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10658,
        "content": [
          "$$\n\\begin{pmatrix} 1 & 2 & 3 & 4 \\\\ -1 & 1 & -1 & 1 \\\\ 1 & -4 & -1 & 3 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10659,
        "content": [
          "$$\n\\begin{pmatrix} 2 & 1 & 3 & 4 \\\\ 1 & 0 & -1 & 1 \\\\ -4 & 1 & 0 & 3 \\end{pmatrix}\n$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Matrices"
  },
  {
    "id": 2663,
    "content": [
      "Which of the following is NOT true about argument and validity?"
    ],
    "explanation": [
      "The definition of a valid argument is that if all of its premises are true, then its conclusion must also be true. It is impossible for a valid argument to have all true premises and a false conclusion. Statement (C) contradicts this definition; it describes an invalid argument."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10660,
        "content": [
          "An argument which is not valid is fallacy"
        ],
        "isCorrect": false
      },
      {
        "id": 10661,
        "content": [
          "The validity of an argument can be checked by using a truth table."
        ],
        "isCorrect": false
      },
      {
        "id": 10662,
        "content": [
          "In a valid argument, the conclusion may be true or false whenever all the premises are true."
        ],
        "isCorrect": true
      },
      {
        "id": 10663,
        "content": [
          "In a valid argument if all the premises are true then the conclusion must also be true."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 2664,
    "content": [
      "Which one of the following compound statements has a converse with truth value False?"
    ],
    "explanation": [
      "The converse of a conditional statement \"If p, then q\" is \"If q, then p\". A conditional statement is false only when the hypothesis (the 'if' part) is true and the conclusion (the 'then' part) is false.",
      "For statement (A), p is \"6 is a prime integer\" (False), and q is \"4 is an even number\" (True).",
      "The converse is \"If 4 is an even number, then 6 is a prime integer\". Here, the hypothesis is True and the conclusion is False. Therefore, the converse is False."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10664,
        "content": [
          "If 6 is a prime integer, then 4 is an even number."
        ],
        "isCorrect": true
      },
      {
        "id": 10665,
        "content": [
          "If man is immortal, then the earth does not rotate around the sun."
        ],
        "isCorrect": false
      },
      {
        "id": 10666,
        "content": [
          "If athlete Derartu Tulu was born on October 21, 1971, then 6 is prime."
        ],
        "isCorrect": false
      },
      {
        "id": 10667,
        "content": [
          "If man is mortal, then the earth does not rotate around the sun."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 2665,
    "content": [
      "The solution set of the equation given by log(x² - 3) = 2 log(x - 1) is:"
    ],
    "explanation": [
      "First, we establish the domain for the logarithms. We need x²-3 > 0 and x-1 > 0.",
      "The second condition implies x > 1. The first implies x > √3 or x < -√3. The combined domain is x > √3.",
      "Using the logarithm property n log(a) = log(aⁿ):\n$$\n\\log(x^2 - 3) = \\log((x-1)^2)\n$$\n$$\nx^2 - 3 = (x-1)^2 = x^2 - 2x + 1\n$$\n$$\n-3 = -2x + 1 \\implies 2x = 4 \\implies x = 2\n$$\nWe check if the solution x=2 is in the domain. Since 2 > √3 (approx 1.732), it is a valid solution.",
      "The solution set is {2}."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10668,
        "content": [
          "{1/2}"
        ],
        "isCorrect": false
      },
      {
        "id": 10669,
        "content": [
          "{2}"
        ],
        "isCorrect": true
      },
      {
        "id": 10670,
        "content": [
          "{4}"
        ],
        "isCorrect": false
      },
      {
        "id": 10671,
        "content": [
          "∅"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 2666,
    "content": [
      "Which of the following is true about the trigonometric values of the given pairs of angles?"
    ],
    "explanation": [
      "We use the identity sin(180° - θ) = sin(θ).",
      "For option (D), let θ = 60°. Then sin(120°) = sin(180° - 60°) = sin(60°). This statement is true.",
      "The other options are false.",
      "For example, cos(120°) = -cos(60°), and tan(105°) = -tan(75°)."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10672,
        "content": [
          "tan(75°) = tan(105°)"
        ],
        "isCorrect": false
      },
      {
        "id": 10673,
        "content": [
          "sin(75°) = cos(105°)"
        ],
        "isCorrect": false
      },
      {
        "id": 10674,
        "content": [
          "cos(120°) = cos(60°)"
        ],
        "isCorrect": false
      },
      {
        "id": 10675,
        "content": [
          "sin(120°) = sin(60°)"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 5,
    "unitName": "Introduction to Trigonometry"
  },
  {
    "id": 2667,
    "content": [
      "Which one of the following intervals is the solution set of the inequality x² - 5x + 6 ≤ 0?"
    ],
    "explanation": [
      "First, we find the roots of the quadratic equation x² - 5x + 6 = 0.",
      "Factoring the quadratic, we get (x - 2)(x - 3) = 0. The roots are x = 2 and x = 3.",
      "The expression represents an upward-opening parabola. The parabola is less than or equal to zero between its roots.",
      "Therefore, the solution to the inequality x² - 5x + 6 ≤ 0 is the interval."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_INEQUALTIES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10676,
        "content": [
          "[0, 2]"
        ],
        "isCorrect": false
      },
      {
        "id": 10677,
        "content": [
          "[2, 3]"
        ],
        "isCorrect": true
      },
      {
        "id": 10678,
        "content": [
          "[3, ∞)"
        ],
        "isCorrect": false
      },
      {
        "id": 10679,
        "content": [
          "(-∞, 2]"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Solving Inequality"
  },
  {
    "id": 2668,
    "content": [
      "What are the coordinates of a point that divides the line segment with end points P(0, 1) and Q(5, 6) in the ratio 2:3 from P?"
    ],
    "explanation": [
      "We use the section formula for a point (x, y) that divides the line segment from P(x₁, y₁) to Q(x₂, y₂) in the ratio m:n.\n$$\n(x, y) = (\\frac{nx_1 + mx_2}{m+n}, \\frac{ny_1 + my_2}{m+n})\n$$\nHere, (x₁, y₁) = (0, 1), (x₂, y₂) = (5, 6), m=2, and n=3.\n$$\nx = \\frac{3(0) + 2(5)}{2+3} = \\frac{10}{5} = 2\n$$\n$$\ny = \\frac{3(1) + 2(6)}{2+3} = \\frac{3+12}{5} = \\frac{15}{5} = 3\n$$\nThe coordinates of the point are (2, 3)."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10680,
        "content": [
          "(2, 3)"
        ],
        "isCorrect": true
      },
      {
        "id": 10681,
        "content": [
          "(0, 2)"
        ],
        "isCorrect": false
      },
      {
        "id": 10682,
        "content": [
          "(3, 2)"
        ],
        "isCorrect": false
      },
      {
        "id": 10683,
        "content": [
          "(0, 3)"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 2669,
    "content": [
      "Which one of the following trigonometric values is correct?"
    ],
    "explanation": [
      "We use trigonometric identities for negative angles and reference angles. The identity for cosine is cos(-θ) = cos(θ).",
      "So, cos(-120°) = cos(120°).",
      "The angle 120° is in the second quadrant, where cosine is negative. The reference angle is 180° - 120° = 60°.",
      "cos(120°) = -cos(60°) = -0.5. This statement is correct."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10684,
        "content": [
          "sin(-120°) = 0.5"
        ],
        "isCorrect": false
      },
      {
        "id": 10685,
        "content": [
          "cos(-120°) = -0.5"
        ],
        "isCorrect": true
      },
      {
        "id": 10686,
        "content": [
          "tan(-120°) = -1"
        ],
        "isCorrect": false
      },
      {
        "id": 10687,
        "content": [
          "cos(-60°) = √3/2"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 5,
    "unitName": "Introduction to Trigonometry"
  },
  {
    "id": 2670,
    "content": [
      "Which one of the following is an onto function from R on to [0, ∞)?"
    ],
    "explanation": [
      "An onto (surjective) function from set A to set B is a function where every element in B is the image of at least one element in A. Here, the domain is R and the codomain is [0, ∞).",
      "The function f(x) = √x² simplifies to f(x) = |x|. The domain of this function is all real numbers (R). The range (the set of all possible output values) is all non-negative real numbers, which is [0, ∞). Since the range is equal to the codomain, the function is onto."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10688,
        "content": [
          "f(x) = √x²"
        ],
        "isCorrect": true
      },
      {
        "id": 10689,
        "content": [
          "f(x) = |x| + 2"
        ],
        "isCorrect": false
      },
      {
        "id": 10690,
        "content": [
          "f(x) = x² + 1"
        ],
        "isCorrect": false
      },
      {
        "id": 10691,
        "content": [
          "f(x) = 2ˣ"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2671,
    "content": [
      "Which one of the following is the simplified form of $$\\frac{4x^4 - 64}{2-x}$$ for x ≠ 2?"
    ],
    "explanation": [
      "We simplify the expression by factoring the numerator and the denominator.",
      "Numerator:\n$$\n4x^4 - 64 = 4(x^4 - 16)\n$$\nThis is a difference of squares:\n$$\n4(x^2 - 4)(x^2 + 4)\n$$\nFactoring further:\n$$\n4(x-2)(x+2)(x^2+4)\n$$\nDenominator:\n$$\n2 - x = -(x - 2)\n$$\nThe expression becomes:\n$$\n\\frac{4(x-2)(x+2)(x^2+4)}{-(x-2)}\n$$\nSince x ≠ 2, we can cancel the (x-2) terms:\n$$\n-4(x+2)(x^2+4)\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10692,
        "content": [
          "4(x + 2)(x² + 4)"
        ],
        "isCorrect": false
      },
      {
        "id": 10693,
        "content": [
          "4(x - 2)(x² - 4)"
        ],
        "isCorrect": false
      },
      {
        "id": 10694,
        "content": [
          "-4(x + 2)(x² + 4)"
        ],
        "isCorrect": true
      },
      {
        "id": 10695,
        "content": [
          "-4(x - 2)(x² + 4)"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 2672,
    "content": [
      "If Birr 20,000 is deposited in a Bank at a rate of 12% interest compounded monthly, how long will it take to double the amount?"
    ],
    "explanation": [
      "We use the formula for compound interest:\n$$\nA = P(1 + \\frac{r}{n})^{nt}\n$$",
      "We have P=20,000, A=40,000 (double the amount), r=0.12 (12%), and n=12 (compounded monthly). We need to find t.\n$$\n40000 = 20000(1 + \\frac{0.12}{12})^{12t}\n$$\n$$\n2 = (1 + 0.01)^{12t} = (1.01)^{12t}\n$$\nTake the natural logarithm of both sides:\n$$\n\\ln(2) = 12t \\ln(1.01)\n$$\n$$\nt = \\frac{\\ln(2)}{12 \\ln(1.01)}\n$$\n$$\n\\approx \\frac{0.6931}{12 \\times 0.00995} \\approx \\frac{0.6931}{0.1194}\n$$\n$$\n\\approx 5.805 \\ \\text{years}\n$$",
      "This is approximately 5.81 years."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_APPLICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10696,
        "content": [
          "7.59 years"
        ],
        "isCorrect": false
      },
      {
        "id": 10697,
        "content": [
          "6 years"
        ],
        "isCorrect": false
      },
      {
        "id": 10698,
        "content": [
          "5.81 years"
        ],
        "isCorrect": true
      },
      {
        "id": 10699,
        "content": [
          "5 years"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Mathematical Application in Business"
  },
  {
    "id": 2673,
    "content": [
      "Which one of the following is true about the matrix\n$$\n\\begin{pmatrix} 1 & 3 & 5 \\\\ 6 & 4 & 2 \\\\ 9 & 7 & 0 \\end{pmatrix}\n$$"
    ],
    "explanation": [
      "Let's check the cofactor of the entry 1, which is in row 1, column 1 (a₁₁).",
      "The cofactor Cᵢⱼ is given by $$C_{ij} = (-1)^{i+j} M_{ij}$$, where Mᵢⱼ is the minor.",
      "The minor M₁₁ is the determinant of the submatrix formed by removing the 1st row and 1st column:\n$$\nM_{11} = \\det\\begin{pmatrix} 4 & 2 \\\\ 7 & 0 \\end{pmatrix}\n$$\n$$\n= (4)(0) - (2)(7) = -14\n$$\nThe cofactor C₁₁ is:\n$$\nC_{11} = (-1)^{1+1} M_{11} = (1)(-14) = -14\n$$\nThis statement is true. The other statements are false."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10700,
        "content": [
          "The minor of the entry 3 is 18"
        ],
        "isCorrect": false
      },
      {
        "id": 10701,
        "content": [
          "The cofactor of the entry 5 is -6."
        ],
        "isCorrect": false
      },
      {
        "id": 10702,
        "content": [
          "The minor of the entry 0 is 14"
        ],
        "isCorrect": false
      },
      {
        "id": 10703,
        "content": [
          "The cofactor of the entry 1 is -14."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Determinants and Their Properties"
  },
  {
    "id": 2674,
    "content": [
      "Consider the points A(-2, 1), B(3, 0), C(3, -1) and D(1, 1) in xy-plane. If u = AB and v = CD, then which one of the following is equal to u - v?"
    ],
    "explanation": [
      "First, we find the component form of vectors u and v.",
      "u = AB = B - A = (3 - (-2), 0 - 1) = (5, -1).",
      "v = CD = D - C = (1 - 3, 1 - (-1)) = (-2, 2).",
      "Then, we compute the difference u - v:",
      "u - v = (5, -1) - (-2, 2) = (5 - (-2), -1 - 2) = (7, -3)."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_VECTORS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10704,
        "content": [
          "(3, 1)"
        ],
        "isCorrect": false
      },
      {
        "id": 10705,
        "content": [
          "(-7, 3)"
        ],
        "isCorrect": false
      },
      {
        "id": 10706,
        "content": [
          "(-3, 1)"
        ],
        "isCorrect": false
      },
      {
        "id": 10707,
        "content": [
          "(7, -3)"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 8,
    "unitName": "Vectors in 2D"
  },
  {
    "id": 2675,
    "content": [
      "What is the point of intersection of the medians of ΔABC whose vertices are given by A(0, 0), B(6, 0) and C(0, 4)?"
    ],
    "explanation": [
      "The point of intersection of the medians of a triangle is called the centroid.",
      "The coordinates of the centroid are the average of the coordinates of the vertices.\n$$\n\\text{Centroid (G)} = (\\frac{x_1+x_2+x_3}{3}, \\frac{y_1+y_2+y_3}{3})\n$$\n$$\nG = (\\frac{0+6+0}{3}, \\frac{0+0+4}{3})\n$$\n$$\n= (\\frac{6}{3}, \\frac{4}{3}) = (2, \\frac{4}{3})\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10708,
        "content": [
          "(2, 4/3)"
        ],
        "isCorrect": true
      },
      {
        "id": 10709,
        "content": [
          "(1, 2/3)"
        ],
        "isCorrect": false
      },
      {
        "id": 10710,
        "content": [
          "(9/5, 6/5)"
        ],
        "isCorrect": false
      },
      {
        "id": 10711,
        "content": [
          "(6/5, 4/5)"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 2676,
    "content": [
      "What is the image of the circle with equation (x + 2)² + (y - 2)² = 1, when it is rotated through π/6 about the origin?"
    ],
    "explanation": [
      "Rotating a circle only changes the position of its center; the radius remains the same. The original center is C = (-2, 2). We rotate this point by θ = π/6.",
      "The rotation formulas are: x' = x cosθ - y sinθ and y' = x sinθ + y cosθ.",
      "With θ = π/6, we have cos(π/6) = √3/2 and sin(π/6) = 1/2.",
      "x' = (-2)(√3/2) - (2)(1/2) = -√3 - 1 = -(√3+1).",
      "y' = (-2)(1/2) + (2)(√3/2) = -1 + √3 = √3-1.",
      "The new center is C' = (-(√3+1), √3-1). The new equation is (x - x')² + (y - y')² = 1, which becomes\n$$\n(x + (\\sqrt{3}+1))^2 + (y - (\\sqrt{3}-1))^2 = 1\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRANSFORMATION_PLANE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10712,
        "content": [
          "$$\n(x + (\\sqrt{3}-1))^2 + (y - (\\sqrt{3}+1))^2 = 1\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10713,
        "content": [
          "$$\n(x - (\\sqrt{3}+1))^2 + (y + (\\sqrt{3}-1))^2 = 1\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10714,
        "content": [
          "$$\n(x + (\\sqrt{3}+1))^2 + (y - (\\sqrt{3}-1))^2 = 1\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10715,
        "content": [
          "$$\n(x - (\\sqrt{3}-1))^2 + (y + (\\sqrt{3}+1))^2 = 1\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Transformation of the Plane"
  },
  {
    "id": 2677,
    "content": [
      "What is the dot (scalar) product of the vectors u = i + 2j and v = -2i + 4j?"
    ],
    "explanation": [
      "The vectors can be written in component form as u = (1, 2) and v = (-2, 4).",
      "The dot product of two vectors u = (u₁, u₂) and v = (v₁, v₂) is given by u · v = u₁v₁ + u₂v₂.",
      "u · v = (1)(-2) + (2)(4) = -2 + 8 = 6."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_VECTORS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10716,
        "content": [
          "-8"
        ],
        "isCorrect": false
      },
      {
        "id": 10717,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 10718,
        "content": [
          "6"
        ],
        "isCorrect": true
      },
      {
        "id": 10719,
        "content": [
          "7"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Vectors"
  },
  {
    "id": 2678,
    "content": [
      "$$\n\\int \\frac{x^3 + x^2 - x}{x^2 + x - 2} dx\n$$\nis equal to:"
    ],
    "explanation": [
      "The degree of the numerator is greater than the denominator, so we first perform polynomial long division.\n$$\n\\frac{x^3 + x^2 - x}{x^2 + x - 2} = x + \\frac{x}{x^2 + x - 2}\n$$\nWe decompose the fractional part using partial fractions:\n$$\n\\frac{x}{(x+2)(x-1)} = \\frac{A}{x+2} + \\frac{B}{x-1}\n$$\nSolving for A and B gives A = 2/3 and B = 1/3.",
      "The integral becomes\n$$\n\\int (x + \\frac{2/3}{x+2} + \\frac{1/3}{x-1}) dx\n$$\nIntegrating term by term gives\n$$\n\\frac{x^2}{2} + \\frac{2}{3}\\ln|x+2| + \\frac{1}{3}\\ln|x-1| + c\n$$\nThis matches option A when terms are reordered."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10720,
        "content": [
          "$$\n\\frac{x^2}{2} + \\frac{1}{3}\\ln|x-1| + \\frac{2}{3}\\ln|x+2| + c\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10721,
        "content": [
          "$$\n\\frac{x^2}{2} - \\frac{1}{3}\\ln|x-1| - \\frac{2}{3}\\ln|x+2| + c\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10722,
        "content": [
          "$$\n\\frac{x^2}{2} - \\frac{1}{3}\\ln|x-1| + \\frac{2}{3}\\ln|x+2| + c\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10723,
        "content": [
          "$$\n\\frac{x^2}{2} + \\frac{1}{3}\\ln|x-1| - \\frac{2}{3}\\ln|x+2| + c\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2679,
    "content": [
      "If r₁ and r₂ are the roots of the equation 3x² + 9x + 16 = 0, which one of the following is true?"
    ],
    "explanation": [
      "Given (3x² + 9x + 16 = 0):",
      "Sum of roots:\n$$\nr₁ + r₂ = -\\frac{b}{a} = -\\frac{9}{3} = -3\n$$\nProduct of roots:\n$$\nr₁r₂ = \\frac{c}{a} = \\frac{16}{3}\n$$\nNow check each:\n- (A) ($$r₁ + r₂ = 3$$) → False (it’s −3)\n- (B) ($$r₁r₂ = -\\frac{16}{3}$$) → False (it’s positive)\n- (C) ($$r₁² + r₂²$$ = $$(r₁ + r₂)² - 2r₁r₂$$ = $$(-3)² - 2(16/3)$$ = $$9 - 32/3 = -5/3)$$ → True\n- (D) ($$\\frac{1}{r₁} + \\frac{1}{r₂}$$ = $$\\frac{r₁ + r₂}{r₁r₂}$$ = $$\\frac{-3}{16/3}$$ = $$-\\frac{9}{16}$$) → False"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10724,
        "content": [
          "$$r₁ + r₂ = 3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10725,
        "content": [
          "$$r₁r₂ = - \\frac{16}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10726,
        "content": [
          "$$r₁² + r₂² = - \\frac{5}{3}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10727,
        "content": [
          "$$\\frac{1}{r_1} + \\frac{1}{r_2} = \\frac{9}{16}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 2680,
    "content": [
      "The following is the distribution of the marks of students obtained in Mathematics test out of 50.",
      "images/maths/year_2014_na/q63_1.png",
      "What is the first quartile of the distribution?"
    ],
    "explanation": [
      "First, find the total frequency (N): N = 15+30+25+20+10 = 100.",
      "The position of the first quartile (Q₁) is N/4 = 100/4 = 25.",
      "The cumulative frequencies are: 15, 45, 70, 90, 100. The 25th value falls in the 26-31 class.",
      "Use the formula for Q₁ for grouped data:\n$$\nQ_1 = L + (\\frac{N/4 - cf}{f}) \\times w\n$$",
      "L (lower class boundary) = 25.5.",
      "cf (cumulative frequency before the Q₁ class) = 15.",
      "f (frequency of the Q₁ class) = 30.",
      "w (class width) = 6.\n$$\nQ_1 = 25.5 + (\\frac{25 - 15}{30}) \\times 6\n$$\n$$\n= 25.5 + \\frac{10}{30} \\times 6 = 25.5 + 2 = 27.5\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2014_na/q63_1.png"
    ],
    "choices": [
      {
        "id": 10728,
        "content": [
          "28"
        ],
        "isCorrect": false
      },
      {
        "id": 10729,
        "content": [
          "26"
        ],
        "isCorrect": false
      },
      {
        "id": 10730,
        "content": [
          "26.5"
        ],
        "isCorrect": false
      },
      {
        "id": 10731,
        "content": [
          "27.5"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 2681,
    "content": [
      "Let p and q be propositions. Which of the following compound statement is a tautology?"
    ],
    "explanation": [
      "A tautology is a compound statement that is always true, regardless of the truth values of the individual propositions.",
      "The statement (p ⇒ q) ⇔ (¬p ∨ q) represents the logical equivalence that defines the conditional (implication) operator. This equivalence is a fundamental law of logic and is always true, making it a tautology."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10732,
        "content": [
          "(p ∨ q) ⇔ p"
        ],
        "isCorrect": false
      },
      {
        "id": 10733,
        "content": [
          "(p ⇒ q) ⇔ p"
        ],
        "isCorrect": false
      },
      {
        "id": 10734,
        "content": [
          "(p ∧ q) ⇔ p"
        ],
        "isCorrect": false
      },
      {
        "id": 10735,
        "content": [
          "(p ⇒ q) ⇔ (¬p ∨ q)"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 2682,
    "content": [
      "Which one of the following is NOT true about the graph of f(x) = 5 + |x|/(x+1)?"
    ],
    "explanation": [
      "An oblique (or slant) asymptote occurs in a rational function when the degree of the numerator is exactly one greater than the degree of the denominator.",
      "For f(x) = 5 + |x|/(x+1), as x approaches ±∞, the term |x|/(x+1) approaches either 1 or -1. The function does not grow linearly like y=5+x. Thus, it does not have an oblique asymptote. The other statements are true: there is a vertical asymptote at x=-1 and horizontal asymptotes at y=6 (as x→∞) and y=4 (as x→-∞)."
    ],
    "year": "YEAR_2014",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10736,
        "content": [
          "y = 5 + x is its oblique asymptote."
        ],
        "isCorrect": true
      },
      {
        "id": 10737,
        "content": [
          "y = 6 is its horizontal asymptote of f."
        ],
        "isCorrect": false
      },
      {
        "id": 10738,
        "content": [
          "y = 4 is its horizontal asymptote."
        ],
        "isCorrect": false
      },
      {
        "id": 10739,
        "content": [
          "x = -1 is its vertical asymptote of f."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2683,
    "content": [
      "A Geometric Series with first term a and common ratio r is convergent if"
    ],
    "explanation": [
      "A geometric series converges when its terms keep getting smaller. That happens only if the common ratio’s absolute value is less than 1.",
      "If |r| ≥ 1, the terms don’t get smaller, so the sum keeps growing instead of settling to a fixed value."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10740,
        "content": [
          "|r| ≥ 1"
        ],
        "isCorrect": false
      },
      {
        "id": 10741,
        "content": [
          "|r| > 1"
        ],
        "isCorrect": false
      },
      {
        "id": 10742,
        "content": [
          "|r| ≤ 1"
        ],
        "isCorrect": false
      },
      {
        "id": 10743,
        "content": [
          "|r| < 1"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2684,
    "content": [
      "Which of the following is an upper bound for the sequence\n$$\n{\\{\\frac{n+1}{n}\\}}_{n=1}^{\\infty} \\ \\text{?}\n$$"
    ],
    "explanation": [
      "Let the sequence be\n$$\na_n = \\frac{n+1}{n} = 1 + \\frac{1}{n}\n$$\nThe first few terms are a₁=2, a₂=3/2=1.5, a₃=4/3≈1.33.",
      "The sequence is decreasing and approaches 1 as n approaches infinity. The maximum value is the first term, a₁=2. An upper bound is any number greater than or equal to the maximum value of the sequence. Therefore, 2 is an upper bound (it is also the least upper bound)."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10744,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 10745,
        "content": [
          "0"
        ],
        "isCorrect": false
      },
      {
        "id": 10746,
        "content": [
          "2"
        ],
        "isCorrect": true
      },
      {
        "id": 10747,
        "content": [
          "4/3"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2685,
    "content": [
      "The general term of a sequence is $$a_n = (\\frac{1}{2})^{1-n}$$. Then which of the following is true about this sequence?"
    ],
    "explanation": [
      "The general term can be simplified:\n$$\na_n = (2^{-1})^{1-n} = 2^{-1(1-n)} = 2^{n-1}\n$$",
      "For n=1, a₁=2⁰=1. For n=2, a₂=2¹=2. For n=3, a₃=2²=4. The sequence is {1, 2, 4, 8, ...}.",
      "All terms of the sequence are positive integers, which are by definition natural numbers."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10748,
        "content": [
          "0 is one of its terms."
        ],
        "isCorrect": false
      },
      {
        "id": 10749,
        "content": [
          "Its terms are non-positive."
        ],
        "isCorrect": false
      },
      {
        "id": 10750,
        "content": [
          "Its terms are odd numbers."
        ],
        "isCorrect": false
      },
      {
        "id": 10751,
        "content": [
          "Its terms are natural numbers."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2686,
    "content": [
      "The distance between point (4, -3) and the line l: x + y - 7 = 0 is ______."
    ],
    "explanation": [
      "The formula for the distance from a point (x₀, y₀) to a line Ax + By + C = 0 is\n$$\nd = \\frac{|Ax_0 + By_0 + C|}{\\sqrt{A^2 + B^2}}\n$$",
      "Here, (x₀, y₀) = (4, -3) and the line is 1x + 1y - 7 = 0. So, A=1, B=1, C=-7.\n$$\nd = \\frac{|1(4) + 1(-3) - 7|}{\\sqrt{1^2 + 1^2}}\n$$\n$$\nd = \\frac{|4 - 3 - 7|}{\\sqrt{2}} = \\frac{|-6|}{\\sqrt{2}} = \\frac{6}{\\sqrt{2}}\n$$\n$$\nd = \\frac{6\\sqrt{2}}{2} = 3\\sqrt{2}\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10752,
        "content": [
          "$$4√2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10753,
        "content": [
          "$$2√2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10754,
        "content": [
          "$$\\frac{3\\sqrt{2}}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10755,
        "content": [
          "$$3√2$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 2687,
    "content": [
      "Let $$f(x) = \\frac{x^2 - x}{2x^2 - x - 1}$$, which of the following is NOT true about f and its graph?"
    ],
    "explanation": [
      "First, factor the numerator and denominator:\n$$\nf(x) = \\frac{x(x - 1)}{(2x + 1)(x - 1)}\n$$",
      "The function simplifies to $$f(x) = \\frac{x}{2x + 1}$$ with a hole at x=1.",
      "An even function must satisfy f(-x) = f(x). For this function,\n$$\nf(-x) = \\frac{-x}{2(-x) + 1} = \\frac{-x}{-2x + 1}\n$$\nwhich is not equal to f(x). Therefore, the statement that f is an even function is NOT true.",
      "The other statements are true: The denominator 2x+1 is zero at x=-1/2 (vertical asymptote). The cancelled factor x-1 causes a hole at x=1, where y=1/(2(1)+1) = 1/3. The ratio of the leading coefficients of the original function is 1/2, so y=1/2 is a horizontal asymptote."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10756,
        "content": [
          "x = -1/2 is a vertical asymptote."
        ],
        "isCorrect": false
      },
      {
        "id": 10757,
        "content": [
          "The graph of f has a hole at (1, 1/3)."
        ],
        "isCorrect": false
      },
      {
        "id": 10758,
        "content": [
          "f is an even function."
        ],
        "isCorrect": true
      },
      {
        "id": 10759,
        "content": [
          "y = 1/2 is a horizontal asymptote."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2688,
    "content": [
      "Which of the following statements is NOT true?"
    ],
    "explanation": [
      "Variance measures the average squared deviation of data points from the mean. A larger variance signifies greater spread or dispersion of data values. Therefore, a large variance means the data values are, on average, farther from the mean, not closer."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10760,
        "content": [
          "When the variance of a data is close to zero, the data shows less variability."
        ],
        "isCorrect": false
      },
      {
        "id": 10761,
        "content": [
          "Variance indicates the variability of a set of numerical data items."
        ],
        "isCorrect": false
      },
      {
        "id": 10762,
        "content": [
          "If two data have equal mean, the data with less variance shows less variability."
        ],
        "isCorrect": false
      },
      {
        "id": 10763,
        "content": [
          "A large value of variance shows that the data values are closer to the mean."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 7,
    "unitName": "Statistics"
  },
  {
    "id": 2689,
    "content": [
      "The following is the frequency distribution of a grouped data.",
      "images/maths/year_2012/q7_1.png",
      "What is the mean of the data?"
    ],
    "explanation": [
      "To find the mean of grouped data, calculate the midpoint (x) for each class, multiply it by the frequency (f), sum these products, and divide by the total frequency.",
      "Midpoints: (3+7)/2=5; (8+12)/2=10; (13+17)/2=15; (18+22)/2=20.",
      "Total frequency Σf = 2 + 2 + 10 + 6 = 20.",
      "Sum of (frequency × midpoint) Σ(f⋅x) = (2⋅5) + (2⋅10) + (10⋅15) + (6⋅20) = 10 + 20 + 150 + 120 = 300.",
      "Mean = Σ(f⋅x) / Σf = 300 / 20 = 15."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2012/q7_1.png"
    ],
    "choices": [
      {
        "id": 10764,
        "content": [
          "15"
        ],
        "isCorrect": true
      },
      {
        "id": 10765,
        "content": [
          "14"
        ],
        "isCorrect": false
      },
      {
        "id": 10766,
        "content": [
          "12.5"
        ],
        "isCorrect": false
      },
      {
        "id": 10767,
        "content": [
          "13"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 2690,
    "content": [
      "If p: \"the rainy season is very good this year\" and q: \"rivers are rising\", then the statement \"It is not true that neither the rainy season is very good this year nor rivers are rising\" denoted by"
    ],
    "explanation": [
      "The phrase “neither p nor q” means ¬p ∧ ¬q. So, “It is not true that neither p nor q” becomes ¬(¬p ∧ ¬q).",
      "By De Morgan’s law: ¬(¬p ∧ ¬q) = ¬¬p ∨ ¬¬q = p ∨ q.",
      "Hence, the symbolic form of the given statement is ¬(¬p ∨ ¬q), equivalent to p ∧ q in logic."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10768,
        "content": [
          "(¬p ⇒ q) ∨ ¬q"
        ],
        "isCorrect": false
      },
      {
        "id": 10769,
        "content": [
          "(p ⇒ q) ∨ (¬p ⇒ ¬q)"
        ],
        "isCorrect": false
      },
      {
        "id": 10770,
        "content": [
          "¬p ∧ ¬q"
        ],
        "isCorrect": false
      },
      {
        "id": 10771,
        "content": [
          "¬(¬p ∨ ¬q)"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 2691,
    "content": [
      "$$\n\\lim_{x\\to\\infty} \\left(\\frac{x-2}{x}\\right)^{-2x+1} =\n$$"
    ],
    "explanation": [
      "This limit is of the indeterminate form 1^∞. We can rewrite the expression to fit the form $$\\lim_{u\\to\\infty} (1 + \\frac{k}{u})^{au}$$ which equals $$e^{ka}$$\n$$\n\\lim_{x\\to\\infty} \\left(\\frac{x-2}{x}\\right)^{-2x+1}\n$$\n$$\n= \\lim_{x\\to\\infty} \\left(1 - \\frac{2}{x}\\right)^{-2x+1}\n$$\n$$\n= \\lim_{x\\to\\infty} \\left(1 + \\frac{-2}{x}\\right)^{-2x+1}\n$$",
      "As x→∞, the '+1' in the exponent becomes insignificant. The limit is determined by the main terms.\n$$\n\\lim_{x\\to\\infty} \\left(1 + \\frac{-2}{x}\\right)^{-2x} = e^{(-2)(-2)} = e^4\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10772,
        "content": [
          "e⁴"
        ],
        "isCorrect": true
      },
      {
        "id": 10773,
        "content": [
          "e⁻⁴"
        ],
        "isCorrect": false
      },
      {
        "id": 10774,
        "content": [
          "e²"
        ],
        "isCorrect": false
      },
      {
        "id": 10775,
        "content": [
          "e⁻²"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2692,
    "content": [
      "Given $$0 < a_n < \\frac{1}{n}$$ for each n=1,2,3..... Which of the following is true?"
    ],
    "explanation": [
      "This is a direct application of the Squeeze Theorem (or Sandwich Theorem). We are given the inequality $$0 < a_n < \\frac{1}{n}$$.",
      "We take the limit of all parts of the inequality as n approaches infinity.\n$$\n\\lim_{n\\to\\infty} 0 \\leq \\lim_{n\\to\\infty} a_n \\leq \\lim_{n\\to\\infty} \\frac{1}{n}\n$$\n$$\n0 \\leq \\lim_{n\\to\\infty} a_n \\leq 0\n$$\nSince the limit of aₙ is squeezed between 0 and 0, the limit must be 0."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10776,
        "content": [
          "$$\\lim_{n\\to\\infty} a_n < 0$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10777,
        "content": [
          "$$\\lim_{n\\to\\infty} a_n = 0$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10778,
        "content": [
          "$$\\lim_{n\\to\\infty} a_n$$ does not exist"
        ],
        "isCorrect": false
      },
      {
        "id": 10779,
        "content": [
          "$$\\lim_{n\\to\\infty} a_n > 0$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2693,
    "content": [
      "Let $$f(x) = x^2 + 2x + 3$$ find a number c ∈ (1, 3) such that $$f'(c) = \\frac{f(3) - f(1)}{2}$$?"
    ],
    "explanation": [
      "This question applies the Mean Value Theorem, which states that if f is continuous on [a,b] and differentiable on (a,b), then there exists a c in (a,b) such that\n$$\nf'(c) = \\frac{f(b) - f(a)}{b - a}\n$$\nHere a=1, b=3, so b-a=2.",
      "First, calculate the average rate of change:\n$$\nf(3) = 3^2 + 2(3) + 3 = 9 + 6 + 3 = 18\n$$\n$$\nf(1) = 1^2 + 2(1) + 3 = 1 + 2 + 3 = 6\n$$\n$$\n\\frac{f(3) - f(1)}{2} = \\frac{18 - 6}{2} = \\frac{12}{2} = 6\n$$",
      "Next, find the derivative: $$f'(x) = 2x + 2$$.",
      "Set $$f'(c) = 6$$:\n$$\n2c + 2 = 6 \\implies 2c = 4 \\implies c = 2\n$$",
      "The value c=2 is in the specified interval (1, 3)."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10780,
        "content": [
          "-6"
        ],
        "isCorrect": false
      },
      {
        "id": 10781,
        "content": [
          "6"
        ],
        "isCorrect": false
      },
      {
        "id": 10782,
        "content": [
          "-2"
        ],
        "isCorrect": false
      },
      {
        "id": 10783,
        "content": [
          "2"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2694,
    "content": [
      "For what value of c the conclusion of Rolle's theorem is satisfied for the function f(x) = 2x -x²-x³ on [-2, 1]?"
    ],
    "explanation": [
      "Rolle's Theorem requires f(a)=f(b). Let's check:",
      "f(-2) = 2(-2) - (-2)² - (-2)³ = -4 - 4 + 8 = 0.",
      "f(1) = 2(1) - (1)² - (1)³ = 2 - 1 - 1 = 0.",
      "Since f(-2)=f(1), the theorem applies. We need to find c in (-2, 1) where f'(c)=0.",
      "First, find the derivative: $$f'(x) = 2 - 2x - 3x^2$$.",
      "Set f'(c) = 0: $$-3c^2 - 2c + 2 = 0$$ or $$3c^2 + 2c - 2 = 0$$.",
      "Use the quadratic formula:\n$$\nc = \\frac{-2 \\pm \\sqrt{2^2 - 4(3)(-2)}}{2(3)}\n$$\n$$\n= \\frac{-2 \\pm \\sqrt{4 + 24}}{6}\n$$\n$$\n= \\frac{-1 \\pm \\sqrt{7}}{3}\n$$",
      "Both values, $$c \\approx \\frac{-1+2.646}{3} \\approx 0.549$$ and $$c \\approx \\frac{-1-2.646}{3} \\approx -1.215$$, are within the interval (-2, 1)."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10784,
        "content": [
          "$$\n\\frac{-1\\pm\\sqrt{5}}{3}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10785,
        "content": [
          "$$\n\\frac{1\\pm\\sqrt{7}}{3}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10786,
        "content": [
          "$$\n\\frac{1\\pm\\sqrt{5}}{3}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10787,
        "content": [
          "$$\n\\frac{-1\\pm\\sqrt{7}}{3}\n$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2695,
    "content": [
      "Let z₁ = 2 + i, z₂ = 3 + i and z₃ = 1 - i, then what are the real and imaginary parts of z₁z₂z₃ respectively?"
    ],
    "explanation": [
      "First, multiply z₁ and z₂:\n$$\nz_1z_2 = (2 + i)(3 + i)\n$$\n$$\n= 6 + 2i + 3i + i^2 = 6 + 5i - 1 = 5 + 5i\n$$",
      "Now, multiply the result by z₃:\n$$\n(z_1z_2)z_3 = (5 + 5i)(1 - i)\n$$\n$$\n= 5(1+i)(1-i) = 5(1^2 - i^2)\n$$\n$$\n= 5(1 - (-1)) = 5(2) = 10\n$$",
      "The result is 10, which can be written as 10 + 0i. The real part is 10 and the imaginary part is 0."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10788,
        "content": [
          "6 and 3"
        ],
        "isCorrect": false
      },
      {
        "id": 10789,
        "content": [
          "-6 and -3"
        ],
        "isCorrect": false
      },
      {
        "id": 10790,
        "content": [
          "-1 and 1"
        ],
        "isCorrect": false
      },
      {
        "id": 10791,
        "content": [
          "10 and 0"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2696,
    "content": [
      "What is the value of a and b if\n$$\n\\frac{a + 2i}{3i} = \\frac{b+i}{4} \\ \\text{?}\n$$"
    ],
    "explanation": [
      "Cross-multiply the terms to get an equation without fractions:\n$$\n4(a + 2i) = 3i(b + i)\n$$\n$$\n4a + 8i = 3bi + 3i^2\n$$\n$$\n4a + 8i = 3bi - 3\n$$",
      "Group the real and imaginary parts:\n$$\n4a + 8i = -3 + (3b)i\n$$",
      "Equate the real parts:\n$$\n4a = -3 \\implies a = -3/4\n$$",
      "Equate the imaginary parts:\n$$\n8 = 3b \\implies b = 8/3\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10792,
        "content": [
          "a = 3/4, b = -8/3"
        ],
        "isCorrect": false
      },
      {
        "id": 10793,
        "content": [
          "a = 3/4, b = 8/3"
        ],
        "isCorrect": false
      },
      {
        "id": 10794,
        "content": [
          "a = -3/4, b = 8/3"
        ],
        "isCorrect": true
      },
      {
        "id": 10795,
        "content": [
          "a = -3/4, b = -8/3"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2697,
    "content": [
      "The table shown below is a simple frequency distribution of data with variable x.",
      "images/maths/year_2012/q15_1.png",
      "What is the variance of the data?"
    ],
    "explanation": [
      "First, calculate the mean (μ). Total frequency N = 2+5+6+5+2 = 20.\n$$\n\\mu = \\frac{\\sum f_i x_i}{N}\n$$\n$$\n= \\frac{1(2) + 3(5) + 4(6) + 5(5) + 7(2)}{20}\n$$\n$$\n= \\frac{2+15+24+25+14}{20} = \\frac{80}{20} = 4\n$$",
      "Next, calculate the variance (σ²), which is the average of the squared differences from the mean.\n$$\n\\sigma^2 = \\frac{\\sum f_i (x_i - \\mu)^2}{N}\n$$\n$$\n\\sigma^2 = \\frac{2(1-4)^2 + 5(3-4)^2 + 6(4-4)^2 + 5(5-4)^2 + 2(7-4)^2}{20}\n$$\n$$\n\\sigma^2 = \\frac{2(9) + 5(1) + 6(0) + 5(1) + 2(9)}{20}\n$$\n$$\n= \\frac{18+5+0+5+18}{20} = \\frac{46}{20} = 2.3\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2012/q15_1.png"
    ],
    "choices": [
      {
        "id": 10796,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 10797,
        "content": [
          "√3"
        ],
        "isCorrect": false
      },
      {
        "id": 10798,
        "content": [
          "3.2"
        ],
        "isCorrect": false
      },
      {
        "id": 10799,
        "content": [
          "2.3"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 7,
    "unitName": "Statistics"
  },
  {
    "id": 2698,
    "content": [
      "The second derivative of the function $$f(x) = xe^{-x}$$ is"
    ],
    "explanation": [
      "Find the first derivative using the product rule:\n$$\nf'(x) = (1)(e^{-x}) + (x)(-e^{-x})\n$$\n$$\n= e^{-x} - xe^{-x} = (1-x)e^{-x}\n$$",
      "Find the second derivative, again using the product rule:\n$$\nf''(x) = (-1)(e^{-x}) + (1-x)(-e^{-x})\n$$\n$$\n= -e^{-x} - e^{-x} + xe^{-x}\n$$\n$$\nf''(x) = -2e^{-x} + xe^{-x} = (x-2)e^{-x}\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10800,
        "content": [
          "$$-xe^{-x}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10801,
        "content": [
          "$$(2-x)e^{-x}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10802,
        "content": [
          "$$(x-2)e^{-x}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10803,
        "content": [
          "$$(x+2)^2e^{-x}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2699,
    "content": [
      "If p and q are propositions, then which one of the following pairs of compound propositions are equivalent?"
    ],
    "explanation": [
      "Two propositions are equivalent if they have the same truth table. Let's analyze option C.",
      "p ⇔ q (biconditional) is true only when p and q have the same truth value (both true or both false).",
      "¬p ⇔ ¬q is true only when ¬p and ¬q have the same truth value. This happens when p and q are both false (so ¬p and ¬q are both true) or when p and q are both true (so ¬p and ¬q are both false). This is the same condition as for p ⇔ q. Thus, they are equivalent."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10804,
        "content": [
          "p ⇒ ¬q and ¬p ∧ q"
        ],
        "isCorrect": false
      },
      {
        "id": 10805,
        "content": [
          "¬(p ∧ q) and ¬p ∨ q"
        ],
        "isCorrect": false
      },
      {
        "id": 10806,
        "content": [
          "p ⇔ q and ¬p ⇔ ¬q"
        ],
        "isCorrect": true
      },
      {
        "id": 10807,
        "content": [
          "¬p ⇒ q and q ⇒ ¬p"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 2700,
    "content": [
      "The volume of a cube is increasing at a rate of 9cm³/sec. How fast is the surface area increasing when the length of an edge is 10cm?"
    ],
    "explanation": [
      "Let the side length be s, volume V, and surface area A. Then V = s³ and A = 6s².",
      "We are given dV/dt = 9. Differentiate V with respect to time t:\n$$\n\\frac{dV}{dt} = 3s^2 \\frac{ds}{dt}\n$$",
      "Substitute the given value:\n$$\n9 = 3s^2 \\frac{ds}{dt}\n$$\nWhich gives $$\\frac{ds}{dt} = \\frac{3}{s^2}$$.",
      "We need to find dA/dt. Differentiate A with respect to time t:\n$$\n\\frac{dA}{dt} = 12s \\frac{ds}{dt}\n$$",
      "Substitute the expression for ds/dt:\n$$\n\\frac{dA}{dt} = 12s \\left(\\frac{3}{s^2}\\right) = \\frac{36}{s}\n$$",
      "When s = 10 cm,\n$$\n\\frac{dA}{dt} = \\frac{36}{10} = 3.6 \\ \\text{cm²/sec}\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_APPLICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10808,
        "content": [
          "3.6cm²/sec"
        ],
        "isCorrect": true
      },
      {
        "id": 10809,
        "content": [
          "36cm²/sec"
        ],
        "isCorrect": false
      },
      {
        "id": 10810,
        "content": [
          "90cm²/sec"
        ],
        "isCorrect": false
      },
      {
        "id": 10811,
        "content": [
          "6cm²/sec"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Mathematical Application in Business"
  },
  {
    "id": 2701,
    "content": [
      "The product of two positive real numbers is 100, such that the sum of two times the first number and eight times the second number is minimum. Which of the following pairs of numbers are the first and the second numbers respectively?"
    ],
    "explanation": [
      "Let the two numbers be x and y. We have the constraint xy = 100, so y = 100/x.",
      "We want to minimize the sum S = 2x + 8y.",
      "Substitute y into the sum equation:\n$$\nS(x) = 2x + 8\\left(\\frac{100}{x}\\right) = 2x + 800x^{-1}\n$$",
      "To find the minimum, take the derivative and set it to zero:\n$$\nS'(x) = 2 - 800x^{-2} = 2 - \\frac{800}{x^2}\n$$\n$$\nS'(x) = 0 \\implies 2 = \\frac{800}{x^2} \\implies 2x^2 = 800 \\implies x^2 = 400\n$$",
      "Since x must be positive, x = 20.",
      "Then y = 100/x = 100/20 = 5. The two numbers are 20 and 5."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_APPLICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10812,
        "content": [
          "25 and 4"
        ],
        "isCorrect": false
      },
      {
        "id": 10813,
        "content": [
          "20 and 5"
        ],
        "isCorrect": true
      },
      {
        "id": 10814,
        "content": [
          "1 and 99"
        ],
        "isCorrect": false
      },
      {
        "id": 10815,
        "content": [
          "50 and 2"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Mathematical Application in Business"
  },
  {
    "id": 2702,
    "content": [
      "The maximum profit that a company can make if the profit function is given by P(x) = 36 + 72x - 18x² is"
    ],
    "explanation": [
      "The profit function P(x) = -18x² + 72x + 36 is a downward-opening parabola. The maximum value occurs at the vertex.",
      "The x-coordinate of the vertex is given by the formula x = -b/(2a).",
      "Here, a = -18 and b = 72.\n$$\nx = \\frac{-72}{2(-18)} = \\frac{-72}{-36} = 2\n$$\nTo find the maximum profit, substitute x=2 into the profit function:\n$$\nP(2) = 36 + 72(2) - 18(2)^2 = 36 + 144 - 18(4) = 180 - 72 = 108\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_APPLICATION",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10816,
        "content": [
          "124"
        ],
        "isCorrect": false
      },
      {
        "id": 10817,
        "content": [
          "31"
        ],
        "isCorrect": false
      },
      {
        "id": 10818,
        "content": [
          "2232"
        ],
        "isCorrect": false
      },
      {
        "id": 10819,
        "content": [
          "108"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Mathematical Application in Business"
  },
  {
    "id": 2703,
    "content": [
      "If\n$$\nf(x) = \\begin{cases} k(2^x), & \\text{if } x > 2 \\\\ x^3 - x + 1, & \\text{if } x \\leq 2 \\end{cases}\n$$\n, then for what value of k is f continuous at x = 2?"
    ],
    "explanation": [
      "For f to be continuous at x=2, the left-hand limit and the right-hand limit must be equal.",
      "Left-hand limit:\n$$\n\\lim_{x\\to 2^-} f(x) = \\lim_{x\\to 2^-} (x^3 - x + 1)\n$$\n$$\n= 2^3 - 2 + 1 = 8 - 2 + 1 = 7\n$$",
      "Right-hand limit:\n$$\n\\lim_{x\\to 2^+} f(x) = \\lim_{x\\to 2^+} k(2^x)\n$$\n$$\n= k(2^2) = 4k\n$$",
      "Set the limits equal:\n$$\n4k = 7 \\implies k = 7/4\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10820,
        "content": [
          "7/4"
        ],
        "isCorrect": true
      },
      {
        "id": 10821,
        "content": [
          "4"
        ],
        "isCorrect": false
      },
      {
        "id": 10822,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 10823,
        "content": [
          "7/2"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2704,
    "content": [
      "Which of the following is equal to\n$$\n\\sin^{-1}(\\sin(\\frac{5\\pi}{4})) \\ \\text{?}\n$$"
    ],
    "explanation": [
      "The range of the arcsin function ($$\\sin^{-1}$$) is [-π/2, π/2].",
      "First, evaluate the inside: $$\\sin(\\frac{5\\pi}{4})$$. The angle 5π/4 is in Quadrant III, where sine is negative. The reference angle is π/4.\n$$\n\\sin(\\frac{5\\pi}{4}) = -\\sin(\\frac{\\pi}{4}) = -\\frac{\\sqrt{2}}{2}\n$$",
      "Now, find $$\\sin^{-1}(-\\frac{\\sqrt{2}}{2})$$. We need the angle θ in [-π/2, π/2] for which sin(θ) = -√2/2. This angle is -π/4."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10824,
        "content": [
          "$$-\\frac{\\pi}{4}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10825,
        "content": [
          "$$\\frac{5\\pi}{4}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10826,
        "content": [
          "$$-\\frac{\\sqrt{2}}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10827,
        "content": [
          "$$\\frac{\\sqrt{2}}{2}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 5,
    "unitName": "Introduction to Trigonometry"
  },
  {
    "id": 2705,
    "content": [
      "Which one of the following is true about \n$$\nf(x) = -2 + 3\\sin(\\frac{1}{2}x + 3) \\ \\text{?}\n$$"
    ],
    "explanation": [
      "The function is in the form f(x) = D + A sin(B(x-C)).",
      "Amplitude is |A| = |3| = 3.",
      "Period is\n$$\n2\\pi/|B| = 2\\pi/(1/2) = 4\\pi\n$$",
      "Vertical shift is D = -2. The range of sin is [-1, 1], so the range of 3sin(...) is [-3, 3]. After shifting down by 2, the range becomes [-3-2, 3-2] = [-5, 1]. This statement is true.",
      "Phase shift requires factoring:\n$$\n\\sin(\\frac{1}{2}(x+6))\n$$\nThe phase shift is -6."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10828,
        "content": [
          "The period is 2π"
        ],
        "isCorrect": false
      },
      {
        "id": 10829,
        "content": [
          "The amplitude is 1"
        ],
        "isCorrect": false
      },
      {
        "id": 10830,
        "content": [
          "The range is [-5, 1]"
        ],
        "isCorrect": true
      },
      {
        "id": 10831,
        "content": [
          "The phase shift is 6"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Trigonometric Function"
  },
  {
    "id": 2706,
    "content": [
      "If the 1st and 4th terms of a geometric progression are 3 and 81 respectively, what is the common ratio for this progression?"
    ],
    "explanation": [
      "Let the first term be a₁ and the common ratio be r. The nth term is given by\n$$\na_n = a_1 r^{n-1}\n$$",
      "We are given a₁ = 3 and a₄ = 81.",
      "Using the formula for the 4th term:\n$$\na_4 = a_1 r^{4-1} \\implies 81 = 3 \\cdot r^3\n$$\n$$\nr^3 = \\frac{81}{3} = 27\n$$\n$$\nr = \\sqrt{27} = 3\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10832,
        "content": [
          "1/3"
        ],
        "isCorrect": false
      },
      {
        "id": 10833,
        "content": [
          "9"
        ],
        "isCorrect": false
      },
      {
        "id": 10834,
        "content": [
          "1/9"
        ],
        "isCorrect": false
      },
      {
        "id": 10835,
        "content": [
          "3"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2707,
    "content": [
      "If the inverse of the matrix $$\\begin{pmatrix} x & 2x \\\\ -x & x \\end{pmatrix}$$ is $$\\begin{pmatrix} -1 & -2 \\\\ 1 & 1 \\end{pmatrix}$$, then which one of the following is the value of x?"
    ],
    "explanation": [
      "To find the value of x, we use the property that a matrix multiplied by its inverse equals the identity matrix, for a 2x2 matrix the identity matrix equals\n$$\nI = \\begin{pmatrix} 1 & 0 \\\\ 0 & 1 \\end{pmatrix}\n$$\nSet up the equation:\n$$\n\\begin{pmatrix} x & 2x \\\\ -x & x \\end{pmatrix} \\begin{pmatrix} -1 & -2 \\\\ 1 & 1 \\end{pmatrix} = \\begin{pmatrix} 1 & 0 \\\\ 0 & 1 \\end{pmatrix}\n$$\nPerform the matrix multiplication on the left side:\n$$\n\\begin{pmatrix} (-x+2x) & (-2x+2x) \\\\ (x+x) & (2x+x) \\end{pmatrix}\n$$\nSimplify the resulting matrix:\n$$\n\\begin{pmatrix} x & 0 \\\\ 2x & 3x \\end{pmatrix} = \\begin{pmatrix} 1 & 0 \\\\ 0 & 1 \\end{pmatrix}\n$$\nEquate the corresponding elements to find x. By comparing the elements in the bottom-right corner, we get the equation:\n$$\n3x = 1\n$$\n$$\nx = \\frac{1}{3}\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10836,
        "content": [
          "-1"
        ],
        "isCorrect": false
      },
      {
        "id": 10837,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 10838,
        "content": [
          "-1/3"
        ],
        "isCorrect": false
      },
      {
        "id": 10839,
        "content": [
          "1/3"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Matrices"
  },
  {
    "id": 2708,
    "content": [
      "What is the set of values of k so that the system\n$$\n\\begin{cases} x - y + z = 3 \\\\ 2x + y - z = 4 \\\\ kx - 2y - z = 5 \\end{cases}\n$$\nhas a solution?"
    ],
    "explanation": [
      "The system will have a unique solution if the determinant of the coefficient matrix is non-zero.",
      "The coefficient matrix is\n$$\nA = \\begin{pmatrix} 1 & -1 & 1 \\\\ 2 & 1 & -1 \\\\ k & -2 & -1 \\end{pmatrix}\n$$",
      "Calculate the determinant:\n$$\n\\det(A) = 1(1(-1) - (-1)(-2)) - (-1)(2(-1) - (-1)k) + 1(2(-2) - 1k)\n$$\n$$\n\\det(A) = 1(-1 - 2) + 1(-2 + k) + 1(-4 - k)\n$$\n$$\n\\det(A) = -3 - 2 + k - 4 - k = -9\n$$",
      "Since the determinant is -9, which is never zero regardless of the value of k, the system always has a unique solution. Therefore, the set of values for k is all real numbers, R."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10840,
        "content": [
          "R"
        ],
        "isCorrect": true
      },
      {
        "id": 10841,
        "content": [
          "R\\{1}"
        ],
        "isCorrect": false
      },
      {
        "id": 10842,
        "content": [
          "R\\{-1}"
        ],
        "isCorrect": false
      },
      {
        "id": 10843,
        "content": [
          "R\\{-1, 1}"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 2709,
    "content": [
      "Let $$A = \\begin{pmatrix} 1 & 2 \\\\ 3 & 4 \\end{pmatrix}$$ and $$B = \\begin{pmatrix} 2 & -1 \\\\ -1 & 3 \\end{pmatrix}$$. Then which of the following is equal to 3A + 2B?"
    ],
    "explanation": [
      "First, perform scalar multiplication on each matrix.\n$$\n3A = 3 \\begin{pmatrix} 1 & 2 \\\\ 3 & 4 \\end{pmatrix} = \\begin{pmatrix} 3 & 6 \\\\ 9 & 12 \\end{pmatrix}\n$$\n$$\n2B = 2 \\begin{pmatrix} 2 & -1 \\\\ -1 & 3 \\end{pmatrix} = \\begin{pmatrix} 4 & -2 \\\\ -2 & 6 \\end{pmatrix}\n$$",
      "Now, add the corresponding elements of the two resulting matrices.\n$$\n3A + 2B = \\begin{pmatrix} 3+4 & 6+(-2) \\\\ 9+(-2) & 12+6 \\end{pmatrix} = \\begin{pmatrix} 7 & 4 \\\\ 7 & 18 \\end{pmatrix}\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10844,
        "content": [
          "$$\n\\begin{pmatrix} 7 & 4 \\\\ 7 & 18 \\end{pmatrix}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10845,
        "content": [
          "$$\n\\begin{pmatrix} 7 & 4 \\\\ 7 & 7 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10846,
        "content": [
          "$$\n\\begin{pmatrix} 3 & 1 \\\\ 2 & 7 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10847,
        "content": [
          "$$\n\\begin{pmatrix} 3 & 4 \\\\ 2 & 18 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Matrices"
  },
  {
    "id": 2710,
    "content": [
      "Which of the following is an interval at which the function $$f(x) = \\frac{1}{x-1} - \\sqrt{4-x^2}$$ is differentiable?"
    ],
    "explanation": [
      "A function is differentiable where its derivative is defined.",
      "First, find the derivative of f(x):\n$$\nf'(x) = \\frac{-1}{(x-1)^2} - \\frac{1}{2\\sqrt{4-x^2}}(-2x)\n$$\n$$\n= \\frac{-1}{(x-1)^2} + \\frac{x}{\\sqrt{4-x^2}}\n$$",
      "For f'(x) to be defined, two conditions must be met:\n    1. The denominator (x-1)² cannot be zero, so x ≠ 1.\n    2. The expression inside the square root in the denominator must be strictly positive, so 4 - x² > 0. This implies x² < 4, which means -2 < x < 2.",
      "Combining these conditions, the function is differentiable on the interval (-2, 2), excluding the point x=1. This is represented as (-2, 1) U (1, 2).\n    IsGrouped: false\n    GroupId: -1\n    GroupIndex: -1\n    SharedItemId: -1"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10848,
        "content": [
          "(-2, 1) U (1, 2)"
        ],
        "isCorrect": true
      },
      {
        "id": 10849,
        "content": [
          "(-2, 2)"
        ],
        "isCorrect": false
      },
      {
        "id": 10850,
        "content": [
          "(-∞, -2) U (2, ∞)"
        ],
        "isCorrect": false
      },
      {
        "id": 10851,
        "content": [
          "[-2, 1) U (1, 2]"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2711,
    "content": [
      "The function $$f(x) = (x-1)^{2/3}$$ is differentiable on"
    ],
    "explanation": [
      "To determine differentiability, we find the derivative and check its domain.\n$$\nf'(x) = \\frac{d}{dx}(x-1)^{2/3}\n$$\n$$\n= \\frac{2}{3}(x-1)^{-1/3} = \\frac{2}{3\\sqrt{x-1}}\n$$",
      "The derivative f'(x) is defined for all real numbers except where the denominator is zero. The denominator is zero when x-1=0, which is at x=1. At x=1, the tangent line is vertical, so the function is not differentiable there.",
      "Therefore, the function is differentiable on all real numbers except 1, which is the union of intervals (-∞, 1) U (1, ∞)."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10852,
        "content": [
          "[1, ∞)"
        ],
        "isCorrect": false
      },
      {
        "id": 10853,
        "content": [
          "(-∞, 1]"
        ],
        "isCorrect": false
      },
      {
        "id": 10854,
        "content": [
          "(-∞, -1) U (-1, ∞)"
        ],
        "isCorrect": false
      },
      {
        "id": 10855,
        "content": [
          "(-∞, 1) U (1, ∞)"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2712,
    "content": [
      "What is the slope of the line tangent to the graph of f(x) = x² + tanx at (π, f(π))?"
    ],
    "explanation": [
      "The slope of the tangent line is the value of the derivative at the given point.",
      "First, find the derivative of f(x):\n$$\nf'(x) = \\frac{d}{dx}(x^2 + \\tan x) = 2x + \\sec^2 x\n$$",
      "Now, evaluate the derivative at x = π:\n$$\nf'(\\pi) = 2\\pi + \\sec^2(\\pi)\n$$",
      "We know that $$\\cos(\\pi) = -1$$, so $$\\sec(\\pi) = 1/\\cos(\\pi) = -1$$.\n$$\nf'(\\pi) = 2\\pi + (-1)^2 = 2\\pi + 1\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10856,
        "content": [
          "2π"
        ],
        "isCorrect": false
      },
      {
        "id": 10857,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 10858,
        "content": [
          "2π + 1"
        ],
        "isCorrect": true
      },
      {
        "id": 10859,
        "content": [
          "2π - 1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2713,
    "content": [
      "If f(x) = 4 - x²sinx, then which of the following expressions describes f'(x)?"
    ],
    "explanation": [
      "The derivative of the constant 4 is 0. We differentiate the term -x²sinx using the product rule, where u = -x² and v = sinx. So, u' = -2x and v' = cosx.\n$$\nf'(x) = u'v + uv' = (-2x)(\\sin x) + (-x^2)(\\cos x)\n$$\n$$\nf'(x) = -2x\\sin x - x^2\\cos x\n$$",
      "Factoring out -x from both terms gives:\n$$\nf'(x) = -x(2\\sin x + x\\cos x)\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10860,
        "content": [
          "-x(xcosx + 2sinx)"
        ],
        "isCorrect": true
      },
      {
        "id": 10861,
        "content": [
          "1 + cosx + 2sinx"
        ],
        "isCorrect": false
      },
      {
        "id": 10862,
        "content": [
          "x(xcosx - 2sinx)"
        ],
        "isCorrect": false
      },
      {
        "id": 10863,
        "content": [
          "1 - cosx - 2sinx"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2714,
    "content": [
      "Consider the sequence whose terms are $$a_1 = 6$$, and $$a_{n+1} = -\\frac{1}{3}(a_n)$$ for n∈N. Then what is the sum of the first ten terms is"
    ],
    "explanation": [
      "The sequence is a geometric progression with first term a = a₁ = 6 and common ratio r = -1/3.",
      "The sum of the first n terms of a geometric series is given by the formula\n$$\nS_n = \\frac{a(1 - r^n)}{1 - r}\n$$",
      "We need to find S₁₀:\n$$\nS_{10} = \\frac{6(1 - (-1/3)^{10})}{1 - (-1/3)}\n$$\n$$\n= \\frac{6(1 - (-1/3)^{10})}{1 + 1/3} = \\frac{6(1 - (-1/3)^{10})}{4/3}\n$$\n$$\nS_{10} = 6 \\cdot \\frac{3}{4} \\left(1 - \\left(-\\frac{1}{3}\\right)^{10}\\right)\n$$\n$$\n= \\frac{18}{4}\\left(1 - \\left(-\\frac{1}{3}\\right)^{10}\\right)\n$$\n$$\n= \\frac{9}{2}\\left(1 - \\left(-\\frac{1}{3}\\right)^{10}\\right)\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10864,
        "content": [
          "$$9\\left(1 - \\left(-\\frac{1}{3}\\right)^{10}\\right)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10865,
        "content": [
          "$$\\frac{9}{2}\\left(1 - \\left(-\\frac{1}{3}\\right)^{10}\\right)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10866,
        "content": [
          "$$9\\left(1 - \\left(-\\frac{1}{3}\\right)^{11}\\right)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10867,
        "content": [
          "$$\\frac{9}{2}\\left(1 - \\left(-\\frac{1}{3}\\right)^{11}\\right)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2715,
    "content": [
      "Which one of the following is a row reduced echelon form of the matrix\n$$\n\\begin{pmatrix} 1 & 1 & 1 \\\\ 2 & 1 & 3 \\\\ 4 & -1 & 4 \\end{pmatrix} \\ \\text{?}\n$$"
    ],
    "explanation": [
      "We use Gaussian elimination to find the row-reduced echelon form (RREF).",
      "Start with\n$$\n\\begin{pmatrix} 1 & 1 & 1 \\\\ 2 & 1 & 3 \\\\ 4 & -1 & 4 \\end{pmatrix}\n$$\nR2 → R2 - 2R1; R3 → R3 - 4R1 gives\n$$\n\\begin{pmatrix} 1 & 1 & 1 \\\\ 0 & -1 & 1 \\\\ 0 & -5 & 0 \\end{pmatrix}\n$$\nR2 → -R2 gives\n$$\n\\begin{pmatrix} 1 & 1 & 1 \\\\ 0 & 1 & -1 \\\\ 0 & -5 & 0 \\end{pmatrix}\n$$\nR1 → R1 - R2; R3 → R3 + 5R2 gives\n$$\n\\begin{pmatrix} 1 & 0 & 2 \\\\ 0 & 1 & -1 \\\\ 0 & 0 & -5 \\end{pmatrix}\n$$\nR3 → -1/5 R3 gives\n$$\n\\begin{pmatrix} 1 & 0 & 2 \\\\ 0 & 1 & -1 \\\\ 0 & 0 & 1 \\end{pmatrix}\n$$\nR1 → R1 - 2R3; R2 → R2 + R3 gives\n$$\n\\begin{pmatrix} 1 & 0 & 0 \\\\ 0 & 1 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix}\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10868,
        "content": [
          "$$\n\\begin{pmatrix} 1 & 0 & 0 \\\\ 0 & 0 & 1 \\\\ 0 & 0 & 0 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10869,
        "content": [
          "$$\n\\begin{pmatrix} 1 & 1 & 1 \\\\ 0 & 1 & 3 \\\\ 0 & 0 & 1 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10870,
        "content": [
          "$$\n\\begin{pmatrix} 1 & 0 & 0 \\\\ 0 & 1 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10871,
        "content": [
          "$$\n\\begin{pmatrix} 1 & 0 & 0 \\\\ 0 & 1 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Matrices"
  },
  {
    "id": 2716,
    "content": [
      "For what value of k does the system\n$$\n\\begin{cases} 2x - y + 4z = 6 \\\\ kx - y - z = 2 \\\\ x + y + 2z = 8 \\end{cases}\n$$\nhas a unique solution?"
    ],
    "explanation": [
      "A system of linear equations has a unique solution if the determinant of the coefficient matrix is non-zero.",
      "The coefficient matrix is\n$$\nA = \\begin{pmatrix} 2 & -1 & 4 \\\\ k & -1 & -1 \\\\ 1 & 1 & 2 \\end{pmatrix}\n$$",
      "Calculate the determinant:\n$$\n\\det(A) = 2(-1(2) - (-1)(1)) - (-1)(k(2) - (-1)(1)) + 4(k(1) - (-1)(1))\n$$\n$$\n\\det(A) = 2(-2+1) + (2k+1) + 4(k+1)\n$$\n$$\n= -2 + 2k + 1 + 4k + 4 = 6k + 3\n$$",
      "For a unique solution, det(A) ≠ 0. So,\n$$\n6k + 3 \\neq 0 \\implies 6k \\neq -3 \\implies k \\neq -1/2\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_EQUATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10872,
        "content": [
          "k ≠ -1/2"
        ],
        "isCorrect": true
      },
      {
        "id": 10873,
        "content": [
          "k ≠ -1/3, 1/2"
        ],
        "isCorrect": false
      },
      {
        "id": 10874,
        "content": [
          "k ≠ -1/6"
        ],
        "isCorrect": false
      },
      {
        "id": 10875,
        "content": [
          "k ≠ 1/2"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Solving Equation"
  },
  {
    "id": 2717,
    "content": [
      "Let $$A = \\begin{pmatrix} 2 & -1 \\\\ 1 & 3 \\end{pmatrix}$$ and $$B = \\begin{pmatrix} 2 & 5 & -4 \\\\ 3 & 2 & 6 \\end{pmatrix}$$. The AB is?"
    ],
    "explanation": [
      "To find the product AB, we multiply the rows of matrix A by the columns of matrix B. The result will be a 2x3 matrix.\n$$\nAB = \\begin{pmatrix} 2 & -1 \\\\ 1 & 3 \\end{pmatrix} \\begin{pmatrix} 2 & 5 & -4 \\\\ 3 & 2 & 6 \\end{pmatrix}\n$$\n$$\n= \\begin{pmatrix} (2)(2)+(-1)(3) & (2)(5)+(-1)(2) & (2)(-4)+(-1)(6) \\\\ (1)(2)+(3)(3) & (1)(5)+(3)(2) & (1)(-4)+(3)(6) \\end{pmatrix}\n$$\n$$\n= \\begin{pmatrix} 4-3 & 10-2 & -8-6 \\\\ 2+9 & 5+6 & -4+18 \\end{pmatrix}\n$$\n$$\n= \\begin{pmatrix} 1 & 8 & -14 \\\\ 11 & 11 & 14 \\end{pmatrix}\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_MATRICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10876,
        "content": [
          "$$\n\\begin{pmatrix} 8 & 13 & -18 \\\\ -1 & 8 & -2 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10877,
        "content": [
          "$$\n\\begin{pmatrix} 13 & 1 \\\\ 16 & 8 \\\\ 10 & -14 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10878,
        "content": [
          "$$\n\\begin{pmatrix} 8 & -1 \\\\ 13 & 8 \\\\ 18 & -2 \\end{pmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10879,
        "content": [
          "$$\n\\begin{pmatrix} 1 & 8 & -14 \\\\ 11 & 11 & 14 \\end{pmatrix}\n$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Matrices"
  },
  {
    "id": 2718,
    "content": [
      "The following graph is the graph of the function $$y = x^{m/n}$$, where m and n are positive integers and n ≠ 0.",
      "images/maths/year_2012/q36_1.png",
      "Which of the following is true about m and n?"
    ],
    "explanation": [
      "The curve starts at the origin and is only in the right half (x ≥ 0). This means the denominator n is even, because for even roots (like √x, ⁴√x), negative x-values are not allowed.",
      "The graph is steeper than y = x, meaning the exponent (m/n > 1). So (m > n).",
      "The graph is increasing (not reflected or inverted), meaning (m) is odd, not even."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2012/q36_1.png"
    ],
    "choices": [
      {
        "id": 10880,
        "content": [
          "m is odd, n is even and m > n."
        ],
        "isCorrect": true
      },
      {
        "id": 10881,
        "content": [
          "m is even, n is odd and m < n."
        ],
        "isCorrect": false
      },
      {
        "id": 10882,
        "content": [
          "m is odd, n is even and m < n."
        ],
        "isCorrect": false
      },
      {
        "id": 10883,
        "content": [
          "m is even, n is odd and m > n."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2719,
    "content": [
      "Consider the experiment of rolling a die whose sample space is {1,2,3,4,5,6}. If two dice are rolled simultaneously, what is the probability that a prime number turns up on one of the dice and a composite number on the other?"
    ],
    "explanation": [
      "On a standard die: Prime numbers are {2, 3, 5} (3 outcomes). Composite numbers are {4, 6} (2 outcomes). The number 1 is neither.",
      "The probability of rolling a prime is P(Prime) = 3/6 = 1/2.",
      "The probability of rolling a composite is P(Composite) = 2/6 = 1/3.",
      "We want the probability of (Prime on 1st AND Composite on 2nd) OR (Composite on 1st AND Prime on 2nd).\n$$\nP(\\text{event}) = P(\\text{Prime}) \\times P(\\text{Composite}) + P(\\text{Composite}) \\times P(\\text{Prime})\n$$\n$$\nP(\\text{event}) = \\left(\\frac{1}{2}\\right) \\times \\left(\\frac{1}{3}\\right) + \\left(\\frac{1}{3}\\right) \\times \\left(\\frac{1}{2}\\right)\n$$\n$$\n= \\frac{1}{6} + \\frac{1}{6} = \\frac{2}{6} = \\frac{1}{3}\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_PROBABILITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10884,
        "content": [
          "1/3"
        ],
        "isCorrect": true
      },
      {
        "id": 10885,
        "content": [
          "2/3"
        ],
        "isCorrect": false
      },
      {
        "id": 10886,
        "content": [
          "5/6"
        ],
        "isCorrect": false
      },
      {
        "id": 10887,
        "content": [
          "1/6"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 8,
    "unitName": "Probability"
  },
  {
    "id": 2720,
    "content": [
      "Consider the following frequency distribution of grouped data.",
      "images/maths/year_2012/q38_1.png",
      "Which of the following statements is true about this frequency distribution?"
    ],
    "explanation": [
      "Let's analyze the options based on the table, noting the classes are listed in descending order.",
      "A. The class interval (width) is the difference between consecutive lower limits, e.g., 95 - 90 = 5. So, (A) is false.",
      "B. The second class is 90-94. Its upper limit is 94. So, (B) is false.",
      "C. Class boundaries are found by subtracting 0.5 from the lower limit and adding 0.5 to the upper limit. For the class 85-89, the boundaries are 84.5-89.5. For the class 90-94, the boundaries are 89.5-94.5. The interval 85.5-90.5 is not a valid class boundary. So, (C) is false.",
      "D. The fourth class from the top is 80-84. Its midpoint is (80 + 84) / 2 = 164 / 2 = 82. So, (D) is true."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/maths/year_2012/q38_1.png"
    ],
    "choices": [
      {
        "id": 10888,
        "content": [
          "The class interval is 4"
        ],
        "isCorrect": false
      },
      {
        "id": 10889,
        "content": [
          "95.5 is the upper limit of the second class."
        ],
        "isCorrect": false
      },
      {
        "id": 10890,
        "content": [
          "85.5-90.5 is one of the class boundaries."
        ],
        "isCorrect": false
      },
      {
        "id": 10891,
        "content": [
          "82 is the class midpoint of the fourth class."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 2721,
    "content": [
      "Let $$f(x) = \\frac{1}{(1-\\sqrt{x})^2}$$ Then f'(4) is equal"
    ],
    "explanation": [
      "Rewrite the function as\n$$\nf(x) = (1 - x^{1/2})^{-2}\n$$",
      "Use the chain rule to find the derivative:\n$$\nf'(x) = -2(1 - x^{1/2})^{-3} \\cdot \\frac{d}{dx}(1 - x^{1/2})\n$$\n$$\nf'(x) = -2(1 - \\sqrt{x})^{-3} \\cdot \\left(-\\frac{1}{2}x^{-1/2}\\right)\n$$\n$$\n= \\frac{1}{(1-\\sqrt{x})^3 \\cdot \\sqrt{x}}\n$$",
      "Evaluate the derivative at x = 4:\n$$\nf'(4) = \\frac{1}{(1-\\sqrt{4})^3 \\cdot \\sqrt{4}}\n$$\n$$\n= \\frac{1}{(1-2)^3 \\cdot 2} = \\frac{1}{(-1)^3 \\cdot 2}\n$$\n$$\n= \\frac{1}{-1 \\cdot 2} = -\\frac{1}{2}\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10892,
        "content": [
          "1/2"
        ],
        "isCorrect": false
      },
      {
        "id": 10893,
        "content": [
          "-1/2"
        ],
        "isCorrect": true
      },
      {
        "id": 10894,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 10895,
        "content": [
          "2"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2722,
    "content": [
      "Given the function f(x) = 2x² - 3x + 1, what is the slope of the line passing through the points (-1, f(-1)) and (2, f(2))?"
    ],
    "explanation": [
      "This is asking for the slope of the secant line connecting two points on the function's graph.",
      "First, find the coordinates of the points:\n$$\nf(-1) = 2(-1)^2 - 3(-1) + 1 = 2 + 3 + 1 = 6. \\text{ Point is } (-1, 6).\n$$\n$$\nf(2) = 2(2)^2 - 3(2) + 1 = 8 - 6 + 1 = 3. \\text{ Point is } (2, 3).\n$$",
      "Now use the slope formula:\n$$\nm = \\frac{y_2 - y_1}{x_2 - x_1}\n$$\n$$\nm = \\frac{3 - 6}{2 - (-1)} = \\frac{-3}{3} = -1\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10896,
        "content": [
          "-1"
        ],
        "isCorrect": true
      },
      {
        "id": 10897,
        "content": [
          "-1/3"
        ],
        "isCorrect": false
      },
      {
        "id": 10898,
        "content": [
          "1/3"
        ],
        "isCorrect": false
      },
      {
        "id": 10899,
        "content": [
          "1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2723,
    "content": [
      "Let $$\\vec{u}=(2,0)$$ and $$\\vec{v}=(-1,3)$$ be two vectors in the plane and $$\\vec{w} = -3\\vec{u}+2\\vec{v}$$. Which one of the following is the unit vector in the direction of $$\\vec{w}$$, in terms of the standard unit vectors $$\\vec{i}$$ and $$\\vec{j}$$?"
    ],
    "explanation": [
      "First, calculate the vector $$\\vec{w}$$.\n$$\n\\vec{w} = -3(2,0) + 2(-1,3) = (-6,0) + (-2,6) = (-8,6)\n$$",
      "In terms of standard unit vectors,\n$$\n\\vec{w} = -8\\vec{i} + 6\\vec{j}\n$$",
      "Next, find the magnitude of $$\\vec{w}$$.\n$$\n||\\vec{w}|| = \\sqrt{(-8)^2 + 6^2} = \\sqrt{64 + 36} = \\sqrt{100} = 10\n$$",
      "The unit vector is\n$$\n\\hat{w} = \\frac{\\vec{w}}{||\\vec{w}||}\n$$\n$$\n\\hat{w} = \\frac{-8\\vec{i} + 6\\vec{j}}{10}\n$$\n$$\n= -\\frac{8}{10}\\vec{i} + \\frac{6}{10}\\vec{j}\n$$\n$$\n= -\\frac{4}{5}\\vec{i} + \\frac{3}{5}\\vec{j}\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_VECTORS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10900,
        "content": [
          "$$\n\\frac{4}{5}\\vec{i} - \\frac{3}{5}\\vec{j}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10901,
        "content": [
          "$$\n-\\frac{4}{5}\\vec{i} + \\frac{3}{5}\\vec{j}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10902,
        "content": [
          "$$\n\\frac{3}{5}\\vec{i} - \\frac{4}{5}\\vec{j}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10903,
        "content": [
          "$$\n-\\frac{3}{5}\\vec{i} + \\frac{4}{5}\\vec{j}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 8,
    "unitName": "Vectors in 2D"
  },
  {
    "id": 2724,
    "content": [
      "Which of the following is NOT true about the scalar product of vectors?"
    ],
    "explanation": [
      "The scalar (dot) product of two vectors $$\\vec{a}$$ and $$\\vec{b}$$ is given by\n$$\n\\vec{a} \\cdot \\vec{b} = ||\\vec{a}|| ||\\vec{b}|| \\cos(\\theta)\n$$",
      "For non-zero parallel vectors, the angle θ between them is 0° or 180°. So, cos(θ) is 1 or -1. The scalar product will be non-zero.",
      "For perpendicular vectors, θ = 90°, so cos(θ) = 0, and the scalar product is zero.",
      "The statement that the scalar product of non-zero parallel vectors is zero is false."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_VECTORS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10904,
        "content": [
          "The scalar product is commutative."
        ],
        "isCorrect": false
      },
      {
        "id": 10905,
        "content": [
          "The scalar product of non-zero parallel vectors is zero."
        ],
        "isCorrect": true
      },
      {
        "id": 10906,
        "content": [
          "The scalar product is distributive over addition of vectors."
        ],
        "isCorrect": false
      },
      {
        "id": 10907,
        "content": [
          "The scalar product of perpendicular vectors is zero."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Vectors"
  },
  {
    "id": 2725,
    "content": [
      "Which one of the following is NOT true about transformation?"
    ],
    "explanation": [
      "Rigid motions (isometries) are transformations that preserve distance and angles. The main types of rigid motions are translations, rotations, and reflections. Since reflections preserve the size and shape of figures, they are, by definition, rigid motions. Therefore, the statement \"Reflection is not a rigid motion\" is false."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRANSFORMATION_PLANE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10908,
        "content": [
          "Rotations move triangles in to congruent triangles."
        ],
        "isCorrect": false
      },
      {
        "id": 10909,
        "content": [
          "Translations move angles to congruent angles."
        ],
        "isCorrect": false
      },
      {
        "id": 10910,
        "content": [
          "Rotation is a rigid motion."
        ],
        "isCorrect": false
      },
      {
        "id": 10911,
        "content": [
          "Reflection is not a rigid motion."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Transformation of the Plane"
  },
  {
    "id": 2726,
    "content": [
      "If z = -1+i and w = 1-3i, what is the simplified form of\n$$\n\\frac{5z}{w} + |z|^2w \\ \\text{?}\n$$"
    ],
    "explanation": [
      "First, calculate$$|z|^2$$:\n$$\n|z|^2 = (-1)^2 + (1)^2 = 1+1=2\n$$\nNext, calculate $$\\frac{5z}{w}$$:\n$$\n\\frac{5(-1+i)}{1-3i} = \\frac{5(-1+i)(1+3i)}{(1-3i)(1+3i)}\n$$\n$$\n= \\frac{5(-1-3i+i+3i^2)}{1^2 - (3i)^2}\n$$\n$$\n= \\frac{5(-1-2i-3)}{1+9} = \\frac{5(-4-2i)}{10}\n$$\n$$\n= \\frac{-4-2i}{2} = -2-i\n$$\nNow calculate $$|z|^2w$$:\n$$\n2(1-3i) = 2-6i\n$$\nFinally, add the two parts:\n$$\n(-2-i) + (2-6i) = -7i\n$$\nNote: The question on the paper doesn't include the correct choice, so we added the correct choice here."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_COMPLEX_NUMBERS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10912,
        "content": [
          "4i"
        ],
        "isCorrect": false
      },
      {
        "id": 10913,
        "content": [
          "5i"
        ],
        "isCorrect": false
      },
      {
        "id": 10914,
        "content": [
          "-7i"
        ],
        "isCorrect": true
      },
      {
        "id": 10915,
        "content": [
          "4+5i"
        ],
        "isCorrect": true
      },
      {
        "id": 10916,
        "content": [
          "5+4i"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2727,
    "content": [
      "A real number a is the limit of a sequence {aₙ} if"
    ],
    "explanation": [
      "A real number a is the limit of a sequence {aₙ} if, for all ε > 0, there exists N such that for all n > N, |aₙ − a| < ε — meaning the terms become **arbitrarily close to a** from some point onward."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10917,
        "content": [
          "a is closer to every term of the sequence."
        ],
        "isCorrect": false
      },
      {
        "id": 10918,
        "content": [
          "a ≤ |aₙ| for all n."
        ],
        "isCorrect": false
      },
      {
        "id": 10919,
        "content": [
          "a is very close to all terms aₙ from some arbitrarily big n onward."
        ],
        "isCorrect": true
      },
      {
        "id": 10920,
        "content": [
          "|aₙ| ≤ aₙ ≤ |a| for all n."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2728,
    "content": [
      "Which one of the following is the standard form of the equation of the ellipse with vertices: (3, 1), (3, 9); and minor axis of length 6?"
    ],
    "explanation": [
      "The vertices are (3,1) and (3,9). Since the x-coordinates are the same, this is a vertical ellipse.",
      "The center (h,k) is the midpoint of the vertices:\n$$\n(\\frac{3+3}{2}, \\frac{1+9}{2}) = (3, 5)\n$$\nThe distance from the center to a vertex is the semi-major axis, a. a = 9-5=4, so a²=16.",
      "The length of the minor axis is 2b = 6, so the semi-minor axis b = 3, and b²=9.",
      "The standard equation for a vertical ellipse is\n$$\n\\frac{(x-h)^2}{b^2} + \\frac{(y-k)^2}{a^2} = 1\n$$",
      "Plugging in the values gives\n$$\n\\frac{(x-3)^2}{9} + \\frac{(y-5)^2}{16} = 1\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10921,
        "content": [
          "$$\n\\frac{(x-3)^2}{9} + \\frac{(y-5)^2}{16} = 1\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10922,
        "content": [
          "$$\n\\frac{(x+2)^2}{4} + \\frac{(y-3)^2}{9} = 1\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10923,
        "content": [
          "$$\n\\frac{(x-3)^2}{4} + \\frac{(y-3)^2}{36} = 1\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10924,
        "content": [
          "$$\n\\frac{(x-1)^2}{16} + \\frac{(y-9)^2}{64} = 1\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 2729,
    "content": [
      "What is the image of the ellipse\n$$\n\\frac{(x-3)^2}{6} + \\frac{(y-2)^2}{4} = 1\n$$\nwhen it is rotated through 90° about the origin?"
    ],
    "explanation": [
      "A 90° counter-clockwise rotation about the origin maps a point (x, y) to a new point (x', y') = (-y, x).",
      "To find the equation of the rotated ellipse, we solve for x and y in terms of x' and y': y = -x' and x = y'.",
      "Substitute these into the original ellipse equation:\n$$\n\\frac{(y' - 3)^2}{6} + \\frac{(-x' - 2)^2}{4} = 1\n$$\n$$\n\\frac{(y' - 3)^2}{6} + \\frac{(-(x' + 2))^2}{4} = 1\n$$\n$$\n\\frac{(x' + 2)^2}{4} + \\frac{(y' - 3)^2}{6} = 1\n$$",
      "Replacing (x', y') with (x, y), the new equation is\n$$\n\\frac{(x+2)^2}{4} + \\frac{(y-3)^2}{6} = 1\n$$",
      "Multiplying by the common denominator 24 gives\n$$\n6(x+2)^2 + 4(y-3)^2 = 24\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRANSFORMATION_PLANE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10925,
        "content": [
          "$$\n\\frac{(x-2)^2}{4} + \\frac{(y+3)^2}{6} = 1\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10926,
        "content": [
          "$$\n4(x+3)^2 + 6(y-2)^2 = 24\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10927,
        "content": [
          "$$\n\\frac{(x+2)^2}{6} + \\frac{(y-3)^2}{4} = 1\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10928,
        "content": [
          "$$\n6(x+2)^2 + 4(y-3)^2 = 24\n$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Transformation of the Plane"
  },
  {
    "id": 2730,
    "content": [
      "Let p and q be propositions with truth value True and False respectively. Then which of the following is correct?"
    ],
    "explanation": [
      "Given p is True (T) and q is False (F).",
      "A. (p ∨ ¬q) ⇒ q is (T ∨ ¬F) ⇒ F is (T ∨ T) ⇒ F is T ⇒ F, which is False.",
      "B. ¬p ⇒ q is ¬T ⇒ F is F ⇒ F, which is True.",
      "C. p ∨ (q ∧ ¬p) is T ∨ (F ∧ ¬T) is T ∨ (F ∧ F) is T ∨ F, which is True.",
      "D. (p ⇒ q) ∧ p is (T ⇒ F) ∧ T is F ∧ T, which is False.",
      "Therefore, the only correct statement is (C)."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_LOGIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10929,
        "content": [
          "(p ∨ ¬q) ⇒ q is True."
        ],
        "isCorrect": false
      },
      {
        "id": 10930,
        "content": [
          "¬p ⇒ q is False"
        ],
        "isCorrect": false
      },
      {
        "id": 10931,
        "content": [
          "p ∨ (q ∧ ¬p) is True."
        ],
        "isCorrect": true
      },
      {
        "id": 10932,
        "content": [
          "(p ⇒ q) ∧ p is True."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Further on Set"
  },
  {
    "id": 2731,
    "content": [
      "Let $$f(x) = \\sqrt{x+2}$$ and $$g(x) = x^2 - 1$$. What are the domain and range of the composition of f with g, f∘g respectively?"
    ],
    "explanation": [
      "The composition is\n$$\n(f \\circ g)(x) = f(g(x))\n$$\n$$\n= \\sqrt{(x^2-1)+2} = \\sqrt{x^2+1}\n$$",
      "Domain: The expression inside the square root, x²+1, is always positive for any real number x. Therefore, the domain of f∘g is all real numbers, R.",
      "Range: The minimum value of x² is 0. So the minimum value of x²+1 is 1. The minimum value of $$\\sqrt{x^2+1}$$ is $$\\sqrt{1}=1$$. As x increases, the value increases without bound. So the range is [1, ∞)."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10933,
        "content": [
          "R and [1, ∞)"
        ],
        "isCorrect": true
      },
      {
        "id": 10934,
        "content": [
          "R and [0, ∞)"
        ],
        "isCorrect": false
      },
      {
        "id": 10935,
        "content": [
          "[0, ∞) and [1, ∞)"
        ],
        "isCorrect": false
      },
      {
        "id": 10936,
        "content": [
          "[0, ∞) and [0, ∞)"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2732,
    "content": [
      "Given a rational function $$f(x) = \\frac{2x+4}{x-1}$$ which of the following is NOT true about its graph? The graph has;"
    ],
    "explanation": [
      "Let's check each statement.",
      "A. Horizontal asymptote: Since the degrees of the numerator and denominator are equal, the asymptote is the ratio of the leading coefficients, y = 2/1 = 2. True.",
      "B. Vertical asymptote: This occurs where the denominator is zero, so x-1=0, which means x=1. True.",
      "C. y-intercept: Set x=0. f(0) = (2(0)+4)/(0-1) = 4/-1 = -4. The y-intercept is (0, -4). True.",
      "D. x-intercept: Set y=f(x)=0. This occurs when the numerator is zero. 2x+4=0 → 2x=-4 → x=-2. The x-intercept is (-2, 0). The statement says it is (-4, 0), which is false."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10937,
        "content": [
          "a horizontal asymptote, y = 2."
        ],
        "isCorrect": false
      },
      {
        "id": 10938,
        "content": [
          "a vertical asymptote, x = 1."
        ],
        "isCorrect": false
      },
      {
        "id": 10939,
        "content": [
          "y - intercept (0, -4)."
        ],
        "isCorrect": false
      },
      {
        "id": 10940,
        "content": [
          "x - intercept at (-4, 0)."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2733,
    "content": [
      "$$\n\\lim_{x\\to\\infty} \\left(1 + \\frac{5}{x}\\right)^x\n$$\nis equal to"
    ],
    "explanation": [
      "This limit is in the standard form for the definition of the exponential function e. The general form is\n$$\n\\lim_{n\\to\\infty} \\left(1 + \\frac{k}{n}\\right)^n = e^k\n$$",
      "In this problem, k=5. Therefore, the limit is e⁵."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10941,
        "content": [
          "1/e"
        ],
        "isCorrect": false
      },
      {
        "id": 10942,
        "content": [
          "e⁵"
        ],
        "isCorrect": true
      },
      {
        "id": 10943,
        "content": [
          "5e"
        ],
        "isCorrect": false
      },
      {
        "id": 10944,
        "content": [
          "e⁻⁵"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2734,
    "content": [
      "Which of the following is true about limit of a function?"
    ],
    "explanation": [
      "Option C provides the correct informal definition of a limit. It describes the value the function gets close to as the input gets close to a certain point.",
      "A) is false; the limit of f(x)=c is c.",
      "B) is false; if they are not the same, the limit does not exist.",
      "D) is false; the limit can exist even if the function value is different (a removable discontinuity) or undefined at that point."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10945,
        "content": [
          "Limit of a constant function is always zero."
        ],
        "isCorrect": false
      },
      {
        "id": 10946,
        "content": [
          "Right hand and left hand limits are the same for every function."
        ],
        "isCorrect": false
      },
      {
        "id": 10947,
        "content": [
          "Intuitively, the limit of a function f is a y-value L to which f(x) approaches as x approaches to some specified number."
        ],
        "isCorrect": true
      },
      {
        "id": 10948,
        "content": [
          "Whenever the limit exists for a function it is the same as functional value."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2735,
    "content": [
      "Which of the following is equal to\n$$\n\\lim_{n\\to\\infty} \\frac{\\sin n\\pi}{n^2} \\ \\text{?}\n$$"
    ],
    "explanation": [
      "For any integer n, sin(nπ) is always 0. (sin(π)=0, sin(2π)=0, etc.).",
      "Therefore, the sequence is $$a_n = \\frac{0}{n^2} = 0$$ for all n ≥ 1.",
      "The limit of a constant sequence is the constant itself. Thus, $$\\lim_{n\\to\\infty} 0 = 0$$."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10949,
        "content": [
          "-1"
        ],
        "isCorrect": false
      },
      {
        "id": 10950,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 10951,
        "content": [
          "π"
        ],
        "isCorrect": false
      },
      {
        "id": 10952,
        "content": [
          "0"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2736,
    "content": [
      "If the functions f and g are continuous at x = c, then which one of the following combinations is continuous at x = c?"
    ],
    "explanation": [
      "The product of two continuous functions is continuous. Since f is continuous at c, f⋅f = f² is also continuous at c.",
      "The other options are not always true. (A) requires g(c) ≥ 0. (B) requires g(c) ≠ 0. (C) requires f to be one-to-one and its inverse may not be continuous everywhere."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10953,
        "content": [
          "√g"
        ],
        "isCorrect": false
      },
      {
        "id": 10954,
        "content": [
          "f/g"
        ],
        "isCorrect": false
      },
      {
        "id": 10955,
        "content": [
          "f⁻¹"
        ],
        "isCorrect": false
      },
      {
        "id": 10956,
        "content": [
          "f²"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2737,
    "content": [
      "What is the value of\n$$\n\\lim_{x\\to 0} \\frac{\\sin 4x}{\\sin 6x} \\ \\text{?}\n$$"
    ],
    "explanation": [
      "This limit can be solved using the property\n$$\n\\lim_{\\theta\\to 0} \\frac{\\sin\\theta}{\\theta} = 1\n$$",
      "We manipulate the expression to use this property:\n$$\n\\lim_{x\\to 0} \\frac{\\sin 4x}{\\sin 6x}\n$$\n$$\n= \\lim_{x\\to 0} \\frac{\\sin 4x}{4x} \\cdot \\frac{6x}{\\sin 6x} \\cdot \\frac{4x}{6x}$$\n$$\n= \\left(\\lim_{x\\to 0} \\frac{\\sin 4x}{4x}\\right) \\cdot \\left(\\lim_{x\\to 0} \\frac{6x}{\\sin 6x}\\right) \\cdot \\left(\\frac{4}{6}\\right)\n$$\n$$\n= (1) \\cdot (1) \\cdot \\frac{2}{3} = \\frac{2}{3}\n$$\nAlternatively, using L'Hôpital's Rule since it's the 0/0 form:\n$$\n\\lim_{x\\to 0} \\frac{\\frac{d}{dx}(\\sin 4x)}{\\frac{d}{dx}(\\sin 6x)}\n$$\n$$\n= \\lim_{x\\to 0} \\frac{4\\cos 4x}{6\\cos 6x}\n$$\n$$\n= \\frac{4\\cos(0)}{6\\cos(0)} = \\frac{4}{6} = \\frac{2}{3}\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10957,
        "content": [
          "3/2"
        ],
        "isCorrect": false
      },
      {
        "id": 10958,
        "content": [
          "2/3"
        ],
        "isCorrect": true
      },
      {
        "id": 10959,
        "content": [
          "24"
        ],
        "isCorrect": false
      },
      {
        "id": 10960,
        "content": [
          "6"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2738,
    "content": [
      "Which of the following is a zero for the function f(x) = x³ - 3x² + 3x - 1?"
    ],
    "explanation": [
      "The given function is a perfect cube. It matches the binomial expansion of (a-b)³ = a³ - 3a²b + 3ab² - b³.",
      "With a=x and b=1, we have f(x) = (x-1)³.",
      "A zero of the function is a value of x for which f(x)=0.\n$$\n(x-1)^3 = 0 \\implies x-1 = 0 \\implies x = 1\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10961,
        "content": [
          "0"
        ],
        "isCorrect": false
      },
      {
        "id": 10962,
        "content": [
          "1"
        ],
        "isCorrect": true
      },
      {
        "id": 10963,
        "content": [
          "-2"
        ],
        "isCorrect": false
      },
      {
        "id": 10964,
        "content": [
          "-1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Relation and Function"
  },
  {
    "id": 2739,
    "content": [
      "If $$f(x) = \\frac{\\ln 2}{x^2}$$, then f'(x) is equal to"
    ],
    "explanation": [
      "Rewrite the function as $$f(x) = (\\ln 2) x^{-2}$$. Note that ln(2) is a constant.",
      "Use the power rule for differentiation:\n$$\n\\frac{d}{dx}(cx^n) = cnx^{n-1}\n$$\n$$\nf'(x) = (\\ln 2) \\cdot (-2)x^{-2-1} = -2(\\ln 2)x^{-3}\n$$\n$$\nf'(x) = \\frac{-2\\ln 2}{x^3}\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10965,
        "content": [
          "$$\n\\frac{1}{2x^2}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10966,
        "content": [
          "$$\n\\frac{-2\\ln 2}{x^3}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 10967,
        "content": [
          "$$\n\\frac{-2}{x^4}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10968,
        "content": [
          "$$\n\\frac{1+2\\ln x}{x^3}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2740,
    "content": [
      "Let x² + y² + kx = 1 be equation of a circle for some k∈R. What is the radius of the circle if its center is (2,0)?"
    ],
    "explanation": [
      "First, find the value of k. The standard form of a circle is (x-h)² + (y-k)² = r².",
      "Complete the square for the given equation:\n$$\n(x^2 + kx) + y^2 = 1\n$$\n$$\n(x^2 + kx + (\\frac{k}{2})^2) + y^2 = 1 + (\\frac{k}{2})^2\n$$\n$$\n(x + \\frac{k}{2})^2 + y^2 = 1 + \\frac{k^2}{4}\n$$",
      "The center is at (-k/2, 0). We are given the center is (2, 0). So,\n$$\n-k/2 = 2 \\implies k = -4\n$$",
      "Now find the radius. The right side of the equation is r².\n$$\nr^2 = 1 + \\frac{k^2}{4} = 1 + \\frac{(-4)^2}{4}\n$$\n$$\n= 1 + \\frac{16}{4} = 1 + 4 = 5\n$$",
      "The radius is r = √5."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10969,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 10970,
        "content": [
          "√5"
        ],
        "isCorrect": true
      },
      {
        "id": 10971,
        "content": [
          "√2"
        ],
        "isCorrect": false
      },
      {
        "id": 10972,
        "content": [
          "2"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 2741,
    "content": [
      "The equation of a parabola is given by y² + 6y + 8x + 25 = 0. Which one of the following is NOT true about this parabola?"
    ],
    "explanation": [
      "We need to put the equation in standard form by completing the square for y.\n$$\ny^2 + 6y = -8x - 25\n$$\n$$\ny^2 + 6y + 9 = -8x - 25 + 9\n$$\n$$\n(y + 3)^2 = -8x - 16\n$$\n$$\n(y + 3)^2 = -8(x + 2)\n$$",
      "This is a horizontal parabola of the form (y-k)² = 4p(x-h).",
      "Vertex (h,k) is (-2, -3). So (A) is true.",
      "Since 4p = -8, p = -2. Because p is negative, the parabola opens to the left. Therefore, statement (C) is NOT true.",
      "The focus is at (h+p, k) = (-2-2, -3) = (-4, -3). So (D) is true.",
      "The directrix is x = h-p = -2 - (-2) = 0, which is the y-axis. So (B) is true."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_GEOMETRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10973,
        "content": [
          "Its vertex is (-2, -3)"
        ],
        "isCorrect": false
      },
      {
        "id": 10974,
        "content": [
          "Its directrix is the y-axis"
        ],
        "isCorrect": false
      },
      {
        "id": 10975,
        "content": [
          "It opens to the right"
        ],
        "isCorrect": true
      },
      {
        "id": 10976,
        "content": [
          "Its focus lies at (-4, -3)"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Circles"
  },
  {
    "id": 2742,
    "content": [
      "What is the slope of the line tangent to the graph of f(x) = x² + tanx at (π, f(π))?"
    ],
    "explanation": [
      "The slope is given by the derivative f'(x) evaluated at x=π.",
      "First, find the derivative:\n$$\nf'(x) = \\frac{d}{dx}(x^2 + \\tan x) = 2x + \\sec^2 x\n$$",
      "Now evaluate at x = π:\n$$\nf'(\\pi) = 2(\\pi) + \\sec^2(\\pi)\n$$\n$$\n= 2\\pi + (\\frac{1}{\\cos(\\pi)})^2\n$$\n$$\n= 2\\pi + (\\frac{1}{-1})^2 = 2\\pi + 1\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_CALCULUS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10977,
        "content": [
          "2π"
        ],
        "isCorrect": false
      },
      {
        "id": 10978,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 10979,
        "content": [
          "2π+1"
        ],
        "isCorrect": true
      },
      {
        "id": 10980,
        "content": [
          "2π-1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Introduction to Calculus"
  },
  {
    "id": 2743,
    "content": [
      "Suppose the measurement of height (in meter) of twelve students is: 1.72, 1.65, 1.70, 1.56, 1.72, 1.70, 1.65, 1.70, 1.65, 1.65, 1.70, 1.72. Which one is true about the mode of the data?"
    ],
    "explanation": [
      "Let's count the frequencies:\n- 1.56 → 1\n- 1.65 → 4\n- 1.70 → 4\n- 1.72 → 3",
      "Two values (1.65 and 1.70) appear most frequently.",
      "So the data is bimodal with mode 1.65 and 1.70."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_STATISTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10981,
        "content": [
          "The data is unimodal with mode 1.65."
        ],
        "isCorrect": false
      },
      {
        "id": 10982,
        "content": [
          "The data is unimodal with mode 1.70."
        ],
        "isCorrect": false
      },
      {
        "id": 10983,
        "content": [
          "The data is bimodal with mode 1.65 and 1.70."
        ],
        "isCorrect": true
      },
      {
        "id": 10984,
        "content": [
          "The data is multimodal."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 9,
    "unitName": "Statistics and Probability"
  },
  {
    "id": 2744,
    "content": [
      "Which of the following is correct about f(x) = cotx?"
    ],
    "explanation": [
      "Let's analyze the properties of f(x) = cot(x).",
      "A. The range of cot(x) is all real numbers, (-∞, ∞). So (A) is false.",
      "B. The function cot(x) = cos(x)/sin(x) is undefined when sin(x) = 0. This occurs at integer multiples of π (0, π, 2π, ...). So the domain is all real numbers except x = nπ, where n is an integer. This statement is correct.",
      "C. This is the domain of tan(x). So (C) is false.",
      "D. The period of cot(x) is π. So (D) is false."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_TRIGOMETRIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10985,
        "content": [
          "Its range is (-∞,-1]U[1,∞)"
        ],
        "isCorrect": false
      },
      {
        "id": 10986,
        "content": [
          "Its domain is {x ∈ R: x ≠ nπ, n ∈ Z}"
        ],
        "isCorrect": true
      },
      {
        "id": 10987,
        "content": [
          "Its domain is {x ∈ R: x ≠ π/2 + nπ, n ∈ Z}"
        ],
        "isCorrect": false
      },
      {
        "id": 10988,
        "content": [
          "Its period is 2π"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Trigonometric Function"
  },
  {
    "id": 2745,
    "content": [
      "Let f (x) = 3 - 2x. What is the inverse of f?"
    ],
    "explanation": [
      "To find the inverse function, let y = f(x), then swap x and y, and solve for y.",
      "Start with y = 3 - 2x.",
      "Swap variables: x = 3 - 2y.",
      "Solve for y:\n$$\n2y = 3 - x\n$$\n$$\ny = \\frac{3 - x}{2}\n$$\n$$\nf^{-1}(x) = \\frac{3-x}{2}\n$$"
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_FUNCTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10989,
        "content": [
          "f⁻¹(x) = 2x - 3"
        ],
        "isCorrect": false
      },
      {
        "id": 10990,
        "content": [
          "f⁻¹(x) = 3 + 2x"
        ],
        "isCorrect": false
      },
      {
        "id": 10991,
        "content": [
          "$$f^{-1}(x) = \\frac{x-3}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10992,
        "content": [
          "$$f^{-1}(x) = \\frac{3-x}{2}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Rational Expressions and Rational Function"
  },
  {
    "id": 2746,
    "content": [
      "Let {aₙ} be a sequence of real numbers. Then which of the following is true about the sequence?"
    ],
    "explanation": [
      "This question tests the definitions related to sequences.",
      "A. M is an upper bound if aₙ ≤ M for all n. The inequality is reversed. False.",
      "B. m is a lower bound if m ≤ aₙ for all n. The inequality is reversed. False.",
      "C. This is the definition of a bounded sequence. It must be bounded above and below. True.",
      "D. This describes a sequence whose terms are bounded away from zero, not a bounded sequence (e.g., the sequence aₙ=n satisfies k ≤ |aₙ| for k=1 but is unbounded). False."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_SEQUENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10993,
        "content": [
          "M is an upper bound of {aₙ} if M ≤ aₙ for all aₙ."
        ],
        "isCorrect": false
      },
      {
        "id": 10994,
        "content": [
          "m a lower bound of {aₙ} if aₙ ≤ m for all aₙ."
        ],
        "isCorrect": false
      },
      {
        "id": 10995,
        "content": [
          "The sequence {aₙ} is bounded if it has both an upper bound and a lower bound."
        ],
        "isCorrect": true
      },
      {
        "id": 10996,
        "content": [
          "The sequence {aₙ} is bounded if there exists k > 0 such that k ≤ |aₙ| for all aₙ."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Sequence and Series"
  },
  {
    "id": 2747,
    "content": [
      "Which of the following is the lower bound for the sequence\n$$\n{\\{\\frac{n}{n-1}\\}}_{n=2}^{\\infty} \\ \\text{?}\n$$"
    ],
    "explanation": [
      "Let\n$$\na_n = \\frac{n}{n-1} = \\frac{n-1+1}{n-1} = 1 + \\frac{1}{n-1}\n$$",
      "The first few terms are: a₂ = 2/1 = 2; a₃ = 3/2 = 1.5; a₄ = 4/3 ≈ 1.33.",
      "As n increases, 1/(n-1) decreases and approaches 0. So the sequence is decreasing and approaches 1 from above.",
      "The sequence is always greater than 1. The greatest lower bound (infimum) is 1. Any number less than or equal to 1 is a lower bound. Of the choices given, only 1 fits this description."
    ],
    "year": "YEAR_2012",
    "subject": "MATHS_NATURAL",
    "chapter": "MATH_PROBABILITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10997,
        "content": [
          "9/5"
        ],
        "isCorrect": false
      },
      {
        "id": 10998,
        "content": [
          "1"
        ],
        "isCorrect": true
      },
      {
        "id": 10999,
        "content": [
          "7/4"
        ],
        "isCorrect": false
      },
      {
        "id": 11000,
        "content": [
          "5/3"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 8,
    "unitName": "Probability"
  }
];
export default questions;
