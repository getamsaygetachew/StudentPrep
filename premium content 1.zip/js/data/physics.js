// StudentPrep Premium Content — complete question bank.
const questions = [
  {
    "id": 301,
    "content": [
      "Which one of the following units is NOT a possible unit of electric field strength?"
    ],
    "explanation": [
      "**Joule/Coulomb** is a unit of electric potential (voltage), not electric field strength. Hence, it is the incorrect option."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1201,
        "content": [
          "Newton/Coulomb"
        ],
        "isCorrect": false
      },
      {
        "id": 1202,
        "content": [
          "Joule/Coulomb"
        ],
        "isCorrect": true
      },
      {
        "id": 1203,
        "content": [
          "Volt/meter"
        ],
        "isCorrect": false
      },
      {
        "id": 1204,
        "content": [
          "Joule/(Coulomb $$\\times$$ meter)"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 302,
    "content": [
      "Which one of the following statements does NOT describe magnetic nature of a material?"
    ],
    "explanation": [
      "Heating or hammering a magnet generally causes it to **lose its magnetism** because the process disrupts the alignment of the magnetic dipoles."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1205,
        "content": [
          "There is no a single magnetic North or magnetic South Pole."
        ],
        "isCorrect": false
      },
      {
        "id": 1206,
        "content": [
          "Magnetic dipoles of a material aligned parallel when the magnetic material is placed in external magnetic field."
        ],
        "isCorrect": false
      },
      {
        "id": 1207,
        "content": [
          "Magnetic molecules in a magnet will align when they are heated or hammered."
        ],
        "isCorrect": true
      },
      {
        "id": 1208,
        "content": [
          "Magnetic molecules (dipoles) are oriented randomly when a material lose its magnetism."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Magnetism"
  },
  {
    "id": 303,
    "content": [
      "Which one of the following statements is correct about conduction in semiconductors?"
    ],
    "explanation": [
      "N-type semiconductors are created by doping intrinsic semiconductors with donor atoms, which belong to Group V of the periodic table and have five valence electrons.\n\nThese donor atoms contribute an extra electron to the crystal lattice, increasing the number of free electrons available for conduction.\n\nThese abundant electrons become the majority charge carriers in N-type semiconductors, hence the name \"N-type\" for negative charge carriers."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1209,
        "content": [
          "N-type semiconductor is made from half-filled shell atoms doped with accepter atoms."
        ],
        "isCorrect": false
      },
      {
        "id": 1210,
        "content": [
          "P-type semiconductors have holes as minority charge carriers in the crystal lattice of the material."
        ],
        "isCorrect": false
      },
      {
        "id": 1211,
        "content": [
          "The majority charge carriers in N-type semiconductors are electrons due to doping."
        ],
        "isCorrect": true
      },
      {
        "id": 1212,
        "content": [
          "When atoms with half-filled electrons are doped with atoms of five valance electrons, the majority charge carriers are holes."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Magnetism"
  },
  {
    "id": 304,
    "content": [
      "A small source emits sound waves which are spherical. The intensity of the sound wave measured at a distance r = 3.0 m from the source is I = $$5 \\ \\text{W/m}^2$$. At what distance from the source would the intensity be one-fourth as much as it is at r = 3.0 m?"
    ],
    "explanation": [
      "Sound intensity decreases as the square of the distance from the source.\n$$\nI \\propto \\frac{1}{r^2}\n$$\nWe are given the intensity I = $$5 \\ \\text{W/m}^2$$ at r=3.0 and want to find the distance $$r_{new}$$ where the intensity is one-fourth of this value:\n$$\nI_{new} = \\frac{1}{4} I = \\frac{5}{4} \\text{ W/m}^2\n$$\nUsing the inverse square law, we set up the ratio of the intensities:\n$$\n\\frac{I_{new}}{I} = \\left(\\frac{r_{new}}{r}\\right)^2\n$$\nSubstitute $$I_{new} = \\frac{1}{4} I$$ and simplify:\n$$\n\\frac{\\frac{1}{4} I}{I} = \\left(\\frac{3.0}{r_{new}}\\right)^2\n$$\n$$\n\\frac{1}{4} = \\left(\\frac{3.0}{r_{new}}\\right)^2\n$$\nNow, take the square root of both sides:\n$$\n\\frac{1}{2} = \\frac{3.0}{r_{new}}\n$$\nSolve for  $$r_{new}$$:\n$$\nr_{new} = 2 \\times 3.0 = 6.0 \\ m\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_SOUND",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1213,
        "content": [
          "12.0 m"
        ],
        "isCorrect": false
      },
      {
        "id": 1214,
        "content": [
          "9.0 m"
        ],
        "isCorrect": false
      },
      {
        "id": 1215,
        "content": [
          "4.5 m"
        ],
        "isCorrect": false
      },
      {
        "id": 1216,
        "content": [
          "6.0 m"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Mechanical Oscillation and Sound Wave"
  },
  {
    "id": 305,
    "content": [
      "Consider a system of two point masses $$M_1$$ and $$M_2$$, with $$M_1 = 0.5 M_2$$. The two masses are located on the x-y plane as shown in the figure below.",
      "images/physics/year_2015/q5_1.png",
      "Which one of the following alternatives indicates the position of center of mass of the system?"
    ],
    "explanation": [
      "To find the center of mass of a system of two point masses, we can use the formula:\n\n$$\nX_{cm} = \\frac{M_1x_1 + M_2x_2}{M_1 + M_2}\n$$\n$$\nY_{cm} = \\frac{M_1y_1 + M_2y_2}{M_1 + M_2}\n$$\n\nGiven information:\n\n- $$M_1 = 0.5 M_2$$\n- The positions of the two masses are shown in the figure: $$M_1$$ is at (4, 5) cm and $$M_2$$ is at (6, 3) cm\n\nPlugging in the values:\n$$\nX_{cm} = \\frac{0.5 M_2 \\cdot 4 + M_2 \\cdot 6}{0.5 M_2 + M_2}\n$$\n$$\nX_{cm} = \\frac{16}{3}\n$$\n$$\nY_{cm} = \\frac{0.5 M_2 \\cdot 5 + M_2 \\cdot 3}{0.5 M_2 + M_2}\n$$\n$$\nY_{cm} = \\frac{11}{3}\n$$\n\nThus, the coordinates of the center of mass are: ($$\\frac{16}{3} \\, \\text{cm}, \\frac{11}{3} \\, \\text{cm}$$)"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2015/q5_1.png"
    ],
    "choices": [
      {
        "id": 1217,
        "content": [
          "($$5,4$$) cm"
        ],
        "isCorrect": false
      },
      {
        "id": 1218,
        "content": [
          "($$\\frac{5}{3}, \\frac{7}{3}$$) cm"
        ],
        "isCorrect": false
      },
      {
        "id": 1219,
        "content": [
          "($$\\frac{16}{3}, \\frac{11}{3}$$) cm"
        ],
        "isCorrect": true
      },
      {
        "id": 1220,
        "content": [
          "($$\\frac{11}{3}, \\frac{16}{3}$$) cm"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 306,
    "content": [
      "What is the acceleration due to gravity at an altitude twice the radius of the Earth? ($$g_E$$ is the gravitational acceleration on the surface of the Earth)."
    ],
    "explanation": [
      "The formula for gravitational acceleration at a distance (r) from the center of a planet is given by:\n\n$$\ng_r = \\frac{g_E}{\\left( \\frac{r}{R_E} \\right)^2}\n$$\n\nwhere:\n\n- $$g_E$$ is the gravitational acceleration at the Earth's surface,\n- $$R_E$$ is the radius of the Earth,\n- r is the distance from the center of the Earth.\n\nAt an altitude twice the radius of the Earth, the distance from the center of the Earth is:\n\n$$\nr = 2R_E + R_E = 3R_E\n$$\n\nNow, using the formula for gravitational acceleration:\n$$\ng_r = \\frac{g_E}{(3)^2} = \\frac{g_E}{9}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1221,
        "content": [
          "$$\\frac{g_E}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1222,
        "content": [
          "$$\\frac{g_E}{9}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1223,
        "content": [
          "$$3 \\ g_E$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1224,
        "content": [
          "$$\\frac{g_E}{4}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Uniformly Accelerated Motion"
  },
  {
    "id": 307,
    "content": [
      "Four capacitors are connected in a capacitor network as shown in the figure below.",
      "images/physics/year_2015/q7_1.png",
      "The equivalent capacitance between terminals a and b in μF is"
    ],
    "explanation": [
      "The two capacitors labeled 2 μF and 1 μF are connected in parallel. The total capacitance for capacitors in parallel is:\n$$\nC_{parallel} = C_1 + C_2\n$$\n$$\nC_{parallel} = 2 \\, \\mu F + 1 \\, \\mu F = 3 \\, \\mu F\n$$\nNext, we deal with the series connections. 3/7 μF capacitor is in series with the equivalent capacitance of the parallel capacitors (3 μF). For capacitors in series, the total capacitance is given by:\n$$\n\\frac{1}{C_{series}} = \\frac{1}{C_1} + \\frac{1}{C_2}\n$$\n$$\n\\frac{1}{C_{series}} = \\frac{1}{3/7 \\, \\mu F} + \\frac{1}{3 \\, \\mu F}\n$$\n$$\n\\frac{1}{C_{series}} = \\frac{7}{3 \\, \\mu F} + \\frac{1}{3 \\, \\mu F} = \\frac{8}{3 \\, \\mu F}\n$$\n$$\nC_{series} = \\frac{3}{8} \\, \\mu F\n$$\nNow, this ($$\\frac{3}{8} \\, \\mu F$$) is in series with the ($$\\frac{3}{4} \\, \\mu F$$) capacitor on the right side of the circuit. Using the series formula again:\n$$\n\\frac{1}{C_{eq}} = \\frac{1}{\\frac{3}{8} \\, \\mu F} + \\frac{1}{\\frac{3}{4} \\, \\mu F}\n$$\n$$\n\\frac{1}{C_{eq}} = \\frac{8}{3 \\, \\mu F} + \\frac{4}{3 \\, \\mu F} = \\frac{12}{3 \\, \\mu F} = 4 \\, \\mu F\n$$\nTherefore, the equivalent capacitance between terminals a and b is:\n$$\nC_{eq} = \\frac{1}{4} \\, \\mu F\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2015/q7_1.png"
    ],
    "choices": [
      {
        "id": 1225,
        "content": [
          "3/4"
        ],
        "isCorrect": false
      },
      {
        "id": 1226,
        "content": [
          "12"
        ],
        "isCorrect": false
      },
      {
        "id": 1227,
        "content": [
          "4"
        ],
        "isCorrect": false
      },
      {
        "id": 1228,
        "content": [
          "1/4"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 308,
    "content": [
      "A 64 V battery is connected to a series combination of 3 kΩ bulb and 4 kΩ electric iron. If the total current in the circuit is 8 mA, what is the internal resistance of the battery?"
    ],
    "explanation": [
      "Given:\n- 64 V\n- I = 8 mA = 0.008 A\n- $$R_b$$ = 3 kΩ = 3000 Ω\n- $$R_i$$ = 4 kΩ = 4000 Ω\n\nTotal external resistance:\n\n$$R_{ext}$$ = $$R_b + R_i$$ = 7000 Ω\n\nUsing Ohm's Law, total resistance:\n\n$$R_{total}$$ = $$\\frac{V}{I}$$ = $$\\frac{64}{0.008}$$ = 8000 Ω\n\nInternal resistance of the battery:\n$$R_{int}$$ = $$R_{total}$$ - $$R_{ext}$$ = 1000 Ω = 1 kΩ"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1229,
        "content": [
          "1 kΩ"
        ],
        "isCorrect": true
      },
      {
        "id": 1230,
        "content": [
          "7 kΩ"
        ],
        "isCorrect": false
      },
      {
        "id": 1231,
        "content": [
          "8 kΩ"
        ],
        "isCorrect": false
      },
      {
        "id": 1232,
        "content": [
          "15 kΩ"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 309,
    "content": [
      "A solenoid with 5000 turns and length 1m carries 15A of current. If no iron core is inserted in the solenoid, what is the magnetic field strength at the center of the solenoid?"
    ],
    "explanation": [
      "The formula for the magnetic field of a solenoid is:\n$$\nB = \\mu_0 \\cdot \\frac{N}{L} \\cdot I\n$$\n\nWhere:\n- $$\\mu_0 = 4\\pi \\times 10^{-7} \\, T \\cdot m / A$$ (permeability of free space)\n- N = 5000\n- L = 1 m\n- I = 15 A\n\n$$\nB = (4\\pi \\times 10^{-7}) \\cdot \\frac{5000}{1} \\cdot 15\n$$\n$$\nB = 4\\pi \\times 10^{-7} \\cdot 75000 = 3\\pi \\times 10^{-2} \\, T\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1233,
        "content": [
          "$$20 \\pi \\times 10^{-2} \\ \\text{T}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1234,
        "content": [
          "$$3 \\pi \\times 10^{-2} \\ \\text{T}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1235,
        "content": [
          "$$6 \\pi \\times 10^{-2} \\ \\text{T}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1236,
        "content": [
          "$$4 \\pi \\times 10^{-2} \\ \\text{T}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 310,
    "content": [
      "Light ray is allowed to enter from air medium ($$n_{air} = 1$$) into water medium (index of refraction $$n_w= \\frac{4}{3}$$) at an angle of 30° with the normal to air-water interface (boundary). Which one of the following is correct about the ray-of light?"
    ],
    "explanation": [
      "To analyze the situation, we can use Snell's law, which states:\n$$\nn_1 \\sin(\\theta_1) = n_2 \\sin(\\theta_2)\n$$\nWhere:\n- $$n_1$$ is the refractive index of the first medium (air).\n- $$n_2$$ is the refractive index of the second medium (water).\n- $$\\theta_1$$ is the angle of incidence in the first medium.\n- $$\\theta_2$$ is the angle of refraction in the second medium.\n\nGiven:\n\n- $$n_{air}$$ = 1, $$\\quad n_{water}$$ = $$\\frac{4}{3}$$, $$\\quad \\theta_1$$ = $$30^\\circ$$\n- $$\\sin(\\theta_1)$$ = $$\\sin(30^\\circ)$$ = 0.5\n\n$$\n1 \\cdot \\sin(30^\\circ) = \\frac{4}{3} \\cdot \\sin(\\theta_2)\n$$\n\n$$\n0.5 = \\frac{4}{3} \\sin(\\theta_2)\n$$\n$$\n\\sin(\\theta_2) = \\frac{0.5 \\cdot 3}{4} = \\frac{1.5}{4} = 0.375\n$$\nThis means: $$\\sin(\\theta_2) \\approx 0.38$$\n\nThe speed of light in a medium is given by:\n$$\nv = \\frac{c}{n}\n$$\nWhere:\n\n- c is the speed of light in vacuum (approximately $$3 \\times 10^8 \\ m/s$$).\n- n is the refractive index of the medium.\n\nIn air: $$v_{air} = c$$\n\nIn water: $$v_{water}$$ = $$\\frac{c}{\\frac{4}{3}}$$ = $$\\frac{3c}{4}$$\n\nTo find the speed of light in water as a fraction of its speed in air:\n$$\n\\frac{v_{water}}{v_{air}} = \\frac{\\frac{3c}{4}}{c} = \\frac{3}{4} = 0.75\n$$\nConclusion:\n\n- The sine of the angle of refraction of the light ray in water is equal to 0.5. (False)\n- The sine of the angle of refraction of the light ray in water is equal to 0.38. (True)\n- The speed of the light ray in water is 1.33 times that of its speed in air. (False)\n- The speed of the light ray in water is 0.9 times that of its speed in air. (False)"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_OPTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1237,
        "content": [
          "The sine of the angle of refraction of the light ray in water is equal to 0.5."
        ],
        "isCorrect": false
      },
      {
        "id": 1238,
        "content": [
          "The sine of the angle of refraction of the light ray in water is equal to 0.38."
        ],
        "isCorrect": true
      },
      {
        "id": 1239,
        "content": [
          "The speed of the light ray in water is 1.33 times that of its speed in air."
        ],
        "isCorrect": false
      },
      {
        "id": 1240,
        "content": [
          "The speed of the light ray in water is 0.9 times that of its speed in air."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Electromagnetic Waves and Geometrical Optics"
  },
  {
    "id": 311,
    "content": [
      "A fluid travelling over an objects surface exerts less pressure than if the fluid was static. This is a statement of"
    ],
    "explanation": [
      "Bernoulli's principle states that as the speed of a fluid increases, the pressure within the fluid decreases. This principle is often used to explain how airplanes fly: the shape of an airplane wing causes air to move faster over the top of the wing than the bottom, which creates a difference in pressure that lifts the plane."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_PRESSURE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1241,
        "content": [
          "Bernoulli's principle."
        ],
        "isCorrect": true
      },
      {
        "id": 1242,
        "content": [
          "principle of continuity."
        ],
        "isCorrect": false
      },
      {
        "id": 1243,
        "content": [
          "Pascal's principle."
        ],
        "isCorrect": false
      },
      {
        "id": 1244,
        "content": [
          "Archimedes' principle."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 312,
    "content": [
      "Which one of the following activities of experiment is NOT necessary to determine the specific latent heat of vaporization of water?"
    ],
    "explanation": [
      "To determine the specific latent heat of vaporization of water, the key activities involve measuring the energy input (which is related to mass), the temperature change, and the time for which the energy is supplied. However, measuring volume is not necessary for this determination.\n\nLatent heat of vaporization ($$L_v$$) of a substance, such as water, is given by:\n$$\nL_v = \\frac{Q}{m}\n$$\nWhere:\n- $$L_v$$ = specific latent heat of vaporization (J/kg)\n- $$Q$$ = heat energy supplied (J)\n- $$m$$ = mass of the substance (kg)\n\nHeat energy (Q) can be calculated using the equation:\n\n$$\nQ = m \\cdot c \\cdot \\Delta T\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1245,
        "content": [
          "Measuring temperature."
        ],
        "isCorrect": false
      },
      {
        "id": 1246,
        "content": [
          "Measuring volume"
        ],
        "isCorrect": true
      },
      {
        "id": 1247,
        "content": [
          "Measuring time"
        ],
        "isCorrect": false
      },
      {
        "id": 1248,
        "content": [
          "Measuring mass"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 313,
    "content": [
      "Which one of the following statements is correct about critical and boiling points of a substance?"
    ],
    "explanation": [
      "The boiling point of a substance is the temperature at which the vapor pressure of a liquid equals the pressure surrounding the liquid, and the liquid changes into a vapor.\n\nThe boiling point of water decreases as altitude increases. This is because atmospheric pressure decreases with altitude. As there is less pressure pushing down on the water, it's easier for the water molecules to escape into the air and become vapor.\n\nThe critical point of a substance is the point in temperature and pressure on a phase diagram where the liquid and gaseous phases of a substance merge together into a single phase.\nThe critical point is a specific temperature and pressure for a given substance."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1249,
        "content": [
          "The critical point and the boiling point of a substance occur at the same specific temperature and pressure."
        ],
        "isCorrect": false
      },
      {
        "id": 1250,
        "content": [
          "Both critical temperature and boiling point of a substance can be increased or decreased based on the pressure of the surrounding."
        ],
        "isCorrect": false
      },
      {
        "id": 1251,
        "content": [
          "The boiling point of a substance can be different based on the pressure of the surrounding whereas critical point occurs at one specific pressure and temperature."
        ],
        "isCorrect": true
      },
      {
        "id": 1252,
        "content": [
          "The critical temperature of a substance can be increased or decreased based on the pressure of the surrounding whereas boiling point does not vary with the pressure of the surrounding."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 314,
    "content": [
      "A 30 kg rigid object has a moment of inertia $$45 \\ kgm^2$$ about its center of mass. What is the object's moment of inertia when it rotates through an axis 2m away and parallel to the axis through its center of mass?"
    ],
    "explanation": [
      "The moment of inertia of a rigid object rotating about an axis that is parallel to the axis through its center of mass is given by the parallel-axis theorem:\n$$\nI = I_{cm} + Md^2\n$$\n\nWhere:\n\n- I is the moment of inertia about the new axis\n- $$I_{cm}$$ is the moment of inertia about the center of mass\n- M is the mass of the object\n- d is the distance between the two parallel axes\n\nApplying the Theorem\n\n$$\nI = 45 kgm^2 + 30 kg * (2 m)^2 = 165 kgm^2\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1253,
        "content": [
          "$$90 \\ kgm^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1254,
        "content": [
          "$$165 \\ kgm^2$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1255,
        "content": [
          "$$180 \\ kgm^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1256,
        "content": [
          "$$105 \\ kgm^2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 315,
    "content": [
      "Two coplanar forces acts on a uniform beam as shown in the figure below.",
      "images/physics/year_2015/q15_1.png",
      "The moment of force on the beam is"
    ],
    "explanation": [
      "The moment of force (or torque) on a beam can be calculated using the formula:\n\n$$\n\\tau = F \\times d\n$$\n\nIn the diagram:\n\n- Two forces, ($$F_1 = 30 \\ N$$) and ($$F_2 = 30 \\ N$$), are acting in opposite directions,\n- The distance between the forces is 0.80 m.\n\nThe pivot point is in the middle of the beam.\n\nTaking one force, say ($$F_1$$), the perpendicular distance to the pivot is half the total length = 0.40 m.\n\nFor one force:\n\n$$\n\\tau_1 = 30 \\ N \\times 0.40 \\ m = 12.0 \\ Nm\n$$\n\nFor both forces (in opposite directions):\n\n$$\n\\tau_{total} = 12.0 \\ Nm + 12.0 \\ Nm = 24.0 \\ Nm\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2015/q15_1.png"
    ],
    "choices": [
      {
        "id": 1257,
        "content": [
          "48.0 Nm."
        ],
        "isCorrect": false
      },
      {
        "id": 1258,
        "content": [
          "12.0 Nm."
        ],
        "isCorrect": false
      },
      {
        "id": 1259,
        "content": [
          "30.0 Nm."
        ],
        "isCorrect": false
      },
      {
        "id": 1260,
        "content": [
          "24.0 Nm."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 316,
    "content": [
      "Water flows at the rate of $$500.0 \\ \\text{cm}^3/ \\text{s}$$ at small cross-section $$5 \\ \\text{cm}^2$$. The larger cross-section is $$25 \\ \\text{cm}^2$$. What is the ratio of the speed of the water at $$A_1$$ to $$A_2$$.",
      "images/physics/year_2015/q16_1.png"
    ],
    "explanation": [
      "The flow rate (Q) of water is given by:\n\n$$\nQ = A \\times v\n$$\n\nSince the flow rate remains constant, we can apply the continuity equation:\n$$\nA_1 \\times v_1 = A_2 \\times v_2\n$$\n\nWe are asked to find the ratio $$\\frac{v_1}{v_2}$$\n\nRearranging the continuity equation to find the ratio:\n\n$$\n\\frac{v_1}{v_2} = \\frac{A_2}{A_1}\n$$\n\n$$\n\\frac{v_1}{v_2} = \\frac{25 \\, \\text{cm}^2}{5 \\, \\text{cm}^2} = 5\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2015/q16_1.png"
    ],
    "choices": [
      {
        "id": 1261,
        "content": [
          "5"
        ],
        "isCorrect": true
      },
      {
        "id": 1262,
        "content": [
          "100"
        ],
        "isCorrect": false
      },
      {
        "id": 1263,
        "content": [
          "0.2"
        ],
        "isCorrect": false
      },
      {
        "id": 1264,
        "content": [
          "20"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 317,
    "content": [
      "An ideal monoatomic gas expands adiabatically from an initial volume of 2 liters at a temperature of 300 K to 16 liters of volume. What is the final temperature of the gas? (Use the ratio of specific heat capacity at constant pressure to that at constant volume to be 5/3.)"
    ],
    "explanation": [
      "For an adiabatic process, the following equation holds:\n\n$$\nT_1V_1^{\\gamma-1}=T_2V_2^{\\gamma-1}\n$$\n\n$$\n300 K  \\times (2 \\ L)^{(5/3)-1}=T_2 \\times (16 \\ L)^{(5/3)-1}\n$$\n\n$$\nT_2=75K\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1265,
        "content": [
          "37.5 k"
        ],
        "isCorrect": false
      },
      {
        "id": 1266,
        "content": [
          "75 K"
        ],
        "isCorrect": true
      },
      {
        "id": 1267,
        "content": [
          "2400 k"
        ],
        "isCorrect": false
      },
      {
        "id": 1268,
        "content": [
          "1200 K"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Heat Conduction and Calorimetry"
  },
  {
    "id": 318,
    "content": [
      "Consider a particle performing a circular motion around a circle of radius r, with an angular velocity ω and the particle's projection on the horizontal diameter of the circle (between points Q and R) as shown in the figure below?",
      "images/physics/year_2015/q18_1.png",
      "Which one of the following statements is correct about the motion of the particle and its projection on $$\\overline{QR}$$"
    ],
    "explanation": [
      "The projection of a particle in uniform circular motion exhibits simple harmonic motion because it oscillates around an equilibrium position (the midpoint of $$\\overline{QR}$$) with maximum displacement at points Q and R. The motion is sinusoidal in nature, where the displacement of the projection from the center varies with time as $$x(t) = r \\cos(\\omega t)$$ demonstrating the characteristics of simple harmonic motion."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2015/q18_1.png"
    ],
    "choices": [
      {
        "id": 1269,
        "content": [
          "The projection of the particle on $$\\overline{QR}$$ swings between points Q and R with constant speed."
        ],
        "isCorrect": false
      },
      {
        "id": 1270,
        "content": [
          "The circular motion of the particle can be taken as a simple harmonic motion."
        ],
        "isCorrect": false
      },
      {
        "id": 1271,
        "content": [
          "The projection of the particle on $$\\overline{QR}$$ demonstrates simple harmonic motion."
        ],
        "isCorrect": true
      },
      {
        "id": 1272,
        "content": [
          "The projection of the particle on $$\\overline{QR}$$ demonstrates motion with constant acceleration."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 319,
    "content": [
      "Air molecules vibrate in a pipe of length L closed at one end but open at the other. If the speed of sound through the pipe is V, Which one of the following statements is correct about the resonance effects of vibration of air molecules in the pipe?"
    ],
    "explanation": [
      "When air is enclosed in a pipe that is open at one end and closed at the other, only odd harmonics are present.\n- The fundamental frequency, or first harmonic, corresponds to a wavelength that is four times the length of the pipe (λ = 4L).\n- The relationship between the speed of sound (V), frequency (f) and wavelength (λ) is given by V = fλ.\n- Substituting λ = 4L into the equation, we obtain the fundamental resonance frequency: f = $$\\frac{V}{4L}$$."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_SOUND",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1273,
        "content": [
          "The fundamental resonance frequency is $$\\frac{V}{4L}$$."
        ],
        "isCorrect": true
      },
      {
        "id": 1274,
        "content": [
          "The fundamental wave length of resonance is equal to 2L."
        ],
        "isCorrect": false
      },
      {
        "id": 1275,
        "content": [
          "The resonance frequency of the first harmonics is $$\\frac{V}{L}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1276,
        "content": [
          "The wavelength of the third harmonic is equal to L."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Mechanical Oscillation and Sound Wave"
  },
  {
    "id": 320,
    "content": [
      "A monochromatic light of wave length λ passes through double slits separated by a distance d. If the path difference between the lights is p and n being an integer (0,1, 2, 3,....). Which one of the following would be observed on screen behind the slits?"
    ],
    "explanation": [
      "In double-slit interference, constructive interference occurs when the path difference between the two waves is an integer multiple of the wavelength, p=nλ, where n is an integer (0, 1, 2, 3, ...)."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_SOUND",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1277,
        "content": [
          "constructive interference if p = (n + 1/2) λ"
        ],
        "isCorrect": false
      },
      {
        "id": 1278,
        "content": [
          "constructive interference if p = nλ"
        ],
        "isCorrect": true
      },
      {
        "id": 1279,
        "content": [
          "destructive interference if p = 2 nλ"
        ],
        "isCorrect": false
      },
      {
        "id": 1280,
        "content": [
          "destructive interference if p = 0"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Mechanical Oscillation and Sound Wave"
  },
  {
    "id": 321,
    "content": [
      "Suppose you are standing on a horizontal floor, in a room, with one of your feet and leaning the wall of the room with the other foot. The number of action reaction pair of forces you experience is"
    ],
    "explanation": [
      "The action-reaction pairs of forces you experience:\n\n- Your foot pushing against the floor\n- Your foot leaning against the wall\n\nTherefore, there are two action-reaction pairs of forces acting on you."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1281,
        "content": [
          "1."
        ],
        "isCorrect": false
      },
      {
        "id": 1282,
        "content": [
          "3."
        ],
        "isCorrect": false
      },
      {
        "id": 1283,
        "content": [
          "2."
        ],
        "isCorrect": true
      },
      {
        "id": 1284,
        "content": [
          "4."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 322,
    "content": [
      "The amount of heat energy required to change a substance from a liquid to a gaseous state is known as"
    ],
    "explanation": [
      "**Latent heat of vaporization** is the amount of heat energy required to change a substance from a liquid to a gaseous state without changing its temperature."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1285,
        "content": [
          "specific heat capacity."
        ],
        "isCorrect": false
      },
      {
        "id": 1286,
        "content": [
          "latent heat of fusion."
        ],
        "isCorrect": false
      },
      {
        "id": 1287,
        "content": [
          "quantity of heat."
        ],
        "isCorrect": false
      },
      {
        "id": 1288,
        "content": [
          "latent heat of vaporization."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 323,
    "content": [
      "Which one of the following is correct about mechanical waves?"
    ],
    "explanation": [
      "**Wavelength** is the distance between two identical points on adjacent waves, such as from crest to crest or trough to  trough. It essentially measures the length of one complete wave cycle."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_SOUND",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1289,
        "content": [
          "The maximum height in a transverse wave is known as the trough of the wave."
        ],
        "isCorrect": false
      },
      {
        "id": 1290,
        "content": [
          "The time taken for one complete wave to pass a given point is called the frequency of the wave."
        ],
        "isCorrect": false
      },
      {
        "id": 1291,
        "content": [
          "The distance between two identical points on adjacent waves is known as the wavelength of the wave."
        ],
        "isCorrect": true
      },
      {
        "id": 1292,
        "content": [
          "The number of complete waves that passes a given point per time is called the period of the wave."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Mechanical Oscillation and Sound Wave"
  },
  {
    "id": 324,
    "content": [
      "A boy in a journey covers his route by travelling 3.0 km east and 4.0 km north. What is the magnitude of his resultant displacement?"
    ],
    "explanation": [
      "We can use the Pythagorean theorem. The boy's journey forms a right-angled triangle with the legs being 3.0 km and 4.0 km.\n$$\n\\sqrt{(3.0 \\ km)^2 + (4.0 \\ km)^2} = 5.0 km\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1293,
        "content": [
          "5.0 km"
        ],
        "isCorrect": true
      },
      {
        "id": 1294,
        "content": [
          "1.0 km"
        ],
        "isCorrect": false
      },
      {
        "id": 1295,
        "content": [
          "7.0 km"
        ],
        "isCorrect": false
      },
      {
        "id": 1296,
        "content": [
          "2.7 km"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 325,
    "content": [
      "The graph given below shows the velocity of a man travelling on a motorcycle as a function of time.",
      "images/physics/year_2015/q25_1.png",
      "Which one of the following statements is correct about the velocity-time graph?"
    ],
    "explanation": [
      "- **Displacement from t = 0 to t = 6 s**: This is the area under the graph in this interval, which is a rectangle. The area (displacement) is $$\\text{velocity} \\times \\text{time} = 120 \\text{m}$$.\n- **Displacement from t = 6 s to t = 14 s**: This is the sum of the areas of regions II and III. Both regions are above the time axis, so their areas add up to give the total displacement.\n- **Acceleration from t = 6 s to t = 10 s**: This is the gradient (slope) of the line in this interval. Since the velocity increases, the gradient is positive.\n- **Acceleration in the first 6 s**: The velocity is constant, so the gradient (acceleration) is zero.\n\nSo the correct statement is: **The displacement during the time intervals t = 0 to t = 6 s is equal to the area under the velocity-time graph in the given interval.**"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2015/q25_1.png"
    ],
    "choices": [
      {
        "id": 1297,
        "content": [
          "The displacement during the time interval from t = 6 s to t = 14 s is equal to the area of region II minus the area of region III."
        ],
        "isCorrect": false
      },
      {
        "id": 1298,
        "content": [
          "The displacement during the time intervals t = 0 to t = 6 s is equal to the area under the velocity-time graph in the given interval."
        ],
        "isCorrect": true
      },
      {
        "id": 1299,
        "content": [
          "The acceleration during the time interval from t = 6 s to t = 10 s is equal to the gradient of the curve in the given interval and it is negative."
        ],
        "isCorrect": false
      },
      {
        "id": 1300,
        "content": [
          "The acceleration in the first 6 s is equal to the gradient of the curve in the given interval and it is positive."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 326,
    "content": [
      "A car of mass $$1.50 \\times 10^3 kg$$ collides with a wall and rebounds. The initial and final velocities of the car are $$v_i = -15.0 m/s$$ and $$v_f = 2.60 m/s$$, respectively. If the collision lasts for 0.15 s, what is the magnitude of the average force exerted on the car?"
    ],
    "explanation": [
      "First, calculate the change in momentum:\n\n$$\n\\Delta p = m(v_f - v_1)\n$$\n\nGiven:\n\n- m = $$1.50 \\times 10^3 \\ \\text{kg}$$\n- $$v_1 = -15.0 \\ \\text{m/s}$$\n- $$v_f = 2.60 \\ \\text{m/s}$$\n\n$$\n\\Delta p = 1.50 \\times 10^3 \\ \\text{kg} \\times (2.60 \\ \\text{m/s} - (-15.0 \\ \\text{m/s}))\n$$\n\n$$\n\\Delta p = 2.64 \\times 10^4 \\, \\text{kg} \\cdot \\text{m/s}\n$$\n\nNow, use the impulse-momentum theorem to find the average force:\n\n$$\nF_{\\text{avg}} = \\frac{\\Delta p}{\\Delta t}\n$$\n\n$$\nF_{\\text{avg}} = \\frac{2.64 \\times 10^4 \\, \\text{kg} \\cdot \\text{m/s}}{0.15 \\, \\text{s}}\n$$\n\n$$\nF_{\\text{avg}} = 1.76 \\times 10^5 \\, \\text{N}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1301,
        "content": [
          "$$2.60 \\times 10^4 \\ N$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1302,
        "content": [
          "$$3.96 \\times 10^3 \\ N$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1303,
        "content": [
          "$$2.64 \\times 10^4 \\ N$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1304,
        "content": [
          "$$1.76 \\times 10^5 \\ N$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 327,
    "content": [
      "Starting from rest, a block of mass 5.0 kg slides 2.5 m down a rough 37° incline. The coefficient of kinetic friction between the block and the incline is $$\\mu_{k} = 0.44$$. What is the work done by the friction force on block?"
    ],
    "explanation": [
      "The normal force is equal to the component of the block's weight perpendicular to the incline:\n\n$$\nF_N = mg\\cos(\\theta) = (5.0 kg)(9.8 m/s^2)\\cos(37°) = 39.1 N\n$$\n\nThe friction force ($$F_k$$) acting on the block using the coefficient of kinetic friction:\n\n$$\nF_k = \\mu_{k} \\cdot F_N = (0.44)(39.1 N) = 17.2 N\n$$\n\nCalculate the work done by the friction force. Friction acts opposite to the direction of motion, which means the angle between the friction force and the displacement is 180°:\n\n$$\nW_f = F_k d \\cos(180°) = -44.00 J\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1305,
        "content": [
          "-75.00 J"
        ],
        "isCorrect": false
      },
      {
        "id": 1306,
        "content": [
          "-18.92 J"
        ],
        "isCorrect": false
      },
      {
        "id": 1307,
        "content": [
          "-44.00 J"
        ],
        "isCorrect": true
      },
      {
        "id": 1308,
        "content": [
          "-59.00 J"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 328,
    "content": [
      "An inclined plane is 20 m long and is inclined at an angle of 15° to the horizontal. If the effort required to push a block of weight 3,000 N up the slope is 900 N, what is the efficiency of the inclined plane?"
    ],
    "explanation": [
      "$$\nh = 20 \\sin(15^\\circ)\n$$\n\n$$\nh = 20 \\times 0.2588 \\approx 5.176 \\, \\text{m}\n$$\n\n$$\n\\text{Output Work} = 3000 \\, \\text{N} \\times 5.176 \\, \\text{m} \\approx 15528 \\, \\text{J}\n$$\n\n$$\n\\text{Input Work} = 900 \\, \\text{N} \\times 20 \\, \\text{m} = 18000 \\, \\text{J}\n$$\n\n$$\n\\text{Efficiency} (\\eta) = \\frac{15528}{18000} \\times 100\\% \\approx 86.7\\%\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1309,
        "content": [
          "100%"
        ],
        "isCorrect": false
      },
      {
        "id": 1310,
        "content": [
          "86.7 %"
        ],
        "isCorrect": true
      },
      {
        "id": 1311,
        "content": [
          "25.9%"
        ],
        "isCorrect": false
      },
      {
        "id": 1312,
        "content": [
          "30.0%"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 329,
    "content": [
      "A wooden block of volume $$5.00 \\times 10^{-4} \\ m^3$$ floats partially submerged in water, and a small steel object of mass m is placed on top of the block. When m = 0.25 kg, the system is in equilibrium and the top of the wooden block is at the level of the water. What is the density of the wood?"
    ],
    "explanation": [
      "When the system is in equilibrium, the buoyant force acting on the wooden block is equal to the weight of the wooden block plus the weight of the steel object.\n\n$$\n\\rho_{water} \\cdot V_{block} \\cdot g = \\rho_{wood} \\cdot V_{block} \\cdot g + m_{steel} \\cdot g\n$$\n\nWe are given that $$V_{block}$$ = $$5.00 \\times 10^{-4} \\ m^3$$ and $$m_{steel}$$ =$$0.25 \\ kg$$.\n\nAdditionally, the density of water is $$\\rho_{water}$$ = $$1000 \\ kg \\cdot m^{-3}$$.\n\nSolving for $$\\rho_{wood}$$, we get:\n\n$$\n\\rho_{wood} = \\frac{0.25 \\ kg}{5.00 \\times 10^{-4} \\ m^3}= 500 \\ kg \\cdot m^{-3}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_DENSITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1313,
        "content": [
          "$$1000 \\ kg \\cdot m^{-3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1314,
        "content": [
          "$$1500 \\ kg \\cdot m^{-3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1315,
        "content": [
          "$$500 \\ kg \\cdot m^{-3}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1316,
        "content": [
          "$$800 \\ kg \\cdot m^{-3}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 330,
    "content": [
      "A bimetallic strip made up of iron and brass bonded together is used in a thermostat. The coefficient of linear expansions for iron and brass are $$1.1 \\times 10^{-5}/K$$ and $$1.9 \\times 10^{-5}/K$$, respectively. Which of one the following phenomena occurs when the temperature changes?"
    ],
    "explanation": [
      "The coefficient of linear expansion for brass ($$1.9 \\times 10^{-5}/K$$) is greater than the coefficient of linear expansion for iron ($$1.1 \\times 10^{-5}/K$$). This means that for the same temperature change, brass will expand or contract more than iron."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1317,
        "content": [
          "When the temperature decreases, the brass section of the bimetallic strip contracts slowly than the iron and the strip bends towards the brass section."
        ],
        "isCorrect": false
      },
      {
        "id": 1318,
        "content": [
          "When the temperature increases, the iron section of the bimetallic strip expands faster than the brass and the strip bends towards the brass section."
        ],
        "isCorrect": false
      },
      {
        "id": 1319,
        "content": [
          "When the temperature increases, the brass section of the bimetallic strip expands faster than the iron and the strip bends towards the iron section."
        ],
        "isCorrect": true
      },
      {
        "id": 1320,
        "content": [
          "When the temperature decreases, the iron section of the bimetallic strip contracts faster than the brass and the strip bends towards the iron section."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 331,
    "content": [
      "Which one of the following statements does NOT describe coherent light or interference of coherent light?"
    ],
    "explanation": [
      "Coherent light refers to waves that have a constant phase difference. This constant phase relationship is what allows for sustained interference patterns. Two waves with a variable phase difference will not produce a stable interference pattern. The other options accurately describe coherent light: waves must be of the same type, and coherent waves share the same frequency and wavelength."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_OPTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1321,
        "content": [
          "Two waves which maintain constant phase relationship can produce. sustained interference."
        ],
        "isCorrect": false
      },
      {
        "id": 1322,
        "content": [
          "Sustainable interference pattern can be formed by two waves with variable phase difference."
        ],
        "isCorrect": false
      },
      {
        "id": 1323,
        "content": [
          "In order for two waves to be coherent, they must be the same type of\nwave."
        ],
        "isCorrect": false
      },
      {
        "id": 1324,
        "content": [
          "Coherent light waves have the same frequency and wavelength."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Electromagnetic Waves and Geometrical Optics"
  },
  {
    "id": 332,
    "content": [
      "Kirchhoff's junction rule is a consequence of conservation of"
    ],
    "explanation": [
      "Kirchhoff's junction rule, also known as Kirchhoff's current law, states that the total current entering a junction must equal the total current leaving the junction."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1325,
        "content": [
          "momentum."
        ],
        "isCorrect": false
      },
      {
        "id": 1326,
        "content": [
          "mass."
        ],
        "isCorrect": false
      },
      {
        "id": 1327,
        "content": [
          "charge."
        ],
        "isCorrect": true
      },
      {
        "id": 1328,
        "content": [
          "electrical energy."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 333,
    "content": [
      "Which one of the following statements describes the photoelectric effect interaction of radiation with matter?"
    ],
    "explanation": [
      "In the photoelectric effect, photons must have a frequency above a certain threshold frequency for electrons to be emitted. The energy of the emitted electrons is proportional to the energy of the incident photons, which is given by the equation E=hf, where h is Planck's constant and f is the frequency of the incident radiation."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_PHOTON",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1329,
        "content": [
          "When radiation of certain frequency f, interact with atoms of a material, electrons will be emitted with energies proportional to the radiation energy."
        ],
        "isCorrect": true
      },
      {
        "id": 1330,
        "content": [
          "Any value of energy of photons (radiations) is capable of producing photoelectrons from a metal."
        ],
        "isCorrect": false
      },
      {
        "id": 1331,
        "content": [
          "In photoelectric effect, the photoelectron energy is directly proportional to the wavelength of incident radiation."
        ],
        "isCorrect": false
      },
      {
        "id": 1332,
        "content": [
          "The intensity of radiation incident on a material can affect the energy of photoelectrons emitted from the metal surface."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Basics of Electrons"
  },
  {
    "id": 334,
    "content": [
      "A positive point charge of 2μC is placed on the x-axis at the origin and a positive charge of 6μC and a negative point charge of -4μC are placed, respectively at x=-3cm and x=+3cm on the x-axis. What is the net electric force on the 2μC charge?"
    ],
    "explanation": [
      "To find the net electric force on the 2μC charge, we can use Coulomb's law, which states that the force between two point charges is given by:\n\n$$\nF = k_e \\frac{|q_1 q_2|}{r^2}\n$$\n\nWhere:\n\n- $$k_e$$ is Coulomb's constant, approximately ($$8.99 \\times 10^9$$  $$\\text{N} \\cdot \\text{m}^2 / \\text{C}^2$$)\n- $$q_1$$ and $$q_2$$ are the magnitudes of the charges\n- r is the distance between the charges\n\nForce due to the 6μC charge at x = -3 cm:\n\n$$\nq_1 = 2 \\mu C = 2 \\times 10^{-6} \\ \\text{C}\n$$\n\n$$\nq_2 = 6 \\mu C = 6 \\times 10^{-6} \\ \\text{C}\n$$\n\n$$\nF_1 = 8.99 \\times 10^9 \\frac{(2 \\times 10^{-6})(6 \\times 10{-6})}{(0.03)2} \\approx 119.87 \\ \\text{N}\n$$\n\n- The force is repulsive and directed towards the positive x-axis.\n\nForce due to the -4μC charge at x = +3 cm:\n\n$$\nq_1 = 2 \\mu C = 2 \\times 10^{-6} \\ \\text{C}\n$$\n\n$$\nq_2 = -4 \\mu C = -4 \\times 10^{-6} \\ \\text{C}\n$$\n\n$$\nF_2 = 8.99 \\times 10^9 \\frac{(2 \\times 10^{-6})(4 \\times 10{-6})}{(0.03)2} \\approx 79.91 \\ \\text{N}\n$$\n\nThe force is attractive and directed towards the positive x-axis.\n\nNet force on the 2μC charge (both forces are in the same direction towards the positive x-axis).\n\n$$\nF_{\\text{net}} = F_1 + F_2 \\approx 200 \\ \\text{N}\n$$\n\nSo, the correct answer is: 200 N toward the positive x-axis"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1333,
        "content": [
          "200 N toward the negative x-axis"
        ],
        "isCorrect": false
      },
      {
        "id": 1334,
        "content": [
          "200 N toward the positive x-axis"
        ],
        "isCorrect": true
      },
      {
        "id": 1335,
        "content": [
          "40 N toward the positive x-axis"
        ],
        "isCorrect": false
      },
      {
        "id": 1336,
        "content": [
          "40 N toward the negative x-axis"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 335,
    "content": [
      "Consider a point charge Q in an electrostatic field and a point mass m in a gravitational field. Which one of the following statements is correct about the potential energy of the objects?"
    ],
    "explanation": [
      "The electric force on a charge is given by  F = qE where q is the charge and E is the electric field.\n\nThe force and the electric field are in the same direction for a positive charge and in opposite directions for a negative charge.\n\nThe gravitational force is always attractive and is given by F = mg where m is the mass and g is the acceleration due to gravity."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1337,
        "content": [
          "The electric potential decreases as a positive charge moves opposite to the electric field while the gravitational potential of the mass increases when it moves along the gravitational field."
        ],
        "isCorrect": false
      },
      {
        "id": 1338,
        "content": [
          "The potential energy of the point charge and that of the point mass changes as they move over equipotential surfaces in their respective fields."
        ],
        "isCorrect": false
      },
      {
        "id": 1339,
        "content": [
          "The potential energies at distance r, from the field sources for both Q and m vary inversely with $$r^2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1340,
        "content": [
          "The gravitational force on mass m is in the same direction of gravitational field while electric force on Q in the same or opposite directions of electric field depending the sign of the charge."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 336,
    "content": [
      "Four resistors are connected to a voltage source as shown in the circuit diagram shown below",
      "images/physics/year_2015/q36_1.png",
      "What are the current through the 3 Ω resistor and the voltage drop across the 4 Ω resistor, respectively?"
    ],
    "explanation": [
      "The 3 Ω and 6 Ω resistors are connected in parallel, while the combination of these two resistors is connected in series with the 1 Ω and 4 Ω resistors.\nFor resistors in parallel\n\n$$\\frac{1}{R_{\\text{parallel}}}$$ = $$\\frac{1}{3}$$ + $$\\frac{1}{6}$$\n\n$$R_{\\text{parallel}}$$ = 2  Ω\n\nThe equivalent resistance ($$R_{\\text{parallel}}$$ = 2 Ω) is in series with the 1 Ω and 4 Ω resistors. Therefore, the total resistance is:\n\n$$R_{\\text{total}}$$ = 2 Ω + 1 Ω + 4 Ω = 7 Ω\n\nUsing Ohm's law:\n$$\nI_{\\text{total}} = \\frac{V_{\\text{total}}}{R_{\\text{total}}}\n$$\n\nGiven that the voltage source is 14 V:\n$$\nI_{\\text{total}} = \\frac{14}{7} = 2 \\ A\n$$\n\nSince the 3 Ω and 6 Ω resistors are in parallel, the voltage across them is the same.\n$$\nV_{\\text{parallel}} = I_{\\text{total}} \\times R_{\\text{parallel}} = 2 \\times 2 = 4 \\ V\n$$\n\nUsing Ohm's law:\n$$\nI_{3} = \\frac{V_{\\text{parallel}}}{3} = \\frac{4}{3} \\ A\n$$\n\nThe current through the 4 Ω resistor is the same as the total current because it is in series.\n$$\nV_{4} = I_{\\text{total}} \\times 4 = 8 \\ V\n$$\n\nThe current through the 3 Ω resistor is $$\\frac{4}{3} \\ A$$, and the voltage drop across the 4 Ω resistor is 8 V."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2015/q36_1.png"
    ],
    "choices": [
      {
        "id": 1341,
        "content": [
          "$$\\frac{2}{3} \\ A$$ and $$4 \\ V$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1342,
        "content": [
          "$$2 \\ A$$ and $$8 \\ V$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1343,
        "content": [
          "$$\\frac{4}{3} \\ A$$ and $$8 \\ V$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1344,
        "content": [
          "$$\\frac{3}{4} \\ A$$ and $$8 \\ V$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 337,
    "content": [
      "An electron moving with a speed of $$2.2 \\times 10^7 \\ \\text{m/s}$$ east enters in the region of magnetic field strength of $$5 \\times 10^{-4} \\ \\text{T}$$ directed north. What is the magnetic force experienced by the electron?"
    ],
    "explanation": [
      "$$\nF = qvB \\sin \\theta\n$$\n\nGiven:\n\n- q = $$-1.6 \\times 10^{-19} \\ \\text{C}$$\n- v = $$2.2 \\times 10^7 \\ \\text{m/s}$$\n- B = $$5 \\times 10^{-4} \\ \\text{T}$$\n- $$\\theta = 90^\\circ$$ (since velocity is east and magnetic field is north, they are perpendicular)\n\n$$\nF = (1.6 \\times 10^{-19} \\ \\text{C}) \\times (2.2 \\times 10^7 \\ \\text{m/s}) \\times (5 \\times 10^{-4} \\ \\text{T})\n$$\n\n$$\nF = 1.76 \\times 10^{-15} \\ \\text{N}\n$$\n\nThe direction of the force is perpendicular to both the velocity (east) and the magnetic field (north).\n\nSo, the correct answer is: $$1.76 \\times 10^{-15} \\ \\text{N}$$, perpendicular to north and east directions."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1345,
        "content": [
          "$$1.76 \\times 10^{-15} \\ \\text{N}$$, perpendicular to north and east directions."
        ],
        "isCorrect": true
      },
      {
        "id": 1346,
        "content": [
          "$$8 \\times 10^{-15} \\ \\text{N}$$, perpendicular to north and east directions."
        ],
        "isCorrect": false
      },
      {
        "id": 1347,
        "content": [
          "$$3.64 \\times 10^{-30} \\ \\text{N}$$, towards east direction"
        ],
        "isCorrect": false
      },
      {
        "id": 1348,
        "content": [
          "$$1.76 \\times 10^{-15} \\ \\text{N}$$, towards north direction."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 338,
    "content": [
      "A magnetic field intensity of $$4 \\times 10^{-4} \\ \\text{T}$$ crosses a coil having face area $$100 \\ \\text{cm}^2$$ and $$5 \\times 10^{4}$$ turns perpendicular to the face of the coil. If the magnetic flux in the coil set to zero within 2 ms. What is the magnitude of the induced emf in the coil?"
    ],
    "explanation": [
      "To find the induced emf, we use Faraday's Law of Induction:\n\n$$\n\\varepsilon = -N \\frac{\\Delta \\Phi}{\\Delta t}\n$$\n\nCalculate the initial magnetic flux:\n\n$$\n\\Phi = B \\cdot A\n$$\n\n$$\n\\Phi = 4 \\times 10^{-6} \\ \\text{Wb}\n$$\n\nChange in magnetic flux:\n\n$$\n\\Delta \\Phi = \\Phi - 0 = 4 \\times 10^{-6} \\ \\text{Wb}\n$$\n\nCalculate Induced emf:\n\n$$\n\\varepsilon = -5 \\times 10^4 \\frac{4 \\times 10^{-6} \\ \\text{Wb}}{2 \\times 10^{-3} \\ \\text{s}}\n$$\n\n$$\n\\varepsilon = -100 \\ \\text{V}\n$$\n\nThe magnitude of the induced emf is 100 V"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1349,
        "content": [
          "$$4\\times 10^{-4} \\ \\text{V}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1350,
        "content": [
          "$$100 \\ \\text{V}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1351,
        "content": [
          "$$10 \\ \\text{V}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1352,
        "content": [
          "$$2 \\times 10^{-5} \\ \\text{V}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 339,
    "content": [
      "In a simple a.c circuit, an inductor of 4μH and a capacitor of 9 pF are connected in series to each other and the combination is connected to an a.c source. What is the angular frequency at resonance of the circuit?"
    ],
    "explanation": [
      "The angular frequency at resonance ($$\\omega_0$$) for a series LC circuit is given by the formula:\n$$\n\\omega_0 = \\frac{1}{\\sqrt{LC}}\n$$\nWhere L is the inductance and C is the capacitance.\n\nGiven:\n\n- L = $$4 \\ \\mu H$$ = $$4 \\times 10^{-6} \\ H$$\n- C = $$9 \\ pF$$ = $$9 \\times 10^{-12} \\ F$$\n\nSubstitute these values into the formula:\n$$\n\\omega_0 = \\frac{1}{\\sqrt{(4 \\times 10^{-6})(9 \\times 10^{-12})}}\n$$\n\nSimplifying:\n$$\n\\omega_0 \\approx 1.67 \\times 10^8 \\ \\text{rad/s}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1353,
        "content": [
          "$$3.8 \\times 10^8 \\ \\text{rad/s}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1354,
        "content": [
          "$$2.7 \\times 10^5 \\ \\text{rad/s}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1355,
        "content": [
          "$$3.6  \\times 10^7 \\ \\text{rad/s}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1356,
        "content": [
          "$$1.67 \\times 10^8 \\ \\text{rad/s}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 340,
    "content": [
      "Electrons in a Sodium atom emit radiation when they move from a higher energy level of -0.81eV to a lower energy level of -2.21eV. What is the frequency of radiation emitted in the process?"
    ],
    "explanation": [
      "To find the frequency of the emitted radiation, use the formula:\n\n$$\nE = h \\nu\n$$\n\nWhere\n\n- E is the energy difference\n- h is Planck's constant ($$4.135667696 \\times 10^{-15}$$ $$\\ \\text{eV} \\cdot \\text{s}$$)\n- $$\\nu$$ is the frequency.\n\nCalculate the energy difference:\n\n$$\n\\Delta E = -0.81 \\ \\text{eV} - (-2.21 \\ \\text{eV}) = 1.40 \\ \\text{eV}\n$$\n\nSolve for frequency:\n\n$$\n\\nu = \\frac{1.40 \\ \\text{eV}}{4.135667696 \\times 10^{-15} \\ \\text{eV} \\cdot \\text{s}} \\approx 3.38 \\times 10^{14} \\ \\text{Hz}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_PHOTON",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1357,
        "content": [
          "$$3.38 \\times 10^{14} \\ \\text{Hz}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1358,
        "content": [
          "$$1.40\\times 10^{15} \\ \\text{Hz}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1359,
        "content": [
          "$$8.10\\times 10^{15} \\ \\text{Hz}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1360,
        "content": [
          "$$2.21 \\times 10^{14} \\ \\text{Hz}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Basics of Electrons"
  },
  {
    "id": 341,
    "content": [
      "Which one of the following statements is NOT correct about power of a lens?"
    ],
    "explanation": [
      "The larger the focal length of the lens, the greater is the power of the lens is incorrect because the power P of a lens is inversely proportional to the focal length f and is given by the formula:\n$$\nP = \\frac{1}{f}\n$$\nAs the focal length increases, the power of the lens decreases, not increases."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_OPTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1361,
        "content": [
          "The power of a lens decreases as the focal length of the lens increases."
        ],
        "isCorrect": false
      },
      {
        "id": 1362,
        "content": [
          "The larger the focal length of the lens the greater is the power of the lens."
        ],
        "isCorrect": true
      },
      {
        "id": 1363,
        "content": [
          "The power of a lens is the measure of the strength of the lens."
        ],
        "isCorrect": false
      },
      {
        "id": 1364,
        "content": [
          "Optician gives the name diopters for the unit of power of a lens."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Electromagnetic Waves and Geometrical Optics"
  },
  {
    "id": 342,
    "content": [
      "Which one of the following groups of physical quantities contains only vectors?"
    ],
    "explanation": [
      "**Displacement**, **Velocity**, **Magnetic field**, and **Momentum** are all vector quantities because they have both magnitude and direction."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1365,
        "content": [
          "Work, Electric field, Displacement and Force"
        ],
        "isCorrect": false
      },
      {
        "id": 1366,
        "content": [
          "Acceleration, Speed, Force and Electric field"
        ],
        "isCorrect": false
      },
      {
        "id": 1367,
        "content": [
          "Momentum, Energy, Magnetic field and Force"
        ],
        "isCorrect": false
      },
      {
        "id": 1368,
        "content": [
          "Displacement, Velocity, Magnetic field and Momentum"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 343,
    "content": [
      "Which rule about the number of significant figures is correct? Zeros in the number"
    ],
    "explanation": [
      "- **450.0**: The trailing zero after the decimal point is significant.\n- **0.0023**: The leading zeros are not significant; only 2 and 3 are significant.\n- **1.1000**: All zeros after the decimal point are significant.\n- **2.70018**: All digits, including zeros, are significant."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1369,
        "content": [
          "450.0 are significant figures."
        ],
        "isCorrect": true
      },
      {
        "id": 1370,
        "content": [
          "0.0023 are significant figures."
        ],
        "isCorrect": false
      },
      {
        "id": 1371,
        "content": [
          "1.1000 are not significant figures."
        ],
        "isCorrect": false
      },
      {
        "id": 1372,
        "content": [
          "2.70018 are not significant figures."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 344,
    "content": [
      "Given two vectors $$v_1 = 10$$ units along the positive y-axis and $$v_2 = 6$$ units at an angle of 37° above the positive x-axis. What is the scalar product of the vectors in square of units?"
    ],
    "explanation": [
      "The scalar product (dot product) of two vectors is given by the formula:\n\n$$\nv_1 \\cdot v_2 = |v_1||v_2|\\cos(\\theta)\n$$\n\nWhere:\n\n- θ = 90° - 37° = 53° (the angle between the two vectors, since one is along the y-axis and the other is 37° above the x-axis).\n\nNow, calculate the dot product:\n$$\nv_1 \\cdot v_2 = 10 \\times 6 \\times \\cos(53^\\circ)\n$$\n$$\n\\cos(53^\\circ) \\approx 0.6\n$$\n$$\nv_1 \\cdot v_2 = 10 \\times 6 \\times 0.6 = 36\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1373,
        "content": [
          "45"
        ],
        "isCorrect": false
      },
      {
        "id": 1374,
        "content": [
          "36"
        ],
        "isCorrect": true
      },
      {
        "id": 1375,
        "content": [
          "48"
        ],
        "isCorrect": false
      },
      {
        "id": 1376,
        "content": [
          "60"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Vectors"
  },
  {
    "id": 345,
    "content": [
      "An airplane takes-off at airport A and travels 500 km due east within one hour and then turning to south it flies for 20 minutes to land on airport B which is 100 km away from the turning point. The magnitude average velocity of the plane during its flight between the two airports is"
    ],
    "explanation": [
      "The plane travels 500 km east and then 100 km south. The displacement is the straight-line distance between the starting and ending points, which can be found using the Pythagorean theorem:\n\n$$\n\\text{d} = \\sqrt{(500 \\ \\text{km})^2 + (100 \\ \\text{km})^2} = 100 \\sqrt{26} \\ \\text{km}\n$$\n\nThe plane travels 500 km in 1 hour and 100 km in 20 minutes (which is $$\\frac{1}{3}$$ hour.\n$$\nt_{total} = 1 \\ \\text{hr} + \\frac{1}{3} \\ \\text{hrs} = \\frac{4}{3} \\ \\text{hrs}\n$$\n\nAverage velocity is the total displacement divided by the total time:\n\n$$\nv_{avg} = \\frac{\\text{d}}{t_{total}}\n$$\n$$\nv_{avg} =\\frac{100 \\sqrt{26} \\ \\text{km}}{\\frac{4}{3} \\ \\text{hours}} = 75 \\sqrt{26} \\ \\text{km/h}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1377,
        "content": [
          "$$75 \\sqrt {24} \\ \\text{km/h}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1378,
        "content": [
          "$$100  \\sqrt {34} \\ \\text{km/h}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1379,
        "content": [
          "$$450 \\ \\text{km/h}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1380,
        "content": [
          "$$75 \\sqrt {26} \\ \\text{km/h}$$."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 346,
    "content": [
      "A bullet is fired with an initial speed v at an angle θ with the horizontal. It takes a time to reach its maximum vertical displacement $$h_{max}$$. It hits the target point a distance R away and exactly in the horizontal level to the point where it was fired. Which one of the following statement is NOT correct about the motion of the bullet?"
    ],
    "explanation": [
      "**Option 1:** The bullet hits the target at a time 2T after it was fired (**is correct**)\n\n- The total time of flight $$T_f$$ for projectile motion is given by:\n\n$$\nT_f = \\frac{2v \\sin \\theta}{g}\n$$\n\n- Since the bullet reaches its maximum height at time $$T = \\frac{v \\sin \\theta}{g}$$, the total time of flight is indeed 2T.\n\n**Option 2**: $$h_{max}$$ is directly proportional to the initial speed v (**is NOT correct**)\n\n- The maximum height $$h_{max}$$ is given by:\n\n$$\nh_{max} = \\frac{v^2 \\sin^2 \\theta}{2g}\n$$\n\n- This equation shows that $$h_{max}$$ is proportional to $$v^2$$, not v.\n\n**Option 3**: R will be maximum if $$\\cos \\theta = \\frac{\\sqrt{2}}{2}$$ (**is correct**)\n\n- The range R of the projectile is given by:\n\n$$\nR = \\frac{v^2 \\sin 2\\theta}{g}\n$$\n\n- For the range to be maximum, $$\\sin 2\\theta$$ must be maximized, which happens when $$2\\theta = 90^\\circ$$, or $$\\theta = 45^\\circ$$. At $$\\theta = 45^\\circ$$, $$\\cos \\theta$$ = $$\\frac{\\sqrt{2}}{2}$$.\n\n**Option 4**: θ should be different from 90° to hit the target at a distance R (**is correct**)\n\n- If θ = 90°, the bullet would only move vertically and fall back to the starting point. To hit the target at a distance R, θ must indeed be different from 90°."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1381,
        "content": [
          "The bullet hits the target at a time 2T after it was fired."
        ],
        "isCorrect": false
      },
      {
        "id": 1382,
        "content": [
          "$$h_{max}$$ is directly proportional to the initial speed v."
        ],
        "isCorrect": true
      },
      {
        "id": 1383,
        "content": [
          "R will be maximum if $$\\cos {\\theta}$$= $$\\sqrt{2}/2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1384,
        "content": [
          "θ should be different from 90° to hit the target at a distance R."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 347,
    "content": [
      "A man pushes a 25.0 kg object by 250 N force along an inclined plane inclined at an angle of 37° to the horizontal. If the object moves with constant speed, the friction force exerts on the block is"
    ],
    "explanation": [
      "Component of gravitational force along the plane:\n\n$$\nF_{\\text{gravity}} = mg \\sin(37^\\circ)\n$$\n$$\nF_{appied} = F_{gravity}} + f_{friction}\n$$\n$$\nf_{\\text{friction}} = 250 \\, \\text{N} - mg \\sin(37^\\circ)\n$$\n$$\nf_{\\text{friction}} = 250 \\, \\text{N} - 150 \\, \\text{N} = 100 \\, \\text{N}\n$$\nSince the applied force is up the incline and the gravitational component is down, the friction force must act **down the incline** to oppose the applied force.\n\nCorrect answer: **100.0 N, down the inclined plane.**"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1385,
        "content": [
          "250.0 N, up the inclined plane."
        ],
        "isCorrect": false
      },
      {
        "id": 1386,
        "content": [
          "100.0 N, up the inclined plane."
        ],
        "isCorrect": false
      },
      {
        "id": 1387,
        "content": [
          "100.0 N, down the inclined plane."
        ],
        "isCorrect": true
      },
      {
        "id": 1388,
        "content": [
          "250.0 N, down the inclined plane."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 348,
    "content": [
      "The following three collisions occur in different systems.",
      "I. A billiard ball A collides with an identical ball B and comes to rest after collision, while ball B moves with the same velocity as ball A was moving before.",
      "II. A bullet moving with speed v hits a suspended mass and it imbedded in it and the combination moves with common velocity.",
      "III. Two cars moving in opposite direction become at rest after collision.",
      "Which of the following statements is correct about these collisions?"
    ],
    "explanation": [
      "- **Elastic Collision**: Both momentum and kinetic energy are conserved.\n- **Inelastic Collision**: Momentum is conserved, but kinetic energy is not conserved. In a perfectly inelastic collision, the colliding objects stick together after the collision.\n\n- **Collision I**: This is an **elastic collision**. The billiard ball A comes to rest, and ball B moves with the same velocity as ball A had before the collision, indicating that both momentum and kinetic energy are conserved.\n- **Collision II**: This is an **inelastic collision**. The bullet embeds in the mass, and they move together with a common velocity, meaning kinetic energy is not conserved, although momentum is.\n- **Collision III**: This is also an **inelastic collision**. The two cars come to rest after the collision, indicating that kinetic energy is not conserved, though momentum is."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_MOMENTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1389,
        "content": [
          "II and III are inelastic collisions."
        ],
        "isCorrect": true
      },
      {
        "id": 1390,
        "content": [
          "I and II are elastic collisions."
        ],
        "isCorrect": false
      },
      {
        "id": 1391,
        "content": [
          "I, II and III are inelastic collisions."
        ],
        "isCorrect": false
      },
      {
        "id": 1392,
        "content": [
          "I and III are elastic collisions."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 349,
    "content": [
      "An object of mass M is attached to a spring of spring constant K, as shown in the figure below.",
      "images/physics/year_2015/q49_1.png",
      "If the mass is pulled to a point P, which is at distance A from equilibrium position O, and released. Which one of the following statements is correct about energy of the system? (assume the surface is frictionless)"
    ],
    "explanation": [
      "- **At point O (equilibrium position)**, the system has only kinetic energy because the spring is neither compressed nor stretched.\n- **At point P (maximum displacement)**, the system has only potential energy because the mass is momentarily at rest before reversing direction.\n- **Maximum velocity** occurs at the equilibrium position (point O), not at point P.\n- **At point Q** (somewhere between O and P), the system has both kinetic and potential energy as the mass moves through this point."
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_MOMENTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2015/q49_1.png"
    ],
    "choices": [
      {
        "id": 1393,
        "content": [
          "At point O, the system has both kinetic and potential energy."
        ],
        "isCorrect": false
      },
      {
        "id": 1394,
        "content": [
          "At point P, the system has both kinetic energy and potential energy."
        ],
        "isCorrect": false
      },
      {
        "id": 1395,
        "content": [
          "At point P, the mass attain its maximum velocity."
        ],
        "isCorrect": false
      },
      {
        "id": 1396,
        "content": [
          "At point Q the system has both kinetic energy and potential energy."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 350,
    "content": [
      "A force $$\\vec{F}$$= ($$\\hat{i}-3 \\hat{K}$$) N acts on a wooden bar and drags the bar through a displacement of $$\\vec{r}$$ = $$4 \\hat{i} \\ \\text{m}$$. What is the torque due to the force in N.m?"
    ],
    "explanation": [
      "$$\n\\vec{\\tau} = \\vec{r} \\times \\vec{F}\n$$\nThe cross product $$\\vec{r} \\times \\vec{F}$$:\n$$\n\\vec{\\tau} = \\begin{vmatrix}\n\\hat{i} & \\hat{j} & \\hat{k} \\\\\n4 & 0 & 0 \\\\\n1 & 0 & -3\n\\end{vmatrix}\n$$\n\nCalculating this determinant gives:\n\n$$\n\\vec{\\tau} = \\hat{i} \\begin{vmatrix}\n0 & 0 \\\\\n0 & -3\n\\end{vmatrix} - \\hat{j} \\begin{vmatrix}\n4 & 0 \\\\\n1 & -3\n\\end{vmatrix} + \\hat{k} \\begin{vmatrix}\n4 & 0 \\\\\n1 & 0\n\\end{vmatrix}\n$$\n\nFor $$\\hat{i}$$:\n$$\n\\begin{vmatrix}\n0 & 0 \\\\\n0 & -3\n\\end{vmatrix} = 0\n$$\n\nFor $$\\hat{j}$$:\n$$\n\\begin{vmatrix}\n4 & 0 \\\\\n1 & -3\n\\end{vmatrix} = (4)(-3) - (0)(1) = -12\n$$\n\nFor $$\\hat{k}$$:\n$$\n\\begin{vmatrix}\n4 & 0 \\\\\n1 & 0\n\\end{vmatrix} = (4)(0) - (0)(1) = 0\n$$\n\nCombine the Results:\n\n$$\n\\vec{\\tau} = 0\\hat{i} - (-12)\\hat{j} + 0\\hat{k} = 12\\hat{j} \\, \\text{N.m}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1397,
        "content": [
          "$$4\\hat{i}+12\\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1398,
        "content": [
          "$$-12\\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1399,
        "content": [
          "$$12\\hat{j}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1400,
        "content": [
          "$$12\\hat{k}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 351,
    "content": [
      "Suppose a triangular object (O) is placed in front of a plane mirror and its image is observed at position (X). Which one of the following diagrams represents the image (I) formed by the mirror when it is observed from position (X)"
    ],
    "explanation": [
      "In a plane mirror, the image is always laterally inverted and appears as far behind the mirror as the object is in front of it. This means the image's orientation will be reversed relative to the object.\n\nFor the correct option, the image I is shown on the right side of the mirror, and its orientation is correctly flipped laterally."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_OPTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1401,
        "content": [
          "images/physics/year_2014/q1c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1402,
        "content": [
          "images/physics/year_2014/q1c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1403,
        "content": [
          "images/physics/year_2014/q1c3_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 1404,
        "content": [
          "images/physics/year_2014/q1c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Electromagnetic Waves and Geometrical Optics"
  },
  {
    "id": 352,
    "content": [
      "An object is placed 25.0 cm in front of a concave mirror having focal length of 10.0 cm. The magnification of the mirror is ______________."
    ],
    "explanation": [
      "To find the magnification of the concave mirror, we can use the mirror formula and the magnification formula.\n\nThe mirror formula is:\n\n$$\n\\frac{1}{f} = \\frac{1}{v} + \\frac{1}{u}\n$$\n\nWhere:\n\n- f is the focal length of the mirror (10.0 cm)\n- v is the image distance\n- u is the object distance (-25.0 cm, negative because the object is in front of the mirror)\n\nFirst, we solve for ( v ):\n$$\n\\frac{1}{v} = \\frac{1}{10} + \\frac{1}{-25}\n$$\n\n$$\nv = \\frac{50}{3} \\approx 16.67 \\text{ cm}\n$$\n\nNext, we use the magnification formula:\n\n$$\nm = -\\frac{v}{u}\n$$\n\n$$\nm = -\\frac{16.67}{-25} \\approx 0.67m\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_OPTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1405,
        "content": [
          "2.5"
        ],
        "isCorrect": false
      },
      {
        "id": 1406,
        "content": [
          "16.7"
        ],
        "isCorrect": false
      },
      {
        "id": 1407,
        "content": [
          "0.67"
        ],
        "isCorrect": true
      },
      {
        "id": 1408,
        "content": [
          "1.5"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Electromagnetic Waves and Geometrical Optics"
  },
  {
    "id": 353,
    "content": [
      "Which of the following statements distinguishes between random and systematic errors?"
    ],
    "explanation": [
      "Systematic errors cause measurements to be consistently off in one direction (always above or below the true value), while random errors cause measurements to vary unpredictably around the true value (sometimes above, sometimes below)."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1409,
        "content": [
          "Systematic error can be minimized by taking several readings and averaging; whereas random error cannot be minimized."
        ],
        "isCorrect": false
      },
      {
        "id": 1410,
        "content": [
          "Systematic error makes measured values to be always above or always below the true value; whereas random error causes measured values to be sometimes above and sometimes below the true value."
        ],
        "isCorrect": true
      },
      {
        "id": 1411,
        "content": [
          "Random error makes measured values to be always above or always below the true value; whereas systematic error causes measured values to be sometimes above and sometimes below the true value."
        ],
        "isCorrect": false
      },
      {
        "id": 1412,
        "content": [
          "Random error is biased, whereas systematic error does not show bias."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 354,
    "content": [
      "The unit vector in the direction of $$\\vec{A}$$ = $$3\\hat{i}+4\\hat{j}$$ is"
    ],
    "explanation": [
      "First, calculate the magnitude of $$\\vec{A}$$:\n\n$$\n|\\vec{A}| = \\sqrt{(3)^2 + (4)^2} = 5\n$$\n\nNow, divide each component of $$\\vec{A}$$ by its magnitude:\n\n$$\n\\text{Unit vector} = \\frac{\\vec{A}}{|\\vec{A}|} = \\frac{3\\hat{i} + 4\\hat{j}}{5} = \\frac{3}{5}\\hat{i} + \\frac{4}{5}\\hat{j}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1413,
        "content": [
          "$$\\frac{3}{5} \\hat{i} + \\frac{4}{5} \\hat{j}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1414,
        "content": [
          "$$2\\hat{i} - \\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1415,
        "content": [
          "$$\\frac{3}{2} \\hat{i} + \\frac{4}{2} \\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1416,
        "content": [
          "$$\\hat{i} + \\hat{j}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Vectors"
  },
  {
    "id": 355,
    "content": [
      "Which of the following pair of vectors are collinear?"
    ],
    "explanation": [
      "To determine if two vectors are collinear, we need to check if one vector is a scalar multiple of the other.\n\n**Option 1**:$$2\\hat{i} - 3\\hat{j}$$ and $$-4\\hat{i} - 6\\hat{j}$$:\n\n- $$\\frac{-4}{2}$$ = -2 and $$\\frac{-6}{-3}$$ = 2 (**not collinear**)\n\n**Option 2**:$$\\hat{i} + \\hat{j}$$ and $$-\\hat{i} + \\hat{j}$$:\n\n- $$\\frac{-1}{1} = -1$$ and $$\\frac{1}{1} = 1$$ (**not collinear**)\n\n**Option 3**:$$2\\hat{i} + 3\\hat{j}$$ and $$-4\\hat{i} + 6\\hat{j}$$:\n\n- $$\\frac{-4}{2} = -2$$ and $$\\frac{6}{3} = 2$$ (**not collinear**)\n\n**Option 4**:$$2\\hat{i} + 3\\hat{j}$$ and $$-4\\hat{i} - 6\\hat{j}$$:\n\n- $$\\frac{-4}{2} = -2$$ and $$\\frac{-6}{3} = -2$$ (**collinear**)"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1417,
        "content": [
          "$$2\\hat{i}-3\\hat{j}$$ and $$-4\\hat{i}-6\\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1418,
        "content": [
          "$$\\hat{i}+\\hat{j}$$ and $$-\\hat{i}+\\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1419,
        "content": [
          "$$2\\hat{i}+3\\hat{j}$$ and $$-4\\hat{i}+6\\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1420,
        "content": [
          "$$2\\hat{i}+3\\hat{j}$$ and $$-4\\hat{i}-6\\hat{j}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 356,
    "content": [
      "For an object moving in straight line,"
    ],
    "explanation": [
      "A constant increase in velocity indicates constant acceleration, resulting in a straight line with a positive slope on the velocity-time graph and a horizontal line on the acceleration-time graph."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1421,
        "content": [
          "if the velocity increases by equal amount in equal time interval, the velocity-time graph is straight line with positive slope and the acceleration-time graph is horizontal."
        ],
        "isCorrect": true
      },
      {
        "id": 1422,
        "content": [
          "the slope of displacement-time graph and the area of the region under acceleration-time graph are, respectively, the acceleration and velocity of the object."
        ],
        "isCorrect": false
      },
      {
        "id": 1423,
        "content": [
          "if the displacement changes by equal amount in equal time interval, the displacement-time graph is horizontal line."
        ],
        "isCorrect": false
      },
      {
        "id": 1424,
        "content": [
          "the area of the region under the displacement-time graph and the slope of velocity-time graph are, respectively, the acceleration and displacement of the object."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Uniformly Accelerated Motion"
  },
  {
    "id": 357,
    "content": [
      "Which of the following is true about satellite motion?"
    ],
    "explanation": [
      "The formula for the orbital speed v of a satellite is:\n\n$$\nv = \\sqrt{\\frac{GM}{r}}\n$$\n\nWhere:\n\n- G is the gravitational constant ($$6.67430 \\times 10^{-11}$$ $$\\text{m}^3 \\text{kg}^{-1} \\text{s}^{-2}$$),\n- M is the mass of the Earth,\n- r is the distance from the center of the Earth to the satellite.\n\nFrom this formula, you can see that as the distance r decreases (i.e., the satellite is closer to Earth), the speed v increases. This explains why a satellite closer to Earth moves faster than one farther away."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1425,
        "content": [
          "For equal orbital radius, a satellite moving around the Earth has smaller speed than a satellite moving about Moon."
        ],
        "isCorrect": false
      },
      {
        "id": 1426,
        "content": [
          "A satellite closer to Earth is faster than a satellite farther from the Earth."
        ],
        "isCorrect": true
      },
      {
        "id": 1427,
        "content": [
          "A satellite moving closer to the Earth takes longer time to complete one revolution than a satellite farther from Earth."
        ],
        "isCorrect": false
      },
      {
        "id": 1428,
        "content": [
          "For two satellites moving around the Earth at equal orbital radius, a heavier satellite has larger speed than a lighter one."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 358,
    "content": [
      "A block of mass m is placed on horizontal surface. The coefficient of static friction between the block and the surface is μ. A force of magnitude F acts on the block at an angle θ¸ as shown in the figure below.",
      "images/physics/year_2014/q8_1.png",
      "The minimum magnitude of the force F required to slide the block on the surface is"
    ],
    "explanation": [
      "The force F has components $$F \\cos{\\theta}$$ (horizontal) and $$F \\sin{\\theta}$$ (vertical).\nThe normal force (N) is given by:\n$$\nN = mg + F \\sin{\\theta}\n$$\nThe maximum static friction force ($$f_s$$) is:\n$$\nf_s = \\mu N = \\mu (mg + F \\sin{\\theta})\n$$\nFor the block to start sliding, the horizontal component of F must overcome $$f_s$$:\n$$\nF \\cos{\\theta} = \\mu (mg + F \\sin{\\theta})\n$$\nSolving for F:\n$$\nF = \\frac{\\mu mg}{\\cos{\\theta} - \\mu \\sin{\\theta}}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2014/q8_1.png"
    ],
    "choices": [
      {
        "id": 1429,
        "content": [
          "$$\\frac{\\mu\\text{mg}}{\\cos{\\theta} - \\mu\\sin{\\theta}}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1430,
        "content": [
          "$$\\frac{\\mu\\text{mg}}{\\cos{\\theta} + \\mu\\sin{\\theta}}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1431,
        "content": [
          "$$\\frac{\\mu\\text{mg}}{\\cos{\\theta} - \\sin{\\theta}}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1432,
        "content": [
          "$$\\frac{\\mu\\text{mg}}{\\cos{\\theta} + \\sin{\\theta}}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 359,
    "content": [
      "A ball of mass m moving with a speed v strikes a hard wall at an angle with the wall. It is reflected with the same speed at the same angle as shown in the figure below.",
      "images/physics/year_2014/q9_1.png",
      "If the ball is in contact with the wall for time t, then the average force acting on the wall is given by"
    ],
    "explanation": [
      "We need to consider the change in momentum of the ball in the direction perpendicular to the wall.\n- **Initial momentum** in the direction perpendicular to the wall:\n\n$$\np_{\\text{initial}} = mv \\sin{\\theta}\n$$\n\n- **Final momentum** in the direction perpendicular to the wall:  (since the ball is reflected back with the same speed and angle)\n\n$$\n\np_{\\text{final}} = -mv \\sin{\\theta}\n$$\n\nThe change in momentum ($$\\Delta p$$) is:\n\n$$\n\\Delta p = p_{\\text{final}} - p_{\\text{initial}}\n$$\n\n$$\n\\Delta p = -mv \\sin{\\theta} - (mv \\sin{\\theta}) = -2mv \\sin{\\theta}\n$$\n\nThe average force ($$F_{\\text{avg}}$$) acting on the wall is given by the change in momentum divided by the time of contact (t):\n\n$$\nF_{\\text{avg}} = \\frac{\\Delta p}{t} = \\frac{-2mv \\sin{\\theta}}{t}\n$$\n\nSince force is a vector quantity and we are interested in the magnitude, we take the absolute value:\n\n$$\nF_{\\text{avg}} = \\frac{2mv}{t}\\sin{\\theta}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_MOMENTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2014/q9_1.png"
    ],
    "choices": [
      {
        "id": 1433,
        "content": [
          "$$\\frac{\\text{mv}}{\\text{t}} \\ \\cos{\\theta}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1434,
        "content": [
          "$$\\frac{\\text{mv}}{\\text{t}} \\ \\sin{\\theta}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1435,
        "content": [
          "$$\\frac{\\text{2mv}}{\\text{t}} \\ \\cos{\\theta}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1436,
        "content": [
          "$$\\frac{\\text{2mv}}{\\text{t}} \\ \\sin{\\theta}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 360,
    "content": [
      "According to the work-energy theorem,"
    ],
    "explanation": [
      "When an object is thrown upward, gravity acts downward, opposite to the direction of the object's motion. Since work is defined as the force applied in the direction of displacement, the work done by gravity in this case is negative because the force of gravity and the displacement are in opposite directions."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1437,
        "content": [
          "work done by tension on an object tied to a string and moving in a horizontal circle is negative."
        ],
        "isCorrect": false
      },
      {
        "id": 1438,
        "content": [
          "work done by gravity on an object object thrown downward is negative."
        ],
        "isCorrect": false
      },
      {
        "id": 1439,
        "content": [
          "work done by gravity on an object thrown upward and moving upward is negative."
        ],
        "isCorrect": true
      },
      {
        "id": 1440,
        "content": [
          "work done by gravitational force on a satellite moving around the earth in a circular orbit is positive."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 361,
    "content": [
      "Standing wave is formed when two identical waves travelling in opposite directions in the same medium interfere with each other. If $$y_1$$ and $$y_2$$ are the interfering waves and $$y$$ = $$y_1 + y_2$$ is the resulting standing wave, which of the following is a correct combination?"
    ],
    "explanation": [
      "Given:\n$$y_1 = A \\sin(kx - \\omega t)$$ and $$y_2 = A \\sin(kx + \\omega t)$$\n\n- Using the trigonometric identity for the sum of sine functions:\n$$\n\\sin(a) + \\sin(b) = 2 \\sin\\left(\\frac{a+b}{2}\\right) \\cos\\left(\\frac{a-b}{2}\\right)\n$$\n- Let's apply this to our waves:\n$$\ny = y_1 + y_2 = A \\sin(kx - \\omega t) + A \\sin(kx + \\omega t)\n$$\n- Here,a = $$kx - \\omega t$$ and b = $$kx + \\omega t$$.\n$$\ny = 2A \\sin\\left(\\frac{(kx - \\omega t) + (kx + \\omega t)}{2}\\right) \\cos\\left(\\frac{(kx - \\omega t) - (kx + \\omega t)}{2}\\right)\n$$\n- Simplifying the arguments of the sine and cosine functions:\n$$\ny = 2A \\sin(kx) \\cos(\\omega t)\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_OPTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1441,
        "content": [
          "$$y_1 = A \\sin(kx-\\omega t)$$, $$y_2 = A \\sin(kx+\\omega t)$$, $$y = A \\sin(kx) \\cos(2 \\omega t)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1442,
        "content": [
          "$$y_1 = A \\sin(kx-\\omega t)$$, $$y_2 = A \\sin(kx+\\omega t)$$, $$y = 2A \\sin(kx) \\cos(\\omega t)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1443,
        "content": [
          "$$y_1 = A \\sin(kx-\\omega t)$$, $$y_2 = A \\ \\sin(kx-\\omega t)$$, $$y = 2A \\sin(kx) \\cos(\\omega t)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1444,
        "content": [
          "$$y_1 = A \\sin(kx-\\omega t)$$, $$y_2 = A \\sin(kx+\\omega t)$$, $$y = 2A \\sin(kx-\\omega t)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Electromagnetic Waves and Geometrical Optics"
  },
  {
    "id": 362,
    "content": [
      "A Young double slit experiment consists of two narrow slits separated by 0.06 mm and 1.2 m away from a screen. If the slits are illuminated with a light of wavelength 563 nm, the location of the fourth bright fringe on the screen is"
    ],
    "explanation": [
      "We can use double-slit interference formula:\n\n$$\ny_m = \\frac{m \\lambda L}{d}\n$$\n\nWhere:\n\n- $$y_m$$ is the distance from the central maximum to the $$m^th$$ bright fringe,\n- m is the order of the fringe (for the fourth bright fringe m = 4,\n- $$\\lambda$$ is the wavelength of the light (563 nm or ( $$563 \\times 10^{-9} \\ \\text{m}$$),\n- L is the distance from the slits to the screen (1.2 m),\n- d is the distance between the slits (0.06 mm or ( $$0.06 \\times 10^{-3} \\ \\text{m}$$).\n\n$$\ny_4 = \\frac{4 \\times 563 \\times 10^{-9} \\, \\text{m} \\times 1.2 \\, \\text{m}}{0.06 \\times 10^{-3} \\, \\text{m}}\n$$\n\n$$\ny_4 = 0.4504 \\, \\text{m}\n$$\n\n$$\ny_4 = 45.04 \\, \\text{cm}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_OPTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1445,
        "content": [
          "0.394 cm."
        ],
        "isCorrect": false
      },
      {
        "id": 1446,
        "content": [
          "0.45 cm."
        ],
        "isCorrect": false
      },
      {
        "id": 1447,
        "content": [
          "3.94 cm."
        ],
        "isCorrect": false
      },
      {
        "id": 1448,
        "content": [
          "4.5 cm."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Electromagnetic Waves and Geometrical Optics"
  },
  {
    "id": 363,
    "content": [
      "An electric dipole consists of a negative charge -q placed at a point with x and y coordinates (-2,-2) and a positive charge +q at (2, 2). The dipole is placed in a uniform electric field $$\\vec{E}$$ directed in the positive x direction. If the dipole axis makes an angle θ with the field, which of the following is true about the dipole?"
    ],
    "explanation": [
      "When an electric dipole is placed in a uniform electric field, it experiences a torque that tends to align the dipole moment with the electric field. The torque $$\\tau$$ on the dipole is given by:\n$$\n\\tau = \\vec{p} \\times \\vec{E} = pE \\sin \\theta\n$$\n- Where $$\\vec{p}$$ is the dipole moment, $$\\vec{E}$$ is the electric field, and θ is the angle between $$\\vec{p}$$ and $$\\vec{E}$$.\n\nGiven this, the correct statement is:\n\n- The field rotates the dipole in the direction of decreasing the angle θ, until the dipole becomes parallel to the field.\n- This is because the torque acts to reduce the angle θ to zero, aligning the dipole moment with the electric field direction."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1449,
        "content": [
          "The field rotates the dipole in the direction of decreasing the angle θ, until the dipole becomes parallel to the field."
        ],
        "isCorrect": true
      },
      {
        "id": 1450,
        "content": [
          "The field rotates it in the direction of increasing the angle θ, until the dipole is perpendicular to the field."
        ],
        "isCorrect": false
      },
      {
        "id": 1451,
        "content": [
          "It is in both translational and rotational equilibrium."
        ],
        "isCorrect": false
      },
      {
        "id": 1452,
        "content": [
          "It travels in the direction of the electric field."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 364,
    "content": [
      "The electric potential at a distance of 2 cm from a $$-1.6 \\times 10^{-9} \\text{C}$$ point charge is"
    ],
    "explanation": [
      "The electric potential V due to a point charge Q at a distance r is given by the formula:\n$$\nV = \\frac{kQ}{r}\n$$\n\nGiven:\n\n- k = $$8.99 \\times 10^9$$ $$\\text{N m}^2 \\text{C}^2$$) (Coulomb's constant),\n- Q = $$-1.6 \\times 10^{-9}$$ $$\\text{C}$$,\n- r = 2 cm = 0.02 m.\n\nNow, substituting the values into the formula:\n$$\nV = \\frac{(8.99 \\times 10^9) \\times (-1.6 \\times 10^{-9})}{0.02}\n$$\n$$\nV \\approx -720 \\, \\text{V}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1453,
        "content": [
          "-14.4 V."
        ],
        "isCorrect": false
      },
      {
        "id": 1454,
        "content": [
          "720 V."
        ],
        "isCorrect": false
      },
      {
        "id": 1455,
        "content": [
          "4.4 V."
        ],
        "isCorrect": false
      },
      {
        "id": 1456,
        "content": [
          "-720 V."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 365,
    "content": [
      "Two resistors $$R_1$$ = 1 Ω and $$R_2$$ = 4 Ω are connected in parallel to each other and their combination is connected in series with a third resistor $$R_3$$ = 2 Ω. The whole combination is connected to a voltage source of potential difference 14 V.",
      "images/physics/year_2014/q15_1.png",
      "The potential difference across $$R_1$$ is"
    ],
    "explanation": [
      "Calculate the equivalent resistance of $$R_1$$ and $$R_2$$ in parallel.\n\n$$\\frac{1}{R_p}$$ = $$\\frac{1}{R_1}$$ + $$\\frac{1}{R_2}$$\n\n$$\\frac{1}{R_p}$$ = $$\\frac{1}{1}$$ + $$\\frac{1}{4}$$ = $$1.25$$ \n\n$$R_p$$ = $$\\frac{1}{1.25}$$ = 0.8 Ω\n\nCalculate the total resistance in the circuit.\n\n$$R_{\\text{total}}$$ = $$R_p$$ + $$R_3$$ = 0.8 + 2 = 2.8 Ω\n\nCalculate the total current I in the circuit. Using Ohm''s law V = IR:\n\n$$\nI = \\frac{V_{\\text{source}}}{R_{\\text{total}}} = \\frac{14}{2.8} = 5 \\, A\n$$\n\nCalculate the potential difference across $$R_3$$.\n\n$$\nV_{R_3} = I \\cdot R_3 = 5 \\cdot 2  = 10 \\ V\n$$\n\nCalculate the potential difference across the parallel combination $$V_p$$:\n$$\nV_p = V_{\\text{source}} - V_{R_3} = 14 \\, V - 10 \\, V = 4 \\, V\n$$\n\nIn a parallel circuit, the potential difference across each resistor is the same as the potential difference across the parallel combination. Therefore, the potential difference across $$R_1$$ is: 4 V"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2014/q15_1.png"
    ],
    "choices": [
      {
        "id": 1457,
        "content": [
          "10 V."
        ],
        "isCorrect": false
      },
      {
        "id": 1458,
        "content": [
          "14 V."
        ],
        "isCorrect": false
      },
      {
        "id": 1459,
        "content": [
          "5 V."
        ],
        "isCorrect": false
      },
      {
        "id": 1460,
        "content": [
          "4 V."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 366,
    "content": [
      "Consider a long and tightly wound solenoid carrying current I, having length L and N turns of winding. If n is the number of turns per unit length, which of the following describes the magnetic field produced by the solenoid?"
    ],
    "explanation": [
      "Inside the solenoid the magnetic field is uniform, parallel to the axis of the solenoid. The field inside a long solenoid is constant and directed along its length (parallel to the solenoid's axis). Outside the solenoid the magnetic field outside is negligible because the fields produced by different turns cancel each other out. Thus, the magnetic field outside is very weak."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1461,
        "content": [
          "The magnetic field inside the solenoid is zero, whereas the field outside is perpendicular to the length of the solenoid."
        ],
        "isCorrect": false
      },
      {
        "id": 1462,
        "content": [
          "The magnetic field inside the solenoid is constant and is parallel to the solenoid's axis, whereas the field outside is negligible."
        ],
        "isCorrect": true
      },
      {
        "id": 1463,
        "content": [
          "The magnetic field inside the solenoid is uniform and perpendicular to the axis of the solenoid."
        ],
        "isCorrect": false
      },
      {
        "id": 1464,
        "content": [
          "The magnetic field outside the solenoid is as strong as the field inside it."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 367,
    "content": [
      "According to the law of electromagnetic induction,"
    ],
    "explanation": [
      "Faraday's law, states that the induced electromotive force (emf) in any closed circuit is directly proportional to the rate of change of the magnetic flux through the circuit."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1465,
        "content": [
          "the magnitude of emf induced in a circuit is directly proportional to the rate of change the magnetic flux crossing any surface bounded by the circuit."
        ],
        "isCorrect": true
      },
      {
        "id": 1466,
        "content": [
          "a changing magnetic field parallel to the plane of a circuit induces an emf in it."
        ],
        "isCorrect": false
      },
      {
        "id": 1467,
        "content": [
          "a constant magnetic flux crossing the surface of a circuit induced an emf in the circuit."
        ],
        "isCorrect": false
      },
      {
        "id": 1468,
        "content": [
          "an emf is induced in a circuit when a constant magnetic field crosses its surface."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 368,
    "content": [
      "A resistor R, a capacitor C, and inductor L are connected in series to an AC voltage source that generates a sinusoidal voltage, $$V(t)$$= $$V_p \\ \\sin{(\\omega t)}$$, with $$V_p$$ and $$\\omega$$ being the peak voltage and angular frequency of the source. If $$X_C$$, $$X_L$$, and Z are capacitive reactance, inductive reactance, and impedance, respectively; $$I_{rms}$$ and $$V_{rms}$$ are the root-mean-square (rms) values of the current and voltage, the average power dissipated in series the RLC circuit is given by"
    ],
    "explanation": [
      "The general formula for the average power dissipated in an AC circuit is:\n\n$$\nP_{avg} = I_{rms}^2 R\n$$\n\nHowever, this formula can be expressed in terms of voltage and impedance. \n\n$$\nP_{avg} = I_{rms} V_{rms} \\frac{R}{Z}\n$$\n\nWhere:\n\n- Z = $$\\sqrt{R^2 + (X_L - X_C)^2}$$ is the total impedance of the circuit,\n- $$X_L$$ = $$\\omega L$$ is the inductive reactance,\n- $$X_C$$ = $$\\frac{1}{\\omega C}$$ is the capacitive reactance,\n- $$I_{rms}$$ = $$\\frac{V_{rms}}{Z}$$\n\nThe correct answer is:\n\n$$I_{rms} V_{rms} \\frac{R}{\\sqrt{R^2+(X_L-X_C)^2}}$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1469,
        "content": [
          "$$2I_pV_p$$ $$\\frac{R}{\\sqrt{R^2+(X_L-X_C)^2}}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1470,
        "content": [
          "$$I_{rms} V_{rms}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1471,
        "content": [
          "$$I_{rms} V_{rms}$$ $$\\frac{R}{\\sqrt{R^2+(X_L-X_C)^2}}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1472,
        "content": [
          "$$I^2_{rms}Z$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 369,
    "content": [
      "According to the Heisenberg's uncertainty principle,"
    ],
    "explanation": [
      "According to Heisenberg's uncertainty principle, the product of the uncertainties in position ($$\\Delta x$$) and momentum ($$\\Delta p$$) is constrained by the relation:\n$$\n\\Delta x \\Delta p \\geq \\frac{\\hbar}{2}\n$$\n\nThis means that as the uncertainty in position ($$\\Delta x$$) decreases (i.e., we measure the position more precisely), the uncertainty in momentum ($$\\Delta p$$) must increase, and vice versa."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_PHOTON",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1473,
        "content": [
          "the larger the position uncertainty, the larger the momentum uncertainty."
        ],
        "isCorrect": false
      },
      {
        "id": 1474,
        "content": [
          "if the uncertainty in position decreases, the momentum uncertainty decreases, too."
        ],
        "isCorrect": false
      },
      {
        "id": 1475,
        "content": [
          "the more precisely we measure the position of a particle; we become less precise of its momentum and vice versa."
        ],
        "isCorrect": true
      },
      {
        "id": 1476,
        "content": [
          "we can measure both the position and momentum of a particle simultaneously with unlimited precision."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Basics of Electrons"
  },
  {
    "id": 370,
    "content": [
      "The graph of nuclear binding energy per nucleon (BE/A) versus mass number (A) has its peak near an atomic weight A = 56. Which of the following statements is true about the graph?"
    ],
    "explanation": [
      "- The binding energy per nucleon peaks around iron (A = 56), meaning iron is one of the most stable nuclei.\n- For nuclei heavier than iron, the binding energy per nucleon decreases as the mass number increases, indicating they are less stable.\n- Heavier nuclei can increase stability through nuclear fission, not by increasing protons, but by splitting into smaller, more stable nuclei."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_PHOTON",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1477,
        "content": [
          "Uranium (A = 235), which has larger binding energy than iron (A = 56), is more stable than iron."
        ],
        "isCorrect": false
      },
      {
        "id": 1478,
        "content": [
          "Nucleus with larger number of neutron is more stable than nucleus of the same atom with smaller number of neutron."
        ],
        "isCorrect": false
      },
      {
        "id": 1479,
        "content": [
          "For heavier nuclei (A > 56), the binding energy per nucleon decreases with the increase of mass number; implying that heavier atoms can increase their stability by increasing their protons' number."
        ],
        "isCorrect": true
      },
      {
        "id": 1480,
        "content": [
          "For smaller atoms (A < 56), the biding energy per nucleon generally increases with the increase of mass number; indicating that lighter atoms can increase stability through nuclear fission."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Nuclear Physics"
  },
  {
    "id": 371,
    "content": [
      "Which of the following statements is NOT correct about reflection and refraction of sound waves and their applications?"
    ],
    "explanation": [
      "Echo (refraction of sound) is formed when sound waves reflect off a surface, not when they enter a medium of varying densities. Reflection occurs at the boundary between different media, while entering a new medium leads to refraction."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_SOUND",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1481,
        "content": [
          "In pre-natal scanning, reflection and refraction of sound allows doctors to monitor the progress of a developing baby."
        ],
        "isCorrect": false
      },
      {
        "id": 1482,
        "content": [
          "Reflection of sound (echo) is formed when sound enters a medium of varying densities."
        ],
        "isCorrect": true
      },
      {
        "id": 1483,
        "content": [
          "Reflection and refraction of sound are used to detect flaws in metals and to help people park their cars."
        ],
        "isCorrect": false
      },
      {
        "id": 1484,
        "content": [
          "Refraction of sound is the change in its direction as it travels through a medium having different densities."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Mechanical Oscillation and Sound Wave"
  },
  {
    "id": 372,
    "content": [
      "A torque $$\\tau$$ rotates an object of mass m and moment of inertia I through an angle θ. The work done on the object by the torque is"
    ],
    "explanation": [
      "The work done by a torque is analogous to the work done by a force in linear motion, which is given by the product of the force and the distance moved in the direction of the force.\n\nIn rotational dynamics, the equivalent relationship involves torque and the angular displacement. Hence, the work done is the product of torque and the angle through which the object is rotated.\n$$\nW = \\tau \\theta\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1485,
        "content": [
          "$$I \\theta$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1486,
        "content": [
          "$$m \\theta$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1487,
        "content": [
          "$$\\tau \\theta$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1488,
        "content": [
          "$$\\tau I$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 373,
    "content": [
      "A satellite revolves around the Earth in a circular orbit of radius r = $$4 \\times 10^{16} \\ \\text{m}$$. The period of the satellite is"
    ],
    "explanation": [
      "To find the period of a satellite in circular orbit around the Earth, we can use Kepler's third law:\n\n$$\nT = 2 \\pi \\sqrt{\\frac{r^3}{GM} }\n$$\n\nWhere:\n\n- T = period of the satellite,\n- G = gravitational constant ($$6.674 \\times 10^{-11}$$ $$\\text{m}^3\\, \\text{kg}^{-1}\\, \\text{s}^{-2}$$),\n- M = mass of the Earth $$5.972 \\times 10^{24} \\, \\text{kg}$$,\n- r = radius of the orbit ($$4 \\times 10^{16} \\, \\text{m}$$).\n\nSolving for T:\n$$\nT \\approx 2.52 \\times 10^{18} \\ \\text{s}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1489,
        "content": [
          "$$2.5 \\times 10^{19} \\ \\text{s}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1490,
        "content": [
          "$$3.7 \\times 10^{27} \\ \\text{s}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1491,
        "content": [
          "$$3.7 \\times 10^{26} \\ \\text{s}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1492,
        "content": [
          "$$2.5 \\times 10^{18} \\ \\text{s}$$."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 374,
    "content": [
      "One of the following statements is a correct description of the charging processes?"
    ],
    "explanation": [
      "When a positively charged object contacts the neutral sphere, electrons from the sphere move to the positively charged object, leaving the sphere with a net positive charge."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1493,
        "content": [
          "During charging a neutral object by induction using negatively charged rod, charge flows from the rod to the object."
        ],
        "isCorrect": false
      },
      {
        "id": 1494,
        "content": [
          "When a neutral metallic sphere is charged by induction using a negatively charged rod, the sphere acquires a net negative charge."
        ],
        "isCorrect": false
      },
      {
        "id": 1495,
        "content": [
          "When a positively charged object is momentarily brought into contact with a neutral metallic sphere, the sphere acquires a net positive charge."
        ],
        "isCorrect": true
      },
      {
        "id": 1496,
        "content": [
          "When a plastic rod is rubbed with wool, the two objects acquire a net charge of the same sign."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 375,
    "content": [
      "A parallel plate capacitor is charged with a battery. The battery is then disconnected, and a dielectric material is inserted between the plates of the capacitor. Which of the following is correct about the effect of the dielectric?"
    ],
    "explanation": [
      "When a dielectric material is inserted into a parallel plate capacitor after disconnecting the battery, the following effects occur:\n- The **capacitance increases** because the dielectric reduces the electric field within the capacitor, allowing it to store more charge for the same potential difference.\n- The **charge on the plates remains the same** because the battery is disconnected, so no additional charge can flow onto the plates.\n- The **potential difference decreases** because the capacitance has increased while the charge remains constant.\n- The **electric field decreases** because the dielectric reduces the field strength between the plates.\n- The **energy stored decreases** because the energy stored in a capacitor is given by $$\\frac{Q^2}{2C}$$ ), and since C increases, the energy decreases for the same charge Q."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1497,
        "content": [
          "The potential difference between the plates remains the same and the charge increases."
        ],
        "isCorrect": false
      },
      {
        "id": 1498,
        "content": [
          "The charge on the plates decreases and the energy stored increases."
        ],
        "isCorrect": false
      },
      {
        "id": 1499,
        "content": [
          "The electric field between the plates and the energy stored decrease."
        ],
        "isCorrect": true
      },
      {
        "id": 1500,
        "content": [
          "The capacitance remains the same and the electric field between the plates increases."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 376,
    "content": [
      "Which one of the following statements is correct about the resistance of a conductor with a circular cross-section?"
    ],
    "explanation": [
      "The resistance of the conductor increases as its length increases and its diameter decreases. This is because, according to the formula\n$$\nR = \\rho \\frac{L}{A}\n$$\nResistance R increases with the length L of the conductor and decreases with the cross-sectional area A. The cross-sectional area A for a circular cross-section can be calculated as:\n$$\nA = \\pi \\left(\\frac{d}{2}\\right)^2 = \\frac{\\pi d^2}{4}\n$$\nSince A is proportional to the square of the diameter, a decrease in diameter increases the resistance."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1501,
        "content": [
          "At a given temperature, the resistance of copper and silver wires of- the same length and diameter is the same."
        ],
        "isCorrect": false
      },
      {
        "id": 1502,
        "content": [
          "The resistance of the conductor increases as its length increases and its diameter decreases."
        ],
        "isCorrect": true
      },
      {
        "id": 1503,
        "content": [
          "The resistance of the conductor increases as its length and diameter increases."
        ],
        "isCorrect": false
      },
      {
        "id": 1504,
        "content": [
          "The resistance of the conductor decreases as it is heated."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 377,
    "content": [
      "A student wants to investigate Ohm's law using an ammeter (A) and a voltmeter (V) to measure current through and potential difference across a resistor R. Moreover, she employs a rheostat to vary the potential difference across the resistor. Which of the following connections is the correct set up of the circuit to perform the experiment?"
    ],
    "explanation": [
      "The correct setup is to place the ammeter in series with the resistor to measure the current, and the voltmeter in parallel with the resistor to measure the voltage drop across it."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1505,
        "content": [
          "images/physics/year_2014/q27c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1506,
        "content": [
          "images/physics/year_2014/q27c2_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 1507,
        "content": [
          "images/physics/year_2014/q27c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1508,
        "content": [
          "images/physics/year_2014/q27c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 378,
    "content": [
      "Circular paths followed by two charges $$q_1$$ and $$q_2$$ moving with the same speed in uniform magnetic field directed into the page (x) are shown in the figure below.",
      "images/physics/year_2014/q28_1.png",
      "If the two charges have the same mass, which of the following is correct about the sign and the magnitude of charges?"
    ],
    "explanation": [
      "When a charged particle moves in a uniform magnetic field, it experiences a force perpendicular to both its velocity and the magnetic field. This force causes the particle to move in a circular path. The radius of this path is given by:\n\n$$\nr = \\frac{mv}{|q|B}\n$$\n\nGiven that both charges $$q_1$$ and $$q_2$$ have the same mass and speed, the radius of their paths depends on the magnitude of their charges. A larger charge magnitude results in a smaller radius.\n\nAdditionally, the direction of the force (and thus the direction of the circular motion) depends on the sign of the charge. Using the right-hand rule, if the magnetic field is directed into the page (represented by 'x'), a positive charge will move in a counterclockwise direction, while a negative charge will move in a clockwise direction.\n\n- If $$q_1$$ is negative and $$q_2$$ is positive, they will move in opposite directions (one clockwise and the other counterclockwise).\n- The charge with the smaller radius has a larger magnitude.\n\nTherefore, the correct answer is: $$q_1$$ is negative, $$q_2$$ is positive and | $$q_1$$ | > | $$q_2$$ |.\n\nThis means $$q_1$$ has a larger magnitude than $$q_2$$, resulting in a smaller radius for $$q_1$$ path compared to $$q_2$$ path."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2014/q28_1.png"
    ],
    "choices": [
      {
        "id": 1509,
        "content": [
          "$$q_1$$ is negative, $$q_2$$ is positive and |$$q_1$$|<|$$q_2$$|·"
        ],
        "isCorrect": true
      },
      {
        "id": 1510,
        "content": [
          "$$q_1$$ is negative, $$q_2$$ is positive and |$$q_1$$|>|$$q_2$$|."
        ],
        "isCorrect": false
      },
      {
        "id": 1511,
        "content": [
          "$$q_1$$ is positive, $$q_2$$ is negative and |$$q_1$$|<|$$q_2$$|."
        ],
        "isCorrect": false
      },
      {
        "id": 1512,
        "content": [
          "$$q_1$$ is positive, $$q_2$$ is negative and |$$q_1$$|>|$$q_2$$|."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 379,
    "content": [
      "The primary coil of a transformer has 250 turns and its secondary coil consists of 1500 turns. If 220 V is applied to its primary coil, the voltage induced in the secondary coil and the ratio of current in the primary coil to the current in the secondary coil, respectively, are ______________ ."
    ],
    "explanation": [
      "$$\n\\frac{V_s}{V_p} = \\frac{N_s}{N_p}\n$$\n\n$$\n\\frac{I_p}{I_s} = \\frac{N_s}{N_p}\n$$\n\nFirst, calculate the secondary voltage ($$V_s$$):\n\n$$\n\\frac{V_s}{220} = \\frac{1500}{250}\n$$\n\n$$\nV_s = 1320 \\text{ V}\n$$\n\nNext, calculate the current ratio:\n\n$$\n\\frac{I_p}{I_s} = \\frac{1500}{250}\n$$\n\n$$\n\\frac{I_p}{I_s} = 6\n$$\n\nAnswer is 1320 V and 6"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1513,
        "content": [
          "1320 V and 6"
        ],
        "isCorrect": true
      },
      {
        "id": 1514,
        "content": [
          "1330 V and 6"
        ],
        "isCorrect": false
      },
      {
        "id": 1515,
        "content": [
          "1220 V and 60"
        ],
        "isCorrect": false
      },
      {
        "id": 1516,
        "content": [
          "1320 V and 60"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 380,
    "content": [
      "A diode is an electronic component that"
    ],
    "explanation": [
      "A diode is a specialized electronic component that acts as a one-way switch. It conducts electric current in only one direction and restricts current from the opposite direction. This property makes diodes essential in various applications, such as rectifiers, which convert AC to DC, and in protecting circuits from reverse current."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1517,
        "content": [
          "is useful to convert a DC voltage to AC voltage."
        ],
        "isCorrect": false
      },
      {
        "id": 1518,
        "content": [
          "allows electric current to pass through it in one direction."
        ],
        "isCorrect": true
      },
      {
        "id": 1519,
        "content": [
          "allows the flow of current when its p-type region is connected to the negative terminal of a cell."
        ],
        "isCorrect": false
      },
      {
        "id": 1520,
        "content": [
          "allows current to pass through it either from cathode to anode or from anode to cathode."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 381,
    "content": [
      "Three forces, each having equal magnitudes of 10 N, are applied to an object on a horizontal surface. A force F, makes an angle of 30° above positive x-axis, $$F_2$$ makes 30° above the negative x-axis, and the third force $$F_3$$ is directed along the positive x-axis. The magnitude and direction of their resultant force are, respectively"
    ],
    "explanation": [
      "Resolve each force into its x and y components.\n\nFor $$F_1$$:\n$$\nF_{1x} = 10 \\cos(30^\\circ) \\ \\text{N}\n$$\n$$\nF_{1y} = 10 \\sin(30^\\circ) = 5 \\, \\text{N}\n$$\nFor $$F_2$$:\n$$\nF_{2x} = 10 \\cos(30^\\circ) \\ \\text{N}\n$$\n$$\nF_{2y} = 10 \\sin(30^\\circ) = 5 \\, \\text{N}\n$$\n\nFor $$F_3$$:\n$$\nF_{3x} = 10 \\, \\text{N}\n$$\n$$\nF_{3y} = 0 \\, \\text{N}\n$$\n\nSum of x-components:\n$$\nF_{x_{\\text{total}}} =  10 \\cos(30^\\circ) \\ \\text{N}\n- 10 \\cos(30^\\circ) \\ \\text{N} + 10 \\ \\text{N} = 10 \\, \\text{N}\n$$\n\nSum of y-components:\n$$\nF_{y_{\\text{total}}} = 5 + 5 + 0 = 10 \\, \\text{N}\n$$\n$$\nF_{\\text{total}} = \\sqrt{(F_{x_{\\text{total}}})^2 + (F_{y_{\\text{total}}})^2} = 14.1 \\, \\text{N}\n$$\n\nThe direction is given by the angle $$\\theta$$ with the positive x-axis:\n$$\n\\theta = \\tan^{-1} \\left( \\frac{F_{y_{\\text{total}}}}{F_{x_{\\text{total}}}} \\right) = \\tan^{-1}(1) = 45^\\circ\n$$\n\nThe magnitude and direction of the resultant force are **14.1 N** at **45° above the positive x-axis**"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1521,
        "content": [
          "20 N 45° above positive x-axis."
        ],
        "isCorrect": false
      },
      {
        "id": 1522,
        "content": [
          "14.1 N in the positive y-axis."
        ],
        "isCorrect": false
      },
      {
        "id": 1523,
        "content": [
          "20 N in the negative y-axis."
        ],
        "isCorrect": false
      },
      {
        "id": 1524,
        "content": [
          "14.1 N 45° above positive x-axis."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 382,
    "content": [
      "A student throws a ball vertically upward with a speed of 20 m/s. The maximum height reached by the ball and its velocity 3.0 s after it was thrown are, respectively"
    ],
    "explanation": [
      "The formula to calculate the maximum height is:\n$$\nv_f^2 = v_i^2 - 2gh\n$$\n\nSolving for h:\n$$\n0 = 20^2 - 2 \\times 10 \\times h\n$$\n$$\n400 = 20h\n$$\n$$\nh = 20 \\, \\text{m}\n$$\nFinding the velocity 3.0 seconds after the ball was thrown:\n$$\nv_f = v_i - gt\n$$\n$$\nv_f = 20 - 10 \\times 3 = -10 \\, \\text{m/s}\n$$\n\nThe negative sign indicates that the ball is moving downward after 3 seconds."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1525,
        "content": [
          "20 m and 30 m/s upward."
        ],
        "isCorrect": false
      },
      {
        "id": 1526,
        "content": [
          "15 m and 10 m/s downward."
        ],
        "isCorrect": false
      },
      {
        "id": 1527,
        "content": [
          "105 m and 50 m/s upward."
        ],
        "isCorrect": false
      },
      {
        "id": 1528,
        "content": [
          "20 m and 10 m/s downward."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 383,
    "content": [
      "Which one of the following statements describes the difference between different types of friction?"
    ],
    "explanation": [
      "Static friction acts on objects that are not moving. It increases with the applied force until it reaches a maximum value, known as the limiting friction, just before the object starts to slide."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1529,
        "content": [
          "For an object at rest on a horizontal surface, static friction increases with the increase of the applied force and reaches a maximum value just before sliding occurs."
        ],
        "isCorrect": true
      },
      {
        "id": 1530,
        "content": [
          "Limiting friction is the minimum value of static friction that keeps an object stationary."
        ],
        "isCorrect": false
      },
      {
        "id": 1531,
        "content": [
          "If there is a constant force applied to a stationary object on a horizontal surface, the static friction becomes equal to the limiting\nfriction."
        ],
        "isCorrect": false
      },
      {
        "id": 1532,
        "content": [
          "Limiting and kinetic frictions exist at the same time between two surfaces sliding over each other."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 384,
    "content": [
      "The apparent weight of a 60 kg student standing inside a lift is"
    ],
    "explanation": [
      "The apparent weight of a person in a lift is given by the formula:\n\n$$\nW_{\\text{apparent}} = m(g - a)\n$$\n\nWhere:\n\n- m is the mass of the person (60 kg),\n- g is the acceleration due to gravity ($$10 m/s^2$$),\n- a is the acceleration of the lift.\n\nWhen the lift accelerates downward with $$2 \\ \\text{m/s}^2$$:\n\n$$\nW_{\\text{apparent}} = 60 \\, \\text{kg} \\times (10 \\, \\text{m/s}^2 - 2 \\, \\text{m/s}^2) = 480 \\, \\text{N}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1533,
        "content": [
          "600N when the lift accelerates with acceleration equal to gravitational acceleration."
        ],
        "isCorrect": false
      },
      {
        "id": 1534,
        "content": [
          "600 N when the lift accelerates upward with $$2 m/s^2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1535,
        "content": [
          "480 N when the lift accelerates down ward with $$2 m/s^2$$."
        ],
        "isCorrect": true
      },
      {
        "id": 1536,
        "content": [
          "720 N when the lift is at rest."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 385,
    "content": [
      "Which of the following statements describe the use of energy resources?"
    ],
    "explanation": [
      "Photovoltaic cells convert sunlight directly into electricity without emitting greenhouse gases during operation, making it an environmentally friendly and cost-effective energy resource."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1537,
        "content": [
          "Solar energy produced by photovoltaic cells is free of greenhouse gases and has a very low running cost."
        ],
        "isCorrect": true
      },
      {
        "id": 1538,
        "content": [
          "Hydroelectric power generates a large amount of energy using small dam with little environmental impact and cheap initial cost of\nconstruction."
        ],
        "isCorrect": false
      },
      {
        "id": 1539,
        "content": [
          "Geothermal energy is the most accessible, environmental friendly and inexpensive source of energy."
        ],
        "isCorrect": false
      },
      {
        "id": 1540,
        "content": [
          "Wind energy, which is due to the pressure difference in space as the result of uneven sun heat, is a consistent and economical source of energy."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 386,
    "content": [
      "A student wants to raise an object of mass m through a height h using an inclined plane that makes an angle above the horizontal. If I is the length of the inclined surface, which one of the following is correct about the actual mechanical advantage (AMA) and ideal mechanical advantage (IMA) of the inclined plane?"
    ],
    "explanation": [
      "The **Ideal Mechanical Advantage (IMA)** of an inclined plane is given by the ratio of the length of the incline to the height it raises an object:\n$$\n\\frac{I}{h} = \\frac{1}{\\sin\\theta}\n$$\n\nSo, IMA is $$\\frac{1}{\\sin\\theta}$$, not $$\\frac{1}{\\cos\\theta}$$\n\nThe **Actual Mechanical Advantage (AMA)** is the actual force output to input, and in the absence of friction, AMA should equal IMA, meaning **AMA** is also $$\\frac{1}{\\sin\\theta}$$ without friction"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1541,
        "content": [
          "Neglecting friction, its AMA is 1/sin(θ)"
        ],
        "isCorrect": true
      },
      {
        "id": 1542,
        "content": [
          "Neglecting friction, its IMA is 1/cos(θ)."
        ],
        "isCorrect": false
      },
      {
        "id": 1543,
        "content": [
          "In the presence of friction, it's AMA is 1/sin(θ)."
        ],
        "isCorrect": false
      },
      {
        "id": 1544,
        "content": [
          "In the absence off friction, AMA is sin(θ) and its IMA is cos(θ)."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 387,
    "content": [
      "According to the law of floatation, an object must displaces a volume of fluid"
    ],
    "explanation": [
      "According to the law of floatation, an object floating in a fluid displaces a volume of the fluid such that the weight of the displaced fluid is equal to the weight of the object. This principle is derived from Archimedes' principle, which states that the buoyant force acting on the object is equal to the weight of the fluid displaced. Therefore, for an object to float, the weight of the displaced fluid must equal the weight of the object."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1545,
        "content": [
          "equal to the weight of undisplaced fluid."
        ],
        "isCorrect": false
      },
      {
        "id": 1546,
        "content": [
          "equal to its apparent weight."
        ],
        "isCorrect": false
      },
      {
        "id": 1547,
        "content": [
          "less than its own weight."
        ],
        "isCorrect": false
      },
      {
        "id": 1548,
        "content": [
          "equals to its own weight."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 388,
    "content": [
      "Which one of the following statements describes the unusual behavior of expansion of water?"
    ],
    "explanation": [
      "Water exhibits an unusual property where its density reaches a maximum at around 4°C. As water cools from 4°C to 0°C, it expands, which causes the density to decrease. This is due to the formation of an open hexagonal structure of hydrogen bonds in ice, which makes the molecules more spaced out, leading to a lower density at 0°C than at 4°C."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1549,
        "content": [
          "The density of water at 0°C is less than its density at 4°C, since water molecules move further apart, and form a second hydrogen bond with other water molecules."
        ],
        "isCorrect": true
      },
      {
        "id": 1550,
        "content": [
          "As a temperature of water increases above 4°C, its density increases since water molecules move further apart to form a second hydrogen bond with other molecules."
        ],
        "isCorrect": false
      },
      {
        "id": 1551,
        "content": [
          "At 0°C, water has larger density and smaller volume than its density and volume at 4°C."
        ],
        "isCorrect": false
      },
      {
        "id": 1552,
        "content": [
          "As a temperature of water increases from 0°C to 4°C, its density increases since one molecule of water forms one hydrogen bond with another molecule."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 389,
    "content": [
      "A 40 g of water at 50°C is poured into a well-insulated 30 g of copper calorimeter at 20°C. The temperature of water at equilibrium becomes ______________ ."
    ],
    "explanation": [
      "The heat transferred is given by:\n$$\nQ = mc\\Delta T\n$$\nThe heat lost by the water is:\n$$\nQ_{\\text{water}} = m_{\\text{water}} c_{\\text{water}} (T_{\\text{initial, water}} - T_f)\n$$\n$$\nQ_{\\text{water}} = 168 \\times (50 - T_f)\n$$\n\nThe heat gained by the copper is:\n$$\nQ_{\\text{copper}} = m_{\\text{copper}} c_{\\text{copper}} (T_f - T_{\\text{initial, copper}})\n$$\n$$\nQ_{\\text{copper}} = 11.7 \\times (T_f - 20)\n$$\n\nAt equilibrium, the heat lost by the water equals the heat gained by the copper:\n$$\nQ_{\\text{water}} = Q_{\\text{copper}}\n$$\n$$\n168 \\times (50 - T_f) = 11.7 \\times (T_f - 20)\n$$\n$$\nT_f = \\frac{8634}{179.7} \\approx 47.9°C\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1553,
        "content": [
          "52.4°C"
        ],
        "isCorrect": false
      },
      {
        "id": 1554,
        "content": [
          "47.9°C"
        ],
        "isCorrect": true
      },
      {
        "id": 1555,
        "content": [
          "35°C"
        ],
        "isCorrect": false
      },
      {
        "id": 1556,
        "content": [
          "30°C"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Heat Conduction and Calorimetry"
  },
  {
    "id": 390,
    "content": [
      "An FM radio signal is transmitted from a radio station at a frequency of $$1.5 \\times 10^8 Hz$$. If the wavelength of the radio wave is 2.00 m, the speed of the FM signal is"
    ],
    "explanation": [
      "To find the speed of the FM signal, we can use the formula for the speed of a wave:\n\n$$\nv = f \\lambda\n$$\n\nGiven:\n\n- Frequency f = $$1.5 \\times 10^8 \\ \\text{Hz}$$\n- Wavelength $$\\lambda = 2.00 \\ \\text{m}$$\n\n$$\nv = (1.5 \\times 10^8 \\ \\text{Hz}) \\times (2.00 \\ \\text{m})\n$$\n\n$$\nv = 3.00 \\times 10^8 \\ \\text{m/s}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_SOUND",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1557,
        "content": [
          "$$6.00 \\times 10^8 \\ \\text{m/s}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1558,
        "content": [
          "$$3  \\times 10^8 \\ \\text{m/s}$$."
        ],
        "isCorrect": true
      },
      {
        "id": 1559,
        "content": [
          "$$1.33  \\times 10^8 \\ \\text{m/s}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1560,
        "content": [
          "$$0.75  \\times 10^8 \\ \\text{m/s}$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Mechanical Oscillation and Sound Wave"
  },
  {
    "id": 391,
    "content": [
      "Which one of the following statements is correct about transformation of mechanical energy into other forms and the law of conservation of total energy?"
    ],
    "explanation": [
      "- **Dissipative Forces** are forces like friction that cause energy to be lost from the system, usually in the form of heat. When a wooden block slides on a rough surface, friction acts as a dissipative force, converting some of the mechanical energy into heat, thus the total mechanical energy is not conserved.\n- Mechanical energy (the sum of kinetic and potential energy) is conserved only in the absence of dissipative forces. In the presence of friction, mechanical energy is transformed into other forms of energy, such as thermal energy."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1561,
        "content": [
          "Due to dissipative force, the mechanical energy of a wooden block sliding on a rough horizontal surface is not conserved."
        ],
        "isCorrect": true
      },
      {
        "id": 1562,
        "content": [
          "Mechanical energy of a wooden block sliding on a rough horizontal surface is conserved."
        ],
        "isCorrect": false
      },
      {
        "id": 1563,
        "content": [
          "Neglecting air resistance, an object moving vertically downward gains potential energy and loses an equal amount of kinetic energy."
        ],
        "isCorrect": false
      },
      {
        "id": 1564,
        "content": [
          "Neglecting air resistance, an object moving vertically upward gains kinetic energy and loses an equal amount of gravitational potential energy."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 392,
    "content": [
      "A wheel rotating at angular speed of 20 rev/s is brought to rest after 40 rev under a constant angular acceleration. The angular acceleration of a point on the wheel is"
    ],
    "explanation": [
      "To find the angular acceleration, we can use the following kinematic equation for rotational motion:\n\n$$\n\\omega_f^2 = \\omega_i^2 + 2\\alpha\\theta\n$$\n\nPlugging in the values:\n\n$$\n0 = (20)^2 + 2\\alpha(40)\n$$\n\n$$\n0 = 400 + 80\\alpha\n$$\n\n$$\n\\alpha = -5 \\ \\text{rev/s}^2\n$$\n\nThe wheel's angular acceleration is negative because it is decelerating."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1565,
        "content": [
          "$$5 \\ rev/s^2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1566,
        "content": [
          "$$-0.5 \\ rev/s^2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1567,
        "content": [
          "$$-5 \\ rev/s^2$$."
        ],
        "isCorrect": true
      },
      {
        "id": 1568,
        "content": [
          "$$0.25 \\ rev/s^2$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 393,
    "content": [
      "The parallel axis theorem states that if $$I_{cm}$$ is the moment of inertia of a body of mass M about an axis passing through its center of mass (cm), its moment of inertia about any axis"
    ],
    "explanation": [
      "The parallel axis theorem states that the moment of inertia (I) of a body about any axis parallel to an axis through its center of mass (cm) is given by:\n\n$$\nI = I_{cm} + Md^2\n$$\n\nWhere:\n\n- $$I_{cm}$$ is the moment of inertia about the center of mass axis,\n- M is the mass of the body,\n- d is the distance between the two parallel axes.\n\nThis theorem is used to calculate the moment of inertia when the axis of rotation is shifted parallel to the axis through the center of mass."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1569,
        "content": [
          "perpendicular to and a displacement d from the axis through the cm is $$I = I_{cm}+ \\frac{1}{2}Md^2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1570,
        "content": [
          "parallel to and a displacement d from the axis through the cm is $$I = I_{cm} + Md^2$$."
        ],
        "isCorrect": true
      },
      {
        "id": 1571,
        "content": [
          "perpendicular to and a displacement d from the axis through the cm is $$I = I_{cm} + Md^2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1572,
        "content": [
          "parallel to and a displacement d from the axis through the cm is $$I=I_{cm}+ \\frac{1}{2}Md^2$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 394,
    "content": [
      "Three forces of equal magnitude are exerted at the center of a uniform beam of length L and negligible mass, as shown in the Figure.",
      "images/physics/year_2014/q44_1.png",
      "If $$\\vec{\\tau_A}$$, $$\\vec{\\tau_B}$$, and $$\\vec{\\tau_O}$$ are net torques on the beam about an axis parallel to the z-axis and passing through point A, B, and O, respectively, which one of the following expressions is correct?"
    ],
    "explanation": [
      "$$\\tau$$ about a point is calculated as:\n\n$$\n\\tau = r \\cdot F \\cdot \\sin(\\theta)\n$$\nTorque about Point A ($$\\vec{\\tau_A}$$):\n\n$$\n\\vec{\\tau_A}= (\\frac{L}{2} + d) F( \\sin{(30°)} + \\sin{(150°)} +  \\sin{(270°)})\n$$\n$$\n\\vec{\\tau_A} = (\\frac{L}{2} + d)  F \\cdot  (0.5 + 0.5 - 1) = 0\n$$\n\nTorque about Point B ($$\\vec{\\tau_B}$$):\n\n$$\n\\vec{\\tau_B}= \\frac{L}{2} F (\\sin{(30°)} + \\sin{(150°)} +  \\sin{(270°)})\n$$\n\n$$\n\\vec{\\tau_B} = \\frac{L}{2} F \\cdot  (0.5 + 0.5 - 1) = 0\n$$\n\nTorque about Point O ($$\\vec{\\tau_O}$$):\n\n$$\n\\vec{\\tau_O}= 0 \\cdot F(\\sin{(30°)} + \\sin{(150°)} +  \\sin{(270°)})\n$$\n\n$$\n\\vec{\\tau_O} = 0\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2014/q44_1.png"
    ],
    "choices": [
      {
        "id": 1573,
        "content": [
          "$$\\vec{\\tau_A}$$ = $$\\vec{\\tau_B}$$ = $$\\vec{\\tau_O}$$ = 0"
        ],
        "isCorrect": true
      },
      {
        "id": 1574,
        "content": [
          "$$\\vec{\\tau_A}$$ > $$\\vec{\\tau_B}$$ > $$\\vec{\\tau_O}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1575,
        "content": [
          "$$\\vec{\\tau_A}$$ < $$\\vec{\\tau_B}$$ < $$\\vec{\\tau_O}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1576,
        "content": [
          "$$\\vec{\\tau_O}$$ = 0, $$\\vec{\\tau_A}$$ > $$\\vec{\\tau_B}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 395,
    "content": [
      "Tensile stress is the"
    ],
    "explanation": [
      "**Tensile stress** is defined as the force exerted per unit area within materials, which causes them to elongate. It is specifically related to the perpendicular component of the applied force (tension) acting over the cross-sectional area of the material."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1577,
        "content": [
          "parallel component of the applied force divided by the cross sectional area of an object."
        ],
        "isCorrect": false
      },
      {
        "id": 1578,
        "content": [
          "ratio of change in length of an object to the original length."
        ],
        "isCorrect": false
      },
      {
        "id": 1579,
        "content": [
          "perpendicular component of the applied force divided by the cross sectional area of an object."
        ],
        "isCorrect": true
      },
      {
        "id": 1580,
        "content": [
          "ratio of original length to the change in length of the object."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 396,
    "content": [
      "A certain fluid has a density of $$1080 \\ kg/m^3$$ and is observed to rise to a height of 2.1 cm in a 1.0 mm diameter tube. If the contact angle between the wall and the surface is zero, the surface tension of the fluid is"
    ],
    "explanation": [
      "To find the surface tension of the fluid, we can use this formula:\n$$\nh = \\frac{2 \\gamma \\cos(\\theta)}{\\rho g r}\n$$\n\nGiven values:\n\n- $$\\rho$$ = $$1080 \\ kg/m^3$$\n- h = 2.1 cm = 0.021 m\n- d = 1.0 mm = 0.001 m, thus radius r = 0.0005 m\n- θ = 0 (cos(0) = 1))\n\nRearranging the formula for surface tension ($$\\gamma$$):\n$$\n\\gamma = \\frac{h \\rho g r}{2 \\cos(\\theta)}\n$$\n$$\n\\gamma \\approx 0.0567 \\, N/m\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_DENSITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1581,
        "content": [
          "5670 N/m."
        ],
        "isCorrect": false
      },
      {
        "id": 1582,
        "content": [
          "0.02835 N/m."
        ],
        "isCorrect": false
      },
      {
        "id": 1583,
        "content": [
          "0.1134 N/m,"
        ],
        "isCorrect": false
      },
      {
        "id": 1584,
        "content": [
          "0.0567 N/m."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 397,
    "content": [
      "A slab of thermal insulator has a cross-section of $$0.1 m^2$$, a length of 2 cm, and thermal conductivity of 0.1 J/(m.s °C). If the temperature difference between the opposite faces of the insulator is 100°C, the amount of heat flowing through the slab in 24 h is"
    ],
    "explanation": [
      "To calculate the amount of heat flowing through the thermal insulator slab, we can use Fourier's law of heat conduction, which is given by:\n\n$$\nQ = \\frac{k \\cdot A \\cdot \\Delta T}{L} \\cdot t\n$$\n\nGiven\n\n- k = $$0.1 \\ J/(m \\cdot s °C)$$\n- A = $$0.1 \\ \\text{m}^2$$\n- $$\\Delta T$$ = $$100 \\ \\text{°C}$$\n- L = 2 cm = 0.02 m\n- t = 24 h = 86400 s\n\n$$\nQ = \\frac{0.1 \\cdot 0.1 \\cdot 100}{0.02} \\cdot 86400\n$$\n$$\nQ = 4.32 \\times 10^6 \\ \\text{J}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1585,
        "content": [
          "$$1.2 \\times 10^3 \\ \\text{J}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1586,
        "content": [
          "$$4.32 \\times 10^6 \\ \\text{J}$$."
        ],
        "isCorrect": true
      },
      {
        "id": 1587,
        "content": [
          "$$7.2 \\times 10^4 \\ \\text{J}$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1588,
        "content": [
          "$$5.0 \\times 10^1 \\ \\text{J}$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Heat Conduction and Calorimetry"
  },
  {
    "id": 398,
    "content": [
      "A 100 J of work is done on a system and 418.6 J of heat is extracted from it. According to the first law of thermodynamics, the change in the internal energy of the system is"
    ],
    "explanation": [
      "Using the first law of thermodynamics, we use the equation:\n$$\n\\Delta U = Q + W\n$$\n\nIn this case:\n\n- Work done on the system,W = 100 J\n- Heat extracted from the system Q = -418.6 J\n\n$$\n\\Delta U = -418.6 \\, \\text{J} + 100 \\, \\text{J} = -318.6 \\, \\text{J}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1589,
        "content": [
          "-518.6 J."
        ],
        "isCorrect": false
      },
      {
        "id": 1590,
        "content": [
          "-318.6 J."
        ],
        "isCorrect": true
      },
      {
        "id": 1591,
        "content": [
          "318.6 J."
        ],
        "isCorrect": false
      },
      {
        "id": 1592,
        "content": [
          "518.6 J."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 399,
    "content": [
      "Which of the following statements describe the difference between reversible and irreversible processes?"
    ],
    "explanation": [
      "In a reversible process, the system is always infinitesimally close to equilibrium, allowing it to reverse direction without any net change in entropy. In contrast, an irreversible process involves deviations from equilibrium, leading to entropy production."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1593,
        "content": [
          "In an irreversible process, a system\ncan move from one thermodynamic state to another and back to its initial state; whereas a system in a reversible process cannot move back to its initial state."
        ],
        "isCorrect": false
      },
      {
        "id": 1594,
        "content": [
          "A system undergoing reversible process is always close to thermodynamic equilibrium, whereas a system undergoing irreversible process is not in thermal equilibrium."
        ],
        "isCorrect": true
      },
      {
        "id": 1595,
        "content": [
          "Ice at 0°C placed in a metallic can at 40°C undergoes a reversible process; whereas ice at 0°C placed in a metal can at 0°C undergoes an irreversible process."
        ],
        "isCorrect": false
      },
      {
        "id": 1596,
        "content": [
          "A process is reversible if its entropy increases, but irreversible if its entropy is constant."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 400,
    "content": [
      "Which one of the following statements is correct about resonance in an oscillating object?"
    ],
    "explanation": [
      "Resonance occurs when an oscillating system is driven by an external force at a frequency that matches the system's natural frequency. When this happens, the system absorbs energy most efficiently, causing the amplitude of the oscillations to increase significantly. This is why at resonance, the amplitude becomes maximum."
    ],
    "year": "YEAR_2014",
    "subject": "PHYSICS",
    "chapter": "PHY_OPTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1597,
        "content": [
          "At resonance, the driving frequency is equal to the natural frequency and the amplitude becomes maximum."
        ],
        "isCorrect": true
      },
      {
        "id": 1598,
        "content": [
          "Dumping increases the amplitude and natural frequency of the oscillator."
        ],
        "isCorrect": false
      },
      {
        "id": 1599,
        "content": [
          "Resonance occurs when the frequency of a periodic driving force is greater than the natural frequency of the oscillator."
        ],
        "isCorrect": false
      },
      {
        "id": 1600,
        "content": [
          "Resonance occurs when the oscillator is subject to a constant driving force."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Electromagnetic Waves and Geometrical Optics"
  },
  {
    "id": 886,
    "content": [
      "Lenz's law states that the direction of the induced current in a loop is in such a way that the current"
    ],
    "explanation": [
      "According to Lenz's law, the direction of the induced current in a loop creates a magnetic field that opposes the change in magnetic flux that induced the current."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3544,
        "content": [
          "is in opposite direction to that of the applied magnetic field that is causing it."
        ],
        "isCorrect": false
      },
      {
        "id": 3545,
        "content": [
          "creates a magnetic field that reinforces the change in magnetic flux through the loop."
        ],
        "isCorrect": false
      },
      {
        "id": 3546,
        "content": [
          "is in the same direction as that of the applied magnetic field that is causing it."
        ],
        "isCorrect": false
      },
      {
        "id": 3547,
        "content": [
          "creates a magnetic field that opposes the change in magnetic flux through the loop."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 887,
    "content": [
      "Which one of the following statements is correct about the resistance of a conducting wire? The resistance of the wire is"
    ],
    "explanation": [
      "The resistance $$R$$ of a wire is inversely proportional to its cross-sectional area $$A$$.\n\nThis is because a larger cross-sectional area provides more space for electrons to flow, reducing resistance. This relationship is expressed by the formula: $$R = \\rho \\frac{L}{A}$$, where $$\\rho$$ is the resistivity, $$L$$ is the length, and $$A$$ is the cross-sectional area."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3548,
        "content": [
          "directly proportional to the square of its length."
        ],
        "isCorrect": false
      },
      {
        "id": 3549,
        "content": [
          "directly proportional to the square of its cross-sectional area."
        ],
        "isCorrect": false
      },
      {
        "id": 3550,
        "content": [
          "inversely proportional to its cross-sectional area."
        ],
        "isCorrect": true
      },
      {
        "id": 3551,
        "content": [
          "inversely proportional to its length."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 888,
    "content": [
      "Consider an ideal transformer having $$N_p$$ and $$N_s$$ turns, and voltages $$V_p$$ and $$V_s$$ in its primary and secondary coils, respectively. Which one of the following is the correct ideal transformer equation?"
    ],
    "explanation": [
      "The ideal transformer equation relates the voltages and number of turns in the primary and secondary coils.\n\nThe correct relationship is $$\\frac{V_s}{V_p} = \\frac{N_s}{N_p}$$, which shows that the ratio of the secondary voltage to the primary voltage is equal to the ratio of the number of turns in the secondary coil to the number of turns in the primary coil."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3552,
        "content": [
          "$$V_p = (\\frac{N_s}{N_p})^2 V_s$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3553,
        "content": [
          "$$\\frac{V_s}{V_p} = \\frac{N_s}{N_p}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3554,
        "content": [
          "$$\\frac{N_s}{N_p} = (\\frac{V_s}{V_p})^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3555,
        "content": [
          "$$\\frac{V_s}{V_p} = \\frac{N_p}{N_s}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 889,
    "content": [
      "Which one of the following statements is correct about the electrical conductivity of materials? Materials in which all the"
    ],
    "explanation": [
      "Insulators are materials where electrons, both inner and outermost, are tightly bound to their parent atoms. This tight binding restricts the movement of electrons, making it difficult for electric current to flow."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3556,
        "content": [
          "outer most shell electrons are free to move within the material are semiconductors."
        ],
        "isCorrect": false
      },
      {
        "id": 3557,
        "content": [
          "outer most shell electrons are tightly bound to its parent atom are conductors."
        ],
        "isCorrect": false
      },
      {
        "id": 3558,
        "content": [
          "inner and outer most shell electrons are tightly bound to its parent atom are insulators."
        ],
        "isCorrect": true
      },
      {
        "id": 3559,
        "content": [
          "inner and outer most shell electrons are free to move within the material are conductors."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Magnetism"
  },
  {
    "id": 890,
    "content": [
      "Which one of the following statements distinguishes precision from accuracy?"
    ],
    "explanation": [
      "Precision refers to how close repeated measurements are to each other. Accuracy refers to how close a measured value is to the true or accepted value."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3560,
        "content": [
          "Accuracy measures how exact a value is whereas precision indicates how close a measured value is to the true value."
        ],
        "isCorrect": false
      },
      {
        "id": 3561,
        "content": [
          "Precision indicates how close a measured value is to the true value, whereas accuracy refers to the closeness of repeatedly measured values to each other."
        ],
        "isCorrect": false
      },
      {
        "id": 3562,
        "content": [
          "Precision is a measure of the closeness of repeatedly measured values to each other, whereas accuracy refers to the closeness of measured values to the true value."
        ],
        "isCorrect": true
      },
      {
        "id": 3563,
        "content": [
          "Precision is a measure of the closeness of repeatedly measured values to each other, whereas accuracy is related to the number of significant figures."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 891,
    "content": [
      "Which of the following statements about the nature electromagnetic waves is correct? Electromagnetic waves are transverse waves produced when"
    ],
    "explanation": [
      "Electromagnetic waves are transverse waves produced when electric and magnetic fields are oscillating perpendicular to each other. The oscillating electric field produces an oscillating magnetic field, and vice versa, which propagates as a wave."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3564,
        "content": [
          "charges are placed at rest in an electric and magnetic fields that are perpendicular to each other."
        ],
        "isCorrect": false
      },
      {
        "id": 3565,
        "content": [
          "electric and magnetic fields are oscillating perpendicular to each other."
        ],
        "isCorrect": true
      },
      {
        "id": 3566,
        "content": [
          "charges are placed at rest in an electric and magnetic fields that are parallel to each other."
        ],
        "isCorrect": false
      },
      {
        "id": 3567,
        "content": [
          "electric and magnetic fields are oscillating parallel to each other."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 892,
    "content": [
      "Three resistors are connected between points a and b as shown in the figure below.",
      "images/physics/year_2016/q7_1.png",
      "The effective resistance of the circuit is"
    ],
    "explanation": [
      "We are given a circuit with three resistors connected in parallel between points 'a' and 'b'. (3 kΩ, 6 kΩ, and 2 kΩ). For resistors connected in parallel, the reciprocal of the equivalent resistance ($$R_{eq}$$) is the sum of the reciprocals of the individual resistances:\n\n$$\n\\frac{1}{R_{eq}} = \\frac{1}{R_1} + \\frac{1}{R_2} + \\frac{1}{R_3}\n$$\n\nSubstituting the given values:\n\n$$\\frac{1}{R_{eq}}$$ = $$\\frac{1}{3 \\, \\text{k}}$$ + $$\\frac{1}{6 \\, \\text{k}}$$ + $$\\frac{1}{2 \\, \\text{k}}$$\n\n$$R_{eq}$$ = 1 kΩ"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2016/q7_1.png"
    ],
    "choices": [
      {
        "id": 3568,
        "content": [
          "11.0 Ω."
        ],
        "isCorrect": false
      },
      {
        "id": 3569,
        "content": [
          "1.0 Ω."
        ],
        "isCorrect": false
      },
      {
        "id": 3570,
        "content": [
          "11.0 kΩ."
        ],
        "isCorrect": false
      },
      {
        "id": 3571,
        "content": [
          "1.0 kΩ."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 893,
    "content": [
      "A concave mirror has a radius of curvature of 30.0 cm. It is positioned so that the upright image of an object is 2.0 times the size of the object. How far is the object from the mirror?"
    ],
    "explanation": [
      "Using R=30.0 cm, the focal length is\n$$\nf=\\frac R2=15.0\\rm\\ cm\n$$\nFor an upright (virtual) image of magnification m = +2\n$$\nm=-\\frac{d_i}{d_o}=2\\;\\Longrightarrow\\;d_i=-2\\,d_o\n$$\nThe mirror equation gives\n$$\n\\frac1f=\\frac1{d_o}+\\frac1{d_i}\n$$\n$$\n=\\frac1{d_o}-\\frac1{2d_o}\n$$\n$$\n=\\frac{1/2}{d_o}\n$$\n$$\nd_o=\\frac{f}{2}=\\frac{15.0}{2}=7.5\\rm\\ cm\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_OPTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3572,
        "content": [
          "15.0 cm"
        ],
        "isCorrect": false
      },
      {
        "id": 3573,
        "content": [
          "10.0 cm"
        ],
        "isCorrect": false
      },
      {
        "id": 3574,
        "content": [
          "7.5 cm"
        ],
        "isCorrect": true
      },
      {
        "id": 3575,
        "content": [
          "22.5 cm"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Electromagnetic Waves and Geometrical Optics"
  },
  {
    "id": 894,
    "content": [
      "In an experiment to determine the direction of the magnetic field around a long straight current-carrying wire, a student placed a small compass at point P, as shown in the diagram.",
      "images/physics/year_2016/q9_1.png",
      "If the direction of the current in the wire is directed out-of the page, then the magnetic needle of the compass will point"
    ],
    "explanation": [
      "By the right‐hand rule (thumb pointing out of the page), the magnetic field circles counterclockwise.  At point P (to the left of the wire), the field is directed downward, so the compass needle points downward."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2016/q9_1.png"
    ],
    "choices": [
      {
        "id": 3576,
        "content": [
          "downward."
        ],
        "isCorrect": true
      },
      {
        "id": 3577,
        "content": [
          "to the right."
        ],
        "isCorrect": false
      },
      {
        "id": 3578,
        "content": [
          "upward."
        ],
        "isCorrect": false
      },
      {
        "id": 3579,
        "content": [
          "to the left."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 895,
    "content": [
      "A combination of logic gate is constructed from an NAND gate and an OR gate, as shown in the diagram below.",
      "images/physics/year_2016/q10_1.png",
      "The truth table for the logic circuit shown above is"
    ],
    "explanation": [
      "First, we have a NAND gate with inputs P and Q. The output of the NAND gate is $$\\overline{P \\cdot Q}$$.\n\nThen, this output is fed into an OR gate, along with the input Q. The output of the OR gate is $$\\overline{P \\cdot Q} + Q$$.\n\nLet's evaluate this for each possible input:\n\n- If P = 0 and Q = 0: $$\\overline{0 \\cdot 0} + 0 = \\overline{0} + 0 = 1 + 0 = 1$$\n- If P = 0 and Q = 1: $$\\overline{0 \\cdot 1} + 1 = \\overline{0} + 1 = 1 + 1 = 1$$\n- If P = 1 and Q = 0: $$\\overline{1 \\cdot 0} + 0 = \\overline{0} + 0 = 1 + 0 = 1$$\n- If P = 1 and Q = 1: $$\\overline{1 \\cdot 1} + 1 = \\overline{1} + 1 = 0 + 1 = 1$$\n\nThe correct truth table is:\n\n| P | Q | Output |\n| --- | --- | --- |\n| 0 | 0 | 1 |\n| 0 | 1 | 1 |\n| 1 | 0 | 1 |\n| 1 | 1 | 1 |"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2016/q10_1.png"
    ],
    "choices": [
      {
        "id": 3580,
        "content": [
          "| P | Q | Output |\n| --- | --- | --- |\n| 0 | 0 | 0 |\n| 0 | 1 | 0 |\n| 1 | 0 | 0 |\n| 1 | 1 | 0 |"
        ],
        "isCorrect": false
      },
      {
        "id": 3581,
        "content": [
          "| P | Q | Output |\n| --- | --- | --- |\n| 0 | 0 | 0 |\n| 0 | 1 | 1 |\n| 1 | 0 | 1 |\n| 1 | 1 | 0 |"
        ],
        "isCorrect": false
      },
      {
        "id": 3582,
        "content": [
          "| P | Q | Output |\n| --- | --- | --- |\n| 0 | 0 | 1 |\n| 0 | 1 | 0 |\n| 1 | 0 | 0 |\n| 1 | 1 | 1 |"
        ],
        "isCorrect": false
      },
      {
        "id": 3583,
        "content": [
          "| P | Q | Output |\n| --- | --- | --- |\n| 0 | 0 | 1 |\n| 0 | 1 | 1 |\n| 1 | 0 | 1 |\n| 1 | 1 | 1 |"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Magnetism"
  },
  {
    "id": 896,
    "content": [
      "When a force F is applied to a wire of length L fixed at one end, the wire extends by x. The tensile strain of the wire is"
    ],
    "explanation": [
      "Tensile strain is defined as the change in length divided by the original length. Given that the wire extends by $$x$$ and has an original length of $$L$$, the tensile strain is $$x/L$$."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_FORCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3584,
        "content": [
          "the applied force F divided by the extension."
        ],
        "isCorrect": false
      },
      {
        "id": 3585,
        "content": [
          "the product of the force F and the extension x."
        ],
        "isCorrect": false
      },
      {
        "id": 3586,
        "content": [
          "the extension x divided by the length L."
        ],
        "isCorrect": true
      },
      {
        "id": 3587,
        "content": [
          "the length L divided by the extension x."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 897,
    "content": [
      "Which one of the following factors does NOT affect the moment of inertia of an object?"
    ],
    "explanation": [
      "The moment of inertia of an object depends on its mass, the axis of rotation, and its size/shape. It does not depend on the angular speed of the object. The moment of inertia ($$I$$) is related to the mass distribution around the axis of rotation; therefore, angular speed does not influence it.\n$$\nI = mr^2\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3588,
        "content": [
          "The angular speed of the object"
        ],
        "isCorrect": true
      },
      {
        "id": 3589,
        "content": [
          "The mass of the object"
        ],
        "isCorrect": false
      },
      {
        "id": 3590,
        "content": [
          "The axis about which the object is rotating"
        ],
        "isCorrect": false
      },
      {
        "id": 3591,
        "content": [
          "The size of the object"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 898,
    "content": [
      "Which of the following describes the difference between static and dynamic equilibrium? In static equilibrium,"
    ],
    "explanation": [
      "In static equilibrium, an object is at rest, meaning it has zero velocity and zero acceleration. In dynamic equilibrium, an object is in motion but with constant velocity, meaning it has zero acceleration."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3592,
        "content": [
          "acceleration is zero, whereas in dynamic equilibrium the acceleration increases uniformly."
        ],
        "isCorrect": false
      },
      {
        "id": 3593,
        "content": [
          "an object moves with constant velocity, whereas in dynamic equilibrium, an object is at rest."
        ],
        "isCorrect": false
      },
      {
        "id": 3594,
        "content": [
          "an object is at rest, whereas in dynamic equilibrium, the object moves with constant velocity."
        ],
        "isCorrect": true
      },
      {
        "id": 3595,
        "content": [
          "an object moves with constant acceleration, whereas in dynamic equilibrium, the object is at rest."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 899,
    "content": [
      "About an axis of rotation perpendicular to a plane of a couple, the forces in a couple produce"
    ],
    "explanation": [
      "A couple consists of two equal and opposite forces acting on a body but not along the same line. These forces produce torques in the same direction about any axis perpendicular to the plane containing the forces."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_FORCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3596,
        "content": [
          "torques in opposite direction."
        ],
        "isCorrect": false
      },
      {
        "id": 3597,
        "content": [
          "torques in the same direction."
        ],
        "isCorrect": true
      },
      {
        "id": 3598,
        "content": [
          "no torque."
        ],
        "isCorrect": false
      },
      {
        "id": 3599,
        "content": [
          "non-zero resultant force."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Elasticity and Static Equilibrium and Rigid Body"
  },
  {
    "id": 900,
    "content": [
      "Which one of the following statements describes the difference between heat and temperature?"
    ],
    "explanation": [
      "Heat is the transfer of energy due to a temperature difference between two systems or objects. Temperature, on the other hand, is a measure of the average kinetic energy of the particles within a substance."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3600,
        "content": [
          "Heat is a measure of the average kinetic energy, whereas temperature is a flow of energy from hotter to colder object."
        ],
        "isCorrect": false
      },
      {
        "id": 3601,
        "content": [
          "Heat is an energy that flows spontaneously from colder to hotter object, whereas temperature is the degree of hotness and coldness."
        ],
        "isCorrect": false
      },
      {
        "id": 3602,
        "content": [
          "Heat is a transfer of energy due to temperature difference, whereas temperature is a measure of the average kinetic energy."
        ],
        "isCorrect": true
      },
      {
        "id": 3603,
        "content": [
          "Heat is measured with a thermometer in Kelvin, whereas temperature is measured with a Calorimeter in Joule."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 901,
    "content": [
      "Which one of the following statements does NOT describe the relationship of physics with biology?"
    ],
    "explanation": [
      "While physics deals with the interactions of large numbers of particles, biology is more focused on the study of living organisms, their functions, and processes. The relationship between the two involves specific applications rather than a general concern with the interaction of large numbers of particles as a primary focus."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3604,
        "content": [
          "Both physics and biology are mainly concerned in the interaction of large number of particles."
        ],
        "isCorrect": true
      },
      {
        "id": 3605,
        "content": [
          "Newtonian mechanics and biology are used to explain why cheetah is fastest animal."
        ],
        "isCorrect": false
      },
      {
        "id": 3606,
        "content": [
          "Physics and biology are interrelated to each other in the study of vision and color detection."
        ],
        "isCorrect": false
      },
      {
        "id": 3607,
        "content": [
          "Physics and biology used to study how air vibrates in vocal cords."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 902,
    "content": [
      "Which one of the following is a correct relation of physics with medicine?"
    ],
    "explanation": [
      "Medical physics is a discipline that applies the principles of physics to medicine. It involves the use of physics concepts and techniques in medical diagnosis, treatment, and research."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3608,
        "content": [
          "Physics is a branch of medicine that sets standards during medical diagnosis."
        ],
        "isCorrect": false
      },
      {
        "id": 3609,
        "content": [
          "A discipline called medical physics deals with principles of physics in medical diagnosis."
        ],
        "isCorrect": true
      },
      {
        "id": 3610,
        "content": [
          "Modern medical imaging instrument are developed with knowledge of medicine and later used by physics."
        ],
        "isCorrect": false
      },
      {
        "id": 3611,
        "content": [
          "Medicine is a branch of physics dealing with nuclear reaction."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 903,
    "content": [
      "A ball is released from a height h. It then rises to a maximum height of $$\\frac{1}{2}h$$ after collision with the ground. Neglecting air resistance, which one of the following statements is correct about the ball's mechanical energy?"
    ],
    "explanation": [
      "Since the ball rises to only $$\\frac{1}{2}h$$ after the collision, some of its mechanical energy is lost during the impact with the ground. This could be due to factors like heat, sound, or deformation of the ball or the ground. Therefore, the mechanical energy after the collision is less than the mechanical energy before the collision."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3612,
        "content": [
          "Mechanical energy after collision is greater than mechanical energy before collision."
        ],
        "isCorrect": false
      },
      {
        "id": 3613,
        "content": [
          "Mechanical energy before collision is equal to after collision."
        ],
        "isCorrect": false
      },
      {
        "id": 3614,
        "content": [
          "Mechanical energy after collision is less than mechanical energy before collision."
        ],
        "isCorrect": true
      },
      {
        "id": 3615,
        "content": [
          "Mechanical energy of the ball increases while moving downward, but decreases while moving upward."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 904,
    "content": [
      "A glass tube of radius 30 mm is inserted in a bowl which contains methyl iodide of density 2.28 kg/m³. If the contact angle of the methyl iodide in the tube is 30⁰ and the surface tension is 0.26 N/m, how much height does the methyl iodide rises through the tube?"
    ],
    "explanation": [
      "Using the capillary‐rise formula for a fluid wetting the tube (contact angle < 90°)\n$$\nh=\\frac{2\\,\\gamma\\cos\\theta}{\\rho\\,g\\,r}\n$$\nWith\n- $$\\gamma=0.26\\rm\\ N/m$$\n- $$\\theta=30°$$ $$\\implies$$ $$\\cos\\theta$$ = $$\\tfrac{\\sqrt3}{2}\\approx0.866$$\n- $$\\rho=2.28\\rm\\ kg/m^3$$\n- $$g=9.81\\rm\\ m/s^2$$\n- $$r=30\\rm\\ mm=0.03\\ m$$\n\n$$\nh =\\frac{2(0.26)(0.866)}{(2.28)(9.81)(0.03)} \\approx0.66\\rm\\ m\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3616,
        "content": [
          "6.6 m"
        ],
        "isCorrect": false
      },
      {
        "id": 3617,
        "content": [
          "0.066 m"
        ],
        "isCorrect": false
      },
      {
        "id": 3618,
        "content": [
          "0.52 m"
        ],
        "isCorrect": false
      },
      {
        "id": 3619,
        "content": [
          "0.66 m"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 905,
    "content": [
      "Two rods, one made of brass and the other made of copper, are joined end to end. The length of the brass section is 0.2 m and the length of the copper section is 0.8 m. Each segment has cross-sectional area 0.005 $$m^2$$. The free end of the brass segment is kept at $$100^\\circ C$$ and the free end of the copper segment is kept at $$0^\\circ C$$. If the rate of heat flow is the same through both rods, what is the temperature of a point where the two segments are joined? ($$k_{cu} = 385 W/m.K$$, $$k_{br} = 109 W/m.K$$)"
    ],
    "explanation": [
      "Let $$T$$ be the temperature at the junction.\n\nThe rate of heat flow ($$Q$$) through a rod is given by:\n$$\nQ = \\frac{kA(T_H - T_C)}{L}\n$$\nwhere:\n- $$k$$ is the thermal conductivity,\n- $$A$$ is the cross-sectional area,\n- $$T_H$$ is the hot temperature,\n- $$T_C$$ is the cold temperature,\n- $$L$$ is the length.\n\nFor the brass rod:\n$$\nQ_{br} = \\frac{k_{br}A(100 - T)}{L_{br}} = \\frac{109A(100 - T)}{0.2}\n$$\n\nFor the copper rod:\n$$\nQ_{cu} = \\frac{k_{cu}A(T - 0)}{L_{cu}} = \\frac{385A(T)}{0.8}\n$$\n\nSince the rate of heat flow is the same through both rods, $$Q_{br} = Q_{cu}$$. Therefore:\n$$\n\\frac{109A(100 - T)}{0.2} = \\frac{385A(T)}{0.8}\n$$\nThe cross-sectional area $$A$$ cancels out:\n$$\n\\frac{109(100 - T)}{0.2} = \\frac{385T}{0.8}\n$$\n\n$$\n\\frac{109(100 - T)}{0.2} = \\frac{385T}{0.8}\n$$\n\n$$\n109(100 - T) \\times 0.8 = 385T \\times 0.2\n$$\n\n$$\nT = \\frac{43600}{821} \\approx 53^\\circ C\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3620,
        "content": [
          "$$100^\\circ C$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3621,
        "content": [
          "$$53^\\circ C$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3622,
        "content": [
          "$$50^\\circ C$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3623,
        "content": [
          "$$10.2^\\circ C$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Heat Conduction and Calorimetry"
  },
  {
    "id": 906,
    "content": [
      "A pressure applied to one point in an enclosed incompressible fluid is transmitted to all parts of the fluid without reducing in value. This is the principle of"
    ],
    "explanation": [
      "Pascal's principle states that pressure applied to an enclosed fluid is transmitted undiminished to every portion of the fluid and to the walls of the containing vessel."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3624,
        "content": [
          "Archimedes."
        ],
        "isCorrect": false
      },
      {
        "id": 3625,
        "content": [
          "Pascal."
        ],
        "isCorrect": true
      },
      {
        "id": 3626,
        "content": [
          "Continuity."
        ],
        "isCorrect": false
      },
      {
        "id": 3627,
        "content": [
          "Bernoulli."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 907,
    "content": [
      "Which of the following statement describes uniform motion?"
    ],
    "explanation": [
      "Uniform motion is defined as motion with constant speed in a straight line. An object moving with constant speed in a straight line maintains the same velocity over time, which is the definition of uniform motion."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3628,
        "content": [
          "An object moving at 30 m/s toward East and then 30 m/s toward North"
        ],
        "isCorrect": false
      },
      {
        "id": 3629,
        "content": [
          "An object moving around a circular track with constant speed of 30 m/s"
        ],
        "isCorrect": false
      },
      {
        "id": 3630,
        "content": [
          "An object moving with constant speed of 30 m/s in a straight line"
        ],
        "isCorrect": true
      },
      {
        "id": 3631,
        "content": [
          "An object, starting from rest, moving, on a straight line to attain a velocity of 30 m/s"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 908,
    "content": [
      "Which of the following statement describes inertia of an object? It"
    ],
    "explanation": [
      "Inertia is the tendency of an object to resist changes in its state of motion. The inertia of an object increases with increasing mass. A more massive object has a greater resistance to changes in its velocity."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3632,
        "content": [
          "increases with increasing mass of the object."
        ],
        "isCorrect": true
      },
      {
        "id": 3633,
        "content": [
          "increases with an increasing velocity of the object."
        ],
        "isCorrect": false
      },
      {
        "id": 3634,
        "content": [
          "makes to change state of rest of the object."
        ],
        "isCorrect": false
      },
      {
        "id": 3635,
        "content": [
          "is a physical quantity which has a unit of mass."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 909,
    "content": [
      "Two objects, object A of mass $$m$$ and object B of mass $$2m$$ are placed at heights of $$h_1$$ and $$h_2$$, respectively, from the surface of the earth. Assuming that the gravitational field strength is constant, the potential energy of object A is twice of that of object B, if"
    ],
    "explanation": [
      "The gravitational potential energy (PE) of an object is given by $$PE = mgh$$, where $$m$$ is the mass, $$g$$ is the gravitational field strength, and $$h$$ is the height.\n- For object A, $$PE_A = mgh_1$$.\n- For object B, $$PE_B = (2m)gh_2$$.\n\nGiven that $$PE_A = 2PE_B$$, we have:\n$$\nmgh_1 = 2(2mgh_2)\n$$\n$$\nmgh_1 = 4mgh_2\n$$\n$$\nh_1 = 4h_2\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3636,
        "content": [
          "$$h_1 = \\frac{1}{2}h_2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 3637,
        "content": [
          "$$h_1 = 2h_2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 3638,
        "content": [
          "$$h_1 = \\frac{1}{4}h_2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 3639,
        "content": [
          "$$h_1 = 4h_2$$."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 910,
    "content": [
      "A car travels 60 m north and then 80 m west. What is the magnitude of the resultant displacement of the car from its starting point?"
    ],
    "explanation": [
      "The car's displacement can be found using the Pythagorean theorem, as the north and west movements are perpendicular to each other.\n$$\nd = \\sqrt{(60)^2 + (80)^2}\n$$\n$$\nd = \\sqrt{10000}\n$$\n$$\nd = 100 \\, m\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3640,
        "content": [
          "100 m"
        ],
        "isCorrect": true
      },
      {
        "id": 3641,
        "content": [
          "140 m"
        ],
        "isCorrect": false
      },
      {
        "id": 3642,
        "content": [
          "20 m"
        ],
        "isCorrect": false
      },
      {
        "id": 3643,
        "content": [
          "4800 m"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 911,
    "content": [
      "The velocity-time graph of an object moving along a straight line toward east is described by the figure shown below.",
      "images/physics/year_2016/q26_1.png",
      "What is the total displacement moved by the object?"
    ],
    "explanation": [
      "The total displacement is the area under the velocity-time graph. The graph can be divided into two sections: a rectangle from 0 to 15 seconds and a triangle from 15 to 20 seconds.\n\nArea of rectangle (0 to 15 s):\n$$\nA_1 = v \\times t\n$$\n$$\nA_1 = 30 \\frac{m}{s} \\times 15 s = 450 \\, m\n$$\nArea of triangle (15 to 20 s):\n$$\nA_2 = \\frac{1}{2} \\times base \\times height\n$$\n$$\nA_2 = \\frac{1}{2} \\times (20 - 15) s \\times 30 \\frac{m}{s} = 75 \\, m\n$$\nTotal displacement:\n$$\nD_{total} = A_1 + A_2 = 450 \\, m + 75 \\, m = 525 \\, m\n$$\nThe total displacement moved by the object is 525 m East."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2016/q26_1.png"
    ],
    "choices": [
      {
        "id": 3644,
        "content": [
          "450 m East"
        ],
        "isCorrect": false
      },
      {
        "id": 3645,
        "content": [
          "375 m East"
        ],
        "isCorrect": false
      },
      {
        "id": 3646,
        "content": [
          "525 m East"
        ],
        "isCorrect": true
      },
      {
        "id": 3647,
        "content": [
          "600 m East"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 912,
    "content": [
      "A person of mass 75 kg experiences a net force of 400 N when placed in an upward accelerating lift. What is its apparent weight?"
    ],
    "explanation": [
      "The net force is given by $$F_{net}$$ = $$F_{app} - W$$, where $$F_{app}$$ is the apparent weight and $$W$$ is the actual weight.\n\nThe actual weight is $$W$$ = $$mg$$ = $$75 kg \\times 10 m/s^2$$ = $$750 N$$.\n\nGiven the net force $$F_{net}$$ = $$400 N$$, we have:\n$$\n400 N = F_{app} - 750 N\n$$\n$$\nF_{app} = 400 N + 750 N = 1150 N\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_FORCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3648,
        "content": [
          "350 N"
        ],
        "isCorrect": false
      },
      {
        "id": 3649,
        "content": [
          "1150 N"
        ],
        "isCorrect": true
      },
      {
        "id": 3650,
        "content": [
          "400 N"
        ],
        "isCorrect": false
      },
      {
        "id": 3651,
        "content": [
          "750 N"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 913,
    "content": [
      "A block of mass 20 kg is pushed horizontally, at constant speed, along a rough horizontal floor over a distance of 5 m. If coefficient of kinetic friction between the block and the surface is 0.4, what is the amount of work done by friction?"
    ],
    "explanation": [
      "The friction force is $$F_f$$ = $$\\mu_k N$$, where $$\\mu_k$$ is the coefficient of kinetic friction and $$N$$ is the normal force. Since the block is on a horizontal surface, $$N$$ = $$mg$$. Thus, $$F_f$$ = $$\\mu_k mg$$ = $$0.4 \\times 20 kg \\times 10 m/s^2$$ = $$80 N$$.\n\nThe work done by friction is $$W$$ = $$-F_f d$$, where $$d$$ is the distance. Since friction opposes the motion, the work is negative.\n$$\nW = -80 N \\times 5 m = -400 J\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3652,
        "content": [
          "-1000 J"
        ],
        "isCorrect": false
      },
      {
        "id": 3653,
        "content": [
          "-100 J"
        ],
        "isCorrect": false
      },
      {
        "id": 3654,
        "content": [
          "-40 J"
        ],
        "isCorrect": false
      },
      {
        "id": 3655,
        "content": [
          "-400 J"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 914,
    "content": [
      "A 200N force is required to be applied at one end of a 1m long lever, 80cm from its fulcrum, in order to lift a load of 600N placed at the other end as shown the figure below.",
      "images/physics/year_2016/q29_1.png",
      "What is the efficiency of the lever?"
    ],
    "explanation": [
      "The efficiency of a lever is given by:\n$$\n\\text{Efficiency} = \\frac{\\text{Mechanical Advantage (MA)}}{\\text{Velocity Ratio (VR)}} \\times 100\\%\n$$\nThe mechanical advantage is:\n$$\nMA = \\frac{Load}{Effort} = \\frac{600 N}{200 N} = 3\n$$\nThe velocity ratio is:\n$$\nVR = \\frac{\\text{Effort arm}}{\\text{Load arm}} = \\frac{80 cm}{20 cm} = 4\n$$\nEfficiency:\n$$\n\\text{Efficiency} = \\frac{3}{4} \\times 100\\% = 75\\%\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2016/q29_1.png"
    ],
    "choices": [
      {
        "id": 3656,
        "content": [
          "83%"
        ],
        "isCorrect": false
      },
      {
        "id": 3657,
        "content": [
          "75%"
        ],
        "isCorrect": true
      },
      {
        "id": 3658,
        "content": [
          "17%"
        ],
        "isCorrect": false
      },
      {
        "id": 3659,
        "content": [
          "25%"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 915,
    "content": [
      "A substance with a mass of 2kg has a volume of $$2.5 \\times 10^{-3} m^3$$. What is the relative density of the substance?"
    ],
    "explanation": [
      "The density of the substance is:\n$$\n\\rho = \\frac{m}{V} = \\frac{2 kg}{2.5 \\times 10^{-3} m^3} = 800 kg/m^3\n$$\nRelative density (RD) is:\n$$\nRD = \\frac{\\text{Density of substance}}{\\text{Density of water}} = \\frac{800 kg/m^3}{1000 kg/m^3} = 0.8\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_DENSITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3660,
        "content": [
          "1.25"
        ],
        "isCorrect": false
      },
      {
        "id": 3661,
        "content": [
          "0.8"
        ],
        "isCorrect": true
      },
      {
        "id": 3662,
        "content": [
          "8.0"
        ],
        "isCorrect": false
      },
      {
        "id": 3663,
        "content": [
          "80"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 916,
    "content": [
      "The gauge pressure at a point in a fluid at rest is defined as"
    ],
    "explanation": [
      "Gauge pressure is the difference between the absolute pressure and the atmospheric pressure."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_PRESSURE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3664,
        "content": [
          "the actual pressure at a given point relative to absolute vacuum."
        ],
        "isCorrect": false
      },
      {
        "id": 3665,
        "content": [
          "the sum of absolute pressure and atmospheric pressure."
        ],
        "isCorrect": false
      },
      {
        "id": 3666,
        "content": [
          "the pressure difference between the absolute pressure and the atmospheric pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 3667,
        "content": [
          "the atmospheric pressure difference between sea level and the local area at which the fluid exists."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 917,
    "content": [
      "How do we use manometer to measure pressure of a given gas? We use in such a way that"
    ],
    "explanation": [
      "A manometer measures pressure based on the principle of hydrostatic equilibrium, where the pressure difference is related to the height difference of the fluid column."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_PRESSURE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3668,
        "content": [
          "the principle of the hydrostatic equilibrium is considered to measure the pressure of unknown gas."
        ],
        "isCorrect": true
      },
      {
        "id": 3669,
        "content": [
          "the pressure at the surface of open end manometer is the same as the gas pressure in closed tube."
        ],
        "isCorrect": false
      },
      {
        "id": 3670,
        "content": [
          "the gauge pressure equals the atmospheric pressure."
        ],
        "isCorrect": false
      },
      {
        "id": 3671,
        "content": [
          "the gauge pressure in a fluid in the open end equals the gas pressure in closed tube."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 918,
    "content": [
      "Consider two balls A and B are projected with the same velocity, $$v_0$$ at angles $$\\theta_1$$ and $$\\theta_2$$, respectively, $$0 < \\theta_1 < 45^\\circ$$ and $$45^\\circ < \\theta_2 < 90^\\circ$$. Which one of the following statements is correct about the motion of the balls?"
    ],
    "explanation": [
      "For a projectile launched with an initial velocity $$v_0$$ at an angle $$\\theta$$, the range $$R$$ is given by $$R$$ = $$\\frac{v_0^2 \\sin(2\\theta)}{g}$$.\n\nThe ranges of two projectiles are equal if their launch angles are complementary, i.e., $$\\theta_1 + \\theta_2$$ = $$90^\\circ$$, because $$\\sin(2\\theta)$$ = $$\\sin(180^\\circ - 2\\theta)$$. So, $$\\sin(2\\theta_1)$$ = $$\\sin(2(90^\\circ - \\theta_2))$$ = $$\\sin(180^\\circ - 2\\theta_2)$$ = $$\\sin(2\\theta_2)$$."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3672,
        "content": [
          "The range of ball A is smaller than its maximum height."
        ],
        "isCorrect": false
      },
      {
        "id": 3673,
        "content": [
          "Ball A takes longer time than ball B to reach its maximum height."
        ],
        "isCorrect": false
      },
      {
        "id": 3674,
        "content": [
          "Both balls have equal speed at their respective maximum height."
        ],
        "isCorrect": false
      },
      {
        "id": 3675,
        "content": [
          "The two balls cover equal ranges when $$\\theta_1 + \\theta_2$$ = $$90^\\circ$$."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 919,
    "content": [
      "A car initially traveling at speed of 20 m/s undergoes a constant deceleration of magnitude 1.5 m/s². If the radius of each tire is 0.3 m, how many revolutions does each tire make, without slipping, before the car comes to rest?"
    ],
    "explanation": [
      "First, find the distance $$d$$ the car travels using\n$$\nv_f^2 = v_i^2 + 2ad\n$$\nWhere $$v_f = 0 \\ m/s$$ , $$v_i = 20 \\ m/s$$, and $$a = -1.5 \\ m/s^2$$. Thus,\n$$\n0 = 20^2 + 2(-1.5)d\n$$\n$$\nd = \\frac{400}{3} \\ m\n$$\nNext, find the circumference of the tire:\n$$\nC = 2\\pi r = 2\\pi (0.3) = 0.6\\pi \\ m\n$$\nThen, the number of revolutions is:\n$$\nN = \\frac{d}{C}\n$$\n$$\nN = \\frac{400/3}{0.6\\pi}\n$$\n$$\nN \\approx 70.77 \\ revolutions\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3676,
        "content": [
          "444.4 rev"
        ],
        "isCorrect": false
      },
      {
        "id": 3677,
        "content": [
          "70.77 rev"
        ],
        "isCorrect": true
      },
      {
        "id": 3678,
        "content": [
          "44.44 rev"
        ],
        "isCorrect": false
      },
      {
        "id": 3679,
        "content": [
          "133.33 rev"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 920,
    "content": [
      "A constant tangential force is applied on a rim of uniform solid disk of mass m = 50 kg and radius r = 0.5 m. If the angular speed of the disk changes by 1 rev/s within 2.0 s, what is the magnitude of the torque produced by the force? (moment of inertia of disk $$I=\\frac{mr^2}{2}$$)"
    ],
    "explanation": [
      "First, convert the change in angular speed to rad/s: $$1 \\text{ rev/s} = 2\\pi \\text{ rad/s}$$.\n\nThe angular acceleration $$\\alpha$$ = $$\\frac{\\Delta \\omega}{\\Delta t}$$ = $$\\frac{2\\pi}{2}$$ = $$\\pi \\text{ rad/s}^2$$.\n\nThe torque $$\\tau$$ = $$I\\alpha$$, where $$I$$ = $$\\frac{1}{2}mr^2$$ = $$\\frac{1}{2}(50)(0.5)^2$$ = $$\\frac{50}{8}$$ = $$6.25 \\text{ kg m}^2$$.\n\nTherefore, $$\\tau$$ = $$(6.25)(\\pi)$$ $$\\approx$$ $$6.25(3.14)$$ $$\\approx$$ $$19.625 Nm$$."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3680,
        "content": [
          "19.6 Nm"
        ],
        "isCorrect": true
      },
      {
        "id": 3681,
        "content": [
          "39.3 Nm"
        ],
        "isCorrect": false
      },
      {
        "id": 3682,
        "content": [
          "3.125 Nm"
        ],
        "isCorrect": false
      },
      {
        "id": 3683,
        "content": [
          "8.25 Nm"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 921,
    "content": [
      "A loop of 0.1 m wide in diameter is placed in xy-plane in uniform magnetic field of 0.6 T that is perpendicular to the plane of the loop. What is the net magnetic flux through the coil?"
    ],
    "explanation": [
      "The magnetic flux $$\\Phi$$ = $$B \\cdot A$$ = $$B \\cdot \\pi r^2$$, where $$B$$ = $$0.6 \\ T$$ and $$r$$ = $$\\frac{0.1}{2}$$ = $$0.05 \\ m$$.\n\nSo, $$\\Phi$$ = $$0.6 \\cdot \\pi (0.05)^2$$ $$\\approx$$ $$0.00471 \\ Wb$$ or $$4.71 \\times 10^{-3} \\ Wb$$."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3684,
        "content": [
          "$$1.9 \\times 10^{-2} \\ Wb$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3685,
        "content": [
          "$$5.6 \\times 10^{-2} \\ Wb$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3686,
        "content": [
          "$$4.7 \\times 10^{-3} \\ Wb$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3687,
        "content": [
          "$$9.4 \\times 10^{-3} \\ Wb$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 922,
    "content": [
      "A 12 V voltage source is connected across the primary coil of a transformer having 600 turns. If the secondary coil of a transformer has 1000 turns, what voltage appears across the secondary coil?"
    ],
    "explanation": [
      "The transformer equation is\n$$\n\\frac{V_p}{N_p} = \\frac{V_s}{N_s}\n$$\nWhere $$V_p$$ is the primary voltage, $$N_p$$ is the number of turns in the primary coil, $$V_s$$ is the secondary voltage, and $$N_s$$ is the number of turns in the secondary coil.\n\nGiven $$V_p = 12 \\ V$$, $$N_p = 600$$, and $$N_s = 1000$$, we have\n$$\n\\frac{12}{600} = \\frac{V_s}{1000}\n$$\n$$\nV_s = \\frac{12 \\cdot 1000}{600} = 20 \\ V\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3688,
        "content": [
          "72.0 V"
        ],
        "isCorrect": false
      },
      {
        "id": 3689,
        "content": [
          "7.2 V"
        ],
        "isCorrect": false
      },
      {
        "id": 3690,
        "content": [
          "12.0 V"
        ],
        "isCorrect": false
      },
      {
        "id": 3691,
        "content": [
          "20.0 V"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 923,
    "content": [
      "The following table shows the density of different objects at 20°C.",
      "images/physics/year_2016/q38_1.png",
      "Based on the information given in the table, if we identify substances that sink and float with respect to other substance,"
    ],
    "explanation": [
      "Bone (1800 kg/m³), iron (7860 kg/m³), and seawater (1025 kg/m³) all have densities greater than that of water (1000 kg/m³). Since a substance sinks in another if its density is greater than the fluid’s density, all three substances—bone, iron, and seawater—will sink in water."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_DENSITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2016/q38_1.png"
    ],
    "choices": [
      {
        "id": 3692,
        "content": [
          "bone, iron and seawater will sink in water."
        ],
        "isCorrect": true
      },
      {
        "id": 3693,
        "content": [
          "water, gasoline and ice will sink into seawater."
        ],
        "isCorrect": false
      },
      {
        "id": 3694,
        "content": [
          "gasoline, ice and blood floats on the surface of water."
        ],
        "isCorrect": false
      },
      {
        "id": 3695,
        "content": [
          "gold, blood and copper floats in gasoline."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 924,
    "content": [
      "Which one of the following statements differentiates emitter, collector and base of a transistor?"
    ],
    "explanation": [
      "The emitter region is heavily doped as compared to the base and collector regions. This is because the emitter is responsible for injecting a large number of charge carriers into the base."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3696,
        "content": [
          "The collector region is heavily doped as compared with emitter and base."
        ],
        "isCorrect": false
      },
      {
        "id": 3697,
        "content": [
          "The emitter region is heavily doped as compared with base and collector."
        ],
        "isCorrect": true
      },
      {
        "id": 3698,
        "content": [
          "The three parts; emitter, base and collector are equally doped."
        ],
        "isCorrect": false
      },
      {
        "id": 3699,
        "content": [
          "The base region is heavily doped as compared with base and collector."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 925,
    "content": [
      "The following figure shows a switch of circuit consisting of a battery source, two switches represented by letters A and B, and a light bulb Y.",
      "images/physics/year_2016/q40_1.png",
      "Which one of the following logic get can be represented by equivalent switch circuit?"
    ],
    "explanation": [
      "The two switches are wired in parallel, so closing either A or B completes the circuit and lights Y. That behavior implements an OR gate."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2016/q40_1.png"
    ],
    "choices": [
      {
        "id": 3700,
        "content": [
          "images/physics/year_2016/q40c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3701,
        "content": [
          "images/physics/year_2016/q40c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3702,
        "content": [
          "images/physics/year_2016/q40c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3703,
        "content": [
          "images/physics/year_2016/q40c4_1.png"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 926,
    "content": [
      "The angular momentum of a rotating object is defined as the product of its"
    ],
    "explanation": [
      "Angular momentum $$L$$ is defined as the product of the moment of inertia $$I$$ and the angular velocity $$\\omega$$, i.e., $$L = I\\omega$$."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_MOMENTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3704,
        "content": [
          "moment of inertia and the square of the angular velocity."
        ],
        "isCorrect": false
      },
      {
        "id": 3705,
        "content": [
          "mass and the angular velocity."
        ],
        "isCorrect": false
      },
      {
        "id": 3706,
        "content": [
          "mass and one-half of the square of the angular velocity."
        ],
        "isCorrect": false
      },
      {
        "id": 3707,
        "content": [
          "moment of inertia and angular velocity."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 927,
    "content": [
      "What do you call the sound wave that is heard after reflection from a hard surface?"
    ],
    "explanation": [
      "An echo is a sound wave that is heard after reflection from a hard surface."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_SOUND",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3708,
        "content": [
          "Echo"
        ],
        "isCorrect": true
      },
      {
        "id": 3709,
        "content": [
          "Loudness"
        ],
        "isCorrect": false
      },
      {
        "id": 3710,
        "content": [
          "Pitch"
        ],
        "isCorrect": false
      },
      {
        "id": 3711,
        "content": [
          "Timber"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Mechanical Oscillation and Sound Wave"
  },
  {
    "id": 928,
    "content": [
      "Which one of the following waves is identified as longitudinal wave?"
    ],
    "explanation": [
      "Sound waves are longitudinal waves, meaning that the displacement of the medium is in the same direction as the wave's propagation."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_SOUND",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3712,
        "content": [
          "Sound wave"
        ],
        "isCorrect": true
      },
      {
        "id": 3713,
        "content": [
          "Deep water wave"
        ],
        "isCorrect": false
      },
      {
        "id": 3714,
        "content": [
          "S-wave of Earthquake"
        ],
        "isCorrect": false
      },
      {
        "id": 3715,
        "content": [
          "Wave on a vibrating string"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Mechanical Oscillation and Sound Wave"
  },
  {
    "id": 929,
    "content": [
      "Which of the following statements is correct about the components of the velocity of a ball projected up at an angle of $$\\theta$$ with the horizontal? Neglecting the air resistance,"
    ],
    "explanation": [
      "In projectile motion without air resistance, the horizontal component of velocity remains constant because there is no horizontal acceleration."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3716,
        "content": [
          "the vertical component of velocity increases while the horizontal component of velocity decreases."
        ],
        "isCorrect": false
      },
      {
        "id": 3717,
        "content": [
          "the vertical component of the velocity remains constant throughout its journey."
        ],
        "isCorrect": false
      },
      {
        "id": 3718,
        "content": [
          "the horizontal velocity of the ball is equal to zero at the maximum height."
        ],
        "isCorrect": false
      },
      {
        "id": 3719,
        "content": [
          "the horizontal component of the velocity remains constant throughout its journey."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 930,
    "content": [
      "Which one of the following statements is correct about the electric field due to a charged spherical solid conductor?"
    ],
    "explanation": [
      "For a charged spherical solid conductor, the electric field inside the sphere is zero because any excess charge resides on the surface of the conductor."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3720,
        "content": [
          "It is non-zero constant outside the sphere."
        ],
        "isCorrect": false
      },
      {
        "id": 3721,
        "content": [
          "It is zero inside the sphere."
        ],
        "isCorrect": true
      },
      {
        "id": 3722,
        "content": [
          "It is parallel to the surface of the sphere."
        ],
        "isCorrect": false
      },
      {
        "id": 3723,
        "content": [
          "It is non-zero constant inside the sphere."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 931,
    "content": [
      "A metal wire made of coefficient of linear expansion $$\\alpha$$ is heated so that its temperature is changed by $$\\Delta T$$. If the length of the wire before heating is $$L_0$$, which one of the following expressions is correct for the final length of the wire after heating?"
    ],
    "explanation": [
      "The linear expansion formula is given by $$\\Delta L$$ = $$L_0 \\alpha \\Delta T$$, so the final length $$L$$ = $$L_0 + \\Delta L$$ = $$L_0 + L_0 \\alpha \\Delta T$$ = $$L_0(1 + \\alpha \\Delta T)$$."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3724,
        "content": [
          "$$\\frac{L_0}{1+\\alpha\\Delta T}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3725,
        "content": [
          "$$L_0\\alpha\\Delta T$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3726,
        "content": [
          "$$\\frac{L_0}{1-\\alpha\\Delta T}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3727,
        "content": [
          "$$L_0(1+\\alpha\\Delta T)$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 932,
    "content": [
      "What amount of heat energy is required to completely melt 200g of ice at 0 °C? (Take specific latent heat of melting for ice, $$L_f = 3.3 \\times 10^5 \\ J/kg$$)"
    ],
    "explanation": [
      "The heat energy required to melt the ice is $$Q$$ = $$mL_f$$, where $$m$$ = $$0.2 \\ kg$$ and $$L_f$$ = $$3.3 \\times 10^5 J/kg$$. So,\n$$\nQ = 0.2 \\times 3.3 \\times 10^5 = 6.6 \\times 10^4 J\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3728,
        "content": [
          "$$6.60 \\times 10^4 \\ J$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3729,
        "content": [
          "$$1.65 \\times 10^7 \\ J$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3730,
        "content": [
          "$$1.65 \\times 10^3 \\ J$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3731,
        "content": [
          "Zero"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 933,
    "content": [
      "The orbital speed of a satellite at a height of 780 km from the surface of the earth is 7,465 m/s. what is the period of the satellite?"
    ],
    "explanation": [
      "The Earth's radius is approximately 6400 km.\n\nTherefore, the orbital radius is r = 6400 + 780 = 7180 km or $$7.180 \\times 10^6$$ m.\n\nThe period T is related to the orbital speed v and the circumference by\n$$\nT = \\frac{2\\pi r}{v}\n$$\n$$\nT = \\frac{2\\pi (7.180 \\times 10^6)}{7465}\n$$\n$$\nT \\approx 6.043 \\times 10^3 s\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3732,
        "content": [
          "$$6.04 \\times 10^3$$ s"
        ],
        "isCorrect": true
      },
      {
        "id": 3733,
        "content": [
          "$$6.04 \\times 10^2$$ s"
        ],
        "isCorrect": false
      },
      {
        "id": 3734,
        "content": [
          "$$6.60 \\times 10^2$$ s"
        ],
        "isCorrect": false
      },
      {
        "id": 3735,
        "content": [
          "$$6.60 \\times 10^3$$ s"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 934,
    "content": [
      "The charge of 20.0 $$\\mu$$C is stored on the capacitor when a potential difference between its two parallel plates is 200.0 V. what is the capacitance of the capacitor?"
    ],
    "explanation": [
      "The capacitance $$C$$ = $$\\frac{Q}{V}$$, where $$Q$$ = $$20.0 \\times 10^{-6} \\ C$$ and $$V = 200.0 \\ V$$.\n$$\nC = \\frac{20.0 \\times 10^{-6}}{200.0}\n$$\n$$\nC = 0.1 \\times 10^{-6} F\n$$\n$$\nC = 0.1 \\mu F\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3736,
        "content": [
          "10.0 $$\\mu$$F"
        ],
        "isCorrect": false
      },
      {
        "id": 3737,
        "content": [
          "1.0 $$\\mu$$F"
        ],
        "isCorrect": false
      },
      {
        "id": 3738,
        "content": [
          "4.0 mF"
        ],
        "isCorrect": false
      },
      {
        "id": 3739,
        "content": [
          "0.1 $$\\mu$$F"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Magnetism"
  },
  {
    "id": 935,
    "content": [
      "An air filled parallel plate capacitor is connected to a potential difference v to store electric charge. If the area of the plates is A and the separation between the plates is d, then the electrical energy stored on the capacitor is"
    ],
    "explanation": [
      "The energy stored in a capacitor is $$U$$ = $$\\frac{1}{2}CV^2$$, where the capacitance $$C$$ of a parallel plate capacitor is $$C$$ = $$\\frac{\\epsilon_0 A}{d}$$.\n\nThus, $$U$$ = $$\\frac{1}{2} \\frac{\\epsilon_0 A}{d} V^2$$ = $$\\frac{1}{2} \\frac{\\epsilon_0 A V^2}{d}$$."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3740,
        "content": [
          "$$\\frac{\\epsilon_0 A V^2}{d}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3741,
        "content": [
          "$$\\frac{1}{2} \\frac{\\epsilon_0 d V^2}{A}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3742,
        "content": [
          "$$\\frac{1}{2} \\frac{\\epsilon_0 A V^2}{d}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3743,
        "content": [
          "$$\\frac{\\epsilon_0 d V^2}{A}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Magnetism"
  },
  {
    "id": 936,
    "content": [
      "Which one of the following is correct about the four basic forces in nature?"
    ],
    "explanation": [
      "The strong nuclear force is a short-range force that holds protons and neutrons together inside the nucleus, overcoming the electromagnetic repulsion between the protons."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_FORCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3744,
        "content": [
          "Electromagnetic force is the weakest of all the forces in nature."
        ],
        "isCorrect": false
      },
      {
        "id": 3745,
        "content": [
          "Gravitational force is attractive force that acts on the scale of the atomic nucleus."
        ],
        "isCorrect": false
      },
      {
        "id": 3746,
        "content": [
          "Strong nuclear force is short-range force that holds protons and neutrons together inside a nucleus."
        ],
        "isCorrect": true
      },
      {
        "id": 3747,
        "content": [
          "Weak nuclear force keeps the electrons in their orbit around a nucleus."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 937,
    "content": [
      "Which of the following is correct about impulse?"
    ],
    "explanation": [
      "Impulse is defined as the change in momentum of an object. The impulse $$J$$ = $$\\Delta p$$ = $$F\\Delta t$$, where $$F$$ is the force applied and $$\\Delta t$$ is the time interval. The direction of the impulse is the same as the direction of the change in momentum."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_MOMENTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3748,
        "content": [
          "The direction of the impulse is in the same direction to change in the momentum of the object."
        ],
        "isCorrect": true
      },
      {
        "id": 3749,
        "content": [
          "During momentum change final momentum of an object is along the impulse on the object."
        ],
        "isCorrect": false
      },
      {
        "id": 3750,
        "content": [
          "Impulse due to a force exerted for a short time is equal to impulse due to the same force exerted for a long time."
        ],
        "isCorrect": false
      },
      {
        "id": 3751,
        "content": [
          "The impulse is smaller than change of momentum which caused by the applied force."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 938,
    "content": [
      "A person walked 10 m in a direction 53° North of East, 10 m North, and finally 20 m in a direction 37° North of West. The magnitude of the person's displacement is"
    ],
    "explanation": [
      "**Break movements into components:**\n\n- 10 m at 53° North of East: $$x_1$$ = 6 m (East), $$y_1$$ = 8 m (North)\n- 10 m North: $$x_2$$ = 0, $$y_2$$ = 10 m (North)\n- 20 m at 37° North of West: $$x_3$$ = 16 m (West), $$y_3$$ = 12 m (North)\n\n**Sum components:**\n\n- x = 6 + 0 - 16 = -10 m (West)\n- y = 8 + 10 + 12 = 30 m (North)\n\n**Calculate displacement:**\n$$\nD = \\sqrt{(-10)^2 + (30)^2} = \\sqrt{1000} \\approx 31.6 \\, \\text{m}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3752,
        "content": [
          "30.0 m."
        ],
        "isCorrect": false
      },
      {
        "id": 3753,
        "content": [
          "31.6 m."
        ],
        "isCorrect": true
      },
      {
        "id": 3754,
        "content": [
          "40.0 m."
        ],
        "isCorrect": false
      },
      {
        "id": 3755,
        "content": [
          "20.0 m."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 939,
    "content": [
      "Which of the following pair of vectors is collinear?"
    ],
    "explanation": [
      "Two vectors are collinear if one is a scalar multiple of the other.\n- Option 1: $$\\vec{C} = \\hat{i} + \\hat{j}$$ and $$\\vec{D} = \\hat{i} - \\hat{j}$$\n    - These vectors are not scalar multiples of each other.\n- Option 2: $$\\vec{A} = 2\\hat{i} + 3\\hat{j}$$ and $$\\vec{B} = -4\\hat{i} + 6\\hat{j}$$\n    - $$\\frac{-4}{2} = -2$$ and $$\\frac{6}{3} = 2$$, so $$\\vec{B}$$ is not a scalar multiple of $$\\vec{A}$$.\n- Option 3: $$\\vec{E} = -\\hat{i} + \\hat{j}$$ and $$\\vec{F} = 3\\hat{i} - 3\\hat{j}$$\n    - $$-3(-\\hat{i} + \\hat{j}) = 3\\hat{i} - 3\\hat{j}$$, so $$\\vec{F} = -3\\vec{E}$$. These vectors are collinear.\n- Option 4 : $$\\vec{G} = 2\\hat{i} + 3\\hat{j}$$ and $$\\vec{F} = 3\\hat{i} + 2\\hat{j}$$\n    - These vectors are not scalar multiples of each other."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3756,
        "content": [
          "$$\\vec{C}$$ = $$\\hat{i}$$ + $$\\hat{j}$$ and $$\\vec{D}$$ = $$\\hat{i}$$ - $$\\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3757,
        "content": [
          "$$\\vec{A}$$ = $$2\\hat{i}$$ + $$3\\hat{j}$$ and $$\\vec{B}$$ = $$-4\\hat{i}$$ + $$6\\hat{j}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3758,
        "content": [
          "$$\\vec{E}$$ = $$-\\hat{i}$$ + $$\\hat{j}$$ and $$\\vec{F}$$ = $$3\\hat{i}$$ - $$3\\hat{j}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3759,
        "content": [
          "$$\\vec{G}$$ = $$2\\hat{i}$$ +$$ 3\\hat{j}$$ and $$\\vec{F}$$ = $$3\\hat{i}$$ + $$2\\hat{j}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 940,
    "content": [
      "A ball is thrown vertically upward with 12 m/s from the ground. Its speed when the ball is 4.0 m above the ground is"
    ],
    "explanation": [
      "Using the kinematic equation $$v_f^2$$ = $$v_i^2$$ + $$2ad$$, where $$v_i = 12 m/s$$, $$a = -10 m/s^2$$, and $$d = 4.0 m$$\n\n$$v_f^2$$ = $$(12)^2 + 2(-10)(4)$$ = $$144 - 80$$ = $$64$$.\n\nTherefore, $$v_f$$ = $$\\sqrt{64}$$ = $$8 m/s$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3760,
        "content": [
          "8 m/s."
        ],
        "isCorrect": true
      },
      {
        "id": 3761,
        "content": [
          "15 m/s."
        ],
        "isCorrect": false
      },
      {
        "id": 3762,
        "content": [
          "10 m/s."
        ],
        "isCorrect": false
      },
      {
        "id": 3763,
        "content": [
          "12 m/s."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 941,
    "content": [
      "An object is projected at angle $$\\theta$$ from the horizontal with initial velocity $$v_0$$. Which one of the following expressions represents the relationship between maximum height, $$h_{max}$$, and range of the projectile, R?"
    ],
    "explanation": [
      "The range $$R$$ = $$\\frac{v_0^2 \\sin(2\\theta)}{g}$$ = $$\\frac{2v_0^2 \\sin(\\theta) \\cos(\\theta)}{g}$$ and the maximum height $$h_{max}$$ = $$\\frac{v_0^2 \\sin^2(\\theta)}{2g}$$.\n\nThen $$R$$ = $$\\frac{2 v_0^2 \\sin(\\theta) \\cos(\\theta)}{g}$$ = $$\\frac{4 (\\frac{v_0^2 \\sin^2(\\theta)}{2g})}{\\frac{\\sin(\\theta)}{\\cos(\\theta)}}$$ = $$\\frac{4h_{max}}{\\tan(\\theta)}$$."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3764,
        "content": [
          "$$R = h_{max} \\frac{\\tan \\theta}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3765,
        "content": [
          "$$R = 4 h_{max} \\tan \\theta$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3766,
        "content": [
          "$$R = \\frac{2 h_{max}}{\\tan \\theta}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3767,
        "content": [
          "$$R = \\frac{4 h_{max}}{\\tan \\theta}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 942,
    "content": [
      "A 0.5 kg block moving with an initial speed of 5.0 m/s slides 2.5 m on a rough horizontal surface before coming to rest. The coefficient of kinetic friction is"
    ],
    "explanation": [
      "The work done by friction is equal to the change in kinetic energy:\n$$\nW = \\Delta KE\n$$\nThe work done by friction is\n$$\nW = -f_k d = -\\mu_k m g d\n$$\nWhere $$\\mu_k$$ is the coefficient of kinetic friction, $$m = 0.5 kg$$, $$g = 10 m/s^2$$, and $$d = 2.5 m$$.\n\nThe change in kinetic energy is $$\\Delta KE$$ = $$\\frac{1}{2}mv_f^2$$ - $$\\frac{1}{2}mv_i^2$$ = $$0$$ - $$\\frac{1}{2}(0.5)(5.0)^2$$ = $$-\\frac{1}{2}(0.5)(25)$$ = $$-6.25 J$$.\n\nThus, $$-\\mu_k m g d$$ = $$-6.25$$, so $$\\mu_k$$ = $$\\frac{6.25}{m g d}$$ = $$\\frac{6.25}{(0.5)(10)(2.5)}$$ = $$\\frac{6.25}{12.5}$$ = $$0.5$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_FORCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3768,
        "content": [
          "0.5."
        ],
        "isCorrect": true
      },
      {
        "id": 3769,
        "content": [
          "0.3."
        ],
        "isCorrect": false
      },
      {
        "id": 3770,
        "content": [
          "0.1."
        ],
        "isCorrect": false
      },
      {
        "id": 3771,
        "content": [
          "0.4."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 943,
    "content": [
      "A 0.2 kg ball is kicked from the ground at 16 m/s in a direction making an angle $$\\theta$$ above the horizontal. Neglecting air resistance, the magnitude of velocity of the ball when it is 3.0 m from the ground is"
    ],
    "explanation": [
      "Using conservation of energy, we have\n$$\nKE_i + PE_i = KE_f + PE_f\n$$\nThe initial kinetic energy is\n\n$$\nKE_i = \\frac{1}{2} m v_i^2 = \\frac{1}{2} (0.2) (16)^2 = 25.6 J\n$$\n\n- The initial potential energy is $$PE_i$$ = $$0 J$$ (at ground level).\n- The final potential energy is $$PE_f$$ = $$mgh$$ = $$(0.2)(9.8)(3.0)$$ = $$5.88 J$$.\n- The final kinetic energy is $$KE_f$$ = $$\\frac{1}{2} m v_f^2$$.\n\n$$\n25.6 + 0 = \\frac{1}{2} (0.2) v_f^2 + 5.88\n$$\n\n$$\n25.6 - 5.88 = 0.1 v_f^2\n$$\n\n$$\n19.72 = 0.1 v_f^2\n$$\n$$\nv_f^2 = 197.2\n$$\n\n$$\nv_f = \\sqrt{197.2} \\approx 14.04 m/s\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3772,
        "content": [
          "7 m/s."
        ],
        "isCorrect": false
      },
      {
        "id": 3773,
        "content": [
          "2 m/s."
        ],
        "isCorrect": false
      },
      {
        "id": 3774,
        "content": [
          "14 m/s."
        ],
        "isCorrect": true
      },
      {
        "id": 3775,
        "content": [
          "16 m/s."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 944,
    "content": [
      "The angular speed of a disk rotating about its axis increases by 2000 rad/s in a time interval of 3.0 s. If the moment of inertia of the disk is 0.6 kg m², what is the average torque on the disk?"
    ],
    "explanation": [
      "The torque $$\\tau$$ = $$I\\alpha$$, where $$\\alpha$$ = $$\\frac{\\Delta \\omega}{\\Delta t}$$ = $$\\frac{2000}{3.0} \\text{ rad/s}^2$$ and $$I$$ = $$0.6 \\text{ kg m}^2$$.\n\nTherefore, $$\\tau$$ = $$0.6 \\cdot \\frac{2000}{3.0}$$ = $$\\frac{1200}{3}$$ = $$400 Nm$$"
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3776,
        "content": [
          "670 Nm"
        ],
        "isCorrect": false
      },
      {
        "id": 3777,
        "content": [
          "1200 Nm"
        ],
        "isCorrect": false
      },
      {
        "id": 3778,
        "content": [
          "6000 Nm"
        ],
        "isCorrect": false
      },
      {
        "id": 3779,
        "content": [
          "400 Nm"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 945,
    "content": [
      "A small ball of mass m tied to a rope of length l is moving along a vertical circle about a point O as shown in the figure.",
      "images/physics/year_2016/q60_1.png",
      "If A, B, C, and D are points on the path, then which one of the following is correct about the force exert on the ball at these points?"
    ],
    "explanation": [
      "The net force towards the center of the circle provides the centripetal force, and the tension in the string is directed toward the center of the circle.\n\nAt point D, the weight is perpendicular to the radial direction and is $$mg$$. Therefore, the radial force is due only to the tension in the string, and the radial force = tension on the rope.\n\nAt point C: the radial force is tension + weight =$$T+mg$$\n\nAt point A: radial direction is up and gravity is down (center), so T - mg = mv2/r\n\nAt point B: Weight does not change the tension of the rope."
    ],
    "year": "YEAR_2016",
    "subject": "PHYSICS",
    "chapter": "PHY_FORCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2016/q60_1.png"
    ],
    "choices": [
      {
        "id": 3780,
        "content": [
          "At point C, the radial force and the tension on the rope are in opposite direction."
        ],
        "isCorrect": false
      },
      {
        "id": 3781,
        "content": [
          "At point D, the radial force is equal to the tension on the rope."
        ],
        "isCorrect": true
      },
      {
        "id": 3782,
        "content": [
          "At point A, the radial force is in opposite direction to the gravitational force on a ball."
        ],
        "isCorrect": false
      },
      {
        "id": 3783,
        "content": [
          "At point B, the radial force is equal to the gravitational force on the ball."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2408,
    "content": [
      "Vector quantities are represented by"
    ],
    "explanation": [
      "Vector quantities, such as force and velocity, are defined by having both a magnitude (size) and a direction. Scalar quantities, like mass and time, only have magnitude."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9640,
        "content": [
          "magnitude and direction."
        ],
        "isCorrect": true
      },
      {
        "id": 9641,
        "content": [
          "direction only."
        ],
        "isCorrect": false
      },
      {
        "id": 9642,
        "content": [
          "magnitude only."
        ],
        "isCorrect": false
      },
      {
        "id": 9643,
        "content": [
          "dimensionless values."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 2409,
    "content": [
      "According to Newton's first law, an object that is in motion continues its state of motion with"
    ],
    "explanation": [
      "Newton's first law, the law of inertia, states that an object will remain at rest or in uniform motion in a straight line (i.e., at a constant velocity) unless acted upon by a net external force. If the resultant force is zero, there is no acceleration, and the velocity remains constant."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9644,
        "content": [
          "a decreasing speed if the resultant force exerted on it is zero."
        ],
        "isCorrect": false
      },
      {
        "id": 9645,
        "content": [
          "constant velocity if the resultant force exerted on it is not zero."
        ],
        "isCorrect": false
      },
      {
        "id": 9646,
        "content": [
          "an increasing speed if the resultant force exerted on it is not zero."
        ],
        "isCorrect": false
      },
      {
        "id": 9647,
        "content": [
          "constant velocity if the resultant force exerted on it is zero."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2410,
    "content": [
      "Which of the following correctly describes the difference between distance and displacement?"
    ],
    "explanation": [
      "Distance is a scalar quantity representing the total path length traveled. Displacement is a vector quantity representing the shortest straight-line distance from the initial to the final point. Because displacement is the shortest path, its magnitude can never be greater than the distance traveled."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9648,
        "content": [
          "Distance can be described both in magnitude and direction, while displacement is described only by magnitude."
        ],
        "isCorrect": false
      },
      {
        "id": 9649,
        "content": [
          "Distance depends on the initial and final points, while displacement depends on the path followed by a moving body."
        ],
        "isCorrect": false
      },
      {
        "id": 9650,
        "content": [
          "Distance is always greater than or equal to the magnitude of displacement, while the magnitude of the displacement is always less than or equal to distance."
        ],
        "isCorrect": true
      },
      {
        "id": 9651,
        "content": [
          "Distance has either positive or negative values, while displacement has only positive value."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 2411,
    "content": [
      "Which of the following statements is correct about a uniformly accelerated motion?"
    ],
    "explanation": [
      "The definition of uniformly accelerated motion is that the rate of change of velocity, which is acceleration, is constant over time."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9652,
        "content": [
          "The velocity is constant."
        ],
        "isCorrect": false
      },
      {
        "id": 9653,
        "content": [
          "The acceleration is constant."
        ],
        "isCorrect": true
      },
      {
        "id": 9654,
        "content": [
          "The speed is constant but the direction is changing."
        ],
        "isCorrect": false
      },
      {
        "id": 9655,
        "content": [
          "The displacement increases at a uniform rate."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Uniformly Accelerated Motion"
  },
  {
    "id": 2412,
    "content": [
      "Two displacement vectors have magnitudes 4 m and 3 m. Which one of the following is NOT the possible value of the magnitude of their resultant vector?"
    ],
    "explanation": [
      "The magnitude of the resultant vector R of two vectors A and B must lie in the range |A - B| ≤ R ≤ A + B. For vectors of magnitude 4 m and 3 m, the range is |4 - 3| ≤ R ≤ 4 + 3, which simplifies to 1 m ≤ R ≤ 7 m. The value 12 m is outside this possible range."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9656,
        "content": [
          "1 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9657,
        "content": [
          "7 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9658,
        "content": [
          "5 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9659,
        "content": [
          "12 m"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 2413,
    "content": [
      "A train is moving along a straight line with a constant acceleration of 5 m/s² when it passes by a traffic light point. From there on, if the time taken by the train to reach a velocity of 30 m/s is 4 seconds, then what is the distance of the train from the traffic point after 8 seconds?"
    ],
    "explanation": [
      "First, find the initial velocity (u) when the train passes the traffic light using the formula $$v = u + at$$.\n$$\n30 \\text{ m/s} = u + (5 \\text{ m/s}^2)(4 \\text{ s})\n$$\n$$\nu = 30 - 20 = 10 \\text{ m/s}\n$$",
      "Now, calculate the distance (s) traveled after 8 seconds using the formula $$s = ut + \\frac{1}{2}at^2$$.\n$$\ns = (10 \\text{ m/s})(8 \\text{ s}) + \\frac{1}{2}(5 \\text{ m/s}^2)(8 \\text{ s})^2\n$$\n$$\ns = 80 + \\frac{1}{2}(5)(64)\n$$\n$$\ns = 80 + 160 = 240 \\text{ m}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9660,
        "content": [
          "80 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9661,
        "content": [
          "160 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9662,
        "content": [
          "240 m"
        ],
        "isCorrect": true
      },
      {
        "id": 9663,
        "content": [
          "320 m"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Uniformly Accelerated Motion"
  },
  {
    "id": 2414,
    "content": [
      "Which one of the following statements is a necessary condition for an object to be in linear equilibrium?"
    ],
    "explanation": [
      "An object is in linear equilibrium when the net force acting on it is zero ($$\\Sigma F = 0$$). According to Newton's second law ($$\\Sigma F = ma$$), if the net force is zero, the acceleration (a) must also be zero."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9664,
        "content": [
          "The net force acting on the object is non-zero constant."
        ],
        "isCorrect": false
      },
      {
        "id": 9665,
        "content": [
          "The linear acceleration of the object is zero."
        ],
        "isCorrect": true
      },
      {
        "id": 9666,
        "content": [
          "The linear speed of the object is constant."
        ],
        "isCorrect": false
      },
      {
        "id": 9667,
        "content": [
          "The linear acceleration of the object is non-zero constant."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2415,
    "content": [
      "When an object tends to slide over the surface of another object, tiny bumps at the surface of the two objects knocking and locking together. This causes"
    ],
    "explanation": [
      "The description refers to the microscopic interactions (interlocking of surface irregularities) that give rise to the force of friction, which opposes the relative motion or tendency of motion between surfaces in contact."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_FORCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9668,
        "content": [
          "gravitational force."
        ],
        "isCorrect": false
      },
      {
        "id": 9669,
        "content": [
          "electrostatic force."
        ],
        "isCorrect": false
      },
      {
        "id": 9670,
        "content": [
          "normal force."
        ],
        "isCorrect": false
      },
      {
        "id": 9671,
        "content": [
          "frictional force."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2416,
    "content": [
      "Suppose a ball is thrown vertically upward and after reaching a maximum height, it returns back to its initial position. Which of the following statement is correct about energy changes and work done on the ball?"
    ],
    "explanation": [
      "Work is done when a force causes displacement. Work is positive if the force and displacement are in the same direction. As the ball falls down, the force of gravity and the displacement are both in the downward direction, so the work done by gravity is positive."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9672,
        "content": [
          "On its way up, work done by gravity is positive."
        ],
        "isCorrect": false
      },
      {
        "id": 9673,
        "content": [
          "On its way up, change in its kinetic energy is positive."
        ],
        "isCorrect": false
      },
      {
        "id": 9674,
        "content": [
          "On its way down, work done by gravity is positive."
        ],
        "isCorrect": true
      },
      {
        "id": 9675,
        "content": [
          "On its way down, change in its potential energy is positive."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 2417,
    "content": [
      "The mechanical energy of an oscillating object at any point through its path is equal to"
    ],
    "explanation": [
      "Mechanical energy (ME) is defined as the total energy of motion and position of an object. It is the sum of its kinetic energy (KE) and potential energy (PE). For an ideal system without friction, mechanical energy is conserved."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9676,
        "content": [
          "the sum of its kinetic and potential energies."
        ],
        "isCorrect": true
      },
      {
        "id": 9677,
        "content": [
          "the sum of its kinetic and internal energies."
        ],
        "isCorrect": false
      },
      {
        "id": 9678,
        "content": [
          "the sum of its potential and internal energies."
        ],
        "isCorrect": false
      },
      {
        "id": 9679,
        "content": [
          "the difference between its kinetic and potential energies."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 2418,
    "content": [
      "A 2 kg object accelerates with 1.5 m/s² to the right on a horizontal frictionless surface under the action of two horizontal forces, F₁ and F₂ as shown in the figure below.",
      "images/physics/year_2017/q11_1.png",
      "What should be the magnitude of F₁?"
    ],
    "explanation": [
      "According to Newton's second law, the net force equals mass times acceleration ($$F_{net} = ma$$). The net force is the vector sum of F₁ and F₂. Let the direction to the right be positive.\n$$\nF_{net} = F_1 - F_2\n$$\n$$\nma = F_1 - F_2\n$$\n$$\n(2 \\text{ kg})(1.5 \\text{ m/s}^2) = F_1 - 1 \\text{ N}\n$$\n$$\n3 \\text{ N} = F_1 - 1 \\text{ N}\n$$\n$$\nF_1 = 3 \\text{ N} + 1 \\text{ N} = 4 \\text{ N}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2017/q11_1.png"
    ],
    "choices": [
      {
        "id": 9680,
        "content": [
          "2 N"
        ],
        "isCorrect": false
      },
      {
        "id": 9681,
        "content": [
          "1 N"
        ],
        "isCorrect": false
      },
      {
        "id": 9682,
        "content": [
          "3 N"
        ],
        "isCorrect": false
      },
      {
        "id": 9683,
        "content": [
          "4 N"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2419,
    "content": [
      "A tennis ball of mass 0.10 kg traveling horizontally at 40.0 m/s is struck back by a racket. If the ball returns back with a speed of 30.0 m/s in the opposite direction, what is the magnitude of the impulse delivered to the ball by the racket?"
    ],
    "explanation": [
      "Impulse is equal to the change in momentum ($$\\Delta p = p_f - p_i$$). Let the initial direction of the ball be positive.",
      "Initial momentum:\n$$\np_i = mv_i = (0.10 \\text{ kg})(+40.0 \\text{ m/s}) = 4.0 \\text{ kg m/s}\n$$",
      "Final momentum:\n$$\np_f = mv_f = (0.10 \\text{ kg})(-30.0 \\text{ m/s}) = -3.0 \\text{ kg m/s}\n$$",
      "Impulse:\n$$\n\\Delta p = p_f - p_i = -3.0 \\text{ kg m/s} - 4.0 \\text{ kg m/s} = -7.0 \\text{ kg m/s}\n$$",
      "The magnitude of the impulse is 7.0 kg m/s."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_MOMENTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9684,
        "content": [
          "3.0 kg m/s"
        ],
        "isCorrect": false
      },
      {
        "id": 9685,
        "content": [
          "4.0 kg m/s"
        ],
        "isCorrect": false
      },
      {
        "id": 9686,
        "content": [
          "7.0 kg m/s"
        ],
        "isCorrect": true
      },
      {
        "id": 9687,
        "content": [
          "1.0 kg m/s"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2420,
    "content": [
      "A force that is exerted on a simple machine in order to produce input work is called"
    ],
    "explanation": [
      "In the context of simple machines, the 'effort' is the input force applied to the machine, and the 'load' is the output force that the machine exerts to overcome resistance."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9688,
        "content": [
          "friction."
        ],
        "isCorrect": false
      },
      {
        "id": 9689,
        "content": [
          "load."
        ],
        "isCorrect": false
      },
      {
        "id": 9690,
        "content": [
          "effort."
        ],
        "isCorrect": true
      },
      {
        "id": 9691,
        "content": [
          "normal."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 2421,
    "content": [
      "Which one of the following statements is correct about transverse and longitudinal waves?"
    ],
    "explanation": [
      "This statement correctly defines the two wave types. In longitudinal waves (e.g., sound), particle vibration is parallel to the direction of wave propagation. In transverse waves (e.g., light), particle vibration is perpendicular to the direction of wave propagation."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_SOUND",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9692,
        "content": [
          "The directions of wave motion and vibration of the particles are parallel for transverse waves and perpendicular for longitudinal waves."
        ],
        "isCorrect": false
      },
      {
        "id": 9693,
        "content": [
          "Waves on a string are longitudinal whereas sound waves are transverse."
        ],
        "isCorrect": false
      },
      {
        "id": 9694,
        "content": [
          "The directions of wave motion and vibration of particles are parallel for longitudinal waves but perpendicular for transverse waves."
        ],
        "isCorrect": true
      },
      {
        "id": 9695,
        "content": [
          "A longitudinal wave comprises a series of crests and troughs, whereas a transverse wave comprises a series of compressions and rarefactions."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Mechanical Oscillation and Sound Wave"
  },
  {
    "id": 2422,
    "content": [
      "An object that is partially or fully submerged in a fluid experiences an upward force from the fluid. The apparent weight of the object is the weight of the"
    ],
    "explanation": [
      "The apparent weight of a submerged object is its actual weight (often called weight in air) reduced by the upward buoyant force exerted by the fluid. Apparent Weight = True Weight - Buoyant Force."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9696,
        "content": [
          "fluid it displaces."
        ],
        "isCorrect": false
      },
      {
        "id": 9697,
        "content": [
          "object in air minus the buoyant force."
        ],
        "isCorrect": true
      },
      {
        "id": 9698,
        "content": [
          "object in air."
        ],
        "isCorrect": false
      },
      {
        "id": 9699,
        "content": [
          "fluid it displaces minus the buoyant force."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2423,
    "content": [
      "A force is used to push a box of mass, m along the slop of inclined plane with constant velocity as shown in the figure below.",
      "images/physics/year_2017/q16_1.png",
      "If the coefficient of friction between the box and the inclined plane be µ, the actual mechanical advantage (AMA) of the inclined plane is"
    ],
    "explanation": [
      "Actual Mechanical Advantage (AMA) is the ratio of Load to Effort. The load is the gravitational force being overcome, which is the weight of the box, mg. The effort (F) is the force required to push the box up the incline at a constant velocity. This force must overcome both the component of gravity parallel to the incline (mg sinθ) and the force of friction (µN = µmg cosθ).\n$$\nF_{effort} = mg \\sin\\theta + \\mu mg \\cos\\theta\n$$\n$$\nAMA = \\frac{\\text{Load}}{\\text{Effort}} = \\frac{mg}{mg(\\sin\\theta + \\mu \\cos\\theta)}\n$$\n$$\nAMA = \\frac{1}{\\sin\\theta + \\mu \\cos\\theta}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_FORCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2017/q16_1.png"
    ],
    "choices": [
      {
        "id": 9700,
        "content": [
          "$$\n1/(\\cos\\theta + \\mu\\sin\\theta)\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9701,
        "content": [
          "$$\n1/(\\sin\\theta + \\mu\\cos\\theta)\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 9702,
        "content": [
          "$$\n\\cos\\theta + \\mu\\sin\\theta\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9703,
        "content": [
          "$$\n\\sin\\theta + \\mu\\cos\\theta\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2424,
    "content": [
      "A wheel and axle of radii 40 cm and 8 cm, respectively, is used to lift a bucket of 6 kg of water from a well by applying an effort of 20 N on the wheel. The percentage efficiency of this simple machine is"
    ],
    "explanation": [
      "Efficiency (η) is the ratio of Actual Mechanical Advantage (AMA) to Ideal Mechanical Advantage (IMA), expressed as a percentage.",
      "First, calculate the IMA:\n$$\nIMA = \\frac{\\text{Radius of wheel}}{\\text{Radius of axle}} = \\frac{40 \\text{ cm}}{8 \\text{ cm}} = 5\n$$",
      "Next, calculate the AMA:\n$$\n\\text{Load} = mg = 6 \\text{ kg} \\times 10 \\text{ m/s}^2 = 60 \\text{ N}\n$$\n$$\nAMA = \\frac{\\text{Load}}{\\text{Effort}} = \\frac{60 \\text{ N}}{20 \\text{ N}} = 3\n$$",
      "Finally, calculate the efficiency:\n$$\n\\eta = \\frac{AMA}{IMA} \\times 100\\% = \\frac{3}{5} \\times 100\\% = 60\\%\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9704,
        "content": [
          "60%"
        ],
        "isCorrect": true
      },
      {
        "id": 9705,
        "content": [
          "66.7%"
        ],
        "isCorrect": false
      },
      {
        "id": 9706,
        "content": [
          "30%"
        ],
        "isCorrect": false
      },
      {
        "id": 9707,
        "content": [
          "80%"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 2425,
    "content": [
      "Block A of mass m₁ = 8.0 kg travelling initially at u₁ = 6 m/s in the positive x-direction collides with block B of mass m₂ = 12 kg moving in the same direction at u₂ = 3 m/s. If the velocity of block A, immediately after the collision, is v₁ = 4 m/s to the positive x-axis, what is the velocity of the block B, immediately after the collision?"
    ],
    "explanation": [
      "According to the principle of conservation of linear momentum, the total momentum before the collision is equal to the total momentum after the collision.\n$$\nm_1u_1 + m_2u_2 = m_1v_1 + m_2v_2\n$$\n$$\n(8.0)(6) + (12)(3) = (8.0)(4) + (12)v_2\n$$\n$$\n48 + 36 = 32 + 12v_2\n$$\n$$\n84 = 32 + 12v_2\n$$\n$$\n12v_2 = 84 - 32 = 52\n$$\n$$\nv_2 = \\frac{52}{12} \\approx 4.33 \\text{ m/s}\n$$",
      "Since the result is positive, the velocity is in the positive x-axis direction."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_MOMENTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9708,
        "content": [
          "4.33 m/s to the negative x-axis"
        ],
        "isCorrect": false
      },
      {
        "id": 9709,
        "content": [
          "3.71 m/s to the negative x-axis"
        ],
        "isCorrect": false
      },
      {
        "id": 9710,
        "content": [
          "3.71 m/s to the positive x-axis"
        ],
        "isCorrect": false
      },
      {
        "id": 9711,
        "content": [
          "4.33 m/s to the positive x-axis"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2426,
    "content": [
      "The amount of heat energy required to raise the temperature of a given substance by 1°C is"
    ],
    "explanation": [
      "This is the definition of heat capacity (C), which is the ratio of the heat added to the resulting temperature change ($$C = Q/\\Delta T$$). Specific heat capacity is the heat capacity per unit mass."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9712,
        "content": [
          "latent heat."
        ],
        "isCorrect": false
      },
      {
        "id": 9713,
        "content": [
          "heat capacity."
        ],
        "isCorrect": true
      },
      {
        "id": 9714,
        "content": [
          "quantity of heat."
        ],
        "isCorrect": false
      },
      {
        "id": 9715,
        "content": [
          "specific heat capacity."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Heat Conduction and Calorimetry"
  },
  {
    "id": 2427,
    "content": [
      "Which one of the following statements is correct about the properties of waves?"
    ],
    "explanation": [
      "Diffraction, the bending of waves as they pass around an obstacle or through an aperture, is most significant when the size of the gap is comparable to or smaller than the wavelength of the wave. Therefore, a narrower gap produces more noticeable diffraction effects."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_OPTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9716,
        "content": [
          "When a wave is reflected, its speed and wavelength are changed."
        ],
        "isCorrect": false
      },
      {
        "id": 9717,
        "content": [
          "When a wave is refracted, its speed and wavelength remain the same."
        ],
        "isCorrect": false
      },
      {
        "id": 9718,
        "content": [
          "When two waves interfere destructively, the amplitude of the resultant wave is greater than the amplitude of each wave."
        ],
        "isCorrect": false
      },
      {
        "id": 9719,
        "content": [
          "Diffraction of a wave through a narrow gap is more observable than through a wider gap."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Electromagnetic Waves and Geometrical Optics"
  },
  {
    "id": 2428,
    "content": [
      "A square metal plate of coefficient of linear expansion α, has a surface area A₀ at a temperature T₀. If the temperature is raised by an amount ΔT, then the plate surface area is changed to A which is expressed as"
    ],
    "explanation": [
      "For isotropic materials, the coefficient of superficial (area) expansion, β, is approximately twice the coefficient of linear expansion, α (β ≈ 2α). The formula for area expansion is A = A₀(1 + βΔT). Substituting β with 2α gives A = A₀(1 + 2αΔT)."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9720,
        "content": [
          "A = A₀(1 + αΔT)"
        ],
        "isCorrect": false
      },
      {
        "id": 9721,
        "content": [
          "A = A₀(1 + 3αΔT)"
        ],
        "isCorrect": false
      },
      {
        "id": 9722,
        "content": [
          "A = A₀(1 + 2αΔT)"
        ],
        "isCorrect": true
      },
      {
        "id": 9723,
        "content": [
          "A = 2A₀(1 + αΔT)"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 2429,
    "content": [
      "The atmospheric pressure in a certain area is determined to be 103.36 kPa, using a mercury barometer shown in the figure below. (Acceleration due to gravity, g = 10 m/s², and density of mercury, ρₘ = 13.6 × 10³ kg/m³)",
      "images/physics/year_2017/q22_1_background.png",
      "The height to which the mercury column rises is about"
    ],
    "explanation": [
      "The atmospheric pressure supports the column of mercury. The pressure exerted by the mercury column is given by $$P = \\rho gh$$. We can solve for the height, h.\n$$\nP = 103.36 \\text{ kPa} = 103360 \\text{ Pa}\n$$\n$$\nh = \\frac{P}{\\rho g}\n$$\n$$\nh = \\frac{103360 \\text{ Pa}}{(13.6 \\times 10^3 \\text{ kg/m}^3)(10 \\text{ m/s}^2)}\n$$\n$$\nh = \\frac{103360}{136000} \\text{ m} = 0.76 \\text{ m}\n$$",
      "Converting meters to centimeters: 0.76 m = 76 cm."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_PRESSURE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2017/q22_1_background.png"
    ],
    "choices": [
      {
        "id": 9724,
        "content": [
          "7.6 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9725,
        "content": [
          "760 cm"
        ],
        "isCorrect": false
      },
      {
        "id": 9726,
        "content": [
          "76 mm"
        ],
        "isCorrect": false
      },
      {
        "id": 9727,
        "content": [
          "76 cm"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2430,
    "content": [
      "An object dropped into a sea sinks to a depth of 100 m. Which of the following is correct about the pressure the object experiences? (Assume the density of seawater is 1030 kg/m³ and the air above the see exerts a pressure of $$P_{atmospheric}$$ = 1.00 × 10⁵ Pa, g = 10 m/s²)"
    ],
    "explanation": [
      "First, calculate the gauge pressure (pressure due to the water column) using $$P_{gauge} = \\rho gh$$.\n$$\nP_{gauge} = (1030 \\text{ kg/m}^3)(10 \\text{ m/s}^2)(100 \\text{ m})\n$$\n$$\nP_{gauge} = 1,030,000 \\text{ Pa} = 1.03 \\times 10^6 \\text{ Pa}\n$$",
      "The absolute pressure is the sum of the atmospheric pressure and the gauge pressure.\n$$\nP_{absolute} = P_{atmospheric} + P_{gauge}\n$$\n$$\nP_{absolute} = 1.00 \\times 10^5 \\text{ Pa} + 1.03 \\times 10^6 \\text{ Pa}\n$$\n$$\nP_{absolute} = 0.1 \\times 10^6 \\text{ Pa} + 1.03 \\times 10^6 \\text{ Pa} = 1.13 \\times 10^6 \\text{ Pa}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_PRESSURE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9728,
        "content": [
          "The absolute pressure exerted on it is $$P_{absolute}$$ = 1.13 × 10⁶ Pa."
        ],
        "isCorrect": true
      },
      {
        "id": 9729,
        "content": [
          "The gauge pressure exerted on it is $$P_{gauge}$$ = 1.03 × 10⁷ Pa."
        ],
        "isCorrect": false
      },
      {
        "id": 9730,
        "content": [
          "The gauge pressure exerted on it is $$P_{gauge}$$ = 1.01 × 10⁵ Pa."
        ],
        "isCorrect": false
      },
      {
        "id": 9731,
        "content": [
          "The absolute pressure exerted on it is $$P_{absolute}$$ = 9.30 × 10⁵ Pa."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2431,
    "content": [
      "How much heat energy is required to change 5 kg of ice at -20 °C to water at 10 °C? (Specific heat capacities of water in liquid and solid phases are 4.2 kJ/kg°C and 2.1 kJ/kg°C, respectively, and latent heat of fusion of water, $$L_f$$ = 336000 J/kg)."
    ],
    "explanation": [
      "The total heat required is the sum of three steps:\n\nHeating the ice from -20°C to 0°C:\n$$\nQ_1 = mc_{ice}\\Delta T\n$$\n$$\n= (5 \\text{ kg})(2100 \\text{ J/kg°C})(0 - (-20))\n$$\n$$\n= 210,000 \\text{ J}\n$$\nMelting the ice at 0°C:\n$$\nQ_2 = mL_f = (5 \\text{ kg})(336000 \\text{ J/kg})\n$$\n$$\n= 1,680,000 \\text{ J}\n$$\nHeating the water from 0°C to 10°C:\n$$\nQ_3 = mc_{water}\\Delta T\n$$\n$$\n= (5 \\text{ kg})(4200 \\text{ J/kg°C})(10 - 0)\n$$\n$$\n= 210,000 \\text{ J}\n$$\nTotal Heat $$Q_{total}$$ = $$Q_1 + Q_2 + Q_3$$:\n$$\nQ_{total} = 210,000 + 1,680,000 + 210,000\n$$\n$$\n= 2,100,000 \\text{ J}\n$$\n$$\nQ_{total} = 2.10 \\times 10^6 \\text{ J}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9732,
        "content": [
          "2.10 × 10⁶ J"
        ],
        "isCorrect": true
      },
      {
        "id": 9733,
        "content": [
          "1.89 × 10⁶ J"
        ],
        "isCorrect": false
      },
      {
        "id": 9734,
        "content": [
          "4.20 × 10⁵ J"
        ],
        "isCorrect": false
      },
      {
        "id": 9735,
        "content": [
          "1.68 × 10⁶ J"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Heat Conduction and Calorimetry"
  },
  {
    "id": 2432,
    "content": [
      "An electric field is defined as a region where"
    ],
    "explanation": [
      "An electric field is a vector field that associates to each point in space the electrostatic force per unit of charge exerted on an infinitesimal positive test charge at rest at that point. In simpler terms, it is a region where an electric charge will experience a force."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9736,
        "content": [
          "a neutral particle experiences electric force when it is placed in that region."
        ],
        "isCorrect": false
      },
      {
        "id": 9737,
        "content": [
          "a charged particle experiences an electric force if it is placed in that region."
        ],
        "isCorrect": true
      },
      {
        "id": 9738,
        "content": [
          "a charged particle losses its charge when it is placed in that region."
        ],
        "isCorrect": false
      },
      {
        "id": 9739,
        "content": [
          "a charged particle experiences no electric force when it is placed in that region."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 2433,
    "content": [
      "Which one of the following statements is correct about the speed of sound in different medium? The speed of sound"
    ],
    "explanation": [
      "Options A, B, and D are incorrect general rules. Sound generally travels fastest in solids, then liquids, then gases. It travels slower in denser media (of the same type) but faster in materials with higher stiffness. Option C is worded ambiguously but is the only potentially correct statement, as some less dense materials (like helium) can transmit sound faster than denser materials (like hot air), though temperature also plays a role."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_SOUND",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9740,
        "content": [
          "increases as the temperature and density of a material increases."
        ],
        "isCorrect": false
      },
      {
        "id": 9741,
        "content": [
          "in liquid is less than its speed in gas."
        ],
        "isCorrect": false
      },
      {
        "id": 9742,
        "content": [
          "in a colder and less dense medium is faster than in hotter and denser material."
        ],
        "isCorrect": true
      },
      {
        "id": 9743,
        "content": [
          "in solid is less than its speed in liquid."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Mechanical Oscillation and Sound Wave"
  },
  {
    "id": 2434,
    "content": [
      "Four resistors are connected to a voltage source as shown in the figure below.",
      "images/physics/year_2017/q27_1.png",
      "Which one of the following is correct about the circuit?"
    ],
    "explanation": [
      "In the circuit, the total current flows sequentially through R₁, R₂, and then through the parallel combination of R₃ and R₄. Since R₁, R₂, and the parallel block (R₃ || R₄) are all in the same single path for the total current, they are all in series with each other. Therefore, R₁ is in series with the effective resistance of the parallel R₃ and R₄ combination."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2017/q27_1.png"
    ],
    "choices": [
      {
        "id": 9744,
        "content": [
          "R₁ is connected in series with the effective combination of R₃ and R₄."
        ],
        "isCorrect": true
      },
      {
        "id": 9745,
        "content": [
          "R₂ is connected in parallel with the effective combination of R₃ and R₄."
        ],
        "isCorrect": false
      },
      {
        "id": 9746,
        "content": [
          "R₂ is connected in parallel with R₃."
        ],
        "isCorrect": false
      },
      {
        "id": 9747,
        "content": [
          "R₁ is connected in parallel with R₂."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 2435,
    "content": [
      "What is the magnitude of electric field strength at a distance of 2.0 m from a point charge, Q = 4.0 C?"
    ],
    "explanation": [
      "The magnitude of the electric field (E) from a point charge (Q) is given by Coulomb's law: $$E = kQ/r^2$$, where k is Coulomb's constant.\n$$\nE = \\frac{(9 \\times 10^9 \\text{ Nm}^2/\\text{C}^2)(4.0 \\text{ C})}{(2.0 \\text{ m})^2}\n$$\n$$\nE = \\frac{36 \\times 10^9}{4.0}\n$$\n$$\nE = 9.0 \\times 10^9 \\text{ N/C}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9748,
        "content": [
          "54.0 × 10⁹ N/C"
        ],
        "isCorrect": false
      },
      {
        "id": 9749,
        "content": [
          "18.0 × 10⁹ N/C"
        ],
        "isCorrect": false
      },
      {
        "id": 9750,
        "content": [
          "9.0 × 10⁹ N/C"
        ],
        "isCorrect": true
      },
      {
        "id": 9751,
        "content": [
          "72.0 × 10⁹ N/C"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 2436,
    "content": [
      "A wire that has a resistance of 6 Ω is drawn out so as to make it into a new wire two times as long as the original and half cross-sectional area of the original. What will be the resistance of the new wire?"
    ],
    "explanation": [
      "The resistance of a wire is given by $$R = \\rho L/A$$, where L is the length and A is the cross-sectional area. The new length $$L' = 2L$$ and new area $$A' = A/2$$.",
      "The new resistance R' will be:\n$$\nR' = \\rho \\frac{L'}{A'} = \\rho \\frac{2L}{A/2}\n$$\n$$\nR' = 4 \\left( \\rho \\frac{L}{A} \\right) = 4R\n$$\n$$\nR' = 4 \\times 6 \\Omega = 24 \\Omega\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9752,
        "content": [
          "3 Ω"
        ],
        "isCorrect": false
      },
      {
        "id": 9753,
        "content": [
          "24 Ω"
        ],
        "isCorrect": true
      },
      {
        "id": 9754,
        "content": [
          "12 Ω"
        ],
        "isCorrect": false
      },
      {
        "id": 9755,
        "content": [
          "6 Ω"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 2437,
    "content": [
      "A long straight wire carries a current of 5.0 A. What is the magnetic field strength produced by the current at a distance of 2.0 cm from the wire? (Magnetic permeability free space µ₀ = 4π × 10⁻⁷ Tm/A)"
    ],
    "explanation": [
      "The magnetic field (B) at a distance (r) from a long, straight wire carrying current (I) is given by the formula $$B = (\\mu_0I) / (2\\pi r)$$.\n$$\nB = \\frac{(4\\pi \\times 10^{-7} \\text{ Tm/A})(5.0 \\text{ A})}{2\\pi(0.02 \\text{ m})}\n$$\n$$\nB = \\frac{2 \\times 10^{-7} \\times 5.0}{0.02}\n$$\n$$\nB = \\frac{10 \\times 10^{-7}}{0.02}\n$$\n$$\nB = 500 \\times 10^{-7} \\text{ T} = 5 \\times 10^{-5} \\text{ T}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9756,
        "content": [
          "20 × 10⁻⁵ T"
        ],
        "isCorrect": false
      },
      {
        "id": 9757,
        "content": [
          "5 × 10⁻⁵ T"
        ],
        "isCorrect": true
      },
      {
        "id": 9758,
        "content": [
          "5π × 10⁻⁵ T"
        ],
        "isCorrect": false
      },
      {
        "id": 9759,
        "content": [
          "20π × 10⁻⁵ T"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2438,
    "content": [
      "If two vectors a and b, with respective magnitudes of a and b, form an angle α between them when they are connected tail to tail, then the expression ab cos α defines the value of"
    ],
    "explanation": [
      "The expression ab cos(α) is the definition of the scalar product (or dot product) of two vectors a and b."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9760,
        "content": [
          "scalar product of a and b."
        ],
        "isCorrect": true
      },
      {
        "id": 9761,
        "content": [
          "resultant of a and b."
        ],
        "isCorrect": false
      },
      {
        "id": 9762,
        "content": [
          "projection of a on b."
        ],
        "isCorrect": false
      },
      {
        "id": 9763,
        "content": [
          "vector product of a and b."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Vectors"
  },
  {
    "id": 2439,
    "content": [
      "Which one of the following statements is correct about real and virtual images?"
    ],
    "explanation": [
      "A key difference between real and virtual images is that real images are formed by the actual convergence of light rays at a point. This allows them to be projected onto a screen. Virtual images are formed where light rays only appear to originate from and cannot be projected."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_OPTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9764,
        "content": [
          "Real images can be magnified but virtual images cannot."
        ],
        "isCorrect": false
      },
      {
        "id": 9765,
        "content": [
          "Virtual images can be magnified but real images cannot."
        ],
        "isCorrect": false
      },
      {
        "id": 9766,
        "content": [
          "Virtual images can be displayed on a screen unlike the real ones."
        ],
        "isCorrect": false
      },
      {
        "id": 9767,
        "content": [
          "Real images can be displayed on a screen unlike the virtual ones."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Electromagnetic Waves and Geometrical Optics"
  },
  {
    "id": 2440,
    "content": [
      "An object moving in one dimension with constant acceleration a travels through a displacement s in a time interval t. If its velocity at the initial time t = 0 is vᵢ and its velocity at a later time t is vբ, which of the following is a correct relation between the given quantities?"
    ],
    "explanation": [
      "We can derive this kinematic equation. Start with the standard equation $$s = v_i t + \\frac{1}{2}at^2$$. We also know that $$v_f = v_i + at$$, which can be rearranged to $$v_i = v_f - at$$. Substituting this expression for $$v_i$$ into the first equation:\n$$\ns = (v_f - at)t + \\frac{1}{2}at^2\n$$\n$$\ns = v_f t - at^2 + \\frac{1}{2}at^2\n$$\n$$\ns = v_f t - \\frac{1}{2}at^2\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9768,
        "content": [
          "$$s = \\frac{(v_f - v_i)}{2} t$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9769,
        "content": [
          "$$s = v_i t + \\frac{1}{2} at^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9770,
        "content": [
          "$$s = \\frac{v_f^2 - v_i^2}{a}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9771,
        "content": [
          "$$s = v_f t - \\frac{1}{2} at^2$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Uniformly Accelerated Motion"
  },
  {
    "id": 2441,
    "content": [
      "If the critical angle for an optically denser medium to air boundary is 53°, what will be the refractive index of the medium? (Assume the index of refraction of air is 1.00, sin53° = 0.8)"
    ],
    "explanation": [
      "The critical angle ($$\\theta_c$$) is related to the refractive indices of the two media ($$n_1$$ for the denser medium, $$n_2$$ for the less dense medium) by the formula $$\\sin(\\theta_c) = n_2/n_1$$. Here, $$n_2$$ is the refractive index of air (1.00) and $$\\theta_c$$ = 53°.\n$$\n\\sin(53^\\circ) = \\frac{n_{air}}{n_{medium}}\n$$\n$$\nn_{medium} = \\frac{n_{air}}{\\sin(53^\\circ)}\n$$\n$$\nn_{medium} = \\frac{1.00}{0.8} = 1.25\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_OPTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9772,
        "content": [
          "1.25"
        ],
        "isCorrect": true
      },
      {
        "id": 9773,
        "content": [
          "1.00"
        ],
        "isCorrect": false
      },
      {
        "id": 9774,
        "content": [
          "1.33"
        ],
        "isCorrect": false
      },
      {
        "id": 9775,
        "content": [
          "1.67"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Electromagnetic Waves and Geometrical Optics"
  },
  {
    "id": 2442,
    "content": [
      "Given the displacement vector A = (3 î - 4 ĵ) m, what is the unit vector in the direction of A?"
    ],
    "explanation": [
      "To find the unit vector, first calculate the magnitude of vector A.\n$$\n|A| = \\sqrt{3^2 + (-4)^2} = \\sqrt{9 + 16} = \\sqrt{25} = 5 \\text{ m}\n$$",
      "Then, divide the vector A by its magnitude.\n$$\n\\hat{A} = \\frac{A}{|A|} = \\frac{3 \\hat{i} - 4 \\hat{j}}{5}\n$$\n$$\n\\hat{A} = \\frac{3}{5}\\hat{i} - \\frac{4}{5}\\hat{j} = 0.6 \\hat{i} - 0.8 \\hat{j}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9776,
        "content": [
          "0.6 î + 0.8 ĵ"
        ],
        "isCorrect": false
      },
      {
        "id": 9777,
        "content": [
          "0.8 î - 0.6 ĵ"
        ],
        "isCorrect": false
      },
      {
        "id": 9778,
        "content": [
          "0.6 î - 0.8 ĵ"
        ],
        "isCorrect": true
      },
      {
        "id": 9779,
        "content": [
          "- 0.6 î + 0.8 ĵ"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Vectors"
  },
  {
    "id": 2443,
    "content": [
      "Suppose that you are given two forces with F₁ = 75 N in the direction of 53° west of north and F₂ = 100 N in the direction of 37° east of north. If you add the two forces using analytical and graphical methods and represent using graphical scale of 1 cm for 10 N force, what are the possible length and direction of the arrow line for the resultant vector?"
    ],
    "explanation": [
      "Resolve each force into its x (East-West) and y (North-South) components. Let North be the positive y-axis and East be the positive x-axis.",
      "For F₁ (53° West of North):\n$$\nF_{1x} = -75 \\sin(53^\\circ) = -75(0.8) = -60 \\text{ N}\n$$\n$$\nF_{1y} = +75 \\cos(53^\\circ) = +75(0.6) = 45 \\text{ N}\n$$",
      "For F₂ (37° East of North):\n$$\nF_{2x} = +100 \\sin(37^\\circ) = +100(0.6) = 60 \\text{ N}\n$$\n$$\nF_{2y} = +100 \\cos(37^\\circ) = +100(0.8) = 80 \\text{ N}\n$$",
      "Sum the components to find the resultant force R:\n$$\nR_x = F_{1x} + F_{2x} = -60 + 60 = 0 \\text{ N}\n$$\n$$\nR_y = F_{1y} + F_{2y} = 45 + 80 = 125 \\text{ N}\n$$",
      "The resultant force is 125 N in the positive y-direction (due North). Using the scale 1 cm = 10 N, the length is 125 N / (10 N/cm) = 12.5 cm."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9780,
        "content": [
          "1.73 cm to 45° North of East"
        ],
        "isCorrect": false
      },
      {
        "id": 9781,
        "content": [
          "1.25 cm to the North"
        ],
        "isCorrect": false
      },
      {
        "id": 9782,
        "content": [
          "17.3 cm to 45° North of East"
        ],
        "isCorrect": false
      },
      {
        "id": 9783,
        "content": [
          "12.5 cm to the North"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 2444,
    "content": [
      "Suppose a particle of mass, m is tied to a string and then whirled around in a horizontal circle of radius r about the center O as shown in the figure below.",
      "images/physics/year_2017/q37_1.png",
      "If the string makes an angle of θ to the vertical while rotating, the component of the force that is responsible for the circular motion of the mass by providing the centripetal force is"
    ],
    "explanation": [
      "The tension (T) in the string can be resolved into two components. The vertical component, T cosθ, balances the weight of the particle (mg). The horizontal component, T sinθ, is directed towards the center of the circular path and provides the necessary centripetal force to maintain the circular motion."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2017/q37_1.png"
    ],
    "choices": [
      {
        "id": 9784,
        "content": [
          "T sinθ"
        ],
        "isCorrect": true
      },
      {
        "id": 9785,
        "content": [
          "T cosθ"
        ],
        "isCorrect": false
      },
      {
        "id": 9786,
        "content": [
          "mg sinθ"
        ],
        "isCorrect": false
      },
      {
        "id": 9787,
        "content": [
          "mg cosθ"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2445,
    "content": [
      "Which one of the following statements is correct about the fundamental forces in nature and their applications?"
    ],
    "explanation": [
      "Gravitational force is the weakest of the four fundamental forces but acts over infinite distances, making it the dominant force governing the motion of celestial bodies like planets, stars, and galaxies. The other statements incorrectly describe the roles of the nuclear and electromagnetic forces."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_FORCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9788,
        "content": [
          "The force that keeps the nucleus of an atom from flying apart due to the repulsive force between protons is the weak nuclear force."
        ],
        "isCorrect": false
      },
      {
        "id": 9789,
        "content": [
          "The gravitational force makes planets to revolve around the Sun and to follow their orbital path."
        ],
        "isCorrect": true
      },
      {
        "id": 9790,
        "content": [
          "The force that arises in most radioactive processes and in nuclear reactions that generate the Sun's energy is the strong nuclear force."
        ],
        "isCorrect": false
      },
      {
        "id": 9791,
        "content": [
          "The electromagnetic force is the force that keeps protons and neutrons bound together in the nucleus of an atom."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2446,
    "content": [
      "A spring stores 120 J of elastic potential energy when it is stretched by 0.5 m. What is the potential energy stored by the spring when it is stretched by 1.5 m?"
    ],
    "explanation": [
      "Elastic potential energy (PE) is given by $$PE = \\frac{1}{2}kx^2$$, where k is the spring constant and x is the stretch distance.",
      "First, find the spring constant k:\n$$\n120 \\text{ J} = \\frac{1}{2} k (0.5 \\text{ m})^2\n$$\n$$\n120 = \\frac{1}{2} k (0.25)\n$$\n$$\nk = \\frac{120}{0.125} = 960 \\text{ N/m}\n$$",
      "Now, calculate the potential energy for a stretch of 1.5 m:\n$$\nPE = \\frac{1}{2} (960 \\text{ N/m}) (1.5 \\text{ m})^2\n$$\n$$\nPE = 480 \\times 2.25 = 1080 \\text{ J}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9792,
        "content": [
          "480 J"
        ],
        "isCorrect": false
      },
      {
        "id": 9793,
        "content": [
          "960 J"
        ],
        "isCorrect": false
      },
      {
        "id": 9794,
        "content": [
          "1080 J"
        ],
        "isCorrect": true
      },
      {
        "id": 9795,
        "content": [
          "540 J"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 2447,
    "content": [
      "The velocity-time graph of an object moving in a straight line is shown in the figure below.",
      "images/physics/year_2017/q40_1.png",
      "What is the magnitude of the total displacement covered by the object in the time interval of 14 seconds?"
    ],
    "explanation": [
      "The total displacement (∆x) is the net signed area under the velocity-time graph. We calculate the area below the axis (t=0 to t=2s) and the area above the axis (t=2 to t=14 s).\n$$\n\\text{Area}_{\\text{Negative}} = \\frac{1}{2} \\times 2 \\times (-6) = -6 \\text{ m}\n$$\n$$\n\\text{Area}{\\text{Positive}} = \\text{Area}{\\text{Trapezoid } (2-14)}\n$$\n$$\n\\text{Area}_{\\text{Positive}} = \\frac{1}{2} \\times [(14-2) + (10-6)] \\times 12\n$$\n$$\n\\text{Area}_{\\text{Positive}} = \\frac{1}{2} \\times [16] \\times 12 = 96 \\text{ m}\n$$\n$$\n\\text{Total Displacement } (\\Delta x) = -6 \\text{ m} + 96 \\text{ m}\n$$\n$$\n\\Delta x = 90 \\text{ m}\n$$\nThe magnitude of the total displacement is:\n$$\n|\\Delta x| = 90 \\text{ m}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2017/q40_1.png"
    ],
    "choices": [
      {
        "id": 9796,
        "content": [
          "102 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9797,
        "content": [
          "90 m"
        ],
        "isCorrect": true
      },
      {
        "id": 9798,
        "content": [
          "54 m"
        ],
        "isCorrect": false
      },
      {
        "id": 9799,
        "content": [
          "42 m"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 2448,
    "content": [
      "A crane at port is used to lift 10,000 kg object to a height of 20 m. If the power developed by the crane is 50,000 W, how long does it take to lift the object? (Acceleration due to gravity, g = 10 m/s²)"
    ],
    "explanation": [
      "Power is the rate at which work is done ($$P = W/t$$). The work done (W) in lifting the object is equal to the change in its gravitational potential energy, $$W = mgh$$.\n$$\nW = (10,000 \\text{ kg})(10 \\text{ m/s}^2)(20 \\text{ m}) = 2,000,000 \\text{ J}\n$$",
      "Time taken can be found by rearranging the power formula: $$t = W/P$$.\n$$\nt = \\frac{2,000,000 \\text{ J}}{50,000 \\text{ W}} = 40 \\text{ s}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9800,
        "content": [
          "400 s"
        ],
        "isCorrect": false
      },
      {
        "id": 9801,
        "content": [
          "40 s"
        ],
        "isCorrect": true
      },
      {
        "id": 9802,
        "content": [
          "4 s"
        ],
        "isCorrect": false
      },
      {
        "id": 9803,
        "content": [
          "2 s"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 2449,
    "content": [
      "A system of four masses m₁ = 4 kg, m₂ = 4 kg, m₃ = 5 kg and m₄ = 3 kg are located in the xy-plane at the coordinates of (0, 0), (30 cm, 0), (-40 cm, 0) and (0, 20 cm), respectively. What is the coordinate of the center of mass of the system?"
    ],
    "explanation": [
      "The coordinates of the center of mass ($$x_{cm}, y_{cm}$$) are calculated as the weighted average of the positions of the masses.\n$$\nx_{cm} = \\frac{\\sum m_i x_i}{\\sum m_i} = \\frac{(4)(0) + (4)(30) + (5)(-40) + (3)(0)}{4+4+5+3}\n$$\n$$\nx_{cm} = \\frac{0 + 120 - 200 + 0}{16} = \\frac{-80}{16} = -5 \\text{ cm}\n$$\n$$\ny_{cm} = \\frac{\\sum m_i y_i}{\\sum m_i} = \\frac{(4)(0) + (4)(0) + (5)(0) + (3)(20)}{16}\n$$\n$$\ny_{cm} = \\frac{0 + 0 + 0 + 60}{16} = \\frac{60}{16} = 3.75 \\text{ cm}\n$$",
      "The center of mass is at (-5 cm, 3.75 cm)."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9804,
        "content": [
          "(20 cm, 3.75 cm)"
        ],
        "isCorrect": false
      },
      {
        "id": 9805,
        "content": [
          "(-6.7 cm, 5 cm)"
        ],
        "isCorrect": false
      },
      {
        "id": 9806,
        "content": [
          "(-5 cm, 10 cm)"
        ],
        "isCorrect": false
      },
      {
        "id": 9807,
        "content": [
          "(-5 cm, 3.75 cm)"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2450,
    "content": [
      "Which of the following concepts of physics are the primary focus points in mechanical engineering?"
    ],
    "explanation": [
      "Mechanical engineering is a broad field based heavily on the principles of mechanics (which includes dynamics, forces, and stress analysis of materials) and thermal-fluid sciences (thermodynamics, heat transfer). The other options include fields like optics and nuclear physics, which are not central to mechanical engineering."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9808,
        "content": [
          "Dynamics, Thermodynamics, Force, and Stress"
        ],
        "isCorrect": true
      },
      {
        "id": 9809,
        "content": [
          "Geometric optics, Electrostatics, Thermodynamics, and Stress"
        ],
        "isCorrect": false
      },
      {
        "id": 9810,
        "content": [
          "Molecular physics, Dynamics, Nuclear physics, and Force"
        ],
        "isCorrect": false
      },
      {
        "id": 9811,
        "content": [
          "Nuclear physics, Geometric optics, Dynamics, and Force"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2451,
    "content": [
      "Which one of the following defense technologies is correctly matched with its working principle?"
    ],
    "explanation": [
      "Infrared devices work by detecting thermal radiation (heat) that objects emit. This allows them to \"see\" in the absence of visible light. The other options are incorrect: A describes a missile, not radar. B and C incorrectly attribute the working principle of radar to missiles and drones."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9812,
        "content": [
          "A radar is a rocket propelled weapon designed to deliver an explosive weapon with a great accuracy at high speed."
        ],
        "isCorrect": false
      },
      {
        "id": 9813,
        "content": [
          "Missiles radiate electromagnetic signal and examine the echo received to identify the location of the target."
        ],
        "isCorrect": false
      },
      {
        "id": 9814,
        "content": [
          "Drones radiate electromagnetic signal and examine the echo received to identify the location of the target."
        ],
        "isCorrect": false
      },
      {
        "id": 9815,
        "content": [
          "Infrared device uses heat emission to identify objects that cannot be detected using available light sources."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Magnetism"
  },
  {
    "id": 2452,
    "content": [
      "Which one of the following phenomena occurs during change of phases of a matter? During a phase change from"
    ],
    "explanation": [
      "Phase changes occur at a constant temperature. The transition from liquid to gas (boiling/evaporation) requires energy input to overcome intermolecular forces, so heat is absorbed. This is known as the latent heat of vaporization."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9816,
        "content": [
          "solid to liquid, heat energy is released from a substance while its temperature remains constant."
        ],
        "isCorrect": false
      },
      {
        "id": 9817,
        "content": [
          "gas to liquid, heat energy is absorbed by a substance while its temperature remains constant."
        ],
        "isCorrect": false
      },
      {
        "id": 9818,
        "content": [
          "liquid to gas, heat energy is absorbed by a substance while its temperature remains constant."
        ],
        "isCorrect": true
      },
      {
        "id": 9819,
        "content": [
          "liquid to solid, heat energy is released from a substance while its temperature changes uniformly."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 2453,
    "content": [
      "Assume that a ball is thrown horizontally from a building of height h above the ground with initial speed v₀. Which one of the following statements is correct about the motion of the object?"
    ],
    "explanation": [
      "For projectile motion, assuming negligible air resistance, the only force acting on the object is gravity, which acts vertically downwards. Since there is no horizontal force, there is no horizontal acceleration. Consequently, the horizontal component of velocity remains constant throughout the motion."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9820,
        "content": [
          "Its vertical component velocity remains constant."
        ],
        "isCorrect": false
      },
      {
        "id": 9821,
        "content": [
          "Its horizontal component acceleration is zero."
        ],
        "isCorrect": true
      },
      {
        "id": 9822,
        "content": [
          "Its horizontal component velocity uniformly increases."
        ],
        "isCorrect": false
      },
      {
        "id": 9823,
        "content": [
          "Its vertical component acceleration is zero."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 2454,
    "content": [
      "A projectile is thrown from a level ground with an initial velocity $$v_0$$ making an angle of θ above the horizontal. If the maximum height covered by the projectile is H, what is the horizontal range of the projectile in terms of H and θ?"
    ],
    "explanation": [
      "The formulas for maximum height (H) and horizontal range (R) are:\n$$\nH = \\frac{v_0^2 \\sin^2\\theta}{2g}\n$$\n$$\nR = \\frac{v_0^2 \\sin(2\\theta)}{g} = \\frac{2v_0^2 \\sin\\theta \\cos\\theta}{g}\n$$",
      "From the height equation, we can express $$v_0^2$$:\n$$\nv_0^2 = \\frac{2gH}{\\sin^2\\theta}\n$$",
      "Substitute this into the range equation:\n$$\nR = \\frac{2 \\left(\\frac{2gH}{\\sin^2\\theta}\\right) \\sin\\theta \\cos\\theta}{g}\n$$\n$$\nR = \\frac{4gH \\sin\\theta \\cos\\theta}{g \\sin^2\\theta}\n$$\n$$\nR = 4H \\frac{\\cos\\theta}{\\sin\\theta} = \\frac{4H}{\\tan\\theta}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9824,
        "content": [
          "H tanθ"
        ],
        "isCorrect": false
      },
      {
        "id": 9825,
        "content": [
          "$$\\frac{H}{\\tan\\theta}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9826,
        "content": [
          "$$\\frac{H}{4 \\tan\\theta}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9827,
        "content": [
          "$$\\frac{4H}{\\tan\\theta}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 2455,
    "content": [
      "Four point masses m₁=4 kg, m₂=1 kg, m₃=3 kg and m₄=5 kg are attached to a massless road which lays on the x-axis as shown in the figure below.",
      "images/physics/year_2017/q48_1.png",
      "How much is the moment of inertia of the system about the y-axis?"
    ],
    "explanation": [
      "The formula for the moment of inertia ($$I_y$$) about the y-axis for a system of point masses is:\n$$\nI_y = \\sum m_i x_i^2\n$$\nSubstituting the given values:\n$$\nI_y = m_1 x_1^2 + m_2 x_2^2 + m_3 x_3^2 + m_4 x_4^2\n$$\n$$\nI_y = (4)(5)^2 + (1)(2)^2 + (3)(0)^2 + (5)(-4)^2\n$$\n$$\nI_y = (4)(25) + (1)(4) + (3)(0) + (5)(16)\n$$\n$$\nI_y = 100 + 4 + 0 + 80\n$$\n$$\nI_y = 184 \\text{ kg} \\cdot \\text{m}^2\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2017/q48_1.png"
    ],
    "choices": [
      {
        "id": 9828,
        "content": [
          "184 kgm²"
        ],
        "isCorrect": true
      },
      {
        "id": 9829,
        "content": [
          "187 kgm²"
        ],
        "isCorrect": false
      },
      {
        "id": 9830,
        "content": [
          "84 kgm²"
        ],
        "isCorrect": false
      },
      {
        "id": 9831,
        "content": [
          "190 kgm²"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2456,
    "content": [
      "The flow rate of a fluid is defined as"
    ],
    "explanation": [
      "Volumetric flow rate (often just called flow rate) is the volume of fluid that passes through a given surface per unit time. It is a fundamental quantity in fluid dynamics. Mass flow rate is the mass per unit time."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9832,
        "content": [
          "the speed with which the fluid flowing through a pipe."
        ],
        "isCorrect": false
      },
      {
        "id": 9833,
        "content": [
          "the volume of the fluid crossing an area per unit time taken."
        ],
        "isCorrect": true
      },
      {
        "id": 9834,
        "content": [
          "the rate of change of the speed with which fluid flowing through a pipe."
        ],
        "isCorrect": false
      },
      {
        "id": 9835,
        "content": [
          "the mass of the fluid crossing an area per unit time taken."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2457,
    "content": [
      "At normal condition, solids are almost incompressible compared to liquids and gases. The reason is that"
    ],
    "explanation": [
      "In the solid state, particles (atoms or molecules) are tightly packed in a fixed, often crystalline, structure. The strong intermolecular forces hold them in place, allowing only for vibrations about their fixed positions. This rigid structure strongly resists changes in volume, making solids nearly incompressible."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_DENSITY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9836,
        "content": [
          "their atoms are relatively fixed distance apart and held together."
        ],
        "isCorrect": true
      },
      {
        "id": 9837,
        "content": [
          "their atoms are free to slide about and interact with neighbors."
        ],
        "isCorrect": false
      },
      {
        "id": 9838,
        "content": [
          "there is much space and little force between atoms."
        ],
        "isCorrect": false
      },
      {
        "id": 9839,
        "content": [
          "their atoms vibrate and free to move."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2458,
    "content": [
      "Which of the following statements is correct about magnets?"
    ],
    "explanation": [
      "A fundamental property of magnetism is that magnetic poles always exist in pairs (north and south). There are no known magnetic monopoles. Therefore, if a bar magnet is cut, each resulting piece will be a smaller magnet with its own north and south pole."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9840,
        "content": [
          "Like electric charges, magnetic poles exist in a single isolated form."
        ],
        "isCorrect": false
      },
      {
        "id": 9841,
        "content": [
          "The north pole of one magnet repels the south pole of another magnet."
        ],
        "isCorrect": false
      },
      {
        "id": 9842,
        "content": [
          "If you cut a bar magnet into two, each piece has both north and south poles."
        ],
        "isCorrect": true
      },
      {
        "id": 9843,
        "content": [
          "Unlike permanent magnets, electromagnets are magnets without poles."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Magnetism"
  },
  {
    "id": 2459,
    "content": [
      "A wheel of radius, r = 50 cm, rotates about a fixed perpendicular axis that passes through its center. If the angular speed is ω = 200 rad/s, how much is the tangential speed of a point on the rim of the wheel?"
    ],
    "explanation": [
      "The tangential speed (v) of a point in circular motion is related to its angular speed (ω) and the radius (r) of the circle by the equation $$v = r\\omega$$. Remember to convert the radius to meters.\n$$\nr = 50 \\text{ cm} = 0.5 \\text{ m}\n$$\n$$\nv = (0.5 \\text{ m})(200 \\text{ rad/s}) = 100 \\text{ m/s}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9844,
        "content": [
          "800 m/s"
        ],
        "isCorrect": false
      },
      {
        "id": 9845,
        "content": [
          "10,000 m/s"
        ],
        "isCorrect": false
      },
      {
        "id": 9846,
        "content": [
          "100 m/s"
        ],
        "isCorrect": true
      },
      {
        "id": 9847,
        "content": [
          "80,000 m/s"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 2460,
    "content": [
      "Suppose your mass is measured to be 50 kg. If your friend having a mass of 55 kg is at a distance 2 m apart from you, what is the magnitude of gravitational force between you and your friend?"
    ],
    "explanation": [
      "Use Newton's Law of Universal Gravitation, $$F = G(m_1m_2)/r^2$$, where G = 6.67 × 10⁻¹¹ Nm²/kg².\n$$\nF = \\frac{(6.67 \\times 10^{-11} \\text{ Nm}^2/\\text{kg}^2)(50 \\text{ kg})(55 \\text{ kg})}{(2 \\text{ m})^2}\n$$\n$$\nF = \\frac{(6.67 \\times 10^{-11})(2750)}{4}\n$$\n$$\nF = \\frac{1.834 \\times 10^{-8}}{4} \\approx 4.59 \\times 10^{-8} \\text{ N}\n$$",
      "This rounds to 4.6 × 10⁻⁸ N."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_FORCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9848,
        "content": [
          "9.2 × 10⁻¹¹ N"
        ],
        "isCorrect": false
      },
      {
        "id": 9849,
        "content": [
          "9.2 × 10⁻⁸ N"
        ],
        "isCorrect": false
      },
      {
        "id": 9850,
        "content": [
          "4.6 × 10⁻¹¹ N"
        ],
        "isCorrect": false
      },
      {
        "id": 9851,
        "content": [
          "4.6 × 10⁻⁸ N"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2461,
    "content": [
      "A 10 N force is applied to the smaller circular piston of a hydraulic lift of radius 0.1 m to lift a 2500 N load placed on the larger piston. What is the area of the larger piston?"
    ],
    "explanation": [
      "According to Pascal's principle for a hydraulic lift, the pressure is transmitted equally throughout the fluid, so $$P_1 = P_2$$. This means $$F_1/A_1 = F_2/A_2$$. We can solve for the area of the larger piston, A₂.",
      "First, find the area of the smaller piston, A₁:\n$$\nA_1 = \\pi r^2 = (3.14)(0.1 \\text{ m})^2 = 0.0314 \\text{ m}^2\n$$",
      "Now, solve for A₂:\n$$\nA_2 = A_1 \\frac{F_2}{F_1} = (0.0314 \\text{ m}^2) \\frac{2500 \\text{ N}}{10 \\text{ N}}\n$$\n$$\nA_2 = 0.0314 \\times 250 = 7.85 \\text{ m}^2\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_PRESSURE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9852,
        "content": [
          "0.25 m²"
        ],
        "isCorrect": false
      },
      {
        "id": 9853,
        "content": [
          "2.50 m²"
        ],
        "isCorrect": false
      },
      {
        "id": 9854,
        "content": [
          "7.85 m²"
        ],
        "isCorrect": true
      },
      {
        "id": 9855,
        "content": [
          "3.14 m²"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2462,
    "content": [
      "The magnetic field created by a long straight current carrying wire"
    ],
    "explanation": [
      "The magnetic field lines produced by a current in a long, straight wire form concentric circles around the wire. The direction of the field is given by the right-hand grip rule, and its strength is inversely proportional to the distance from the wire."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9856,
        "content": [
          "is directly proportional to the distance from the wire."
        ],
        "isCorrect": false
      },
      {
        "id": 9857,
        "content": [
          "is inversely proportional to the current in the wire."
        ],
        "isCorrect": false
      },
      {
        "id": 9858,
        "content": [
          "is directed in the same direction as the current."
        ],
        "isCorrect": false
      },
      {
        "id": 9859,
        "content": [
          "forms circular pattern around the wire."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2463,
    "content": [
      "What will happen on a pure semiconductor when it is doped by group III element?"
    ],
    "explanation": [
      "Group III elements (like boron or gallium) have three valence electrons. When doped into a semiconductor like silicon (which has four valence electrons), they create a deficiency of one electron in the covalent bond structure. This \"hole\" acts as a positive charge carrier, resulting in a P-type semiconductor."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9860,
        "content": [
          "It becomes N-type semiconductor."
        ],
        "isCorrect": false
      },
      {
        "id": 9861,
        "content": [
          "It becomes P-type semiconductor."
        ],
        "isCorrect": true
      },
      {
        "id": 9862,
        "content": [
          "It becomes intrinsic semiconductor"
        ],
        "isCorrect": false
      },
      {
        "id": 9863,
        "content": [
          "It gets extra free electrons."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 2464,
    "content": [
      "We usually use plastic materials to cover metallic wires that carry electricity to protect living things from danger. Which of the following statement correctly describes the nature of the plastic to use for this purpose?"
    ],
    "explanation": [
      "Plastics are electrical insulators. In insulators, the valence electrons are very tightly bound to their atoms and are not free to move throughout the material. This high resistance to electron flow prevents the passage of electric current, making plastics excellent for insulating wires and ensuring safety."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9864,
        "content": [
          "Since it has free electrons, it facilitates the easy flow of electric current in the metallic wires."
        ],
        "isCorrect": false
      },
      {
        "id": 9865,
        "content": [
          "Since it has no free electrons, it directs the electrons in the wire to flow in the same direction."
        ],
        "isCorrect": false
      },
      {
        "id": 9866,
        "content": [
          "Since every electron in plastic is slightly bound to the parent atom, it becomes poor conductor."
        ],
        "isCorrect": false
      },
      {
        "id": 9867,
        "content": [
          "Since every electron in plastic is tightly bound to the parent atom, it becomes poor conductor."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 2465,
    "content": [
      "Which one of the following statements is correct about the current-voltage (I-V) characteristics of a typical semiconductor diode?"
    ],
    "explanation": [
      "When a diode is forward-biased, very little current flows until the applied voltage reaches the \"cut-in\" or \"threshold\" voltage. Beyond this point, the diode's resistance drops significantly, and the current increases exponentially. This sharp rise is a key feature of the forward bias region on the I-V curve."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9868,
        "content": [
          "The current due to the minority charge carriers is represented in the forward bias region of the I-V curve."
        ],
        "isCorrect": false
      },
      {
        "id": 9869,
        "content": [
          "The current due to the majority charge carriers is represented in the reverse bias region of the I-V curve."
        ],
        "isCorrect": false
      },
      {
        "id": 9870,
        "content": [
          "The region of the I-V curve that rises very rapidly after the voltage exceeds the cut-in voltage is the forward bias region."
        ],
        "isCorrect": true
      },
      {
        "id": 9871,
        "content": [
          "The region of the I-V curve that increases very rapidly after the bias voltage exceeds the breakdown voltage is in the forward bias region."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 2466,
    "content": [
      "Consider a circuit containing diode and load resistor (R₁) are connected to an AC voltage source as shown in the figure below.",
      "images/physics/year_2017/q59_1.png",
      "If initially, polarity of 'a' is positive while 'b' is negative,"
    ],
    "explanation": [
      "The circuit shown is a half-wave rectifier. During the first half-cycle of the AC source, terminal 'a' is positive and 'b' is negative. This polarity forward-biases the diode (positive potential to the anode). A forward-biased diode acts like a closed switch, allowing current to flow through the load resistor $$R_L$$, thus developing a voltage across it."
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2017/q59_1.png"
    ],
    "choices": [
      {
        "id": 9872,
        "content": [
          "During the first half-cycle, the diode is forward biased and voltage is developed across the load resistor."
        ],
        "isCorrect": true
      },
      {
        "id": 9873,
        "content": [
          "During the second half-cycle, the diode is reverse biased and no current flow in the load resistor."
        ],
        "isCorrect": false
      },
      {
        "id": 9874,
        "content": [
          "During the second half-cycle, the diode is forward biased and current flows in the load resistor."
        ],
        "isCorrect": false
      },
      {
        "id": 9875,
        "content": [
          "During the first half-cycle, the diode is reverse biased and voltage is developed across the load resistor."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 2467,
    "content": [
      "A circular coil is located in a uniform magnetic field of magnitude 0.50 T directed perpendicular to the plane of the coil. If the area of the coil changes with uniform rate, in such a way that it increases by 4.0 × 10⁻³ m² in 2 s, what is the magnitude of the induced electromotive force (emf) in the coil?"
    ],
    "explanation": [
      "According to Faraday's law of electromagnetic induction, the magnitude of the induced emf (ε) is equal to the rate of change of magnetic flux ($$\\Phi_B$$).\n$$\n|\\epsilon| = \\left| \\frac{\\Delta \\Phi_B}{\\Delta t} \\right|\n$$",
      "Since the magnetic field B is uniform and perpendicular to the coil's area A, the flux is $$\\Phi_B = BA$$. The change in flux is due to the change in area: $$\\Delta\\Phi_B = B(\\Delta A)$$.\n$$\n|\\epsilon| = \\frac{B \\Delta A}{\\Delta t}\n$$\n$$\n|\\epsilon| = \\frac{(0.50 \\text{ T})(4.0 \\times 10^{-3} \\text{ m}^2)}{2 \\text{ s}}\n$$\n$$\n|\\epsilon| = \\frac{2.0 \\times 10^{-3}}{2} \\text{ V}\n$$\n$$\n|\\epsilon| = 1.0 \\times 10^{-3} \\text{ V}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9876,
        "content": [
          "1.0 × 10⁻³ V"
        ],
        "isCorrect": true
      },
      {
        "id": 9877,
        "content": [
          "4.0 × 10⁻³ V"
        ],
        "isCorrect": false
      },
      {
        "id": 9878,
        "content": [
          "1.0 × 10³ V"
        ],
        "isCorrect": false
      },
      {
        "id": 9879,
        "content": [
          "2.5 × 10² V"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2468,
    "content": [
      "Kirchhoff's junction rule state that"
    ],
    "explanation": [
      "Kirchhoff's junction rule is based on the principle of conservation of charge. It states that the total current (or charge per unit time) entering a junction must equal the total current leaving that junction. This means that charge is not accumulated at the junction."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9880,
        "content": [
          "current traversing any closed loop at particular time is zero."
        ],
        "isCorrect": false
      },
      {
        "id": 9881,
        "content": [
          "the potential drop at a given junction equals the electromotive force at that particular point"
        ],
        "isCorrect": false
      },
      {
        "id": 9882,
        "content": [
          "charge entering the junction equals the charge leaving that junction at a particular time."
        ],
        "isCorrect": true
      },
      {
        "id": 9883,
        "content": [
          "the sum of the voltage drop across any closed loop equals the sum of electromotive force."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 2469,
    "content": [
      "Which one of the following statement is NOT correct about the magnetic properties of matter?"
    ],
    "explanation": [
      "Diamagnetic materials do not have unpaired electrons. Their magnetic effect arises from the orbital motion of electrons, which creates magnetic dipoles that oppose the external magnetic field.",
      "The statement that they have unpaired electrons that align with the field is incorrect.",
      "Paramagnetic and ferromagnetic materials have unpaired electrons that align with an external magnetic field."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9884,
        "content": [
          "There is a tendency to oppose the applied magnetic field in a diamagnetic substance."
        ],
        "isCorrect": false
      },
      {
        "id": 9885,
        "content": [
          "The unpaired electrons in diamagnetic materials will align with the applied magnetic field and parallel to each other."
        ],
        "isCorrect": true
      },
      {
        "id": 9886,
        "content": [
          "The unpaired electrons in ferromagnetic materials will align with the applied magnetic field and parallel to each other."
        ],
        "isCorrect": false
      },
      {
        "id": 9887,
        "content": [
          "The unpaired electrons in paramagnetic substance which will tend to align themselves in the same direction as the applied magnetic field."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2470,
    "content": [
      "Suppose a conductor of length l carrying a current I placed in a uniform magnetic field of magnitude B. When the conductor is making an angle θ with that of the magnetic field then the force experienced by the conductor due to the magnetic field is given by"
    ],
    "explanation": [
      "The magnetic force experienced by a straight conductor of length vector $$\\vec{l}$$ carrying a current I in a uniform magnetic field $$\\vec{B}$$ is given by the vector cross product formula:\n$$\n\\vec{F} = I(\\vec{l} \\times \\vec{B})\n$$",
      "The magnitude of this force is $$F = BIl \\sin \\theta$$."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9888,
        "content": [
          "$$\n\\vec{F} = I(\\vec{B} \\times \\vec{l})\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9889,
        "content": [
          "$$\nF = BIl \\cos \\theta\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9890,
        "content": [
          "$$\nF = BIl \\tan \\theta\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9891,
        "content": [
          "$$\n\\vec{F} = I(\\vec{l} \\times \\vec{B})\n$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2471,
    "content": [
      "Which one of the following statement is correct about tangent galvanometer?"
    ],
    "explanation": [
      "A tangent galvanometer works on the principle that a current flowing through its coil produces a magnetic field at the center. This field is perpendicular to the horizontal component of the Earth's magnetic field and causes a compass needle to deflect. The current is directly proportional to the tangent of the deflection angle."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9892,
        "content": [
          "The current through a coil of the wire generates a magnetic field at the center of the coil"
        ],
        "isCorrect": true
      },
      {
        "id": 9893,
        "content": [
          "It consists of a coil of insulated copper wire on a circular magnetic frame."
        ],
        "isCorrect": false
      },
      {
        "id": 9894,
        "content": [
          "The current is inversely proportional to the tangent of the angle of the needle's deflection."
        ],
        "isCorrect": false
      },
      {
        "id": 9895,
        "content": [
          "It is a device used to measure the electric current in terms of the electric field it produces."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2472,
    "content": [
      "A long conductor shown in the figure carries a current I in the direction indicated by the arrow.",
      "images/physics/year_2013/q5_1.png",
      "Which statement is NOT correct about the magnetic field produced by this current carrying conductor?"
    ],
    "explanation": [
      "The magnetic field strength (B) around a long, straight current-carrying wire is given by the formula:\n$$\nB = \\frac{\\mu_0 I}{2\\pi r}\n$$",
      "This shows that the field strength is inversely proportional to the distance (r) from the conductor, not directly proportional."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2013/q5_1.png"
    ],
    "choices": [
      {
        "id": 9896,
        "content": [
          "Doubling the current through the conductor doubles the field strength."
        ],
        "isCorrect": false
      },
      {
        "id": 9897,
        "content": [
          "Reversing the current direction will reverse the direction of the magnetic field."
        ],
        "isCorrect": false
      },
      {
        "id": 9898,
        "content": [
          "The magnetic field encircles the conductor."
        ],
        "isCorrect": false
      },
      {
        "id": 9899,
        "content": [
          "The field strength is directly proportional to the distance from the conductor."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2473,
    "content": [
      "A coiled copper has 50 turns and coil cross-sectional area of 9 × 10⁻⁴ m². This coil is initially placed in a uniform magnetic field 0.02 T and pulled out of a field completely (where the field is zero) in 0.5 seconds. What is the magnitude of the induced electromotive force?"
    ],
    "explanation": [
      "According to Faraday's law of induction, the induced EMF is:\n$$\n\\mathcal{E} = -N \\frac{\\Delta \\Phi_B}{\\Delta t}\n$$",
      "The change in magnetic flux is the final flux minus the initial flux.\n$$\n\\Delta \\Phi_B = \\Phi_{final} - \\Phi_{initial}\n$$\n$$\n\\Delta \\Phi_B = 0 - (B \\cdot A) = -(0.02 \\text{ T})(9 \\times 10^{-4} \\text{ m}^2)\n$$\n$$\n\\Delta \\Phi_B = -1.8 \\times 10^{-5} \\text{ Wb}\n$$",
      "The induced EMF is then calculated as:\n$$\n\\mathcal{E} = -50 \\frac{-1.8 \\times 10^{-5} \\text{ Wb}}{0.5 \\text{ s}}\n$$\n$$\n\\mathcal{E} = 1.8 \\times 10^{-3} \\text{ V}\n$$",
      "This is equal to 1.8 mV."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9900,
        "content": [
          "3.2 mV"
        ],
        "isCorrect": false
      },
      {
        "id": 9901,
        "content": [
          "9.0 mV"
        ],
        "isCorrect": false
      },
      {
        "id": 9902,
        "content": [
          "18 mV"
        ],
        "isCorrect": false
      },
      {
        "id": 9903,
        "content": [
          "1.8 mV"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2474,
    "content": [
      "A 15.0 mH inductor is used to induce an electromotive force of 5.0 mV. What is the rate change of the induced current?"
    ],
    "explanation": [
      "The induced EMF in an inductor is given by the formula $$ \\mathcal{E} = L \\frac{\\Delta I}{\\Delta t} $$ (ignoring the negative sign for magnitude). We need to find the rate of change of current, $$\\frac{\\Delta I}{\\Delta t}$$.",
      "Rearranging the formula gives:\n$$\n\\frac{\\Delta I}{\\Delta t} = \\frac{\\mathcal{E}}{L}\n$$",
      "Substituting the values:\n$$\n\\frac{\\Delta I}{\\Delta t} = \\frac{5.0 \\times 10^{-3} \\text{ V}}{15.0 \\times 10^{-3} \\text{ H}}\n$$\n$$\n\\frac{\\Delta I}{\\Delta t} = \\frac{5}{15} \\text{ A/s} \\approx 0.33 \\text{ A/s}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9904,
        "content": [
          "3.0 A/s"
        ],
        "isCorrect": false
      },
      {
        "id": 9905,
        "content": [
          "0.30 A/s"
        ],
        "isCorrect": false
      },
      {
        "id": 9906,
        "content": [
          "0.33 A/s"
        ],
        "isCorrect": true
      },
      {
        "id": 9907,
        "content": [
          "3.3 A/s"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Magnetism"
  },
  {
    "id": 2475,
    "content": [
      "A coil and a permanent magnet are set in relative motion. Which one of the following statement is NOT correct about induced electromotive force?"
    ],
    "explanation": [
      "The induced EMF depends on the rate of change of magnetic flux, given by\n$$\n\\frac{\\Delta \\Phi_B}{\\Delta t}\n$$",
      "The direction of motion is critical because it determines how the magnetic flux through the coil changes. For example, moving a coil parallel to the magnetic field lines will not change the flux and will induce no EMF, whereas moving it perpendicular to the lines will induce an EMF. Therefore, the direction of motion has a significant effect."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9908,
        "content": [
          "Coil with larger number of turns produce greater induced electromotive forces."
        ],
        "isCorrect": false
      },
      {
        "id": 9909,
        "content": [
          "Moving a magnet relative to the coil and the coil relative to the magnet with equal speed will produce the same electromotive force."
        ],
        "isCorrect": false
      },
      {
        "id": 9910,
        "content": [
          "The magnitude of the induced electromotive force is directly proportional to the relative velocity between the two."
        ],
        "isCorrect": false
      },
      {
        "id": 9911,
        "content": [
          "The direction in which the coil moves relative to the magnetic field does not have any effect on the induced electromotive force."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Electromagnetism"
  },
  {
    "id": 2476,
    "content": [
      "What is the advantage of using alternating current in transmission of electric energy?"
    ],
    "explanation": [
      "The primary advantage of AC for power transmission is that its voltage can be easily and efficiently changed using transformers.",
      "Power is transmitted at very high voltages to minimize current (since Power = V × I) and thus reduce power loss due to resistance in the wires ($$P_{loss} = I^2R$$).",
      "The voltage is then stepped down by transformers for safe use in homes and businesses."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9912,
        "content": [
          "It enables to reach the consumers at very high voltage."
        ],
        "isCorrect": false
      },
      {
        "id": 9913,
        "content": [
          "It enables a transformer to increase or decrease the voltage as required."
        ],
        "isCorrect": true
      },
      {
        "id": 9914,
        "content": [
          "It completely avoids energy loss due to heating."
        ],
        "isCorrect": false
      },
      {
        "id": 9915,
        "content": [
          "It uses very high current in the transmission line."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 2477,
    "content": [
      "Capacitive reactance is defined as"
    ],
    "explanation": [
      "Capacitive reactance, denoted as $$X_C$$, is the opposition that a capacitor presents to the flow of alternating current (AC). It is analogous to resistance in a DC circuit and is measured in ohms (Ω)."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9916,
        "content": [
          "the equivalent quantity to resistance when we are talking about capacitors."
        ],
        "isCorrect": true
      },
      {
        "id": 9917,
        "content": [
          "the equivalent quantity to impedance of in RLC circuit."
        ],
        "isCorrect": false
      },
      {
        "id": 9918,
        "content": [
          "the equivalent quantity to resistance when we are talking about inductors."
        ],
        "isCorrect": false
      },
      {
        "id": 9919,
        "content": [
          "the equivalent quantity to resistance when we are talking about resistors."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 2478,
    "content": [
      "The second law of thermodynamics states that"
    ],
    "explanation": [
      "The second law of thermodynamics can be stated in several ways. The entropy formulation states that the total entropy of an isolated system (or the universe as a whole) can only increase or remain constant; it can never decrease. This expresses the natural tendency of systems to move towards a state of greater disorder."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9920,
        "content": [
          "the increase in the internal energy of a system is equal to the sum of the energy entering the system through heating, and work done on the system."
        ],
        "isCorrect": false
      },
      {
        "id": 9921,
        "content": [
          "two bodies that are separately in thermal equilibrium with a third body must be in thermal equilibrium with each other."
        ],
        "isCorrect": false
      },
      {
        "id": 9922,
        "content": [
          "no process is possible in which there is an overall decrease in the entropy of the universe."
        ],
        "isCorrect": true
      },
      {
        "id": 9923,
        "content": [
          "no process is possible in which there is an overall increase in the entropy of the universe."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 2479,
    "content": [
      "A mass-spring system set to oscillate in a simple harmonic motion over friction less horizontal surface. The amplitude of this oscillation is 20 cm. A second mass-spring system with the same spring constant is set to oscillate in the same way but with amplitude of 10 cm. The energy of the"
    ],
    "explanation": [
      "The total mechanical energy (E) of a mass-spring system in simple harmonic motion is given by:\n$$\nE = \\frac{1}{2} k A^2\n$$",
      "where k is the spring constant and A is the amplitude. The ratio of the energies is:\n$$\n\\frac{E_1}{E_2} = \\frac{\\frac{1}{2} k A_1^2}{\\frac{1}{2} k A_2^2} = \\left(\\frac{A_1}{A_2}\\right)^2\n$$",
      "Given $$A_1 = 20$$ cm and $$A_2 = 10$$ cm, the ratio is:\n$$\n\\left(\\frac{20}{10}\\right)^2 = 2^2 = 4\n$$",
      "Therefore, the first system has four times the energy of the second one."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9924,
        "content": [
          "first mass-spring system has four times the second one."
        ],
        "isCorrect": true
      },
      {
        "id": 9925,
        "content": [
          "second mass-spring system has the square of the first one."
        ],
        "isCorrect": false
      },
      {
        "id": 9926,
        "content": [
          "first mass-spring system has twice the second one."
        ],
        "isCorrect": false
      },
      {
        "id": 9927,
        "content": [
          "second mass-spring system has half of the first one."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 2480,
    "content": [
      "Suppose you are given the following travelling waves that have the same frequency and the same amplitude A.",
      "images/physics/year_2013/q13_1.png",
      "Which graph represents the super position of the two waves?"
    ],
    "explanation": [
      "The two initial waves are shown to be in phase, meaning their peaks and troughs align.",
      "According to the principle of superposition, when two in-phase waves interfere, they undergo constructive interference, which means their amplitudes add up.",
      "Since both waves have an amplitude of A, the resulting wave will have the same frequency but a new amplitude of A + A = 2A. Graph A correctly shows a resultant wave with amplitude 2A."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_SOUND",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2013/q13_1.png"
    ],
    "choices": [
      {
        "id": 9928,
        "content": [
          "images/physics/year_2013/q13c1_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 9929,
        "content": [
          "images/physics/year_2013/q13c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 9930,
        "content": [
          "images/physics/year_2013/q13c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 9931,
        "content": [
          "images/physics/year_2013/q13c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Mechanical Oscillation and Sound Wave"
  },
  {
    "id": 2481,
    "content": [
      "A string vibrates with speed of 110 m/s in its fourth harmonic has a frequency of 880 Hz. What is the length of the string?"
    ],
    "explanation": [
      "The formula for the frequency of the nth harmonic on a string is:\n$$\nf_n = n \\frac{v}{2L}\n$$",
      "where n is the harmonic number, v is the wave speed, and L is the length of the string. We are given n=4, v=110 m/s, and f₄=880 Hz. Rearranging the formula to solve for L:\n$$\nL = n \\frac{v}{2f_n}\n$$\n$$\nL = 4 \\times \\frac{110 \\text{ m/s}}{2 \\times 880 \\text{ Hz}}\n$$\n$$\nL = \\frac{440}{1760} \\text{ m} = 0.25 \\text{ m}\n$$",
      "Converting to centimeters: $$0.25 \\text{ m} \\times 100 \\text{ cm/m} = 25.0 \\text{ cm}$$."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_SOUND",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9932,
        "content": [
          "25.0 cm"
        ],
        "isCorrect": true
      },
      {
        "id": 9933,
        "content": [
          "12.5 cm"
        ],
        "isCorrect": false
      },
      {
        "id": 9934,
        "content": [
          "50.0 cm"
        ],
        "isCorrect": false
      },
      {
        "id": 9935,
        "content": [
          "31.3 cm"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 6,
    "unitName": "Mechanical Oscillation and Sound Wave"
  },
  {
    "id": 2482,
    "content": [
      "An interference patterns observed after a monochromatic beam of light passes through a single slit and a double slit. Which one of the following is correct about the width of the central maxima and the first order maxima in single slit and double slit?"
    ],
    "explanation": [
      "In a single-slit diffraction pattern, the central maximum is significantly brighter and is exactly twice as wide as the other maxima (fringes).",
      "In a double-slit interference pattern, all the bright fringes (maxima) are of approximately equal width and intensity."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_OPTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9936,
        "content": [
          "The width of the central maxima has equal with the width of the first order maxima in a single slit interference while it has twice the width of the first order maxima in double slit interference."
        ],
        "isCorrect": false
      },
      {
        "id": 9937,
        "content": [
          "The width of the central maxima has twice the width of the first order maxima in both cases."
        ],
        "isCorrect": false
      },
      {
        "id": 9938,
        "content": [
          "The width of the central maxima and first order maxima has equal width in both cases."
        ],
        "isCorrect": false
      },
      {
        "id": 9939,
        "content": [
          "The width of the central maxima has twice the width of the first order maxima in a single slit interference while it has equal width in double slit interference."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Electromagnetic Waves and Geometrical Optics"
  },
  {
    "id": 2483,
    "content": [
      "A light wave of wavelength 590 nm pass through a narrow double slit of 0.2 mm slit separation. An interference pattern is formed on a screen at a distance of 1.5 m. What is the distance between the consecutive bright fringes on the screen?"
    ],
    "explanation": [
      "The distance between consecutive bright fringes (fringe spacing, Δy) in a double-slit experiment is given by the formula:\n$$\n\\Delta y = \\frac{\\lambda L}{d}\n$$",
      "Given: $$ \\lambda = 590 \\text{ nm} = 590 \\times 10^{-9} \\text{ m} $$, $$ L = 1.5 \\text{ m} $$, and $$ d = 0.2 \\text{ mm} = 0.2 \\times 10^{-3} \\text{ m} $$.",
      "Substituting the values:\n$$\n\\Delta y = \\frac{(590 \\times 10^{-9} \\text{ m}) \\times (1.5 \\text{ m})}{0.2 \\times 10^{-3} \\text{ m}}\n$$\n$$\n\\Delta y = 4.425 \\times 10^{-3} \\text{ m}\n$$",
      "Converting to millimeters: $$4.425 \\text{ mm} \\approx 4.43 \\text{ mm}$$."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_OPTICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9940,
        "content": [
          "1.97 mm"
        ],
        "isCorrect": false
      },
      {
        "id": 9941,
        "content": [
          "4.43 mm"
        ],
        "isCorrect": true
      },
      {
        "id": 9942,
        "content": [
          "0.43 mm"
        ],
        "isCorrect": false
      },
      {
        "id": 9943,
        "content": [
          "44.3 mm"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Electromagnetic Waves and Geometrical Optics"
  },
  {
    "id": 2484,
    "content": [
      "According to Gauss's law the net electric flux through any hypothetical closed surface is proportional to the enclosed;"
    ],
    "explanation": [
      "Gauss's law states that the net electric flux through any closed surface is directly proportional to the total net electric charge enclosed within that surface. The mathematical form is:\n$$\n\\Phi_E = \\oint \\vec{E} \\cdot d\\vec{A} = \\frac{Q_{enclosed}}{\\epsilon_0}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9944,
        "content": [
          "Electric field."
        ],
        "isCorrect": false
      },
      {
        "id": 9945,
        "content": [
          "Potential difference."
        ],
        "isCorrect": false
      },
      {
        "id": 9946,
        "content": [
          "Electric current."
        ],
        "isCorrect": false
      },
      {
        "id": 9947,
        "content": [
          "Electric charge."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Magnetism"
  },
  {
    "id": 2485,
    "content": [
      "When a dielectric material placed between two parallel metal plates in the presence of electric fields they enable the plates to store"
    ],
    "explanation": [
      "A dielectric material increases the capacitance of a capacitor. The relationship between charge (Q), capacitance (C), and potential difference (V) is Q = CV. If the potential difference (V) is held constant, and the capacitance (C) increases due to the dielectric, the amount of charge (Q) the capacitor can store must also increase."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9948,
        "content": [
          "much less charge at different potential difference."
        ],
        "isCorrect": false
      },
      {
        "id": 9949,
        "content": [
          "the same charge at the same potential difference."
        ],
        "isCorrect": false
      },
      {
        "id": 9950,
        "content": [
          "much more charge at the same potential difference."
        ],
        "isCorrect": true
      },
      {
        "id": 9951,
        "content": [
          "much more charge at different potential difference."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 2486,
    "content": [
      "A parallel plate capacitor with plate area A and plates separation d stores a charge Q when a potential difference V is kept between the plates. Then the region between the plates is completely filled with a dielectric material of dielectric constant $$ \\epsilon_r $$. If E denotes the electric field between the plates, the energy density stored by the capacitor is"
    ],
    "explanation": [
      "The energy density (u), or energy stored per unit volume, in an electric field E is given by:\n$$\nu = \\frac{1}{2} \\epsilon E^2\n$$",
      "For a region filled with a dielectric material, the permittivity $$\\epsilon$$ is $$\\epsilon_0 \\epsilon_r$$, where $$\\epsilon_0$$ is the permittivity of free space and $$\\epsilon_r$$ is the dielectric constant.",
      "Therefore, the energy density is:\n$$\nu = \\frac{1}{2}\\epsilon_0 \\epsilon_r E^2\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_ELECTROMAGNETIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9952,
        "content": [
          "$$\nu = \\frac{1}{2}\\epsilon_0 \\epsilon_r E^2\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 9953,
        "content": [
          "$$\nu = \\frac{\\epsilon_0 \\epsilon_r Q V^2}{Ad}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9954,
        "content": [
          "$$\nu = \\frac{1}{2}\\frac{\\epsilon_0 \\epsilon_r Q^2 V}{d E}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9955,
        "content": [
          "$$\nu = \\frac{\\epsilon_0 \\epsilon_r V^2 A}{2d E}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 2487,
    "content": [
      "A uniform conductor of length L and cross-sectional area A carries a current I when a potential difference V is applied across its ends. If the number of free electrons per unit volume of the conductor is n, and the electron charge is e, then the drift velocity of the electrons in the conductor is"
    ],
    "explanation": [
      "The relationship between current (I), number density of charge carriers (n), cross-sectional area (A), drift velocity ($$v_d$$), and the charge of each carrier (e) is given by the equation:\n$$\nI = n A v_d e\n$$",
      "Solving for the drift velocity, $$v_d$$, gives:\n$$\nv_d = \\frac{I}{nAe}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_CURRENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9956,
        "content": [
          "$$\nV_d = \\frac{eLA}{I}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9957,
        "content": [
          "$$\nV_d = \\frac{I}{neA}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 9958,
        "content": [
          "$$\nV_d = \\frac{neA}{I}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9959,
        "content": [
          "$$\nV_d = \\frac{neI}{A}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Electrostatics and Electric Circuit"
  },
  {
    "id": 2488,
    "content": [
      "A student wants to measure the length and height of the school laboratory. There are Vernier calipers, meter stick, micrometer screw gauge and meter tape measuring instruments in the laboratory. Which one of the following measuring instrument and unit is appropriate for the measurement?"
    ],
    "explanation": [
      "To measure large distances like the dimensions of a room, a meter tape is the most appropriate and convenient tool. Vernier calipers and micrometers are used for very small and precise measurements. A meter stick could be used but is less practical than a tape for room-sized lengths. The standard unit for architectural dimensions is the meter."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9960,
        "content": [
          "Meter tape and meter"
        ],
        "isCorrect": true
      },
      {
        "id": 9961,
        "content": [
          "Vernier calipers and millimeter"
        ],
        "isCorrect": false
      },
      {
        "id": 9962,
        "content": [
          "Micrometer screw gauge and millimeter"
        ],
        "isCorrect": false
      },
      {
        "id": 9963,
        "content": [
          "Meter stick and centimeter"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 2489,
    "content": [
      "In reporting an experimental result the collected data has to be clearly tabulated with appropriate units. Which of the following table correctly represents a data collected during an experiment?"
    ],
    "explanation": [
      "A correctly formatted data table should have clear headings for each column that include the name of the quantity and its unit in parentheses, for example, \"Voltage (V)\". The data entries in the columns should be numerical values only, without repeating the units in each cell. Table C follows these conventions correctly, using Volts (V) for voltage and Amperes (A) for current."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_MEASUREMENT",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9964,
        "content": [
          "images/physics/year_2013/q22c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 9965,
        "content": [
          "images/physics/year_2013/q22c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 9966,
        "content": [
          "images/physics/year_2013/q22c3_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 9967,
        "content": [
          "images/physics/year_2013/q22c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Physical Quantities"
  },
  {
    "id": 2490,
    "content": [
      "A 10 N force is applied in the direction of North-East, which of the following graphical representation of the force is correct? (Assume the lengths of all arrows are equal and the paper head points towards North)"
    ],
    "explanation": [
      "With North being the top of the page and East being the right, the North-East direction is diagonally upwards and to the right, at a 45-degree angle between North and East. The arrow in option A correctly points in this direction."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9968,
        "content": [
          "images/physics/year_2013/q23c1_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 9969,
        "content": [
          "images/physics/year_2013/q23c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 9970,
        "content": [
          "images/physics/year_2013/q23c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 9971,
        "content": [
          "images/physics/year_2013/q23c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 2491,
    "content": [
      "Two vectors of magnitude 8 units in the direction of East and the second vector of magnitude 6 units in the direction of North are given. If you add the two vectors using graphical method, which graph represents the resultant of the two vectors?"
    ],
    "explanation": [
      "To add vectors graphically, the \"head-to-tail\" method is used. First, draw the 8-unit vector pointing East (to the right). Then, from the head (tip) of this first vector, draw the 6-unit vector pointing North (upwards). The resultant vector is drawn from the tail (start) of the first vector to the head of the second vector. Graph A correctly illustrates this process and the resulting vector."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9972,
        "content": [
          "images/physics/year_2013/q24c1_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 9973,
        "content": [
          "images/physics/year_2013/q24c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 9974,
        "content": [
          "images/physics/year_2013/q24c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 9975,
        "content": [
          "images/physics/year_2013/q24c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Vectors"
  },
  {
    "id": 2492,
    "content": [
      "Which of the following pair of vectors are collinear?"
    ],
    "explanation": [
      "Two vectors are collinear if one is a scalar multiple of the other. In option A, the second vector $$\\begin{bmatrix} -4 \\\\ -2 \\end{bmatrix}$$ can be obtained by multiplying the first vector $$\\begin{bmatrix} 4 \\\\ 2 \\end{bmatrix}$$ by the scalar -1. Since they are scalar multiples, they are collinear (they lie on the same line but point in opposite directions)."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9976,
        "content": [
          "$$\n\\begin{bmatrix} 4 \\\\ 2 \\end{bmatrix}, \\begin{bmatrix} -4 \\\\ -2 \\end{bmatrix}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 9977,
        "content": [
          "$$\n\\begin{bmatrix} 4 \\\\ 2 \\end{bmatrix}, \\begin{bmatrix} -4 \\\\ 2 \\end{bmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9978,
        "content": [
          "$$\n\\begin{bmatrix} 4 \\\\ 2 \\end{bmatrix}, \\begin{bmatrix} 4 \\\\ -2 \\end{bmatrix}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 9979,
        "content": [
          "$$\n\\begin{bmatrix} -4 \\\\ 2 \\end{bmatrix}, \\begin{bmatrix} 4 \\\\ 2 \\end{bmatrix}\n$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 2493,
    "content": [
      "Instantaneous velocity is different from average velocity in that; instantaneous velocity is"
    ],
    "explanation": [
      "Average velocity is the total displacement divided by the total time interval. Instantaneous velocity, by contrast, is the velocity of an object at a single, specific point in time. It is the limit of the average velocity as the time interval approaches zero."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9980,
        "content": [
          "the velocity at a particular instant of time."
        ],
        "isCorrect": true
      },
      {
        "id": 9981,
        "content": [
          "in opposite direction to the displacement of the moving object."
        ],
        "isCorrect": false
      },
      {
        "id": 9982,
        "content": [
          "the total displacement to the time taken."
        ],
        "isCorrect": false
      },
      {
        "id": 9983,
        "content": [
          "the average velocity during the time of acceleration."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 2494,
    "content": [
      "A car travelling at 20 m/s starts to speedup. After 5 minutes its speed is 144 m/s. What is the acceleration of the car?"
    ],
    "explanation": [
      "Acceleration is the rate of change of velocity, calculated as:\n$$\na = \\frac{\\Delta v}{\\Delta t} = \\frac{v_f - v_i}{t}\n$$",
      "First, convert the time to seconds:\n$$\nt = 5 \\text{ minutes} \\times 60 \\text{ s/min} = 300 \\text{ s}\n$$",
      "Now, calculate the acceleration:\n$$\na = \\frac{144 \\text{ m/s} - 20 \\text{ m/s}}{300 \\text{ s}}\n$$\n$$\na = \\frac{124 \\text{ m/s}}{300 \\text{ s}} \\approx 0.413 \\text{ m/s}^2\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9984,
        "content": [
          "28.8 m/s²"
        ],
        "isCorrect": false
      },
      {
        "id": 9985,
        "content": [
          "0.41 m/s²"
        ],
        "isCorrect": true
      },
      {
        "id": 9986,
        "content": [
          "24.8 m/s²"
        ],
        "isCorrect": false
      },
      {
        "id": 9987,
        "content": [
          "0.55 m/s²"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 2495,
    "content": [
      "A bullet of 200 g mass fired from a 30.0 m high building, horizontally. At the same time a bullet of the same mass fired vertically down from the same height. What can be concluded about the motion of the two bullets?"
    ],
    "explanation": [
      "The time it takes for an object to fall depends only on its initial vertical velocity and vertical displacement.",
      "The bullet fired horizontally has an initial vertical velocity of zero. The bullet \"fired vertically down\" is given an initial downward velocity.",
      "Since the second bullet starts with a downward velocity while the first one starts with none, the second bullet will reach the ground in less time. Therefore, the bullet fired horizontally takes more time to strike the ground."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9988,
        "content": [
          "A bullet fired vertically takes more time to strike the ground."
        ],
        "isCorrect": false
      },
      {
        "id": 9989,
        "content": [
          "Both bullets move with the same horizontal velocity"
        ],
        "isCorrect": false
      },
      {
        "id": 9990,
        "content": [
          "Both bullets strike the ground at the same time."
        ],
        "isCorrect": false
      },
      {
        "id": 9991,
        "content": [
          "A bullet fired horizontally takes more time to strike the ground."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 2496,
    "content": [
      "A bird flies at speed of 10m/s to south relative to the Earth. A wind blows at speed of 4m/s to East relative to the Earth. What is the speed of the bird relative to the wind?"
    ],
    "explanation": [
      "Let $$\\vec{v}{bE}$$ be the velocity of the bird relative to the Earth, and $$\\vec{v}{wE}$$ be the velocity of the wind relative to the Earth. We want to find $$\\vec{v}{bW}$$, the velocity of the bird relative to the wind.",
      "The relationship is:\n$$\n\\vec{v}{bW} = \\vec{v}{bE} - \\vec{v}{wE}\n$$",
      "Let South be the -y direction and East be the +x direction. So, $$\\vec{v}{bE} = -10 \\hat{j} \\text{ m/s}$$ and $$\\vec{v}{wE} = 4 \\hat{i} \\text{ m/s}$$.\n$$\n\\vec{v}{bW} = (-10 \\hat{j}) - (4 \\hat{i}) = -4 \\hat{i} - 10 \\hat{j} \\text{ m/s}\n$$",
      "This vector has a westward component (-x) and a southward component (-y), so the direction is South-West. The speed is the magnitude:\n$$\n|\\vec{v}{bW}| = \\sqrt{(-4)^2 + (-10)^2}\n$$\n$$\n|\\vec{v}_{bW}| = \\sqrt{16 + 100} = \\sqrt{116} \\approx 10.8 \\text{ m/s}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_VECTOR",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9992,
        "content": [
          "6m/s in the direction of North-East"
        ],
        "isCorrect": false
      },
      {
        "id": 9993,
        "content": [
          "10.8m/s in the direction of North-West"
        ],
        "isCorrect": false
      },
      {
        "id": 9994,
        "content": [
          "6m/s in the direction of South-East"
        ],
        "isCorrect": false
      },
      {
        "id": 9995,
        "content": [
          "10.8m/s in the direction of South-West"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Vector Quantity"
  },
  {
    "id": 2497,
    "content": [
      "Dynamics is a branch of mechanics concerned with the motion or an object"
    ],
    "explanation": [
      "Dynamics is the study of why objects move the way they do. It analyzes the relationship between the motion of objects and the forces that cause that motion. Kinematics, in contrast, describes motion without considering its causes."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 9996,
        "content": [
          "under the action of forces."
        ],
        "isCorrect": true
      },
      {
        "id": 9997,
        "content": [
          "under the action of balanced forces."
        ],
        "isCorrect": false
      },
      {
        "id": 9998,
        "content": [
          "without its causes."
        ],
        "isCorrect": false
      },
      {
        "id": 9999,
        "content": [
          "whose velocity is constant."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2498,
    "content": [
      "Which one of the following statement is correct about, a bar on which a force acts at one end and pivoted at the other?"
    ],
    "explanation": [
      "The force vector and the position vector (from the pivot to the point of application of force) define a plane of rotation. The torque vector is, by definition, perpendicular to this plane.",
      "Therefore, the force and torque vectors are not coplanar. However, this question is likely conceptually flawed or poorly worded.",
      "Among the given choices, C is the least incorrect in a loose sense, as the force is the direct cause of the torque within the rotational system. The other options are definitively incorrect as force is perpendicular to torque, angular acceleration, and angular velocity in simple rotation."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10000,
        "content": [
          "The force is parallel to the angular acceleration produced."
        ],
        "isCorrect": false
      },
      {
        "id": 10001,
        "content": [
          "The force, angular velocity and the torque are coplanar."
        ],
        "isCorrect": false
      },
      {
        "id": 10002,
        "content": [
          "The force is coplanar with the torque it produces."
        ],
        "isCorrect": true
      },
      {
        "id": 10003,
        "content": [
          "The force is collinear with the angular velocity"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2499,
    "content": [
      "The necessary condition for an object to be in rotational equilibrium is"
    ],
    "explanation": [
      "An object is in rotational equilibrium when its rate of rotation is constant (which includes being stationary). This occurs when the net torque acting on the object is zero. The statement that the sum of clockwise torques equals the sum of counter-clockwise torques is equivalent to saying the net torque is zero."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10004,
        "content": [
          "the net moment of all forces should be non-zero."
        ],
        "isCorrect": false
      },
      {
        "id": 10005,
        "content": [
          "the net torque acting on the object is different from zero."
        ],
        "isCorrect": false
      },
      {
        "id": 10006,
        "content": [
          "the net force exerting on the object must be zero."
        ],
        "isCorrect": false
      },
      {
        "id": 10007,
        "content": [
          "the sum of clockwise torques equals to the sum of counter clockwise torques."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2500,
    "content": [
      "An aluminum wire of initial length 2.0 m where increased by 2.0 cm in its length being on application of a force of 9.0 N. What is the strain energy of the material?"
    ],
    "explanation": [
      "The strain energy (or elastic potential energy) stored in the wire is given by the formula:\n$$\nU = \\frac{1}{2} F \\Delta L\n$$",
      "where F is the applied force and ΔL is the extension. First, convert the extension to meters:\n$$\n\\Delta L = 2.0 \\text{ cm} = 0.02 \\text{ m}\n$$",
      "Substitute the values into the energy formula:\n$$\nU = \\frac{1}{2} (9.0 \\text{ N})(0.02 \\text{ m}) = 0.09 \\text{ J}\n$$",
      "This is equivalent to $$9.0 \\times 10^{-2} \\text{ J}$$."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10008,
        "content": [
          "0.18 J"
        ],
        "isCorrect": false
      },
      {
        "id": 10009,
        "content": [
          "0.9 J"
        ],
        "isCorrect": false
      },
      {
        "id": 10010,
        "content": [
          "9.0 ×10⁻² J"
        ],
        "isCorrect": true
      },
      {
        "id": 10011,
        "content": [
          "4.5 × 10⁻²J"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 2501,
    "content": [
      "Ethanol has a surface tension of 22x 10⁻³ N/m and its density is of 0.789 g/cm³. The radius of the capillary tube is 15 mm, and the contact angle is 30°. Determine the height rise in the column of the capillary tube."
    ],
    "explanation": [
      "The height (h) of capillary rise is given by the formula:\n$$\nh = \\frac{2T \\cos\\theta}{\\rho g r}\n$$",
      "We must use consistent SI units. T = 22 × 10⁻³ N/m, θ = 30°, r = 15 mm = 0.015 m, g ≈ 9.8 m/s².\n$$\n\\rho = 0.789 \\text{ g/cm}^3 = 789 \\text{ kg/m}^3\n$$",
      "Substituting the values:\n$$\nh = \\frac{2 \\times (22 \\times 10^{-3} \\text{ N/m}) \\times \\cos(30^{\\circ})}{(789 \\text{ kg/m}^3) \\times (9.8 \\text{ m/s}^2) \\times (0.015 \\text{ m})}\n$$\n$$\nh \\approx \\frac{0.0381}{115.983} \\approx 0.000328 \\text{ m}\n$$",
      "Converting to millimeters: $$0.000328 \\text{ m} \\times 1000 \\text{ mm/m} \\approx 0.33 \\text{ mm}$$. The closest option is 0.32 mm."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10012,
        "content": [
          "0.32 mm"
        ],
        "isCorrect": true
      },
      {
        "id": 10013,
        "content": [
          "0.16 mm"
        ],
        "isCorrect": false
      },
      {
        "id": 10014,
        "content": [
          "3.2 mm"
        ],
        "isCorrect": false
      },
      {
        "id": 10015,
        "content": [
          "1.6 mm"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2502,
    "content": [
      "Suppose a stream of fluid flows past a solid object, which one of the following does NOT affect the laminar flow of the fluid?"
    ],
    "explanation": [
      "The nature of fluid flow (whether it is laminar or turbulent) is determined by properties of the fluid (viscosity, density) and the conditions of the flow (velocity, shape, and size of the object). The density of the solid object itself does not affect the flow pattern of the fluid around it."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10016,
        "content": [
          "Viscosity of the fluid"
        ],
        "isCorrect": false
      },
      {
        "id": 10017,
        "content": [
          "The density of the solid object"
        ],
        "isCorrect": true
      },
      {
        "id": 10018,
        "content": [
          "The shape of the solid object"
        ],
        "isCorrect": false
      },
      {
        "id": 10019,
        "content": [
          "The speed of the solid object"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2503,
    "content": [
      "Water enters a tube of non-uniform diameter. The speed of the force at the entry of area A₁ is 12 m/s and the speed becomes 4 m/s at the exit opening of area A₂. Which one is correct about the ratio of $$A_1/A_2$$?"
    ],
    "explanation": [
      "The principle of continuity for an incompressible fluid states that the product of the cross-sectional area and the fluid speed is constant:\n$$\nA_1 v_1 = A_2 v_2\n$$",
      "To find the ratio $$\\frac{A_1}{A_2}$$, we rearrange the equation:\n$$\n\\frac{A_1}{A_2} = \\frac{v_2}{v_1}\n$$",
      "Substituting the given values:\n$$\n\\frac{A_1}{A_2} = \\frac{4 \\text{ m/s}}{12 \\text{ m/s}} = \\frac{1}{3}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_FLUID",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10020,
        "content": [
          "1/4"
        ],
        "isCorrect": false
      },
      {
        "id": 10021,
        "content": [
          "4"
        ],
        "isCorrect": false
      },
      {
        "id": 10022,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 10023,
        "content": [
          "1/3"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2504,
    "content": [
      "The particular temperature and pressure at which the solid, liquid, and gaseous phases of a given substance are all at equilibrium with another is known as:"
    ],
    "explanation": [
      "The triple point is the specific combination of temperature and pressure at which the three phases (solid, liquid, and gas) of a substance can coexist in thermodynamic equilibrium."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10024,
        "content": [
          "Heat capacity"
        ],
        "isCorrect": false
      },
      {
        "id": 10025,
        "content": [
          "Triple point"
        ],
        "isCorrect": true
      },
      {
        "id": 10026,
        "content": [
          "Critical point"
        ],
        "isCorrect": false
      },
      {
        "id": 10027,
        "content": [
          "Phase change"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 2505,
    "content": [
      "Most solids expand upon heating, which one of the following statements correctly describe the phenomena?"
    ],
    "explanation": [
      "When a solid is heated, the added thermal energy increases the average kinetic energy of its constituent atoms or molecules. This causes them to vibrate more vigorously and with a larger amplitude about their fixed positions in the crystal lattice, leading to thermal expansion."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10028,
        "content": [
          "Increase in temperature decreases the vibrational kinetic energy and increases the amplitude of the atoms constituting the solid."
        ],
        "isCorrect": false
      },
      {
        "id": 10029,
        "content": [
          "Increase in temperature increases the vibrational kinetic energy and decreases the amplitude of the atoms constituting the solid."
        ],
        "isCorrect": false
      },
      {
        "id": 10030,
        "content": [
          "Increase in temperature increases the vibrational kinetic energy and amplitude of the atoms constituting the solid."
        ],
        "isCorrect": true
      },
      {
        "id": 10031,
        "content": [
          "Increase in temperature decreases the vibrational kinetic energy and amplitude of the atoms constituting the solid."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 2506,
    "content": [
      "If 25 J is taken away by heat from a system, and the system does 20 J of work, what is the change in internal energy of the system?"
    ],
    "explanation": [
      "The first law of thermodynamics is:\n$$\n\\Delta U = Q - W\n$$",
      "Heat is taken away from the system, so Q is negative: Q = -25 J. The system does work on the surroundings, so W is positive: W = +20 J.",
      "Substituting these values:\n$$\n\\Delta U = (-25 \\text{ J}) - (20 \\text{ J}) = -45 \\text{ J}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_THERMODYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10032,
        "content": [
          "45.0 J"
        ],
        "isCorrect": false
      },
      {
        "id": 10033,
        "content": [
          "-45.0 J"
        ],
        "isCorrect": true
      },
      {
        "id": 10034,
        "content": [
          "5.0 J"
        ],
        "isCorrect": false
      },
      {
        "id": 10035,
        "content": [
          "-5.0 J"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 7,
    "unitName": "Temperature and Thermometer"
  },
  {
    "id": 2507,
    "content": [
      "A sample mixture of gas contains 72% of hydrogen and 28% of Helium. What is the partial pressure of helium at an atmospheric pressure of 76 cm of mercury (Hg)?"
    ],
    "explanation": [
      "According to Dalton's Law of Partial Pressures, the partial pressure of a gas in a mixture is equal to its mole fraction (or percentage by volume) multiplied by the total pressure.",
      "Partial Pressure of Helium = (Percentage of Helium) × (Total Pressure)\n$$\nP_{He} = 0.28 \\times 76 \\text{ cm of Hg}\n$$\n$$\nP_{He} = 21.28 \\text{ cm of Hg}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_PRESSURE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10036,
        "content": [
          "33.44 cm of Hg"
        ],
        "isCorrect": false
      },
      {
        "id": 10037,
        "content": [
          "76.0 cm of Hg"
        ],
        "isCorrect": false
      },
      {
        "id": 10038,
        "content": [
          "54.72 cm of Hg"
        ],
        "isCorrect": false
      },
      {
        "id": 10039,
        "content": [
          "21.28 cm of Hg"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Fluid Mechanics"
  },
  {
    "id": 2508,
    "content": [
      "Which one of the following statements is NOT correct about the concept and units of coefficient of friction?"
    ],
    "explanation": [
      "The coefficient of static friction ($$\\mu_s$$) is typically greater than the coefficient of kinetic friction ($$\\mu_k$$).",
      "This is because it takes more force to overcome inertia and start an object moving than it does to keep it moving once it's in motion. The statement that static friction is less than kinetic friction is incorrect."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_FORCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10040,
        "content": [
          "Coefficient of friction is the ratio of frictional force to normal force."
        ],
        "isCorrect": false
      },
      {
        "id": 10041,
        "content": [
          "Coefficient of static friction is less than its value of kinetic friction."
        ],
        "isCorrect": true
      },
      {
        "id": 10042,
        "content": [
          "Coefficient of static friction has no unit."
        ],
        "isCorrect": false
      },
      {
        "id": 10043,
        "content": [
          "The coefficient of friction is always less or equal to unity (1)."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2509,
    "content": [
      "A car is traveling at constant velocity along a straight line. Which, statement is correct?"
    ],
    "explanation": [
      "If a car travels at a constant velocity, its acceleration is zero. According to Newton's first law, this means the net force acting on it is also zero.",
      "The displacement ($$\\Delta x$$) is given by $$ \\Delta x = v \\cdot t $$. Since v is constant, displacement increases linearly with time."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10044,
        "content": [
          "The displacement of the car increase linearly with time."
        ],
        "isCorrect": true
      },
      {
        "id": 10045,
        "content": [
          "The displacement of the car is in opposite direction."
        ],
        "isCorrect": false
      },
      {
        "id": 10046,
        "content": [
          "The net force on the car is different from zero."
        ],
        "isCorrect": false
      },
      {
        "id": 10047,
        "content": [
          "The acceleration of the car is in opposite direction."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Motion in a Straight Line"
  },
  {
    "id": 2510,
    "content": [
      "Which one of the following statements is correct about the impulse on an object?"
    ],
    "explanation": [
      "The impulse-momentum theorem states that the impulse applied to an object is equal to the change in its momentum.\n$$\nJ = \\Delta p\n$$",
      "Impulse itself is the product of the average force and the time interval over which it acts.\n$$\nJ = F_{avg} \\Delta t\n$$",
      "Statement C correctly identifies impulse as the change in momentum."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_MOMENTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10048,
        "content": [
          "The impulse on an object is changed when the net force acting on the object is zero."
        ],
        "isCorrect": false
      },
      {
        "id": 10049,
        "content": [
          "The area under the curve of momentum versus time graph is the impulse on an object."
        ],
        "isCorrect": false
      },
      {
        "id": 10050,
        "content": [
          "Impulse is the change in momentum when a force is exerted on an object for a very short period of time."
        ],
        "isCorrect": true
      },
      {
        "id": 10051,
        "content": [
          "Impulse is the rate of change in momentum due to external force exerted on an object for a very short period of time."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2511,
    "content": [
      "Consider two collisions that occurred between two trollies having the same mass, moving with the same speed, and in opposite directions,\nCollision 1:- after collision the two trollies bounce back with the same speed.\nCollision 2:- after collision the two trollies stick together due to magnetic coupler.\nWhich of the following statement is correct about the two collisions?"
    ],
    "explanation": [
      "An elastic collision is one in which kinetic energy is conserved. In Collision 1, the trollies bouncing back with the same speed indicates that kinetic energy was conserved.",
      "An inelastic collision is one where kinetic energy is not conserved. In Collision 2, the trollies stick together, which is a characteristic of a perfectly inelastic collision where the maximum amount of kinetic energy is lost."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_MOMENTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10052,
        "content": [
          "Both collisions are elastic."
        ],
        "isCorrect": false
      },
      {
        "id": 10053,
        "content": [
          "Collision 1 is elastic and collision 2 is inelastic."
        ],
        "isCorrect": true
      },
      {
        "id": 10054,
        "content": [
          "Both collisions are inelastic."
        ],
        "isCorrect": false
      },
      {
        "id": 10055,
        "content": [
          "Collision 1 is inelastic and collision 2 is elastic."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2512,
    "content": [
      "Suppose that you are given a mass attached to a spring and oscillates up and down. This mass-spring system has maximum gravitational potential energy (GPE), elastic potential energy (EPE) and kinetic energy (KE) at the"
    ],
    "explanation": [
      "In a vertically oscillating mass-spring system:",
      "Gravitational Potential Energy (GPE) is maximum at the highest point (top) of the oscillation.",
      "Elastic Potential Energy (EPE) is maximum when the spring is stretched the most, which is at the lowest point (bottom).",
      "Kinetic Energy (KE) is maximum when the mass passes through its equilibrium position (middle), where its speed is greatest.",
      "Therefore, the maxima occur at the top, bottom, and middle, respectively."
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10056,
        "content": [
          "middle, top and bottom respectively."
        ],
        "isCorrect": false
      },
      {
        "id": 10057,
        "content": [
          "middle, bottom and top respectively."
        ],
        "isCorrect": false
      },
      {
        "id": 10058,
        "content": [
          "bottom, middle and top respectively."
        ],
        "isCorrect": false
      },
      {
        "id": 10059,
        "content": [
          "top, bottom and middle respectively."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 2513,
    "content": [
      "A pendulum shown in the figure below has 2.5 m length and mass m. When it pass point A, its mass has a speed of 2.0 m/s. (neglect the air resistance)",
      "images/physics/year_2013/q46_1.png",
      "The height of the pendulum at displacement positions B and C is"
    ],
    "explanation": [
      "By the principle of conservation of mechanical energy, the kinetic energy at the lowest point (A) is converted into gravitational potential energy at the highest points (B and C).\n$$\nKE_A = PE_B\n$$\n$$\n\\frac{1}{2}mv_A^2 = mgh\n$$",
      "Solving for height h:\n$$\nh = \\frac{v_A^2}{2g}\n$$",
      "Using g ≈ 10 m/s²:\n$$\nh = \\frac{(2.0 \\text{ m/s})^2}{2 \\times 10 \\text{ m/s}^2} = \\frac{4}{20} \\text{ m} = 0.2 \\text{ m}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/physics/year_2013/q46_1.png"
    ],
    "choices": [
      {
        "id": 10060,
        "content": [
          "0.1 m"
        ],
        "isCorrect": false
      },
      {
        "id": 10061,
        "content": [
          "2.5 m"
        ],
        "isCorrect": false
      },
      {
        "id": 10062,
        "content": [
          "0.2 m"
        ],
        "isCorrect": true
      },
      {
        "id": 10063,
        "content": [
          "0.4 m"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 2514,
    "content": [
      "A 5.0 kg stone is dropped from a top of 30.0 m building. At a height of 10.0 m above the ground, 60% of its initial potential energy is converted to kinetic energy. Which of the following statements is correct about the transformation of energy for the stone?"
    ],
    "explanation": [
      "Initial energy at 30 m is all potential energy:\n$$\nE_i = PE_i = mgH = mg(30)\n$$",
      "At 10 m, the potential energy is:\n$$\nPE_f = mgh = mg(10)\n$$",
      "The kinetic energy is 60% of the initial PE:\n$$\nKE_f = 0.60 \\times PE_i = 0.60 \\times mg(30) = mg(18)\n$$",
      "The total mechanical energy at 10 m is:\n$$\nE_f = PE_f + KE_f = mg(10) + mg(18) = mg(28)\n$$",
      "The energy lost to air resistance is the difference between initial and final energy:\n$$\nE_{lost} = E_i - E_f = mg(30) - mg(28) = mg(2)\n$$",
      "The percentage of initial energy lost is:\n$$\n\\frac{E_{lost}}{E_i} \\times 100\\% = \\frac{mg(2)}{mg(30)} \\times 100\\% = \\frac{2}{30} \\times 100\\% \\approx 6.7\\%\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_WORK",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10064,
        "content": [
          "The sum of its potential energy and kinetic energy is the same at every point during its fall."
        ],
        "isCorrect": false
      },
      {
        "id": 10065,
        "content": [
          "6.7% of its gravitational potential energy is dissipated due to air resistance."
        ],
        "isCorrect": true
      },
      {
        "id": 10066,
        "content": [
          "60% of its original potential energy is converted to heat energy due to air resistance."
        ],
        "isCorrect": false
      },
      {
        "id": 10067,
        "content": [
          "The remaining 40% of the energy is still available as gravitational potential energy."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Force, Work, Energy and Power"
  },
  {
    "id": 2515,
    "content": [
      "A force of $$ \\begin{bmatrix} 3 \\\\ 4 \\end{bmatrix} $$ N acts at a displacement of $$ \\begin{bmatrix} 4 \\\\ 3 \\end{bmatrix} $$ m. The magnitude and the direction of the torque produced is"
    ],
    "explanation": [
      "Torque is calculated using the cross product of the position vector $$\\vec{r}$$ and the force vector $$\\vec{F}$$:\n$$\n\\vec{\\tau} = \\vec{r} \\times \\vec{F}\n$$",
      "Given $$\\vec{r} = 4\\hat{i} + 3\\hat{j}$$ m and $$\\vec{F} = 3\\hat{i} + 4\\hat{j}$$ N.\n$$\n\\vec{\\tau} = (4\\hat{i} + 3\\hat{j}) \\times (3\\hat{i} + 4\\hat{j})\n$$\n$$\n\\vec{\\tau} = (4 \\times 3)(\\hat{i} \\times \\hat{i}) + (4 \\times 4)(\\hat{i} \\times \\hat{j}) + (3 \\times 3)(\\hat{j} \\times \\hat{i}) + (3 \\times 4)(\\hat{j} \\times \\hat{j})\n$$",
      "Since $$\\hat{i} \\times \\hat{i} = 0$$, $$\\hat{j} \\times \\hat{j} = 0$$, $$\\hat{i} \\times \\hat{j} = \\hat{k}$$, and $$\\hat{j} \\times \\hat{i} = -\\hat{k}$$:\n$$\n\\vec{\\tau} = 0 + 16\\hat{k} - 9\\hat{k} + 0\n$$\n$$\n\\vec{\\tau} = 7\\hat{k} \\text{ N.m}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_DYNAMICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10068,
        "content": [
          "$$-7.0 N.m  \\hat{k}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10069,
        "content": [
          "$$-24.0 N.m \\hat{k}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10070,
        "content": [
          "$$24.0 N.m \\hat{k}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 10071,
        "content": [
          "$$7.0 N.m \\hat{k}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  },
  {
    "id": 2516,
    "content": [
      "A wheel starts rotating at 1.2 Hz and reaches 1.8 Hz in 5 seconds. Calculate the angular displacement it covers within 5 seconds?"
    ],
    "explanation": [
      "For constant angular acceleration, the angular displacement is the average angular velocity multiplied by time:\n$$\n\\Delta\\theta = \\left(\\frac{\\omega_i + \\omega_f}{2}\\right)t\n$$",
      "First, convert the frequencies (f) to angular velocities (ω) using $$\\omega = 2\\pi f$$.\n$$\n\\omega_i = 2\\pi(1.2 \\text{ Hz}) = 2.4\\pi \\text{ rad/s}\n$$\n$$\n\\omega_f = 2\\pi(1.8 \\text{ Hz}) = 3.6\\pi \\text{ rad/s}\n$$",
      "Now, calculate the displacement:\n$$\n\\Delta\\theta = \\left(\\frac{2.4\\pi + 3.6\\pi}{2}\\right) \\times 5\\text{ s}\n$$\n$$\n\\Delta\\theta = \\left(\\frac{6.0\\pi}{2}\\right) \\times 5 = 3\\pi \\times 5 = 15\\pi \\text{ rad}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_KINEMATICS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10072,
        "content": [
          "10π rad"
        ],
        "isCorrect": false
      },
      {
        "id": 10073,
        "content": [
          "3π rad"
        ],
        "isCorrect": false
      },
      {
        "id": 10074,
        "content": [
          "30π rad"
        ],
        "isCorrect": false
      },
      {
        "id": 10075,
        "content": [
          "15π rad"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Motion in One and Two Dimensions"
  },
  {
    "id": 2517,
    "content": [
      "If you are given the following physical quantities in angular motion: torque (τ), Linear momentum (p), moment of inertia (I), angular speed (ω), and angular acceleration (α). The angular momentum (L) is the"
    ],
    "explanation": [
      "Angular momentum (L) for a rigid body rotating about a fixed axis is defined as the product of its moment of inertia (I) and its angular speed (ω).",
      "The formula is:\n$$\nL = I\\omega\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "PHYSICS",
    "chapter": "PHY_MOMENTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 10076,
        "content": [
          "product of moment of inertia and angular speed."
        ],
        "isCorrect": true
      },
      {
        "id": 10077,
        "content": [
          "ratio of moment of inertia to angular acceleration."
        ],
        "isCorrect": false
      },
      {
        "id": 10078,
        "content": [
          "product of moment of inertia and torque."
        ],
        "isCorrect": false
      },
      {
        "id": 10079,
        "content": [
          "ratio of linear momentum to moment of inertia."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Dynamics"
  }
];
export default questions;
