// StudentPrep Premium Content — complete question bank.
const questions = [
  {
    "id": 1457,
    "content": [
      "Choose the word opposite in meaning to the word below.",
      "---",
      "**Pessimism**"
    ],
    "explanation": [
      "Pessimism is a tendency to see the worst aspect of things or believe that the worst will happen; a lack of hope or confidence in the future. Optimism is hopefulness and confidence about the future or the success of something. Therefore, Optimism is the antonym of Pessimism."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANTONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 1,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5829,
        "content": [
          "Sorrow"
        ],
        "isCorrect": false
      },
      {
        "id": 5830,
        "content": [
          "Optimism"
        ],
        "isCorrect": true
      },
      {
        "id": 5831,
        "content": [
          "Arrogance"
        ],
        "isCorrect": false
      },
      {
        "id": 5832,
        "content": [
          "Despair"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1458,
    "content": [
      "Choose the word opposite in meaning to the word below.",
      "---",
      "**Polygamy**"
    ],
    "explanation": [
      "Polygamy is the practice or custom of having more than one wife or husband at the same time. Monogamy is the practice or state of being married to one person at a time. Therefore, Monogamy is the antonym of Polygamy."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANTONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 1,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5833,
        "content": [
          "Monogamy"
        ],
        "isCorrect": true
      },
      {
        "id": 5834,
        "content": [
          "Interference"
        ],
        "isCorrect": false
      },
      {
        "id": 5835,
        "content": [
          "Recovery"
        ],
        "isCorrect": false
      },
      {
        "id": 5836,
        "content": [
          "Detour"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1459,
    "content": [
      "Choose the word opposite in meaning to the word below.",
      "---",
      "**Prospect**"
    ],
    "explanation": [
      "Prospect refers to the possibility or likelihood of some future event occurring or a view or scene. Retrospect involves looking back on or reviewing past events or a period of time. Therefore, Retrospect is the antonym of Prospect in the sense of looking forward versus looking backward."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANTONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 1,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5837,
        "content": [
          "Retrospect"
        ],
        "isCorrect": true
      },
      {
        "id": 5838,
        "content": [
          "Traditional"
        ],
        "isCorrect": false
      },
      {
        "id": 5839,
        "content": [
          "Ideal"
        ],
        "isCorrect": false
      },
      {
        "id": 5840,
        "content": [
          "Modernist"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1460,
    "content": [
      "Choose the word that is nearly similar in meaning to the word that is capitalized.",
      "---",
      "The **DIFFUSION** of the virus had reached an epidemic proportion."
    ],
    "explanation": [
      "Diffusion means the spreading of something more widely. 'Spread' means to extend over a large or increasing area. In the context of a virus becoming widespread, 'spread' is the most fitting synonym for diffusion."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 2,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5841,
        "content": [
          "dissemination"
        ],
        "isCorrect": false
      },
      {
        "id": 5842,
        "content": [
          "spread"
        ],
        "isCorrect": true
      },
      {
        "id": 5843,
        "content": [
          "diagnosis"
        ],
        "isCorrect": false
      },
      {
        "id": 5844,
        "content": [
          "vulnerability"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1461,
    "content": [
      "Choose the word that is nearly similar in meaning to the word that is capitalized.",
      "---",
      "The electric poles were **IMPREGNATED** with chemical solutions for durability."
    ],
    "explanation": [
      "Impregnated means to soak or saturate something thoroughly with a substance. 'Saturated' means thoroughly soaked, which closely matches the meaning of impregnating the poles with chemical solutions."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 2,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5845,
        "content": [
          "saturated"
        ],
        "isCorrect": true
      },
      {
        "id": 5846,
        "content": [
          "varnished"
        ],
        "isCorrect": false
      },
      {
        "id": 5847,
        "content": [
          "erected"
        ],
        "isCorrect": false
      },
      {
        "id": 5848,
        "content": [
          "washed"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1462,
    "content": [
      "Choose the word that is nearly similar in meaning to the word that is capitalized.",
      "---",
      "The sense of **ANIMOSITY** between the rival groups was resolved peacefully."
    ],
    "explanation": [
      "Animosity refers to strong hostility or ill will. 'Hatred' is intense dislike or ill will, making it the closest synonym among the given options."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 2,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5849,
        "content": [
          "grievance"
        ],
        "isCorrect": false
      },
      {
        "id": 5850,
        "content": [
          "hatred"
        ],
        "isCorrect": true
      },
      {
        "id": 5851,
        "content": [
          "exposure"
        ],
        "isCorrect": false
      },
      {
        "id": 5852,
        "content": [
          "revenge"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1463,
    "content": [
      "Choose the word that is nearly similar in meaning to the word that is capitalized.",
      "---",
      "The practice of tax **EVASION** is harmful to the development of a nation."
    ],
    "explanation": [
      "Evasion means the act of escaping or avoiding something, often implies illegality or deceit (as in tax evasion). 'Avoidance' means keeping away from or preventing something from happening. While tax evasion has a specific illegal connotation distinct from legal tax avoidance, 'avoidance' is the closest general meaning provided in the options."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 2,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5853,
        "content": [
          "avoidance"
        ],
        "isCorrect": true
      },
      {
        "id": 5854,
        "content": [
          "endorsement"
        ],
        "isCorrect": false
      },
      {
        "id": 5855,
        "content": [
          "conviction"
        ],
        "isCorrect": false
      },
      {
        "id": 5856,
        "content": [
          "resilience"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1464,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "GUNPOWDER: EXPLOSION;",
      "Volcano:______________."
    ],
    "explanation": [
      "The relationship is Cause: Effect or Object: Characteristic Action. Gunpowder is a substance whose characteristic action or result is an explosion. Similarly, a volcano is a geological feature whose characteristic action or result is an eruption."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 3,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5857,
        "content": [
          "Landslide"
        ],
        "isCorrect": false
      },
      {
        "id": 5858,
        "content": [
          "Concentration"
        ],
        "isCorrect": false
      },
      {
        "id": 5859,
        "content": [
          "Eruption"
        ],
        "isCorrect": true
      },
      {
        "id": 5860,
        "content": [
          "Pasteurization"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1465,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "CARAVAN: DESERT;",
      "Perch:______________."
    ],
    "explanation": [
      "The relationship is Entity: Typical Environment/Medium. A caravan (a group traveling together) is typically associated with traveling through a desert. A perch is a type of fish, and fish live in an aquatic environment."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 3,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5861,
        "content": [
          "Aquatic"
        ],
        "isCorrect": true
      },
      {
        "id": 5862,
        "content": [
          "Terrestrial"
        ],
        "isCorrect": false
      },
      {
        "id": 5863,
        "content": [
          "Aerial"
        ],
        "isCorrect": false
      },
      {
        "id": 5864,
        "content": [
          "Tropical"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1466,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "HISTORY: CHRONOLOGICAL;",
      "Topography:______________."
    ],
    "explanation": [
      "History is the study of past events, typically arranged in chronological order (time sequence). Topography is the arrangement or description of the physical features of an area, which relates to space. Therefore, topography is concerned with spatial arrangement."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 3,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5865,
        "content": [
          "Temperature"
        ],
        "isCorrect": false
      },
      {
        "id": 5866,
        "content": [
          "Spatial"
        ],
        "isCorrect": true
      },
      {
        "id": 5867,
        "content": [
          "Climate"
        ],
        "isCorrect": false
      },
      {
        "id": 5868,
        "content": [
          "Travel"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1467,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "DREAM: SHATTERED;",
      "Promises:______________."
    ],
    "explanation": [
      "A dream (an aspiration or hope) can be shattered, meaning it fails or is destroyed. Similarly, promises can be broken, meaning they are not kept or fulfilled. 'Broken' is the common term used when promises fail."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 3,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5869,
        "content": [
          "Broken"
        ],
        "isCorrect": true
      },
      {
        "id": 5870,
        "content": [
          "Denied"
        ],
        "isCorrect": false
      },
      {
        "id": 5871,
        "content": [
          "Cancelled"
        ],
        "isCorrect": false
      },
      {
        "id": 5872,
        "content": [
          "fulfilled"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1468,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "BROADCAST: VERBAL;",
      "Paralanguage:______________."
    ],
    "explanation": [
      "A broadcast (like radio) is primarily a form of verbal communication. Paralanguage refers to non-verbal elements of communication used to modify meaning and convey emotion, such as pitch, volume, and, importantly, gestures and facial expressions, which relate to the body. Therefore, paralanguage is often expressed through the body."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 3,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5873,
        "content": [
          "Audio-visual"
        ],
        "isCorrect": false
      },
      {
        "id": 5874,
        "content": [
          "Imagery"
        ],
        "isCorrect": false
      },
      {
        "id": 5875,
        "content": [
          "Body"
        ],
        "isCorrect": true
      },
      {
        "id": 5876,
        "content": [
          "Multimodal"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1469,
    "content": [
      "Answer the question based on the information found in the passage.",
      "---",
      "The spread of English across the globe is attributed to ________________."
    ],
    "explanation": [
      "Paragraph 1 explicitly states that \"British adventurism, expansionism, as well as the slave trade and Christian evangelism\" and \"British colonialism\" led to the global spread of the English language. Therefore, British colonialism is the correct attributed cause mentioned in the text."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 4,
    "groupIndex": null,
    "sharedContentId": 1,
    "sharedContent": [
      "1. Historically, British adventurism, expansionism, as well as the slave trade and Christian evangelism led to the global spread of the English language and its diverse forms. It was commanded to become the medium of international communication as a legacy of the British colonialism and was chauvinistically described as 'a window on the world', if not the chosen tongue.\n2. As the influence of the British Empire **recedes**, however, English speakers around the globe are now left to their discretion. In the past, there was a great fascination among Indians for 'pure language'. Several generations of Head Masters have spent **their** lives instilling in the minds of students that speaking the 'Queen's English' was the ultimate in educational attainment. Nowadays, English is becoming more and more **monolithic**. In this scenario, the international standard variety of English will be the common factor that allows for mutual intelligibility among its Afro-Asian varieties."
    ],
    "images": [],
    "choices": [
      {
        "id": 5877,
        "content": [
          "WWII"
        ],
        "isCorrect": false
      },
      {
        "id": 5878,
        "content": [
          "British colonialism"
        ],
        "isCorrect": true
      },
      {
        "id": 5879,
        "content": [
          "the Will of Queen Elizabeth"
        ],
        "isCorrect": false
      },
      {
        "id": 5880,
        "content": [
          "WWI"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1470,
    "content": [
      "Answer the question based on the information found in the passage.",
      "---",
      "What was the misconception of Indian Head Masters about the end goal of education?"
    ],
    "explanation": [
      "Paragraph 2 states that \"Several generations of Head Masters have spent their lives instilling in the minds of students that speaking the ‘Queen’s English’ was the ultimate in educational attainment.\" This indicates their belief (presented as a past fascination, potentially a misconception in the modern view) that mastering this specific form of English was the highest educational goal."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 4,
    "groupIndex": null,
    "sharedContentId": 1,
    "sharedContent": [
      "1. Historically, British adventurism, expansionism, as well as the slave trade and Christian evangelism led to the global spread of the English language and its diverse forms. It was commanded to become the medium of international communication as a legacy of the British colonialism and was chauvinistically described as 'a window on the world', if not the chosen tongue.\n2. As the influence of the British Empire **recedes**, however, English speakers around the globe are now left to their discretion. In the past, there was a great fascination among Indians for 'pure language'. Several generations of Head Masters have spent **their** lives instilling in the minds of students that speaking the 'Queen's English' was the ultimate in educational attainment. Nowadays, English is becoming more and more **monolithic**. In this scenario, the international standard variety of English will be the common factor that allows for mutual intelligibility among its Afro-Asian varieties."
    ],
    "images": [],
    "choices": [
      {
        "id": 5881,
        "content": [
          "Linguistic hybridity"
        ],
        "isCorrect": false
      },
      {
        "id": 5882,
        "content": [
          "Mastering the ‘Queen’s English’"
        ],
        "isCorrect": true
      },
      {
        "id": 5883,
        "content": [
          "Reading Shakespeare"
        ],
        "isCorrect": false
      },
      {
        "id": 5884,
        "content": [
          "A preference for the American English"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1471,
    "content": [
      "Answer the question based on the information found in the passage.",
      "---",
      "The word **THEIR** in paragraph 2 refers to ________________."
    ],
    "explanation": [
      "The sentence in paragraph 2 reads: \"Several generations of Head Masters have spent **their** lives instilling...\". The pronoun \"their\" clearly refers back to the subject of the sentence, which is \"Several generations of Head Masters\" (Indian Head Masters, in context)."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 4,
    "groupIndex": null,
    "sharedContentId": 1,
    "sharedContent": [
      "1. Historically, British adventurism, expansionism, as well as the slave trade and Christian evangelism led to the global spread of the English language and its diverse forms. It was commanded to become the medium of international communication as a legacy of the British colonialism and was chauvinistically described as 'a window on the world', if not the chosen tongue.\n2. As the influence of the British Empire **recedes**, however, English speakers around the globe are now left to their discretion. In the past, there was a great fascination among Indians for 'pure language'. Several generations of Head Masters have spent **their** lives instilling in the minds of students that speaking the 'Queen's English' was the ultimate in educational attainment. Nowadays, English is becoming more and more **monolithic**. In this scenario, the international standard variety of English will be the common factor that allows for mutual intelligibility among its Afro-Asian varieties."
    ],
    "images": [],
    "choices": [
      {
        "id": 5885,
        "content": [
          "native speakers"
        ],
        "isCorrect": false
      },
      {
        "id": 5886,
        "content": [
          "Indian head Masters"
        ],
        "isCorrect": true
      },
      {
        "id": 5887,
        "content": [
          "English speakers worldwide"
        ],
        "isCorrect": false
      },
      {
        "id": 5888,
        "content": [
          "colonial masters"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1472,
    "content": [
      "Answer the question based on the information found in the passage.",
      "---",
      "The word **RECEDES** in paragraph 2, could interchangeably be used with ________________."
    ],
    "explanation": [
      "The sentence states, \"As the influence of the British Empire **recedes**...\". 'Recedes' here means to diminish or lessen in influence or importance. 'Shrinks' means to become smaller in size or amount, which is the closest meaning to diminishing influence among the choices."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 4,
    "groupIndex": null,
    "sharedContentId": 1,
    "sharedContent": [
      "1. Historically, British adventurism, expansionism, as well as the slave trade and Christian evangelism led to the global spread of the English language and its diverse forms. It was commanded to become the medium of international communication as a legacy of the British colonialism and was chauvinistically described as 'a window on the world', if not the chosen tongue.\n2. As the influence of the British Empire **recedes**, however, English speakers around the globe are now left to their discretion. In the past, there was a great fascination among Indians for 'pure language'. Several generations of Head Masters have spent **their** lives instilling in the minds of students that speaking the 'Queen's English' was the ultimate in educational attainment. Nowadays, English is becoming more and more **monolithic**. In this scenario, the international standard variety of English will be the common factor that allows for mutual intelligibility among its Afro-Asian varieties."
    ],
    "images": [],
    "choices": [
      {
        "id": 5889,
        "content": [
          "outshines"
        ],
        "isCorrect": false
      },
      {
        "id": 5890,
        "content": [
          "shrinks"
        ],
        "isCorrect": true
      },
      {
        "id": 5891,
        "content": [
          "predominates"
        ],
        "isCorrect": false
      },
      {
        "id": 5892,
        "content": [
          "outnumbers"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1473,
    "content": [
      "Answer the question based on the information found in the passage.",
      "---",
      "The word **MONOLITHIC** in paragraph 2 is synonymous with ________________."
    ],
    "explanation": [
      "Monolithic means large, powerful, indivisible, and uniform. 'Unitary' means forming a single or uniform entity. This closely matches the sense of uniformity implied by 'monolithic'. Hybrid and multilingual suggest diversity, the opposite of monolithic. Pure doesn't capture the sense of singular structure."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 4,
    "groupIndex": null,
    "sharedContentId": 1,
    "sharedContent": [
      "1. Historically, British adventurism, expansionism, as well as the slave trade and Christian evangelism led to the global spread of the English language and its diverse forms. It was commanded to become the medium of international communication as a legacy of the British colonialism and was chauvinistically described as 'a window on the world', if not the chosen tongue.\n2. As the influence of the British Empire **recedes**, however, English speakers around the globe are now left to their discretion. In the past, there was a great fascination among Indians for 'pure language'. Several generations of Head Masters have spent **their** lives instilling in the minds of students that speaking the 'Queen's English' was the ultimate in educational attainment. Nowadays, English is becoming more and more **monolithic**. In this scenario, the international standard variety of English will be the common factor that allows for mutual intelligibility among its Afro-Asian varieties."
    ],
    "images": [],
    "choices": [
      {
        "id": 5893,
        "content": [
          "hybrid"
        ],
        "isCorrect": false
      },
      {
        "id": 5894,
        "content": [
          "multilingual"
        ],
        "isCorrect": false
      },
      {
        "id": 5895,
        "content": [
          "unitary"
        ],
        "isCorrect": true
      },
      {
        "id": 5896,
        "content": [
          "pure"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1474,
    "content": [
      "Choose the best answer from the table that completes the numbered spaces in the passage.",
      "---",
      "The first blank space could be completed with one of the following words."
    ],
    "explanation": [
      "The passage contrasts the \"wide range of academic departments\" and \"numerous courses\" at a large university with the \"limited number of courses\" at a small college. This limitation implies a focus or **specialization** in the opportunities offered by the small college."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 5,
    "groupIndex": null,
    "sharedContentId": 2,
    "sharedContent": [
      "Choose the most appropriate word from the table and complete the numbered spaces.\n\n| anonymous | exposes |\n| --- | --- |\n| cosmopolitan  | specialization |\n| homogenous |  |\n1. One of the major decisions which preparatory school leavers face is the dilemma of joining a large university or a small college. The large university provides a wide range of academic departments as well as numerous courses within such departments. The small college, however, generally offers a limited number of courses and (1. _________________ ) opportunities with a better student-faculty ratio, thus permitting individualized attention to students.\n2. Because of its large, (2. _________________  ) student body (often exceeding 20,000), the university (3. _________________  ) its students to various cultural, social, and extracurricular activities. On the other hand, the (4. _________________  ) student body of the small college affords greater opportunities for direct involvement and individual participation in such activities and intercultural clubs. All the more, the university closely approximates the real world since it provides a relaxed, impersonal and sometimes (5. _________________  ) existence.\n3. In contrast, the intimate atmosphere of the small college allows the students three-to-four years of structured living in which they contemplate and prepare for the real world. In making their choice among the institutions of higher education, the students must, therefore, consider many subjective and objective factors before joining anyone of these centres of timeless fellowship."
    ],
    "images": [],
    "choices": [
      {
        "id": 5897,
        "content": [
          "homogenous"
        ],
        "isCorrect": false
      },
      {
        "id": 5898,
        "content": [
          "exposes"
        ],
        "isCorrect": false
      },
      {
        "id": 5899,
        "content": [
          "specialization"
        ],
        "isCorrect": true
      },
      {
        "id": 5900,
        "content": [
          "cosmopolitan"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1475,
    "content": [
      "Choose the best answer from the table that completes the numbered spaces in the passage.",
      "---",
      "The word ________________ is more appropriate to complete the second blank space."
    ],
    "explanation": [
      "Blank (2) describes the large student body (often exceeding 20,000) of a large university. A large student body in a university setting is often diverse and international, best described as **cosmopolitan**."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 5,
    "groupIndex": null,
    "sharedContentId": 2,
    "sharedContent": [
      "Choose the most appropriate word from the table and complete the numbered spaces.\n\n| anonymous | exposes |\n| --- | --- |\n| cosmopolitan  | specialization |\n| homogenous |  |\n1. One of the major decisions which preparatory school leavers face is the dilemma of joining a large university or a small college. The large university provides a wide range of academic departments as well as numerous courses within such departments. The small college, however, generally offers a limited number of courses and (1. _________________ ) opportunities with a better student-faculty ratio, thus permitting individualized attention to students.\n2. Because of its large, (2. _________________  ) student body (often exceeding 20,000), the university (3. _________________  ) its students to various cultural, social, and extracurricular activities. On the other hand, the (4. _________________  ) student body of the small college affords greater opportunities for direct involvement and individual participation in such activities and intercultural clubs. All the more, the university closely approximates the real world since it provides a relaxed, impersonal and sometimes (5. _________________  ) existence.\n3. In contrast, the intimate atmosphere of the small college allows the students three-to-four years of structured living in which they contemplate and prepare for the real world. In making their choice among the institutions of higher education, the students must, therefore, consider many subjective and objective factors before joining anyone of these centres of timeless fellowship."
    ],
    "images": [],
    "choices": [
      {
        "id": 5901,
        "content": [
          "anonymous"
        ],
        "isCorrect": false
      },
      {
        "id": 5902,
        "content": [
          "cosmopolitan"
        ],
        "isCorrect": true
      },
      {
        "id": 5903,
        "content": [
          "homogenous"
        ],
        "isCorrect": false
      },
      {
        "id": 5904,
        "content": [
          "specialization"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1476,
    "content": [
      "Choose the best answer from the table that completes the numbered spaces in the passage.",
      "---",
      "One of the following words could be used in the third blank space."
    ],
    "explanation": [
      "Blank (3) describes the university's action regarding its students and various activities. The university **exposes** its students to these cultural, social, and extracurricular activities by making them available."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 5,
    "groupIndex": null,
    "sharedContentId": 2,
    "sharedContent": [
      "Choose the most appropriate word from the table and complete the numbered spaces.\n\n| anonymous | exposes |\n| --- | --- |\n| cosmopolitan  | specialization |\n| homogenous |  |\n1. One of the major decisions which preparatory school leavers face is the dilemma of joining a large university or a small college. The large university provides a wide range of academic departments as well as numerous courses within such departments. The small college, however, generally offers a limited number of courses and (1. _________________ ) opportunities with a better student-faculty ratio, thus permitting individualized attention to students.\n2. Because of its large, (2. _________________  ) student body (often exceeding 20,000), the university (3. _________________  ) its students to various cultural, social, and extracurricular activities. On the other hand, the (4. _________________  ) student body of the small college affords greater opportunities for direct involvement and individual participation in such activities and intercultural clubs. All the more, the university closely approximates the real world since it provides a relaxed, impersonal and sometimes (5. _________________  ) existence.\n3. In contrast, the intimate atmosphere of the small college allows the students three-to-four years of structured living in which they contemplate and prepare for the real world. In making their choice among the institutions of higher education, the students must, therefore, consider many subjective and objective factors before joining anyone of these centres of timeless fellowship."
    ],
    "images": [],
    "choices": [
      {
        "id": 5905,
        "content": [
          "homogenous"
        ],
        "isCorrect": false
      },
      {
        "id": 5906,
        "content": [
          "exposes"
        ],
        "isCorrect": true
      },
      {
        "id": 5907,
        "content": [
          "cosmopolitan"
        ],
        "isCorrect": false
      },
      {
        "id": 5908,
        "content": [
          "specialization"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1477,
    "content": [
      "Choose the best answer from the table that completes the numbered spaces in the passage.",
      "---",
      "The word ________________ is more appropriate for completing the fourth blank space."
    ],
    "explanation": [
      "Blank (4) describes the student body of the small college, contrasting it with the large, cosmopolitan university. A small college often has a less diverse, more uniform student body, which can be described as **homogenous**, especially in contrast to the cosmopolitan nature implied for the large university."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 5,
    "groupIndex": null,
    "sharedContentId": 2,
    "sharedContent": [
      "Choose the most appropriate word from the table and complete the numbered spaces.\n\n| anonymous | exposes |\n| --- | --- |\n| cosmopolitan  | specialization |\n| homogenous |  |\n1. One of the major decisions which preparatory school leavers face is the dilemma of joining a large university or a small college. The large university provides a wide range of academic departments as well as numerous courses within such departments. The small college, however, generally offers a limited number of courses and (1. _________________ ) opportunities with a better student-faculty ratio, thus permitting individualized attention to students.\n2. Because of its large, (2. _________________  ) student body (often exceeding 20,000), the university (3. _________________  ) its students to various cultural, social, and extracurricular activities. On the other hand, the (4. _________________  ) student body of the small college affords greater opportunities for direct involvement and individual participation in such activities and intercultural clubs. All the more, the university closely approximates the real world since it provides a relaxed, impersonal and sometimes (5. _________________  ) existence.\n3. In contrast, the intimate atmosphere of the small college allows the students three-to-four years of structured living in which they contemplate and prepare for the real world. In making their choice among the institutions of higher education, the students must, therefore, consider many subjective and objective factors before joining anyone of these centres of timeless fellowship."
    ],
    "images": [],
    "choices": [
      {
        "id": 5909,
        "content": [
          "exposes"
        ],
        "isCorrect": false
      },
      {
        "id": 5910,
        "content": [
          "homogenous"
        ],
        "isCorrect": true
      },
      {
        "id": 5911,
        "content": [
          "cosmopolitan"
        ],
        "isCorrect": false
      },
      {
        "id": 5912,
        "content": [
          "anonymous"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1478,
    "content": [
      "Choose the best answer from the table that completes the numbered spaces in the passage.",
      "---",
      "The word ________________ could be used in the fifth blank space."
    ],
    "explanation": [
      "Blank (5) describes the type of existence a large university provides, characterized as \"relaxed, impersonal and sometimes. In a large institution with potentially tens of thousands of students, individuals can feel unknown or lost in the crowd, leading to an **anonymous** existence."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 5,
    "groupIndex": null,
    "sharedContentId": 2,
    "sharedContent": [
      "Choose the most appropriate word from the table and complete the numbered spaces.\n\n| anonymous | exposes |\n| --- | --- |\n| cosmopolitan  | specialization |\n| homogenous |  |\n1. One of the major decisions which preparatory school leavers face is the dilemma of joining a large university or a small college. The large university provides a wide range of academic departments as well as numerous courses within such departments. The small college, however, generally offers a limited number of courses and (1. _________________ ) opportunities with a better student-faculty ratio, thus permitting individualized attention to students.\n2. Because of its large, (2. _________________  ) student body (often exceeding 20,000), the university (3. _________________  ) its students to various cultural, social, and extracurricular activities. On the other hand, the (4. _________________  ) student body of the small college affords greater opportunities for direct involvement and individual participation in such activities and intercultural clubs. All the more, the university closely approximates the real world since it provides a relaxed, impersonal and sometimes (5. _________________  ) existence.\n3. In contrast, the intimate atmosphere of the small college allows the students three-to-four years of structured living in which they contemplate and prepare for the real world. In making their choice among the institutions of higher education, the students must, therefore, consider many subjective and objective factors before joining anyone of these centres of timeless fellowship."
    ],
    "images": [],
    "choices": [
      {
        "id": 5913,
        "content": [
          "specialization"
        ],
        "isCorrect": false
      },
      {
        "id": 5914,
        "content": [
          "anonymous"
        ],
        "isCorrect": true
      },
      {
        "id": 5915,
        "content": [
          "exposes"
        ],
        "isCorrect": false
      },
      {
        "id": 5916,
        "content": [
          "homogenous"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1479,
    "content": [
      "Assume all statements are true. Then, evaluate each conclusion (I, II, etc.) and decide which one(s) logically follow from the statements.",
      "---",
      "**Statement:** The vacancy announcement stipulates that all applicants are required to produce a medical certificate.",
      "**Conclusions:**",
      "I. Any candidate who tests positive will be rejected.",
      "II. Medical certificate is not mandatory for application or employment.",
      "III. A candidate who produces a forged medical certificate would be entertained.",
      "Which conclusion could be reasonably drawn from the premise?"
    ],
    "explanation": [
      "The statement explicitly says applicants are *required* to produce a medical certificate. This directly contradicts Conclusion II, making it false.\n\nConclusion III is illogical; producing forged documents typically leads to disqualification, not entertainment.\n\nConclusion I, while not a direct deductive consequence of merely *producing* a certificate, is the most reasonable inference drawn from the *purpose* of requiring a medical certificate in an application process – it's usually for screening based on health requirements, meaning failing the implied test (testing positive for a disqualifying condition) would lead to rejection.\n\nTherefore, Conclusion I is the only one that can be reasonably drawn from the premise in a practical context."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 6,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5917,
        "content": [
          "Only conclusion I"
        ],
        "isCorrect": true
      },
      {
        "id": 5918,
        "content": [
          "Only conclusion II"
        ],
        "isCorrect": false
      },
      {
        "id": 5919,
        "content": [
          "Both conclusion I and II"
        ],
        "isCorrect": false
      },
      {
        "id": 5920,
        "content": [
          "Both conclusion II and III"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1480,
    "content": [
      "Assume all statements are true. Then, evaluate each conclusion (I, II, etc.) and decide which one(s) logically follow from the statements.",
      "---",
      "**Statement:** In many undemocratic countries, minority groups were marginalized for one reason or another.",
      "**Conclusions:**",
      "I. In such countries, individual rights were more important than group rights.",
      "II. In such countries, group rights were more important than individual rights.",
      "III. In such countries, citizens could be marginalized on racial and religious grounds.",
      "IV. Collective identity was more significant than individual identity.",
      "Which one of the conclusions is more logical?"
    ],
    "explanation": [
      "The statement indicates that *minority groups* are marginalized in undemocratic countries. This marginalization based on group affiliation implies that group identity is a significant factor.\n\nConclusion II (group rights being more important, or rather, group status determining treatment over individual merit) and Conclusion IV (collective identity being more significant) directly follow from this focus on groups.\n\nConclusion III provides plausible examples (\"racial and religious grounds\") for the \"one reason or another\" mentioned in the statement, which are common bases for group marginalization.\n\nConclusion I contradicts the premise, as group marginalization suggests individual rights might be secondary to group identity.\n\nTherefore, Conclusions II, III, and IV are all logical inferences drawn from the statement."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 6,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5921,
        "content": [
          "Conclusion I"
        ],
        "isCorrect": false
      },
      {
        "id": 5922,
        "content": [
          "Conclusion II"
        ],
        "isCorrect": false
      },
      {
        "id": 5923,
        "content": [
          "Conclusions II and III"
        ],
        "isCorrect": false
      },
      {
        "id": 5924,
        "content": [
          "Conclusion II, III and IV"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1481,
    "content": [
      "Assume all statements are true. Then, evaluate each conclusion (I, II, etc.) and decide which one(s) logically follow from the statements.",
      "---",
      "**Statement:** Many investment projects contribute to environmental pollution unless they are closely monitored by regulatory agencies.",
      "**Conclusion:**",
      "I. The development policies of certain countries is exemplary.",
      "II. Environmental impact should not be undermined in the implementation of projects.",
      "III. Regulatory agencies are responsible for monitoring the implementation of modalities.",
      "Which one of the conclusions is implied by the head sentence?"
    ],
    "explanation": [
      "The statement directly links lack of monitoring by regulatory agencies to environmental pollution from investment projects.\n\nThis implies two things: first, that environmental impact is a significant concern that needs attention (Conclusion II - environmental impact should not be undermined), and second, that regulatory agencies have a crucial role in preventing this pollution through monitoring (Conclusion III - agencies are responsible for monitoring).\n\nConclusion I is not mentioned or implied in the statement. Thus, both Conclusions II and III are logically implied by the statement."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 6,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5925,
        "content": [
          "Conclusion I"
        ],
        "isCorrect": false
      },
      {
        "id": 5926,
        "content": [
          "Conclusion II"
        ],
        "isCorrect": false
      },
      {
        "id": 5927,
        "content": [
          "Conclusions II and III"
        ],
        "isCorrect": true
      },
      {
        "id": 5928,
        "content": [
          "Conclusion I and II"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1482,
    "content": [
      "The migration of birds from one part of the world to another is attributed to impulses of weather. They flock from Polar Regions to the tropical zone or vice-versa following seasonal changes. The choice of their destination depends on whether or not these migratory birds are cold-blooded.",
      "The assumption of the above argument revolves around"
    ],
    "explanation": [
      "The argument states that the choice of destination for migrating birds depends on whether or not they are cold-blooded.\n\nThis implies that cold-blooded birds need to move to areas where the temperature is suitable for them during different seasons.\n\nTheir body temperature is dependent on the external environment, so they would need to migrate to warmer climates during colder periods and potentially vice-versa, depending on their specific needs.\n\nThis necessity for seasonal readjustment based on their physiology is a core assumption of the argument."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 6,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5929,
        "content": [
          "the seasonal readjustment of cold-blooded birds"
        ],
        "isCorrect": true
      },
      {
        "id": 5930,
        "content": [
          "the bipolar migration of all birds"
        ],
        "isCorrect": false
      },
      {
        "id": 5931,
        "content": [
          "the survival of birds under the strains of climate"
        ],
        "isCorrect": false
      },
      {
        "id": 5932,
        "content": [
          "the difference between polar and tropical birds"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1483,
    "content": [
      "The traditional view about the predestination of poverty has been challenged on scientific grounds. With the advent of science and technology, the stratification of the human society into the poor and the rich is based on man-made problems rather than Divine intervention. In order to ensure equality and equitability of natural resources, modern governments should adopt and enforce the pillars of good governance.",
      "This writer proposes that"
    ],
    "explanation": [
      "The passage argues that science and technology show poverty stems from \"man-made problems,\" not predestination or Divine intervention. It further suggests solutions through \"good governance\" (a human action).\n\nTherefore, the writer proposes that poverty is man-made and can be resolved by humans (through actions like good governance)."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 6,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5933,
        "content": [
          "the fate of the poor is irreversible."
        ],
        "isCorrect": false
      },
      {
        "id": 5934,
        "content": [
          "the fortune and the misfortune of humanity is predestined."
        ],
        "isCorrect": false
      },
      {
        "id": 5935,
        "content": [
          "poverty is man-made and can be resolved by humans themselves."
        ],
        "isCorrect": true
      },
      {
        "id": 5936,
        "content": [
          "the traditional view of pessimism is still persistent."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1484,
    "content": [
      "Assume all statements are true. Then, evaluate each conclusion (I, II, etc.) and decide which one(s) logically follow from the statements.",
      "---",
      "**Statement:** All public and private schools were closed down during the outburst of the Covid-19 pandemic, which also led to socio-economic crisis.",
      "**Conclusions:**",
      "I. The spread of Covid-19 was caused by the closure of schools.",
      "II. The spread of Covid-19 had forced the closure of schools apart from impacting the socio-economic sector.",
      "III. The outbreak of this virus had nothing to do with the social service sector.",
      "The writer seems to underline the consequences of Covid-19 as stated in"
    ],
    "explanation": [
      "The statement says schools were closed *during* the pandemic outbreak, which *also* led to a socio-economic crisis.\n\nConclusion I incorrectly reverses causality (closure didn't cause spread; spread caused closure). Conclusion III makes an unsupported claim about the social service sector.\n\nConclusion II accurately reflects the statement: the spread of Covid-19 forced schools to close *and* impacted the socio-economic sector. The writer underlines these consequences as presented in Conclusion II."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 6,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5937,
        "content": [
          "conclusion I."
        ],
        "isCorrect": false
      },
      {
        "id": 5938,
        "content": [
          "conclusion II."
        ],
        "isCorrect": true
      },
      {
        "id": 5939,
        "content": [
          "conclusion III."
        ],
        "isCorrect": false
      },
      {
        "id": 5940,
        "content": [
          "Not given"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1485,
    "content": [
      "The Ministry of Inland Revenue and Customs praised the loyal tax payers for discharging their duty.",
      "What can we deduce from this premise?"
    ],
    "explanation": [
      "The statement explicitly mentions \"loyal tax payers\" being praised for \"discharging their duty.\" This directly implies that such duty-bound taxpayers exist.\n\nPaying taxes is fundamental to supporting government functions, including \"development endeavours.\" Therefore, it can be deduced that there are duty-bound taxpayers who support development.\n\nThe other options are not supported: praising loyal taxpayers doesn't mean tax avoidance is controlled, doesn't speak to the relationship between income and business, and makes an irrelevant claim about VAT."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 6,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5941,
        "content": [
          "Tax avoidance has completely been put under control."
        ],
        "isCorrect": false
      },
      {
        "id": 5942,
        "content": [
          "Income generation and business are not interrelated."
        ],
        "isCorrect": false
      },
      {
        "id": 5943,
        "content": [
          "There are duty-bound tax payers who support the development endeavours."
        ],
        "isCorrect": true
      },
      {
        "id": 5944,
        "content": [
          "Deduction of value added taxes on the price of goods is fashionable."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1486,
    "content": [
      "Assume all statements are true. Then, evaluate each conclusion (I, II, etc.) and decide which one(s) logically follow from the statements.",
      "---",
      "**Statement:** The outbreak of malaria in the tropical zones has posed a threat to public health and the GDP of malarial countries.",
      "**Conclusions:**",
      "I. Tropical countries should prioritize the eradication of malaria for humanitarian and economic reasons.",
      "II. The death of people from malaria does not affect the GDP of a country.",
      "III. Malaria should not be the focal point of research.",
      "Which one of the above conclusions could be drawn from the premise?"
    ],
    "explanation": [
      "The statement explicitly mentions that malaria poses a threat to both \"public health\" (humanitarian aspect) and \"GDP\" (economic aspect) in tropical countries.\n\nTherefore, concluding that these countries should prioritize malaria eradication for both humanitarian and economic reasons (Conclusion I) is a logical inference directly supported by the premise."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 6,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5945,
        "content": [
          "Conclusion II"
        ],
        "isCorrect": false
      },
      {
        "id": 5946,
        "content": [
          "Conclusion I"
        ],
        "isCorrect": true
      },
      {
        "id": 5947,
        "content": [
          "Conclusion III"
        ],
        "isCorrect": false
      },
      {
        "id": 5948,
        "content": [
          "Not given"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1487,
    "content": [
      "Choose the word which cannot be categorized under the same group or category."
    ],
    "explanation": [
      "Humidity, Altitude, and Temperature are all related to geographical or atmospheric conditions (elements of weather or climate). Calendar relates to the measurement and organization of time."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 7,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5949,
        "content": [
          "Humidity"
        ],
        "isCorrect": false
      },
      {
        "id": 5950,
        "content": [
          "Altitude"
        ],
        "isCorrect": false
      },
      {
        "id": 5951,
        "content": [
          "Temperature"
        ],
        "isCorrect": false
      },
      {
        "id": 5952,
        "content": [
          "Calendar"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1488,
    "content": [
      "Choose the word which cannot be categorized under the same group or category."
    ],
    "explanation": [
      "Regicide (killing a monarch), Genocide (killing a large group of people), and Patricide (killing one's father) all involve the killing of *others*. Suicide is the act of killing *oneself*."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 7,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5953,
        "content": [
          "Regicide"
        ],
        "isCorrect": false
      },
      {
        "id": 5954,
        "content": [
          "Genocide"
        ],
        "isCorrect": false
      },
      {
        "id": 5955,
        "content": [
          "Suicide"
        ],
        "isCorrect": true
      },
      {
        "id": 5956,
        "content": [
          "Patricide"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1489,
    "content": [
      "Choose the word which cannot be categorized under the same group or category."
    ],
    "explanation": [
      "Referendum, Consensus, and Universal suffrage are all concepts related to political processes, collective decision-making, or societal rights. Photosynthesis is a biological process occurring in plants."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 7,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5957,
        "content": [
          "Referendum"
        ],
        "isCorrect": false
      },
      {
        "id": 5958,
        "content": [
          "Consensus"
        ],
        "isCorrect": false
      },
      {
        "id": 5959,
        "content": [
          "Photosynthesis"
        ],
        "isCorrect": true
      },
      {
        "id": 5960,
        "content": [
          "Universal suffrage"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1490,
    "content": [
      "Choose the word which cannot be categorized under the same group or category."
    ],
    "explanation": [
      "Sword, Machine gun, and Rifle are all types of weapons. Bracelet is an item of jewelry or an accessory worn on the wrist."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 7,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5961,
        "content": [
          "Sword"
        ],
        "isCorrect": false
      },
      {
        "id": 5962,
        "content": [
          "Bracelet"
        ],
        "isCorrect": true
      },
      {
        "id": 5963,
        "content": [
          "Machine gun"
        ],
        "isCorrect": false
      },
      {
        "id": 5964,
        "content": [
          "Rifle"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1491,
    "content": [
      "Choose the word which cannot be categorized under the same group or category."
    ],
    "explanation": [
      "Chronicle, Biography, and Diary are all forms of written records detailing events, life stories, or personal thoughts. Civil code refers to a systematic collection of laws governing civil matters."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 7,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5965,
        "content": [
          "Chronicle"
        ],
        "isCorrect": false
      },
      {
        "id": 5966,
        "content": [
          "Biography"
        ],
        "isCorrect": false
      },
      {
        "id": 5967,
        "content": [
          "Diary"
        ],
        "isCorrect": false
      },
      {
        "id": 5968,
        "content": [
          "Civil code"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1492,
    "content": [
      "Which one of the following is true for every natural number $$n$$?"
    ],
    "explanation": [
      "We need to check which inequality holds for all natural numbers $$n$$ = $$1, 2, 3, ...$$.\n- $$(n+1)^3$$ = $$n^3 + 3n^2 + 3n + 1$$.\n    - Since $$n$$ is a natural number, $$3n^2$$ + $$3n$$ is always positive.\n    - Therefore, $$n^3$$ + $$3n^2$$ + $$3n$$ + $$1$$ $$\\ge$$ $$n^3$$ + $$1$$.\n    - This statement is true for all natural numbers $$n$$.\n- For $$n=4$$, $$6^4 - 1$$ = $$1296 - 1$$ = $$1295$$, which is not less than or equal to 625. So, this option is false.\n- $$n^2 - 2n + 1$$ = $$(n-1)^2$$. The inequality is $$(n+1)^2$$ $$\\le$$ $$(n-1)^2$$.\n    - For $$n=1$$, $$(1+1)^2 = 4$$ and $$(1-1)^2 = 0$$. $$4 \\not\\le 0$$. So, this option is false.\n- For $$n=4$$, $$n^2 = 16$$ and $$n!$$ = $$4!$$ = $$24$$. $$16 \\not\\ge 24$$. So, this option is false."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5969,
        "content": [
          "$$(n+1)^3$$ $$\\ge$$ $$n^3 + 1$$"
        ],
        "isCorrect": true
      },
      {
        "id": 5970,
        "content": [
          "$$6^n - 1$$ $$\\le$$ $$625$$"
        ],
        "isCorrect": false
      },
      {
        "id": 5971,
        "content": [
          "$$(n+1)^2$$ $$\\le$$ $$n^2 - 2n + 1$$"
        ],
        "isCorrect": false
      },
      {
        "id": 5972,
        "content": [
          "$$n^2$$ $$\\ge$$ $$n!$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1493,
    "content": [
      "Question is based on the data given in the tables.",
      "---",
      "What is the ratio of the number of male freshman social science students to the number of female sophomore natural science students?"
    ],
    "explanation": [
      "- Number of male freshmen = 1,000\n- Number of male freshman social science students = 30% of 1,000 = 0.30 * 1,000 = 300\n- Number of female sophomores = 450\n- Number of female sophomore natural science students = 50% of 450 = 0.50 * 450 = 225\n\nThe ratio is\n$$\n\\frac{\\text{Male Freshman Social Science}}{\\text{Female Sophomore Natural Science}} = \\frac{300}{225}\n$$\nSimplify the ratio by dividing both numbers by their greatest common divisor, 75:\n$$\n\\frac{300 \\div 75}{225 \\div 75} = \\frac{4}{3}\n$$\nThe ratio is 4 to 3"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 8,
    "groupIndex": null,
    "sharedContentId": 3,
    "sharedContent": [
      "### Student Enrollment by Class and Gender",
      "**Distribution of enrollment by class and gender**",
      "Total enrollment; 4,800",
      "images/sat/year_2015_na/shared_1.png",
      "**Percent of total enrollment majoring in selected academic areas**",
      "images/sat/year_2015_na/shared_2.png"
    ],
    "images": [
      "images/sat/year_2015_na/shared_1.png",
      "images/sat/year_2015_na/shared_2.png"
    ],
    "choices": [
      {
        "id": 5973,
        "content": [
          "9 to 20"
        ],
        "isCorrect": false
      },
      {
        "id": 5974,
        "content": [
          "4 to 3"
        ],
        "isCorrect": true
      },
      {
        "id": 5975,
        "content": [
          "20 to 9"
        ],
        "isCorrect": false
      },
      {
        "id": 5976,
        "content": [
          "3 to 4"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1494,
    "content": [
      "Question is based on the data given in the tables.",
      "---",
      "If the total enrollment is 20 percent greater than it was five years ago, what was the total enrollment five years ago?"
    ],
    "explanation": [
      "The current total enrollment is 4,800\n\nLet E be the enrollment five years ago\n\nThe current enrollment is 20% greater than E, meaning\n\nCurrent Enrollment = $$E + 0.20 \\times E$$ = $$1.20 \\times E$$\n\nSo, $$4,800$$ = $$1.20 \\times E$$\n$$\nE = \\frac{4,800}{1.20} = 4,000\n$$\nThe enrollment five years ago was 4,000"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 8,
    "groupIndex": null,
    "sharedContentId": 3,
    "sharedContent": [
      "### Student Enrollment by Class and Gender",
      "**Distribution of enrollment by class and gender**",
      "Total enrollment; 4,800",
      "images/sat/year_2015_na/shared_1.png",
      "**Percent of total enrollment majoring in selected academic areas**",
      "images/sat/year_2015_na/shared_2.png"
    ],
    "images": [
      "images/sat/year_2015_na/shared_1.png",
      "images/sat/year_2015_na/shared_2.png"
    ],
    "choices": [
      {
        "id": 5977,
        "content": [
          "3,600"
        ],
        "isCorrect": false
      },
      {
        "id": 5978,
        "content": [
          "4,600"
        ],
        "isCorrect": false
      },
      {
        "id": 5979,
        "content": [
          "3,000"
        ],
        "isCorrect": false
      },
      {
        "id": 5980,
        "content": [
          "4,000"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1495,
    "content": [
      "Question is based on the data given in the tables.",
      "---",
      "How many students are either juniors or males or both?"
    ],
    "explanation": [
      "We use the Principle of Inclusion-Exclusion:\n\nNumber(Juniors or Males) = Number(Juniors) + Number(Males) - Number(Male Juniors).\n\nFrom the table: Number(Juniors) = 1,000, Number(Males) = 2,850, Number(Male Juniors) = 620\n\nSo, Number(Juniors or Males) = 1,000 + 2,850 - 620 = 3,850 - 620 = 3,230"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 8,
    "groupIndex": null,
    "sharedContentId": 3,
    "sharedContent": [
      "### Student Enrollment by Class and Gender",
      "**Distribution of enrollment by class and gender**",
      "Total enrollment; 4,800",
      "images/sat/year_2015_na/shared_1.png",
      "**Percent of total enrollment majoring in selected academic areas**",
      "images/sat/year_2015_na/shared_2.png"
    ],
    "images": [
      "images/sat/year_2015_na/shared_1.png",
      "images/sat/year_2015_na/shared_2.png"
    ],
    "choices": [
      {
        "id": 5981,
        "content": [
          "1,000"
        ],
        "isCorrect": false
      },
      {
        "id": 5982,
        "content": [
          "2,850"
        ],
        "isCorrect": false
      },
      {
        "id": 5983,
        "content": [
          "620"
        ],
        "isCorrect": false
      },
      {
        "id": 5984,
        "content": [
          "3,230"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1496,
    "content": [
      "Question is based on the data given in the tables.",
      "---",
      "In which enrollment class do the female students have the highest percentage?"
    ],
    "explanation": [
      "Calculate the percentage of female students in each class:\n- Freshman: $$\\frac{800}{1,800} \\approx 44.4\\%$$\n- Sophomore: $$\\frac{450}{1,200} = 37.5\\%$$\n- Junior: $$\\frac{380}{1,000} = 38.0\\%$$\n- Senior: $$\\frac{320}{800} = 40.0\\%$$\n\nThe highest percentage is for Freshmen (approximately 44.4%)."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 8,
    "groupIndex": null,
    "sharedContentId": 3,
    "sharedContent": [
      "### Student Enrollment by Class and Gender",
      "**Distribution of enrollment by class and gender**",
      "Total enrollment; 4,800",
      "images/sat/year_2015_na/shared_1.png",
      "**Percent of total enrollment majoring in selected academic areas**",
      "images/sat/year_2015_na/shared_2.png"
    ],
    "images": [
      "images/sat/year_2015_na/shared_1.png",
      "images/sat/year_2015_na/shared_2.png"
    ],
    "choices": [
      {
        "id": 5985,
        "content": [
          "Freshman"
        ],
        "isCorrect": true
      },
      {
        "id": 5986,
        "content": [
          "Junior"
        ],
        "isCorrect": false
      },
      {
        "id": 5987,
        "content": [
          "Sophomore"
        ],
        "isCorrect": false
      },
      {
        "id": 5988,
        "content": [
          "Senior"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1497,
    "content": [
      "Question is based on the data given in the tables.",
      "---",
      "What is the number of male junior social science students?"
    ],
    "explanation": [
      "From the first table, the number of male junior students is 620\n\nFrom the second table, 30% of total enrollment majors in Social Science.\n\nThe number of male junior social science students is 30% of 620\n$$\n0.30 \\times 620 = 186\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 8,
    "groupIndex": null,
    "sharedContentId": 3,
    "sharedContent": [
      "### Student Enrollment by Class and Gender",
      "**Distribution of enrollment by class and gender**",
      "Total enrollment; 4,800",
      "images/sat/year_2015_na/shared_1.png",
      "**Percent of total enrollment majoring in selected academic areas**",
      "images/sat/year_2015_na/shared_2.png"
    ],
    "images": [
      "images/sat/year_2015_na/shared_1.png",
      "images/sat/year_2015_na/shared_2.png"
    ],
    "choices": [
      {
        "id": 5989,
        "content": [
          "310"
        ],
        "isCorrect": false
      },
      {
        "id": 5990,
        "content": [
          "620"
        ],
        "isCorrect": false
      },
      {
        "id": 5991,
        "content": [
          "186"
        ],
        "isCorrect": true
      },
      {
        "id": 5992,
        "content": [
          "500"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1498,
    "content": [
      "If your total income is 12,000 Birr per month and you can't spend more than 60% on housing, what is the maximum amount of your total income that can be spent on housing?"
    ],
    "explanation": [
      "The maximum amount that can be spent on housing is 60% of the total income.\n\nCalculate 60% of 12,000 Birr:\n$$\n0.60 \\times 12,000 = 7,200 \\ Birr\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5993,
        "content": [
          "9,000 Birr"
        ],
        "isCorrect": false
      },
      {
        "id": 5994,
        "content": [
          "5,600 Birr"
        ],
        "isCorrect": false
      },
      {
        "id": 5995,
        "content": [
          "6,000 Birr"
        ],
        "isCorrect": false
      },
      {
        "id": 5996,
        "content": [
          "7,200 Birr"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1499,
    "content": [
      "Suppose that the perimeter of a rectangular farm is 80 meter. If the farm is y meter long and x meter wide then which one of the following functions of x will model the total area of the farm in square meter?"
    ],
    "explanation": [
      "The perimeter of a rectangle is given by\n$$\nP = 2(L + W)\n$$\nHere, $$P$$ = $$80$$, $$L$$= $$y$$, and $$W$$= $$x$$.\n$$\n80 = 2(y + x)\n$$\n$$\n40 = y + x\n$$\nWe can express the length $$y$$ in terms of the width $$x$$:\n$$\ny = 40 - x\n$$\nThe area of the rectangle is\n$$\nA = L \\times W = y \\times x\n$$\nSubstituting the expression for $$y$$, we get the area as a function of\n$$\nx: A(x) = (40 - x)x = 40x - x^2\n$$\nRearranging this gives\n$$\nA(x) = -x^2 + 40x\n$$\nThis matches option $$f(x)$$ = $$-x^2 + 40x$$"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 5997,
        "content": [
          "$$f(x)$$ = $$-x^2 + 40x$$"
        ],
        "isCorrect": true
      },
      {
        "id": 5998,
        "content": [
          "$$g(x)$$ = $$x^2 - 40x$$"
        ],
        "isCorrect": false
      },
      {
        "id": 5999,
        "content": [
          "$$h(x)$$ = $$-2x^2 + 80x$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6000,
        "content": [
          "$$k(x)$$ = $$2x^2 + 80x$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1500,
    "content": [
      "Which one of the following is the coefficient of $$x^3y$$ in the expansion of the algebraic expression $$(x+y)^4$$?"
    ],
    "explanation": [
      "According to the Binomial Theorem, the term containing $$x^{n-k}y^k$$ in the expansion of $$(x+y)^n$$ is given by\n$$\n\\binom{n}{k} x^{n-k} y^k\n$$\nIn this case, $$n=4$$. We are looking for the term with\n$$\nx^3y = x^{4-1}y^1\n$$\nSo $$k=1$$.\n\nThe coefficient is\n$$\n\\binom{n}{k} = \\binom{4}{1}\n$$\nCalculating the binomial coefficient:\n$$\n\\binom{4}{1} = \\frac{4!}{1!(4-1)!} = \\frac{4!}{1!3!} = 4\n$$\nThe coefficient is 4"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6001,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 6002,
        "content": [
          "6"
        ],
        "isCorrect": false
      },
      {
        "id": 6003,
        "content": [
          "4"
        ],
        "isCorrect": true
      },
      {
        "id": 6004,
        "content": [
          "3"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1501,
    "content": [
      "Which one of the following is the degree of the polynomial function $$f(x)$$ = $$(2x + 7)^5(3x - 1)^2$$?"
    ],
    "explanation": [
      "The degree of a product of polynomials is the sum of the degrees of the factors.\n\nThe term $$(2x + 7)^5$$ has a degree of 5 (since the highest power of x when expanded would be $$x^5$$)\n\nThe term $$(3x - 1)^2$$ has a degree of 2\n\nTherefore, the degree of the polynomial function $$f(x)$$ is the sum of these degrees: 5 + 2 = 7"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6005,
        "content": [
          "6"
        ],
        "isCorrect": false
      },
      {
        "id": 6006,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 6007,
        "content": [
          "7"
        ],
        "isCorrect": true
      },
      {
        "id": 6008,
        "content": [
          "2"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1502,
    "content": [
      "Which one of the following is necessarily true about any real numbers x and y?"
    ],
    "explanation": [
      "The absolute value function $$|a|$$ gives the magnitude of a number $$a$$. \n\nA fundamental property of absolute values is that $$|a| = |-a|$$ for any real number $$a$$.\n\nIf we let $$a$$ = $$x + y$$, then $$-a$$ = $$-(x + y)$$ = $$-x - y$$.\n\nTherefore, $$|x + y|$$ = $$|-(x + y)|$$ = $$|-x - y|$$ is always true for any real numbers x and y.\n\nThe other options are not always true (counterexamples can be found, e.g., for option $$(x - y)^2$$ $$\\le$$ $$(x + y)^2$$, let x=1, y=-2; for option $$(x - y)^2$$ $$\\le$$ $$(x + y)^2$$, let x=1, y=2; for option $$|x + y|$$ $$\\ge$$ $$|x - y|$$, let x=1, y=-2)."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6009,
        "content": [
          "$$(x - y)^2$$ $$\\le$$ $$(x + y)^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6010,
        "content": [
          "$$(x - y)^2$$ $$\\le$$ $$(x + y)^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6011,
        "content": [
          "$$|x + y|$$ $$\\ge$$ $$|x - y|$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6012,
        "content": [
          "$$|x + y|$$ $$=$$ $$|-x - y|$$"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1503,
    "content": [
      "Suppose $$\\{a_n\\}_{n=1}^{\\infty}$$ is an arithmetic sequence and $$a_5$$ + $$a_8$$ = $$41$$ and $$a_8$$ - $$a_5$$ = $$9$$, then which one of the following is the sequence?"
    ],
    "explanation": [
      "Let the arithmetic sequence have first term $$a_1$$ and common difference $$d$$. Then the $$n^{th}$$ term is $$a_n = a_1 + (n-1)d$$.\nWe are given two equations:\n$$\na_5 + a_8 = 41 \\ \\text{(1)}\n$$\n$$\na_8 - a_5 = 9 \\ \\text{(2)}\n$$\nFrom equation (2):\n$$\n(a_1 + (8-1)d) - (a_1 + (5-1)d) = 9\n$$\n$$\n(a_1 + 7d) - (a_1 + 4d) = 9\n$$\n$$\n3d = 9 \\implies d = 3\n$$\nSubstitute $$d=3$$ into equation (1):\n$$\n(a_1 + 4d) + (a_1 + 7d) = 41\n$$\n$$\n2a_1 + 11d = 41\n$$\n$$\n2a_1 + 11(3) = 41\n$$\n$$\n2a_1 = 8 \\implies a_1 = 4\n$$\nThe sequence starts with $$a_1 = 4$$ and has a common difference $$d = 3$$. The sequence is 4, 4+3, 4+2(3), ... which is 4, 7, 10, 13, 16,..."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6013,
        "content": [
          "2, 5, 8, 11, 14,..."
        ],
        "isCorrect": false
      },
      {
        "id": 6014,
        "content": [
          "4, 7, 10, 13, 16,..."
        ],
        "isCorrect": true
      },
      {
        "id": 6015,
        "content": [
          "1, 4, 7, 10, 13,..."
        ],
        "isCorrect": false
      },
      {
        "id": 6016,
        "content": [
          "3, 6, 9, 12, 15,..."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1504,
    "content": [
      "Which one of the following is the $$100^{th}$$ term of the geometric sequence $${\\{G_n\\}}_{n=1}^{\\infty}$$, where $$G_n \\div G_{n-1}$$ = $$-1$$ and $$G_3$$ = $$5$$?"
    ],
    "explanation": [
      "$$G_n \\div G{n-1} = -1$$ means the common ratio of the geometric sequence is $$r = -1$$\n\nThe formula for the $$n^{th}$$ term of a geometric sequence is\n$$\nG_n = G_1 \\cdot r^{n-1}\n$$\nWe know $$r = -1$$ and $$G_3 = 5$$.\n\nWe can use the formula for $$n = 3$$:\n$$\nG_3 = G_1 \\cdot r^{3-1} = G_1 \\cdot r^2\n$$\nSubstituting the known values, we get:\n$$\n5 = G_1 \\cdot (-1)^2\n$$\n$$\n5 = G_1 \\cdot 1\n$$\n$$\nG_1 = 5\n$$\nNow that we know the first term $$G_1 = 5$$ and the common ratio $$r = -1$$, we can find the $$100^{th}$$ term using the formula with $$n = 100$$:\n$$\nG_{100} = G_1 \\cdot r^{100-1} = G_1 \\cdot r^{99}\n$$\nSubstituting the values of $$G_1$$ and $$r$$:\n$$\nG_{100} = 5 \\cdot (-1)^{99}\n$$\nSince the exponent 99 is odd, $$(-1)^{99}$$ = $$-1$$\n$$\nG_{100} = 5 \\cdot (-1) = -5\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6017,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 6018,
        "content": [
          "-5"
        ],
        "isCorrect": true
      },
      {
        "id": 6019,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 6020,
        "content": [
          "-1"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1505,
    "content": [
      "If the $$n^{th}$$-term of the arithmetic sequence $$\\{a_n\\}_{n=1}^{\\infty}$$ is given by $$a_n$$ = $$3n - 2$$, then which one of the following is the sum of the first seven terms of the sequence?"
    ],
    "explanation": [
      "The sum of the first n terms of an arithmetic sequence is given by the formula\n$$\nS_n = \\frac{n}{2}(a_1 + a_n)\n$$\n\n- First, find the first term ($$a_1$$): $$a_1$$ = $$3(1) - 2$$ = $$1$$\n- Next, find the seventh term ($$a_7$$): $$a_7$$ = $$3(7) - 2$$ = $$19$$\n\nNow, calculate the sum $$S_7$$:\n$$\nS_7 = \\frac{7}{2}(a_1 + a_7)\n$$\n$$\nS_7 = \\frac{7}{2}(1 + 19) = 70\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6021,
        "content": [
          "70"
        ],
        "isCorrect": true
      },
      {
        "id": 6022,
        "content": [
          "19"
        ],
        "isCorrect": false
      },
      {
        "id": 6023,
        "content": [
          "72"
        ],
        "isCorrect": false
      },
      {
        "id": 6024,
        "content": [
          "28"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1506,
    "content": [
      "Which one of the following is the sum of the first six terms of the geometric sequence $$\\{3(\\frac{1}{2})^{n-1}\\}_{n=1}^{\\infty}$$?"
    ],
    "explanation": [
      "The given sequence is a geometric sequence with the first term $$a_1$$ = $$3(\\frac{1}{2})^{1-1}$$ = $$3(\\frac{1}{2})^0 = 3$$ and common ratio $$r$$ = $$\\frac{1}{2}$$.\n\nThe formula for the sum of the first n terms of a geometric sequence is\n$$\nS_n = a \\frac{1 - r^n}{1 - r}\n$$\nWe need the sum of the first six terms ($$n=6$$).\n$$\nS_6 = 3 \\frac{1 - (\\frac{1}{2})^6}{1 - \\frac{1}{2}}\n$$\n$$\nS_6 = 3 \\frac{1 - \\frac{1}{64}}{\\frac{1}{2}}\n$$\n$$\nS_6 = 3 \\frac{\\frac{64-1}{64}}{\\frac{1}{2}}\n$$\n$$\nS_6 = 3 \\frac{\\frac{63}{64}}{\\frac{1}{2}}\n$$\n$$\nS_6 = 3 \\times \\frac{63}{64} \\times 2\n$$\n$$\nS_6 = 3 \\times \\frac{63}{32}\n$$\n$$\nS_6 = \\frac{189}{32}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6025,
        "content": [
          "$$\\frac{93}{16}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6026,
        "content": [
          "$$\\frac{189}{32}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6027,
        "content": [
          "$$\\frac{45}{8}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6028,
        "content": [
          "$$\\frac{381}{64}$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1507,
    "content": [
      "Consider the system of linear equations $$x - 2y$$ = $$3$$ and $$-3x + 2y$$ = $$1$$. Then which one of the following is true about the system?"
    ],
    "explanation": [
      "To determine the nature of the solution, we can try to solve the system.\n- Equation 1: $$x - 2y = 3$$\n- Equation 2: $$-3x + 2y = 1$$\n\nAdding Equation 1 and Equation 2 eliminates y:\n$$\n(x - 2y) + (-3x + 2y) = 3 + 1\n$$\n$$\nx = -2\n$$\nSubstitute $$x$$ = $$-2$$ into Equation 1:\n$$\n(-2) - 2y = 3\n$$\n$$\ny = -\\frac{5}{2}\n$$\nSince we found a single value for x and a single value for y ($$x=-2$$, $$y=-5/2$$), the system has a unique solution."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6029,
        "content": [
          "The system has no solution."
        ],
        "isCorrect": false
      },
      {
        "id": 6030,
        "content": [
          "The system has infinite solutions."
        ],
        "isCorrect": false
      },
      {
        "id": 6031,
        "content": [
          "The system has two different solutions."
        ],
        "isCorrect": false
      },
      {
        "id": 6032,
        "content": [
          "The system has unique solution."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1508,
    "content": [
      "Suppose you want to select a 3-person committee from a group of 7 teachers. How many ways are there to do this?"
    ],
    "explanation": [
      "Selecting a committee involves choosing a subset of individuals where the order does not matter.\n\nThis is a combination problem. The number of ways to choose k items from a set of n items is given by the combination formula\n$$\n\\binom{n}{k} = \\frac{n!}{k!(n-k)!}\n$$\nHere, we are selecting a 3-person committee (k=3) from a group of 7 teachers (n=7)\n$$\n\\binom{7}{3} = \\frac{7!}{3!(7-3)!}\n$$\n$$\n= \\frac{7!}{3!4!} = \\frac{7 \\times 6 \\times 5 \\times 4!}{ (3 \\times 2 \\times 1) \\times 4!}\n$$\n$$\n= \\frac{7 \\times 6 \\times 5}{6} = 7 \\times 5 = 35\n$$\nThere are 35 ways to select the committee."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6033,
        "content": [
          "210"
        ],
        "isCorrect": false
      },
      {
        "id": 6034,
        "content": [
          "35"
        ],
        "isCorrect": true
      },
      {
        "id": 6035,
        "content": [
          "60"
        ],
        "isCorrect": false
      },
      {
        "id": 6036,
        "content": [
          "120"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1509,
    "content": [
      "A box contains 12 pieces of paper, each of which has the name of one of the 12 students in a class consisting of 7 male and 5 female students, all with different names. What is the probability of a randomly selected piece of paper has a female student name?"
    ],
    "explanation": [
      "The probability of an event is the ratio of the number of favorable outcomes to the total number of possible outcomes.\n\nNumber of favorable outcomes (selecting a female student's name) = 5 (since there are 5 female students).\n\nTotal number of possible outcomes (selecting any student's name) = 12 (since there are 12 students in total).\n$$\n\\text{Probability (Female Name)} = \\frac{5}{12}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6037,
        "content": [
          "$$\\frac{5}{12}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6038,
        "content": [
          "$$\\frac{5}{7}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6039,
        "content": [
          "$$\\frac{7}{12}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6040,
        "content": [
          "$$\\frac{7}{5}$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1510,
    "content": [
      "According to surveys in an area, 25% of the trees planted did not grow in the year 2011 E.C. and 35% of the trees planted did not grow in the year 2014 E.C. What was the percentage increase in the fraction of trees planted that did not grow from the year 2011 E.C. to the year 2014 E.C.?"
    ],
    "explanation": [
      "The initial fraction (in 2011) of trees that did not grow is 25% or 0.25. The final fraction (in 2014) is 35% or 0.35.\n\nThe absolute increase in the fraction is 0.35 - 0.25 = 0.10.\n\nThe percentage increase is calculated relative to the initial value (2011 fraction):\n$$\nP_{\\text{increase}} = \\left( \\frac{\\text{Final Value} - \\text{Initial Value}}{\\text{Initial Value}} \\right) \\times 100\\%\n$$\n$$\nP_{\\text{increase}} = \\left( \\frac{0.10}{0.25} \\right) \\times 100\\%\n$$\n$$\nP_{\\text{increase}} = 0.4 \\times 100\\% = 40\\%\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6041,
        "content": [
          "60%"
        ],
        "isCorrect": false
      },
      {
        "id": 6042,
        "content": [
          "40%"
        ],
        "isCorrect": true
      },
      {
        "id": 6043,
        "content": [
          "50%"
        ],
        "isCorrect": false
      },
      {
        "id": 6044,
        "content": [
          "30%"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1511,
    "content": [
      "A lake was 30m deep. Two months later, its depth decreased by 20%. If the depth of the lake increased from where it was after two months by 15% in three months' time, what was the cumulative percentage change in the depth of the lake during the five months?"
    ],
    "explanation": [
      "Initial depth = 30m.\n\nAfter 2 months, depth decreases by 20%: New depth = $$30 \\times (1 - 0.20)$$ = $$30 \\times 0.80$$ = $$24 \\ m$$\n\nAfter another 3 months, depth increases by 15% from the 24m depth: Final depth = $$24 \\times (1 + 0.15)$$ = $$24 \\times 1.15$$ = $$27.6 \\ m$$\n\nTotal time = 2 + 3 = 5 month\n.\nTotal change in depth = Final depth - Initial depth = 27.6 - 30 = -2.4 m\n\nCumulative percentage change = $$(\\frac{\\text{Total Change}}{\\text{Initial Depth}}) \\times 100\\%$$ = $$(\\frac{-2.4}{30}) \\times 100\\%$$ = $$-0.08 \\times 100\\%$$ = $$-8\\%$$\n\nThe depth decreased by 8%. The magnitude of the change is 8%."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6045,
        "content": [
          "6%"
        ],
        "isCorrect": false
      },
      {
        "id": 6046,
        "content": [
          "5%"
        ],
        "isCorrect": false
      },
      {
        "id": 6047,
        "content": [
          "8%"
        ],
        "isCorrect": true
      },
      {
        "id": 6048,
        "content": [
          "10%"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1512,
    "content": [
      "Which one of the following is the solution set of the system of linear equations given by $$x + y$$ = $$1$$ and $$3x - y$$ = $$7$$?"
    ],
    "explanation": [
      "We have the system:\n\n1. $$x + y$$ = $$1$$\n2. $$3x - y$$ = $$7$$\n\nAdd the two equations: $$(x + y)$$ + $$(3x - y)$$ = $$1 + 7$$\n$$\n4x = 8\n$$\n$$\nx = 2\n$$\nSubstitute $$x=2$$ into the first equation: $$2 + y$$ = $$1$$\n$$\ny = 1 - 2 = -1\n$$\nThe unique solution is the ordered pair (2, -1). The solution set is $$\\{(2, -1)\\}$$."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6049,
        "content": [
          "$$\\{(-1, 2)\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6050,
        "content": [
          "$$\\{(2, -1)\\}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6051,
        "content": [
          "$$\\{(2, 1)\\}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6052,
        "content": [
          "$$\\{(-2, 1)\\}$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1513,
    "content": [
      "Which one of the following ordered pair of numbers is **not** in the solution of the system of linear inequalities $$x + y \\ge 1$$ and $$x - 2y \\le 2$$?"
    ],
    "explanation": [
      "We test each ordered pair against both inequalities:\n- (1, 2): -> Solution\n    - $$1+2$$ = $$3 \\ge 1$$ (True)\n    - $$1 - 2(2)$$ = $$1 - 4$$ = $$-3 \\le 2$$ (True)\n- (2, 1): -> Solution\n    - $$2+1$$ = $$3 \\ge 1$$ (True)\n    - $$2 - 2(1)$$ = $$2 - 2$$ = $$0 \\le 2$$ (True)\n- (-1, 2): -> Solution\n    - $$-1+2$$ = $$1 \\ge 1$$ (True)\n    - $$-1 - 2(2)$$ = $$-1 - 4$$ = $$-5 \\le 2$$ (True)\n- (2, -1): -> Not a solution\n    - $$2+(-1)$$ = $$1 \\ge 1$$ (True)\n    - $$2 - 2(-1)$$ = $$2 + 2$$ = $$4 \\le 2$$ (False)\n\nTherefore, (2, -1) is not in the solution set."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6053,
        "content": [
          "(1, 2)"
        ],
        "isCorrect": false
      },
      {
        "id": 6054,
        "content": [
          "(2, 1)"
        ],
        "isCorrect": false
      },
      {
        "id": 6055,
        "content": [
          "(-1, 2)"
        ],
        "isCorrect": false
      },
      {
        "id": 6056,
        "content": [
          "(2, -1)"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1514,
    "content": [
      "Given the system of linear inequalities\n$$\n\\begin{cases} \nax + by \\geq c \\\\ \nax + by \\leq c\n\\end{cases}\n$$\nfor arbitrary constants a, b, c in $$\\mathbb{R}$$ with $$c \\neq 0$$, then which one of the following is true about the solution set of the system?"
    ],
    "explanation": [
      "For a point (x, y) to be a solution to the system, it must satisfy *both* inequalities simultaneously.\n\nLet's consider the expression ax + by.\n\n- The first inequality states that ax + by must be greater than or equal to c.\n- The second inequality states that ax + by must be less than or equal to c.\n\nThe only way for a value to be both greater than or equal to c and less than or equal to c at the same time is if that value is exactly equal to c.\n\nTherefore, any solution (x, y) to the system must satisfy the equation:\n$$\nax + by = c\n$$\n\nThe set of all points (x, y) that satisfy this condition is $$\\{(x, y): ax + by = c\\}$$"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6057,
        "content": [
          "$$\n\\{(x, y): ax + by \\ge c\\}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6058,
        "content": [
          "$$\n\\{(x, y): ax + by \\le c\\}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 6059,
        "content": [
          "$$\n\\{(x, y): ax + by = c\\}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 6060,
        "content": [
          "$$\n\\{(x, y): ax + by \\ne c\\}\n$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1515,
    "content": [
      "A woman spent one fifth of her salary for clothing, two fifth her salary for different bills and 100 Birr for her transport. After covering all these costs she is left with 4,500 Birr. What was the salary she received?"
    ],
    "explanation": [
      "Let S be the woman's salary.\n- Amount spent on clothing = $$\\frac{1}{5}S$$\n- Amount spent on bills = $$\\frac{2}{5}S$$\n- Amount spent on transport = $$100$$\n- Total amount spent = $$\\frac{1}{5}S$$ + $$\\frac{2}{5}S$$ + $$100$$ = $$\\frac{3}{5}S$$ + $$100$$\n- Amount remaining = Salary - Total amount spent\n\n$$\n4,500 = S - (\\frac{3}{5}S + 100)\n$$\n$$\nS = \\frac{23,000}{2} = 11,500\n$$\nThe salary she received was 11,500 Birr."
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6061,
        "content": [
          "11,500 Birr"
        ],
        "isCorrect": true
      },
      {
        "id": 6062,
        "content": [
          "12,500 Birr"
        ],
        "isCorrect": false
      },
      {
        "id": 6063,
        "content": [
          "13,500 Birr"
        ],
        "isCorrect": false
      },
      {
        "id": 6064,
        "content": [
          "10,500 Birr"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1516,
    "content": [
      "During the sunshine, an upright building 16 meters tall is casting a shadow of 12 meters long. At the same time, a nearby upright building is casting a shadow of 18 meters long. If the lengths of the shadows are proportional to the heights of the buildings, what is the height, in meter, of the taller building?"
    ],
    "explanation": [
      "Let $$H_1$$ and $$S_1$$ be the height and shadow length of the first building, and $$H_2$$ and $$S_2$$ be the height and shadow length of the second building.\n\nWe are given $$H_1$$ = $$16 \\ m$$, $$S_1$$ = $$12 \\ m$$, and $$S_2$$ = $$18 \\ m$$.\n\nSince the heights and shadows are proportional (due to the sun being at the same angle for both), the ratio of height to shadow length is constant:\n$$\n\\frac{H_1}{S_1} = \\frac{H_2}{S_2}\n$$\n$$\n\\frac{16}{12} = \\frac{H_2}{18}\n$$\nSolve for $$H_2$$:\n$$\nH_2 = \\frac{16}{12} \\times 18\n$$\n$$\nH_2 = 24 \\ \\text{meters}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 6065,
        "content": [
          "32"
        ],
        "isCorrect": false
      },
      {
        "id": 6066,
        "content": [
          "17"
        ],
        "isCorrect": false
      },
      {
        "id": 6067,
        "content": [
          "36"
        ],
        "isCorrect": false
      },
      {
        "id": 6068,
        "content": [
          "24"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1822,
    "content": [
      "Answer the question based on the information found in the passage.",
      "---",
      "In the phrase, \"the planet's well-being\", what does \"the planet\" refer to?"
    ],
    "explanation": [
      "The passage discusses air pollution as an environmental concern affecting human health and the planet. Contextually, \"the planet\" refers to Earth, the place inhabited by humans and affected by environmental issues like air pollution."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 25,
    "groupIndex": null,
    "sharedContentId": 9,
    "sharedContent": [
      "Air pollution, one of the most pressing environmental concerns, is posing significant risks to human health and the planet's well-being. It is characterized by the presence of pollutants in the air. It's not just about breathing problems; it also harms the heart and makes life less enjoyable. Particulate matter, consisting of tiny particles suspended in the air, is a major contributor to air pollution. These particles can penetrate deep into the lungs, causing respiratory diseases and aggravating existing health conditions. Ground-level ozone, another common air pollutant, can lead to respiratory problems and the formation of smog.\n\nTo combat air pollution, it is **imperative** to adopt sustainable practices and reduce dependence on fossil fuels. Governments play a crucial role in enforcing stringent emission standards for industries and promoting public transportation. Additionally, individuals can contribute by using energy-efficient appliances, carpooling, and planting trees to improve air quality. By collectively addressing the root causes of air pollution, we can create a healthier environment for current and future generations. Planting trees and participating in community clean-up efforts further contributes to the improvement of air quality at the local level.\n\nSource: slightly adapted from https://www.pw.live/exams/school/air-pollution-essay/"
    ],
    "images": [],
    "choices": [
      {
        "id": 7296,
        "content": [
          "The earth"
        ],
        "isCorrect": true
      },
      {
        "id": 7297,
        "content": [
          "The sun"
        ],
        "isCorrect": false
      },
      {
        "id": 7298,
        "content": [
          "The moon"
        ],
        "isCorrect": false
      },
      {
        "id": 7299,
        "content": [
          "The nine planets"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1823,
    "content": [
      "Answer the question based on the information found in the passage.",
      "---",
      "How can an air pollution-free environment be created for the new generation?"
    ],
    "explanation": [
      "The passage states, \"By collectively addressing the root causes of air pollution, we can create a healthier environment for current and future generations.\" This directly supports the idea that tackling the causes from the source is the way to create a better environment. While options A, B, and C are mentioned or implied as *methods* to combat pollution, option D represents the overall strategy emphasized in the text for achieving the goal."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 25,
    "groupIndex": null,
    "sharedContentId": 9,
    "sharedContent": [
      "Air pollution, one of the most pressing environmental concerns, is posing significant risks to human health and the planet's well-being. It is characterized by the presence of pollutants in the air. It's not just about breathing problems; it also harms the heart and makes life less enjoyable. Particulate matter, consisting of tiny particles suspended in the air, is a major contributor to air pollution. These particles can penetrate deep into the lungs, causing respiratory diseases and aggravating existing health conditions. Ground-level ozone, another common air pollutant, can lead to respiratory problems and the formation of smog.\n\nTo combat air pollution, it is **imperative** to adopt sustainable practices and reduce dependence on fossil fuels. Governments play a crucial role in enforcing stringent emission standards for industries and promoting public transportation. Additionally, individuals can contribute by using energy-efficient appliances, carpooling, and planting trees to improve air quality. By collectively addressing the root causes of air pollution, we can create a healthier environment for current and future generations. Planting trees and participating in community clean-up efforts further contributes to the improvement of air quality at the local level.\n\nSource: slightly adapted from https://www.pw.live/exams/school/air-pollution-essay/"
    ],
    "images": [],
    "choices": [
      {
        "id": 7300,
        "content": [
          "By planting trees every year"
        ],
        "isCorrect": false
      },
      {
        "id": 7301,
        "content": [
          "By restricting private use of car"
        ],
        "isCorrect": false
      },
      {
        "id": 7302,
        "content": [
          "By devising rules and regulations"
        ],
        "isCorrect": false
      },
      {
        "id": 7303,
        "content": [
          "Tackling the causes of air pollution from the source"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1824,
    "content": [
      "Answer the question based on the information found in the passage.",
      "---",
      "As used in the passage, what is the meaning of the word \"**imperative**\"?"
    ],
    "explanation": [
      "The passage states, \"To combat air pollution, it is **imperative** to adopt sustainable practices...\". In this context, \"imperative\" means absolutely necessary or essential. \"Compulsory\" shares this meaning of being required or obligatory, fitting the sense that adopting these practices is crucial and not merely suggested."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 25,
    "groupIndex": null,
    "sharedContentId": 9,
    "sharedContent": [
      "Air pollution, one of the most pressing environmental concerns, is posing significant risks to human health and the planet's well-being. It is characterized by the presence of pollutants in the air. It's not just about breathing problems; it also harms the heart and makes life less enjoyable. Particulate matter, consisting of tiny particles suspended in the air, is a major contributor to air pollution. These particles can penetrate deep into the lungs, causing respiratory diseases and aggravating existing health conditions. Ground-level ozone, another common air pollutant, can lead to respiratory problems and the formation of smog.\n\nTo combat air pollution, it is **imperative** to adopt sustainable practices and reduce dependence on fossil fuels. Governments play a crucial role in enforcing stringent emission standards for industries and promoting public transportation. Additionally, individuals can contribute by using energy-efficient appliances, carpooling, and planting trees to improve air quality. By collectively addressing the root causes of air pollution, we can create a healthier environment for current and future generations. Planting trees and participating in community clean-up efforts further contributes to the improvement of air quality at the local level.\n\nSource: slightly adapted from https://www.pw.live/exams/school/air-pollution-essay/"
    ],
    "images": [],
    "choices": [
      {
        "id": 7304,
        "content": [
          "compulsory"
        ],
        "isCorrect": true
      },
      {
        "id": 7305,
        "content": [
          "tentative"
        ],
        "isCorrect": false
      },
      {
        "id": 7306,
        "content": [
          "conditional"
        ],
        "isCorrect": false
      },
      {
        "id": 7307,
        "content": [
          "optional"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1825,
    "content": [
      "Answer the question based on the information found in the passage.",
      "---",
      "Which one of the following is **NOT** an air pollutant?"
    ],
    "explanation": [
      "The passage explicitly identifies particulate matter and ground-level ozone as air pollutants, and mentions smog as being formed due to ground-level ozone. Carpooling, however, is listed as an action individuals can take to *contribute* to combating air pollution, making it a solution, not a pollutant itself."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 25,
    "groupIndex": null,
    "sharedContentId": 9,
    "sharedContent": [
      "Air pollution, one of the most pressing environmental concerns, is posing significant risks to human health and the planet's well-being. It is characterized by the presence of pollutants in the air. It's not just about breathing problems; it also harms the heart and makes life less enjoyable. Particulate matter, consisting of tiny particles suspended in the air, is a major contributor to air pollution. These particles can penetrate deep into the lungs, causing respiratory diseases and aggravating existing health conditions. Ground-level ozone, another common air pollutant, can lead to respiratory problems and the formation of smog.\n\nTo combat air pollution, it is **imperative** to adopt sustainable practices and reduce dependence on fossil fuels. Governments play a crucial role in enforcing stringent emission standards for industries and promoting public transportation. Additionally, individuals can contribute by using energy-efficient appliances, carpooling, and planting trees to improve air quality. By collectively addressing the root causes of air pollution, we can create a healthier environment for current and future generations. Planting trees and participating in community clean-up efforts further contributes to the improvement of air quality at the local level.\n\nSource: slightly adapted from https://www.pw.live/exams/school/air-pollution-essay/"
    ],
    "images": [],
    "choices": [
      {
        "id": 7308,
        "content": [
          "smog"
        ],
        "isCorrect": false
      },
      {
        "id": 7309,
        "content": [
          "carpooling"
        ],
        "isCorrect": true
      },
      {
        "id": 7310,
        "content": [
          "ground-level ozone"
        ],
        "isCorrect": false
      },
      {
        "id": 7311,
        "content": [
          "particulate matter"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1826,
    "content": [
      "Choose the word opposite in meaning to the word below.",
      "---",
      "DAUNTING"
    ],
    "explanation": [
      "\"Daunting\" means seeming difficult to deal with in prospect; intimidating or discouraging. \"Entertaining\" means providing amusement or enjoyment. Things that are daunting are typically challenging and perhaps unpleasant to face, while things that are entertaining are enjoyable and engaging, making \"Entertaining\" the most nearly opposite choice. Discouraging, Intimidating, and Frightening are synonyms or closely related in meaning to Daunting."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANTONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 26,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7312,
        "content": [
          "Discouraging"
        ],
        "isCorrect": false
      },
      {
        "id": 7313,
        "content": [
          "Intimidating"
        ],
        "isCorrect": false
      },
      {
        "id": 7314,
        "content": [
          "Frightening"
        ],
        "isCorrect": false
      },
      {
        "id": 7315,
        "content": [
          "Entertaining"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1827,
    "content": [
      "Choose the word opposite in meaning to the word below.",
      "---",
      "IMMACULATE"
    ],
    "explanation": [
      "\"Immaculate\" means perfectly clean, neat, or tidy; free from flaws or mistakes. \"Filthy\" means disgustingly dirty. Therefore, \"Filthy\" is the most direct opposite of \"Immaculate\". \"Spotless\" and \"Tidy\" are synonyms or near-synonyms of Immaculate. \"Lucid\" means clear or easy to understand, which is unrelated."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANTONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 26,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7316,
        "content": [
          "Filthy"
        ],
        "isCorrect": true
      },
      {
        "id": 7317,
        "content": [
          "Lucid"
        ],
        "isCorrect": false
      },
      {
        "id": 7318,
        "content": [
          "Spotless"
        ],
        "isCorrect": false
      },
      {
        "id": 7319,
        "content": [
          "Tidy"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1828,
    "content": [
      "Choose the word opposite in meaning to the word below.",
      "---",
      "RAVAGE"
    ],
    "explanation": [
      "\"Ravage\" means to cause severe and extensive damage to something; to devastate or ruin. \"Renovate\" means to restore something old, especially a building, to a good state of repair. Thus, \"Renovate\" (to repair or restore) is the opposite of \"Ravage\" (to destroy or damage severely). \"Devastate,\" \"Ruin,\" and \"Damage\" are synonyms or related to the meaning of Ravage."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANTONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 26,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7320,
        "content": [
          "Devastate"
        ],
        "isCorrect": false
      },
      {
        "id": 7321,
        "content": [
          "Ruin"
        ],
        "isCorrect": false
      },
      {
        "id": 7322,
        "content": [
          "Damage"
        ],
        "isCorrect": false
      },
      {
        "id": 7323,
        "content": [
          "Renovate"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1829,
    "content": [
      "Answer the question based on the information found in the passage.",
      "---",
      "What does to \"**make informed decision**\" mean in the above passage? It means decision:"
    ],
    "explanation": [
      "The passage mentions education empowering individuals to make \"informed decisions\" about family size in the context of managing population growth.\n\nAn \"informed decision\" generally means a choice made after understanding the relevant facts and information. Therefore, it means a decision based on facts and information, not personal opinion or solely satisfying oneself or others."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 27,
    "groupIndex": null,
    "sharedContentId": 10,
    "sharedContent": [
      "Population, which means the total number of people living in a certain area, is a critical aspect of our world. However, this simple number has **far-reaching** effects on our world. It greatly influences our societies, economies, and environment. When population grows too rapidly, it can create problems like shortages of food, clean water, and housing. On the flip side, a declining population can lead to workforce shortages and economic difficulties. Striking a balance is essential.\n\nTo manage population growth, governments and communities implement various strategies. They promote family planning, educate people about birth control, and create job opportunities to reduce the pressure on resources. Education is a key tool here as it empowers individuals to make **informed decisions** about family size. In essence, understanding and managing population is crucial for ensuring a better quality of life for everyone and a sustainable future for our planet.\n\nSource: slightly adapted https://infinitylearn.com/surge/english/paragraph/population-paragraph/"
    ],
    "images": [],
    "choices": [
      {
        "id": 7324,
        "content": [
          "based on facts and information."
        ],
        "isCorrect": true
      },
      {
        "id": 7325,
        "content": [
          "made for the sake of satisfying oneself."
        ],
        "isCorrect": false
      },
      {
        "id": 7326,
        "content": [
          "made for the sake of satisfying others."
        ],
        "isCorrect": false
      },
      {
        "id": 7327,
        "content": [
          "based on mere personal opinion."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1830,
    "content": [
      "Answer the question based on the information found in the passage.",
      "---",
      "What is the theme of the passage?"
    ],
    "explanation": [
      "The passage discusses both the challenges of **rapid population growth** (shortages of food, water, and housing) and **declining population** (workforce shortages and economic difficulties). It emphasizes the importance of **striking a balance** to manage these issues.\n\nTherefore, the central theme is the need to maintain a balance between birth rate and death rate for a stable society."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 27,
    "groupIndex": null,
    "sharedContentId": 10,
    "sharedContent": [
      "Population, which means the total number of people living in a certain area, is a critical aspect of our world. However, this simple number has **far-reaching** effects on our world. It greatly influences our societies, economies, and environment. When population grows too rapidly, it can create problems like shortages of food, clean water, and housing. On the flip side, a declining population can lead to workforce shortages and economic difficulties. Striking a balance is essential.\n\nTo manage population growth, governments and communities implement various strategies. They promote family planning, educate people about birth control, and create job opportunities to reduce the pressure on resources. Education is a key tool here as it empowers individuals to make **informed decisions** about family size. In essence, understanding and managing population is crucial for ensuring a better quality of life for everyone and a sustainable future for our planet.\n\nSource: slightly adapted https://infinitylearn.com/surge/english/paragraph/population-paragraph/"
    ],
    "images": [],
    "choices": [
      {
        "id": 7328,
        "content": [
          "Population control and its disadvantages."
        ],
        "isCorrect": false
      },
      {
        "id": 7329,
        "content": [
          "The need to balance birth rate and death rate."
        ],
        "isCorrect": true
      },
      {
        "id": 7330,
        "content": [
          "Population growth always poses challenges."
        ],
        "isCorrect": false
      },
      {
        "id": 7331,
        "content": [
          "Decline in population size has problems."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1831,
    "content": [
      "Answer the question based on the information found in the passage.",
      "---",
      "Based on the information given in the passage, which one of the following statements is correct?"
    ],
    "explanation": [
      "The passage states that **\"governments and communities implement various strategies\"** to manage population growth. It mentions efforts like family planning, education, and job creation, which involve both **government policies** and **community participation**. This makes it clear that population control is a shared responsibility."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 27,
    "groupIndex": null,
    "sharedContentId": 10,
    "sharedContent": [
      "Population, which means the total number of people living in a certain area, is a critical aspect of our world. However, this simple number has **far-reaching** effects on our world. It greatly influences our societies, economies, and environment. When population grows too rapidly, it can create problems like shortages of food, clean water, and housing. On the flip side, a declining population can lead to workforce shortages and economic difficulties. Striking a balance is essential.\n\nTo manage population growth, governments and communities implement various strategies. They promote family planning, educate people about birth control, and create job opportunities to reduce the pressure on resources. Education is a key tool here as it empowers individuals to make **informed decisions** about family size. In essence, understanding and managing population is crucial for ensuring a better quality of life for everyone and a sustainable future for our planet.\n\nSource: slightly adapted https://infinitylearn.com/surge/english/paragraph/population-paragraph/"
    ],
    "images": [],
    "choices": [
      {
        "id": 7332,
        "content": [
          "Having the requisite understanding about population is what matters most."
        ],
        "isCorrect": false
      },
      {
        "id": 7333,
        "content": [
          "Both the government and the community are responsible for controlling population."
        ],
        "isCorrect": true
      },
      {
        "id": 7334,
        "content": [
          "The role of the community is highly constrained."
        ],
        "isCorrect": false
      },
      {
        "id": 7335,
        "content": [
          "It is the sole responsibility of the government to control population growth."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1832,
    "content": [
      "Answer the question based on the information found in the passage.",
      "---",
      "What does the word \"**far-reaching**\" mean according to the context of the passage?"
    ],
    "explanation": [
      "In the passage, \"far-reaching\" describes the **effects of population on societies, economies, and the environment**. This means population has **broad and significant impacts**, particularly on economic development, resource distribution, and overall societal well-being. Therefore, **option B best captures the meaning of \"far-reaching\" in this context**."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 27,
    "groupIndex": null,
    "sharedContentId": 10,
    "sharedContent": [
      "Population, which means the total number of people living in a certain area, is a critical aspect of our world. However, this simple number has **far-reaching** effects on our world. It greatly influences our societies, economies, and environment. When population grows too rapidly, it can create problems like shortages of food, clean water, and housing. On the flip side, a declining population can lead to workforce shortages and economic difficulties. Striking a balance is essential.\n\nTo manage population growth, governments and communities implement various strategies. They promote family planning, educate people about birth control, and create job opportunities to reduce the pressure on resources. Education is a key tool here as it empowers individuals to make **informed decisions** about family size. In essence, understanding and managing population is crucial for ensuring a better quality of life for everyone and a sustainable future for our planet.\n\nSource: slightly adapted https://infinitylearn.com/surge/english/paragraph/population-paragraph/"
    ],
    "images": [],
    "choices": [
      {
        "id": 7336,
        "content": [
          "facilitating resource allocation"
        ],
        "isCorrect": false
      },
      {
        "id": 7337,
        "content": [
          "impacting economic development"
        ],
        "isCorrect": true
      },
      {
        "id": 7338,
        "content": [
          "affecting certain areas"
        ],
        "isCorrect": false
      },
      {
        "id": 7339,
        "content": [
          "going to faraway places"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1833,
    "content": [
      "Assume all statements are true. Then, evaluate each conclusion (I, II, etc.) and decide which one(s) logically follow from the statements.",
      "---",
      "**Statement:** Thomas Edison failed so many times before he invented the light bulb. Instead of quitting, however, Edison tried again and again until he finally achieved success. His achievement was applauded as an extraordinary determination.",
      "**Conclusion I:** A problem can be a chance to do one's best.",
      "**Conclusion II:** It is advisable to have perseverance in the face of challenges.",
      "**Conclusion III:** One has to always indulge in a problem whatever the consequences may be.",
      "A more valid conclusion for the above statement is:"
    ],
    "explanation": [
      "Conclusions I and II follow because the statement highlights Edison's perseverance and how he viewed failures as steps toward success.\n\nConclusion III does not follow, as the statement does not imply engaging in a problem regardless of consequences."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 28,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7340,
        "content": [
          "Conclusions I and II"
        ],
        "isCorrect": true
      },
      {
        "id": 7341,
        "content": [
          "Conclusions II and III"
        ],
        "isCorrect": false
      },
      {
        "id": 7342,
        "content": [
          "Conclusion II"
        ],
        "isCorrect": false
      },
      {
        "id": 7343,
        "content": [
          "Conclusion I"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1834,
    "content": [
      "It is apparent that most of the well-paid jobs in today's thriving economy require a higher level learning, usually a university degree. Conversely, many of the new jobs being created and flourishing, ranging from medium level businesses to huge manufacturing industries mainly require knowledge other than just having a degree. For workers in these new jobs, basic skills in communication, interpersonal skills and team work play a crucial role in getting a job and attaining career development.",
      "Based on this information, it is valid to conclude that:"
    ],
    "explanation": [
      "The passage highlights that many of the new and flourishing jobs prioritize skills like communication, interpersonal skills, and teamwork over just having a degree."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 28,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7344,
        "content": [
          "Career development in most jobs is impossible without producing a degree."
        ],
        "isCorrect": false
      },
      {
        "id": 7345,
        "content": [
          "A university degree is irrelevant for the newly created and flourishing jobs."
        ],
        "isCorrect": false
      },
      {
        "id": 7346,
        "content": [
          "The new jobs that are being created rather require knowledge of soft skills."
        ],
        "isCorrect": true
      },
      {
        "id": 7347,
        "content": [
          "Holding a university degree is crucial for career development."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1835,
    "content": [
      "Assume all statements are true. Then, evaluate each conclusion (I, II, etc.) and decide which one(s) logically follow from the statements.",
      "---",
      "**Statement I:** For quite some years now, several sub-cities in Addis Ababa get one or two days' of water supply per week.",
      "**Statement II:** There has been significant imbalance between demand for and supply of water in the city",
      "**Statement III:** There has been a booming water trading market in the city in the last few years.",
      "Which one of the following ideas is **TRUE** about the above statements?"
    ],
    "explanation": [
      "Statement II describes a fundamental problem: water demand exceeds supply (imbalance). This imbalance (cause) leads to consequences like rationing (Statement I - getting water only 1-2 days/week) and the emergence of alternative markets (Statement III - a booming water trading market to meet unmet demand).\n\nTherefore, Statement II is the underlying cause, and Statements I and III are effects or consequences stemming from that imbalance."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 28,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7348,
        "content": [
          "Each of the three is an independent cause for three different effects."
        ],
        "isCorrect": false
      },
      {
        "id": 7349,
        "content": [
          "Statement III is the cause and statements I and II are its effects."
        ],
        "isCorrect": false
      },
      {
        "id": 7350,
        "content": [
          "Statement II is the cause and statements I and III are its effects."
        ],
        "isCorrect": true
      },
      {
        "id": 7351,
        "content": [
          "Statement I is the cause and statements II and III are its effects."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1836,
    "content": [
      "Assume all statements are true. Then, evaluate each conclusion (I, II, etc.) and decide which one(s) logically follow from the statements.",
      "---",
      "**Statement:** XYZ company workers who have their own cars are constantly complaining as they do not get parking spaces either in the company compound or by the side of the street facing the company. The company administration couldn't give any solutions to the complaints of the workers.",
      "**Conclusion I:** The workers should start using public transportation.",
      "**Conclusion II:** The workers should leave their cars at home.",
      "**Conclusion III:** The workers should rather sell their cars",
      "Which one of the following conclusions would follow from the above statement?"
    ],
    "explanation": [
      "The statement describes a parking problem for workers with cars and the administration's inability to solve it.\n\nConclusions I (use public transport) and II (leave cars at home) are logical potential actions workers could take to avoid the parking problem described. These actions directly address the issue of bringing a car to work when parking is unavailable.\n\nConclusion III (sell their cars) is an extreme measure and doesn't necessarily follow logically just from a parking issue at work; the workers might need their cars for other purposes.\n\nTherefore, Conclusions I and II are the most direct and plausible actions that follow from the situation described."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 28,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7352,
        "content": [
          "Both conclusions I and III"
        ],
        "isCorrect": false
      },
      {
        "id": 7353,
        "content": [
          "Both conclusions I and II"
        ],
        "isCorrect": true
      },
      {
        "id": 7354,
        "content": [
          "Conclusion II"
        ],
        "isCorrect": false
      },
      {
        "id": 7355,
        "content": [
          "Conclusion I"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1837,
    "content": [
      "Five students (namely **Ha**, **Ga**, **Ta**, **Za** and **Ya**), all from the same grade level sat for four exams on four different subjects: English, History, Geography and Mathematics. For **Ha** History was the easiest while Mathematics was the most difficult; on the other hand, **Ga** found them to be the reverse of what **Ha** found them to be. **Ta** found both History and Mathematics the hardest and Geography the easiest. **Za** rather found them to be the opposite of what **Ta** found them to be. For **Ya**, what **Ha** found the easiest was the most difficult.",
      "According to the text, which subject was the most difficult one for most of the students?"
    ],
    "explanation": [
      "Let's determine the most difficult subject for each student based on the provided information:\n- **Ha:** Mathematics is most difficult.\n- **Ga:** Finds subjects the reverse of Ha, so History is most difficult.\n- **Ta:** Finds History and Mathematics the hardest (most difficult).\n- **Za:** Finds subjects the opposite of Ta. Since Ta found Geography easiest, Za finds Geography most difficult. (Also, Za finds History & Maths easiest).\n- **Ya:** Finds what Ha found easiest (History) to be the most difficult. So, History is most difficult for Ya.\n\nCounting the students for whom each subject was most difficult:\n\n- Mathematics: Ha, Ta (2 students)\n- History: Ga, Ta, Ya (3 students)\n- Geography: Za (1 student)\n- English: (0 students)\n\nHistory was the most difficult subject for the highest number of students (3)."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 28,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7356,
        "content": [
          "Mathematics"
        ],
        "isCorrect": false
      },
      {
        "id": 7357,
        "content": [
          "English"
        ],
        "isCorrect": false
      },
      {
        "id": 7358,
        "content": [
          "History"
        ],
        "isCorrect": true
      },
      {
        "id": 7359,
        "content": [
          "Geography"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1838,
    "content": [
      "Assume all statements are true. Then, evaluate each conclusion (I, II, etc.) and decide which one(s) logically follow from the statements.",
      "---",
      "**Assumption:** Most traffic accidents in Ethiopia are caused mainly because of what many drivers commit while driving: such as talking on the phone, exchanging text messages, violation of traffic regulations, and recklessness among other causes.",
      "**Conclusion I:** Most traffic accidents are caused because drivers do not have the requisite driving skills.",
      "**Conclusion II:** Most traffic accidents are caused due to the decisions such drivers make while they are driving.",
      "**Conclusion III:** Most traffic accidents are the consequences of the ill-behaviors of such drivers.",
      "Which one of the following conclusions is more logical for the above assumption?"
    ],
    "explanation": [
      "The assumption attributes accidents to specific driver actions while driving (talking on phone, texting, violations, recklessness).\n\n- Conclusion I focuses on lack of skills, which isn't the primary focus of the assumption (though related, the assumption emphasizes actions/choices).\n- Conclusion II focuses on driver decisions. The actions listed (talking, texting, violating rules) are indeed decisions made by drivers while driving. This follows logically.\n- Conclusion III focuses on ill-behaviors. The actions listed are clearly examples of ill-advised or negative behaviors while driving. This also follows logically.\n\nSince the assumption lists specific actions that represent both poor decisions and ill-behaviors leading to accidents, both Conclusion II and Conclusion III are logical consequences derived directly from the assumption."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 28,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7360,
        "content": [
          "Both conclusion II and III"
        ],
        "isCorrect": true
      },
      {
        "id": 7361,
        "content": [
          "Both conclusions I and II"
        ],
        "isCorrect": false
      },
      {
        "id": 7362,
        "content": [
          "Conclusion II"
        ],
        "isCorrect": false
      },
      {
        "id": 7363,
        "content": [
          "Conclusion I"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1839,
    "content": [
      "Choose the word which could be interchangeably used with the words that is capitalized.",
      "---",
      "Risk factors such as smoking, overweight, lack of physical exercise and stress **EXACERBATE** blood pressure, heart disease, and gastro-intestinal problems."
    ],
    "explanation": [
      "'Exacerbate' means to make a problem, bad situation, or negative feeling worse. 'Aggravate' also means to make a problem worse or more serious, making it the best synonym in this context."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_WORD_SUBSTITUTION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 29,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7364,
        "content": [
          "moderate"
        ],
        "isCorrect": false
      },
      {
        "id": 7365,
        "content": [
          "mitigate"
        ],
        "isCorrect": false
      },
      {
        "id": 7366,
        "content": [
          "aggravate"
        ],
        "isCorrect": true
      },
      {
        "id": 7367,
        "content": [
          "improve"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1840,
    "content": [
      "Choose the word which could be interchangeably used with the words that is capitalized.",
      "---",
      "Unethical work habits **JEOPARDIZE** individuals' development efforts and a country's overall growth potential."
    ],
    "explanation": [
      "'Jeopardize' means to put (someone or something) into a situation in which there is a danger of loss, harm, or failure. 'Detriment' means harm or damage."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_WORD_SUBSTITUTION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 29,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7368,
        "content": [
          "detriment"
        ],
        "isCorrect": true
      },
      {
        "id": 7369,
        "content": [
          "facilitate"
        ],
        "isCorrect": false
      },
      {
        "id": 7370,
        "content": [
          "speed-up"
        ],
        "isCorrect": false
      },
      {
        "id": 7371,
        "content": [
          "accelerate"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1841,
    "content": [
      "Choose the word which could be interchangeably used with the words that is capitalized.",
      "---",
      "Lowland areas usually get **INTERMITTENT** rain; as a result, they have low animal and crop productions."
    ],
    "explanation": [
      "'Intermittent' means occurring at irregular intervals; not continuous or steady. 'Sporadic' also means occurring at irregular intervals or only in a few places; scattered or isolated, making it the closest synonym."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_WORD_SUBSTITUTION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 29,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7372,
        "content": [
          "substantial"
        ],
        "isCorrect": false
      },
      {
        "id": 7373,
        "content": [
          "frequent"
        ],
        "isCorrect": false
      },
      {
        "id": 7374,
        "content": [
          "regular"
        ],
        "isCorrect": false
      },
      {
        "id": 7375,
        "content": [
          "sporadic"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1842,
    "content": [
      "Choose the option that best completes the sentence.",
      "---",
      "Many health professionals believe that laughter has __________ effects on the human body as it enhances both physical and emotional health."
    ],
    "explanation": [
      "The sentence states that laughter *enhances* health, indicating a positive effect. 'Therapeutic' means having healing or curative properties, which aligns with the idea of enhancing physical and emotional health."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SENTENCE_COMPLETION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 30,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7376,
        "content": [
          "detrimental"
        ],
        "isCorrect": false
      },
      {
        "id": 7377,
        "content": [
          "harmful"
        ],
        "isCorrect": false
      },
      {
        "id": 7378,
        "content": [
          "therapeutic"
        ],
        "isCorrect": true
      },
      {
        "id": 7379,
        "content": [
          "adverse"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1843,
    "content": [
      "Choose the option that best completes the sentence.",
      "---",
      "The __________ forests in western Ethiopia, accompanied by the shrimps and singing of birds and the fresh breeze are really inspirational."
    ],
    "explanation": [
      "The context describes an \"inspirational\" scene with singing birds and a fresh breeze. 'Tranquil', meaning calm and peaceful, fits this positive and serene description much better than words suggesting emptiness or neglect."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SENTENCE_COMPLETION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 30,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7380,
        "content": [
          "abandoned"
        ],
        "isCorrect": false
      },
      {
        "id": 7381,
        "content": [
          "deserted"
        ],
        "isCorrect": false
      },
      {
        "id": 7382,
        "content": [
          "empty"
        ],
        "isCorrect": false
      },
      {
        "id": 7383,
        "content": [
          "tranquil"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1844,
    "content": [
      "Choose the option that best completes the sentence.",
      "---",
      "As it contains students from diverse cultural backgrounds, the class is a highly __________ one."
    ],
    "explanation": [
      "The phrase \"diverse cultural backgrounds\" directly implies variety and mixture. 'Heterogeneous' means diverse in character or content, accurately describing a class with students from many different backgrounds."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SENTENCE_COMPLETION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 30,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7384,
        "content": [
          "invariable"
        ],
        "isCorrect": false
      },
      {
        "id": 7385,
        "content": [
          "consistent"
        ],
        "isCorrect": false
      },
      {
        "id": 7386,
        "content": [
          "homogenous"
        ],
        "isCorrect": false
      },
      {
        "id": 7387,
        "content": [
          "heterogeneous"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1845,
    "content": [
      "Choose the option that best completes the sentence.",
      "---",
      "To fight some of the incurable diseases, the world is facing currently, scientists are __________  biotechnology to develop effective drugs."
    ],
    "explanation": [
      "To develop effective drugs against diseases, scientists would logically make use of relevant tools like biotechnology. 'Utilizing' means making practical and effective use of something, which fits the context of applying biotechnology for drug development."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SENTENCE_COMPLETION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 30,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7388,
        "content": [
          "setting aside"
        ],
        "isCorrect": false
      },
      {
        "id": 7389,
        "content": [
          "utilizing"
        ],
        "isCorrect": true
      },
      {
        "id": 7390,
        "content": [
          "discounting"
        ],
        "isCorrect": false
      },
      {
        "id": 7391,
        "content": [
          "overlooking"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1846,
    "content": [
      "Choose the one grammatically correct sentence among the options."
    ],
    "explanation": [
      "- Option D is the only grammatically sound sentence.\n- Option A has incorrect verb form \"can visited\".\n- Option B is redundant with \"return back\".\n- Option C is redundant with \"In my opinion, I think\" and grammatically incorrect with \"when we back\"."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SENTENCE_CORRECTION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 31,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7392,
        "content": [
          "In my opinion, we can visited our friend when we return from school."
        ],
        "isCorrect": false
      },
      {
        "id": 7393,
        "content": [
          "In my opinion, we can visit our friend when we return back from school."
        ],
        "isCorrect": false
      },
      {
        "id": 7394,
        "content": [
          "In my opinion, I think, we can visit our friend when we back from school."
        ],
        "isCorrect": false
      },
      {
        "id": 7395,
        "content": [
          "In my opinion, we can visit our friend when we are back from school."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1847,
    "content": [
      "Choose the one grammatically correct sentence among the options."
    ],
    "explanation": [
      "Option D is the only sentence that makes logical sense.\n\nOptions A, B, and C nonsensically suggest the dog was riding the bicycle. Option D correctly clarifies that the speaker (\"I\") was riding the bicycle when the dog barked."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SENTENCE_CORRECTION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 31,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7396,
        "content": [
          "The dog that was riding a bicycle barked at me."
        ],
        "isCorrect": false
      },
      {
        "id": 7397,
        "content": [
          "The dog, while it was riding a bicycle, barked at me."
        ],
        "isCorrect": false
      },
      {
        "id": 7398,
        "content": [
          "While it was riding a bicycle the dog barked at me."
        ],
        "isCorrect": false
      },
      {
        "id": 7399,
        "content": [
          "The dog barked at me while I was riding a bicycle."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1848,
    "content": [
      "Choose the one grammatically correct sentence among the options"
    ],
    "explanation": [
      "- Option B uses the correct question structure \"What are the things [that] you enjoy doing...?\".\n- Option A has incorrect verb structure \"are you enjoy\".\n- Option C has incorrect structure \"you are enjoy\".\n- Option D is would be grammatically possible if written \"What things [do] you enjoy...\"."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SENTENCE_CORRECTION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 31,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7400,
        "content": [
          "What things are you enjoy doing in your spare time?"
        ],
        "isCorrect": false
      },
      {
        "id": 7401,
        "content": [
          "What are the things you enjoy doing in your spare time?"
        ],
        "isCorrect": true
      },
      {
        "id": 7402,
        "content": [
          "What things you are enjoy doing in your spare time?"
        ],
        "isCorrect": false
      },
      {
        "id": 7403,
        "content": [
          "What things you enjoy doing in your spare time?"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1849,
    "content": [
      "Choose the one grammatically correct sentence among the options."
    ],
    "explanation": [
      "- Option C makes the correct comparison using \"greater than that of India\", where \"that\" properly refers back to \"population\".\n- Option A uses the incorrect comparative \"more great\".\n- Options B and D make illogical comparisons between \"population\" and the country \"India\" or the prepositional phrase \"in India\"."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SENTENCE_CORRECTION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 31,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7404,
        "content": [
          "The population of China is more great than India."
        ],
        "isCorrect": false
      },
      {
        "id": 7405,
        "content": [
          "The population of China is greater than in India."
        ],
        "isCorrect": false
      },
      {
        "id": 7406,
        "content": [
          "The population of China is greater than that of India."
        ],
        "isCorrect": true
      },
      {
        "id": 7407,
        "content": [
          "The population of China is greater than India."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1850,
    "content": [
      "Choose the word that is nearly similar in meaning to the word below.",
      "---",
      "**CONDONE**"
    ],
    "explanation": [
      "'Condone' means to accept or overlook behavior that is considered wrong. 'Forgive' means to stop feeling angry or resentful towards someone for an offense.."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 32,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7408,
        "content": [
          "Forgive"
        ],
        "isCorrect": true
      },
      {
        "id": 7409,
        "content": [
          "Complicate"
        ],
        "isCorrect": false
      },
      {
        "id": 7410,
        "content": [
          "Confuse"
        ],
        "isCorrect": false
      },
      {
        "id": 7411,
        "content": [
          "Discourage"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1851,
    "content": [
      "Choose the word that is nearly similar in meaning to the word below.",
      "---",
      "**ADHERE**"
    ],
    "explanation": [
      "'Adhere' means to stick to something physically, or to follow rules, beliefs, or instructions. 'Obey' means to comply with commands or laws."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 32,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7412,
        "content": [
          "Decline"
        ],
        "isCorrect": false
      },
      {
        "id": 7413,
        "content": [
          "Drop"
        ],
        "isCorrect": false
      },
      {
        "id": 7414,
        "content": [
          "Abandon"
        ],
        "isCorrect": false
      },
      {
        "id": 7415,
        "content": [
          "Obey"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1852,
    "content": [
      "Choose the word that is nearly similar in meaning to the word below.",
      "---",
      "**FEASIBLE**"
    ],
    "explanation": [
      "'Feasible' means possible to do easily or conveniently; likely. 'Achievable' means able to be brought about or reached successfully."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 32,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7416,
        "content": [
          "Unrealistic"
        ],
        "isCorrect": false
      },
      {
        "id": 7417,
        "content": [
          "Impractical"
        ],
        "isCorrect": false
      },
      {
        "id": 7418,
        "content": [
          "Achievable"
        ],
        "isCorrect": true
      },
      {
        "id": 7419,
        "content": [
          "Ambitious"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1853,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "**BOTANY: PLANTS;**",
      "__________ : Soil"
    ],
    "explanation": [
      "The relationship is \"field of study : subject studied\". Botany is the scientific study of plants. Pedology is the scientific study of soil."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 33,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7420,
        "content": [
          "Sociology"
        ],
        "isCorrect": false
      },
      {
        "id": 7421,
        "content": [
          "Pedagogy"
        ],
        "isCorrect": false
      },
      {
        "id": 7422,
        "content": [
          "Pedology"
        ],
        "isCorrect": true
      },
      {
        "id": 7423,
        "content": [
          "Biology"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1854,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "**WONDERFUL: SATISFACTORY;**",
      "Gigantic: __________"
    ],
    "explanation": [
      "The relationship is \"extreme degree : moderate degree\". Wonderful is an extreme degree of satisfactory. Gigantic is an extreme degree of large."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 33,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7424,
        "content": [
          "Broad"
        ],
        "isCorrect": false
      },
      {
        "id": 7425,
        "content": [
          "Large"
        ],
        "isCorrect": true
      },
      {
        "id": 7426,
        "content": [
          "Comprehensive"
        ],
        "isCorrect": false
      },
      {
        "id": 7427,
        "content": [
          "Spacious"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1855,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "**JUSTICE: FAIRNESS;**",
      "_________ : Bias"
    ],
    "explanation": [
      "The relationship is \"concept : defining characteristic/synonym\" or potentially \"ideal : its opposite's defining characteristic\". Justice is characterized by fairness. Prejudice is characterized by bias."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 33,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7428,
        "content": [
          "Rational"
        ],
        "isCorrect": false
      },
      {
        "id": 7429,
        "content": [
          "Prejudice"
        ],
        "isCorrect": true
      },
      {
        "id": 7430,
        "content": [
          "Compassion"
        ],
        "isCorrect": false
      },
      {
        "id": 7431,
        "content": [
          "Just"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1856,
    "content": [
      "Identify the relationship between the capitalized words. Then, apply the same relationship to find the correct answer.",
      "---",
      "**TEAM: PLAYER;**",
      "__________ : Member"
    ],
    "explanation": [
      "The relationship is \"group : individual component\". A player is an individual component of a team. A member is an individual component of a crew."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 33,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7432,
        "content": [
          "Crew"
        ],
        "isCorrect": true
      },
      {
        "id": 7433,
        "content": [
          "Musician"
        ],
        "isCorrect": false
      },
      {
        "id": 7434,
        "content": [
          "Vocalist"
        ],
        "isCorrect": false
      },
      {
        "id": 7435,
        "content": [
          "Trainer"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1857,
    "content": [
      "For what value(s) of k, does the system of linear equations\n$$\n\\begin{cases}\n2x + 3y = 1 \\\\\nkx + 6y = -3\n\\end{cases}\n$$\nhave a unique solution?"
    ],
    "explanation": [
      "A system of two linear equations $$a_1x + b_1y = c_1$$ and $$a_2x + b_2y = c_2$$ has a unique solution if the ratio of the coefficients of x is not equal to the ratio of the coefficients of y, i.e.,\n$$\n\\frac{a_1}{a_2} \\neq \\frac{b_1}{b_2}\n$$\nFor the given system, $$a_1 = 2$$, $$b_1 = 3$$, $$a_2 = k$$, $$b_2 = 6$$. The condition for a unique solution is\n$$\n\\frac{2}{k} \\neq \\frac{3}{6}\n$$\nSimplifying $$\\frac{3}{6}$$ gives $$\\frac{1}{2}$$. So,\n$$\n\\frac{2}{k} \\neq \\frac{1}{2}\n$$\n$$\n2 \\times 2 \\neq k \\times 1\n$$\nWhich simplifies to\n$$\n4 \\neq k\n$$\nTherefore, the system has a unique solution when $$k \\neq 4$$."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7436,
        "content": [
          "$$k = -4$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7437,
        "content": [
          "$$k \\neq 4$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7438,
        "content": [
          "$$k = 4$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7439,
        "content": [
          "$$k \\neq -4$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1858,
    "content": [
      "If $$\\frac{3x^2 + 1}{3x + 6}$$ = $$\\frac{x^2}{x + 2}$$ - $$3$$, then what is the value of $$\\frac{1}{9x + 1}$$?"
    ],
    "explanation": [
      "First, simplify the given equation. Notice that $$3x + 6 = 3(x+2)$$. Substitute this into the equation:\n$$\n\\frac{3x^2 + 1}{3(x + 2)} = \\frac{x^2}{x + 2} - 3\n$$\nMultiply the entire equation by $$3(x+2)$$ (assuming $$x \\neq -2$$) to clear the denominators:\n$$\n3x^2 + 1 = 3(x^2) - 3(3(x+2))\n$$\n$$\n3x^2 + 1 = 3x^2 - 9x - 18\n$$\n$$\n1 = -9x - 18\n$$\n$$\n19 = -9x\n$$\n$$\nx = -\\frac{19}{9}\n$$\nNow substitute this value of x into the expression $$\\frac{1}{9x + 1}$$:\n$$\n\\frac{1}{9(-\\frac{19}{9}) + 1} = \\frac{1}{-19 + 1}\n$$\n$$\n= \\frac{1}{-18} = -\\frac{1}{18}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7440,
        "content": [
          "$$-\\frac{1}{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7441,
        "content": [
          "$$\\frac{1}{20}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7442,
        "content": [
          "$$-\\frac{1}{18}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7443,
        "content": [
          "$$\\frac{1}{18}$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1859,
    "content": [
      "The difference of two numbers is 10, and the sum of three times the larger number and twice the smaller number is 55. Then which one of the following is the value of the larger number?"
    ],
    "explanation": [
      "Let the larger number be L and the smaller number be S. We are given two equations:\n- 1) $$L - S = 10$$\n- 2) $$3L + 2S = 55$$.\n\nFrom equation 1, we can express L as $$L = S + 10$$. Substitute this into equation 2:\n$$\n3(S + 10) + 2S = 55\n$$\n$$\nS = 5\n$$\nNow find the larger number using $$L = S + 10$$:\n$$\nL = 5 + 10 = 15\n$$\nThe larger number is 15"
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7444,
        "content": [
          "14"
        ],
        "isCorrect": false
      },
      {
        "id": 7445,
        "content": [
          "15"
        ],
        "isCorrect": true
      },
      {
        "id": 7446,
        "content": [
          "6"
        ],
        "isCorrect": false
      },
      {
        "id": 7447,
        "content": [
          "5"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1860,
    "content": [
      "What percent of 16 is 12?"
    ],
    "explanation": [
      "To find what percent of 16 is 12, we set up the equation\n$$\n\\frac{\\text{part}}{\\text{whole}} = \\frac{\\text{percent}}{100}\n$$\nHere, the part is 12 and the whole is 16. Let P be the percent. So,\n$$\n\\frac{12}{16} = \\frac{P}{100}\n$$\n$$\n\\frac{3}{4} = \\frac{P}{100}\n$$\n$$\nP = 3 \\times 25 = 75\n$$\nTherefore, 12 is 75% of 16"
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7448,
        "content": [
          "70%"
        ],
        "isCorrect": false
      },
      {
        "id": 7449,
        "content": [
          "50%"
        ],
        "isCorrect": false
      },
      {
        "id": 7450,
        "content": [
          "25%"
        ],
        "isCorrect": false
      },
      {
        "id": 7451,
        "content": [
          "75%"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1861,
    "content": [
      "One root of the equation $$2x^2 + 1 = h - 5x$$ (where h is a constant) is four times the other root. What are the roots of the given equation?"
    ],
    "explanation": [
      "First, rewrite the quadratic equation in the standard form\n$$\nax^2 + bx + c = 0\n$$\nThe equation $$2x^2 + 1$$ = $$h - 5x$$ becomes\n$$\n2x^2 + 5x + (1 - h) = 0\n$$\nLet the roots of this equation be $$r_1$$ and $$r_2$$. We are given that one root is four times the other, so let $$r_1 = 4r_2$$.\n\nAccording to Vieta's formulas for a quadratic equation, the sum of the roots is $$r_1 + r_2$$ = $$-\\frac{b}{a}$$, and the product of the roots is $$r_1 r_2$$ = $$\\frac{c}{a}$$.\n\nIn this equation, $$a = 2$$, $$b = 5$$, and $$c = (1 - h)$$.\n\nUsing the sum of the roots formula:\n$$\n4r_2 + r_2 = -\\frac{5}{2}\n$$\n$$\nr_2 = \\frac{-5}{2 \\times 5} = -\\frac{1}{2}\n$$\nNow, find the other root $$r_1$$ using the relationship $$r_1 = 4r_2$$:\n$$\nr_1 = 4 \\times (-\\frac{1}{2}) = -2\n$$\nThus, the roots of the equation are $$-\\frac{1}{2}$$ and $$-2$$."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7452,
        "content": [
          "$$-2$$ and $$-8$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7453,
        "content": [
          "$$2$$ and $$8$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7454,
        "content": [
          "$$-\\frac{1}{2}$$ and $$-2$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7455,
        "content": [
          "$$\\frac{1}{2}$$ and $$2$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1862,
    "content": [
      "How many different four letter words which start with vowel can be formed from the word MATH if the letters cannot be used more than once?"
    ],
    "explanation": [
      "The given word is **MATH**, and we need to form four-letter words starting with a vowel. The vowels available are **A**.\n\nFix **A** in the first position.\n\nThe remaining three positions can be filled using **M, T, H** in any order.\n\nThe number of ways to arrange **M, T, H** is:\n$$\n3! = 6\n$$\nThus, the correct answer is: **6**"
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7456,
        "content": [
          "24"
        ],
        "isCorrect": false
      },
      {
        "id": 7457,
        "content": [
          "18"
        ],
        "isCorrect": false
      },
      {
        "id": 7458,
        "content": [
          "8"
        ],
        "isCorrect": false
      },
      {
        "id": 7459,
        "content": [
          "6"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1863,
    "content": [
      "A bag contains 15 balls, numbered 1 through 15. What is the probability of selecting a number that is odd or a multiple of 4?"
    ],
    "explanation": [
      "Total numbers in the bag: 15\n\nNumbers that are odd: 1, 3, 5, 7, 9, 11, 13, 15 (8 numbers)\n\nNumbers that are multiples of 4: 4, 8, 12 (3 numbers)\n\nThere is no overlap between odd numbers and multiples of 4.\n\nThus, the total favorable outcomes = 8 + 3 = 11\n\nProbability:\n\n$$\n\\frac{11}{15}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7460,
        "content": [
          "$$\\frac{1}{3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7461,
        "content": [
          "$$\\frac{11}{15}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7462,
        "content": [
          "$$\\frac{1}{5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7463,
        "content": [
          "$$\\frac{8}{15}$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1864,
    "content": [
      "Let $$\\triangle ABC$$ be an isosceles triangle with $$\\angle C = 90^\\circ$$. If the length of side $$\\overline{AC}$$ is 4 cm, then what is the length of side $$\\overline{AB}$$ in centimeters?"
    ],
    "explanation": [
      "Given that $$\\triangle ABC$$ is an **isosceles right triangle** with $$\\angle C = 90^\\circ$$, the two legs are equal in length. That means:\n$$\nAC = BC = 4 \\text{ cm}\n$$\nBy the Pythagorean theorem:\n$$\nAB = \\sqrt{AC^2 + BC^2}\n$$\n$$\nAB = \\sqrt{4^2 + 4^2} = \\sqrt{32} = 4\\sqrt{2}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7464,
        "content": [
          "$$4\\sqrt{2}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7465,
        "content": [
          "8"
        ],
        "isCorrect": false
      },
      {
        "id": 7466,
        "content": [
          "4"
        ],
        "isCorrect": false
      },
      {
        "id": 7467,
        "content": [
          "$$2\\sqrt{2}$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1865,
    "content": [
      "Which one of the following can NOT be the degree measure of each interior angle of a regular polygon?"
    ],
    "explanation": [
      "The formula for the measure of each interior angle $$I$$ of a regular polygon with $$n$$ sides is\n$$\nI = \\frac{(n-2) \\times 180^\\circ}{n}\n$$\nFor a geometric figure to be a regular polygon, the number of sides $$n$$ must be an integer greater than or equal to 3. We can rearrange the formula to solve for $$n$$:\n$$\nI \\times n = (n-2) \\times 180\n$$\n$$\nI \\times n = 180n - 360\n$$\n$$\nn = \\frac{360}{180 - I}\n$$\nWe test each option to see if it yields an integer value for $$n \\ge 3$$.\n\nIf $$I = 140^\\circ$$\n$$\nn = \\frac{360}{180 - 140} = \\frac{360}{40} = 9\n$$\nSince n=9 is an integer $$\\ge 3$$, $$140^\\circ$$ is possible (regular nonagon).\n\nIf $$I = 105^\\circ$$\n$$\nn = \\frac{360}{180 - 105} = \\frac{360}{75} = 4.8\n$$\nSince n=4.8 is not an integer, $$105^\\circ$$ cannot be the interior angle of a regular polygon.\n\nIf $$I = 120^\\circ$$\n$$\nn = \\frac{360}{180 - 120} = \\frac{360}{60} = 6\n$$\nSince n=6 is an integer $$\\ge 3$$, $$120^\\circ$$ is possible (regular hexagon).\n\nIf $$I = 135^\\circ$$\n$$\nn = \\frac{360}{180 - 135} = \\frac{360}{45} = 8\n$$\nSince n=8 is an integer $$\\ge 3$$, $$135^\\circ$$ is possible (regular octagon).\n\nTherefore, $$105^\\circ$$ cannot be the measure."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7468,
        "content": [
          "$$140^\\circ$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7469,
        "content": [
          "$$105^\\circ$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7470,
        "content": [
          "$$120^\\circ$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7471,
        "content": [
          "$$135^\\circ$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1866,
    "content": [
      "Compare Quantity P and Quantity Q using the given information and choose the correct answer.",
      "---",
      "A data of numbers: c, a, b, e, f, c, c, & d is given, where 0 < a < b < c < d < e < f\n\n| Quantity P | Quantity Q |\n| --- | --- |\n| Mode of the data | Median of the data |"
    ],
    "explanation": [
      "First, order the data set according to the given condition 0 < a < b < c < d < e < f. The data set is {c, a, b, e, f, c, c, d}. The ordered data set is {a, b, c, c, c, d, e, f}.\n\nQuantity P (Mode): The mode is the value that appears most frequently. In this set, 'c' appears 3 times, more than any other number. So, the Mode = c.\n\nQuantity Q (Median): The median is the middle value of an ordered data set. Since there are 8 data points (an even number), the median is the average of the 4th and 5th values. The 4th value is 'c' and the 5th value is 'c'. The Median = (c + c) / 2 = 2c / 2 = c.\n\nComparison: Quantity P = c and Quantity Q = c. Therefore, Quantity P and Quantity Q are equal."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 34,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7472,
        "content": [
          "Quantity P is less than Quantity Q."
        ],
        "isCorrect": false
      },
      {
        "id": 7473,
        "content": [
          "The relationship cannot be determined."
        ],
        "isCorrect": false
      },
      {
        "id": 7474,
        "content": [
          "Quantity P is greater than Quantity Q."
        ],
        "isCorrect": false
      },
      {
        "id": 7475,
        "content": [
          "Quantity P and quantity Q are equal."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1867,
    "content": [
      "Compare Quantity P and Quantity Q using the given information and choose the correct answer.",
      "---",
      "Let x, y, z be the lengths of the sides of a triangle. And consider the following quantities.\n\n| Quantity P | Quantity Q |\n| --- | --- |\n| x + y + 3 | z + 3 |"
    ],
    "explanation": [
      "The Triangle Inequality Theorem states that the sum of the lengths of any two sides of a triangle must be greater than the length of the third side.\n\nApplying this theorem to sides x, y, and z, we have x + y > z.\n\nWe need to compare Quantity P (x + y + 3) and Quantity Q (z + 3).\n\nStarting with the inequality x + y > z, we can add 3 to both sides without changing the direction of the inequality:\n$$\nx + y + 3 > z + 3\n$$\nThis means Quantity P is greater than Quantity Q."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 34,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7476,
        "content": [
          "Quantity P is less than Quantity Q."
        ],
        "isCorrect": false
      },
      {
        "id": 7477,
        "content": [
          "Quantity P and quantity Q are equal."
        ],
        "isCorrect": false
      },
      {
        "id": 7478,
        "content": [
          "Quantity P is greater than Quantity Q."
        ],
        "isCorrect": true
      },
      {
        "id": 7479,
        "content": [
          "The relationship cannot be determined."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1868,
    "content": [
      "If $$f(x) = 10^{2x-1}$$, then which one of the following is equal to $$f^{-1}(x)$$?"
    ],
    "explanation": [
      "To find the inverse function $$f^{-1}(x)$$, we start with the equation $$y = f(x) = 10^{2x-1}$$. Then, we swap x and y:\n$$\nx = 10^{2y-1}\n$$\nNow, we solve for y. Take the common logarithm (base 10) of both sides:\n$$\n\\log x = \\log(10^{2y-1})\n$$\nUsing the logarithm property $$\\log_b(b^k) = k$$, we get:\n$$\n\\log x = 2y - 1\n$$\n$$\n\\log x + 1 = 2y\n$$\n$$\ny = \\frac{\\log x + 1}{2}\n$$\n$$\ny = \\frac{1}{2}\\log x + \\frac{1}{2}\n$$\nUsing the logarithm property $$k \\log a = \\log(a^k)$$, we can rewrite $$\\frac{1}{2}\\log x$$ as $$\\log(x^{1/2})$$ or $$\\log \\sqrt{x}$$.\n$$\ny = \\log \\sqrt{x} + \\frac{1}{2}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7480,
        "content": [
          "$$\\log \\sqrt{x} + \\frac{1}{2}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7481,
        "content": [
          "$$\\log \\sqrt{x} - \\frac{1}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7482,
        "content": [
          "$$\\log(2x-1)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7483,
        "content": [
          "$$\\log x + \\frac{1}{2}$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1869,
    "content": [
      "Which one of the following is NOT true about the graph of the function $$f(x) = (\\frac{7}{5})^x$$?",
      "images/sat/year_2016_na/q48_1.png"
    ],
    "explanation": [
      "The function given is $$f(x) = (\\frac{7}{5})^x$$. This is an exponential function.\n\nOption A: The y-intercept occurs when $$x=0$$. $$f(0)$$ = $$(\\frac{7}{5})^0$$ = $$1$$. So the y-intercept is 1. This statement is true.\n\nOption B: For any real number x, $$(\\frac{7}{5})^x$$ will always be a positive number. As x approaches $$-\\infty$$, $$f(x)$$ approaches 0. As x approaches $$+\\infty$$, $$f(x)$$ approaches $$+\\infty$$. Therefore, the range of the function is $$(0, \\infty)$$, which is the set of all positive real numbers, not all real numbers. This statement is false.\n\nOption C: Since the base $$\\frac{7}{5} > 1$$, the function $$f(x)$$ = $$(\\frac{7}{5})^x$$ is an increasing function. This statement is true.\n\nOption D: An exponential function $$a^x$$ is defined for all real values of x. Therefore, the domain is the set of all real numbers. This statement is true."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/sat/year_2016_na/q48_1.png"
    ],
    "choices": [
      {
        "id": 7484,
        "content": [
          "Its y-intercept is 1."
        ],
        "isCorrect": false
      },
      {
        "id": 7485,
        "content": [
          "Its range is the set of all real numbers."
        ],
        "isCorrect": true
      },
      {
        "id": 7486,
        "content": [
          "It is an increasing function."
        ],
        "isCorrect": false
      },
      {
        "id": 7487,
        "content": [
          "Its domain is the set of all real numbers."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1870,
    "content": [
      "What are the values of y and z, respectively, in the sequence:\n$$\n1, \\frac{-1}{3}, \\frac{1}{7}, \\frac{-1}{15}, \\frac{1}{31}, \\frac{-1}{63}, y, z, \\dots \\ ?\n$$"
    ],
    "explanation": [
      "Each term alternates in sign, and the denominator follows a pattern.\n\nDenominators: $$1, 3, 7, 15, 31, 63, \\dots$$\n\nChecking the pattern: $$1 = 2^1 - 1$$, $$3 = 2^2 - 1$$, $$7 = 2^3 - 1$$, $$15 = 2^4 - 1$$, $$31 = 2^5 - 1$$, $$63 = 2^6 - 1$$\n\nThus, the general term for the denominator is:\n$$\n2^n - 1\n$$\nFor the next terms:\n$$\ny = \\frac{1}{2^7 - 1} = \\frac{1}{127}\n$$\n$$\nz = \\frac{-1}{2^8 - 1} = \\frac{-1}{255}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7488,
        "content": [
          "$$\\frac{1}{127}$$ and $$\\frac{-1}{255}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7489,
        "content": [
          "$$\\frac{1}{127}$$ and $$\\frac{-1}{227}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7490,
        "content": [
          "$$\\frac{1}{129}$$ and $$\\frac{-1}{227}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7491,
        "content": [
          "$$\\frac{1}{129}$$ and $$\\frac{-1}{255}$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1871,
    "content": [
      "Which one of the following is the value of x in the sequence 23, 34, 56, 89, x, 188,...?"
    ],
    "explanation": [
      "Let's examine the differences between consecutive terms in the sequence:\n$$\n34 - 23 = 11\n$$\n$$\n56 - 34 = 22\n$$\n$$\n89 - 56 = 33\n$$\nThe differences are increasing multiples of 11:\n$$\n11 \\times 1, 11 \\times 2, 11 \\times 3, \\dots\n$$\nThe next difference should be $$11 \\times 4$$ = $$44$$.\n\nSo, the value of x should be the previous term plus this difference:\n$$\nx = 89 + 44 = 133\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7492,
        "content": [
          "100"
        ],
        "isCorrect": false
      },
      {
        "id": 7493,
        "content": [
          "144"
        ],
        "isCorrect": false
      },
      {
        "id": 7494,
        "content": [
          "111"
        ],
        "isCorrect": false
      },
      {
        "id": 7495,
        "content": [
          "133"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1872,
    "content": [
      "What is the rationalizing factor of the denominator of $$\\frac{1}{\\sqrt[3]{4}}$$?"
    ],
    "explanation": [
      "The denominator is $$\\sqrt[3]{4}$$ = $$\\sqrt[3]{2^2}$$.\n\nTo rationalize a cube root, we need to make the exponent inside the root a multiple of 3. We currently have $$2^2$$. We need $$2^3$$. To get this, we multiply by\n$$\n\\sqrt[3]{2^{3-2}} = \\sqrt[3]{2^1} = \\sqrt[3]{2}\n$$\nThus, the rationalizing factor is $$\\sqrt[3]{2}$$. Multiplying the denominator by this gives\n$$\n\\sqrt[3]{4} \\times \\sqrt[3]{2} = \\sqrt[3]{8} = 2\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7496,
        "content": [
          "$$\\sqrt[3]{2}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7497,
        "content": [
          "$$2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7498,
        "content": [
          "$$\\sqrt{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7499,
        "content": [
          "$$3\\sqrt{2}$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1873,
    "content": [
      "If $$3x - 2 = 3 - 5x$$, then which one of the following is equal to $$7 - 4x$$?"
    ],
    "explanation": [
      "First, solve the equation for x.\n$$\n3x - 2 = 3 - 5x\n$$ \n$$\nx = \\frac{5}{8}\n$$\nNow, substitute this value of x into the expression $$7 - 4x$$:\n$$\n7 - 4x\n$$\n$$\n7 - 4\\left(\\frac{5}{8}\\right)\n$$\n$$\n7 - \\frac{5}{2}\n$$\nTo subtract, find a common denominator: $$7 = \\frac{14}{2}$$\n$$\n\\frac{14}{2} - \\frac{5}{2} = \\frac{14 - 5}{2} = \\frac{9}{2}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7500,
        "content": [
          "$$-\\frac{9}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7501,
        "content": [
          "$$\\frac{19}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 7502,
        "content": [
          "$$\\frac{9}{2}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 7503,
        "content": [
          "$$\\frac{13}{2}$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1874,
    "content": [
      "The greatest common factor and least common multiple of two numbers are 12 and 336, respectively. If one of the numbers is 84, then which one of the following is the other number?"
    ],
    "explanation": [
      "For any two positive integers a and b, the product of the numbers is equal to the product of their greatest common factor (GCF) and least common multiple (LCM). That is,\n$$\na \\times b = GCF(a, b) \\times LCM(a, b)\n$$\nLet the two numbers be a and b. We are given GCF = 12, LCM = 336, and one number (say a) is 84. We need to find the other number, b. Using the property:\n$$\n84 \\times b = 12 \\times 336\n$$\nSolve for b:\n$$\nb = 48\n$$\nSo, the other number is 48."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7504,
        "content": [
          "48"
        ],
        "isCorrect": true
      },
      {
        "id": 7505,
        "content": [
          "96"
        ],
        "isCorrect": false
      },
      {
        "id": 7506,
        "content": [
          "36"
        ],
        "isCorrect": false
      },
      {
        "id": 7507,
        "content": [
          "72"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1875,
    "content": [
      "How many numbers in the set $$\\{-8, -5, -3, -1, 0, 2, 5, 7, 8\\}$$ satisfy the condition $$|5 - 3x| < 11$$?"
    ],
    "explanation": [
      "The inequality |5 - 3x| < 11 means -11 < 5 - 3x < 11.\n\nSolving for x by subtracting 5 from all parts\n$$\n-16 < -3x < 6\n$$\nThen, dividing all parts by -3 and reversing the inequality signs gives\n$$\n\\frac{-16}{-3} > x > \\frac{6}{-3}\n$$\n$$\n-2 < x < \\frac{16}{3}\n$$\nSince $$\\frac{16}{3}$$ is approximately 5.67, the condition is -2 < x < 5.67.\n\nThe numbers from the set {-8, -5, -3, -1, 0, 2, 5, 7, 8} that fall within this range are -1, 0, 2, and  5. Thus, there are 4 such numbers."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7508,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 7509,
        "content": [
          "6"
        ],
        "isCorrect": false
      },
      {
        "id": 7510,
        "content": [
          "4"
        ],
        "isCorrect": true
      },
      {
        "id": 7511,
        "content": [
          "5"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1876,
    "content": [
      "A father is 32 years old and his son is 8 years old now. In how many years will the father be three times as old as his son?"
    ],
    "explanation": [
      "Let y be the number of years after which the father will be three times as old as his son.\nIn y years, the father's age will be $$32 + y$$.\nIn y years, the son's age will be $$8 + y$$.\nWe want to find y such that the father's age is three times the son's age:\n$$32 + y = 3 \\times (8 + y)$$\nNow, solve this equation for y:\n$$32 + y = 24 + 3y$$\nSubtract y from both sides:\n$$32 = 24 + 2y$$\nSubtract 24 from both sides:\n$$32 - 24 = 2y$$\n$$8 = 2y$$\nDivide by 2:\n$$y = 4$$\nIn 4 years, the father will be $$32 + 4 = 36$$ years old, and the son will be $$8 + 4 = 12$$ years old. Since $$36 = 3 \\times 12$$, the condition is met. Therefore, it will take 4 years."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 7512,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 7513,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 7514,
        "content": [
          "6"
        ],
        "isCorrect": false
      },
      {
        "id": 7515,
        "content": [
          "4"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1877,
    "content": [
      "Answer the question based on the data given in the table.",
      "---",
      "Which school has the lowest percentage of income from term fees out of its total income?"
    ],
    "explanation": [
      "Calculate the total income for each school and then find the percentage of term fees for each.\n\nP: Total = 120+24+54+60+12 = 270. Term % = (24/270)*100 ≈ 8.89%\n\nQ: Total = 60+12+21+54+3 = 150. Term % = (12/150)*100 = 8.00%\n\nR: Total = 210+45+60+60+15 = 390. Term % = (45/390)*100 ≈ 11.54%\n\nS: Total = 90+24+51+42+3 = 210. Term % = (24/210)*100 ≈ 11.43%\n\nT: Total = 120+30+60+55+15 = 280. Term % = (30/280)*100 ≈ 10.71%\n\nSchool Q has the lowest percentage (8.00%)."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 35,
    "groupIndex": null,
    "sharedContentId": 11,
    "sharedContent": [
      "The table shows the annual income of five schools P, Q, R, S and T in thousands Birr.",
      "images/sat/year_2016_na/shared_1.png"
    ],
    "images": [
      "images/sat/year_2016_na/shared_1.png"
    ],
    "choices": [
      {
        "id": 7516,
        "content": [
          "S"
        ],
        "isCorrect": false
      },
      {
        "id": 7517,
        "content": [
          "P"
        ],
        "isCorrect": false
      },
      {
        "id": 7518,
        "content": [
          "R"
        ],
        "isCorrect": false
      },
      {
        "id": 7519,
        "content": [
          "Q"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 1878,
    "content": [
      "Answer the question based on the data given in the table.",
      "---",
      "Which school has the lowest ratio of miscellaneous to term fees?"
    ],
    "explanation": [
      "Calculate the ratio of miscellaneous income to term fees income (Miscellaneous / Term Fees) for each school.\n\nP: 12 / 24 = 0.5\n\nQ: 3 / 12 = 0.25\n\nR: 15 / 45 ≈ 0.33\n\nS: 3 / 24 = 0.125\n\nT: 15 / 30 = 0.5\n\nSchool S has the lowest ratio (0.125)."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 35,
    "groupIndex": null,
    "sharedContentId": 11,
    "sharedContent": [
      "The table shows the annual income of five schools P, Q, R, S and T in thousands Birr.",
      "images/sat/year_2016_na/shared_1.png"
    ],
    "images": [
      "images/sat/year_2016_na/shared_1.png"
    ],
    "choices": [
      {
        "id": 7520,
        "content": [
          "S"
        ],
        "isCorrect": true
      },
      {
        "id": 7521,
        "content": [
          "T"
        ],
        "isCorrect": false
      },
      {
        "id": 7522,
        "content": [
          "Q"
        ],
        "isCorrect": false
      },
      {
        "id": 7523,
        "content": [
          "R"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1879,
    "content": [
      "Answer the question based on the data given in the table.",
      "---",
      "What is the average of the income from tuition fees of the five schools?"
    ],
    "explanation": [
      "Sum the tuition fees for all five schools and divide by the number of schools (5).\n\nSum = 120 + 60 + 210 + 90 + 120 = 600\n\nAverage = 600 / 5 = 120.\n\nThe average income from tuition fees is 120 thousand Birr."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 35,
    "groupIndex": null,
    "sharedContentId": 11,
    "sharedContent": [
      "The table shows the annual income of five schools P, Q, R, S and T in thousands Birr.",
      "images/sat/year_2016_na/shared_1.png"
    ],
    "images": [
      "images/sat/year_2016_na/shared_1.png"
    ],
    "choices": [
      {
        "id": 7524,
        "content": [
          "90"
        ],
        "isCorrect": false
      },
      {
        "id": 7525,
        "content": [
          "120"
        ],
        "isCorrect": true
      },
      {
        "id": 7526,
        "content": [
          "100"
        ],
        "isCorrect": false
      },
      {
        "id": 7527,
        "content": [
          "210"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1880,
    "content": [
      "Answer the question based on the data given in the table.",
      "---",
      "Which school has the lowest income from donations and term fees?"
    ],
    "explanation": [
      "Calculate the sum of donations and term fees for each school.\n\nP: 54 + 24 = 78\n\nQ: 21 + 12 = 33\n\nR: 60 + 45 = 105\n\nS: 51 + 24 = 75\n\nT: 60 + 30 = 90\n\nSchool Q has the lowest combined income from donations and term fees (33 thousand Birr)."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 35,
    "groupIndex": null,
    "sharedContentId": 11,
    "sharedContent": [
      "The table shows the annual income of five schools P, Q, R, S and T in thousands Birr.",
      "images/sat/year_2016_na/shared_1.png"
    ],
    "images": [
      "images/sat/year_2016_na/shared_1.png"
    ],
    "choices": [
      {
        "id": 7528,
        "content": [
          "S"
        ],
        "isCorrect": false
      },
      {
        "id": 7529,
        "content": [
          "R"
        ],
        "isCorrect": false
      },
      {
        "id": 7530,
        "content": [
          "Q"
        ],
        "isCorrect": true
      },
      {
        "id": 7531,
        "content": [
          "T"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 1881,
    "content": [
      "Answer the question based on the data given in the table.",
      "---",
      "Which school has the lowest percentage of income from term fees out of its total income?"
    ],
    "explanation": [
      "Calculate the total income for each school (already done for Q56) and then find the percentage of grants for each.\n\nP: Total = 270. Grant % = (60/270)*100 ≈ 22.22%\n\nQ: Total = 150. Grant % = (54/150)*100 = 36.00%\n\nR: Total = 390. Grant % = (60/390)*100 ≈ 15.38%\n\nS: Total = 210. Grant % = (42/210)*100 = 20.00%\n\nT: Total = 280. Grant % = (55/280)*100 ≈ 19.64%\n\nSchool Q has the highest percentage (36.00%)."
    ],
    "year": "YEAR_2016",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 35,
    "groupIndex": null,
    "sharedContentId": 11,
    "sharedContent": [
      "The table shows the annual income of five schools P, Q, R, S and T in thousands Birr.",
      "images/sat/year_2016_na/shared_1.png"
    ],
    "images": [
      "images/sat/year_2016_na/shared_1.png"
    ],
    "choices": [
      {
        "id": 7532,
        "content": [
          "P"
        ],
        "isCorrect": false
      },
      {
        "id": 7533,
        "content": [
          "S"
        ],
        "isCorrect": false
      },
      {
        "id": 7534,
        "content": [
          "Q"
        ],
        "isCorrect": true
      },
      {
        "id": 7535,
        "content": [
          "T"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3048,
    "content": [
      "Read the given set of conditions and assumptions and choose the most appropriate answer.",
      "---",
      "Tamrat's train never bothered him because there were always seats available on it, and he was able to spend his time on the train comfortably reading the newspaper or playing games on his mobile phone. Ever since the train schedule changed, the train has been extremely crowded, and by the time the doors open at his station, there isn't a seat to be found."
    ],
    "explanation": [
      "The passage directly contrasts Tamrat's previous comfortable experience (available seats) with the current situation (extremely crowded, no seats). This change directly supports the conclusion that the train has become less comfortable."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 89,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12200,
        "content": [
          "Tamrat's train is less comfortable since the train schedule changed."
        ],
        "isCorrect": true
      },
      {
        "id": 12201,
        "content": [
          "Tamrat would be better off taking the bus to work instead of the train."
        ],
        "isCorrect": false
      },
      {
        "id": 12202,
        "content": [
          "Tamrat will likely look for a new job closer to home."
        ],
        "isCorrect": false
      },
      {
        "id": 12203,
        "content": [
          "Any traveller who uses the train will complain about the new schedule."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3049,
    "content": [
      "Read the given set of conditions and assumptions and choose the most appropriate answer.",
      "---",
      "It is called Restitution when you compensate someone for damaging his or her property in some way. Which of the following situations is the best example of Restitution?"
    ],
    "explanation": [
      "Restitution is defined as compensating someone for damage. In this scenario, Tom damaged his friend's camera and offered to pay for the damages, which is a direct act of restitution."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 89,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12204,
        "content": [
          "Tom borrows his friend's camera. Tom fails to zipper the case, and the camera falls on the ground, and the lens shatters. When Tom returns the camera, he tells his friend that he will pay for the damage."
        ],
        "isCorrect": true
      },
      {
        "id": 12205,
        "content": [
          "Tom borrows his friend's car and returns the car with an empty petrol tank. He apologizes and tells his friend that he will fill the tank tomorrow."
        ],
        "isCorrect": false
      },
      {
        "id": 12206,
        "content": [
          "A pothole in the parking of Peter's company caused his flat tyre. He informs his boss and expects that the company should pay for the repair."
        ],
        "isCorrect": false
      },
      {
        "id": 12207,
        "content": [
          "Peter asks Tom to stay in his apartment when he is out of town. One day Tom arrives to stay and finds that pipe has burst and the apartment is filled with water. He calls the plumber to repair the pipe and pays for the repair."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3050,
    "content": [
      "Read the given set of conditions and assumptions and choose the most appropriate answer.",
      "---",
      "A four-person crew is painting Mr. Omod's house. Michael is painting the front of the house. Roza is in the alley behind the house painting the back. Jemal is painting the window frames on the north side, Shawul is on the south. If Michael switches places with Jamal, and Jemal then switches places with Shawul, where is Shawul?"
    ],
    "explanation": [
      "Initially, Michael is at the front and Shawul is on the south.",
      "First, Michael (front) switches with Jemal (north). Michael moves to the north, and Jemal moves to the front.",
      "Second, Jemal (who is now at the front) switches with Shawul (south). Shawul moves to the front, and Jemal moves to the south. Therefore, Shawul ends up in front of the house."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 89,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12208,
        "content": [
          "on the north side of the house"
        ],
        "isCorrect": false
      },
      {
        "id": 12209,
        "content": [
          "in the alley behind the house"
        ],
        "isCorrect": false
      },
      {
        "id": 12210,
        "content": [
          "on the south side of the house"
        ],
        "isCorrect": false
      },
      {
        "id": 12211,
        "content": [
          "in front of the house"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3051,
    "content": [
      "Read the given set of conditions and assumptions and choose the most appropriate answer.",
      "---",
      "Four friends in the sixth grade were sharing a pizza. They decided that the oldest friend would get the extra piece. Hawi is two months older than Geremew, who is three months younger than Nardos. Kemal is one month older than Geremew. Who should get the extra piece of pizza?"
    ],
    "explanation": [
      "Let's establish the age order. Let Geremew's age be G.",
      "Hawi is G + 2 months.",
      "Kemal is G + 1 month.",
      "Geremew is 3 months younger than Nardos, which means Nardos is 3 months older than Geremew. Nardos is G + 3 months.",
      "Comparing the ages (G+3 > G+2 > G+1 > G), Nardos is the oldest and should get the extra piece of pizza."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 89,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12212,
        "content": [
          "Nardos"
        ],
        "isCorrect": true
      },
      {
        "id": 12213,
        "content": [
          "Hawi"
        ],
        "isCorrect": false
      },
      {
        "id": 12214,
        "content": [
          "Kemal"
        ],
        "isCorrect": false
      },
      {
        "id": 12215,
        "content": [
          "Geremew"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3052,
    "content": [
      "Read the given set of conditions and assumptions and choose the most appropriate answer.",
      "---",
      "If you are a fitness walker, you don't need to go to a health gym. You also don't need any fitness equipment for workouts. All you need is a pair of comfortable athletic shoes.",
      "Which of the following statements does this paragraph support?"
    ],
    "explanation": [
      "The paragraph describes fitness walking as a workout that requires no gym and no special equipment, only shoes. This highlights its nature as both an effective (it's a \"workout\") and convenient (minimal requirements) exercise."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 89,
    "groupIndex": 5,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12216,
        "content": [
          "Walking outdoors provides more health benefits than walking indoor"
        ],
        "isCorrect": false
      },
      {
        "id": 12217,
        "content": [
          "Fitness walking is better than weight lifting"
        ],
        "isCorrect": false
      },
      {
        "id": 12218,
        "content": [
          "Poorly designed shoes can cause foot injuries"
        ],
        "isCorrect": false
      },
      {
        "id": 12219,
        "content": [
          "Fitness walking is an effective and convenient form of exercise"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3053,
    "content": [
      "Read the given set of conditions and assumptions and choose the most appropriate answer.",
      "---",
      "Sara lives in Adama. Her younger cousin Martha lives in a small town in the eastern part of Ethiopia. Martha has visited Sara several times during the past five years. In the same period of time, Sara has visited Martha only once."
    ],
    "explanation": [
      "The passage explicitly states that Martha is Sara's \"younger cousin.\" This directly implies that Sara is older than Martha. The other options are interpretations or assumptions not directly supported by the text."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 89,
    "groupIndex": 6,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12220,
        "content": [
          "Sara thinks small towns are boring."
        ],
        "isCorrect": false
      },
      {
        "id": 12221,
        "content": [
          "Martha likes Sara better than Sara likes Martha."
        ],
        "isCorrect": false
      },
      {
        "id": 12222,
        "content": [
          "Martha wants to move to another town."
        ],
        "isCorrect": false
      },
      {
        "id": 12223,
        "content": [
          "Sara is older than Martha."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3054,
    "content": [
      "Read the given set of conditions and assumptions and choose the most appropriate answer.",
      "---",
      "Solomon introduced Sara as the mother of his sister's brother. How is Sara related to Solomon?"
    ],
    "explanation": [
      "\"His sister's brother\" is Solomon himself (assuming he is the only brother). Therefore, Solomon is introducing Sara as \"the mother of Solomon,\" which means Sara is his mother."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 89,
    "groupIndex": 7,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12224,
        "content": [
          "Niece"
        ],
        "isCorrect": false
      },
      {
        "id": 12225,
        "content": [
          "Aunt"
        ],
        "isCorrect": false
      },
      {
        "id": 12226,
        "content": [
          "Sister"
        ],
        "isCorrect": false
      },
      {
        "id": 12227,
        "content": [
          "Mother"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3055,
    "content": [
      "Read the given set of conditions and assumptions and choose the most appropriate answer.",
      "---",
      "Mrs. Genet wishes to renovate her cottage. She hires the services of a plumber, a carpenter, a painter, an electrician, and an interior decorator. The renovation is to be completed in a period of one week, i.e. Monday to Friday. Every worker will be taking one complete day to do this job. Mrs. Genet will allow just one person to work per day.\n- The painter can do this work only after the plumber and the carpenter have completed their jobs.\n- The interior decorator has to complete his job before that of the electrician.\n- The carpenter cannot work on Monday or Tuesday.",
      "In case the painter works on Thursday, which among the following alternative is possible?"
    ],
    "explanation": [
      "Given the painter works on Thursday.",
      "1. The painter must work after the plumber and carpenter, so the plumber and carpenter must work on Monday, Tuesday, or Wednesday.",
      "2. The carpenter cannot work on Monday or Tuesday, so the carpenter must work on Wednesday.",
      "3. This means the plumber must work on Monday or Tuesday.",
      "4. The schedule so far has workers on Mon/Tue (Plumber), Wed (Carpenter), and Thu (Painter). This leaves Tuesday (if plumber is on Mon) and Friday for the decorator and electrician.",
      "5. The decorator must work before the electrician. Therefore, the decorator must work on Tuesday and the electrician must work on Friday. This fulfills all conditions."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 89,
    "groupIndex": 8,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12228,
        "content": [
          "The electrician works on Tuesday."
        ],
        "isCorrect": false
      },
      {
        "id": 12229,
        "content": [
          "The electrician works on Friday."
        ],
        "isCorrect": true
      },
      {
        "id": 12230,
        "content": [
          "The interior decorator does his work after the painter."
        ],
        "isCorrect": false
      },
      {
        "id": 12231,
        "content": [
          "The plumber and the painter work on consecutive days."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3056,
    "content": [
      "Choose the word that correctly completes the analogy.",
      "---",
      "EXERCISE is to GYM as EATING is to:"
    ],
    "explanation": [
      "The relationship is between an activity and the typical place where it is performed. One goes to a GYM to EXERCISE, and one goes to a RESTAURANT to EAT."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 90,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12232,
        "content": [
          "Dieting"
        ],
        "isCorrect": false
      },
      {
        "id": 12233,
        "content": [
          "Food"
        ],
        "isCorrect": false
      },
      {
        "id": 12234,
        "content": [
          "Restaurant"
        ],
        "isCorrect": true
      },
      {
        "id": 12235,
        "content": [
          "Drink"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3057,
    "content": [
      "Choose the word that correctly completes the analogy.",
      "---",
      "The EVENING is to MORNING as DINNER is to:"
    ],
    "explanation": [
      "The analogy relates a time of day to the main meal eaten during that time. DINNER is the meal for the EVENING, and BREAKFAST is the meal for the MORNING."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 90,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12236,
        "content": [
          "Breakfast"
        ],
        "isCorrect": true
      },
      {
        "id": 12237,
        "content": [
          "Supper"
        ],
        "isCorrect": false
      },
      {
        "id": 12238,
        "content": [
          "Brunch"
        ],
        "isCorrect": false
      },
      {
        "id": 12239,
        "content": [
          "Lunch"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3058,
    "content": [
      "Choose the word that correctly completes the analogy.",
      "---",
      "GUN is to BULLET as a BOW is to:"
    ],
    "explanation": [
      "The relationship is between a weapon and its projectile. A GUN shoots a BULLET, and a BOW shoots an ARROW."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 90,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12240,
        "content": [
          "Wood"
        ],
        "isCorrect": false
      },
      {
        "id": 12241,
        "content": [
          "Arrow"
        ],
        "isCorrect": true
      },
      {
        "id": 12242,
        "content": [
          "Sky"
        ],
        "isCorrect": false
      },
      {
        "id": 12243,
        "content": [
          "Fly"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3059,
    "content": [
      "Choose the word that correctly completes the analogy.",
      "---",
      "PEN is to POET as NEEDLE is to:"
    ],
    "explanation": [
      "The relationship is between a tool and the professional who uses it. A POET uses a PEN, and a TAILOR uses a NEEDLE."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 90,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12244,
        "content": [
          "Button"
        ],
        "isCorrect": false
      },
      {
        "id": 12245,
        "content": [
          "Thread"
        ],
        "isCorrect": false
      },
      {
        "id": 12246,
        "content": [
          "Tailor"
        ],
        "isCorrect": true
      },
      {
        "id": 12247,
        "content": [
          "Sewing"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3060,
    "content": [
      "Choose the word that correctly completes the analogy.",
      "---",
      "PLAY is to ACTOR as CONCERT is to:"
    ],
    "explanation": [
      "The relationship is between a performance and the performer. An ACTOR performs in a PLAY, and a MUSICIAN performs in a CONCERT."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 90,
    "groupIndex": 5,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12248,
        "content": [
          "Musician"
        ],
        "isCorrect": true
      },
      {
        "id": 12249,
        "content": [
          "Symphony"
        ],
        "isCorrect": false
      },
      {
        "id": 12250,
        "content": [
          "Persuasion"
        ],
        "isCorrect": false
      },
      {
        "id": 12251,
        "content": [
          "Piano"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3061,
    "content": [
      "Three of the following words are related. Choose the word that does not fit."
    ],
    "explanation": [
      "Lion, Tiger, and Leopard are all large predatory cats (felines). An elephant does not belong to this category."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 91,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12252,
        "content": [
          "Elephant"
        ],
        "isCorrect": true
      },
      {
        "id": 12253,
        "content": [
          "Lion"
        ],
        "isCorrect": false
      },
      {
        "id": 12254,
        "content": [
          "Tiger"
        ],
        "isCorrect": false
      },
      {
        "id": 12255,
        "content": [
          "Leopard"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3062,
    "content": [
      "Three of the following words are related. Choose the word that does not fit."
    ],
    "explanation": [
      "Pencil, Eraser, and Pen are all tools used for writing or drawing. A book is the medium on which one writes, not the tool itself."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 91,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12256,
        "content": [
          "Pencil"
        ],
        "isCorrect": false
      },
      {
        "id": 12257,
        "content": [
          "Book"
        ],
        "isCorrect": true
      },
      {
        "id": 12258,
        "content": [
          "Eraser"
        ],
        "isCorrect": false
      },
      {
        "id": 12259,
        "content": [
          "Pen"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3063,
    "content": [
      "Three of the following words are related. Choose the word that does not fit."
    ],
    "explanation": [
      "Confusion, Chaos, and Order all describe a state of organization or disorganization. Legal relates to law and is from a different conceptual category."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 91,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12260,
        "content": [
          "Confusion"
        ],
        "isCorrect": false
      },
      {
        "id": 12261,
        "content": [
          "Chaos"
        ],
        "isCorrect": false
      },
      {
        "id": 12262,
        "content": [
          "Order"
        ],
        "isCorrect": false
      },
      {
        "id": 12263,
        "content": [
          "Legal"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3064,
    "content": [
      "Three of the following words are related. Choose the word that does not fit."
    ],
    "explanation": [
      "The Eye, Ear, and Tongue are all sensory organs located in the head. The Heart is an internal circulatory organ located in the chest."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 91,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12264,
        "content": [
          "Heart"
        ],
        "isCorrect": true
      },
      {
        "id": 12265,
        "content": [
          "Eye"
        ],
        "isCorrect": false
      },
      {
        "id": 12266,
        "content": [
          "Ear"
        ],
        "isCorrect": false
      },
      {
        "id": 12267,
        "content": [
          "Tongue"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3065,
    "content": [
      "Three of the following words are related. Choose the word that does not fit."
    ],
    "explanation": [
      "A Writer, Reporter, and Publisher are all involved in the creation and distribution of written content. A Reader is the consumer or audience of that content."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 91,
    "groupIndex": 5,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12268,
        "content": [
          "Reader"
        ],
        "isCorrect": true
      },
      {
        "id": 12269,
        "content": [
          "Writer"
        ],
        "isCorrect": false
      },
      {
        "id": 12270,
        "content": [
          "Reporter"
        ],
        "isCorrect": false
      },
      {
        "id": 12271,
        "content": [
          "Publisher"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3066,
    "content": [
      "Choose the word that is most nearly similar in meaning to the bolded and capitalized word.",
      "---",
      "The special TV report **DISRUPTED** regular programming due to the day's special events."
    ],
    "explanation": [
      "To \"disrupt\" something means to interrupt an event, activity, or process by causing a disturbance or problem. \"Interrupted\" is the closest synonym."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 92,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12272,
        "content": [
          "Complemented"
        ],
        "isCorrect": false
      },
      {
        "id": 12273,
        "content": [
          "Satisfied"
        ],
        "isCorrect": false
      },
      {
        "id": 12274,
        "content": [
          "Continued"
        ],
        "isCorrect": false
      },
      {
        "id": 12275,
        "content": [
          "Interrupted"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3067,
    "content": [
      "Choose the word that is most nearly similar in meaning to the bolded and capitalized word.",
      "---",
      "He **DISSIPATED** his inheritance in less than six months and he is now back to where he was."
    ],
    "explanation": [
      "To \"dissipate\" resources like money means to squander or waste them away. \"Wasted\" is the most direct synonym."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 92,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12276,
        "content": [
          "Accumulated"
        ],
        "isCorrect": false
      },
      {
        "id": 12277,
        "content": [
          "Wasted"
        ],
        "isCorrect": true
      },
      {
        "id": 12278,
        "content": [
          "Hoarded"
        ],
        "isCorrect": false
      },
      {
        "id": 12279,
        "content": [
          "Saved"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3068,
    "content": [
      "Choose the word that is most nearly similar in meaning to the bolded and capitalized word.",
      "---",
      "If enough members of parliament **DISSENT**, the new law will not be approved."
    ],
    "explanation": [
      "To \"dissent\" means to hold or express opinions that are different from those commonly or officially held. \"Disagree\" is the best synonym."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 92,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12280,
        "content": [
          "Support"
        ],
        "isCorrect": false
      },
      {
        "id": 12281,
        "content": [
          "Agree"
        ],
        "isCorrect": false
      },
      {
        "id": 12282,
        "content": [
          "Disagree"
        ],
        "isCorrect": true
      },
      {
        "id": 12283,
        "content": [
          "Question"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3069,
    "content": [
      "Choose the word that is most nearly similar in meaning to the bolded and capitalized word.",
      "---",
      "During the riot, some of the demonstrators **LOOTED** shops and supermarkets and took the goods to their home."
    ],
    "explanation": [
      "\"Looted\" means to steal goods from a place, typically during a riot or war. \"Robbed\" is the most fitting synonym in this context."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 92,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12284,
        "content": [
          "wasted"
        ],
        "isCorrect": false
      },
      {
        "id": 12285,
        "content": [
          "robbed"
        ],
        "isCorrect": true
      },
      {
        "id": 12286,
        "content": [
          "shot"
        ],
        "isCorrect": false
      },
      {
        "id": 12287,
        "content": [
          "burned"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3070,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "The title that best suits the passage would be:"
    ],
    "explanation": [
      "The passage describes how even timid people can miraculously find courage and clarity when facing extreme danger, framing this transformation as a \"miracle very common in nature.\" This central idea is best captured by the title \"The Miracle of Confronting Danger.\""
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 93,
    "groupIndex": 1,
    "sharedContentId": 25,
    "sharedContent": [
      "If a person suddenly encounters any terrible danger, the change of nature one undergoes is equally great. Sometimes fear numbs our senses. Like animals, one stands still, powerless to move a step in fright or to lift a hand in defense of our lives, and sometimes one is seized with panic, and again, act more like the inferior animals than rational beings. On the other hand, frequently in cases of sudden extreme peril, which cannot be escaped by flight, and must be instantly faced, even the most timid men at once as if by miracle, become possessed of the necessary courage, sharp quick apprehension, and swift decision. This is a miracle very common in nature. Man and the inferior animals alike, when confronted with almost certain death 'gather resolution from despair' but there can really be no trace of so debilitating a feeling in the person fighting, or prepared to fight for dear life. At such times the mind is clearer than it has ever been; the nerves are steel, there is nothing felt but a wonderful strength and daring. Looking back at certain perilous moments in my own life, I remember them with a kind of joy, not that there was any joyful excitement then, but because they broadened my horizon, lifted me for a time above myself.",
      "Adapted from Reading Comprehension - Practice Questions"
    ],
    "images": [],
    "choices": [
      {
        "id": 12288,
        "content": [
          "The Miracle of Confronting Danger"
        ],
        "isCorrect": true
      },
      {
        "id": 12289,
        "content": [
          "The Will to Fight"
        ],
        "isCorrect": false
      },
      {
        "id": 12290,
        "content": [
          "The Change of Nature"
        ],
        "isCorrect": false
      },
      {
        "id": 12291,
        "content": [
          "Courage and Panic"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3071,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "What is the meaning of the word debilitating?"
    ],
    "explanation": [
      "In the context \"no trace of so debilitating a feeling,\" the word refers to a feeling that would weaken a person and make them less able to fight. \"Enfeeble,\" which means to make weak, is the correct meaning."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 93,
    "groupIndex": 2,
    "sharedContentId": 25,
    "sharedContent": [
      "If a person suddenly encounters any terrible danger, the change of nature one undergoes is equally great. Sometimes fear numbs our senses. Like animals, one stands still, powerless to move a step in fright or to lift a hand in defense of our lives, and sometimes one is seized with panic, and again, act more like the inferior animals than rational beings. On the other hand, frequently in cases of sudden extreme peril, which cannot be escaped by flight, and must be instantly faced, even the most timid men at once as if by miracle, become possessed of the necessary courage, sharp quick apprehension, and swift decision. This is a miracle very common in nature. Man and the inferior animals alike, when confronted with almost certain death 'gather resolution from despair' but there can really be no trace of so debilitating a feeling in the person fighting, or prepared to fight for dear life. At such times the mind is clearer than it has ever been; the nerves are steel, there is nothing felt but a wonderful strength and daring. Looking back at certain perilous moments in my own life, I remember them with a kind of joy, not that there was any joyful excitement then, but because they broadened my horizon, lifted me for a time above myself.",
      "Adapted from Reading Comprehension - Practice Questions"
    ],
    "images": [],
    "choices": [
      {
        "id": 12292,
        "content": [
          "Strengthen"
        ],
        "isCorrect": false
      },
      {
        "id": 12293,
        "content": [
          "Fatten"
        ],
        "isCorrect": false
      },
      {
        "id": 12294,
        "content": [
          "Enfeeble"
        ],
        "isCorrect": true
      },
      {
        "id": 12295,
        "content": [
          "Debase"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3072,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "The author feels happy in the recollection of dangers faced and overcome because"
    ],
    "explanation": [
      "The author explicitly states in the last sentence the reason for his joy in looking back at perilous moments: \"...because they broadened my horizon, lifted me for a time above myself.\""
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 93,
    "groupIndex": 3,
    "sharedContentId": 25,
    "sharedContent": [
      "If a person suddenly encounters any terrible danger, the change of nature one undergoes is equally great. Sometimes fear numbs our senses. Like animals, one stands still, powerless to move a step in fright or to lift a hand in defense of our lives, and sometimes one is seized with panic, and again, act more like the inferior animals than rational beings. On the other hand, frequently in cases of sudden extreme peril, which cannot be escaped by flight, and must be instantly faced, even the most timid men at once as if by miracle, become possessed of the necessary courage, sharp quick apprehension, and swift decision. This is a miracle very common in nature. Man and the inferior animals alike, when confronted with almost certain death 'gather resolution from despair' but there can really be no trace of so debilitating a feeling in the person fighting, or prepared to fight for dear life. At such times the mind is clearer than it has ever been; the nerves are steel, there is nothing felt but a wonderful strength and daring. Looking back at certain perilous moments in my own life, I remember them with a kind of joy, not that there was any joyful excitement then, but because they broadened my horizon, lifted me for a time above myself.",
      "Adapted from Reading Comprehension - Practice Questions"
    ],
    "images": [],
    "choices": [
      {
        "id": 12296,
        "content": [
          "they added lifted him above himself for a time."
        ],
        "isCorrect": true
      },
      {
        "id": 12297,
        "content": [
          "they brought him a new experience."
        ],
        "isCorrect": false
      },
      {
        "id": 12298,
        "content": [
          "he felt elated as he was alive."
        ],
        "isCorrect": false
      },
      {
        "id": 12299,
        "content": [
          "these experiences boosted his confidence."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3073,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "A man may react to sudden danger in some different ways. Some of these are:"
    ],
    "explanation": [
      "The passage describes various reactions to danger, including standing still (\"powerless to move\"), panicking (\"seized with panic\"), and acting like inferior animals. It also implies fleeing as a reaction (\"cannot be escaped by flight\") and fighting back (being \"prepared to fight for dear life\"). The chosen option provides the most comprehensive list of these described reactions."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 93,
    "groupIndex": 4,
    "sharedContentId": 25,
    "sharedContent": [
      "If a person suddenly encounters any terrible danger, the change of nature one undergoes is equally great. Sometimes fear numbs our senses. Like animals, one stands still, powerless to move a step in fright or to lift a hand in defense of our lives, and sometimes one is seized with panic, and again, act more like the inferior animals than rational beings. On the other hand, frequently in cases of sudden extreme peril, which cannot be escaped by flight, and must be instantly faced, even the most timid men at once as if by miracle, become possessed of the necessary courage, sharp quick apprehension, and swift decision. This is a miracle very common in nature. Man and the inferior animals alike, when confronted with almost certain death 'gather resolution from despair' but there can really be no trace of so debilitating a feeling in the person fighting, or prepared to fight for dear life. At such times the mind is clearer than it has ever been; the nerves are steel, there is nothing felt but a wonderful strength and daring. Looking back at certain perilous moments in my own life, I remember them with a kind of joy, not that there was any joyful excitement then, but because they broadened my horizon, lifted me for a time above myself.",
      "Adapted from Reading Comprehension - Practice Questions"
    ],
    "images": [],
    "choices": [
      {
        "id": 12300,
        "content": [
          "He may be paralysed with fear, flee panic, seized with panic or act like an inferior animal."
        ],
        "isCorrect": false
      },
      {
        "id": 12301,
        "content": [
          "He may flee panic, or fight back, stand still or act like an inferior animal."
        ],
        "isCorrect": true
      },
      {
        "id": 12302,
        "content": [
          "He may be paralysed with fear, run away, or fight."
        ],
        "isCorrect": false
      },
      {
        "id": 12303,
        "content": [
          "He may be paralysed with fear, seized with panic, or act like an inferior animal."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3074,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Explain the phrase 'gather resolution from danger'."
    ],
    "explanation": [
      "The passage actually quotes the phrase as 'gather resolution from despair'. \"Despair\" is a state of hopelessness. To \"gather resolution\" means to become determined. Therefore, the phrase means that the very feeling of hopelessness can make a person determined to face the difficulty."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 93,
    "groupIndex": 5,
    "sharedContentId": 25,
    "sharedContent": [
      "If a person suddenly encounters any terrible danger, the change of nature one undergoes is equally great. Sometimes fear numbs our senses. Like animals, one stands still, powerless to move a step in fright or to lift a hand in defense of our lives, and sometimes one is seized with panic, and again, act more like the inferior animals than rational beings. On the other hand, frequently in cases of sudden extreme peril, which cannot be escaped by flight, and must be instantly faced, even the most timid men at once as if by miracle, become possessed of the necessary courage, sharp quick apprehension, and swift decision. This is a miracle very common in nature. Man and the inferior animals alike, when confronted with almost certain death 'gather resolution from despair' but there can really be no trace of so debilitating a feeling in the person fighting, or prepared to fight for dear life. At such times the mind is clearer than it has ever been; the nerves are steel, there is nothing felt but a wonderful strength and daring. Looking back at certain perilous moments in my own life, I remember them with a kind of joy, not that there was any joyful excitement then, but because they broadened my horizon, lifted me for a time above myself.",
      "Adapted from Reading Comprehension - Practice Questions"
    ],
    "images": [],
    "choices": [
      {
        "id": 12304,
        "content": [
          "Find peace in times of difficulty."
        ],
        "isCorrect": false
      },
      {
        "id": 12305,
        "content": [
          "Hopelessness makes one determined to face the difficulty."
        ],
        "isCorrect": true
      },
      {
        "id": 12306,
        "content": [
          "Questions to be enthusiastic and brave the odds during difficulty"
        ],
        "isCorrect": false
      },
      {
        "id": 12307,
        "content": [
          "To remain calm and not to lose hope when there is a difficulty"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3075,
    "content": [
      "Choose the word that is most nearly opposite in meaning to the bolded and capitalized word.",
      "---",
      "The officer **EXAGGERATED** the damage caused by the rowdies and thus made it look more serious."
    ],
    "explanation": [
      "To \"exaggerate\" is to represent something as larger or more serious than it actually is. The direct opposite is to \"underestimate,\" which means to represent it as smaller or less serious."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANTONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 94,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12308,
        "content": [
          "Condemned"
        ],
        "isCorrect": false
      },
      {
        "id": 12309,
        "content": [
          "Unreported"
        ],
        "isCorrect": false
      },
      {
        "id": 12310,
        "content": [
          "Underestimated"
        ],
        "isCorrect": true
      },
      {
        "id": 12311,
        "content": [
          "Ignored"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3076,
    "content": [
      "Choose the word that is most nearly opposite in meaning to the bolded and capitalized word.",
      "---",
      "The speaker was unable to **PACIFY** the crowd."
    ],
    "explanation": [
      "To \"pacify\" is to calm or bring peace to someone. The opposite is to \"excite\" or agitate them, stirring up their emotions instead of soothing them."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANTONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 94,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12312,
        "content": [
          "Threaten"
        ],
        "isCorrect": false
      },
      {
        "id": 12313,
        "content": [
          "Excite"
        ],
        "isCorrect": true
      },
      {
        "id": 12314,
        "content": [
          "Challenge"
        ],
        "isCorrect": false
      },
      {
        "id": 12315,
        "content": [
          "Antagonize"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3077,
    "content": [
      "Choose the word that is most nearly opposite in meaning to the bolded and capitalized word.",
      "---",
      "His negative attitude to poor people is **DEPLORABLE**."
    ],
    "explanation": [
      "\"Deplorable\" means shockingly bad and deserving of strong condemnation. Its direct opposite is \"commendable,\" which means deserving praise and approval."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANTONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 94,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12316,
        "content": [
          "Commendable"
        ],
        "isCorrect": true
      },
      {
        "id": 12317,
        "content": [
          "Miserable"
        ],
        "isCorrect": false
      },
      {
        "id": 12318,
        "content": [
          "Desirable"
        ],
        "isCorrect": false
      },
      {
        "id": 12319,
        "content": [
          "Equitable"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3078,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "According to the passage, what soil is best for daylilies?"
    ],
    "explanation": [
      "The third paragraph of the passage explicitly states that \"Daylilies grow best in soil that is slightly acidic\"."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 95,
    "groupIndex": 1,
    "sharedContentId": 26,
    "sharedContent": [
      "Daylilies are beautiful perennial flowers that can brighten up any yard or landscape. They are tolerant of drought and flooding, immune to heat stress, and grow well in full sun or light shade. They are the perfect choice for just about any soil or climate condition.",
      "Different varieties of daylilies can be in bloom from late spring until autumn. Individual flowers last only one day, but each plant produces many buds, and many varieties have more than one flowering period.",
      "Daylilies grow best in soil that is slightly acidic, and they prefer either direct sunshine or light shade. The best time to plant them is in the early fall or early spring, but they are hardy enough to endure planting or transplanting at almost any time of year. They should be planted 18 to 24 inches apart, and the bulb should be no deeper than one inch below the soil's surface."
    ],
    "images": [],
    "choices": [
      {
        "id": 12320,
        "content": [
          "Slightly acidic"
        ],
        "isCorrect": true
      },
      {
        "id": 12321,
        "content": [
          "Slightly neutral"
        ],
        "isCorrect": false
      },
      {
        "id": 12322,
        "content": [
          "Moist soil"
        ],
        "isCorrect": false
      },
      {
        "id": 12323,
        "content": [
          "Any soil"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3079,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "You could infer from this passage that these flowers are called day- lilies because"
    ],
    "explanation": [
      "The second paragraph states, \"Individual flowers last only one day,\" which provides the most logical reason for the flower's name."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 95,
    "groupIndex": 2,
    "sharedContentId": 26,
    "sharedContent": [
      "Daylilies are beautiful perennial flowers that can brighten up any yard or landscape. They are tolerant of drought and flooding, immune to heat stress, and grow well in full sun or light shade. They are the perfect choice for just about any soil or climate condition.",
      "Different varieties of daylilies can be in bloom from late spring until autumn. Individual flowers last only one day, but each plant produces many buds, and many varieties have more than one flowering period.",
      "Daylilies grow best in soil that is slightly acidic, and they prefer either direct sunshine or light shade. The best time to plant them is in the early fall or early spring, but they are hardy enough to endure planting or transplanting at almost any time of year. They should be planted 18 to 24 inches apart, and the bulb should be no deeper than one inch below the soil's surface."
    ],
    "images": [],
    "choices": [
      {
        "id": 12324,
        "content": [
          "they look like real lilies, but aren't."
        ],
        "isCorrect": false
      },
      {
        "id": 12325,
        "content": [
          "they only bloom in the daytime."
        ],
        "isCorrect": false
      },
      {
        "id": 12326,
        "content": [
          "Charles Day developed the hybrid."
        ],
        "isCorrect": false
      },
      {
        "id": 12327,
        "content": [
          "the blooms last for one day."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3080,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "How deep should daylilies be planted, according to the passage?"
    ],
    "explanation": [
      "The passage states the bulb should be planted \"no deeper than one inch below the soil's surface.\" While the option \"one inch or more\" is logically flawed (it should be one inch or less), it is the only option that contains the correct numerical value \"one inch\" mentioned in the passage, making it the intended answer despite the error."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 95,
    "groupIndex": 3,
    "sharedContentId": 26,
    "sharedContent": [
      "Daylilies are beautiful perennial flowers that can brighten up any yard or landscape. They are tolerant of drought and flooding, immune to heat stress, and grow well in full sun or light shade. They are the perfect choice for just about any soil or climate condition.",
      "Different varieties of daylilies can be in bloom from late spring until autumn. Individual flowers last only one day, but each plant produces many buds, and many varieties have more than one flowering period.",
      "Daylilies grow best in soil that is slightly acidic, and they prefer either direct sunshine or light shade. The best time to plant them is in the early fall or early spring, but they are hardy enough to endure planting or transplanting at almost any time of year. They should be planted 18 to 24 inches apart, and the bulb should be no deeper than one inch below the soil's surface."
    ],
    "images": [],
    "choices": [
      {
        "id": 12328,
        "content": [
          "one inch or more"
        ],
        "isCorrect": true
      },
      {
        "id": 12329,
        "content": [
          "one to 20 inches"
        ],
        "isCorrect": false
      },
      {
        "id": 12330,
        "content": [
          "any depth work"
        ],
        "isCorrect": false
      },
      {
        "id": 12331,
        "content": [
          "18 to 24 inches"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3081,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Daylilies grow best in"
    ],
    "explanation": [
      "The passage mentions in the third paragraph that daylilies \"prefer either direct sunshine or light shade.\" Therefore, sunshine is one of the best conditions for their growth."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 95,
    "groupIndex": 4,
    "sharedContentId": 26,
    "sharedContent": [
      "Daylilies are beautiful perennial flowers that can brighten up any yard or landscape. They are tolerant of drought and flooding, immune to heat stress, and grow well in full sun or light shade. They are the perfect choice for just about any soil or climate condition.",
      "Different varieties of daylilies can be in bloom from late spring until autumn. Individual flowers last only one day, but each plant produces many buds, and many varieties have more than one flowering period.",
      "Daylilies grow best in soil that is slightly acidic, and they prefer either direct sunshine or light shade. The best time to plant them is in the early fall or early spring, but they are hardy enough to endure planting or transplanting at almost any time of year. They should be planted 18 to 24 inches apart, and the bulb should be no deeper than one inch below the soil's surface."
    ],
    "images": [],
    "choices": [
      {
        "id": 12332,
        "content": [
          "the mornings"
        ],
        "isCorrect": false
      },
      {
        "id": 12333,
        "content": [
          "darkness"
        ],
        "isCorrect": false
      },
      {
        "id": 12334,
        "content": [
          "sunshine"
        ],
        "isCorrect": true
      },
      {
        "id": 12335,
        "content": [
          "the evenings"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3082,
    "content": [
      "Read the passage carefully and choose the best answer according to the information provided.",
      "---",
      "Which of the following is true according to the passage?"
    ],
    "explanation": [
      "The first paragraph clearly states that daylilies are \"tolerant of drought,\" meaning they can stand drought."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 95,
    "groupIndex": 5,
    "sharedContentId": 26,
    "sharedContent": [
      "Daylilies are beautiful perennial flowers that can brighten up any yard or landscape. They are tolerant of drought and flooding, immune to heat stress, and grow well in full sun or light shade. They are the perfect choice for just about any soil or climate condition.",
      "Different varieties of daylilies can be in bloom from late spring until autumn. Individual flowers last only one day, but each plant produces many buds, and many varieties have more than one flowering period.",
      "Daylilies grow best in soil that is slightly acidic, and they prefer either direct sunshine or light shade. The best time to plant them is in the early fall or early spring, but they are hardy enough to endure planting or transplanting at almost any time of year. They should be planted 18 to 24 inches apart, and the bulb should be no deeper than one inch below the soil's surface."
    ],
    "images": [],
    "choices": [
      {
        "id": 12336,
        "content": [
          "Daylilies cannot stand drought."
        ],
        "isCorrect": false
      },
      {
        "id": 12337,
        "content": [
          "Daylilies can stand drought."
        ],
        "isCorrect": true
      },
      {
        "id": 12338,
        "content": [
          "Daylilies cannot grow in sunny weather."
        ],
        "isCorrect": false
      },
      {
        "id": 12339,
        "content": [
          "Heat can cause stress to daylilies."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3083,
    "content": [
      "Suppose a chain letter is started by sending a letter to five people and the letter requires each person who receives the letter to send it on to five additional people. Assume that no person receives more than one letter. How many letters are sent all together if the chain reaches the eighth stage?"
    ],
    "explanation": [
      "This problem describes the sum of a geometric series. The number of letters sent in each stage forms a sequence: 5, 25, 125, ... for 8 stages.",
      "We use the formula for the sum of a geometric series $$S_n = a(r^n - 1) / (r - 1)$$, with a=5, r=5, and n=8.\n$$\nS_8 = \\frac{5(5^8 - 1)}{5 - 1}\n$$\n$$\nS_8 = \\frac{5(390625 - 1)}{4}\n$$\n$$\nS_8 = \\frac{5(390624)}{4}\n$$\n$$\nS_8 = 488,280\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12340,
        "content": [
          "480,280"
        ],
        "isCorrect": false
      },
      {
        "id": 12341,
        "content": [
          "488,280"
        ],
        "isCorrect": true
      },
      {
        "id": 12342,
        "content": [
          "390,625"
        ],
        "isCorrect": false
      },
      {
        "id": 12343,
        "content": [
          "490,625"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3084,
    "content": [
      "If the line passing through (x,y) and (-1,2) has a slope of 3 and the line passing through (x,y) and (2,-1) has a slope of 1, then (x,y) equals:"
    ],
    "explanation": [
      "Using the slope formula, m = (y₂ - y₁) / (x₂ - x₁), we can set up two linear equations.",
      "Equation 1: $$3 = \\frac{y - 2}{x - (-1)}$$ simplifies to y = 3x + 5.",
      "Equation 2: $$1 = \\frac{y - (-1)}{x - 2}$$ simplifies to y = x - 3.",
      "By setting the two expressions for y equal, we get 3x + 5 = x - 3.",
      "Solving for x gives 2x = -8, so x = -4.",
      "Substituting x = -4 into the second equation gives y = -4 - 3 = -7.",
      "Therefore, the coordinates (x,y) are (-4, -7)."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12344,
        "content": [
          "(4,-7)"
        ],
        "isCorrect": false
      },
      {
        "id": 12345,
        "content": [
          "(-4,7)"
        ],
        "isCorrect": false
      },
      {
        "id": 12346,
        "content": [
          "(-4,-7)"
        ],
        "isCorrect": true
      },
      {
        "id": 12347,
        "content": [
          "(4,7)"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3085,
    "content": [
      "Ali wants to invest a total of Birr 20,000 so that his yearly interest is Birr 1690. If he invests part of it in a bank yielding 8% profit and the other part in a stock at 9.5% profit, how much should he invest at each rate?"
    ],
    "explanation": [
      "Let x be the amount invested at 8% and y be the amount at 9.5%.",
      "We can set up a system of two equations:",
      "1) x + y = 20000",
      "2) 0.08x (8%) + 0.095y (9.5%) = 1690",
      "From equation (1), we get x = 20000 - y. Substituting this into equation (2):",
      "0.08(20000 - y) + 0.095y = 1690",
      "1600 - 0.08y + 0.095y = 1690",
      "0.015y = 90, which means y = 6000.",
      "Then x = 20000 - 6000 = 14000.",
      "So, Ali invested Birr 14,000 at 8% and Birr 6,000 at 9.5%."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12348,
        "content": [
          "Birr 8000 at 9.5%; Birr 12000 at 8%"
        ],
        "isCorrect": false
      },
      {
        "id": 12349,
        "content": [
          "Birr 6000 at 9.5%; Birr 14000 at 8%"
        ],
        "isCorrect": true
      },
      {
        "id": 12350,
        "content": [
          "Birr 9000 at 9.5%; Birr 11000 at 8%"
        ],
        "isCorrect": false
      },
      {
        "id": 12351,
        "content": [
          "Birr 7500 at 9.5%; Birr 12500 at 8%"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3086,
    "content": [
      "Meseret begins a saving program in which she will save Birr 1000 the first year, and each subsequent year will save Birr 200 more than she did the previous year. How much will she save during the eighth year?"
    ],
    "explanation": [
      "This is an arithmetic progression with the first term a₁ = 1000 and a common difference d = 200. We need to find the 8th term, a₈.",
      "The formula for the nth term is\n$$\na_n = a_1 + (n-1)d\n$$\n$$\na_8 = 1000 + (8-1) \\times 200\n$$\n$$\na_8 = 1000 + 7 \\times 200\n$$\n$$\na_8 = 1000 + 1400\n$$\n$$\na_8 = 2400\n$$",
      "She will save Birr 2400 in the eighth year."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12352,
        "content": [
          "Birr 2400"
        ],
        "isCorrect": true
      },
      {
        "id": 12353,
        "content": [
          "Birr 2200"
        ],
        "isCorrect": false
      },
      {
        "id": 12354,
        "content": [
          "Birr 1360"
        ],
        "isCorrect": false
      },
      {
        "id": 12355,
        "content": [
          "Birr 2600"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3087,
    "content": [
      "A ball bounces one-half the distance from which it falls. How high does it bounce up on the fifth rebound if the ball is dropped from a height of 20m?"
    ],
    "explanation": [
      "This is a geometric progression. The initial height is 20m and the common ratio is 1/2.",
      "The height of the nth rebound is given by\n$$\nh_n = h_0 \\times r^n\n$$\nFor the 5th rebound:\n$$\nh_5 = 20 \\times (\\frac{1}{2})^5\n$$\n$$\nh_5 = 20 \\times \\frac{1}{32}\n$$\n$$\nh_5 = \\frac{20}{32} = \\frac{5}{8} = 0.625 \\text{m}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12356,
        "content": [
          "2.5m"
        ],
        "isCorrect": false
      },
      {
        "id": 12357,
        "content": [
          "5m"
        ],
        "isCorrect": false
      },
      {
        "id": 12358,
        "content": [
          "1.25m"
        ],
        "isCorrect": false
      },
      {
        "id": 12359,
        "content": [
          "0.625m"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3088,
    "content": [
      "A contest offers a total of 18 prizes. The first prize is worth Birr 10,000, and each successive prize is worth Birr 500 less than the next higher prize. What is the total value of all the prizes?"
    ],
    "explanation": [
      "This is an arithmetic series with n=18, first term a₁ = 10000, and common difference d = -500.",
      "The sum of an arithmetic series is given by\n$$\nS_n = \\frac{n}{2}[2a_1 + (n-1)d]\n$$\n$$\nS_{18} = \\frac{18}{2}[2(10000) + (18-1)(-500)]\n$$\n$$\nS_{18} = 9[20000 - 8500]\n$$\n$$\nS_{18} = 9 = 103,500\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12360,
        "content": [
          "Birr 113,500"
        ],
        "isCorrect": false
      },
      {
        "id": 12361,
        "content": [
          "Birr 103,500"
        ],
        "isCorrect": true
      },
      {
        "id": 12362,
        "content": [
          "Birr 105,000"
        ],
        "isCorrect": false
      },
      {
        "id": 12363,
        "content": [
          "Birr 108,000"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3089,
    "content": [
      "Answer this question based on the table provided.",
      "---",
      "What is the total expenditure of the firm over these items during the year 2007?"
    ],
    "explanation": [
      "To find the total expenditure for 2007, we sum up all the expenses for that year from the table.",
      "Total = Salary + Fuel/Transport + Bonus + Interest + Taxes",
      "Total = 258 + 110 + 2.5 + 33 + 71 = 474.5 million birr."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 96,
    "groupIndex": 1,
    "sharedContentId": 27,
    "sharedContent": [
      "The table below gives the expenditure of a firm (in millions of birr) per annum over the given years.",
      "images/sat/year_2014_na/shared_content_27.png"
    ],
    "images": [
      "images/sat/year_2014_na/shared_content_27.png"
    ],
    "choices": [
      {
        "id": 12364,
        "content": [
          "474.5"
        ],
        "isCorrect": true
      },
      {
        "id": 12365,
        "content": [
          "447.5"
        ],
        "isCorrect": false
      },
      {
        "id": 12366,
        "content": [
          "476.5"
        ],
        "isCorrect": false
      },
      {
        "id": 12367,
        "content": [
          "467.5"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3090,
    "content": [
      "Answer this question based on the table provided.",
      "---",
      "What is the average amount of tax per year which the firm had to pay during the whole period?"
    ],
    "explanation": [
      "First, sum the taxes for all five years: 85 + 71 + 112 + 98 + 93 = 459.",
      "Then, divide the total by the number of years (5) to find the average.",
      "Average Tax = 459 / 5 = 91.8 million birr."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 96,
    "groupIndex": 2,
    "sharedContentId": 27,
    "sharedContent": [
      "The table below gives the expenditure of a firm (in millions of birr) per annum over the given years.",
      "images/sat/year_2014_na/shared_content_27.png"
    ],
    "images": [
      "images/sat/year_2014_na/shared_content_27.png"
    ],
    "choices": [
      {
        "id": 12368,
        "content": [
          "76.5"
        ],
        "isCorrect": false
      },
      {
        "id": 12369,
        "content": [
          "114.75"
        ],
        "isCorrect": false
      },
      {
        "id": 12370,
        "content": [
          "82.9"
        ],
        "isCorrect": false
      },
      {
        "id": 12371,
        "content": [
          "91.8"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3091,
    "content": [
      "Answer this question based on the table provided.",
      "---",
      "Total expenditure on all these items in the year 2006 was approximately what percent of the total expenditure in the year 2010?"
    ],
    "explanation": [
      "First, calculate the total expenditure for 2006: 314 + 92 + 3 + 24 + 85 = 518.",
      "Next, calculate the total expenditure for 2010: 370 + 125 + 3.8 + 42 + 93 = 633.8.",
      "Finally, calculate the percentage:\n$$\n(\\frac{\\text{Total 2006}}{\\text{Total 2010}}) \\times 100\n$$\n$$\n= (\\frac{518}{633.8}) \\times 100 \\approx 81.73\\%\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 96,
    "groupIndex": 3,
    "sharedContentId": 27,
    "sharedContent": [
      "The table below gives the expenditure of a firm (in millions of birr) per annum over the given years.",
      "images/sat/year_2014_na/shared_content_27.png"
    ],
    "images": [
      "images/sat/year_2014_na/shared_content_27.png"
    ],
    "choices": [
      {
        "id": 12372,
        "content": [
          "80.12"
        ],
        "isCorrect": false
      },
      {
        "id": 12373,
        "content": [
          "78.25"
        ],
        "isCorrect": false
      },
      {
        "id": 12374,
        "content": [
          "81.73"
        ],
        "isCorrect": true
      },
      {
        "id": 12375,
        "content": [
          "83.71"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3092,
    "content": [
      "Answer this question based on the table provided.",
      "---",
      "The total amount of bonus paid by the firm during the whole period is approximately what percent of the total amount of salary paid during this period?"
    ],
    "explanation": [
      "First, find the total bonus paid: 3 + 2.5 + 3.4 + 2.6 + 3.8 = 15.3.",
      "Next, find the total salary paid: 314 + 258 + 732 + 450 + 370 = 2124.",
      "Calculate the percentage:\n$$\n(\\frac{\\text{Total Bonus}}{\\text{Total Salary}}) \\times 100\n$$\n$$\n= (\\frac{15.3}{2124}) \\times 100 \\approx 0.72\\%\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 96,
    "groupIndex": 4,
    "sharedContentId": 27,
    "sharedContent": [
      "The table below gives the expenditure of a firm (in millions of birr) per annum over the given years.",
      "images/sat/year_2014_na/shared_content_27.png"
    ],
    "images": [
      "images/sat/year_2014_na/shared_content_27.png"
    ],
    "choices": [
      {
        "id": 12376,
        "content": [
          "0.68"
        ],
        "isCorrect": false
      },
      {
        "id": 12377,
        "content": [
          "0.72"
        ],
        "isCorrect": true
      },
      {
        "id": 12378,
        "content": [
          "0.58"
        ],
        "isCorrect": false
      },
      {
        "id": 12379,
        "content": [
          "0.62"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3093,
    "content": [
      "Answer this question based on the table provided.",
      "---",
      "What is the approximate ratio between the total expenditure on interest on loans for all the years and the total expenditure on fuel and transport for all the years?"
    ],
    "explanation": [
      "First, calculate the total interest on loans: 24 + 33 + 28 + 31 + 42 = 158.",
      "Next, calculate the total on fuel and transport: 92 + 110 + 131 + 104 + 125 = 562.\nRatio = 158 : 562, by simplifying:",
      "158 ÷ 15.8 = 10",
      "562 ÷ 15.8 ≈ 35.6",
      "158 : 562 ≈ 10 : 36"
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 96,
    "groupIndex": 5,
    "sharedContentId": 27,
    "sharedContent": [
      "The table below gives the expenditure of a firm (in millions of birr) per annum over the given years.",
      "images/sat/year_2014_na/shared_content_27.png"
    ],
    "images": [
      "images/sat/year_2014_na/shared_content_27.png"
    ],
    "choices": [
      {
        "id": 12380,
        "content": [
          "10:29"
        ],
        "isCorrect": false
      },
      {
        "id": 12381,
        "content": [
          "10:26"
        ],
        "isCorrect": false
      },
      {
        "id": 12382,
        "content": [
          "10:39"
        ],
        "isCorrect": false
      },
      {
        "id": 12383,
        "content": [
          "10:36"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3094,
    "content": [
      "Let $$x \\neq -2$$, $$x \\neq 3$$ and $$x \\neq -\\frac{4}{7}$$. Then\n$$\n(\\frac{2}{x+2} + \\frac{5}{x-3}) \\div (\\frac{7x+4}{2x-6})\n$$\nequals:"
    ],
    "explanation": [
      "First, simplify the expression in the first parenthesis by finding a common denominator.\n$$\n\\frac{2(x-3) + 5(x+2)}{(x+2)(x-3)} =\n$$\n$$\n\\frac{2x - 6 + 5x + 10}{(x+2)(x-3)} =\n$$\n$$\n\\frac{7x+4}{(x+2)(x-3)}\n$$",
      "Now, perform the division, which is multiplication by the reciprocal.\n$$\n\\frac{7x+4}{(x+2)(x-3)} \\div \\frac{7x+4}{2x-6}\n$$\n$$\n= \\frac{7x+4}{(x+2)(x-3)} \\times \\frac{2(x-3)}{7x+4}\n$$",
      "Cancel the common terms (7x+4) and (x-3) to get\n$$\n\\frac{2}{x+2}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12384,
        "content": [
          "$$\n\\frac{7x-1}{(x+2)(7x+4)}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 12385,
        "content": [
          "$$\n\\frac{2}{x+2}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 12386,
        "content": [
          "$$\n\\frac{7x+4}{x+2}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 12387,
        "content": [
          "$$\n\\frac{3}{x-3}\n$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3095,
    "content": [
      "When the polynomial 5x⁴ - 2x³ + x² - x + 1 is divided by x² - 1, the remainder is:"
    ],
    "explanation": [
      "By the polynomial remainder theorem, if a polynomial P(x) is divided by (x² - 1), the remainder R(x) will be of the form ax+b.",
      "The roots of x² - 1 = 0 are x = 1 and x = -1.\n$$\nP(1) = 5(1)^4 - 2(1)^3 + (1)^2 - 1 + 1 = 4\n$$\nThus,\n$$\nR(1) = a(1)+b = a+b = 4\n$$\n$$\nP(-1) = 5(-1)^4 - 2(-1)^3 + (-1)^2 - (-1) + 1 = 5+2+1+1+1=10\n$$\nThus,\n$$\nR(-1) = a(-1)+b = -a+b = 10\n$$",
      "Solving the system a+b=4 and -a+b=10 gives b=7 and a=-3.",
      "The remainder is\n$$\n-3x+7\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12388,
        "content": [
          "$$\n-3x+7\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 12389,
        "content": [
          "$$\n\\frac{-3x+7}{x^2-1}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 12390,
        "content": [
          "$$\n\\frac{x^2-1}{-3x+7}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 12391,
        "content": [
          "$$\n5x^2-2x+6\n$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3096,
    "content": [
      "Given that x and y are negative numbers.",
      "images/sat/year_2014_na/q49_1.png",
      "Which of the following is true about the relationship between quantities A and B?"
    ],
    "explanation": [
      "Let's compare A and B. We are comparing x+y with x-y. We can subtract x from both quantities to compare y with -y.",
      "Since y is a negative number, -y must be a positive number.",
      "A positive number is always greater than a negative number, so -y > y. Therefore, x-y > x+y, which means Quantity B is greater than Quantity A."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/sat/year_2014_na/q49_1.png"
    ],
    "choices": [
      {
        "id": 12392,
        "content": [
          "The relationship cannot be determined."
        ],
        "isCorrect": false
      },
      {
        "id": 12393,
        "content": [
          "The two quantities are equal."
        ],
        "isCorrect": false
      },
      {
        "id": 12394,
        "content": [
          "Quantity B is greater than quantity A."
        ],
        "isCorrect": true
      },
      {
        "id": 12395,
        "content": [
          "Quantity A is greater than quantity B."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3097,
    "content": [
      "Given that $$2^{1.5894} = 3$$.",
      "images/sat/year_2014_na/q50_1.png",
      "How are quantities A and B related?"
    ],
    "explanation": [
      "We know:\n$$\n2^{1.5894} = 3\n$$\nWe need to compare $$2^{4.327}$$ and $$11$$.",
      "Express (4.327) in terms of (1.5894):",
      "1.5894 × 2 = 3.1788",
      "1.5894 × 3 = 4.7682",
      "So 4.327 lies between 3.1788 and 4.7682.",
      "Thus, $$2^{4.327}$$ lies between $$2^{3.1788} = 3^2 = 9$$ and $$2^{4.7682} = 3^3 = 27$$.",
      "Since 4.327 is closer to 3.1788 than to 4.7682, $$2^{4.327}$$ should be a bit more than 9 but less than halfway to 27 — somewhere around 15–20.",
      "Clearly, $$2^{4.327} (≈15–20)$$ is greater than 11."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/sat/year_2014_na/q50_1.png"
    ],
    "choices": [
      {
        "id": 12396,
        "content": [
          "The relationship cannot be determined."
        ],
        "isCorrect": false
      },
      {
        "id": 12397,
        "content": [
          "The two quantities are equal."
        ],
        "isCorrect": false
      },
      {
        "id": 12398,
        "content": [
          "Quantity B is greater than quantity A."
        ],
        "isCorrect": false
      },
      {
        "id": 12399,
        "content": [
          "Quantity A is greater than quantity B."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3098,
    "content": [
      "The red, green and black lollies in a packet are in the ratio 2:3:5. How many green and black lollies are there, if there are 10 red lollies?"
    ],
    "explanation": [
      "The ratio of red:green:black is 2:3:5. If there are 10 red lollies, this corresponds to the '2' part of the ratio.",
      "The scaling factor is 10/2 = 5.",
      "To find the number of green and black lollies, multiply their ratio parts by this factor.",
      "Green: 3 x 5 = 15.",
      "Black: 5 x 5 = 25."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12400,
        "content": [
          "15 green lollies and 25 black lollies"
        ],
        "isCorrect": true
      },
      {
        "id": 12401,
        "content": [
          "6 green lollies and 15 black lollies"
        ],
        "isCorrect": false
      },
      {
        "id": 12402,
        "content": [
          "30 green lollies and 50 black lollies"
        ],
        "isCorrect": false
      },
      {
        "id": 12403,
        "content": [
          "25 green lollies and 15 black lollies"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3099,
    "content": [
      "At a restaurant the bill came to 82 birr. If you leave 119.72 birr, what percent tip is that?"
    ],
    "explanation": [
      "First, find the amount of the tip by subtracting the bill from the total amount paid: Tip = 119.72 - 82 = 37.72 birr.",
      "To find the percentage, divide the tip amount by the original bill amount and multiply by 100:\n$$\n(\\frac{37.72}{82}) \\times 100 = 0.46 \\times 100 = 46\\%\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12404,
        "content": [
          "38"
        ],
        "isCorrect": false
      },
      {
        "id": 12405,
        "content": [
          "64"
        ],
        "isCorrect": false
      },
      {
        "id": 12406,
        "content": [
          "46"
        ],
        "isCorrect": true
      },
      {
        "id": 12407,
        "content": [
          "31.5"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3100,
    "content": [
      "Suppose the population of a town is given by the model\n$$\np(t) = 17250(\\frac{1}{2})^{t/10}\n$$\nwhere t denotes the number of years since 2000. Which of the following statement is true?"
    ],
    "explanation": [
      "The model is an exponential decay function.",
      "The base of the exponent is (1/2), indicating a decrease.",
      "The term t/10 in the exponent means that when t=10 years, the initial population p(0)=17250 is multiplied by (1/2). Therefore, the population is halved every ten years."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12408,
        "content": [
          "The population doubles every ten years."
        ],
        "isCorrect": false
      },
      {
        "id": 12409,
        "content": [
          "The population in 2000 was 8625."
        ],
        "isCorrect": false
      },
      {
        "id": 12410,
        "content": [
          "The population is growing by 50% every ten years."
        ],
        "isCorrect": false
      },
      {
        "id": 12411,
        "content": [
          "The population is halved every ten years."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3101,
    "content": [
      "Two six sided dice are thrown together. What is the probability that the sum of the two numbers on top is 10?"
    ],
    "explanation": [
      "The total number of possible outcomes when rolling two dice is 6 x 6 = 36.",
      "The combinations that sum to 10 are (4,6), (5,5), and (6,4).",
      "There are 3 favorable outcomes. The probability is the number of favorable outcomes divided by the total number of outcomes:\n$$\n\\frac{3}{36} = \\frac{1}{12}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12412,
        "content": [
          "$$\\frac{1}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 12413,
        "content": [
          "$$\\frac{1}{6}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 12414,
        "content": [
          "$$\\frac{1}{12}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 12415,
        "content": [
          "$$\\frac{5}{6}$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3102,
    "content": [
      "Nine identical balls numbered 1 through 9 are placed in a bag. A ball is randomly drawn and replaced. Then, a second ball is randomly drawn. What is the probability that the first ball drawn and the second ball drawn are both even numbered?"
    ],
    "explanation": [
      "In the set of numbers {1, 2, 3, 4, 5, 6, 7, 8, 9}, there are four even numbers: {2, 4, 6, 8}.",
      "The probability of drawing an even number in one draw is 4/9. Since the ball is replaced, the two draws are independent events.",
      "The probability of both events occurring is the product of their individual probabilities:\n$$\n(\\frac{4}{9}) \\times (\\frac{4}{9}) = \\frac{16}{81}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12416,
        "content": [
          "$$\\frac{16}{81}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 12417,
        "content": [
          "$$\\frac{8}{81}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 12418,
        "content": [
          "$$\\frac{25}{81}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 12419,
        "content": [
          "$$\\frac{20}{81}$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3103,
    "content": [
      "Mesfin bought a laptop valued Birr 7700. One year later the value of the laptop is decreased by $$\\frac{2}{7}$$. What is the new value of the laptop?"
    ],
    "explanation": [
      "First, calculate the amount of the decrease:\n$$\n\\frac{2}{7} \\times 7700 = 2 \\times 1100 = 2200 \\ \\text{birr}\n$$\nThen, subtract this decrease from the original value to find the new value:\n$$\n7700 - 2200 = 5500 \\ \\text{birr}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12420,
        "content": [
          "4400 birr"
        ],
        "isCorrect": false
      },
      {
        "id": 12421,
        "content": [
          "2200 birr"
        ],
        "isCorrect": false
      },
      {
        "id": 12422,
        "content": [
          "9900 birr"
        ],
        "isCorrect": false
      },
      {
        "id": 12423,
        "content": [
          "5500 birr"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3104,
    "content": [
      "Hamza spent 22 minutes on his English homework and 25.08 minutes on his Mathematics homework. What percent more time does Hamza spent on his Mathematics homework?"
    ],
    "explanation": [
      "First, find the additional time spent on Mathematics: 25.08 - 22 = 3.08 minutes.",
      "To find the percent more time, divide this increase by the original time (English homework time) and multiply by 100:\n$$\n(\\frac{3.08}{22}) \\times 100 = 0.14 \\times 100 = 14\\%\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12424,
        "content": [
          "12"
        ],
        "isCorrect": false
      },
      {
        "id": 12425,
        "content": [
          "14"
        ],
        "isCorrect": true
      },
      {
        "id": 12426,
        "content": [
          "28"
        ],
        "isCorrect": false
      },
      {
        "id": 12427,
        "content": [
          "87"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3105,
    "content": [
      "A student earns 13 birr per hour working for the computer center's help desk and 9.50 birr per hour working at the copy center. Because of her course load, she limits her work to 25 hours per week. She wants to earn at least 275 birr each week. Which of the following system of linear inequalities represent this information?"
    ],
    "explanation": [
      "Let x be the hours at the help desk and y be the hours at the copy center.",
      "The total hours are limited to 25, so x + y ≤ 25.",
      "The earnings, 13x + 9.5y, must be at least 275, so 13x + 9.5y ≥ 275.",
      "The hours worked cannot be negative, so x ≥ 0 and y ≥ 0."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12428,
        "content": [
          "$$\n\\begin{cases}\n13x + 9.5y \\geq 275 \\\\\nx + y \\leq 25 \\\\\nx \\geq 0, y \\geq 0\n\\end{cases}\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 12429,
        "content": [
          "$$\n\\begin{cases}\n13x + 9.5y \\leq 275 \\\\\nx + y \\geq 25 \\\\\nx \\geq 0, y \\geq 0\n\\end{cases}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 12430,
        "content": [
          "$$\n\\begin{cases}\n13x + 9.5y > 275 \\\\\nx + y \\leq 25 \\\\\nx \\geq 0, y \\geq 0\n\\end{cases}\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 12431,
        "content": [
          "$$\n\\begin{cases}\n13x + 9.5y < 275 \\\\\nx + y \\leq 25 \\\\\nx \\geq 0, y \\geq 0\n\\end{cases}\n$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3106,
    "content": [
      "Consider the following system of linear inequalities\n$$\nx-y \\le 3\n$$\n$$\n3x-3y \\ge d\n$$",
      "If the solution set of the system is empty, which of the following numbers could be the value of d?"
    ],
    "explanation": [
      "Let's make the inequalities comparable.",
      "Multiply the first inequality by 3: 3(x-y) ≤ 3(3), which gives 3x-3y ≤ 9.",
      "The system is now 3x-3y ≤ 9 and 3x-3y ≥ d.",
      "For the solution set to be empty, there can be no value that is both less than or equal to 9 and greater than or equal to d. This condition is met if d is greater than 9.",
      "Among the given options, only 15 is greater than 9."
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12432,
        "content": [
          "7"
        ],
        "isCorrect": false
      },
      {
        "id": 12433,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 12434,
        "content": [
          "15"
        ],
        "isCorrect": true
      },
      {
        "id": 12435,
        "content": [
          "8"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3107,
    "content": [
      "A Pediatrician uses the model h = 3.3a + 28.6 to estimate the height h of a boy, in inches, in terms of the boy's age a, in years, between the age of 2 and 5. Based on the model, what is the estimated increase, in inches, of the boy's height each year?"
    ],
    "explanation": [
      "The given model is a linear equation, h = 3.3a + 28.6, in the form y = mx + c.",
      "The slope, m, represents the rate of change of h with respect to a.",
      "In this model, the slope is 3.3. This means that for each one-year increase in age (a), the height (h) is estimated to increase by 3.3 inches\n.IsGrouped: false\nGroupId: -1\nGroupIndex: -1\nSharedItemId: -1"
    ],
    "year": "YEAR_2014",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12436,
        "content": [
          "28.6"
        ],
        "isCorrect": false
      },
      {
        "id": 12437,
        "content": [
          "14.3"
        ],
        "isCorrect": false
      },
      {
        "id": 12438,
        "content": [
          "4.3"
        ],
        "isCorrect": false
      },
      {
        "id": 12439,
        "content": [
          "3.3"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3208,
    "content": [
      "If two days after tomorrow is four days before Saturday, what day is it today?"
    ],
    "explanation": [
      "Two days after tomorrow = today + 3. Four days before Saturday = Tuesday. So today + 3 = Tuesday ⇒ today = Saturday."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 108,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12840,
        "content": [
          "Friday"
        ],
        "isCorrect": false
      },
      {
        "id": 12841,
        "content": [
          "Saturday"
        ],
        "isCorrect": true
      },
      {
        "id": 12842,
        "content": [
          "Sunday"
        ],
        "isCorrect": false
      },
      {
        "id": 12843,
        "content": [
          "Monday"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3209,
    "content": [
      "Gad is older than Dan and Dan is older than Betti. With Senni being older than Dan and younger than Gad, who is the youngest?"
    ],
    "explanation": [
      "From the statements, we can establish the age order from oldest to youngest: Gad > Senni > Dan > Betti. Therefore, Betti is the youngest."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 108,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12844,
        "content": [
          "Betti"
        ],
        "isCorrect": true
      },
      {
        "id": 12845,
        "content": [
          "Senni"
        ],
        "isCorrect": false
      },
      {
        "id": 12846,
        "content": [
          "Gad"
        ],
        "isCorrect": false
      },
      {
        "id": 12847,
        "content": [
          "Dan"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3210,
    "content": [
      "Aki is Bali's sister. Yaya is Bali's mother. Lema is Yaya's father. Gette is Lema's mother. Then how is Aki related to Lema?"
    ],
    "explanation": [
      "Yaya is Bali's mother, and Aki is Bali's sister, so Yaya is also Aki's mother. Lema is Yaya's father, which makes Lema Aki's maternal grandfather. Therefore, Aki is Lema's granddaughter."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 108,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12848,
        "content": [
          "daughter"
        ],
        "isCorrect": false
      },
      {
        "id": 12849,
        "content": [
          "granddaughter"
        ],
        "isCorrect": true
      },
      {
        "id": 12850,
        "content": [
          "grandson"
        ],
        "isCorrect": false
      },
      {
        "id": 12851,
        "content": [
          "grandmother"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3211,
    "content": [
      "Read the given set of conditions and assumptions for each question. Then, choose the answer that you think is most appropriate.",
      "---",
      "Statement I: All football players are sportspersons.",
      "Statement II: All sportspersons are fit.",
      "Conclusion: Some football players are fit.",
      "This conclusion is:"
    ],
    "explanation": [
      "From the statements:",
      "All football players are sportspersons.",
      "All sportspersons are fit.",
      "By syllogism, all football players are sportspersons and all sportspersons are fit, so all football players are fit. Therefore, the conclusion \"Some football players are fit\" is definitely true, making it appropriate."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 108,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12852,
        "content": [
          "cannot be determined"
        ],
        "isCorrect": false
      },
      {
        "id": 12853,
        "content": [
          "incorrect"
        ],
        "isCorrect": false
      },
      {
        "id": 12854,
        "content": [
          "reasonably correct"
        ],
        "isCorrect": false
      },
      {
        "id": 12855,
        "content": [
          "appropriate"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3212,
    "content": [
      "How many months have a twenty-eighth day?"
    ],
    "explanation": [
      "All twelve months of the year have at least 28 days."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 108,
    "groupIndex": 5,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12856,
        "content": [
          "seven months"
        ],
        "isCorrect": false
      },
      {
        "id": 12857,
        "content": [
          "twelve months"
        ],
        "isCorrect": true
      },
      {
        "id": 12858,
        "content": [
          "one month"
        ],
        "isCorrect": false
      },
      {
        "id": 12859,
        "content": [
          "two months"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3213,
    "content": [
      "Which of the following can be rearranged into a 5-letter English word?"
    ],
    "explanation": [
      "The letters D-W-A-E-P can be rearranged to form the valid 5-letter English word \"PAWED\".",
      "Note: On the paper, two choices can be rearranged, PASEH to SHAPE, so we changed PASEH to PASEJ"
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 108,
    "groupIndex": 6,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12860,
        "content": [
          "PYRIO"
        ],
        "isCorrect": false
      },
      {
        "id": 12861,
        "content": [
          "DWAEP"
        ],
        "isCorrect": true
      },
      {
        "id": 12862,
        "content": [
          "GOFAT"
        ],
        "isCorrect": false
      },
      {
        "id": 12863,
        "content": [
          "PASEJ"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3214,
    "content": [
      "Read the passage carefully and choose the best answer.",
      "---",
      "What is described as an absurd assumption about reading according to the passage?"
    ],
    "explanation": [
      "The passage describes the assumption \"that, without further trouble, we can possess, co-ordinate, and assimilate all the ideas and sensations rapidly offered to us by a mind greater than our own\" as a \"monstrous absurdity.\" This directly corresponds to the idea that thoughts can be instantly absorbed."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 109,
    "groupIndex": 1,
    "sharedContentId": 31,
    "sharedContent": [
      "What is the matter with our reading is casualness, languor, preoccupation. We don't give the book a chance. We don't put ourselves at the disposal of the book. It is impossible to read properly without using all one's engine power. If we are not tired after reading, common sense is not in us. How one should grapple with a superior and not be out of breath?",
      "But even if we read with the whole force of our brain, and do nothing else, common sense is still not in us, while sublime conceit is. For we are assuming that, without further trouble, we can possess, co-ordinate, and assimilate all the ideas and sensations rapidly offered to us by a mind greater than our own. The assumption has only to be stated in order to appear in its monstrous absurdity. Hence, it follows that something remains to be done; This something is the act of reflection. Reading without subsequent reflection is ridiculous; it is equally a proof of folly and vanity.",
      "Source: Taken From: Warriner, J. E. et al. 1958. English Grammar & Composition. P420"
    ],
    "images": [],
    "choices": [
      {
        "id": 12864,
        "content": [
          "Reading does not require physical effort."
        ],
        "isCorrect": false
      },
      {
        "id": 12865,
        "content": [
          "All books are equally valuable."
        ],
        "isCorrect": false
      },
      {
        "id": 12866,
        "content": [
          "Ideas can be instantly absorbed and organized."
        ],
        "isCorrect": true
      },
      {
        "id": 12867,
        "content": [
          "Superior minds are easy to understand."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3215,
    "content": [
      "Read the passage carefully and choose the best answer.",
      "---",
      "Which of the ideas is used as evidence for your answer to question number 7?"
    ],
    "explanation": [
      "The sentence \"For we are assuming that, without further trouble, we can possess, co-ordinate, and assimilate all the ideas and sensations rapidly offered to us by a mind greater than our own\" is the specific line where the author states the absurd assumption."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 109,
    "groupIndex": 2,
    "sharedContentId": 31,
    "sharedContent": [
      "What is the matter with our reading is casualness, languor, preoccupation. We don't give the book a chance. We don't put ourselves at the disposal of the book. It is impossible to read properly without using all one's engine power. If we are not tired after reading, common sense is not in us. How one should grapple with a superior and not be out of breath?",
      "But even if we read with the whole force of our brain, and do nothing else, common sense is still not in us, while sublime conceit is. For we are assuming that, without further trouble, we can possess, co-ordinate, and assimilate all the ideas and sensations rapidly offered to us by a mind greater than our own. The assumption has only to be stated in order to appear in its monstrous absurdity. Hence, it follows that something remains to be done; This something is the act of reflection. Reading without subsequent reflection is ridiculous; it is equally a proof of folly and vanity.",
      "Source: Taken From: Warriner, J. E. et al. 1958. English Grammar & Composition. P420"
    ],
    "images": [],
    "choices": [
      {
        "id": 12868,
        "content": [
          "Line 3-4 [If we are not ... is not in us.]"
        ],
        "isCorrect": false
      },
      {
        "id": 12869,
        "content": [
          "Line 7-9 [For we ... greater than our own.]"
        ],
        "isCorrect": true
      },
      {
        "id": 12870,
        "content": [
          "Line 4 [tired after reading... disposal of the book.]"
        ],
        "isCorrect": false
      },
      {
        "id": 12871,
        "content": [
          "Line 1 [What is the ... preoccupation.]"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3216,
    "content": [
      "Read the passage carefully and choose the best answer.",
      "---",
      "Why does the author emphasize the act of reflection?"
    ],
    "explanation": [
      "The author states that after reading, \"something remains to be done; This something is the act of reflection.\" This implies reflection is a necessary subsequent step to complete the process and avoid the \"folly and vanity\" of reading without it."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 109,
    "groupIndex": 3,
    "sharedContentId": 31,
    "sharedContent": [
      "What is the matter with our reading is casualness, languor, preoccupation. We don't give the book a chance. We don't put ourselves at the disposal of the book. It is impossible to read properly without using all one's engine power. If we are not tired after reading, common sense is not in us. How one should grapple with a superior and not be out of breath?",
      "But even if we read with the whole force of our brain, and do nothing else, common sense is still not in us, while sublime conceit is. For we are assuming that, without further trouble, we can possess, co-ordinate, and assimilate all the ideas and sensations rapidly offered to us by a mind greater than our own. The assumption has only to be stated in order to appear in its monstrous absurdity. Hence, it follows that something remains to be done; This something is the act of reflection. Reading without subsequent reflection is ridiculous; it is equally a proof of folly and vanity.",
      "Source: Taken From: Warriner, J. E. et al. 1958. English Grammar & Composition. P420"
    ],
    "images": [],
    "choices": [
      {
        "id": 12872,
        "content": [
          "To complete the reading process."
        ],
        "isCorrect": true
      },
      {
        "id": 12873,
        "content": [
          "To simplify the ideas encountered."
        ],
        "isCorrect": false
      },
      {
        "id": 12874,
        "content": [
          "To improve intellectual superiority."
        ],
        "isCorrect": false
      },
      {
        "id": 12875,
        "content": [
          "To make reading more enjoyable."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3217,
    "content": [
      "Read the passage carefully and choose the best answer.",
      "---",
      "Which of the ideas is used as evidence for your answer to question number 9?"
    ],
    "explanation": [
      "The sentence \"Reading without subsequent reflection is ridiculous\" provides direct evidence for why reflection is emphasized; it is presented as an essential part of meaningful reading."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 109,
    "groupIndex": 4,
    "sharedContentId": 31,
    "sharedContent": [
      "What is the matter with our reading is casualness, languor, preoccupation. We don't give the book a chance. We don't put ourselves at the disposal of the book. It is impossible to read properly without using all one's engine power. If we are not tired after reading, common sense is not in us. How one should grapple with a superior and not be out of breath?",
      "But even if we read with the whole force of our brain, and do nothing else, common sense is still not in us, while sublime conceit is. For we are assuming that, without further trouble, we can possess, co-ordinate, and assimilate all the ideas and sensations rapidly offered to us by a mind greater than our own. The assumption has only to be stated in order to appear in its monstrous absurdity. Hence, it follows that something remains to be done; This something is the act of reflection. Reading without subsequent reflection is ridiculous; it is equally a proof of folly and vanity.",
      "Source: Taken From: Warriner, J. E. et al. 1958. English Grammar & Composition. P420"
    ],
    "images": [],
    "choices": [
      {
        "id": 12876,
        "content": [
          "Line 10 [The assumption... absurdity.]"
        ],
        "isCorrect": false
      },
      {
        "id": 12877,
        "content": [
          "Line 12 [Reading without... ridiculous.]"
        ],
        "isCorrect": true
      },
      {
        "id": 12878,
        "content": [
          "Line 4 [tired after reading... not in us.]"
        ],
        "isCorrect": false
      },
      {
        "id": 12879,
        "content": [
          "Line 1 [What is the ... preoccupation.]"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3218,
    "content": [
      "The following sentences are grammatically incorrect. Choose the letter that contains the correct option.",
      "---"
    ],
    "explanation": [
      "The grammatical rule is \"One of the [plural noun] + [singular verb]\". The subject is \"One\", which is singular, so the verb must be \"has\". The noun in the prepositional phrase must be plural, \"payers\". Therefore, \"One of all-time greatest payers has...\" is the correct form."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 110,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12880,
        "content": [
          "One of all-time greatest payer have recently retired from football."
        ],
        "isCorrect": false
      },
      {
        "id": 12881,
        "content": [
          "One of all-time greatest payers have recently retired from football."
        ],
        "isCorrect": false
      },
      {
        "id": 12882,
        "content": [
          "One of all-time greatest payer has recently retired from football."
        ],
        "isCorrect": false
      },
      {
        "id": 12883,
        "content": [
          "One of all-time greatest payers has recently retired from football."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3219,
    "content": [
      "The following sentences are grammatically incorrect. Choose the letter that contains the correct option.",
      "---"
    ],
    "explanation": [
      "To describe a current state, the present continuous tense (\"are not feeling\") is appropriate. \"You'd better\" is the correct contraction for the advisory phrase \"you had better\"."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 110,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12884,
        "content": [
          "If you'll not feel well, you'd better go to clinic."
        ],
        "isCorrect": false
      },
      {
        "id": 12885,
        "content": [
          "If you're not feeling well, you'd better go to clinic."
        ],
        "isCorrect": true
      },
      {
        "id": 12886,
        "content": [
          "If you'll not feel well, you better go to clinic."
        ],
        "isCorrect": false
      },
      {
        "id": 12887,
        "content": [
          "If you're not feeling well, you would better go to clinic."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3220,
    "content": [
      "The following sentences are grammatically incorrect. Choose the letter that contains the correct option.",
      "---"
    ],
    "explanation": [
      "\"Their\" is the correct possessive pronoun to indicate that the school belongs to them. \"There\" indicates location, \"Theirs\" is a possessive pronoun that stands alone, and \"They're\" is a contraction of \"they are\"."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 110,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12888,
        "content": [
          "There school takes only twenty minutes on foot."
        ],
        "isCorrect": false
      },
      {
        "id": 12889,
        "content": [
          "Theirs school takes only twenty minutes on foot."
        ],
        "isCorrect": false
      },
      {
        "id": 12890,
        "content": [
          "Their school takes only twenty minutes on foot."
        ],
        "isCorrect": true
      },
      {
        "id": 12891,
        "content": [
          "They're school takes only twenty minutes on foot."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3221,
    "content": [
      "The following sentences are grammatically incorrect. Choose the letter that contains the correct option.",
      "---"
    ],
    "explanation": [
      "The sentence requires parallel structure. The phrase \"wanted to\" should be followed by verbs in the same form. \"to... take... and then eat\" maintains this parallel structure (the \"to\" is implied for the second verb). The other options break this parallelism."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_REASONING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 110,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12892,
        "content": [
          "I wanted to first take shower and then eat snack."
        ],
        "isCorrect": true
      },
      {
        "id": 12893,
        "content": [
          "I wanted first take shower and then eat snack."
        ],
        "isCorrect": false
      },
      {
        "id": 12894,
        "content": [
          "I wanted to first take shower and then ate snack."
        ],
        "isCorrect": false
      },
      {
        "id": 12895,
        "content": [
          "I wanted to first take shower and then eating snack."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3222,
    "content": [
      "The following items contain a category of words of which one does not belong to the group. Choose a word that does NOT fit to the group.",
      "---"
    ],
    "explanation": [
      "Monogamy, polygamy, and polyandry are all terms related to types of marriage or marital relationships. A polyglot is a person who speaks multiple languages, which does not fit the category."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 111,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12896,
        "content": [
          "Monogamy"
        ],
        "isCorrect": false
      },
      {
        "id": 12897,
        "content": [
          "Polygamy"
        ],
        "isCorrect": false
      },
      {
        "id": 12898,
        "content": [
          "Polyglot"
        ],
        "isCorrect": true
      },
      {
        "id": 12899,
        "content": [
          "Polyandry"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3223,
    "content": [
      "The following items contain a category of words of which one does not belong to the group. Choose a word that does NOT fit to the group.",
      "---"
    ],
    "explanation": [
      "Election, ballot-box, and voting are all terms directly related to the process of electing officials. A signal-box is a piece of railway equipment used for controlling train movements."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 111,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12900,
        "content": [
          "Election"
        ],
        "isCorrect": false
      },
      {
        "id": 12901,
        "content": [
          "Ballot-box"
        ],
        "isCorrect": false
      },
      {
        "id": 12902,
        "content": [
          "Signal-box"
        ],
        "isCorrect": true
      },
      {
        "id": 12903,
        "content": [
          "Voting"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3224,
    "content": [
      "The following items contain a category of words of which one does not belong to the group. Choose a word that does NOT fit to the group.",
      "---"
    ],
    "explanation": [
      "Tiptoeing, strolling, and striding are all different ways of walking. Flying is a method of movement through the air, not on the ground."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 111,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12904,
        "content": [
          "Tiptoeing"
        ],
        "isCorrect": false
      },
      {
        "id": 12905,
        "content": [
          "Flying"
        ],
        "isCorrect": true
      },
      {
        "id": 12906,
        "content": [
          "Strolling"
        ],
        "isCorrect": false
      },
      {
        "id": 12907,
        "content": [
          "Striding"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3225,
    "content": [
      "The following items contain a category of words of which one does not belong to the group. Choose a word that does NOT fit to the group.",
      "---"
    ],
    "explanation": [
      "Yacht, ship, and boat are all specific types of watercraft. Vehicle is a general term for any means of transport, including cars, trucks, and planes, making it the outlier."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_CLASSIFICATION",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 111,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12908,
        "content": [
          "Yacht"
        ],
        "isCorrect": false
      },
      {
        "id": 12909,
        "content": [
          "Ship"
        ],
        "isCorrect": false
      },
      {
        "id": 12910,
        "content": [
          "Vehicle"
        ],
        "isCorrect": true
      },
      {
        "id": 12911,
        "content": [
          "Boat"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3226,
    "content": [
      "Read each of the following pair of words written in capital letter carefully and choose the word that correctly has a similar relationship with the given word.",
      "---",
      "AUTOMOBILE: GARAGE:: Hanger"
    ],
    "explanation": [
      "The relationship is that an AUTOMOBILE is stored or housed in a GARAGE. Similarly, an Airplane is stored or housed in a hangar."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 112,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12912,
        "content": [
          "Deck"
        ],
        "isCorrect": false
      },
      {
        "id": 12913,
        "content": [
          "Truck"
        ],
        "isCorrect": false
      },
      {
        "id": 12914,
        "content": [
          "Train"
        ],
        "isCorrect": false
      },
      {
        "id": 12915,
        "content": [
          "Airplane"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3227,
    "content": [
      "Read each of the following pair of words written in capital letter carefully and choose the word that correctly has a similar relationship with the given word.",
      "---",
      "KEY: LOCK:: Computer"
    ],
    "explanation": [
      "A KEY is used to gain access to or unlock a LOCK. Similarly, a Password is used to gain access to or unlock a Computer."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 112,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12916,
        "content": [
          "Server"
        ],
        "isCorrect": false
      },
      {
        "id": 12917,
        "content": [
          "Screen"
        ],
        "isCorrect": false
      },
      {
        "id": 12918,
        "content": [
          "Monitor"
        ],
        "isCorrect": false
      },
      {
        "id": 12919,
        "content": [
          "Password"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3228,
    "content": [
      "Read each of the following pair of words written in capital letter carefully and choose the word that correctly has a similar relationship with the given word.",
      "---",
      "NEST: BIRD:: Lion"
    ],
    "explanation": [
      "A NEST is the home or dwelling of a BIRD. Similarly, a Den is the home or dwelling of a Lion."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 112,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12920,
        "content": [
          "Backyard"
        ],
        "isCorrect": false
      },
      {
        "id": 12921,
        "content": [
          "Den"
        ],
        "isCorrect": true
      },
      {
        "id": 12922,
        "content": [
          "Hive"
        ],
        "isCorrect": false
      },
      {
        "id": 12923,
        "content": [
          "Cave"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3229,
    "content": [
      "Read each of the following pair of words written in capital letter carefully and choose the word that correctly has a similar relationship with the given word.",
      "---",
      "PHYSICIAN: HOSPITAL:: School"
    ],
    "explanation": [
      "A PHYSICIAN is a professional who works in a HOSPITAL. Similarly, a Teacher is a professional who works in a School."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANALOGY",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 112,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12924,
        "content": [
          "Administrator"
        ],
        "isCorrect": false
      },
      {
        "id": 12925,
        "content": [
          "Student"
        ],
        "isCorrect": false
      },
      {
        "id": 12926,
        "content": [
          "Supervisor"
        ],
        "isCorrect": false
      },
      {
        "id": 12927,
        "content": [
          "Teacher"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3230,
    "content": [
      "Choose the word that is most nearly similar in meaning to the word in capital.",
      "---",
      "PHONEY"
    ],
    "explanation": [
      "The word \"phoney\" means not genuine or fraudulent. \"Fake\" is the closest synonym."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 113,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12928,
        "content": [
          "Fake"
        ],
        "isCorrect": true
      },
      {
        "id": 12929,
        "content": [
          "Funny"
        ],
        "isCorrect": false
      },
      {
        "id": 12930,
        "content": [
          "Genuine"
        ],
        "isCorrect": false
      },
      {
        "id": 12931,
        "content": [
          "Authentic"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3231,
    "content": [
      "Choose the word that is most nearly similar in meaning to the word in capital.",
      "---",
      "HUMOROUS"
    ],
    "explanation": [
      "The word \"humorous\" means causing laughter and amusement. \"Amusing\" is the best synonym."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 113,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12932,
        "content": [
          "Satiating"
        ],
        "isCorrect": false
      },
      {
        "id": 12933,
        "content": [
          "Satisfying"
        ],
        "isCorrect": false
      },
      {
        "id": 12934,
        "content": [
          "Amusing"
        ],
        "isCorrect": true
      },
      {
        "id": 12935,
        "content": [
          "Doubting"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3232,
    "content": [
      "Choose the word that is most nearly similar in meaning to the word in capital.",
      "---",
      "THEFT"
    ],
    "explanation": [
      "\"Theft\" is the act of stealing. \"Burglary,\" which is the illegal entry into a building to commit a theft, is the most similar term."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 113,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12936,
        "content": [
          "Burglary"
        ],
        "isCorrect": true
      },
      {
        "id": 12937,
        "content": [
          "Hypocrisy"
        ],
        "isCorrect": false
      },
      {
        "id": 12938,
        "content": [
          "Gossip"
        ],
        "isCorrect": false
      },
      {
        "id": 12939,
        "content": [
          "Suspicion"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3233,
    "content": [
      "Choose the word that is most nearly opposite in meaning to the word in capital.",
      "---",
      "FONDLY"
    ],
    "explanation": [
      "\"Fondly\" means with affection or liking. The direct opposite is a feeling of intense dislike, which is \"hatred\"."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANTONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 114,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12940,
        "content": [
          "Affectionate"
        ],
        "isCorrect": false
      },
      {
        "id": 12941,
        "content": [
          "Sociable"
        ],
        "isCorrect": false
      },
      {
        "id": 12942,
        "content": [
          "Hatred"
        ],
        "isCorrect": true
      },
      {
        "id": 12943,
        "content": [
          "Agreeable"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3234,
    "content": [
      "Choose the word that is most nearly opposite in meaning to the word in capital.",
      "---",
      "INVINCIBLE"
    ],
    "explanation": [
      "\"Invincible\" means too powerful to be defeated or overcome. The opposite is \"conquerable\", meaning it can be defeated."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANTONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 114,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12944,
        "content": [
          "Breakable"
        ],
        "isCorrect": false
      },
      {
        "id": 12945,
        "content": [
          "Debatable"
        ],
        "isCorrect": false
      },
      {
        "id": 12946,
        "content": [
          "Visible"
        ],
        "isCorrect": false
      },
      {
        "id": 12947,
        "content": [
          "Conquerable"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3235,
    "content": [
      "Choose the word that is most nearly opposite in meaning to the word in capital.",
      "---",
      "SUBORDINATE"
    ],
    "explanation": [
      "\"Subordinate\" means lower in rank or position. The opposite is \"superior\", meaning higher in rank or position."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_ANTONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 114,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12948,
        "content": [
          "Superior"
        ],
        "isCorrect": true
      },
      {
        "id": 12949,
        "content": [
          "Retainer"
        ],
        "isCorrect": false
      },
      {
        "id": 12950,
        "content": [
          "Soldier"
        ],
        "isCorrect": false
      },
      {
        "id": 12951,
        "content": [
          "Inferior"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3236,
    "content": [
      "Read the passage carefully and answer the questions based on the information.",
      "---",
      "In Paragraph 2, the phrase these two individuals refers to"
    ],
    "explanation": [
      "The passage explicitly mentions \"Mr. John Smith wants to sell his grocery store\" and \"someone else with a movie theater\". The phrase \"these two individuals\" refers directly to these two people described in the example."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 115,
    "groupIndex": 1,
    "sharedContentId": 32,
    "sharedContent": [
      "If you want transition from being an employee to an employer, the first step is to serve your current employer as you would wish to be served. Most successful employers today have risen through the ranks, relying on their ability to manage and direct others effectively by suppressing the vices of employers. They started with no more opportunities than you have now.",
      "There are people in your community who could benefit from your skills and vice versa. For example, Mr. John Smith wants to sell his grocery store and start a movie theater, while someone else with a movie theater might want to trade for a grocery store. If you can connect these two individuals, you will serve both and earn a commission in the process."
    ],
    "images": [],
    "choices": [
      {
        "id": 12952,
        "content": [
          "John Smith & the person in movie industry."
        ],
        "isCorrect": true
      },
      {
        "id": 12953,
        "content": [
          "the grocery store and the movie theatre."
        ],
        "isCorrect": false
      },
      {
        "id": 12954,
        "content": [
          "the employer and the employee."
        ],
        "isCorrect": false
      },
      {
        "id": 12955,
        "content": [
          "people and the community as a whole."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3237,
    "content": [
      "Read the passage carefully and answer the questions based on the information.",
      "---",
      "What does the sentence most successful employers today have risen through the ranks, relying on their ability to manage and direct others effectively imply?"
    ],
    "explanation": [
      "The phrase \"risen through the ranks\" implies a process of gaining experience and advancing over time. This journey demonstrates their capability to \"manage and direct others effectively,\" which is a core leadership ability."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 115,
    "groupIndex": 2,
    "sharedContentId": 32,
    "sharedContent": [
      "If you want transition from being an employee to an employer, the first step is to serve your current employer as you would wish to be served. Most successful employers today have risen through the ranks, relying on their ability to manage and direct others effectively by suppressing the vices of employers. They started with no more opportunities than you have now.",
      "There are people in your community who could benefit from your skills and vice versa. For example, Mr. John Smith wants to sell his grocery store and start a movie theater, while someone else with a movie theater might want to trade for a grocery store. If you can connect these two individuals, you will serve both and earn a commission in the process."
    ],
    "images": [],
    "choices": [
      {
        "id": 12956,
        "content": [
          "Every successful employer is the result of his/her hard work and diligence."
        ],
        "isCorrect": false
      },
      {
        "id": 12957,
        "content": [
          "Having different ranks and rewards is the real manifestation of successful employers."
        ],
        "isCorrect": false
      },
      {
        "id": 12958,
        "content": [
          "All successful employers today have reached their level passing through lots of ups and downs."
        ],
        "isCorrect": false
      },
      {
        "id": 12959,
        "content": [
          "Most successful employers have proven their leadership ability through their journey."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3238,
    "content": [
      "Read the passage carefully and answer the questions based on the information.",
      "---",
      "The main intent of the writer in the text is to imply that"
    ],
    "explanation": [
      "The passage outlines a \"first step\" (serving your current employer well) and provides an example of another step (connecting people to create value). This suggests a process with actionable steps for transitioning from employee to employer."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 115,
    "groupIndex": 3,
    "sharedContentId": 32,
    "sharedContent": [
      "If you want transition from being an employee to an employer, the first step is to serve your current employer as you would wish to be served. Most successful employers today have risen through the ranks, relying on their ability to manage and direct others effectively by suppressing the vices of employers. They started with no more opportunities than you have now.",
      "There are people in your community who could benefit from your skills and vice versa. For example, Mr. John Smith wants to sell his grocery store and start a movie theater, while someone else with a movie theater might want to trade for a grocery store. If you can connect these two individuals, you will serve both and earn a commission in the process."
    ],
    "images": [],
    "choices": [
      {
        "id": 12960,
        "content": [
          "the transition from employee to employer does not require much effort except having the interest."
        ],
        "isCorrect": false
      },
      {
        "id": 12961,
        "content": [
          "smooth transition from being an employer to employee is more of a matter of destiny than hard work."
        ],
        "isCorrect": false
      },
      {
        "id": 12962,
        "content": [
          "most successful employers are those who have achieved their dreams through trade-off."
        ],
        "isCorrect": false
      },
      {
        "id": 12963,
        "content": [
          "there are steps that one needs to undergo in the transition from employee to employer."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3239,
    "content": [
      "Read the passage carefully and answer the questions based on the information.",
      "---",
      "According to the passage, what does the word vices most likely denote?"
    ],
    "explanation": [
      "The passage states that successful employers rise by \"suppressing the vices of employers.\" In this context, \"vices\" refers to the negative qualities, flaws, or bad habits (like poor management) that unsuccessful employers might exhibit. \"Weaknesses\" is the best synonym for this meaning."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_READING",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 115,
    "groupIndex": 4,
    "sharedContentId": 32,
    "sharedContent": [
      "If you want transition from being an employee to an employer, the first step is to serve your current employer as you would wish to be served. Most successful employers today have risen through the ranks, relying on their ability to manage and direct others effectively by suppressing the vices of employers. They started with no more opportunities than you have now.",
      "There are people in your community who could benefit from your skills and vice versa. For example, Mr. John Smith wants to sell his grocery store and start a movie theater, while someone else with a movie theater might want to trade for a grocery store. If you can connect these two individuals, you will serve both and earn a commission in the process."
    ],
    "images": [],
    "choices": [
      {
        "id": 12964,
        "content": [
          "deputies"
        ],
        "isCorrect": false
      },
      {
        "id": 12965,
        "content": [
          "strengths"
        ],
        "isCorrect": false
      },
      {
        "id": 12966,
        "content": [
          "weaknesses"
        ],
        "isCorrect": true
      },
      {
        "id": 12967,
        "content": [
          "ambitions"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3240,
    "content": [
      "Choose the word which could be interchangeably used with the bolded and capitalized word in the sentence.",
      "---",
      "The man was killed in a car accident. His **BODY** was dragged from the burning wreckage of his car."
    ],
    "explanation": [
      "In the context of a fatal accident, the word \"remains\" is a common and appropriate synonym for a dead \"body\"."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 116,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12968,
        "content": [
          "remains"
        ],
        "isCorrect": true
      },
      {
        "id": 12969,
        "content": [
          "fire"
        ],
        "isCorrect": false
      },
      {
        "id": 12970,
        "content": [
          "backseats"
        ],
        "isCorrect": false
      },
      {
        "id": 12971,
        "content": [
          "wheels"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3241,
    "content": [
      "Choose the word which could be interchangeably used with the bolded and capitalized word in the sentence.",
      "---",
      "Harvard is one of the most **PRESTIGIOUS** universities in the USA."
    ],
    "explanation": [
      "A \"prestigious\" institution is one that is respected and admired. Therefore, \"admired\" is the best substitute."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 116,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12972,
        "content": [
          "privileged"
        ],
        "isCorrect": false
      },
      {
        "id": 12973,
        "content": [
          "admired"
        ],
        "isCorrect": true
      },
      {
        "id": 12974,
        "content": [
          "furnished"
        ],
        "isCorrect": false
      },
      {
        "id": 12975,
        "content": [
          "expensive"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3242,
    "content": [
      "Choose the word which could be interchangeably used with the bolded and capitalized word in the sentence.",
      "---",
      "The government has just **REPEALED** the law segregating public facilities so that there will be no longer discrimination."
    ],
    "explanation": [
      "To \"repeal\" a law means to revoke or annul it officially. \"Cancelled\" is the closest synonym for this action."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_SYNONYMS",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 116,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12976,
        "content": [
          "approved"
        ],
        "isCorrect": false
      },
      {
        "id": 12977,
        "content": [
          "renewed"
        ],
        "isCorrect": false
      },
      {
        "id": 12978,
        "content": [
          "signed"
        ],
        "isCorrect": false
      },
      {
        "id": 12979,
        "content": [
          "cancelled"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3243,
    "content": [
      "How many triangles are there in the diagram?",
      "images/sat/year_2017_na/q36_1.png"
    ],
    "explanation": [
      "The total number of triangles can be found by summing the triangles of different sizes.",
      "There are 8 small triangles (1-unit), 4 medium triangles composed of two small ones, and 4 large triangles composed of four small ones (one in each quadrant).",
      "The total is 8 + 4 + 4 = 16."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/sat/year_2017_na/q36_1.png"
    ],
    "choices": [
      {
        "id": 12980,
        "content": [
          "18"
        ],
        "isCorrect": false
      },
      {
        "id": 12981,
        "content": [
          "14"
        ],
        "isCorrect": false
      },
      {
        "id": 12982,
        "content": [
          "16"
        ],
        "isCorrect": true
      },
      {
        "id": 12983,
        "content": [
          "12"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3244,
    "content": [
      "Which one of the following statements is true?"
    ],
    "explanation": [
      "A rational number is defined as a number that can be expressed as a fraction p/q, where p and q are integers and q is not zero. Any integer 'a' can be written as a/1, making it the numerator of a rational number."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12984,
        "content": [
          "Every integer number can be numerator of a rational number."
        ],
        "isCorrect": true
      },
      {
        "id": 12985,
        "content": [
          "Every non-negative integer is a natural number."
        ],
        "isCorrect": false
      },
      {
        "id": 12986,
        "content": [
          "The intersection of the set of integers and the set of irrational numbers is non-empty set."
        ],
        "isCorrect": false
      },
      {
        "id": 12987,
        "content": [
          "The sum of two irrational numbers is irrational number."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3245,
    "content": [
      "If\n$$\nf(x) = sin(\\pi x) + e^{x^2} + |x| + x^3\n$$\nand\n$$\ng(x) = cos(\\pi x) + ln(x + 1) + x\n$$\nthen what is the value of f(1) - 2g(0)?"
    ],
    "explanation": [
      "First, evaluate f(1):\n$$\nf(1) = sin(\\pi) + e^{1^2} + |1| + 1^3\n$$\n$$\n= 0 + e + 1 + 1 = e + 2\n$$",
      "Next, evaluate g(0):\n$$\ng(0) = cos(0) + ln(0+1) + 0\n$$\n$$\n= 1 + ln(1) + 0 = 1 + 0 = 1\n$$",
      "Finally, calculate f(1) - 2g(0):\n$$\n(e + 2) - 2(1) = e + 2 - 2 = e\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12988,
        "content": [
          "e"
        ],
        "isCorrect": true
      },
      {
        "id": 12989,
        "content": [
          "ln 2"
        ],
        "isCorrect": false
      },
      {
        "id": 12990,
        "content": [
          "0"
        ],
        "isCorrect": false
      },
      {
        "id": 12991,
        "content": [
          "e + 2"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3246,
    "content": [
      "A person makes a glass of juice and used half of the glass with avocado, one third of the remaining half with mangoes and the rest is filled by banana and papaya with the same proportion. Which one of the following is the ratio of bananas to avocadoes in the glass?"
    ],
    "explanation": [
      "Let the total volume of the glass be 1 unit.",
      "Avocado takes up 1/2 of the glass.",
      "The remaining portion is 1 - 1/2 = 1/2.",
      "Mango takes up 1/3 of the remaining half, which is (1/3) × (1/2) = 1/6 of the glass.",
      "The rest is split between banana and papaya. The remaining portion for them is (1/2) - (1/6) = 2/6 = 1/3.",
      "Banana takes up half of this rest, so banana is (1/2) × (1/3) = 1/6 of the glass.",
      "The ratio of bananas to avocadoes is (1/6) : (1/2). Multiplying both sides by 6 gives 1:3."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12992,
        "content": [
          "1:6"
        ],
        "isCorrect": false
      },
      {
        "id": 12993,
        "content": [
          "1:2"
        ],
        "isCorrect": false
      },
      {
        "id": 12994,
        "content": [
          "1:3"
        ],
        "isCorrect": true
      },
      {
        "id": 12995,
        "content": [
          "2:3"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3247,
    "content": [
      "Which one of the following is the largest number?"
    ],
    "explanation": [
      "To compare the numbers, we raise them to a common power. The Least Common Multiple (LCM) of the root indices (6, 12, 36, 64) is 576.\n$$\n(5^{1/6})^{576} = 5^{96}\n$$\n$$\n(2^{1/36})^{576} = 2^{16}\n$$\n$$\n(11^{1/12})^{576} = 11^{48}\n$$\n$$\n(3^{1/64})^{576} = 3^{9}\n$$\nNow, compare the results. The main comparison is between 5⁹⁶ and 11⁴⁸.",
      "We can rewrite 5⁹⁶ as (5²)⁴⁸, which equals 25⁴⁸.",
      "Since 25⁴⁸ > 11⁴⁸, option (A) is larger than (C). The other results (2¹⁶ and 3⁹) are significantly smaller. Therefore, (A) is the largest number."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 12996,
        "content": [
          "$$\\sqrt[6]{5}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 12997,
        "content": [
          "$$\\sqrt[36]{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 12998,
        "content": [
          "$$\\sqrt[12]{11}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 12999,
        "content": [
          "$$\\sqrt[64]{3}$$"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3248,
    "content": [
      "Two pipes A and B are used to fill a water tank. Pipe A can fill the tank in 3 hours, and pipe B can fill the same tank in 6 hours. How long will it take in hours to fill the tank if both pipes are opened at the same time?"
    ],
    "explanation": [
      "The rate of pipe A is 1/3 of the tank per hour. The rate of pipe B is 1/6 of the tank per hour.",
      "Their combined rate is (1/3) + (1/6) = (2/6) + (1/6) = 3/6 = 1/2 of the tank per hour.",
      "The time required to fill the tank is the reciprocal of the combined rate: 1 / (1/2) = 2 hours."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13000,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 13001,
        "content": [
          "4"
        ],
        "isCorrect": false
      },
      {
        "id": 13002,
        "content": [
          "9"
        ],
        "isCorrect": false
      },
      {
        "id": 13003,
        "content": [
          "2"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3249,
    "content": [
      "A milk factory has only two pipe machines used to fill bottles for market. The old and new machines can fill 35 and 50 bottles per hour, respectively, and a total of 590 bottles are filled every day. One day the old machine was broken after working for 4 hours. How long will it take in hours for the new machine to fill the remaining bottles on that day?"
    ],
    "explanation": [
      "Assuming both machines worked together for the first 4 hours before the old one broke, their combined rate is 35 + 50 = 85 bottles/hour.",
      "In 4 hours, they filled 85 × 4 = 340 bottles.",
      "The number of remaining bottles to be filled is 590 - 340 = 250 bottles.",
      "The new machine, working alone at a rate of 50 bottles/hour, will take 250 / 50 = 5 hours to fill the remaining bottles."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13004,
        "content": [
          "8"
        ],
        "isCorrect": false
      },
      {
        "id": 13005,
        "content": [
          "5"
        ],
        "isCorrect": true
      },
      {
        "id": 13006,
        "content": [
          "13"
        ],
        "isCorrect": false
      },
      {
        "id": 13007,
        "content": [
          "7"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3250,
    "content": [
      "If a spherical soccer ball has a volume of 36π cm³, then which one of the following is the surface area of the ball in square centimeter?"
    ],
    "explanation": [
      "The formula for the volume of a sphere is V = (4/3)πr³.\n$$\n36\\pi = \\frac{4}{3}\\pi r^3\n$$\n$$\n36 = \\frac{4}{3}r^3\n$$\n$$\nr^3 = 36 \\times \\frac{3}{4} = 27\n$$\n$$\nr = 3 \\text{ cm}\n$$",
      "The formula for the surface area of a sphere is A = 4πr².\n$$\nA = 4\\pi(3)^2 = 4\\pi(9) = 36\\pi \\text{ cm}^2\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13008,
        "content": [
          "(16π)/3"
        ],
        "isCorrect": false
      },
      {
        "id": 13009,
        "content": [
          "12π"
        ],
        "isCorrect": false
      },
      {
        "id": 13010,
        "content": [
          "36π"
        ],
        "isCorrect": true
      },
      {
        "id": 13011,
        "content": [
          "(32π)/3"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3251,
    "content": [
      "A ball is shot into the air from the top of the building. The height in meter is given by h(t) = -t² + kt + 30, where t is the time taken in second. What is the possible value of k if the maximum value of height from the ground is 34?"
    ],
    "explanation": [
      "The function h(t) is a downward-opening parabola. Its maximum value occurs at the vertex. The t-coordinate of the vertex is t = -b/(2a) = -k/(2(-1)) = k/2.",
      "The maximum height is h(k/2). Substitute this into the equation:\n$$\nh(\\frac{k}{2}) = -(\\frac{k}{2})^2 + k(\\frac{k}{2}) + 30\n$$\n$$\n34 = -\\frac{k^2}{4} + \\frac{k^2}{2} + 30\n$$\n$$\n34 = \\frac{k^2}{4} + 30\n$$\n$$\n4 = \\frac{k^2}{4}\n$$\n$$\nk^2 = 16\n$$\n$$\nk = 4\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13012,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 13013,
        "content": [
          "4"
        ],
        "isCorrect": true
      },
      {
        "id": 13014,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 13015,
        "content": [
          "6"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3252,
    "content": [
      "A farmer has ten cows. Every day, he receives the same amount of milk in liters from each cow. One day, due to the food supply, he received half of the daily amount of milk from the four cows; he received three-fourth of the daily amount of milk from the three cows, and no milk from the other three cows. In total, he didn't receive ninety-two liters of milk on that day. How many liters of milk did he receive on that particular day?"
    ],
    "explanation": [
      "Let x be the normal daily amount of milk per cow. The normal total is 10x.",
      "On the given day, he received: (4 × x/2) + (3 × 3x/4) + (3 × 0) = 2x + 9x/4 = 17x/4.",
      "The shortfall is the difference between the normal amount and the received amount: 10x - 17x/4 = (40x - 17x)/4 = 23x/4.",
      "We are told this shortfall is 92 liters: 23x/4 = 92.",
      "Solving for x: 23x = 368, so x = 16.",
      "The amount he received is 17x/4 = (17 × 16) / 4 = 17 × 4 = 68 liters."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13016,
        "content": [
          "92"
        ],
        "isCorrect": false
      },
      {
        "id": 13017,
        "content": [
          "16"
        ],
        "isCorrect": false
      },
      {
        "id": 13018,
        "content": [
          "160"
        ],
        "isCorrect": false
      },
      {
        "id": 13019,
        "content": [
          "68"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3253,
    "content": [
      "Use the provided bar graph to answer the question.",
      "---",
      "How many days did the student study more than the average amount of the study?"
    ],
    "explanation": [
      "First, calculate the total study hours: (10 days × 2 hrs) + (7 days × 4 hrs) + (7 days × 6 hrs) + (5 days × 8 hrs) + (3 days × 10 hrs) = 20 + 28 + 42 + 40 + 30 = 160 hours.",
      "The total number of days is 32. The average study time is 160 hours / 32 days = 5 hours/day.",
      "We need to find the number of days the student studied MORE than 5 hours. This includes the days with 6, 8, and 10 hours of study.",
      "Number of days = 7 (for 6 hrs) + 5 (for 8 hrs) + 3 (for 10 hrs) = 15 days."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 117,
    "groupIndex": 1,
    "sharedContentId": 33,
    "sharedContent": [
      "The following bar graph shows the data of a students' study pattern recorded for 32 days.",
      "images/sat/year_2017_na/shared_content_33_1.png"
    ],
    "images": [
      "images/sat/year_2017_na/shared_content_33_1.png"
    ],
    "choices": [
      {
        "id": 13020,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 13021,
        "content": [
          "8"
        ],
        "isCorrect": false
      },
      {
        "id": 13022,
        "content": [
          "17"
        ],
        "isCorrect": false
      },
      {
        "id": 13023,
        "content": [
          "15"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3254,
    "content": [
      "Use the provided bar graph to answer the question.",
      "---",
      "How many days did the student study less than 8 hours?"
    ],
    "explanation": [
      "We need to sum the number of days for study amounts of 2, 4, and 6 hours.",
      "From the graph: 10 days (for 2 hours) + 7 days (for 4 hours) + 7 days (for 6 hours) = 24 days."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 117,
    "groupIndex": 2,
    "sharedContentId": 33,
    "sharedContent": [
      "The following bar graph shows the data of a students' study pattern recorded for 32 days.",
      "images/sat/year_2017_na/shared_content_33_1.png"
    ],
    "images": [
      "images/sat/year_2017_na/shared_content_33_1.png"
    ],
    "choices": [
      {
        "id": 13024,
        "content": [
          "18"
        ],
        "isCorrect": false
      },
      {
        "id": 13025,
        "content": [
          "6"
        ],
        "isCorrect": false
      },
      {
        "id": 13026,
        "content": [
          "24"
        ],
        "isCorrect": true
      },
      {
        "id": 13027,
        "content": [
          "12"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3255,
    "content": [
      "Use the provided bar graph to answer the question.",
      "---",
      "Which time in hours is the median amount of the study?"
    ],
    "explanation": [
      "There are a total of 32 days. The median is the average of the 16th and 17th values when the data is ordered.",
      "The first 10 days correspond to 2 hours of study.",
      "The next 7 days (days 11 through 17) correspond to 4 hours of study.",
      "Both the 16th and 17th values fall into the 4-hour category. Therefore, the median is 4 hours."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 117,
    "groupIndex": 3,
    "sharedContentId": 33,
    "sharedContent": [
      "The following bar graph shows the data of a students' study pattern recorded for 32 days.",
      "images/sat/year_2017_na/shared_content_33_1.png"
    ],
    "images": [
      "images/sat/year_2017_na/shared_content_33_1.png"
    ],
    "choices": [
      {
        "id": 13028,
        "content": [
          "6"
        ],
        "isCorrect": false
      },
      {
        "id": 13029,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 13030,
        "content": [
          "8"
        ],
        "isCorrect": false
      },
      {
        "id": 13031,
        "content": [
          "4"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3256,
    "content": [
      "If -x + 2y = 4, then what is the value of $$(25^y)/(5^x)$$?"
    ],
    "explanation": [
      "The expression can be rewritten using the same base, 5:\n$$(25^y)/(5^x) = (5^2)^y / 5^x = 5^{2y} / 5^x$$",
      "Using the rules of exponents, this simplifies to $$5^{2y-x}$$.",
      "Given that -x + 2y = 4, which is the same as 2y - x = 4, we can substitute the exponent.",
      "The value is $$5^4 = 625$$."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13032,
        "content": [
          "125"
        ],
        "isCorrect": false
      },
      {
        "id": 13033,
        "content": [
          "625"
        ],
        "isCorrect": true
      },
      {
        "id": 13034,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 13035,
        "content": [
          "25"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3257,
    "content": [
      "A woman burns 416 calories in an hour exercise at a fitness center. If she burns 10 calories per minute swimming in the water and 6 calories per minute pedaling on the stationary bike, then how many minutes of the hour does she spend exercising in the water?"
    ],
    "explanation": [
      "Let 's' be the number of minutes swimming and 'p' be the number of minutes pedaling. The total time is one hour, so s + p = 60.",
      "The total calories burned is 10s + 6p = 416.",
      "From the first equation, p = 60 - s. Substitute this into the second equation:\n$$10s + 6(60 - s) = 416$$\n$$10s + 360 - 6s = 416$$\n$$4s = 56$$\n$$s = 14$$",
      "She spends 14 minutes swimming."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13036,
        "content": [
          "56"
        ],
        "isCorrect": false
      },
      {
        "id": 13037,
        "content": [
          "14"
        ],
        "isCorrect": true
      },
      {
        "id": 13038,
        "content": [
          "60"
        ],
        "isCorrect": false
      },
      {
        "id": 13039,
        "content": [
          "46"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3258,
    "content": [
      "Which one of the following is the domain of g(x) = ln(1-x) + ln x?"
    ],
    "explanation": [
      "The natural logarithm function, ln(u), is only defined for u > 0.",
      "For ln(1-x), we must have 1 - x > 0, which means x < 1.",
      "For ln(x), we must have x > 0.",
      "To satisfy both conditions simultaneously, x must be greater than 0 AND less than 1. This corresponds to the open interval (0, 1)."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13040,
        "content": [
          "(0, ∞)"
        ],
        "isCorrect": false
      },
      {
        "id": 13041,
        "content": [
          "R\\\\{(-1,0)}"
        ],
        "isCorrect": false
      },
      {
        "id": 13042,
        "content": [
          "(0, 1)"
        ],
        "isCorrect": true
      },
      {
        "id": 13043,
        "content": [
          "(1, ∞)"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3259,
    "content": [
      "How many days are there from the first day of March to the last day of May?"
    ],
    "explanation": [
      "The number of days in each month are: March = 31, April = 30, May = 31.",
      "The total number of days is the sum: 31 + 30 + 31 = 92 days."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13044,
        "content": [
          "89"
        ],
        "isCorrect": false
      },
      {
        "id": 13045,
        "content": [
          "92"
        ],
        "isCorrect": true
      },
      {
        "id": 13046,
        "content": [
          "91"
        ],
        "isCorrect": false
      },
      {
        "id": 13047,
        "content": [
          "90"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3260,
    "content": [
      "A corporation pays ten employees a total of Birr 100,000 every month. Six out of ten employees receives less than Birr 10,000 per month.",
      "images/sat/year_2017_na/q53_1.png"
    ],
    "explanation": [
      "Quantity P (Average): The average payment is the total payment divided by the number of employees, which is 100,000 / 10 = 10,000 Birr.",
      "Quantity Q (Median): The median is the middle value. With 10 employees, it's the average of the 5th and 6th salaries when ordered from lowest to highest. Since 6 employees earn less than 10,000, both the 5th and 6th salaries must be less than 10,000. Therefore, their average (the median) must also be less than 10,000.",
      "Comparing the two, Quantity P (10,000) is greater than Quantity Q (< 10,000)."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 118,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/sat/year_2017_na/q53_1.png"
    ],
    "choices": [
      {
        "id": 13048,
        "content": [
          "Quantity P is greater than Quantity Q."
        ],
        "isCorrect": true
      },
      {
        "id": 13049,
        "content": [
          "Quantity P is less than Quantity Q."
        ],
        "isCorrect": false
      },
      {
        "id": 13050,
        "content": [
          "The two quantities cannot be compared."
        ],
        "isCorrect": false
      },
      {
        "id": 13051,
        "content": [
          "The two quantities are equal."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3261,
    "content": [
      "Consider the lengths of the sides of a triangle x, y, z, and the quantities given below.",
      "images/sat/year_2017_na/q54_1.png"
    ],
    "explanation": [
      "To compare Quantity P (3x + y - z) and Quantity Q (4x), we can simplify the comparison by subtracting 3x from both quantities.",
      "P: 3x + y - z - 3x = y - z",
      "Q: 4x - 3x = x",
      "According to the Triangle Inequality Theorem, the sum of the lengths of any two sides of a triangle must be greater than the length of the third side. Therefore:\n$$\nx + z > y\n$$\nBy rearranging this inequality, we get:\n$$\nx > y - z\n$$\nSince x is greater than y - z, it follows that Quantity Q must be greater than Quantity P."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": true,
    "groupId": 118,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/sat/year_2017_na/q54_1.png"
    ],
    "choices": [
      {
        "id": 13052,
        "content": [
          "Quantity P is less than Quantity Q."
        ],
        "isCorrect": true
      },
      {
        "id": 13053,
        "content": [
          "Quantity P is greater than Quantity Q."
        ],
        "isCorrect": false
      },
      {
        "id": 13054,
        "content": [
          "The two quantities cannot be compared."
        ],
        "isCorrect": false
      },
      {
        "id": 13055,
        "content": [
          "The two quantities are equal."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3262,
    "content": [
      "Which one of the following is true about the function $$f(x) = x^{2/5}$$?"
    ],
    "explanation": [
      "The function can be interpreted as $$f(x) = (\\sqrt{x})^2$$. The fifth root ($$\\sqrt{x}$$) is defined for all real numbers (positive, negative, and zero).",
      "The result of the fifth root is then squared. Squaring any real number results in a non-negative value (zero or positive).",
      "Therefore, the domain is all real numbers, and the range is all non-negative real numbers, {y ∈ R | y ≥ 0}."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13056,
        "content": [
          "The domain of f is {x ∈ R | x ≥ 0}"
        ],
        "isCorrect": false
      },
      {
        "id": 13057,
        "content": [
          "The range of f is {y ∈ R | y ≥ 0}"
        ],
        "isCorrect": true
      },
      {
        "id": 13058,
        "content": [
          "The range of f is {y | y ∈ R}"
        ],
        "isCorrect": false
      },
      {
        "id": 13059,
        "content": [
          "The domain of f is {x ∈ R | x ≤ 0}"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3263,
    "content": [
      "What is the value of z in the sequence 1, 2, 4, 8, 10, 20, 22, z,...?"
    ],
    "explanation": [
      "The pattern of the sequence is alternating between multiplying by 2 and adding 2.",
      "1 × 2 = 2; 2 + 2 = 4; 4 × 2 = 8; 8 + 2 = 10; 10 × 2 = 20; 20 + 2 = 22.",
      "The next step is to multiply by 2: 22 × 2 = 44. So, z = 44."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13060,
        "content": [
          "44"
        ],
        "isCorrect": true
      },
      {
        "id": 13061,
        "content": [
          "24"
        ],
        "isCorrect": false
      },
      {
        "id": 13062,
        "content": [
          "32"
        ],
        "isCorrect": false
      },
      {
        "id": 13063,
        "content": [
          "40"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3264,
    "content": [
      "An engineer is putting black and white colored ceramics on a square floor of area 36m². Each ceramic has area 1 m². The engineer places the black ones along both diagonals and the rest is covered by white colored ceramics. In what ratio is black to white ceramic used?"
    ],
    "explanation": [
      "The floor has an area of 36 m², so it is a 6m by 6m square. Since each ceramic is 1 m², the floor is a 6x6 grid of ceramics.",
      "The number of black ceramics on the two diagonals of a 6x6 grid is 6 + 6 = 12 (since the grid size is even, the diagonals do not share a central tile).",
      "Total number of tiles is 36. Number of white tiles = Total tiles - Black tiles = 36 - 12 = 24.",
      "The ratio of black to white tiles is 12:24, which simplifies to 1:2."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13064,
        "content": [
          "1:6"
        ],
        "isCorrect": false
      },
      {
        "id": 13065,
        "content": [
          "1:2"
        ],
        "isCorrect": true
      },
      {
        "id": 13066,
        "content": [
          "1:5"
        ],
        "isCorrect": false
      },
      {
        "id": 13067,
        "content": [
          "4:5"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3265,
    "content": [
      "A daily profit earned by a T-shirt factory is modeled by the formula p(x) =-x² + 1,400x - 80,000, where p is the profit and x is the price for each T-shirt sold. What range of prices will yield a profit of at least Birr 400,000?"
    ],
    "explanation": [
      "We need to solve the inequality p(x) ≥ 400,000.\n$$\n-x^2 + 1400x - 80000 \\geq 400000\n$$\n$$\n-x^2 + 1400x - 480000 \\geq 0\n$$",
      "Multiply by -1 and reverse the inequality sign:\n$$\nx^2 - 1400x + 480000 \\leq 0\n$$",
      "Factor the quadratic: (x - 600)(x - 800) ≤ 0.",
      "The roots are x = 600 and x = 800. Since the parabola opens upwards, the expression is less than or equal to zero between the roots.",
      "Therefore, the range of prices is 600 ≤ x ≤ 800."
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13068,
        "content": [
          "600 ≤ x ≤ 800"
        ],
        "isCorrect": true
      },
      {
        "id": 13069,
        "content": [
          "x ≤ 800"
        ],
        "isCorrect": false
      },
      {
        "id": 13070,
        "content": [
          "x ≤ 600 or x ≥ 800"
        ],
        "isCorrect": false
      },
      {
        "id": 13071,
        "content": [
          "x ≤ 600"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3266,
    "content": [
      "Points A, B and C are located on a circle with center O and radius 2 units long. If A, B and C are joined to form an equilateral triangle, then what is the area of triangle ABC in square units?"
    ],
    "explanation": [
      "For an equilateral triangle inscribed in a circle, the relationship between the side length (s) and the circumradius (R) is R = s/√3.",
      "Given R = 2, we can find the side length: 2 = s/√3, so s = 2√3.",
      "The area of an equilateral triangle is given by the formula A = (s²√3)/4.\n$$\nA = \\frac{(2\\sqrt{3})^2\\sqrt{3}}{4}\n$$\n$$\n= \\frac{(4 \\times 3)\\sqrt{3}}{4}\n$$\n$$\n= \\frac{12\\sqrt{3}}{4} = 3\\sqrt{3}\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13072,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 13073,
        "content": [
          "√3"
        ],
        "isCorrect": false
      },
      {
        "id": 13074,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 13075,
        "content": [
          "3√3"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3267,
    "content": [
      "What is the possible value of the missing term x in the sequence -1, 0, 1, 2, -1, 8, 1, 26, -1, x, 1, 242, -1, 728, 1,...?"
    ],
    "explanation": [
      "This sequence interleaves three separate patterns. The pattern that includes x is the subsequence formed by every third number starting from the second term:",
      "0, 2, 8, 26, x, 242, 728\nLet's analyze the differences between the terms in this subsequence:",
      "2 - 0 = 2",
      "8 - 2 = 6",
      "26 - 8 = 18",
      "The pattern of these differences is that each new difference is **3 times** the previous one (2, 6, 18, ...). Following this pattern, the next difference must be:\n$$\n18 \\times 3 = 54\n$$\nTo find the value of x, we add this difference to the previous term (26):\n$$\nx = 26 + 54 = 80\n$$"
    ],
    "year": "YEAR_2017",
    "subject": "SAT_NATURAL",
    "chapter": "SAT_QUANTITATIVE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13076,
        "content": [
          "54"
        ],
        "isCorrect": false
      },
      {
        "id": 13077,
        "content": [
          "36"
        ],
        "isCorrect": false
      },
      {
        "id": 13078,
        "content": [
          "80"
        ],
        "isCorrect": true
      },
      {
        "id": 13079,
        "content": [
          "34"
        ],
        "isCorrect": false
      }
    ]
  }
];
export default questions;
