// StudentPrep Premium Content — complete question bank.
const questions = [
  {
    "id": 401,
    "content": [
      "In a kinetic experiment, a student placed crystals of iodine in a closed reaction vessel, introduced a given quantity of hydrogen gas, and collected data to calculate the rate of formation of hydrogen iodide. What would be the effect obtained on the rate of the reaction, if the student takes more amount of iodine from that used in the first experiment?"
    ],
    "explanation": [
      "Increasing the amount of iodine in the reaction vessel will increase the rate of the reaction. This is because the rate of a reaction depends on the concentration of the reactants. In this case, more iodine means a higher concentration of one of the reactants, which leads to an increased rate of reaction."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1601,
        "content": [
          "It speeds up the rate of the reaction."
        ],
        "isCorrect": true
      },
      {
        "id": 1602,
        "content": [
          "It lowers the rate of the reaction."
        ],
        "isCorrect": false
      },
      {
        "id": 1603,
        "content": [
          "The formation of hydrogen iodide will be decreased."
        ],
        "isCorrect": false
      },
      {
        "id": 1604,
        "content": [
          "The rate of the reaction will be constant."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Chemical Kinetics"
  },
  {
    "id": 402,
    "content": [
      "Which of the following CORRECTLY relates the vapor pressure of a liquid with its boiling point? Boiling point is"
    ],
    "explanation": [
      "The boiling point of a liquid is defined as the temperature at which its vapor pressure equals the external pressure surrounding the liquid."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1605,
        "content": [
          "the temperature at which all the three physical state co-exist."
        ],
        "isCorrect": false
      },
      {
        "id": 1606,
        "content": [
          "the temperature at which the vapor pressure becomes equal to the external pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 1607,
        "content": [
          "the temperature at which molecules present in the vapor phase go back to the liquid state."
        ],
        "isCorrect": false
      },
      {
        "id": 1608,
        "content": [
          "the temperature at which the kinetic energy of molecules is much less than the intermolecular force."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 403,
    "content": [
      "Consider this equilibrium system:",
      "$$CO (g)$$ + $$Fe_3O_4(s)$$ ⇋ $$CO_2 (g)$$ + $$3FeO(s)$$",
      "Which of the following disturbances shift the equilibrium position to the right?"
    ],
    "explanation": [
      "To determine which disturbances shift the equilibrium position to the right, we can use Le Chatelier’s principle. This principle states that if a system at equilibrium is disturbed, the system will adjust itself to counteract the disturbance and restore a new equilibrium.\n\nOption 1: Removing $$CO_2 (g)$$\n\n- Removing a product will shift the equilibrium to the right to produce more $$CO_2 (g)$$ to counteract the disturbance.\n\nOption 2: Removing $$CO (g)$$\n\n- Removing a reactant will shift the equilibrium to the left to produce more $$CO (g)$$ to counteract the disturbance.\n\nOption 3: Removing $$FeO (s)$$\n\n- Since $$FeO (s)$$ is a solid, its removal does not affect the equilibrium position because the concentration of solids does not appear in the equilibrium expression.\n\nOption 4: Adding $$Fe_3O_4 (s)$$\n\n- Adding a solid reactant does not affect the equilibrium position for the same reason as in above.\n\nTherefore, the disturbance that shifts the equilibrium position to the right is: Removing $$CO_2 (g)$$."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1609,
        "content": [
          "Removing $$CO_2 (g)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1610,
        "content": [
          "Removing $$CO (g)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1611,
        "content": [
          "Removing $$FeO (s)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1612,
        "content": [
          "Adding $$Fe_3O_4 (s)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Chemical Equilibrium"
  },
  {
    "id": 404,
    "content": [
      "Which one of the following resulted from interaction of the atomic orbitals of bonding atoms to produce new electron distribution associated with the entire molecule?"
    ],
    "explanation": [
      "Molecular orbitals are formed from the interaction of atomic orbitals of bonding atoms, resulting in a new electron distribution associated with the entire molecule. This process is described by the molecular orbital theory."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1613,
        "content": [
          "Electron orbit"
        ],
        "isCorrect": false
      },
      {
        "id": 1614,
        "content": [
          "Bohr orbit"
        ],
        "isCorrect": false
      },
      {
        "id": 1615,
        "content": [
          "Hybrid orbital"
        ],
        "isCorrect": false
      },
      {
        "id": 1616,
        "content": [
          "Molecular orbital"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 405,
    "content": [
      "Which type of organic substances would be produced by heating a mixture of a carboxylic acid and an alcohol in the presence of $$H_2SO_4$$?"
    ],
    "explanation": [
      "When a carboxylic acid and an alcohol are heated in the presence of sulfuric acid ($$H_2SO_4$$), they undergo a reaction known as **esterification**. \n\nThis process produces esters and water as byproducts. The sulfuric acid acts as a catalyst, facilitating the reaction by protonating the carboxyl group, making it more electrophilic and thus more reactive towards the alcohol."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1617,
        "content": [
          "Ketones"
        ],
        "isCorrect": false
      },
      {
        "id": 1618,
        "content": [
          "Aldehydes"
        ],
        "isCorrect": false
      },
      {
        "id": 1619,
        "content": [
          "Esters"
        ],
        "isCorrect": true
      },
      {
        "id": 1620,
        "content": [
          "Ethers"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 406,
    "content": [
      "Which one of the following is the reducing agent in the following reaction?\n$$\n8NH_3 (g) +6NO_2 (g) \\rightarrow 7N_2 (g) + 12H_2O (l)\n$$"
    ],
    "explanation": [
      "In this reaction, ammonia ($$NH_3$$) is oxidized as its nitrogen changes from an oxidation state of -3 in $$NH_3$$ to 0 in $$N_2$$. This means $$NH_3$$ loses electrons and thus acts as the reducing agent."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1621,
        "content": [
          "$$NO_2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1622,
        "content": [
          "$$NH_3$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1623,
        "content": [
          "$$H_2O$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1624,
        "content": [
          "$$N_2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 407,
    "content": [
      "Carbon forms two stable compounds with oxygen, namely, carbon monoxide and carbon dioxide. For a fixed mass of carbon, the ratio of oxygen in carbon monoxide to oxygen in carbon dioxide is 1:2. This result is consistent with the law of"
    ],
    "explanation": [
      "The law of multiple proportion states that when two elements form more than one compound, the masses of one element that combine with a fixed mass of the other are in the ratio of small whole numbers.\n\nHere, the ratio of oxygen in carbon monoxide to oxygen in carbon dioxide is 1:2, consistent with this law."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1625,
        "content": [
          "definite proportion."
        ],
        "isCorrect": false
      },
      {
        "id": 1626,
        "content": [
          "conservation of mass."
        ],
        "isCorrect": false
      },
      {
        "id": 1627,
        "content": [
          "constant composition."
        ],
        "isCorrect": false
      },
      {
        "id": 1628,
        "content": [
          "multiple proportion."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 408,
    "content": [
      "When a system at equilibrium is disturbed by a change of variable, the system shifts the equilibrium position in a way that tends to counteract this change of variable. This is a statement for"
    ],
    "explanation": [
      "Le Chatelier’s Principle states that if a dynamic equilibrium is disturbed by changing the conditions, the position of equilibrium shifts to counteract the change and reestablish equilibrium.\n\nThis principle helps predict how a system at equilibrium will respond to changes in concentration, temperature, or pressure."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1629,
        "content": [
          "Pauli's exclusion principle"
        ],
        "isCorrect": false
      },
      {
        "id": 1630,
        "content": [
          "Aufbau principle"
        ],
        "isCorrect": false
      },
      {
        "id": 1631,
        "content": [
          "Heisenberg uncertainty principle"
        ],
        "isCorrect": false
      },
      {
        "id": 1632,
        "content": [
          "Le Chatelier Principle"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 409,
    "content": [
      "Which one of the following graphs illustrates the rate change in terms of change in reactant concentration with time?"
    ],
    "explanation": [
      "The correct graph shows a curve that starts high and decreases rapidly at first, then levels off as it approaches the horizontal axis.\n\nThis indicates a rapid initial decrease in reactant concentration, which slows down over time."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1633,
        "content": [
          "images/chemistry/year_2015/q9c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1634,
        "content": [
          "images/chemistry/year_2015/q9c2_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 1635,
        "content": [
          "images/chemistry/year_2015/q9c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1636,
        "content": [
          "images/chemistry/year_2015/q9c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Acid Base Equilibria"
  },
  {
    "id": 410,
    "content": [
      "Which one of the following gas laws states the volume of a fixed amount of gas maintained at constant pressure is directly proportional to the absolute temperature of the gas?"
    ],
    "explanation": [
      "Charles' law states that the volume of a fixed amount of gas is directly proportional to its absolute temperature, provided the pressure remains constant.\n$$\n\\frac{V_1}{T_1} = \\frac{V_2}{T_2}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1637,
        "content": [
          "Charles' law"
        ],
        "isCorrect": true
      },
      {
        "id": 1638,
        "content": [
          "Boyle's law"
        ],
        "isCorrect": false
      },
      {
        "id": 1639,
        "content": [
          "Avogadro's law"
        ],
        "isCorrect": false
      },
      {
        "id": 1640,
        "content": [
          "Combined gas law"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 411,
    "content": [
      "The pH of a 0.1 M solution of formic acid (HCOOH) is 3. What is the Ka of the acid?"
    ],
    "explanation": [
      "$$\\text{HCOOH}$$ ⇌ $$\\text{H}^+$$ + $$\\text{HCOO}^-$$\n\nLet x represent the concentration of $$\\text{H}^+$$ and $$\\text{HCOO}^-$$ at equilibrium:\n\n| Species | Initial Concentration (M) | Change (M) | Equilibrium Concentration (M) |\n| --- | --- | --- | --- |\n| $$\\text{HCOOH}$$ | 0.1 | -x | 0.1 - x |\n| $$\\text{H}^+$$ | 0 | +x | x |\n| $$\\text{HCOO}^-$$ | 0 | +x | x |\n\nThe pH of the solution is given as 3, so the concentration of $$\\text{H}^+$$ is:\n$$\n\\text{H}^+] = 10^{-3} \\, \\text{M}\n$$\n\nThis means that:\n\n$$\nx = 10^{-3} \\, \\text{M}\n$$\nThe expression for the acid dissociation constant is:\n$$\nK_a = \\frac{[\\text{H}^+][\\text{HCOO}^-]}{[\\text{HCOOH}]}\n$$\n\nSubstitute the equilibrium concentrations from the table:\n$$\nK_a = \\frac{x \\cdot x}{0.1 - x}\n$$\n\nNow substitute ($$x = 10^{-3}$$) into the equation:\n$$\nK_a = \\frac{(10^{-3})(10^{-3})}{0.1 - 10^{-3}}\n$$\n$$\nK_a \\approx 1.01 \\times 10^{-5}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1641,
        "content": [
          "$$1.01 \\times 10^{-5}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1642,
        "content": [
          "$$1.01 \\times 10^{-7}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1643,
        "content": [
          "$$9.99 \\times 10^{-4}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1644,
        "content": [
          "$$9.99 \\times 10^{-5}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 412,
    "content": [
      "A system does 15 J of work and no other changes take place. Which of the following function has fallen by 15 J?"
    ],
    "explanation": [
      "When a system does work, it loses energy. Since no other changes take place, the work done by the system (15 J) results in a decrease in its internal energy by the same amount. Therefore, the internal energy has fallen by 15 J."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1645,
        "content": [
          "Internal energy"
        ],
        "isCorrect": true
      },
      {
        "id": 1646,
        "content": [
          "Specific heat"
        ],
        "isCorrect": false
      },
      {
        "id": 1647,
        "content": [
          "Enthalpy"
        ],
        "isCorrect": false
      },
      {
        "id": 1648,
        "content": [
          "Entropy"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 413,
    "content": [
      "Which of the following is CORRECTLY stated about the spontaneity of a reaction?"
    ],
    "explanation": [
      "To determine the spontaneity of a reaction, we use the Gibbs free energy equation:\n\n$$\n\\Delta G = \\Delta H - T \\Delta S\n$$\n\nWhere:\n\n- $$\\Delta G$$ is the change in Gibbs free energy,\n- $$\\Delta H$$ is the change in enthalpy,\n- T is the temperature in Kelvin, and\n- $$\\Delta S$$ is the change in entropy.\n\nA reaction is **spontaneous** if $$\\Delta G < 0$$.\n\nFor an endothermic reaction ($$\\Delta H > 0$$) with positive reaction entropy ($$\\Delta S > 0$$), at low temperatures, $$T \\Delta S$$ is small, and $$\\Delta G$$ will be positive. Thus, the reaction is non-spontaneous at low temperatures. At higher temperatures, $$T \\Delta S$$ can dominate, potentially making $$\\Delta G$$ negative, leading to spontaneity."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1649,
        "content": [
          "For an endothermic reaction with negative reaction entropy, the reaction is spontaneous at all temperature."
        ],
        "isCorrect": false
      },
      {
        "id": 1650,
        "content": [
          "For an exothermic reaction with positive reaction entropy, the reaction is non-spontaneous at all temperature."
        ],
        "isCorrect": false
      },
      {
        "id": 1651,
        "content": [
          "For an endothermic reaction with positive reaction entropy, the reaction is non-spontaneous at low temperature."
        ],
        "isCorrect": true
      },
      {
        "id": 1652,
        "content": [
          "For an exothermic reaction with negative reaction entropy, the reaction is spontaneous at high temperature."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 414,
    "content": [
      "In thermodynamics: solutions in a beaker, a gas in a cylinder, a reaction vessel, a biological cell are examples of a"
    ],
    "explanation": [
      "A thermodynamic system is a specific portion of matter or a space where thermodynamic processes occur and are studied."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1653,
        "content": [
          "thermodynamic variables"
        ],
        "isCorrect": false
      },
      {
        "id": 1654,
        "content": [
          "state function"
        ],
        "isCorrect": false
      },
      {
        "id": 1655,
        "content": [
          "path function"
        ],
        "isCorrect": false
      },
      {
        "id": 1656,
        "content": [
          "thermodynamic system"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 415,
    "content": [
      "Given the following:",
      "images/chemistry/year_2015/q15_1.png",
      "and the enthalpy for the reaction\n$$\n\\frac{1}{2}N_2(g) +\\frac{3}{2} H_2(g)  \\rightarrow NH_3(g); \\Delta H=-45 kJ/mol\n$$\nWhat is the bond energy for $$NH_3$$?"
    ],
    "explanation": [
      "The enthalpy change $$\\Delta H$$ for a reaction is given by the equation:\n$$\n\\Delta H = \\sum \\text{(Bond energies of bonds broken)} - \\sum \\text{(Bond energies of bonds formed)}\n$$\n\nFor the reaction:\n$$\n\\frac{1}{2}N_2(g) + \\frac{3}{2}H_2(g)  \\rightarrow NH_3(g)\n$$\n\n- Bonds broken:\n    - $$\\frac{1}{2}$$ mole of $$N \\equiv N$$ (bond energy = 942 kJ/mol)\n    - $$\\frac{3}{2}$$ moles of $$H-H$$ (bond energy = 436 kJ/mol)\n- Bonds formed:\n    - 1 mole of $$NH_3$$, which contains $$3 N-H$$ bonds (let's call it x)\n\nThe enthalpy of the reaction is given as $$\\Delta H = -45 \\text{ kJ/mol}$$. Now, substitute the bond energies into the enthalpy equation:\n$$\n-45 = \\left( \\frac{1}{2} \\times 942 + \\frac{3}{2} \\times 436 \\right) - (3 \\times x)\n$$\n$$\nx = \\frac{1170}{3} = 390 \\text{ kJ/mol}\n$$\nThe bond energy of each $$N-H$$ bond in $$NH_3$$ is 390 kJ/mol. Since $$NH_3$$ has 3 $$N-H$$ bonds, the total bond energy for $$NH_3$$ is:\n$$\n3 \\times 390 = 1170 \\text{ kJ/mol}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2015/q15_1.png"
    ],
    "choices": [
      {
        "id": 1657,
        "content": [
          "1125"
        ],
        "isCorrect": false
      },
      {
        "id": 1658,
        "content": [
          "1170"
        ],
        "isCorrect": true
      },
      {
        "id": 1659,
        "content": [
          "960"
        ],
        "isCorrect": false
      },
      {
        "id": 1660,
        "content": [
          "1080"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 416,
    "content": [
      "The rate law for: $$(CH_3)_3 \\text{-} C \\text{-} Br (aq)$$ + $$H_2O (l)$$ $$\\rightarrow$$ $$(CH_3)_3 \\text{-} C \\text{-} OH (aq)$$ + $$H^+$$ + $$Br^ \\text{-} (aq)$$ is rate= $$k [(CH_3)_3 \\text{-} C \\text{-} Br]$$.\n\nThe accepted mechanism for the reaction is\n\nI. $$(CH_3)_3 \\text{-} C \\text{-} Br(aq)$$ $$\\rightarrow$$ $$(CH_3)_3 \\text{-} C^+(aq)$$ + $$Br^-(aq)$$ [slow]\n\nII. $$(CH_3)_3 \\text{-} C^+(aq)$$ + $$H_2O(l)$$ $$\\rightarrow$$ $$(CH_3)_3 \\text{-} C \\text{-} OH_2^+ (aq)$$ [fast]\n\nIII. $$(CH_3)_3 \\text{-} C \\text{-} OH_2^+ (aq)$$ $$\\rightarrow$$ $$H^+$$+ $$(CH_3)_3 \\text{-} C \\text{-} OH(aq)$$ [fast]\n\nWhy DOES NOT $$H_2O$$ appear in the rate law? Beacuse"
    ],
    "explanation": [
      "The rate law is determined by the rate-determining step, which is the slowest step in the reaction mechanism.\n\nIn the given mechanism, the first step (I) is the slow step. Since this step does not involve water, water does not appear in the rate law. The species that participate in the slow step are what determine the rate law."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1661,
        "content": [
          "water is a catalyst in the reaction."
        ],
        "isCorrect": false
      },
      {
        "id": 1662,
        "content": [
          "water is an intermediate species."
        ],
        "isCorrect": false
      },
      {
        "id": 1663,
        "content": [
          "water exists in the liquid state in the reaction."
        ],
        "isCorrect": false
      },
      {
        "id": 1664,
        "content": [
          "water is missing in the rate determining step."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 417,
    "content": [
      "Which type of substances has the following general formula? ($$R_1$$, $$R_2$$ and $$R_3$$ hydrocarbon groups.)",
      "images/chemistry/year_2015/q17_1.png"
    ],
    "explanation": [
      "The structure is characteristic of triglycerides, which are a type of fat. Triglycerides consist of a glycerol molecule bonded to three fatty acid chains through ester linkages."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2015/q17_1.png"
    ],
    "choices": [
      {
        "id": 1665,
        "content": [
          "Carboxylic acids"
        ],
        "isCorrect": false
      },
      {
        "id": 1666,
        "content": [
          "Fats"
        ],
        "isCorrect": true
      },
      {
        "id": 1667,
        "content": [
          "Alcohols"
        ],
        "isCorrect": false
      },
      {
        "id": 1668,
        "content": [
          "Fatty acids"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 418,
    "content": [
      "The rate law for this reaction\n$$\nCO (g) + NO_2 (g) \\rightarrow CO+2 (g) + NO (g)\n$$\nis rate = $$k[NO_2]^2$$.\n\nWhich one of the following could be a plausible mechanism for the reaction?"
    ],
    "explanation": [
      "For this rate law, the rate-determining step (slow step) must involve two molecules of $$NO_2$$.\n\nThe correct choice is:\n\n$$\nNO_2(g) + NO_2(g) \\rightarrow NO_3(g) + NO(g) \\ \\text{[slow]}\n$$\n\n$$\nNO_3(g) + CO(g) \\rightarrow NO_2(g) + CO_2(g) \\ \\text{[fast]}\n$$\n\nSince the slow step involves two molecules of $$NO_2$$, the rate law for the slow step is:\n$$\n\\text{rate} = k[NO_2]^2\n$$\n\nOther options involve different steps as the slow step, but they do not yield the correct rate law involving $$[NO_2]^2$$."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1669,
        "content": [
          "$$NO_2(g)$$ + $$NO_2 (g)$$ $$\\rightarrow$$ $$NO_3 (g)$$ + $$NO (g)$$ [slow]",
          "$$NO_3(g)$$ + $$CO (g)$$ $$\\rightarrow$$ $$NO_2 (g)$$ + $$CO_2(g)$$ [fast]"
        ],
        "isCorrect": true
      },
      {
        "id": 1670,
        "content": [
          "$$NO_3(g)$$ + $$NO (g)$$ $$\\rightarrow$$ $$NO_2 (g)$$ + $$NO_2 (g)$$ [slow]",
          "$$NO_3(g)$$ + $$CO (g)$$ $$\\rightarrow$$ $$NO_2 (g)$$ + $$CO_2 (g)$$ [fast]"
        ],
        "isCorrect": false
      },
      {
        "id": 1671,
        "content": [
          "$$NO_3 (g)$$ + $$NO (g)$$ $$\\rightarrow$$ $$NO_2(g)$$ + $$NO_2 (g)$$ [slow]",
          "$$NO_2 (g)$$ + $$CO_2 (g)$$ $$\\rightarrow$$ $$NO_3 (g)$$ + $$CO (g)$$ [fast]"
        ],
        "isCorrect": false
      },
      {
        "id": 1672,
        "content": [
          "$$NO_2 (g)$$ + $$NO_2 (g)$$ $$\\rightarrow$$ $$NO_3 (g)$$ + $$NO (g)$$ [fast]",
          "$$NO_3 (g)$$ + $$CO (g)$$ $$\\rightarrow$$ $$NO_2 (g)$$ + $$CO_2 (g)$$ [slow]"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 419,
    "content": [
      "The speed with which a solute goes into solution is"
    ],
    "explanation": [
      "The rate of dissolution refers to how quickly a solute dissolves in a solvent."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1673,
        "content": [
          "degree of solvation"
        ],
        "isCorrect": false
      },
      {
        "id": 1674,
        "content": [
          "heat of solution"
        ],
        "isCorrect": false
      },
      {
        "id": 1675,
        "content": [
          "rate of dissolution"
        ],
        "isCorrect": true
      },
      {
        "id": 1676,
        "content": [
          "extent of dissolution"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 420,
    "content": [
      "Which one of the following explains how 2 L of 1 M NaOH aqueous stock solution is converted into a 0.25 M NaOH solution?"
    ],
    "explanation": [
      "The dilution formula is:\n\n$$\nM_1 \\times V_1 = M_2 \\times V_2\n$$\n\n$$\n1 \\times 2 = 0.25 \\times V_2\n$$\n\n$$\nV_2 = \\frac{2}{0.25} = 8 \\, \\text{L}\n$$\n\nSo, the final volume $$V_2$$ should be 8 L. To achieve this, you need to add water to the initial 2 L solution to make up the total volume to 8 L. Therefore, you need to add:\n\n$$\n8 \\, \\text{L} - 2 \\, \\text{L} = 6 \\, \\text{L}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1677,
        "content": [
          "Adding 6 L water to the stock solution"
        ],
        "isCorrect": true
      },
      {
        "id": 1678,
        "content": [
          "Adding 8 L water to the stock solution"
        ],
        "isCorrect": false
      },
      {
        "id": 1679,
        "content": [
          "Evaporating 0.25 L of water from the stock solution"
        ],
        "isCorrect": false
      },
      {
        "id": 1680,
        "content": [
          "Evaporating 1 L of water from the stock solution"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 421,
    "content": [
      "Which one of the following IS TRUE about isotopes?"
    ],
    "explanation": [
      "Isotopes of an element have the same number of protons and electrons, which means they have the same chemical properties. However, they differ in the number of neutrons, leading to different mass numbers."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1681,
        "content": [
          "Isotopes of an element are identical in mass number."
        ],
        "isCorrect": false
      },
      {
        "id": 1682,
        "content": [
          "Isotopes of the same elements contain the same number of neutrons."
        ],
        "isCorrect": false
      },
      {
        "id": 1683,
        "content": [
          "Isotopes of an element have the same chemical properties."
        ],
        "isCorrect": true
      },
      {
        "id": 1684,
        "content": [
          "Isotopes of an element are atoms that have different number of electrons and protons."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 422,
    "content": [
      "Which one of the following describes the quantum mechanical model?"
    ],
    "explanation": [
      "The quantum mechanical model of the atom describes the behavior of electrons in terms of probabilities rather than fixed paths. This model indicates that electrons do not follow precise orbits but are found within regions called orbitals, where there is a high probability of locating them."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1685,
        "content": [
          "The locations of electrons in an atom are described in terms of probability."
        ],
        "isCorrect": true
      },
      {
        "id": 1686,
        "content": [
          "An atom is represented by a solid indestructible sphere."
        ],
        "isCorrect": false
      },
      {
        "id": 1687,
        "content": [
          "An atom is a sphere with a positively charged matter, in which electrons are embedded."
        ],
        "isCorrect": false
      },
      {
        "id": 1688,
        "content": [
          "Electrons moved around the nucleus of an atom in circular orbits."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 423,
    "content": [
      "Which one of the following is the diagrammatic representation of $$_{17}^{35}Cl$$?"
    ],
    "explanation": [
      "The correct arrangement is 17 protons and 18 neutrons (35 - 17), with 2 electrons in the first shell, 8 in the second, and 7 in the third."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1689,
        "content": [
          "images/chemistry/year_2015/q23c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1690,
        "content": [
          "images/chemistry/year_2015/q23c2_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 1691,
        "content": [
          "images/chemistry/year_2015/q23c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1692,
        "content": [
          "images/chemistry/year_2015/q23c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 424,
    "content": [
      "Which one of the following is an ionic compound?"
    ],
    "explanation": [
      "Ionic compounds are formed when there is a transfer of electrons between atoms, typically between a metal and a non-metal, leading to the formation of positive and negative ions.\n\nIn $$CaCl_2$$, calcium (Ca) is a metal, and chlorine (Cl) is a non-metal. Calcium loses two electrons to become a $$Ca^{2+}$$ ion, while each chlorine atom gains one electron to become a $$Cl^-$$ ion, resulting in an ionic bond."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1693,
        "content": [
          "$$CaCl_2$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1694,
        "content": [
          "$$CO_2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1695,
        "content": [
          "$$PCl_3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1696,
        "content": [
          "$$H_2O_2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 425,
    "content": [
      "An element is located in Group VIIA and $$3^{rd}$$ period of the modern periodic table. On the basis of this the element;"
    ],
    "explanation": [
      "An element in Group VIIA (Group 17) and the 3rd period is chlorine (Cl). Chlorine is a halogen and non-metal, and it typically forms acidic oxides like $$\\text{Cl}_2\\text{O}_7$$. This is characteristic of non-metals in this group."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PERIODIC_TABLE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1697,
        "content": [
          "generally forms an ion with -2 charges."
        ],
        "isCorrect": false
      },
      {
        "id": 1698,
        "content": [
          "has very low ionization energy."
        ],
        "isCorrect": false
      },
      {
        "id": 1699,
        "content": [
          "forms an acidic oxide."
        ],
        "isCorrect": true
      },
      {
        "id": 1700,
        "content": [
          "has extremely low electron affinity."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Periodic Classification of Elements"
  },
  {
    "id": 426,
    "content": [
      "Which of the properties of solvents WOULD NOT be affected by the formation of a solution with a non-volatile solute?"
    ],
    "explanation": [
      "The chemical identity of a solvent remains unchanged by the formation of a solution, as the solvent retains its molecular structure and composition. However, properties like boiling point, chemical potential, and freezing point would be affected when a non-volatile solute is added."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1701,
        "content": [
          "Boiling Point"
        ],
        "isCorrect": false
      },
      {
        "id": 1702,
        "content": [
          "Chemical potential"
        ],
        "isCorrect": false
      },
      {
        "id": 1703,
        "content": [
          "Chemical identity"
        ],
        "isCorrect": true
      },
      {
        "id": 1704,
        "content": [
          "Freezing Point"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 427,
    "content": [
      "The partial pressure of acetylene, $$C_2H_2$$, in a container is 10 atm at 25°C. What is the solubility in molarity of $$C_2H_2$$, assume that $$C_2H_2$$ obeys Henry's law? ($$K_H$$ = $$1.04 \\ \\text{mol/L atm}$$)"
    ],
    "explanation": [
      "Using Henry's Law:\n\n$$\nC = K_H \\cdot P\n$$\n\nWhere\n\n- C is the solubility in mol/L\n- $$K_H$$ is the Henry's law constant\n- P is the partial pressure of the gas.\n\n$$\nC = (1.04 \\ \\text{mol/L atm}) \\times (10 \\ \\text{atm}) = 10.4 \\ \\text{mol/L}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1705,
        "content": [
          "0.104"
        ],
        "isCorrect": false
      },
      {
        "id": 1706,
        "content": [
          "9.62"
        ],
        "isCorrect": false
      },
      {
        "id": 1707,
        "content": [
          "104"
        ],
        "isCorrect": false
      },
      {
        "id": 1708,
        "content": [
          "10.4"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 428,
    "content": [
      "What is the normality of a solution that contains 19.6 g of $$H_2SO_4$$, in 20 mL of the solution?"
    ],
    "explanation": [
      "$$\nN = \\frac{\\text{Weight of Solute (g)}}{\\text{Equivalent Weight of Solute (g/eq)} \\times \\text{Volume of Solution (L)}}\n$$\n\nGiven:\n\n- Weight of  $$H_2SO_4$$ = 19.6 g\n- Volume of solution = 20 mL = 0.02 L\n\nThe molecular weight of  $$H_2SO_4$$ is 98 g/mol, and since  $$H_2SO_4$$ has 2 hydrogen ions (H⁺), its equivalent weight is:\n\n$$\n\\text{Equivalent Weight} = \\frac{\\text{Molecular Weight}}{\\text{Number of H⁺ ions}} = \\frac{98}{2} = 49 \\text{ g/eq}\n$$\n\nCalculate the normality:\n\n$$\nN = \\frac{19.6 \\text{ g}}{49 \\text{ g/eq} \\times 0.02 \\text{ L}} = 20 \\text{ N}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1709,
        "content": [
          "0.02"
        ],
        "isCorrect": false
      },
      {
        "id": 1710,
        "content": [
          "0.01"
        ],
        "isCorrect": false
      },
      {
        "id": 1711,
        "content": [
          "20"
        ],
        "isCorrect": true
      },
      {
        "id": 1712,
        "content": [
          "10"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 429,
    "content": [
      "Which one of the following illustrates an extensive property?"
    ],
    "explanation": [
      "An extensive property is one that depends on the amount of matter or size of the system. If a system is divided into parts, the value of an extensive property for the entire system will be the sum of the values of that property for all the individual parts.\n\nExamples of extensive properties include mass, volume, and total energy. This behavior distinguishes extensive properties from intensive properties, which remain the same regardless of the system's size or amount of matter."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1713,
        "content": [
          "The electrode potential at standard condition for the half-reaction $$2Cu^{2+}$$ + $$4e^-$$ $$\\rightarrow$$ $$2Cu$$ is the same as for $$Cu^{2+}$$ + $$2e^-$$ $$\\rightarrow$$ $$2Cu$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1714,
        "content": [
          "If a system is divided into parts and it is found that the property of the complete system has a value that is the sum of the values of the property of all the parts."
        ],
        "isCorrect": true
      },
      {
        "id": 1715,
        "content": [
          "Doubling the volume of a sample also doubles the mass; so the ratio of mass to volume remains the same."
        ],
        "isCorrect": false
      },
      {
        "id": 1716,
        "content": [
          "If water in two beakers at the same temperature are mixed to make a single quantity of water and the temperature of the combined quantity of water is the same as it was in the two separate beakers."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 430,
    "content": [
      "The point in a titration at which the number of moles of $$OH^-$$ ions added to a solution is equal to the number of moles of $$H^+$$ ions originally present is"
    ],
    "explanation": [
      "In a titration, the **equivalence point** is reached when the amount of titrant added (in this case, the base containing $$OH^-$$ ions) is stoichiometrically equivalent to the amount of substance being titrated (the acid containing $$H^+$$ ions).\n\nAt this point, the number of moles of $$OH^-$$ ions is equal to the number of moles of $$H^+$$ ions in the solution. This indicates that the acid has been completely neutralized by the base."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1717,
        "content": [
          "Zero point"
        ],
        "isCorrect": false
      },
      {
        "id": 1718,
        "content": [
          "End point"
        ],
        "isCorrect": false
      },
      {
        "id": 1719,
        "content": [
          "Triple point"
        ],
        "isCorrect": false
      },
      {
        "id": 1720,
        "content": [
          "Equivalence point"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 431,
    "content": [
      "Which one of the following is TRUE about the electrolysis of a molten hypothetical electrolyte, MX?"
    ],
    "explanation": [
      "Electrolysis involves the transfer of electrons, where oxidation occurs at the anode, and reduction occurs at the cathode. In this case, the electrolyte MX dissociates into M⁺ and X⁻ ions. At the cathode (negative electrode), M⁺ ions gain electrons (reduction), and at the anode (positive electrode), X⁻ ions lose electrons (oxidation)."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1721,
        "content": [
          "X is produced at the negative electrode."
        ],
        "isCorrect": false
      },
      {
        "id": 1722,
        "content": [
          "M is produced at the anode."
        ],
        "isCorrect": false
      },
      {
        "id": 1723,
        "content": [
          "Electrons are not transferred from one species to the other."
        ],
        "isCorrect": false
      },
      {
        "id": 1724,
        "content": [
          "The overall reaction is redox reaction."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 432,
    "content": [
      "During the extraction of an unknown metal, the metallic ore was fused with NaOH in air and then dissolved in water to obtain the soluble unknown metal containing species. Reduction with carbon is followed after the solution is treated with HCI. Finally the obtained oxide is reduced to its metallic form by aluminum. The most probable unknown metal would be"
    ],
    "explanation": [
      "The extraction process described involves several steps that are characteristic of chromium extraction.\n\nChromium ore (typically chromite, $$FeCr_2O_4$$) is fused with NaOH in the presence of air to form sodium chromate ($$Na_2CrO_4$$). This compound is soluble in water, allowing the chromium to be separated from other impurities.\n\nThe solution is then treated with HCl to convert sodium chromate to chromium(III) oxide ($$Cr_2O_3$$).\n\nFinally, the chromium(III) oxide is reduced to metallic chromium using aluminum in a process known as aluminothermic reduction."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1725,
        "content": [
          "Ca"
        ],
        "isCorrect": false
      },
      {
        "id": 1726,
        "content": [
          "Zn"
        ],
        "isCorrect": false
      },
      {
        "id": 1727,
        "content": [
          "Cr"
        ],
        "isCorrect": true
      },
      {
        "id": 1728,
        "content": [
          "Pb"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 433,
    "content": [
      "Why tin does NOT react with cold water but calcium reacts with cold water quite readily?"
    ],
    "explanation": [
      "Tin is less reactive compared to calcium, which is why it does not react with cold water, whereas calcium reacts quite readily."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1729,
        "content": [
          "Due to its less reactive nature."
        ],
        "isCorrect": true
      },
      {
        "id": 1730,
        "content": [
          "Due to the formation of a thin oxide layer."
        ],
        "isCorrect": false
      },
      {
        "id": 1731,
        "content": [
          "Due to its physical state."
        ],
        "isCorrect": false
      },
      {
        "id": 1732,
        "content": [
          "Due to the pH of water."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 434,
    "content": [
      "Why is vulcanization performed in natural rubber?"
    ],
    "explanation": [
      "Vulcanization is performed to introduce sulfur cross-links between polymer chains in natural rubber, which enhances its strength, elasticity, and durability."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_POLYMER",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1733,
        "content": [
          "To convert the monomer unit in natural rubber in to polymer."
        ],
        "isCorrect": false
      },
      {
        "id": 1734,
        "content": [
          "To establish cross-links between polymer chain in the natural rubber."
        ],
        "isCorrect": true
      },
      {
        "id": 1735,
        "content": [
          "To decrease the number of monomer unit in the natural rubber."
        ],
        "isCorrect": false
      },
      {
        "id": 1736,
        "content": [
          "To increase the number of monomer unit in the natural rubber."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Polymers"
  },
  {
    "id": 435,
    "content": [
      "Which one of the following explains the determination of the cell potential of Zn-Cu cell using voltmeter?"
    ],
    "explanation": [
      "Each U-tube served as a salt bridge that can be filled with saturated KCl. This setup allows ions to flow between the two half-cells, maintaining electrical neutrality and enabling the measurement of the cell potential using a voltmeter."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1737,
        "content": [
          "In the Cu half- cell, Cu metal will be dipped in ZnSO4 solution."
        ],
        "isCorrect": false
      },
      {
        "id": 1738,
        "content": [
          "In the Zn half- cell, Zn metal will be dipped in CuSO4 solution."
        ],
        "isCorrect": false
      },
      {
        "id": 1739,
        "content": [
          "Each U-tube served as a salt bridge that can be filled with saturated KCI."
        ],
        "isCorrect": true
      },
      {
        "id": 1740,
        "content": [
          "After the experiment the mass of zinc is increased."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Electrochemistry"
  },
  {
    "id": 436,
    "content": [
      "Which one of the following is an example of molecular crystals?"
    ],
    "explanation": [
      "Molecular crystals are composed of molecules held together by intermolecular forces such as Van der Waals forces, dipole-dipole interactions, or hydrogen bonds.\n\nSolid carbon dioxide (commonly known as dry ice) is a molecular crystal because it consists of $$CO_2$$ molecules that are held together by these types of intermolecular forces.\n\nIn contrast, diamond and magnesium are examples of covalent and metallic crystals, respectively, while sodium chloride is an ionic crystal."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1741,
        "content": [
          "Diamond"
        ],
        "isCorrect": false
      },
      {
        "id": 1742,
        "content": [
          "Sodium Chloride"
        ],
        "isCorrect": false
      },
      {
        "id": 1743,
        "content": [
          "Solid carbon dioxide"
        ],
        "isCorrect": true
      },
      {
        "id": 1744,
        "content": [
          "Magnesium"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 437,
    "content": [
      "Which one of the following COULD NOT be considered as factor influencing the rate of chemical reaction?"
    ],
    "explanation": [
      "The rate constant is a value specific to a particular reaction at a given temperature and is part of the rate law equation. It does not influence the rate of reaction itself; rather, it describes the relationship between the concentrations of reactants and the rate of reaction.\n\nIn contrast, the presence of a catalyst, the surface area of reactants, and the temperature of reactants are all factors that can significantly affect the rate of a chemical reaction."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1745,
        "content": [
          "Presence of catalyst"
        ],
        "isCorrect": false
      },
      {
        "id": 1746,
        "content": [
          "Surface area of reactants"
        ],
        "isCorrect": false
      },
      {
        "id": 1747,
        "content": [
          "The rate constant of the reaction"
        ],
        "isCorrect": true
      },
      {
        "id": 1748,
        "content": [
          "Temperature of reactants"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Chemical Kinetics"
  },
  {
    "id": 438,
    "content": [
      "Which one of the following shows the hybridization scheme of the central atom in $$H_2O$$?"
    ],
    "explanation": [
      "- In water, oxygen has two lone pairs of electrons and forms two sigma bonds with hydrogen atoms.\n- Oxygen's ground state electron configuration is $$1s^2 2s^2 2p^4$$, where two electrons in the 2p orbitals are unpaired and the other two are paired.\n- During $$sp^3$$ hybridization, one s orbital and three p orbitals combine to form four sp³ hybrid orbitals. Two of these orbitals will contain lone pairs of electrons, while the other two will contain single electrons to form bonds with hydrogen."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1749,
        "content": [
          "images/chemistry/year_2015/q38c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1750,
        "content": [
          "images/chemistry/year_2015/q38c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1751,
        "content": [
          "images/chemistry/year_2015/q38c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 1752,
        "content": [
          "images/chemistry/year_2015/q38c4_1.png"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 439,
    "content": [
      "In which of the following order of a reaction, a plot of $$ln [A]_t$$ versus time is a straight line whose slope is - k?"
    ],
    "explanation": [
      "For a first-order reaction, the integrated rate law is expressed as:\n\n$$\n\\ln [A]_t = -kt + \\ln [A]_0\n$$\n\nWhen plotting $$\\ln [A]_t$$ versus time (t), the equation takes the form of a straight line y = mx + b, where:\n\n- y is $$\\ln [A]_t$$,\n- m (the slope) is $$-k$$, and\n- b (the y-intercept) is $$\\ln [A]_0$$."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1753,
        "content": [
          "First"
        ],
        "isCorrect": true
      },
      {
        "id": 1754,
        "content": [
          "Zero"
        ],
        "isCorrect": false
      },
      {
        "id": 1755,
        "content": [
          "Third"
        ],
        "isCorrect": false
      },
      {
        "id": 1756,
        "content": [
          "Second"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 440,
    "content": [
      "A forward and reverse reaction continues to take place at equal rate in microscopic level without change in composition at macroscopic level. This statement is the definition of"
    ],
    "explanation": [
      "Dynamic equilibrium refers to the state in which the forward and reverse reactions occur at the same rate, leading to no net change in the concentrations of reactants and products at the macroscopic level. While the reactions continue to happen on a microscopic level, the overall system appears stable and unchanged over time."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1757,
        "content": [
          "Chemical kinetics"
        ],
        "isCorrect": false
      },
      {
        "id": 1758,
        "content": [
          "Dynamic equilibrium"
        ],
        "isCorrect": true
      },
      {
        "id": 1759,
        "content": [
          "Degree of freedom"
        ],
        "isCorrect": false
      },
      {
        "id": 1760,
        "content": [
          "The law of mass action"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 441,
    "content": [
      "The heat change at constant pressure that results when 1 mole of a compound is formed from its elements in their standard states is"
    ],
    "explanation": [
      "The standard enthalpy of formation is defined as the heat change that occurs at constant pressure when one mole of a compound is formed from its elements in their standard states.\n$$\n\\Delta H_f^\\circ = \\sum \\Delta H_f^\\circ (\\text{products}) - \\sum \\Delta H_f^\\circ (\\text{reactants})\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1761,
        "content": [
          "standard entropy of reaction"
        ],
        "isCorrect": false
      },
      {
        "id": 1762,
        "content": [
          "standard enthalpy of reaction"
        ],
        "isCorrect": false
      },
      {
        "id": 1763,
        "content": [
          "standard reduction potential"
        ],
        "isCorrect": false
      },
      {
        "id": 1764,
        "content": [
          "standard enthalpy of formation"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 442,
    "content": [
      "What is a redox reaction? It is a reaction in which"
    ],
    "explanation": [
      "A redox reaction involves the transfer of electrons between two chemical species. In these reactions, one species loses electrons (is oxidized), while the other gains electrons (is reduced)."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1765,
        "content": [
          "two insoluble ions in compounds form an insoluble products."
        ],
        "isCorrect": false
      },
      {
        "id": 1766,
        "content": [
          "electrons are transferred between species."
        ],
        "isCorrect": true
      },
      {
        "id": 1767,
        "content": [
          "atoms or ions of two compound exchange bonding partners."
        ],
        "isCorrect": false
      },
      {
        "id": 1768,
        "content": [
          "an acid and a base neutralize each other."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 443,
    "content": [
      "Which one of the following explains how electroplating takes place?"
    ],
    "explanation": [
      "In the electroplating process, the metal to be plated is used as the anode (positive terminal), and the metal on which electroplating takes place is made the cathode (negative terminal).\n\nThe electrolyte is a salt solution of the metal to be deposited. When an electric current is passed through the electrolyte, the metal ions in the electrolyte are reduced and deposited onto the cathode. The anode metal is oxidized, and its ions go into the solution."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1769,
        "content": [
          "The electrolyte is an aqueous solution of a salt of the plated metal."
        ],
        "isCorrect": true
      },
      {
        "id": 1770,
        "content": [
          "The object to be electroplated either metal or graphite-coated plastic constitutes the anode."
        ],
        "isCorrect": false
      },
      {
        "id": 1771,
        "content": [
          "The cations in the electrolyte are supplied either by the added salt or from oxidation of the anode."
        ],
        "isCorrect": false
      },
      {
        "id": 1772,
        "content": [
          "Metal is deposited on the anode by reduction of ions in the electrolyte solution."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 444,
    "content": [
      "How does the equivalent mass of a base is obtained?"
    ],
    "explanation": [
      "The equivalent mass of a base is defined as the mass of the base that can furnish one mole of hydroxide ions ($$OH^-$$) in a reaction. To calculate it, you take the molar mass of the base and divide it by the number of hydroxide ions produced per formula unit. This gives you the equivalent mass.\n$$\n\\text{Equivalent mass} = \\frac{\\text{Molar mass}}{\\text{Number of } OH^- \\text{ ions}}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1773,
        "content": [
          "By multiplying its molar mass by the number of $$OH^-$$ ions furnished by one formula unit of a base."
        ],
        "isCorrect": false
      },
      {
        "id": 1774,
        "content": [
          "By dividing its molar mass by the number of $$OH^-$$ ions furnished by one formula unit of a base."
        ],
        "isCorrect": true
      },
      {
        "id": 1775,
        "content": [
          "By multiplying its number of equivalent by the number of $$OH^-$$ ions furnished by one formula unit of a base."
        ],
        "isCorrect": false
      },
      {
        "id": 1776,
        "content": [
          "By dividing its number of equivalent by the number of $$OH^-$$ ions furnished by one formula unit of a base."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 445,
    "content": [
      "Which one of the following reactions would occur spontaneously in an aqueous solution at 25°C? Assume that the initial concentrations of the dissolved species are all 1.0M.",
      "images/chemistry/year_2015/q45_1.png"
    ],
    "explanation": [
      "A reaction is spontaneous if the cell potential is positive. The overall cell potential is given by:\n\n$$\nE°_{\\text{cell}} = E°_{\\text{cathode}} - E°_{\\text{anode}}\n$$\n\nOption: $$2Br^- (aq)$$ + $$Sn^{2+} (aq)$$ $$\\rightarrow$$ $$Br_2 (l)$$ + $$Sn (s)$$\n\n**Cathode**:\n$$\nBr_2 + 2e^- \\rightarrow 2Br^- (E° = -1.07 V)\n$$\nThe half-reaction is reversed thus we use −1.07 V.\n\n**Anode**:\n$$\nSn^{2+} + 2e^- \\rightarrow Sn \\quad (E° = -0.14 \\, \\text{V})\n$$\n\n$$\nE°_{\\text{cell}} = (-1.07) - (-0.14) = -0.93 \\, \\text{V} \\quad \\text{(Non-spontaneous)}\n$$\nOption: $$2Ag (s)$$ + $$Ni^{2+} (aq)$$ $$\\rightarrow$$ $$2Ag^+ (aq)$$ + $$Ni (s)$$\n\n**Cathode**:\n\n$$\nNi^{2+} + 2e^- \\rightarrow Ni \\quad (E° = -0.25 \\, \\text{V})\n$$\n**Anode**:\n\n$$\n2Ag \\rightarrow 2Ag^+ + 2e^- \\quad (E° = -1.6 \\, \\text{V})\n$$\nThe half-reaction is for 2 moles so we use (0.8 * 2) = −1.5 V.\n$$\nE°_{\\text{cell}} = (−0.25 V) - (−0.16 V) = −0.09 V \\, \\text{V} \\quad \\text{(Non-spontaneous)}\n$$\nOption: $$Ca (s)$$ + $$Cd^{2+} (aq)$$ $$\\rightarrow$$ $$Ca^{2+} (aq)$$ + $$Cd (s)$$\n\n**Anode**:\n\n$$\nCa \\rightarrow Ca^{2+} + 2e^- \\quad (E° = 2.87 \\, \\text{V})\n$$\nThe half-reaction is reversed thus we use 2.87 V.\n\n**Cathode**:\n$$\nCd^{2+} + 2e^- \\rightarrow Cd \\quad (E° = -0.40 \\, \\text{V})\n$$\n\n$$\nE°_{\\text{cell}} = (-0.40) - (-2.87) = - 3.27 V \\, \\text{V} \\quad \\text{(Non-spontaneous)}\n$$\nOption: $$Cu^{2+} (aq)$$ + $$Fe^{2+} (aq)$$ $$\\rightarrow$$ $$Cu^+ (aq)$$ + $$Fe^{3+} (aq)$$\n\n**Cathode**:\n\n$$\nCu+(E°=+0.15 V)Cu^{2+} + e^- \\rightarrow Cu^{+} \\quad (E° = +0.15 \\, \\text{V})\n$$\n\n**Anode**:\n$$\nFe^{2+} \\rightarrow Fe^{3+} + e^- \\quad (E° = -0.77 \\, \\text{V})\n$$\nThe half-reaction is reversed thus we use -0.77 V.\n\n$$\nE°_{\\text{cell}} = 0.15 - (-0.77) = +0.92 \\, \\text{V} \\quad \\text{(Spontaneous)}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2015/q45_1.png"
    ],
    "choices": [
      {
        "id": 1777,
        "content": [
          "$$2Br^- (aq)$$ + $$Sn^{2+} (aq)$$ $$\\rightarrow$$ $$Br_2 (l)$$ + $$Sn (s)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1778,
        "content": [
          "$$2Ag (s)$$ + $$Ni^{2+} (aq)$$ $$\\rightarrow$$ $$2Ag^+ (aq)$$ + $$Ni (s)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1779,
        "content": [
          "$$Ca (s)$$ + $$Cd^{2+} (aq)$$ $$\\rightarrow$$ $$Ca^{2+} (aq)$$ + $$Cd (s)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1780,
        "content": [
          "$$Cu^{2+} (aq)$$ + $$Fe^{2+} (aq)$$ $$\\rightarrow$$ $$Cu^+ (aq)$$ + $$Fe^{3+} (aq)$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 446,
    "content": [
      "Which of the following statements describes chemical industries? It is"
    ],
    "explanation": [
      "Industrial chemistry applies procedures to transform natural raw materials into beneficial products. This branch of chemistry bridges the gap between theoretical chemistry and its practical commercial application."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1781,
        "content": [
          "an area of chemistry concerned with the speeds, or rates, at which chemical reactions occur."
        ],
        "isCorrect": false
      },
      {
        "id": 1782,
        "content": [
          "the symbols of the atoms of the elements involved."
        ],
        "isCorrect": false
      },
      {
        "id": 1783,
        "content": [
          "an expression for the chemical composition of a compound in terms of a process in which dissolved solute comes out of solution and forms crystals."
        ],
        "isCorrect": false
      },
      {
        "id": 1784,
        "content": [
          "a firm that involves usage of raw material to produce desired products by using chemical reactions and refining methods."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 447,
    "content": [
      "What will be the product if phosphorus reacts with excess amount of oxygen?"
    ],
    "explanation": [
      "Phosphorus reacts with oxygen in two main ways, depending on the amount of oxygen present:\n- **Limited oxygen:** Forms tetraphosphorus hexoxide ($$P_4O_6$$)\n- **Excess oxygen:** Forms tetraphosphorus decoxide ( $$P_4O_{10}$$)"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1785,
        "content": [
          "$$H_3PO_3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1786,
        "content": [
          "$$H_3PO_4$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1787,
        "content": [
          "$$P_4O_{10}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1788,
        "content": [
          "$$P_4O_6$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Acid Base Equilibria"
  },
  {
    "id": 448,
    "content": [
      "One of the basic differences between metallic conduction and electrolytic conduction is:"
    ],
    "explanation": [
      "- **Metallic Conduction**: This type of conduction involves the flow of delocalized electrons within a lattice of positively charged metal ions. These electrons are free to move throughout the metallic structure, allowing for the easy flow of electrical current.\n- **Electrolytic Conduction**: This type of conduction occurs in electrolytes, which are substances that conduct electricity when dissolved in water or molten. In electrolytic conduction, the movement of ions (both cations and anions) carries the electric charge. When an electric potential is applied, the positively charged cations move towards the cathode (negative electrode), while the negatively charged anions move towards the anode (positive electrode)."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_METALS_NONMETALS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1789,
        "content": [
          "The conduction of electricity is due to the movement of ions in an electrolytic conduction while the flow of mobile electrons in metallic conduction."
        ],
        "isCorrect": true
      },
      {
        "id": 1790,
        "content": [
          "The charge carriers in metals are cations and anions while mobile electrons are in electrolytic conduction."
        ],
        "isCorrect": false
      },
      {
        "id": 1791,
        "content": [
          "The charge carriers in metals are localized electrons while strongly held ions are in electrolytic conduction."
        ],
        "isCorrect": false
      },
      {
        "id": 1792,
        "content": [
          "The conduction of electricity is due to the movement of ions in metallic conduction while the flow of mobile electrons in electrolytic conduction."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Metals and Non Metals"
  },
  {
    "id": 449,
    "content": [
      "Which one of the following gases is released from combustion of a fuel in an industrial machinery causing global warming?"
    ],
    "explanation": [
      "The combustion of fossil fuels in industrial machinery primarily releases carbon dioxide ($$CO_2$$) into the atmosphere."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1793,
        "content": [
          "$$CO$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1794,
        "content": [
          "$$CO_2$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1795,
        "content": [
          "$$NO$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1796,
        "content": [
          "$$SO_2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 450,
    "content": [
      "The number of digits to the right of the decimal point denotes:"
    ],
    "explanation": [
      "The number of digits to the right of the decimal point indicates the decimal places in a number.\n\nSignificant figures represent the precision of a measurement and include all certain digits plus one uncertain digit.\n\nConversion factors are used to convert between different units of measurement, such as converting meters to kilometers.\n\nScientific notation is a way to express very large or small numbers using powers of ten."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1797,
        "content": [
          "Significant figures"
        ],
        "isCorrect": false
      },
      {
        "id": 1798,
        "content": [
          "Decimal places"
        ],
        "isCorrect": true
      },
      {
        "id": 1799,
        "content": [
          "Conversion factor"
        ],
        "isCorrect": false
      },
      {
        "id": 1800,
        "content": [
          "Scientific notation"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 451,
    "content": [
      "Which of the following would occur during the formation of ions?"
    ],
    "explanation": [
      "Ion formation involves the gain or loss of electrons to achieve a stable electron configuration, often resembling that of a noble gas.\n\nIonic bonds are formed by the transfer of valence electrons from one atom to another, typically from a metal to a non-metal. This results in the formation of ions: positively charged cations and negatively charged anions."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1801,
        "content": [
          "Inner most shell electrons are involved."
        ],
        "isCorrect": false
      },
      {
        "id": 1802,
        "content": [
          "Valence electrons are shared between atoms."
        ],
        "isCorrect": false
      },
      {
        "id": 1803,
        "content": [
          "The electronic configuration of an atom forming the ion remains unaffected."
        ],
        "isCorrect": false
      },
      {
        "id": 1804,
        "content": [
          "Valence electrons are transferred from one atom to another."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 452,
    "content": [
      "In order to illustrate the structure and properties of a solid, a student put hundred marble balls in to a box that representing metal cations and the empty space between and around the marble representing the electron sea. Which one of the following bonding is represented by this model?"
    ],
    "explanation": [
      "The student's model uses marbles to represent metal cations and the empty space to depict the \"electron sea.\" This directly corresponds to the electron-sea model of metallic bonding.\n\nMetallic bonding involves the sharing of free or delocalized electrons among a lattice of positively charged metal ions. This creates a \"sea\" of electrons that are mobile throughout the structure, explaining properties like electrical conductivity."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1805,
        "content": [
          "Covalent bonding"
        ],
        "isCorrect": false
      },
      {
        "id": 1806,
        "content": [
          "Ionic bonding"
        ],
        "isCorrect": false
      },
      {
        "id": 1807,
        "content": [
          "Metallic bonding"
        ],
        "isCorrect": true
      },
      {
        "id": 1808,
        "content": [
          "Dative bonding"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 453,
    "content": [
      "Which one of the following explains dipole-dipole force?"
    ],
    "explanation": [
      "Dipole-dipole forces are attractive forces that occur between polar molecules.\n\nA polar molecule has a permanent dipole, meaning it has a partially positive end and a partially negative end due to an uneven distribution of electrons within the molecule.\n\nDipole-dipole forces are stronger than London dispersion forces but weaker than ion-ion interactions because only partial charges are involved."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1809,
        "content": [
          "A type of intermolecular force that exists between non-polar molecules."
        ],
        "isCorrect": false
      },
      {
        "id": 1810,
        "content": [
          "The intermolecular attraction between oppositely charged poles of nearby polar molecules."
        ],
        "isCorrect": true
      },
      {
        "id": 1811,
        "content": [
          "An attractive force resulting from temporary dipoles induced in molecules."
        ],
        "isCorrect": false
      },
      {
        "id": 1812,
        "content": [
          "An electrostatic attraction between metal ions and valence electrons."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 454,
    "content": [
      "Which one of the following reactions creates energy in our bodies during respiration?"
    ],
    "explanation": [
      "$$\nC_6H_{12}O_6 (s) + 6O_2 (g) \\rightarrow 6CO_2 (g) + 6H_2O (l)\n$$\nThis equation represents the process of cellular respiration, where glucose is broken down in the presence of oxygen to produce carbon dioxide, water and energy in the form of ATP. This reaction is exothermic, meaning it releases energy."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1813,
        "content": [
          "$$C_6H_{12}O_6 (s)$$ + $$6O_2 (g)$$ $$\\rightarrow$$ $$6CO_2 (g)$$ + $$6H_2O (l)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1814,
        "content": [
          "$$6CO_2 (g)$$ + $$6H_2O (l)$$ $$\\rightarrow$$  $$C_6H_{12}O_6 (s)$$ + $$6O2 (g)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1815,
        "content": [
          "$$C_6H_{12}O_6 (s)$$ $$\\rightarrow$$ $$2C_2H_5OH (l)$$ + $$2CO_2 (g)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1816,
        "content": [
          "$$N_2H_4CO (g)$$ + $$H_2O (g)$$ $$\\rightarrow$$ $$2NH_3 (l)$$ + $$CO_2 (g)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 455,
    "content": [
      "\"A reaction that involves the exchange of positive and negative ions of each reactant\". This is a definition of a"
    ],
    "explanation": [
      "A double displacement reaction is defined as a reaction in which two compounds react to form two new compounds by exchanging the positive and negative ions of each reactant.\n\nDecomposition reaction: This involves the breakdown of a single compound into two or more elements or simpler compounds.\n\nCombination reaction: This involves two or more substances combining to form a single product.\n\nSingle displacement reaction: In this reaction, a more reactive element displaces a less reactive element from a compound."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1817,
        "content": [
          "Decomposition reaction"
        ],
        "isCorrect": false
      },
      {
        "id": 1818,
        "content": [
          "Combination reaction"
        ],
        "isCorrect": false
      },
      {
        "id": 1819,
        "content": [
          "Double displacement reaction"
        ],
        "isCorrect": true
      },
      {
        "id": 1820,
        "content": [
          "Single displacement reaction"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 456,
    "content": [
      "What are the four quantum numbers for an electron in a 2s orbital?"
    ],
    "explanation": [
      "The four quantum numbers and their values for an electron in a 2s orbital are:\n\n- **Principal quantum number (n):** This number represents the electron's energy level. For a 2s orbital, n = **2**.\n- **Angular momentum quantum number (ℓ):** This number indicates the shape of the orbital and has values ranging from 0 to n-1. For n = 2, the possible values of ℓ are 0 and 1. ℓ = 0 corresponds to an s orbital, and ℓ = 1 corresponds to a p orbital. Therefore, for a 2s orbital, ℓ = 0.\n- **Magnetic quantum number (mℓ):** This number describes the orbital's orientation in space. It can take on integer values from -ℓ to +ℓ, including 0. Since ℓ = 0 for a 2s orbital, the only possible value for mℓ is **0**.\n- **Spin quantum number (ms):** This number designates the electron's intrinsic spin. It can have two possible values: **+½** or -½. The problem specifies the electron has a spin of +½."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1821,
        "content": [
          "$$2$$, $$1$$, $$0$$, $$+\\frac{1}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1822,
        "content": [
          "$$2$$, $$1$$, $$1$$, $$+\\frac{1}{2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1823,
        "content": [
          "$$2$$, $$0$$, $$0$$, $$+\\frac{1}{2}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1824,
        "content": [
          "$$2$$, $$0$$, $$1$$, $$+\\frac{1}{2}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 457,
    "content": [
      "A student uses a digital balance (±0.02), a thermometer (±0.1), a measuring cylinder (+0.05), and a beaker (±0.5) during an experiment. Which of the above instrument is more precise?"
    ],
    "explanation": [
      "The **digital balance (±0.02)** is the most precise instrument among the given options.\n\n- **Precision** refers to the closeness of multiple measurements to each other. In simpler terms, a precise instrument will give very similar readings if you measure the same thing multiple times.\n- **Uncertainty** in a measurement indicates the range within which the true value likely lies. A lower uncertainty value means the instrument is more precise."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1825,
        "content": [
          "The thermometer"
        ],
        "isCorrect": false
      },
      {
        "id": 1826,
        "content": [
          "The digital balance"
        ],
        "isCorrect": true
      },
      {
        "id": 1827,
        "content": [
          "The Beaker"
        ],
        "isCorrect": false
      },
      {
        "id": 1828,
        "content": [
          "The measuring cylinder"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 458,
    "content": [
      "Which one of the following explains that light has BOTH wave and particle nature?"
    ],
    "explanation": [
      "Electromagnetic radiation (EMR) can be understood as a stream of particles called photons.\n\nEach photon carries energy (E) that is directly proportional to its frequency (ν), represented by the equation E = hν, where h is Planck's constant. This concept of quantized energy packets demonstrates the particle-like nature of light."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1829,
        "content": [
          "A beam of light is a stream of particles of electromagnetic energy, with energy proportional to the observed frequency of the light."
        ],
        "isCorrect": true
      },
      {
        "id": 1830,
        "content": [
          "An electron that is bound to the nucleus behaves like a standing wave and its position is given in terms of probability."
        ],
        "isCorrect": false
      },
      {
        "id": 1831,
        "content": [
          "Microscopic systems, such as atoms and molecules can possess wave properties."
        ],
        "isCorrect": false
      },
      {
        "id": 1832,
        "content": [
          "Light consists of electromagnetic waves which have an oscillating electric and magnetic disturbance that spreads electromagnetic radiation."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 459,
    "content": [
      "A nuclear breakdown in which particles or electromagnetic radiation is emitted is _____________."
    ],
    "explanation": [
      "Radioactive decay is defined as the spontaneous emission of particles and/or radiation from the unstable nuclei of certain atoms."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1833,
        "content": [
          "Radioactive isotopes"
        ],
        "isCorrect": false
      },
      {
        "id": 1834,
        "content": [
          "Radioactivity"
        ],
        "isCorrect": false
      },
      {
        "id": 1835,
        "content": [
          "Radio wave"
        ],
        "isCorrect": false
      },
      {
        "id": 1836,
        "content": [
          "Radioactive decay"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 460,
    "content": [
      "Which statement describes valence shell electron pair repulsion (VSEPR) theory?"
    ],
    "explanation": [
      "VSEPR Theory centers around the idea that electron pairs in the valence shell (outermost shell) of an atom will repel each other. This repulsion influences the shape of the molecule.\n\nIn VSEPR, the electron pairs, whether bonding pairs (involved in a bond) or lone pairs (not involved in a bond), will position themselves to maximize the distance between them, minimizing repulsion and leading to a stable molecular geometry."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1837,
        "content": [
          "Each degenerate orbitals are occupied by a single electron before the second electrons of opposite spin enters the orbitals."
        ],
        "isCorrect": false
      },
      {
        "id": 1838,
        "content": [
          "Electron pairs will be as far apart from each other in three dimensional spaces as possible."
        ],
        "isCorrect": true
      },
      {
        "id": 1839,
        "content": [
          "Atomic orbitals are capable of combining to produce new electron distribution."
        ],
        "isCorrect": false
      },
      {
        "id": 1840,
        "content": [
          "A covalent bond is formed when orbitals of two atoms overlap and the overlap region is occupied by a pair of electrons."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 461,
    "content": [
      "Which one of the following is a colorless, flammable volatile liquid and miscible with non-polar solvents?"
    ],
    "explanation": [
      "Benzene ($$C_6H_6$$) is a colorless liquid at room temperature. It is highly flammable, burning with a smoky flame. Benzene is volatile. Benzene is nonpolar and dissolves in nonpolar solvents like carbon tetrachloride and ether."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1841,
        "content": [
          "Benzene"
        ],
        "isCorrect": true
      },
      {
        "id": 1842,
        "content": [
          "Ethanol"
        ],
        "isCorrect": false
      },
      {
        "id": 1843,
        "content": [
          "Methanol"
        ],
        "isCorrect": false
      },
      {
        "id": 1844,
        "content": [
          "Methane"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 462,
    "content": [
      "The IUPAC name of the compound with the following structure is:",
      "images/chemistry/year_2015/q62_1.png"
    ],
    "explanation": [
      "First Identify the longest continuous chain of carbon atoms. In this structure, the longest chain is a six-carbon chain (hexane).\n- Next, number the chain from the end that gives the substituents the lowest possible numbers. In this case, numbering from the left gives the lowest possible locants.\n- The structure has three methyl groups (CH₃) attached to the main chain.\n    - One methyl group is attached to carbon - 2.\n    - Another methyl group is attached to carbon 3.\n    - The third methyl group is attached to carbon 4.\n- Since the longest chain is hexane and there are three methyl groups at positions 2, 3, and 4, the correct IUPAC name for this compound is **2, 3, 4-trimethylhexane**."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2015/q62_1.png"
    ],
    "choices": [
      {
        "id": 1845,
        "content": [
          "3, 4, 5-Trimethylhexane"
        ],
        "isCorrect": false
      },
      {
        "id": 1846,
        "content": [
          "2-Ethyl-3, 4-dimethylpentane"
        ],
        "isCorrect": false
      },
      {
        "id": 1847,
        "content": [
          "4-Ethyl-2, 3-dimethylpentane"
        ],
        "isCorrect": false
      },
      {
        "id": 1848,
        "content": [
          "2, 3, 4-Trimethylhexane"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 6,
    "unitName": "Hydrocarbons and Their Natural Sources"
  },
  {
    "id": 463,
    "content": [
      "Which one of the following petroleum products is used as a solvent and in dry cleaning?"
    ],
    "explanation": [
      "Petroleum ether is used as a solvent in dry cleaning. Dry cleaning uses chemicals that can dissolve grease and stains without using water."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1849,
        "content": [
          "Kerosene"
        ],
        "isCorrect": false
      },
      {
        "id": 1850,
        "content": [
          "Paraffin wax"
        ],
        "isCorrect": false
      },
      {
        "id": 1851,
        "content": [
          "Petroleum ether"
        ],
        "isCorrect": true
      },
      {
        "id": 1852,
        "content": [
          "Diesel oil"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 464,
    "content": [
      "Which one of the following is NOT TRUE about laboratory preparation of ethylene by dehydration of ethanol?"
    ],
    "explanation": [
      "- Ethylene decolorizes bromine water. This is because the bromine atoms add across the double bond in ethylene, forming a colorless dibromoethane.\n- Concentrated sulfuric acid is used as a dehydrating agent in the laboratory preparation of ethene.\n- Ethylene also decolorizes alkaline potassium permanganate (KMnO4). This is because the potassium permanganate oxidizes the ethylene, breaking the double bond and forming a colorless diol.\n- Combustion of ethylene actually produces a luminous flame. This is because the combustion of ethylene is incomplete, producing soot particles that make the flame luminous."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1853,
        "content": [
          "The collected ethylene gas in the experiment decolorizes $$Br_2$$ in $$CCI_4$$."
        ],
        "isCorrect": false
      },
      {
        "id": 1854,
        "content": [
          "Concentrated sulphuric acid is used as a dehydrating agent."
        ],
        "isCorrect": false
      },
      {
        "id": 1855,
        "content": [
          "Combustion of ethylene produces a non-luminous flame."
        ],
        "isCorrect": true
      },
      {
        "id": 1856,
        "content": [
          "The collected ethylene gas in the experiment decolorizes alkaline $$KMnO_4$$."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 6,
    "unitName": "Hydrocarbons and Their Natural Sources"
  },
  {
    "id": 465,
    "content": [
      "Which one of the following is an essential nutrient of plants?"
    ],
    "explanation": [
      "Potassium is mentioned as one of the primary mineral nutrients, alongside nitrogen and phosphorus. It plays several vital roles in plant growth."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_METALS_NONMETALS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1857,
        "content": [
          "Aluminum"
        ],
        "isCorrect": false
      },
      {
        "id": 1858,
        "content": [
          "Lead"
        ],
        "isCorrect": false
      },
      {
        "id": 1859,
        "content": [
          "Sodium"
        ],
        "isCorrect": false
      },
      {
        "id": 1860,
        "content": [
          "Potassium"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Metals and Non Metals"
  },
  {
    "id": 466,
    "content": [
      "Which one of the following is the main reason for the large difference in dipole-moment between the triatomic molecules water ($$H_2O$$) and carbon dioxide ($$CO_2$$)?"
    ],
    "explanation": [
      "In water ($$H_2O$$), the molecule is bent (with a bond angle of about 104.5°), and the lone pairs of electrons on oxygen contribute to the overall dipole moment by reinforcing the polar nature of the O-H bonds. This results in a significant net dipole moment.\n\nOn the other hand, in carbon dioxide ($$CO_2$$), the molecule is linear, with the two polar C=O bonds pointing in opposite directions. As a result, the bond dipoles cancel each other out, leading to a net dipole moment of zero despite the polarity of individual bonds."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1861,
        "content": [
          "The presence of lone pairs of electrons in water ($$H_2O$$) partially reinforces bond polarities."
        ],
        "isCorrect": true
      },
      {
        "id": 1862,
        "content": [
          "The higher electronegativity difference among atoms in water ($$H_2O$$) than in carbon dioxide ($$CO_2$$)."
        ],
        "isCorrect": false
      },
      {
        "id": 1863,
        "content": [
          "The presence of multiple bonds in carbon dioxide ($$CO_2$$) while single bonds in water."
        ],
        "isCorrect": false
      },
      {
        "id": 1864,
        "content": [
          "The bonds in carbon dioxide ($$CO_2$$) are directed 180° and bond polarity reinforces each other."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 467,
    "content": [
      "How many non-bonding pairs of electrons are present in the valence shell of the central atom in $$CIF_3$$?"
    ],
    "explanation": [
      "The central atom in $$ClF_3$$ is chlorine. Chlorine has 7 valence electrons, and it forms three bonds with three fluorine atoms.\n\nTo determine the number of non-bonding pairs (lone pairs) on chlorine:\n\n- Chlorine has 7 valence electrons.\n- Each bond with fluorine uses 1 electron, so 3 electrons are used for bonding.\n- This leaves 7 - 3 = 4 electrons on chlorine, which form 2 lone pairs.\n\nTherefore, the number of non-bonding electron pairs on chlorine in $$ClF_3$$ is 2."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1865,
        "content": [
          "1"
        ],
        "isCorrect": false
      },
      {
        "id": 1866,
        "content": [
          "0"
        ],
        "isCorrect": false
      },
      {
        "id": 1867,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 1868,
        "content": [
          "2"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 468,
    "content": [
      "Which one would be observed in a laboratory activity that is applied on naphthalene?"
    ],
    "explanation": [
      "Naphthalene is a non-polar organic compound. Benzene, being a non-polar solvent, can dissolve non-polar solutes like naphthalene due to the \"like dissolves like\" principle. Hence, naphthalene is soluble in benzene."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1869,
        "content": [
          "It is soluble in benzene."
        ],
        "isCorrect": true
      },
      {
        "id": 1870,
        "content": [
          "It conducts electricity in molten state."
        ],
        "isCorrect": false
      },
      {
        "id": 1871,
        "content": [
          "It shows relatively high melting point."
        ],
        "isCorrect": false
      },
      {
        "id": 1872,
        "content": [
          "It is soluble in water."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 6,
    "unitName": "Hydrocarbons and Their Natural Sources"
  },
  {
    "id": 469,
    "content": [
      "Which one of the following statements is CORRECT?"
    ],
    "explanation": [
      "Valence Bond (VB) theory, unlike the Lewis model, goes beyond simply showing electron pairs and linkages. It explains molecular shapes by considering how atomic orbitals interact and overlap when forming bonds.\n\nFor instance, VB theory explains the tetrahedral shape of methane ($$CH_4$$) by the hybridization of carbon's atomic orbitals into four equivalent $$sp^3$$ orbitals."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1873,
        "content": [
          "Valence bond model simply shows the linkage between atoms and the presence of lone pairs."
        ],
        "isCorrect": false
      },
      {
        "id": 1874,
        "content": [
          "Lewis model predicts the shapes of molecules based on electron-pair repulsions around a central atom."
        ],
        "isCorrect": false
      },
      {
        "id": 1875,
        "content": [
          "In Lewis model, electrons repel one another and a pair of bonding electrons lies far apart as possible."
        ],
        "isCorrect": false
      },
      {
        "id": 1876,
        "content": [
          "Valence bond model explain molecular shape from the interaction of atomic orbitals."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 470,
    "content": [
      "The energy required to completely separate one mole of a solid ionic compound into gaseous ions is a/an"
    ],
    "explanation": [
      "Lattice energy (U) is defined as the enthalpy change that occurs when one mole of an ionic solid separates into gaseous ions. It's a measure of the strength of the electrostatic attraction between ions in the crystal lattice.\n\nThe existence of ionic solids is primarily due to the lattice energy exceeding the energy required for electron transfer during compound formation. In simpler terms, the energy released when ions come together to form a solid is greater than the energy needed to create those ions in the first place."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1877,
        "content": [
          "Ionization energy"
        ],
        "isCorrect": false
      },
      {
        "id": 1878,
        "content": [
          "Activation energy"
        ],
        "isCorrect": false
      },
      {
        "id": 1879,
        "content": [
          "Lattice energy"
        ],
        "isCorrect": true
      },
      {
        "id": 1880,
        "content": [
          "Bond energy"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 471,
    "content": [
      "Which of the following compounds reacts with basic oxide to form salt and water?"
    ],
    "explanation": [
      "A **basic oxide** reacts with an **acid** in a neutralization reaction to produce a **salt** and **water**. This is because basic oxides are typically metal oxides that can neutralize acids, leading to the formation of a salt and water."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1881,
        "content": [
          "Acid"
        ],
        "isCorrect": true
      },
      {
        "id": 1882,
        "content": [
          "Acidic oxide"
        ],
        "isCorrect": false
      },
      {
        "id": 1883,
        "content": [
          "Base"
        ],
        "isCorrect": false
      },
      {
        "id": 1884,
        "content": [
          "Neutral oxide"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 472,
    "content": [
      "Which one of the following reaction represents formation of an acid from its salt?"
    ],
    "explanation": [
      "$$\nNaNO_3 (s) + H_2SO_4 (l) \\rightarrow NaHSO_4 (s) + HNO_3 (l)\n$$\n\nThis reaction shows the formation of nitric acid ($$HNO_3$$) from sodium nitrate ($$NaNO_3$$), which is its salt."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1885,
        "content": [
          "$$CH_3COOH (aq)$$ + $$CH_3OH (aq)$$ $$\\rightarrow$$ $$CH_3CO_2CH_3 (aq)$$ + $$H_2O (l)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1886,
        "content": [
          "$$P_2O_5 (s)$$ + $$6NaOH (aq)$$ $$\\rightarrow$$ $$2Na_3PO_4 (s)$$ + $$3H_20 (l)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1887,
        "content": [
          "$$NaNO_3 (s)$$ + $$H_2SO_4 (l)$$ $$\\rightarrow$$ $$NaHSO_4 (s)$$ + $$HNO_3 (l)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1888,
        "content": [
          "$$AgNO_3 (aq)$$ + $$NaCl (aq)$$ $$\\rightarrow$$ $$NaNO_3 (aq)$$ + $$AgCl (s)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 473,
    "content": [
      "The negative logarithm of the molar concentration of hydrogen ion to the base ten is known as _____________."
    ],
    "explanation": [
      "The pH of a solution is defined as the negative logarithm of the molar concentration of hydrogen ions. Here is the equation:\n$$\npH = - log[H^+]\n$$\nThe pH scale ranges from 0 to 14, with a pH of 7 being neutral. Solutions with a pH less than 7 are considered **acidic**, and those with a pH greater than 7 are considered **basic**."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1889,
        "content": [
          "$$pH$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1890,
        "content": [
          "$$K_a$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1891,
        "content": [
          "$$pOН$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1892,
        "content": [
          "$$K_w$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 474,
    "content": [
      "Which one of the following galvanic cell is an example of secondary cell?"
    ],
    "explanation": [
      "- Primary cells are galvanic cells that are not rechargeable. Examples of primary cells include Daniell’s cell and zinc-carbon (Leclanche) dry cells.\n- Unlike primary cells, secondary cells are rechargeable. This means the electrode reactions can be reversed, and the original reactants can be regenerated. This is done by passing a direct current through the cell, a process called charging or recharging.\n- A lead storage battery is an example of a secondary cell."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1893,
        "content": [
          "Leclanche dry cell"
        ],
        "isCorrect": false
      },
      {
        "id": 1894,
        "content": [
          "Zinc-carbon dry cell"
        ],
        "isCorrect": false
      },
      {
        "id": 1895,
        "content": [
          "Daniel's cell"
        ],
        "isCorrect": false
      },
      {
        "id": 1896,
        "content": [
          "Lead storage cell"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 475,
    "content": [
      "Which one of the following is responsible for electrolytic conductivity?"
    ],
    "explanation": [
      "Electrolytic conductivity refers to the ability of a substance to conduct electricity when it's in a molten state or dissolved in a solution. This conductivity arises from the movement of ions towards electrodes with opposite charges."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1897,
        "content": [
          "Ions strongly held in a fixed position."
        ],
        "isCorrect": false
      },
      {
        "id": 1898,
        "content": [
          "Free electrons."
        ],
        "isCorrect": false
      },
      {
        "id": 1899,
        "content": [
          "Electrons held in a fixed position."
        ],
        "isCorrect": false
      },
      {
        "id": 1900,
        "content": [
          "Movement of ions."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 476,
    "content": [
      "Which one of the following statement is TRUE about gases?"
    ],
    "explanation": [
      "Gases do not have a fixed shape or volume. They take the shape and volume of their container. Liquids, on the other hand, have a fixed volume but no fixed shape, meaning they take the shape of their container. Solids have a fixed shape and volume."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1901,
        "content": [
          "The particles of gases are closely packed together."
        ],
        "isCorrect": false
      },
      {
        "id": 1902,
        "content": [
          "The volume of a gas is kept constant as pressure increases."
        ],
        "isCorrect": false
      },
      {
        "id": 1903,
        "content": [
          "When a gas sample is heated at constant pressure, its volume decreases."
        ],
        "isCorrect": false
      },
      {
        "id": 1904,
        "content": [
          "The volume of a gas is equal to the volume of its container."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 477,
    "content": [
      "Which one of the following mathematical expressions is derived from the combination of Boyle's law, Charles' law and Avogadro's law?"
    ],
    "explanation": [
      "$$\nV \\ \\alpha \\ \\frac{nT}{P}\n$$\n\nThis expression is derived from the combination of Boyle's law, Charles' law, and Avogadro's law, which together form the ideal gas law:\n\n$$\nPV = nRT\n$$\n\nFrom this, you can solve for V:\n\n$$\nV = \\frac{nRT}{P}\n$$"
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1905,
        "content": [
          "$$V \\ \\alpha \\ \\frac{nT}{P}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1906,
        "content": [
          "$$V \\ \\alpha \\ \\frac{T}{nP}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1907,
        "content": [
          "$$V \\ \\alpha \\ \\frac{nP}{T}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1908,
        "content": [
          "$$V \\ \\alpha \\ \\frac{P}{nT}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 478,
    "content": [
      "180 g of calcium carbonate ($$CaCO_3$$) is allowed to react with 156 gram of hydrochloric acid ($$HCI$$), according to the following reaction. Which of the following substances is the limiting reagent? (Atomic masses; Ca = 40, CI = 35.5, O = 16, C = 12, H = 1)\n$$\nCaCO_3 + 2HCI \\rightarrow CaCl_2 + CO_2 + H_2O\n$$"
    ],
    "explanation": [
      "To determine the limiting reagent, we need to compare the moles of each reactant. The formula for calculating moles is:\n$$\nn=\\frac{m}{M}\n$$\n\n**Moles of $$CaCO_3$$:**\n\n- $$M_{CaCO_3} = 40 + 12 + (16 \\times 3) = 100 \\, \\text{g/mol}$$\n- $$n_{CaCO_3} = \\frac{180}{100} = 1.8 \\, \\text{mol}$$\n\n**Moles of $$HCl$$:**\n\n- $$M_{HCl} = 1 + 35.5 = 36.5 \\, \\text{g/mol}$$\n- $$n_{HCl} = \\frac{156}{36.5} \\approx 4.27 \\, \\text{mol}$$\n\nFrom the balanced equation, 1 mole of $$CaCO_3$$ reacts with 2 moles of $$HCl$$.\n\nFor 1.8 moles of $$CaCO_3$$, the required moles of $$HCl$$ are:\n$$\nn_{HCl, \\, \\text{required}} = 1.8 \\times 2 = 3.6 \\, \\text{mol}\n$$\n\nSince we have 4.27 moles of $$HCl$$ available and only 3.6 moles are needed, $$HCl$$ is in excess, and $$CaCO_3$$ is the limiting reagent."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1909,
        "content": [
          "$$HCI$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1910,
        "content": [
          "$$CaCO_3$$"
        ],
        "isCorrect": true
      },
      {
        "id": 1911,
        "content": [
          "$$H_2O$$"
        ],
        "isCorrect": false
      },
      {
        "id": 1912,
        "content": [
          "$$CO_2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 479,
    "content": [
      "Which one of the following isomers differs in the arrangement of carbon atoms in the longest continuous carbon chain?"
    ],
    "explanation": [
      "Structural isomers differ in the connectivity or arrangement of their atoms, which includes the longest continuous carbon chain. In this case, structural isomers can have different carbon skeletons, leading to variations in the longest carbon chain."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1913,
        "content": [
          "Geometric"
        ],
        "isCorrect": false
      },
      {
        "id": 1914,
        "content": [
          "Position"
        ],
        "isCorrect": false
      },
      {
        "id": 1915,
        "content": [
          "Cis-trans"
        ],
        "isCorrect": false
      },
      {
        "id": 1916,
        "content": [
          "Structural"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 6,
    "unitName": "Hydrocarbons and Their Natural Sources"
  },
  {
    "id": 480,
    "content": [
      "Which one of the following methods can be used in the laboratory for the preparation of alkynes?"
    ],
    "explanation": [
      "Alkynes can be prepared by dehydrohalogenation of vicinal (adjacent) dihalides with a base such as $$NaOH$$, $$KOH$$, or $$NaNH_2$$. Dehydrohalogenation is the removal of a hydrogen atom and a halogen atom from a molecule. For example, the reaction of 1,2-dibromoethane with KOH yields ethyne."
    ],
    "year": "YEAR_2015",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 1917,
        "content": [
          "Dehydration of alcohols with concentrated sulphuric acid."
        ],
        "isCorrect": false
      },
      {
        "id": 1918,
        "content": [
          "Heating of sodium salt of an organic acid with soda lime."
        ],
        "isCorrect": false
      },
      {
        "id": 1919,
        "content": [
          "Dehydrohalogenation of adjacent dihalides with sodium hydroxide."
        ],
        "isCorrect": true
      },
      {
        "id": 1920,
        "content": [
          "Hydrogenation of alkenes with a metal catalyst."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 6,
    "unitName": "Hydrocarbons and Their Natural Sources"
  },
  {
    "id": 726,
    "content": [
      "What is the significance of electron probability distribution? It tells us about"
    ],
    "explanation": [
      "The exact position and momentum of an electron cannot be simultaneously known with precision.\n\nInstead, we use probability distributions to describe the likelihood of finding an electron in a particular region around the nucleus. This distribution reflects the inherent uncertainty and wave-like nature of electrons, making it impossible to assign them fixed paths or orbits."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2903,
        "content": [
          "the probability of finding an electron is very far away from the nucleus."
        ],
        "isCorrect": false
      },
      {
        "id": 2904,
        "content": [
          "finding the electron very close to the nucleus at all times."
        ],
        "isCorrect": false
      },
      {
        "id": 2905,
        "content": [
          "finding the electron in its orbit at a particular time."
        ],
        "isCorrect": false
      },
      {
        "id": 2906,
        "content": [
          "the uncertainty to assign fixed path for electrons."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 727,
    "content": [
      "Which group in the periodic table contains elements with the valence electron configuration of $$ns^2np^1$$?"
    ],
    "explanation": [
      "Elements with the valence electron configuration of $$ns^2np^1$$ are found in **Group 13 (III)** of the periodic table.\n\nThis group includes elements like boron, aluminum, and gallium. These elements have three valence electrons, with two in the s orbital and one in the p orbital, corresponding to the $$ns^2np^1$$ configuration."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2907,
        "content": [
          "IV"
        ],
        "isCorrect": false
      },
      {
        "id": 2908,
        "content": [
          "II"
        ],
        "isCorrect": false
      },
      {
        "id": 2909,
        "content": [
          "I"
        ],
        "isCorrect": false
      },
      {
        "id": 2910,
        "content": [
          "III"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 728,
    "content": [
      "Which of the following is a correct Lewis structure for diazomethane ($$CH_2N_2$$)?"
    ],
    "explanation": [
      "In diazomethane, the carbon atom is bonded to two hydrogen atoms and to two nitrogen atoms, one with a double bond and the other with a triple bond.\n\nThe positive charge is on the carbon atom, and the negative charge is on the nitrogen atom with the triple bond. This is because the more electronegative nitrogen stabilizes the negative charge, while carbon holds the positive charge in this structure."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2911,
        "content": [
          "images/chemistry/year_2014/q3c1_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 2912,
        "content": [
          "images/chemistry/year_2014/q3c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 2913,
        "content": [
          "images/chemistry/year_2014/q3c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 2914,
        "content": [
          "images/chemistry/year_2014/q3c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 729,
    "content": [
      "Which of the following is a property of covalent compounds? Covalent compounds"
    ],
    "explanation": [
      "Covalent compounds typically do not dissolve well in water because they lack the charged ions that ionic compounds have. Water is a polar solvent, so it dissolves polar or ionic substances more easily. Since covalent compounds are often nonpolar, they do not interact well with water molecules and are thus insoluble."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2915,
        "content": [
          "is crystalline solids at room temperature."
        ],
        "isCorrect": false
      },
      {
        "id": 2916,
        "content": [
          "is generally insoluble in water."
        ],
        "isCorrect": true
      },
      {
        "id": 2917,
        "content": [
          "has high melting and boiling points."
        ],
        "isCorrect": false
      },
      {
        "id": 2918,
        "content": [
          "is non-volatile."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 730,
    "content": [
      "Which of the following is a covalent molecule?"
    ],
    "explanation": [
      "Covalent molecules are formed when atoms share electrons to achieve a stable electron configuration. This type of bonding typically occurs between nonmetal atoms.\n\n$$PCl_5$$ (phosphorus pentachloride) is a covalent molecule because it consists of a central phosphorus atom bonded to five chlorine atoms through covalent bonds."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2919,
        "content": [
          "$$CO_3^{2-}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 2920,
        "content": [
          "$$[NH_4]^+$$"
        ],
        "isCorrect": false
      },
      {
        "id": 2921,
        "content": [
          "$$NaCl$$"
        ],
        "isCorrect": false
      },
      {
        "id": 2922,
        "content": [
          "$$PCl_5$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 731,
    "content": [
      "Which of the following postulates of Dalton's atomic theory was modified by the modern atomic theory?"
    ],
    "explanation": [
      "Dalton's atomic stated that atoms were the smallest particles of an element and were indivisible and indestructible. \n\nHowever, later scientific discoveries, as discussed in the sources, showed that atoms are actually composed of even smaller subatomic particles: protons, neutrons, and electrons."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2923,
        "content": [
          "Compounds are formed when atoms of more than one element combine."
        ],
        "isCorrect": false
      },
      {
        "id": 2924,
        "content": [
          "Atoms are neither created nor destroyed in chemical reactions."
        ],
        "isCorrect": false
      },
      {
        "id": 2925,
        "content": [
          "Atoms are indivisible and indestructible."
        ],
        "isCorrect": true
      },
      {
        "id": 2926,
        "content": [
          "Atoms are the smallest particles of all elements."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 732,
    "content": [
      "Which of the following includes all of the known atomic models?"
    ],
    "explanation": [
      "- Dalton's Atomic Model: described atoms as indivisible and indestructible particles that make up elements.\n- Thomson Model (Plum Pudding Model): disproving the idea of atoms being indivisible. His model, depicted the atom as a sphere of positive charge with negatively charged electrons embedded within it, similar to plums in a pudding.\n- Rutherford Model (Nuclear Model):  This model positioned a tiny, dense, positively charged nucleus at the center of the atom, with electrons orbiting it at a distance.\n- Bohr Model: Niels Bohr refined Rutherford's model by proposing that electrons orbit the nucleus in specific energy levels or shells.\n- Quantum Mechanical Model: The most modern and accurate model, it builds upon the previous models and incorporates the wave-particle duality of matter."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2927,
        "content": [
          "Bohr Model, Thomson Model, Rutherford Model, Dalton's Atomic Model, de Broglie Model"
        ],
        "isCorrect": false
      },
      {
        "id": 2928,
        "content": [
          "Bohr Model, the Quantum Mechanical Model, Rutherford Model, Thomson Model, Dalton's Atomic Model"
        ],
        "isCorrect": true
      },
      {
        "id": 2929,
        "content": [
          "Bohr Model, the Quantum Mechanical Model, Thomson Model, Rutherford Model"
        ],
        "isCorrect": false
      },
      {
        "id": 2930,
        "content": [
          "Bohr Model, Quantum Mechanical Model, Dalton's Atomic Model, Valence Bond Model"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 733,
    "content": [
      "The electron configuration of Cu (Z=29) is:"
    ],
    "explanation": [
      "The correct electron configuration of Cu (Z = 29) is:\n$$\n[Ar] 4s^1 3d^{10}\n$$\n\nThe Aufbau principle provides a general order for filling orbitals with electrons, starting with the lowest energy levels. However, there are exceptions, and copper is one of them.\n\nChromium (Cr) and copper (Cu) are exceptions to the Aufbau principle because half-filled and fully filled d subshells are particularly stable. Chromium has an electron configuration of $$[Ar]4s^13d^5$$ (half-filled 3d subshell), and copper has an electron configuration of $$[Ar]4s^13d^{10}$$ (fully filled 3d subshell)."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2931,
        "content": [
          "$$[Ar]4s^13d^{10}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 2932,
        "content": [
          "$$[Kr]4s^23d^9$$"
        ],
        "isCorrect": false
      },
      {
        "id": 2933,
        "content": [
          "$$[Ar]4s^24d^9$$"
        ],
        "isCorrect": false
      },
      {
        "id": 2934,
        "content": [
          "$$[Ar]4s^23p^8$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 734,
    "content": [
      "What does Mendeleev's Periodic Law state? Properties of elements are periodic functions of their"
    ],
    "explanation": [
      "Mendeleev's periodic law states that the physical and chemical properties of elements are the periodic function of their atomic weights.  Mendeleev organized the elements in increasing order of atomic weight and noticed that elements with similar properties appeared periodically."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2935,
        "content": [
          "atomic radius."
        ],
        "isCorrect": false
      },
      {
        "id": 2936,
        "content": [
          "atomic masses."
        ],
        "isCorrect": true
      },
      {
        "id": 2937,
        "content": [
          "electron configurations."
        ],
        "isCorrect": false
      },
      {
        "id": 2938,
        "content": [
          "atomic numbers."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 735,
    "content": [
      "Among the following reactions which one shows a coordinate covalent bond formation?"
    ],
    "explanation": [
      "A coordinate covalent bond, also known as a dative bond, is a type of covalent bond where both electrons in the bond come from the same atom.\n\nIn the reaction between ammonia ($$NH_3$$) and boron trifluoride ($$BF_3$$), the nitrogen atom in $$NH_3$$ donates its lone pair of electrons to the boron atom in $$BF_3$$, forming a coordinate covalent bond.\n\nThis bond is different from a regular covalent bond, where each atom typically contributes one electron to the bond."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2939,
        "content": [
          "images/chemistry/year_2014/q10c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 2940,
        "content": [
          "images/chemistry/year_2014/q10c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 2941,
        "content": [
          "images/chemistry/year_2014/q10c3_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 2942,
        "content": [
          "images/chemistry/year_2014/q10c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 736,
    "content": [
      "Which of the following statements is correct regarding alkenes and alkynes?"
    ],
    "explanation": [
      "Alkenes and alkynes are hydrocarbons. Hydrocarbons are nonpolar molecules. Nonpolar molecules like alkanes, alkenes, and alkynes are held together by weak intermolecular forces called London dispersion forces."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2943,
        "content": [
          "The molecules of alkenes and alkynes are held together by weak inter-molecular force."
        ],
        "isCorrect": true
      },
      {
        "id": 2944,
        "content": [
          "Alkynes have longer bond length and less surface area than alkenes."
        ],
        "isCorrect": false
      },
      {
        "id": 2945,
        "content": [
          "Alkenes are soluble in polar solvents, while alkynes are not soluble in polar solvents."
        ],
        "isCorrect": false
      },
      {
        "id": 2946,
        "content": [
          "Alkenes and alkynes are soluble in polar solvents."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 737,
    "content": [
      "What is the general formula of alkynes?"
    ],
    "explanation": [
      "The general formula for alkynes is:\n$$\nC_nH_{2n-2} \\ (n \\geq 2)\n$$\nAlkynes are hydrocarbons with at least one triple bond between two carbon atoms."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2947,
        "content": [
          "$$C_nH_{2n+2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 2948,
        "content": [
          "$$C_nH_{2n}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 2949,
        "content": [
          "$$C_nH_{n-2} \\ (n>2)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 2950,
        "content": [
          "$$C_nH_{2n-2} \\ (n≥2)$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 6,
    "unitName": "Hydrocarbons and Their Natural Sources"
  },
  {
    "id": 738,
    "content": [
      "Which functional group containing compound is named using the suffix \"-ol\"?"
    ],
    "explanation": [
      "The suffix \"-ol\" is used to name compounds that contain a hydroxyl group (-OH). This is characteristic of alcohols, where the hydroxyl group is attached to a carbon atom."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2951,
        "content": [
          "Phenyl"
        ],
        "isCorrect": false
      },
      {
        "id": 2952,
        "content": [
          "Hydroxyl"
        ],
        "isCorrect": true
      },
      {
        "id": 2953,
        "content": [
          "Aryl"
        ],
        "isCorrect": false
      },
      {
        "id": 2954,
        "content": [
          "Carboxyl"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 739,
    "content": [
      "Which of the following represents the general formula of monohydric alcohols?"
    ],
    "explanation": [
      "$$C_nH_{2n+1}OH$$ represents the general formula for monohydric alcohols, which contain one hydroxyl group (-OH) and follow the alkyl chain formula of $$C_nH_{2n+1}$$ for an alcohol."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2955,
        "content": [
          "$$C_nH_{2n+1}OH$$"
        ],
        "isCorrect": true
      },
      {
        "id": 2956,
        "content": [
          "$$C_nH_{2n}OH$$"
        ],
        "isCorrect": false
      },
      {
        "id": 2957,
        "content": [
          "$$C_nH_{n-2}(OH)_2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 2958,
        "content": [
          "$$C_nH_{2n-2}OH$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 740,
    "content": [
      "What is a Lewis acid? It is"
    ],
    "explanation": [
      "According to the Lewis concept, a Lewis acid is any species that accepts an electron pair to form a bond. A Lewis base is an electron pair donor.\n\nThe Lewis definition of acids and bases expands upon the Brønsted-Lowry definition, which defines an acid as a proton $$H^+$$ donor and a base as a proton $$H^+$$ acceptor."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2959,
        "content": [
          "a proton acceptor."
        ],
        "isCorrect": false
      },
      {
        "id": 2960,
        "content": [
          "an electron pair acceptor."
        ],
        "isCorrect": true
      },
      {
        "id": 2961,
        "content": [
          "an electron pair donor."
        ],
        "isCorrect": false
      },
      {
        "id": 2962,
        "content": [
          "a proton donor."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 741,
    "content": [
      "What is enthalpy change? It is"
    ],
    "explanation": [
      "Enthalpy change is defined as the amount of heat released or absorbed during the dissolution process. It is symbolized by $$\\Delta H$$ and is calculated as the enthalpy of products minus the enthalpy of reactants.\n\nEnthalpy change is expressed in kJ/mol for reactions occurring at standard conditions, which is defined as a temperature of 298.15 K and a pressure of 1 atm."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2963,
        "content": [
          "the amount of heat absorbed in a reaction."
        ],
        "isCorrect": false
      },
      {
        "id": 2964,
        "content": [
          "the amount of heat given out or absorbed in a reaction at constant pressure and volume."
        ],
        "isCorrect": false
      },
      {
        "id": 2965,
        "content": [
          "the amount of heat given out or absorbed in a reaction at constant pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 2966,
        "content": [
          "the amount of heat given out in a reaction."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 742,
    "content": [
      "What is oxidation? Oxidation is"
    ],
    "explanation": [
      "Oxidation is defined as the loss of one or more electrons by an atom. When an atom loses electrons, its oxidation number increases.\n\nConversely, reduction is the gain of one or more electrons by an atom, and a reduction is the gain of one or more electrons. When an atom gains electrons, its oxidation number decreases. \n\nOxidation and reduction always occur simultaneously."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2967,
        "content": [
          "the reduction of the oxidation state of the oxidizing agent."
        ],
        "isCorrect": false
      },
      {
        "id": 2968,
        "content": [
          "the addition of electron(s) to the oxidizing agent."
        ],
        "isCorrect": false
      },
      {
        "id": 2969,
        "content": [
          "the loss of electrons by a species, accompanied by an increase in oxidation number."
        ],
        "isCorrect": true
      },
      {
        "id": 2970,
        "content": [
          "the addition of hydrogen to a substance and the removal of oxygen from a substance."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 743,
    "content": [
      "What is meant by preferential discharge, if a number of ions are present in a solution? It means that the one which requires"
    ],
    "explanation": [
      "During electrolysis, when multiple cations or anions are present in a solution, they compete to get discharged at their respective electrodes.\n\nThe ion that requires the least amount of energy to be liberated will be discharged first. This is known as preferential discharge.\n\nThe electrochemical series ranks ions based on their standard reduction potentials. Ions lower in the series have higher reduction potentials and are more likely to be reduced (cations) or oxidized (anions)."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2971,
        "content": [
          "highest energy will be liberated last at a given electrode."
        ],
        "isCorrect": false
      },
      {
        "id": 2972,
        "content": [
          "highest energy will be liberated first at a given electrode."
        ],
        "isCorrect": false
      },
      {
        "id": 2973,
        "content": [
          "least energy will be liberated last at a given electrode."
        ],
        "isCorrect": false
      },
      {
        "id": 2974,
        "content": [
          "least energy will be liberated first at a given electrode."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 744,
    "content": [
      "Faraday's Second Law states:"
    ],
    "explanation": [
      "Faraday's second law of electrolysis states that the masses of different substances liberated or dissolved by the same amount of electricity are proportional to their equivalent masses."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2975,
        "content": [
          "the amount of a substance consumed or produced at an electrode is inversely proportional to the quantity of electricity passing through the solution."
        ],
        "isCorrect": false
      },
      {
        "id": 2976,
        "content": [
          "the amount of a substance consumed or produced at an electrode is directly proportional to the quantity of electricity passing through the solution."
        ],
        "isCorrect": false
      },
      {
        "id": 2977,
        "content": [
          "passing the same quantity of electricity through solutions of different electrolytes produces masses of substances that are directly proportional to their equivalent masses."
        ],
        "isCorrect": true
      },
      {
        "id": 2978,
        "content": [
          "passing the same quantity of electricity through solutions of different electrolytes produces masses of substances that are directly proportional to their molecular masses."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 745,
    "content": [
      "Which of the following is true about Zn-Cu voltaic cell?"
    ],
    "explanation": [
      "In a Zn-Cu voltaic cell, zinc acts as the anode. During the cell's operation, zinc atoms at the anode lose electrons (oxidation) and become $$Zn^{2+}$$ ions, which dissolve into the electrolyte solution.\n\nThis process leads to a decrease in the mass of the zinc electrode over time."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2979,
        "content": [
          "As the cell operates, electrons are continuously generated at the cathode and consumed at the anode."
        ],
        "isCorrect": false
      },
      {
        "id": 2980,
        "content": [
          "The electrons flow from right to left through the external circuit."
        ],
        "isCorrect": false
      },
      {
        "id": 2981,
        "content": [
          "After the cell runs for several hours, the Zn electrode weights less."
        ],
        "isCorrect": true
      },
      {
        "id": 2982,
        "content": [
          "The anode half-cell consists of Cu electrode dipped into a $$Cu^2+$$ solution."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 746,
    "content": [
      "Which of the following is a polyprotic acid?"
    ],
    "explanation": [
      "Polyprotic acids are acids that contain more than one ionizable (replaceable) hydrogen ion in an aqueous solution.\n\n$$H_3PO_4$$ is a triprotic acid because it contains three ionizable hydrogen atoms. \n\n$$HNO_3$$, $$HF$$, and $$HCl$$ are all monoprotic acids because each gives only one $$H^+$$ ion upon dissociation in an aqueous solution."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2983,
        "content": [
          "$$HNO_3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 2984,
        "content": [
          "$$HF$$"
        ],
        "isCorrect": false
      },
      {
        "id": 2985,
        "content": [
          "$$H_3PO_4$$"
        ],
        "isCorrect": true
      },
      {
        "id": 2986,
        "content": [
          "$$HCI$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 747,
    "content": [
      "Which of the following does represent a general property of a base?"
    ],
    "explanation": [
      "- Bases form hydroxide ions ($$OH^-$$) in a solution. Strong bases dissociate completely and form many hydroxide ions, which can carry an electrical current. So, solutions of strong bases are good conductors of electricity.\n- Aqueous solutions of bases turn red litmus paper to blue, not the other way around.\n- Aqueous solutions of bases turn methyl orange to yellow, not red.\n- Bases release hydroxide ions ($$OH^-$$), not hydronium ions ($$H_3O^+$$) in aqueous solutions."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2987,
        "content": [
          "Aqueous solution of bases turns methyl orange in to red."
        ],
        "isCorrect": false
      },
      {
        "id": 2988,
        "content": [
          "Soluble bases release hydronium ion in aqueous solution."
        ],
        "isCorrect": false
      },
      {
        "id": 2989,
        "content": [
          "Aqueous solution of bases turns blue litmus paper to red."
        ],
        "isCorrect": false
      },
      {
        "id": 2990,
        "content": [
          "Solutions of strong bases are good conductors of electricity."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 748,
    "content": [
      "What are salts? Salts are"
    ],
    "explanation": [
      "Salts are ionic compounds that are formed by the neutralization reaction between an acid and a base.\n\nDuring a neutralization reaction, the cation from the base and the anion from the acid combine to form a salt, while the $$H^+$$ and $$OH^-$$ ions combine to form water.\n\nSalts are also defined as ionic compounds that are formed when the ionizable hydrogen of acids is completely or partially replaced by metal ions or ammonium ions."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2991,
        "content": [
          "ionic compounds formed by partial replacement of ionizable hydroxide by metal cations."
        ],
        "isCorrect": false
      },
      {
        "id": 2992,
        "content": [
          "ionic compounds that derive their cations from a base and their anions from an acid."
        ],
        "isCorrect": true
      },
      {
        "id": 2993,
        "content": [
          "ionic compounds that result from the reaction between metal hydroxide and water."
        ],
        "isCorrect": false
      },
      {
        "id": 2994,
        "content": [
          "ionic compounds formed by complete replacement of ionizable hydrogen by anions of the acid."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 749,
    "content": [
      "The process in which a compound absorbs electrical energy and decomposes into its element is"
    ],
    "explanation": [
      "- **Electrolysis** is a process that uses electrical energy to drive a non-spontaneous chemical reaction. This often involves decomposing a compound into its constituent elements.\n\nLet's look at the other options:\n\n- **Electroplating** is a process that uses electrolysis to deposit a thin layer of one metal onto another metal.\n- **Hydrolysis** is a chemical reaction in which water is used to break down a compound.\n- **Solvolysis** is a type of chemical reaction where the solvent, like water or alcohol, breaks down a compound."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2995,
        "content": [
          "electroplating."
        ],
        "isCorrect": false
      },
      {
        "id": 2996,
        "content": [
          "hydrolysis."
        ],
        "isCorrect": false
      },
      {
        "id": 2997,
        "content": [
          "solvolysis."
        ],
        "isCorrect": false
      },
      {
        "id": 2998,
        "content": [
          "electrolysis."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 750,
    "content": [
      "Which of the following is true about galvanic cells used in commercial lead storage batteries? In lead storage batteries,"
    ],
    "explanation": [
      "A lead storage battery, a type of secondary cell, is the common automobile battery that delivers either 6 or 12 volts depending on the number of cells used. A single lead-storage cell delivers 2 volts. To achieve a 12 V output, six cells are connected in series."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 2999,
        "content": [
          "the galvanic cells are made up of $$PbO_2$$ of anodes."
        ],
        "isCorrect": false
      },
      {
        "id": 3000,
        "content": [
          "half of the galvanic cells are connected in series."
        ],
        "isCorrect": false
      },
      {
        "id": 3001,
        "content": [
          "galvanic cells are connected in parallel."
        ],
        "isCorrect": false
      },
      {
        "id": 3002,
        "content": [
          "galvanic cells are connected in series."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 751,
    "content": [
      "What is the mole ratio of oxygen gas to carbon dioxide gas in the following reaction?\n$$\nC_3H_8 (g) +5O_2 (g) \\rightarrow 3CO_2 (g) + 4H_2O (l)\n$$"
    ],
    "explanation": [
      "The mole ratio of oxygen gas to carbon dioxide gas in the reaction is 5:3. The chemical equation provided shows that 5 moles of oxygen gas ($$O_2$$) react to produce 3 moles of carbon dioxide ($$CO_2$$)."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3003,
        "content": [
          "7 mole oxygen gas to 5 mole carbon dioxide"
        ],
        "isCorrect": false
      },
      {
        "id": 3004,
        "content": [
          "2 mole oxygen gas to 3 mole carbon dioxide"
        ],
        "isCorrect": false
      },
      {
        "id": 3005,
        "content": [
          "5 mole oxygen gas to 3 mole carbon dioxide"
        ],
        "isCorrect": true
      },
      {
        "id": 3006,
        "content": [
          "10 mole oxygen gas to 6 mole carbon dioxide"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 752,
    "content": [
      "Consider the following chemical equation for the combustion of ethane ($$C_2H_6$$) in the presence of oxygen to produce carbon dioxide and water.\n$$\n2C_2H_6 (g) +7O_2 (g) \\rightarrow 4CO_2 (g) + 6H_2O (l)\n$$\nIn this reaction:"
    ],
    "explanation": [
      "The balanced chemical equation you provided shows that 2 moles of ethane react with 7 moles of oxygen to produce 4 moles of carbon dioxide and 6 moles of water.\n\nThis means that for every 2 moles of ethane consumed, 4 moles of carbon dioxide are produced. Therefore, carbon dioxide is formed twice as fast as ethane is consumed."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3007,
        "content": [
          "$$CO_2$$ is formed twice as fast as ethane is consumed."
        ],
        "isCorrect": true
      },
      {
        "id": 3008,
        "content": [
          "water is formed at a rate equal to 2/3 the rate of formation of $$CO_2$$."
        ],
        "isCorrect": false
      },
      {
        "id": 3009,
        "content": [
          "the rate of formation of $$CO_2$$ equals the rate of formation of water."
        ],
        "isCorrect": false
      },
      {
        "id": 3010,
        "content": [
          "the rate of consumption of ethane is 7 times faster than the rate of consumption of oxygen."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 753,
    "content": [
      "Which of the following factors DOES NOT affect the rate of a reaction?"
    ],
    "explanation": [
      "Enthalpy is a thermodynamic property that describes the heat absorbed or released during a reaction at constant pressure. While enthalpy indicates whether a reaction is exothermic or endothermic, it doesn't directly determine how fast the reaction proceeds."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3011,
        "content": [
          "Enthalpy"
        ],
        "isCorrect": true
      },
      {
        "id": 3012,
        "content": [
          "Temperature"
        ],
        "isCorrect": false
      },
      {
        "id": 3013,
        "content": [
          "Surface area"
        ],
        "isCorrect": false
      },
      {
        "id": 3014,
        "content": [
          "Concentration"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 754,
    "content": [
      "How does a catalyst increase the rate of a reaction?"
    ],
    "explanation": [
      "Catalysts work by providing an alternative mechanism for the reaction to occur. This new pathway has a lower activation energy ($$E_a$$).\n\nActivation energy is the minimum energy required for a reaction to start. The lower the activation energy, the easier it is for reactant molecules to overcome this energy barrier and form products, thus increasing the reaction rate."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3015,
        "content": [
          "By changing the equilibrium constant"
        ],
        "isCorrect": false
      },
      {
        "id": 3016,
        "content": [
          "By lowering the activation energy"
        ],
        "isCorrect": true
      },
      {
        "id": 3017,
        "content": [
          "By increasing the activation energy"
        ],
        "isCorrect": false
      },
      {
        "id": 3018,
        "content": [
          "By forming an intermediate complex"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Chemical Kinetics"
  },
  {
    "id": 755,
    "content": [
      "Which of the following statements correctly describes Boyle's Law?"
    ],
    "explanation": [
      "Boyle's Law states that for a fixed amount of gas at a constant temperature, the volume of the gas is inversely proportional to the pressure exerted on it. This means that if the pressure increases, the volume decreases, and vice versa. The mathematical expression for Boyle's Law is:\n$$\nP V = \\text{constant}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3019,
        "content": [
          "The volume of a gas at a given temperature is inversely proportional to the square root of the applied pressure."
        ],
        "isCorrect": false
      },
      {
        "id": 3020,
        "content": [
          "The volume of a gas at a given temperature is proportional to the square root of the applied pressure."
        ],
        "isCorrect": false
      },
      {
        "id": 3021,
        "content": [
          "The volume of a gas at a given temperature is inversely proportional to the applied pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 3022,
        "content": [
          "The volume of a gas at a given temperature is directly proportional to the applied pressure."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 756,
    "content": [
      "Which statement describes the formation of a covalent bond? In covalent\nbond electrons are"
    ],
    "explanation": [
      "Covalent bonding involves the sharing of electrons between atoms to achieve a stable electron configuration, often resembling that of a noble gas.\n\nThis sharing is most common between non-metallic atoms because they have a strong tendency to gain electrons to fill their valence shells."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3023,
        "content": [
          "transferred from non-metallic atoms to metallic atoms."
        ],
        "isCorrect": false
      },
      {
        "id": 3024,
        "content": [
          "shared between non-metallic atoms."
        ],
        "isCorrect": true
      },
      {
        "id": 3025,
        "content": [
          "transferred from metallic atoms to non-metallic atoms."
        ],
        "isCorrect": false
      },
      {
        "id": 3026,
        "content": [
          "shared between metallic atoms."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 757,
    "content": [
      "How do the elements of Group IIA form ions?"
    ],
    "explanation": [
      "The elements of Group IIA form ions by losing 2 electrons. The elements in Group IIA are alkaline earth metals. Alkaline earth metals have an $$ns^2$$ outer electron configuration. To achieve an octet, elements in Group IIA lose their two outermost electrons."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3027,
        "content": [
          "By gaining 2 electrons"
        ],
        "isCorrect": false
      },
      {
        "id": 3028,
        "content": [
          "By losing 2 electrons"
        ],
        "isCorrect": true
      },
      {
        "id": 3029,
        "content": [
          "By losing one electron"
        ],
        "isCorrect": false
      },
      {
        "id": 3030,
        "content": [
          "By gaining one electron"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 758,
    "content": [
      "How is hydrogen bonding formed? It is formed when a hydrogen atom is bonded to"
    ],
    "explanation": [
      "Hydrogen bonding is a specific type of dipole-dipole interaction, which is stronger than typical dipole-dipole interactions, but weaker than ionic bonds.\n\nHydrogen bonds form when a hydrogen atom in one molecule is attracted to an unshared electron pair on an electronegative atom, specifically oxygen, nitrogen, or fluorine in another molecule."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3031,
        "content": [
          "highly electronegative elements, fluorine, oxygen and nitrogen."
        ],
        "isCorrect": true
      },
      {
        "id": 3032,
        "content": [
          "highly electronegative elements, chlorine, oxygen and nitrogen."
        ],
        "isCorrect": false
      },
      {
        "id": 3033,
        "content": [
          "highly electronegative elements, fluorine oxygen and phosphorus."
        ],
        "isCorrect": false
      },
      {
        "id": 3034,
        "content": [
          "highly electronegative elements, fluorine, chlorine and oxygen."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 759,
    "content": [
      "Which one of the following forms of energy change occurs from the combustion of carbon in oxygen is"
    ],
    "explanation": [
      "Combustion of carbon in oxygen is an exothermic reaction, meaning it releases energy in the form of heat."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3035,
        "content": [
          "solar energy."
        ],
        "isCorrect": false
      },
      {
        "id": 3036,
        "content": [
          "heat energy."
        ],
        "isCorrect": true
      },
      {
        "id": 3037,
        "content": [
          "electrical energy."
        ],
        "isCorrect": false
      },
      {
        "id": 3038,
        "content": [
          "light energy."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 760,
    "content": [
      "What is the molar volume of a gas?"
    ],
    "explanation": [
      "STP for gases is defined as a temperature of 0°C (273 K) and a pressure of 1 atmosphere (atm).\n\nAt STP, the volume of one mole of any ideal gas is 22.4 liters (L). This is considered the standard molar volume."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3039,
        "content": [
          "The volume of a gas at STP (standard temperature 25°C and pressure, 1 kPa), which is equal to 22. 4 L/mol."
        ],
        "isCorrect": false
      },
      {
        "id": 3040,
        "content": [
          "The volume of a gas at STP (standard temperature 0°C and pressure, 1 kPa), which is equal to 22. 4 L/mol."
        ],
        "isCorrect": false
      },
      {
        "id": 3041,
        "content": [
          "The volume of a gas at STP (standard temperature 25°C and pressure, 1 atm.), which is equal to 22. 4 L/mol."
        ],
        "isCorrect": false
      },
      {
        "id": 3042,
        "content": [
          "The volume of a gas at STP (standard temperature, 0°C and pressure, 1 atm.), which is equal to 22. 4 L/mol."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 761,
    "content": [
      "In the first order decomposition of dinitrogen pentoxide at 335 K\n$$\nN_2O_5 (g) \\rightarrow 2NO_2 (g) + \\frac{1}{2}O_2(g)\n$$\nA reaction was carried out with 2.5 g of $$N_2O_5$$, sample at 335 K and after 109 seconds, 1.50 g of $$N_2O_5$$ remained. What is the value of the rate constant?"
    ],
    "explanation": [
      "The decomposition of dinitrogen pentoxide $$N_2O_5$$ follows first-order kinetics, and the rate constant k can be calculated using the first-order rate equation:\n\n$$\n\\ln \\left( \\frac{[A]_0}{[A]_t} \\right) = kt\n$$\n\nGiven:\n\n- Initial mass of $$N_2O_5 = 2.5 \\, \\text{g}$$,\n- Mass of $$N_2O_5$$ at time t = 109 seconds is 1.50 g.\n\n$$\n\\ln \\left( \\frac{2.5}{1.50} \\right) = k \\times 109\n$$\n$$\nk  \\approx 4.69 \\times 10^{-3} \\, \\text{s}^{-1}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3043,
        "content": [
          "$$7.63 \\times 10^{-2} s^{-1}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3044,
        "content": [
          "$$6.25 \\times 10^{-2}s^{-1}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3045,
        "content": [
          "$$4.69 \\times 10^{-3}s^{-1}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3046,
        "content": [
          "$$2.25 \\times 10^{-5}s^{-1}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Chemical Kinetics"
  },
  {
    "id": 762,
    "content": [
      "What is the difference between reversible and irreversible reactions?"
    ],
    "explanation": [
      "Reversible reactions are reactions that do not go to completion. Instead, they reach a state of equilibrium, where the rates of the forward and reverse reactions are equal. \n\nAt equilibrium, there is a mixture of both reactants and products present."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3047,
        "content": [
          "In irreversible reactions, there is a mixture of products and reactants."
        ],
        "isCorrect": false
      },
      {
        "id": 3048,
        "content": [
          "In reversible reactions, the reaction goes to completion."
        ],
        "isCorrect": false
      },
      {
        "id": 3049,
        "content": [
          "In irreversible reactions, there is equilibrium between reactants and products."
        ],
        "isCorrect": false
      },
      {
        "id": 3050,
        "content": [
          "In reversible reactions, there is equilibrium between reactants and products."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 763,
    "content": [
      "Consider the reactions all given bellow are in gaseous state. For which of the following reactions is $$K_p$$ less than $$K_c$$?"
    ],
    "explanation": [
      "The relationship between the equilibrium constants $$K_p$$ (in terms of partial pressures) and $$K_c$$ (in terms of concentrations) is given by the equation:\n\n$$\nK_p = K_c \\cdot (RT)^{\\Delta n}\n$$\n\n$$\n\\Delta n = \\text{moles of gaseous products} - \\text{moles of gaseous reactants}\n$$\n\nFor $$K_p$$ to be less than $$K_c$$, the term $$(RT)^{\\Delta n}$$ must be less than 1, which implies that $$\\Delta n$$ should be negative.\nOption: $$2SO_2 + O_2$$ ⇌ $$2SO_3$$\n\n- $$\\Delta n$$ = (2) - (2 + 1) = -1 so $$K_p < K_c$$.\n\nOption: $$N_2O_4$$ ⇌ $$2NO_2$$\n\n- $$\\Delta n$$ = (2) - (1) = +1 so $$K_p > K_c$$.\n\nOption: $$N_2 + O_2$$ ⇌ $$2NO$$\n\n- $$\\Delta n$$ = (2) - (2) = 0 do $$K_p = K_c$$.\n\nOption: $$2HI$$ ⇌ $$H_2 + I_2$$\n\n- $$\\Delta n$$ = (2) - (2) = 0 so $$K_p = K_c$$."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3051,
        "content": [
          "$$2SO_2$$ + $$O_2$$ ⇌ $ $$2SO_3$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3052,
        "content": [
          "$$N_2O_4$$ ⇌ $$2NO_2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3053,
        "content": [
          "$$N_2$$ + $$O_2$$ ⇌ $$2NO$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3054,
        "content": [
          "$$2HI$$ ⇌ $$H_2$$ + $$I_2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 764,
    "content": [
      "The heating curve shown below shows a substance in the solid, liquid and gas phase. Which segment represents only the liquid phase?",
      "images/chemistry/year_2014/q39_1.png"
    ],
    "explanation": [
      "- **Segment 1:** Solid\n- **Segment 2:** Solid to Liquid (Melting)\n- **Segment 3:** Liquid\n- **Segment 4:** Liquid to Gas (Boiling)\n- **Segment 5:** Gas"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2014/q39_1.png"
    ],
    "choices": [
      {
        "id": 3055,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 3056,
        "content": [
          "3"
        ],
        "isCorrect": true
      },
      {
        "id": 3057,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 3058,
        "content": [
          "1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 765,
    "content": [
      "The general formula for saturated monocarboxylic acids is"
    ],
    "explanation": [
      "Monocarboxylic acids are organic acids containing a carboxyl group (-COOH).\n\nSaturated monocarboxylic acids, like acetic acid (CH₃COOH), have only single bonds between carbon atoms, and the formula RCOOH represents a carboxyl group (-COOH) attached to an alkyl group (R)."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3059,
        "content": [
          "RCOR"
        ],
        "isCorrect": false
      },
      {
        "id": 3060,
        "content": [
          "RCOOH"
        ],
        "isCorrect": true
      },
      {
        "id": 3061,
        "content": [
          "ROR"
        ],
        "isCorrect": false
      },
      {
        "id": 3062,
        "content": [
          "RCHO"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 766,
    "content": [
      "What is the concentration of a solution? It is"
    ],
    "explanation": [
      "Concentration is defined as the relative amount of solute compared to the total quantity of the solution or the solvent."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3063,
        "content": [
          "number of moles of solute and number of moles of solvent."
        ],
        "isCorrect": false
      },
      {
        "id": 3064,
        "content": [
          "the amount of solute needed to make a concentrated solution."
        ],
        "isCorrect": false
      },
      {
        "id": 3065,
        "content": [
          "the amount of solvent needed to dissolve a solute."
        ],
        "isCorrect": false
      },
      {
        "id": 3066,
        "content": [
          "the quantity of solute in a given quantity of solution."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 767,
    "content": [
      "How many moles of $$C_{12}H_{22}O_{11}$$ (sucrose molecular weight = 342.91 g/mol) is needed there to prepare 2.0L of 0.3 M solution?"
    ],
    "explanation": [
      "$$\nn = M \\times V\n$$\n\nGiven:\n\n- M = 0.3 mol/L,\n- V = 2.0 L\n\n$$\nn = 0.3 \\, \\text{mol/L} \\times 2.0 \\, \\text{L} = 0.6 \\, \\text{mol}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3067,
        "content": [
          "6.6"
        ],
        "isCorrect": false
      },
      {
        "id": 3068,
        "content": [
          "0.6"
        ],
        "isCorrect": true
      },
      {
        "id": 3069,
        "content": [
          "0.43"
        ],
        "isCorrect": false
      },
      {
        "id": 3070,
        "content": [
          "0.15"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 768,
    "content": [
      "At 75°C, the vapor pressure of pure water is 39 kPa. Which one of the vapor pressure of a solution obtained by dissolving 34.2 g sucrose in 180 mL of water? (Assume that the density of water is 1.000 g/mL)"
    ],
    "explanation": [
      "To calculate the vapor pressure of the solution, we use Raoult's Law:\n$$\nP_{\\text{solution}} = X_{\\text{solvent}} \\cdot P_{\\text{pure}}\n$$\nThe mass of water is:\n$$\\text{Mass of water} = 180 \\, \\text{mL} \\times 1.000 \\, \\frac{\\text{g}}{\\text{mL}} = 180 \\, \\text{g}$$\nThe molar mass of water is 18.015 g/mol, so the moles of water are:\n$$\n\\text{Moles of water} = \\frac{180 \\, \\text{g}}{18.015 \\, \\text{g/mol}} = 9.993 \\, \\text{mol}\n$$\nThe mass of sucrose is 34.2 g. The molar mass of sucrose is = 342.3 g/mol, so the moles of sucrose are:\n$$\n\\text{Moles of sucrose} = \\frac{34.2 \\, \\text{g}}{342.3 \\, \\text{g/mol}} = 0.100 \\, \\text{mol}\n$$\n\nThe mole fraction of water is:\n$$X_{\\text{water}} = \\frac{M_\\text{water}}{M_\\text{water} + M_\\text{sucrose}} = \\frac{9.993}{9.993 + 0.100} = 0.990$$\n\nApplying Raoult's Law:\n$$\nP_{\\text{solution}} = 0.990 \\times 39 \\, \\text{kPa} = 38.6 \\, \\text{kPa}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3071,
        "content": [
          "44.5 kPa"
        ],
        "isCorrect": false
      },
      {
        "id": 3072,
        "content": [
          "41.1 kPa"
        ],
        "isCorrect": false
      },
      {
        "id": 3073,
        "content": [
          "38.6 kPa"
        ],
        "isCorrect": true
      },
      {
        "id": 3074,
        "content": [
          "31.2 kPa"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 769,
    "content": [
      "Which of the following statements is NOT true about the colligative properties of electrolytes and non-electrolytes?"
    ],
    "explanation": [
      "Electrolytes, when dissolved in water, dissociate into ions. This dissociation results in a greater number of particles in the solution compared to non-electrolytes.\n\nColligative properties depend on the number of solute particles in a solution, not their nature. Since electrolytes produce more particles in solution than non-electrolytes, they have a greater effect on colligative properties."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3075,
        "content": [
          "The effect of non-electrolytes on colligative properties is the same as those of electrolytes."
        ],
        "isCorrect": true
      },
      {
        "id": 3076,
        "content": [
          "The effect of non-electrolytes on colligative properties is very low compared to electrolytes."
        ],
        "isCorrect": false
      },
      {
        "id": 3077,
        "content": [
          "The colligative properties of non-electrolytes are not considerably changed."
        ],
        "isCorrect": false
      },
      {
        "id": 3078,
        "content": [
          "The effect of electrolytes on colligative properties is very high compared to non-electrolytes."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 770,
    "content": [
      "For the reaction shown below, which of the following is a conjugate acid-base pair?",
      "$$HC_2O_4^{-1}(aq)$$ + $$H_2O(l)$$ ⇌ $$H_3O^+$$ + $$C_2O_4^{2-}$$"
    ],
    "explanation": [
      "A conjugate acid-base pair consists of two species that differ by one proton (H⁺). In this case, $$HC_2O_4^{-1}$$ loses a proton to form $$C_2O_4^{2-}$$, making them a conjugate acid-base pair."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3079,
        "content": [
          "$$HC_2O_4^{-1}$$ and $$C_2O_4^{2-}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3080,
        "content": [
          "$$H_3O^+$$ and $$HC_2O_4^{-1}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3081,
        "content": [
          "$$H_2O$$ and $$C_2O_4^{2-}$$-"
        ],
        "isCorrect": false
      },
      {
        "id": 3082,
        "content": [
          "$$HC_2O_4^{-1}$$ and $$H_2O$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 771,
    "content": [
      "Which of the following assumptions of the kinetic molecular theory of gases explains the high compressibility of gases?"
    ],
    "explanation": [
      "Gases are highly compressible because the space between the gas particles is very large compared to the size of the particles themselves. When pressure is applied, the gas particles can be forced closer together, reducing the volume of the gas."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3083,
        "content": [
          "Different particles have different speeds."
        ],
        "isCorrect": false
      },
      {
        "id": 3084,
        "content": [
          "Particles are always in random motion."
        ],
        "isCorrect": false
      },
      {
        "id": 3085,
        "content": [
          "There is no force of attraction between gas molecules."
        ],
        "isCorrect": false
      },
      {
        "id": 3086,
        "content": [
          "The actual volume of gas molecules in negligible."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 772,
    "content": [
      "Consider a bottle containing water, water vapor and air in equilibrium. If the temperature decreases slightly, the amount of water vapors;"
    ],
    "explanation": [
      "When the temperature of a system containing water vapor decreases, the water vapor loses kinetic energy. As a result, the water molecules slow down and the intermolecular forces of attraction between them become stronger, causing the water vapor to condense into liquid water. This decreases the amount of water vapor in the bottle."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3087,
        "content": [
          "and vapor pressure will decrease."
        ],
        "isCorrect": true
      },
      {
        "id": 3088,
        "content": [
          "will decrease and the vapor pressure will increase."
        ],
        "isCorrect": false
      },
      {
        "id": 3089,
        "content": [
          "will increase and the vapor pressure will decrease."
        ],
        "isCorrect": false
      },
      {
        "id": 3090,
        "content": [
          "and vapor pressure will increase."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 773,
    "content": [
      "Why do water droplets collect on the outside of a glass of water on a hot day?"
    ],
    "explanation": [
      "Condensation is the process by which water vapor changes into liquid water. This happens when the water vapor cools down.\n\nOn a hot day, the air surrounding the glass of cold water is warm and holds more moisture. When this warm, moist air comes into contact with the cold surface of the glass, the water vapor in the air loses energy and cools down. As the water vapor cools, it reaches a point where it can no longer remain in its gaseous state and condenses into liquid water droplets on the outside of the glass."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3091,
        "content": [
          "There will be a sublimation of water vapor on the outside of a glass."
        ],
        "isCorrect": false
      },
      {
        "id": 3092,
        "content": [
          "There will be a condensation of water vapor on the glass."
        ],
        "isCorrect": true
      },
      {
        "id": 3093,
        "content": [
          "Water from the glass starts to vaporize."
        ],
        "isCorrect": false
      },
      {
        "id": 3094,
        "content": [
          "There is heat exchange between the water in the glass and the surrounding."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 774,
    "content": [
      "What are hydrocarbons? Compounds that contain"
    ],
    "explanation": [
      "Hydrocarbons are compounds that contain only carbon and hydrogen atoms."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3095,
        "content": [
          "benzene and its derivatives only."
        ],
        "isCorrect": false
      },
      {
        "id": 3096,
        "content": [
          "benzene rings only."
        ],
        "isCorrect": false
      },
      {
        "id": 3097,
        "content": [
          "hydrogen and carbon only."
        ],
        "isCorrect": true
      },
      {
        "id": 3098,
        "content": [
          "hydrogen and carbon with no benzene rings."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 6,
    "unitName": "Hydrocarbons and Their Natural Sources"
  },
  {
    "id": 775,
    "content": [
      "Which of the following statement is INCORRECT regarding the boiling points of alkanes?"
    ],
    "explanation": [
      "- Alkanes are non-polar molecules, meaning they only exhibit London dispersion forces as their intermolecular force. London dispersion forces increase with molecular weight. The heavier the molecule, the stronger the London dispersion forces, and the higher the boiling point.\n- Branching in an alkane decreases the boiling point. Straight-chain alkanes have a larger surface area and, therefore, stronger intermolecular forces than branched alkanes.\n- Cycloalkanes have higher boiling points than linear alkanes because their ring structure restricts their movement, resulting in stronger intermolecular forces.\n- While surface area does contribute to the boiling point, it is not the only factor. Molecular weight is the most significant factor."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3099,
        "content": [
          "The boiling point of cycloalkanes is higher than that of linear alkanes."
        ],
        "isCorrect": false
      },
      {
        "id": 3100,
        "content": [
          "Boiling points of straight chain alkanes is greater than that of branched chain alkanes."
        ],
        "isCorrect": false
      },
      {
        "id": 3101,
        "content": [
          "Surface area is the only factor that determines the boiling points of alkanes."
        ],
        "isCorrect": true
      },
      {
        "id": 3102,
        "content": [
          "Boiling points increases with stronger Van der Waals forces."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 6,
    "unitName": "Hydrocarbons and Their Natural Sources"
  },
  {
    "id": 776,
    "content": [
      "The self-ionization of water can be expressed by the equation:",
      " $$H_2O(l)$$ + $$H_2O(l)$$ ⇌ $$H_3O^+ (aq)$$ + $$OH^- (aq)$$",
      "Which of the following is the correct expression of the ionic product of water?"
    ],
    "explanation": [
      "The equilibrium constant expression is derived from the balanced chemical equation, where the product of the concentrations of the products is divided by the product of the concentrations of the reactants, each raised to the power of its stoichiometric coefficient.\n\nHowever, the concentration of liquid and solids remains essentially constant in this process. Therefore, the concentration of (l) and (s) is not included in the $$K_w$$ expression, and the correct formula is simply the product of the concentrations of the hydronium ions (H3O+) and hydroxide ions (OH−) in this case.\n$$\nK_w = [H_3O^+][OH^-]\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3103,
        "content": [
          "$$K_w$$ = $$[H_3O^+][OH^-]/[H2O]$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3104,
        "content": [
          "$$K_w$$= $$[H_3O^+][OH^-]$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3105,
        "content": [
          "$$K_w$$ = $$K_c(H_2O)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3106,
        "content": [
          "$$K_w$$ = $$K_c(H2O)^2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Chemical Equilibrium"
  },
  {
    "id": 777,
    "content": [
      "What is the effect of a common ion in an electrolytic solution?"
    ],
    "explanation": [
      "The common ion effect is the shift in an ionic equilibrium caused by the addition of a solute that provides an ion that takes part in the equilibrium.\n\nFor example, if you add HCl (aq) to a solution of acetic acid, the equilibrium composition should shift to the left because HCl (aq) is a strong acid that provides  $$H_3O^+$$ ion. The degree of ionization of acetic acid is decreased by the addition of a strong acid."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3107,
        "content": [
          "It has no effect on the pH of a solution."
        ],
        "isCorrect": false
      },
      {
        "id": 3108,
        "content": [
          "It decreases the solubility of a solute."
        ],
        "isCorrect": true
      },
      {
        "id": 3109,
        "content": [
          "It suppresses the imitation of a weak base and lowers the pOH."
        ],
        "isCorrect": false
      },
      {
        "id": 3110,
        "content": [
          "It suppresses the imitation of a weak acid and raises the pH."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 778,
    "content": [
      "Sodium carbonate is a basic salt because it is a salt of"
    ],
    "explanation": [
      "Sodium carbonate ($$Na_2CO_3$$) is a salt formed from sodium hydroxide (a strong base) and carbonic acid (a weak acid).\n\nThe carbonate ion ($$CO_3^{-2}$$), which is the conjugate base of the weak acid, undergoes hydrolysis in water, leading to the formation of hydroxide ions ($$OH^-$$). This results in a basic solution."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3111,
        "content": [
          "a strong acid and a weak base and the anion of the strong acid can be hydrolyzed."
        ],
        "isCorrect": false
      },
      {
        "id": 3112,
        "content": [
          "a weak acid and a weak base and the cation of the weak base can be hydrolyzed."
        ],
        "isCorrect": false
      },
      {
        "id": 3113,
        "content": [
          "a strong base and a strong acid and the anion of the strong acid can be hydrolyzed."
        ],
        "isCorrect": false
      },
      {
        "id": 3114,
        "content": [
          "a strong base and a weak acid and the anion of the weak acid can be hydrolyzed."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 779,
    "content": [
      "Which of the following statements is true for an acid-base titration?"
    ],
    "explanation": [
      "Acid-base titrations are used to determine the concentration of an acid or base by adding a titrant of known concentration until the reaction reaches an equivalence point. This process allows for quantitative analysis, as it provides precise measurements of concentration."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3115,
        "content": [
          "An acid-base titration is a method of qualitative analysis for determining the concentration of an acid or base."
        ],
        "isCorrect": false
      },
      {
        "id": 3116,
        "content": [
          "An acid-base titration is a method of quantitative analysis for determining the concentration of an acid or base."
        ],
        "isCorrect": true
      },
      {
        "id": 3117,
        "content": [
          "Acid-base titrations cannot be carried out in the absence of indicators."
        ],
        "isCorrect": false
      },
      {
        "id": 3118,
        "content": [
          "Indicators catalyze an acid-base titration to show the inflection point of the titration curve."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 780,
    "content": [
      "What is the change in internal energy ($$\\Delta E$$) for a reaction, in which the system absorbs 650 J of heat and 125 J of work is done on the system?"
    ],
    "explanation": [
      "The change in internal energy ($$\\Delta E$$) for a system can be calculated using the first law of thermodynamics, which is given by:\n$$\n\\Delta E = q + w\n$$\n\nwhere:\n\n- q is the heat absorbed by the system,\n- w is the work done on the system.\n\nIn this case:\n\n- q = 650 J,\n- w = 125 J\n\n$$\n\\Delta E = 650 \\, \\text{J} + 125 \\, \\text{J} = 775 \\, \\text{J}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3119,
        "content": [
          "-535 J"
        ],
        "isCorrect": false
      },
      {
        "id": 3120,
        "content": [
          "-775 J"
        ],
        "isCorrect": false
      },
      {
        "id": 3121,
        "content": [
          "535 J"
        ],
        "isCorrect": false
      },
      {
        "id": 3122,
        "content": [
          "775 J"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 781,
    "content": [
      "Which of the following carboxylic acids is a solid substance at room temperature?"
    ],
    "explanation": [
      "The physical state of a carboxylic acid at room temperature depends on the length of its carbon chain.\n\nAs the number of carbon atoms in the chain increases, the van der Waals forces between molecules become stronger. Stronger intermolecular forces require more energy (higher temperatures) to overcome, leading to higher melting points.\n\nOctanoic acid (C8) is a liquid at room temperature. Nonanoic acid (C9) is also liquid at room temperature. Decanoic acid (C10) is a solid at room temperature."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3123,
        "content": [
          "Octanoic acid"
        ],
        "isCorrect": false
      },
      {
        "id": 3124,
        "content": [
          "Heptanoic acid"
        ],
        "isCorrect": false
      },
      {
        "id": 3125,
        "content": [
          "Decanoic acid"
        ],
        "isCorrect": true
      },
      {
        "id": 3126,
        "content": [
          "Nonanoic acid"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 782,
    "content": [
      "Which one of the following is correctly stated regarding solubility as an equilibrium process?"
    ],
    "explanation": [
      "- A saturated solution is in equilibrium with the undissolved solute, meaning no more solute can be dissolved.\n- An unsaturated solution has not reached its solubility limit, so more solute can be dissolved.\n- A supersaturated solution is a meta-stable state where more solute is dissolved than is normally possible at a given temperature. They are not more stable than saturated solutions."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3127,
        "content": [
          "Saturated solution is a solution in which more of the solute can be dissolved."
        ],
        "isCorrect": false
      },
      {
        "id": 3128,
        "content": [
          "Unsaturated solution is a solution that is in equilibrium with respect to a given dissolved substance."
        ],
        "isCorrect": false
      },
      {
        "id": 3129,
        "content": [
          "Supersaturated solution is more stable than saturated solution."
        ],
        "isCorrect": false
      },
      {
        "id": 3130,
        "content": [
          "Supersaturated solution is a solution that contains more than the equilibrium amount of dissolved solute."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 783,
    "content": [
      "What is the formula of pentatonic acid?"
    ],
    "explanation": [
      "Pentanoic acid (also known as valeric acid) is a carboxylic acid with a five-carbon chain."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3131,
        "content": [
          "$$CH_3(CH_2)_3COOH$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3132,
        "content": [
          "$$CH_3(CH_2)_4COOH$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3133,
        "content": [
          "$$CH_3(CH_2)_5COOH$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3134,
        "content": [
          "$$CH_3(CH_2)_2COOH$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 784,
    "content": [
      "What is the rate of dissolution? It is"
    ],
    "explanation": [
      "The rate of dissolution specifically refers to how quickly a solid solute (such as salt or sugar) dissolves in a solvent (like water) to form a solution. This process involves the breaking apart of the solute particles and their integration into the solvent."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3135,
        "content": [
          "the speed at which a solid substrate goes into solution."
        ],
        "isCorrect": true
      },
      {
        "id": 3136,
        "content": [
          "the rate at which a solid turns to liquid."
        ],
        "isCorrect": false
      },
      {
        "id": 3137,
        "content": [
          "the speed at which a solid sublimes."
        ],
        "isCorrect": false
      },
      {
        "id": 3138,
        "content": [
          "the rate at which a solid dissociates."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 785,
    "content": [
      "What is the IUPAC name of an ester having the molecular formula $$C_6H_{12}O_2$$?"
    ],
    "explanation": [
      "The IUPAC naming system for esters involves identifying the components derived from the alcohol and carboxylic acid. An ester has the general formula $$RCOOR'$$, where $$R$$ comes from the carboxylic acid and $$R'$$ from the alcohol.\n\nTo name an ester, first identify the alkyl group from the alcohol, which is written first in the name. Then, take the name of the carboxylic acid, change its suffix to “-oate,” and write it second.\n\nFor example, in the case of ethyl butanoate, the alcohol is ethanol (giving the ethyl group) and the acid is butanoic acid (which becomes butanoate). The combined name is ethyl butanoate. The molecular formula for this ester is $$C_6H_{12}O_2$$, which aligns with the structure derived from these components."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3139,
        "content": [
          "Methyl butyrate"
        ],
        "isCorrect": false
      },
      {
        "id": 3140,
        "content": [
          "Ethyl butanoate"
        ],
        "isCorrect": true
      },
      {
        "id": 3141,
        "content": [
          "Pentyl butyrate"
        ],
        "isCorrect": false
      },
      {
        "id": 3142,
        "content": [
          "Ethyl butyrate"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 786,
    "content": [
      "Which of the following statements is NOT correct about minerals and ores?"
    ],
    "explanation": [
      "Minerals are naturally occurring substances that contain metals or their compounds.\n\nOres are a specific type of mineral that are economically viable to extract metals from.\n\nWhile all ores are minerals, not all minerals are ores. This is because some minerals may not have a high enough concentration of the desired metal to make extraction profitable."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3143,
        "content": [
          "Ores are usually used to extract metals economically."
        ],
        "isCorrect": false
      },
      {
        "id": 3144,
        "content": [
          "Minerals are the natural forms in which various metals exist."
        ],
        "isCorrect": false
      },
      {
        "id": 3145,
        "content": [
          "All ores are minerals."
        ],
        "isCorrect": false
      },
      {
        "id": 3146,
        "content": [
          "All minerals are ores."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 787,
    "content": [
      "Why is $$CaCl_2$$ added to $$NaCl$$ in a $$1:1\\frac{1}{2}$$ ratio in the Down's cell for the manufacturing of sodium metal?"
    ],
    "explanation": [
      "Pure $$NaCl$$ melts at 801°C. To make the process more economical, the melting temperature is lowered by adding $$CaCl_2$$. This allows the electrolysis to be carried out at a lower temperature, saving energy."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3147,
        "content": [
          "$$CaCl_2$$ is used as an electrolyte."
        ],
        "isCorrect": false
      },
      {
        "id": 3148,
        "content": [
          "$$CaCl_2$$ is used to lower the density of the mixture."
        ],
        "isCorrect": false
      },
      {
        "id": 3149,
        "content": [
          "$$CaCl_2$$ is used to lower the melting temperature of $$NaCl$$."
        ],
        "isCorrect": true
      },
      {
        "id": 3150,
        "content": [
          "$$CaCl_2$$ is used as a catalyst."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 788,
    "content": [
      "Which of the following is NOT a major step in metallurgical processes?"
    ],
    "explanation": [
      "The three principal steps in extracting a metal from its ore are:\n\n- **Preparation (concentration) of the ore:** This step involves processes like oil floatation and magnetic separation to remove impurities and increase the concentration of the desired metal.\n- **Production of the metal:** This step involves processes like roasting and calcination to convert the metal compound in the ore into a more usable form.\n- **Purification of the metal:** This is the final step and involves processes like chemical reduction and electrolytic reduction to obtain the metal in its pure form.\n\n**Mining the ore** is the process of extracting the ore from the earth, which is a necessary preliminary step to the metallurgical process, but not a metallurgical process itself."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3151,
        "content": [
          "Extracting the metal and refining"
        ],
        "isCorrect": false
      },
      {
        "id": 3152,
        "content": [
          "Pretreatment"
        ],
        "isCorrect": false
      },
      {
        "id": 3153,
        "content": [
          "Concentrating the ore"
        ],
        "isCorrect": false
      },
      {
        "id": 3154,
        "content": [
          "Mining the ore"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 789,
    "content": [
      "Which monomers are used for the synthesis of Teflon?"
    ],
    "explanation": [
      "The monomer used for the synthesis of Teflon is Tetrafluoroethylene. Teflon is formed by the addition polymerization of tetrafluoroethylene ($$CF_2=CF_2$$)."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_POLYMER",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3155,
        "content": [
          "Tetrafluoroethylene"
        ],
        "isCorrect": true
      },
      {
        "id": 3156,
        "content": [
          "Propylene"
        ],
        "isCorrect": false
      },
      {
        "id": 3157,
        "content": [
          "Styrene and Phenol"
        ],
        "isCorrect": false
      },
      {
        "id": 3158,
        "content": [
          "Isoprene"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Polymers"
  },
  {
    "id": 790,
    "content": [
      "Which of the following represents the structure of a disaccharide?"
    ],
    "explanation": [
      "The structure that represents a disaccharide features two six-membered rings connected by an ether linkage (C-O-C). This linkage is a key characteristic of disaccharides, which are composed of two monosaccharides joined together."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3159,
        "content": [
          "images/chemistry/year_2014/q65c1_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 3160,
        "content": [
          "images/chemistry/year_2014/q65c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3161,
        "content": [
          "images/chemistry/year_2014/q65c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3162,
        "content": [
          "images/chemistry/year_2014/q65c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 791,
    "content": [
      "What is the purpose of synthetic cryolite in the extraction of aluminum by the Hall's process?"
    ],
    "explanation": [
      "- Pure aluminum oxide has a melting point of 2045 °C.\n- Adding cryolite ($$Na_3AlF_6$$) reduces the melting point to 1000 °C.\n- This makes the electrolysis process more efficient and cost-effective.\n- The molten cryolite also acts as a conducting medium for the electrolysis."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3163,
        "content": [
          "Cryolite is used as a catalyst in the extraction of aluminum."
        ],
        "isCorrect": false
      },
      {
        "id": 3164,
        "content": [
          "Cryolite increases the melting point of alumina."
        ],
        "isCorrect": false
      },
      {
        "id": 3165,
        "content": [
          "Cryolite reduces the melting point of alumina."
        ],
        "isCorrect": true
      },
      {
        "id": 3166,
        "content": [
          "Cryolite increases the purity of the extracted aluminum."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 792,
    "content": [
      "Which of the following is a chemical property of aluminum?"
    ],
    "explanation": [
      "- Chemical properties are properties that can only be observed when a substance undergoes a chemical change.\n- Aluminum reacts with dilute acids like HCl and H2SO4 to form salts and liberate hydrogen gas. This is a chemical change because the composition of the aluminum is changing.\n- The other options are physical properties of aluminum because they can be observed without changing the chemical composition of aluminum."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_METALS_NONMETALS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3167,
        "content": [
          "Aluminum has a lower density than any other commercial metal."
        ],
        "isCorrect": false
      },
      {
        "id": 3168,
        "content": [
          "Aluminum is a good conductor of heat and electricity."
        ],
        "isCorrect": false
      },
      {
        "id": 3169,
        "content": [
          "Aluminum is a grey metal in color."
        ],
        "isCorrect": false
      },
      {
        "id": 3170,
        "content": [
          "Aluminum liberates hydrogen gas from dilute acids like $$HCI$$ and $$H_2SO4$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Metals and Non Metals"
  },
  {
    "id": 793,
    "content": [
      "How is tanning carried out? In tanning the hides or skins are"
    ],
    "explanation": [
      "Tanning is a process that converts animal hides or skins into leather by treating them with various chemicals to prevent decomposition and to enhance their durability and appearance.\n\nOne common method of tanning involves the use of chromium salts, particularly chromium(III) sulfate, which is effective in providing flexibility and water resistance to the leather."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3171,
        "content": [
          "treated with dilute hydrochloric acid to remove the lime."
        ],
        "isCorrect": false
      },
      {
        "id": 3172,
        "content": [
          "treated with chromium salts."
        ],
        "isCorrect": true
      },
      {
        "id": 3173,
        "content": [
          "soaked in lime and water for several days."
        ],
        "isCorrect": false
      },
      {
        "id": 3174,
        "content": [
          "soaked in water for several days."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 794,
    "content": [
      "How can a project of establishing an industry that consumes coal affect the\nenvironment?"
    ],
    "explanation": [
      "Establishing an industry that consumes coal contributes to the rise in global temperature primarily through the emission of greenhouse gases, particularly carbon dioxide."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3175,
        "content": [
          "By changing the pH of water"
        ],
        "isCorrect": false
      },
      {
        "id": 3176,
        "content": [
          "Production of high level of lead in the atmosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 3177,
        "content": [
          "Rise in global temperature"
        ],
        "isCorrect": true
      },
      {
        "id": 3178,
        "content": [
          "Increment in concentration of nitric oxide"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Introduction to Environmental Chemistry"
  },
  {
    "id": 795,
    "content": [
      "Which of the following is a fundamental quantity SI unit?"
    ],
    "explanation": [
      "The SI base unit for length is the meter (m). The other options are derived units."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3179,
        "content": [
          "Length"
        ],
        "isCorrect": true
      },
      {
        "id": 3180,
        "content": [
          "Pressure"
        ],
        "isCorrect": false
      },
      {
        "id": 3181,
        "content": [
          "Force"
        ],
        "isCorrect": false
      },
      {
        "id": 3182,
        "content": [
          "Speed"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 796,
    "content": [
      "What are intermolecular forces? They are forces due to the attraction between"
    ],
    "explanation": [
      "Intermolecular forces are attractive or repulsive forces that exist between molecules. They are weaker than the forces that hold atoms together within a molecule (intramolecular forces)."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3183,
        "content": [
          "cations and delocalized electrons."
        ],
        "isCorrect": false
      },
      {
        "id": 3184,
        "content": [
          "nuclei and electron pair."
        ],
        "isCorrect": false
      },
      {
        "id": 3185,
        "content": [
          "cations and anions."
        ],
        "isCorrect": false
      },
      {
        "id": 3186,
        "content": [
          "molecules."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 797,
    "content": [
      "Which of the following belongs to chemical bonding theories?"
    ],
    "explanation": [
      "- **Valence bond theory** and **molecular orbital theory** are the two modern bonding theories that explain covalent bonds more accurately than earlier models.\n- **Valence shell electron pair repulsion (VSEPR) theory** is a model used to predict molecular geometries.\n- **Kinetic-molecular theory** is a model for understanding the behavior of gases."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3187,
        "content": [
          "Valence bond theory and valence shell electron pair repulsion theory."
        ],
        "isCorrect": false
      },
      {
        "id": 3188,
        "content": [
          "Molecular orbital theory and kinetic-molecular theory."
        ],
        "isCorrect": false
      },
      {
        "id": 3189,
        "content": [
          "Valence bond theory and molecular orbital theory."
        ],
        "isCorrect": true
      },
      {
        "id": 3190,
        "content": [
          "Kinetic-molecular theory and valence shell electron pair repulsion theory."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 798,
    "content": [
      "In which of the following molecules is the central atom $$sp^2$$ hybridized?"
    ],
    "explanation": [
      "In $$SO_2$$, the sulfur atom forms two double bonds with oxygen atoms and has one  lone pair, resulting in a trigonal planar geometry which is  characteristic of $$sp^2$$."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3191,
        "content": [
          "$$CO$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3192,
        "content": [
          "$$SO_2$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3193,
        "content": [
          "$$N_2O$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3194,
        "content": [
          "$$CO_2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 799,
    "content": [
      "For a reaction:\n$$\n\\frac{1}{2}A \\rightarrow 2B\n$$\nthe rate of disappearance of 'A' is related to the appearance of 'B' by the expression:"
    ],
    "explanation": [
      "To relate the rate of disappearance of A to the rate of appearance of \\( B \\) for the reaction\n$$\n\\frac{1}{2}A \\rightarrow 2B\n$$\n\nwe can use the stoichiometric coefficients from the balanced equation. The relationship can be expressed as:\n$$\n-\\frac{1}{a} \\frac{\\Delta A}{\\Delta t} = \\frac{1}{b} \\frac{\\Delta B}{\\Delta t}\n$$\n\nSubstituting these values into the equation gives:\n$$\n-\\frac{1}{\\frac{1}{2}} \\frac{\\Delta A}{\\Delta t} = \\frac{1}{2} \\frac{\\Delta B}{\\Delta t}\n$$\n\nRearranging this gives:\n$$\n-\\frac{\\Delta A}{\\Delta t} = \\frac{1}{4} \\frac{\\Delta B}{\\Delta t}\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3195,
        "content": [
          "$$-\\frac{\\Delta A}{\\Delta t}$$ = $$\\frac{1}{4} \\frac{\\Delta B}{\\Delta t}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3196,
        "content": [
          "$$-\\frac{\\Delta A}{\\Delta t}$$ = $$\\frac{1}{2} \\frac{\\Delta B}{\\Delta t}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3197,
        "content": [
          "$$-\\frac{\\Delta A}{\\Delta t}$$ = $$\\frac{4 \\Delta B}{\\Delta t}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3198,
        "content": [
          "$$-\\frac{\\Delta A}{\\Delta t}$$ = $$\\frac{\\Delta B}{\\Delta t}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 800,
    "content": [
      "The half-life of a reaction is the time taken for the"
    ],
    "explanation": [
      "The half-life of a reaction refers specifically to the time required for the concentration of a reactant to decrease to half of its initial concentration."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3199,
        "content": [
          "complete conversion of a reactant into a product."
        ],
        "isCorrect": false
      },
      {
        "id": 3200,
        "content": [
          "rate constant to decrease by 50% of its initial value."
        ],
        "isCorrect": false
      },
      {
        "id": 3201,
        "content": [
          "rate constant to increase by 50% of its initial value."
        ],
        "isCorrect": false
      },
      {
        "id": 3202,
        "content": [
          "reactant concentration to decrease by 50% of its initial value."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 801,
    "content": [
      "For the conversion of 3.5 yards into meter using the factor label method, which of the following is the correct step?\n\n1 yard = 3.5 feet; 1 foot = 12 inch; 1 inch = 2.54 cm; 1m = 100 cm"
    ],
    "explanation": [
      "The conversion process must use the correct unit ratios to ensure proper cancellation of units, leading to the desired outcome of meters.\n\n- Starting with **3.5 yards**, we convert it to feet using the ratio $$\\frac{3.5 \\text{ feet}}{1 \\text{ yard}}$$.\n- Next, we convert feet to inches using $$\\frac{12 \\text{ inches}}{1 \\text{ foot}}$$.\n- Then, we convert inches to centimeters using $$\\frac{2.54 \\text{ cm}}{1 \\text{ inch}}$$.\n- Finally, we convert centimeters to meters using $$\\frac{1 \\text{ m}}{100 \\text{ cm}}$$.\n\nThus, the correct setup should be:\n$$\n(\\frac{3.5 \\text{yards}}{1})(\\frac{3.5 \\text{ feet}}{1 \\text{ yard}})(\\frac{12 \\text{ in}}{1 \\text{ foot}})(\\frac{2.54 \\text{ cm}}{1 \\text{ in}})(\\frac{1 \\text{ m}}{100 \\text{ cm}})\n$$"
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3203,
        "content": [
          "(3.5 yards/1)(3.5 feet/1 yard)(1foot/112 in)(2.54 cm/1 in)(1 m/100 cm)"
        ],
        "isCorrect": false
      },
      {
        "id": 3204,
        "content": [
          "(3.5 yards/1)(3.5 feet/1 yard)(12 in/1 foot)(1 in/2.54 m)(1m/100 cm)"
        ],
        "isCorrect": false
      },
      {
        "id": 3205,
        "content": [
          "(3.5 yards/1)(1 yard/3.5 feet)(12 in/1 foot)(2.54 cm/1 in)(1m/100 cm)"
        ],
        "isCorrect": false
      },
      {
        "id": 3206,
        "content": [
          "(3.5 yards/1)(3.5 feet/1 yard)(12 in/1 foot)(2.54 cm/1 in)(1m/100 cm)"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 802,
    "content": [
      "In the scientific method, a predictive statement that can be tested experimentally is:"
    ],
    "explanation": [
      "A hypothesis is a testable prediction or statement that proposes an explanation for an observed phenomenon. It's a crucial part of the scientific method because it provides a specific direction for experimental investigation."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3207,
        "content": [
          "hypothesis."
        ],
        "isCorrect": true
      },
      {
        "id": 3208,
        "content": [
          "proof."
        ],
        "isCorrect": false
      },
      {
        "id": 3209,
        "content": [
          "evidence."
        ],
        "isCorrect": false
      },
      {
        "id": 3210,
        "content": [
          "truth."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Chemistry and it's Importance"
  },
  {
    "id": 803,
    "content": [
      "Which of the following is NOT true about cathode rays? Cathode rays"
    ],
    "explanation": [
      "- Cathode rays are beams of negatively charged particles called electrons.\n- Electrons are constituents of all matter.\n- The characteristics of cathode rays are independent of the material making up the cathode, and their mass-to-charge ratio is constant for all gases.\n- Cathode rays travel in straight lines from the cathode (negative electrode) to the anode (positive electrode)."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3211,
        "content": [
          "are common constituents of all matter and their m/e is constant for all gases."
        ],
        "isCorrect": false
      },
      {
        "id": 3212,
        "content": [
          "contain particles, which are positively charged."
        ],
        "isCorrect": true
      },
      {
        "id": 3213,
        "content": [
          "travel in straight lines from cathode to the anode."
        ],
        "isCorrect": false
      },
      {
        "id": 3214,
        "content": [
          "contain particles, which are negatively charged."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 804,
    "content": [
      "Which of the following statements is correct about the energy of a photon?"
    ],
    "explanation": [
      "- The energy of a single quantum of energy is given by the equation: E = hν, where h is Planck's constant and ν is the frequency of the radiation.\n- This equation shows that the energy of a quantum is directly proportional to the frequency of the radiation.\n- Therefore, the energy of a photon, which is a quantum of light, is also directly proportional to the observed frequency of the light."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3215,
        "content": [
          "It is directly proportional to the wave length of the light."
        ],
        "isCorrect": false
      },
      {
        "id": 3216,
        "content": [
          "It is directly related to the intensity of the light."
        ],
        "isCorrect": false
      },
      {
        "id": 3217,
        "content": [
          "It is inversely proportional to the observed frequency of the light."
        ],
        "isCorrect": false
      },
      {
        "id": 3218,
        "content": [
          "It is directly proportional to the observed frequency of the light."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 805,
    "content": [
      "Which of the following explains the emission spectra of atoms consisting of a series of fine lines?"
    ],
    "explanation": [
      "When an electron in an atom absorbs energy, it can move to a higher energy level (excitation). When the electron returns to a lower energy level, it releases energy in the form of electromagnetic radiation (photons).\n\nThe energy of the emitted photon corresponds to the difference in energy between the two levels. Because energy levels in atoms are quantized (discrete), the emitted light consists of specific wavelengths, resulting in the characteristic fine lines observed in atomic emission spectra."
    ],
    "year": "YEAR_2014",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3219,
        "content": [
          "An electron that revolves around the nucleus emits radiation."
        ],
        "isCorrect": false
      },
      {
        "id": 3220,
        "content": [
          "The energy of the atoms is continuous with discreet frequencies."
        ],
        "isCorrect": false
      },
      {
        "id": 3221,
        "content": [
          "An electron undergoes a transition by energy changes corresponding to photon of specific wave length."
        ],
        "isCorrect": true
      },
      {
        "id": 3222,
        "content": [
          "An electron can have specific energy values in an atom."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 806,
    "content": [
      "The branch of chemistry that is involved in separation, identifying and determining the relative amounts of components in a sample of material is known as"
    ],
    "explanation": [
      "Analytical chemistry is the branch of chemistry that deals with the separation, identification, and quantification of the components of a sample."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3223,
        "content": [
          "biochemistry."
        ],
        "isCorrect": false
      },
      {
        "id": 3224,
        "content": [
          "analytical chemistry."
        ],
        "isCorrect": true
      },
      {
        "id": 3225,
        "content": [
          "physical chemistry."
        ],
        "isCorrect": false
      },
      {
        "id": 3226,
        "content": [
          "inorganic chemistry."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Chemistry and it's Importance"
  },
  {
    "id": 807,
    "content": [
      "Significant figures are figures with"
    ],
    "explanation": [
      "Significant figures are digits in a number that are known with certainty, plus one final digit that is uncertain or estimated."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3227,
        "content": [
          "measured values with the highest precision."
        ],
        "isCorrect": false
      },
      {
        "id": 3228,
        "content": [
          "measured values with the highest accuracy."
        ],
        "isCorrect": false
      },
      {
        "id": 3229,
        "content": [
          "measured values with the highest uncertainty."
        ],
        "isCorrect": false
      },
      {
        "id": 3230,
        "content": [
          "exactly known digits with the last digit uncertain."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 808,
    "content": [
      "For the determination of the density of a new ceramic, a student measured the mass of a piece on an analytical balance and obtained 3.8056 gram and its volume 2.5 mL by displacement of water in a graduated cylinder. The correct reported density of the ceramic should be"
    ],
    "explanation": [
      "To calculate the density, we use the formula:\n$$\nDensity = \\frac{Mass}{Volume}\n$$\nGiven the mass is 3.8056 g and the volume is 2.5 mL.\n$$\nDensity = \\frac{3.8056 \\, g}{2.5 \\, mL} = 1.52224 \\, g/mL\n$$\nHowever, we need to consider significant figures. The volume (2.5 mL) has only two significant figures, so the density should also be reported with two significant figures. Therefore, the correct reported density is 1.5 g/mL."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3231,
        "content": [
          "1.5222 g/mL"
        ],
        "isCorrect": false
      },
      {
        "id": 3232,
        "content": [
          "1.5224 g/mL"
        ],
        "isCorrect": false
      },
      {
        "id": 3233,
        "content": [
          "1.5 g/mL"
        ],
        "isCorrect": true
      },
      {
        "id": 3234,
        "content": [
          "3.5 g/mL"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 809,
    "content": [
      "The scientific method is"
    ],
    "explanation": [
      "The scientific method is a systematic approach to gaining knowledge through observation, experimentation, and analysis.\n\nIt involves formulating hypotheses, designing experiments to test those hypotheses, collecting data, and drawing conclusions based on the evidence.\n\nThe key aspect is that the experiments must be reproducible to validate the findings."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3235,
        "content": [
          "a collection of scientific guesses and hypotheses by seeking patterns in the observations."
        ],
        "isCorrect": false
      },
      {
        "id": 3236,
        "content": [
          "a method of arriving at an organized body of knowledge based on reproducible experiments and observations."
        ],
        "isCorrect": true
      },
      {
        "id": 3237,
        "content": [
          "the sum total of unique guidelines for the practice of science in the world."
        ],
        "isCorrect": false
      },
      {
        "id": 3238,
        "content": [
          "the result of fortunate, accidental discovery in the development of science."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Chemistry and it's Importance"
  },
  {
    "id": 810,
    "content": [
      "One of the following is NOT a cause of uncertainty in measurement?"
    ],
    "explanation": [
      "The type of material measured itself is not a cause of uncertainty; rather, factors related to the measurement process and the tools used contribute to uncertainty."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3239,
        "content": [
          "The type of material measured"
        ],
        "isCorrect": true
      },
      {
        "id": 3240,
        "content": [
          "The person doing the experiment"
        ],
        "isCorrect": false
      },
      {
        "id": 3241,
        "content": [
          "The measuring device"
        ],
        "isCorrect": false
      },
      {
        "id": 3242,
        "content": [
          "The environment where the measurement is made"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 811,
    "content": [
      "Which of the following is true about isotopes? Isotopes of an element have"
    ],
    "explanation": [
      "Isotopes of an element have the same number of protons but different numbers of neutrons. This difference in neutron number leads to variations in their atomic mass."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3243,
        "content": [
          "the same number of electrons and neutrons."
        ],
        "isCorrect": false
      },
      {
        "id": 3244,
        "content": [
          "different number of neutrons and the same number protons."
        ],
        "isCorrect": true
      },
      {
        "id": 3245,
        "content": [
          "different physical and chemical properties."
        ],
        "isCorrect": false
      },
      {
        "id": 3246,
        "content": [
          "the same atomic mass but different atomic numbers."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 812,
    "content": [
      "The following diagrammatic representations shows the shape for various orbitals. Which one represents the $$d_z^2$$ orbitals?"
    ],
    "explanation": [
      "The $$d_z^2$$ orbital has a unique shape, consisting of two lobes along the z-axis and a donut-shaped ring (torus) around the center in the xy-plane. This shape is accurately represented in option A."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_QUANTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3247,
        "content": [
          "images/chemistry/year_2013/q7c1_1_background.png"
        ],
        "isCorrect": true
      },
      {
        "id": 3248,
        "content": [
          "images/chemistry/year_2013/q7c2_1_background.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3249,
        "content": [
          "images/chemistry/year_2013/q7c3_1_background.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3250,
        "content": [
          "images/chemistry/year_2013/q7c4_1_background.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 813,
    "content": [
      "Silver (Z=47) has several known isotopes, but two occur naturally, $$^{107}Ag$$ and $$^{109}Ag$$. Given the following mass spectrometric data, calculate the atomic mass of Ag",
      "images/chemistry/year_2013/q8_1.png"
    ],
    "explanation": [
      "To calculate the atomic mass of Ag, use the weighted average based on the abundance of each isotope:\n$$\nAtomic \\, Mass = (Mass_{107} \\times Abundance_{107}) + (Mass_{109} \\times Abundance_{109})\n$$\nConvert the percentages to decimals:\n$$\nAtomic \\, Mass = (106.90509 \\times 0.5184) + (108.90476 \\times 0.4816)\n$$\n$$\nAtomic \\, Mass = 55.4202 + 52.4407\n$$\n$$\nAtomic \\, Mass = 107.8609 \\, amu\n$$\nRounding to two decimal places, the atomic mass of Ag is 107.86 amu."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PERIODIC_TABLE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2013/q8_1.png"
    ],
    "choices": [
      {
        "id": 3251,
        "content": [
          "108.9 amu"
        ],
        "isCorrect": false
      },
      {
        "id": 3252,
        "content": [
          "107.94 amu"
        ],
        "isCorrect": false
      },
      {
        "id": 3253,
        "content": [
          "107.4 amu"
        ],
        "isCorrect": false
      },
      {
        "id": 3254,
        "content": [
          "107.86 amu"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Periodic Classification of Elements"
  },
  {
    "id": 814,
    "content": [
      "Which statement correctly describes Heisenberg's uncertainty principle?"
    ],
    "explanation": [
      "Heisenberg's uncertainty principle states that it is impossible to know both the exact position and momentum of a particle."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_QUANTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3255,
        "content": [
          "If we measure the momentum of a particle precisely then its position will be correspondingly precise."
        ],
        "isCorrect": false
      },
      {
        "id": 3256,
        "content": [
          "A particle with a mass moving at a given speed can be described by the wave characteristics of material particles."
        ],
        "isCorrect": false
      },
      {
        "id": 3257,
        "content": [
          "A small particle like the electron can behave both as a particle and a wave."
        ],
        "isCorrect": false
      },
      {
        "id": 3258,
        "content": [
          "Both the location and the momentum of a subatomic particle like the electron cannot be precisely known."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 815,
    "content": [
      "Which of the following statement is correct about energy changes when an electron changes its energy level?"
    ],
    "explanation": [
      "When an electron jumps from a lower energy level to a higher energy level, it absorbs energy equal to the difference between the two energy levels."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_QUANTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3259,
        "content": [
          "When an electron jumps from a lower energy level to a higher level, the photon emitted is equal to the difference between the two energy levels."
        ],
        "isCorrect": false
      },
      {
        "id": 3260,
        "content": [
          "When an electron falls from a higher energy level to a lower energy level, the energy is equal to the difference between the two energy levels is observed."
        ],
        "isCorrect": false
      },
      {
        "id": 3261,
        "content": [
          "When an electron jumps from a lower energy level to a higher level, the energy is equal to the difference between the two energy levels is absorbed."
        ],
        "isCorrect": true
      },
      {
        "id": 3262,
        "content": [
          "When an electron falls from a higher energy level to a lower energy level, the energy is higher than the difference between the two energy levels is emitted."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 816,
    "content": [
      "The sanitizer in wide use for protection against Covid-19 is labeled 83% alcohol. How can one scientifically check the concentration? This can be done by"
    ],
    "explanation": [
      "To scientifically check the concentration of the alcohol in the sanitizer, the best approach is through experimentation."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3263,
        "content": [
          "forming a hypothesis."
        ],
        "isCorrect": false
      },
      {
        "id": 3264,
        "content": [
          "experimentation."
        ],
        "isCorrect": true
      },
      {
        "id": 3265,
        "content": [
          "collection of data."
        ],
        "isCorrect": false
      },
      {
        "id": 3266,
        "content": [
          "making observation."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Chemistry and it's Importance"
  },
  {
    "id": 817,
    "content": [
      "The correct electronic configuration for chromium (Cr, Z=24) is"
    ],
    "explanation": [
      "The correct electronic configuration for Chromium (Cr, Z=24) is $$1s^22s^22p^63s^23p^64s^13d^5$$.\n\nChromium is an exception to Hund's rule. It promotes an electron from the 4s orbital to the 3d orbital to achieve a more stable half-filled d subshell."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3267,
        "content": [
          "$$1s^22s^22p^63s^23p^63d^44d^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3268,
        "content": [
          "$$1s^22s^22p^63s^23p^64s^03d^6$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3269,
        "content": [
          "$$1s^22s^22p^63s^23p^64s^13d^5$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3270,
        "content": [
          "$$1s^22s^22p^63s^23p^64s^23d^4$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 818,
    "content": [
      "According to Hund's rule equal energy (degenerate) orbitals are filled with"
    ],
    "explanation": [
      "Hund's rule states that electrons will individually occupy each orbital within a subshell before any orbital is doubly occupied, and that all electrons in singly occupied orbitals have the same spin (to maximize total spin). This results in the maximum number of unpaired electrons with parallel spins."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_QUANTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3271,
        "content": [
          "two electrons of opposite spins placed in the first orbitals."
        ],
        "isCorrect": false
      },
      {
        "id": 3272,
        "content": [
          "maximum number of unpaired electrons with parallel spins."
        ],
        "isCorrect": true
      },
      {
        "id": 3273,
        "content": [
          "two electrons of parallel spins placed in the first orbital."
        ],
        "isCorrect": false
      },
      {
        "id": 3274,
        "content": [
          "maximum number of unpaired electrons with opposite spins."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 819,
    "content": [
      "In the modern periodic table"
    ],
    "explanation": [
      "In the modern periodic table, non-metals are generally located on the right-hand side. Metals are on the left, and elements with similar properties are in the same group (vertical column), not period (horizontal row). Transition elements are in the middle."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PERIODIC_TABLE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3275,
        "content": [
          "non-metals are placed on the right hand side of the periodic table."
        ],
        "isCorrect": true
      },
      {
        "id": 3276,
        "content": [
          "elements with similar properties are placed in the same period."
        ],
        "isCorrect": false
      },
      {
        "id": 3277,
        "content": [
          "metals are placed on the right hand side of the periodic table."
        ],
        "isCorrect": false
      },
      {
        "id": 3278,
        "content": [
          "transition and inner transition elements are placed in the middle of the periodic table."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Periodic Classification of Elements"
  },
  {
    "id": 820,
    "content": [
      "The electrolysis of liquid (molten) $$NaCl$$ in the set-up for the electrochemical cell is given in the following figure below.",
      "images/chemistry/year_2013/q15_1.png",
      "Which of the following statements is true about the electrolysis of molten sodium chloride?"
    ],
    "explanation": [
      "During the electrolysis of molten $$NaCl$$, the following occurs:\n- At the anode (positive electrode), chloride ions ($$Cl^-$$) are oxidized to chlorine gas ($$Cl_2$$).\n$$2Cl^- \\rightarrow Cl_2 + 2e^-$$\n- At the cathode (negative electrode), sodium ions ($$Na^+$$) are reduced to sodium metal ($$Na$$).\n$$Na^+ + e^- \\rightarrow Na$$\n\nTherefore, the net reaction produces chlorine gas at the anode and sodium metal at the cathode."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2013/q15_1.png"
    ],
    "choices": [
      {
        "id": 3279,
        "content": [
          "$$Cl_2$$ is formed at the cathode."
        ],
        "isCorrect": false
      },
      {
        "id": 3280,
        "content": [
          "$$Na$$ is oxidized at the anode."
        ],
        "isCorrect": false
      },
      {
        "id": 3281,
        "content": [
          "The net reaction produces $$Cl_2$$ at the anode and $$Na$$ at the cathode."
        ],
        "isCorrect": true
      },
      {
        "id": 3282,
        "content": [
          "$$O_2$$ is produced at the anode due to oxidation of water."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 821,
    "content": [
      "Covalent compounds are liquids or gases at room temperature and have low melting and boiling points. Which of the following statements explains these properties of covalent compounds?"
    ],
    "explanation": [
      "Covalent compounds are formed by the sharing of electrons between non-metal atoms, creating discrete molecules rather than a continuous lattice structure like ionic compounds. The forces holding atoms together within a molecule (covalent bonds) are strong, but the intermolecular forces (such as Van der Waals forces, dipole-dipole interactions, or hydrogen bonding) between these molecules are relatively weak.\n\nAs a result, covalent compounds typically have low melting and boiling points and often exist as liquids or gases at room temperature."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3283,
        "content": [
          "The intermolecular forces of attraction in covalent compounds are strong."
        ],
        "isCorrect": false
      },
      {
        "id": 3284,
        "content": [
          "The unit of particles in covalent compounds are ions."
        ],
        "isCorrect": false
      },
      {
        "id": 3285,
        "content": [
          "There are no forces of attraction between the molecules in covalent compounds."
        ],
        "isCorrect": false
      },
      {
        "id": 3286,
        "content": [
          "Covalent compounds exist as separate molecules."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 822,
    "content": [
      "Both carbonyl sulphide, $$COS$$ ($$SCO$$), $$S=C=O$$ and carbon dioxide ($$CO_2$$) $$O=C=O$$ are linear molecules. $$COS$$ is polar whereas $$CO_2$$ is non-polar, this is because"
    ],
    "explanation": [
      "$$CO_2$$ is non-polar because it is a linear molecule with two identical $$C=O$$ bonds arranged symmetrically, which means the bond dipoles cancel each other out, resulting in a net dipole moment of zero."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3287,
        "content": [
          "$$CO_2$$ has a net dipole moment of zero."
        ],
        "isCorrect": true
      },
      {
        "id": 3288,
        "content": [
          "the $$C=O$$ bonds in both $$COS$$ and $$CO_2$$ are polar."
        ],
        "isCorrect": false
      },
      {
        "id": 3289,
        "content": [
          "regions of high negative charge is distributed equally around the central atom in $$COS$$."
        ],
        "isCorrect": false
      },
      {
        "id": 3290,
        "content": [
          "Sulphur is more electronegative than oxygen."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 823,
    "content": [
      "Which of the following statements is true about the formation of $$CH_4$$ according to valence bond theory?"
    ],
    "explanation": [
      "In methane ($$CH_4$$), carbon undergoes $$sp^3$$ hybridization. This involves mixing one 2s orbital and three 2p orbitals to form four equivalent $$sp^3$$ hybrid orbitals. These hybrid orbitals are then used to form sigma bonds with the four hydrogen atoms."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3291,
        "content": [
          "The 2s and two 2p orbitals in carbon hybridize to form three $$sp^2$$ orbitals."
        ],
        "isCorrect": false
      },
      {
        "id": 3292,
        "content": [
          "The 2s and three 2p orbitals in carbon hybridize to form four $$sp^3$$ orbitals."
        ],
        "isCorrect": true
      },
      {
        "id": 3293,
        "content": [
          "The 2s and one 2p orbitals in carbon hybridize to form two $$sp$$ orbitals."
        ],
        "isCorrect": false
      },
      {
        "id": 3294,
        "content": [
          "Carbon can form two hybrid orbitals as it has got only two half-filled orbitals."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 6,
    "unitName": "Hydrocarbons and Their Natural Sources"
  },
  {
    "id": 824,
    "content": [
      "Phosphorus (Z=15) has the electronic configuration $$1s^22s^22p^63s^23p^3$$, what kind of hybridization does phosphorus undergo in the formation of phosphorus pentachloride($$PCl_5$$)?"
    ],
    "explanation": [
      "In $$PCl_5$$, phosphorus is bonded to five chlorine atoms. To accommodate these five bonds, phosphorus undergoes $$sp^3d$$ hybridization. This means one s orbital, three p orbitals, and one d orbital hybridize to form five $$sp^3d$$ hybrid orbitals, which are then used to form sigma bonds with the five chlorine atoms."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3295,
        "content": [
          "$$sp^3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3296,
        "content": [
          "$$sp^3d$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3297,
        "content": [
          "$$sp^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3298,
        "content": [
          "$$sp$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 825,
    "content": [
      "One of the following reactions illustrates the formation of coordinate covalent bond?"
    ],
    "explanation": [
      "A coordinate covalent bond is formed when one atom donates both electrons to form a bond. In the reaction $$NH_3 + HCl$$ $$\\rightarrow$$ $$NH_4^+ + Cl^-$$, nitrogen in $$NH_3$$ donates its lone pair to form a bond with $$H^+$$ from $$HCl$$, creating the ammonium ion ($$NH_4^+$$.)"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3299,
        "content": [
          "$$NaOH + HCl$$ $$\\rightarrow$$ $$NaCl + H_2O$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3300,
        "content": [
          "$$Be + 2F_2$$ $$\\rightarrow$$ $$BeF_2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3301,
        "content": [
          "$$NH_3 + HCl$$ $$\\rightarrow$$ $$NH_4^+ + Cl^-$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3302,
        "content": [
          "$$CaCO_3 + HCl$$ $$\\rightarrow$$ $$CaCl_2 + H_2O + CO_2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 826,
    "content": [
      "Hydrogen bonding occurs in compounds that contain H-N, H-O and H-F bonds. These bonds are stronger than the ordinary dipole-dipole interactions because"
    ],
    "explanation": [
      "Hydrogen bonds are formed due to the attraction between the partially positive hydrogen atom of one molecule and the partially negative lone pairs on the highly electronegative nitrogen, oxygen, or fluorine atoms of another molecule."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3303,
        "content": [
          "the partially positive H of one molecule is attracted to the partially negative lone pairs on the N, O or F of another molecule."
        ],
        "isCorrect": true
      },
      {
        "id": 3304,
        "content": [
          "the H-N, H-O and H-F bonds are less polar than ordinary covalent bonds."
        ],
        "isCorrect": false
      },
      {
        "id": 3305,
        "content": [
          "the small sizes of N, O and F makes these atoms so electropositive that their covalently bonded H is highly negative."
        ],
        "isCorrect": false
      },
      {
        "id": 3306,
        "content": [
          "the H-N, H-O and H-F bonds are non-polar and thus do not interact with neighboring molecules."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 827,
    "content": [
      "Which of the following is an example of exception to the octet rule?"
    ],
    "explanation": [
      "$$PCl_5$$ is an exception to the octet rule because the central phosphorus atom is surrounded by five chlorine atoms, resulting in 10 electrons in its valence shell."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3307,
        "content": [
          "$$NH_3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3308,
        "content": [
          "$$CCl_4$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3309,
        "content": [
          "$$H_2O$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3310,
        "content": [
          "$$PCl_5$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 828,
    "content": [
      "Which of the following pair is true about the general properties of the different types of crystalline solids",
      "images/chemistry/year_2013/q23_1.png"
    ],
    "explanation": [
      "- Ionic solids are hard, have high melting points, and conduct electricity when dissolved in water or molten.\n- Metallic solids have hardness ranging from soft to hard, have melting points ranging from low to high, and are good conductors of electricity and heat.\n\nTherefore, statements I and IV are true."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2013/q23_1.png"
    ],
    "choices": [
      {
        "id": 3311,
        "content": [
          "I and III"
        ],
        "isCorrect": false
      },
      {
        "id": 3312,
        "content": [
          "II and III"
        ],
        "isCorrect": false
      },
      {
        "id": 3313,
        "content": [
          "I and II"
        ],
        "isCorrect": false
      },
      {
        "id": 3314,
        "content": [
          "I and IV"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 829,
    "content": [
      "When the boiling point of hydrides of group VIA elements, $$H_2O$$, $$H_2S$$, $$H_2Se$$ and $$H_2Te$$ are arranged in the order of increasing boiling point. The trend is $$H_2Te < H_2Se < H_2S < H_2O$$, water having the highest boiling point, this is due to"
    ],
    "explanation": [
      "The high boiling point of water compared to other hydrides of group VIA elements is primarily due to the presence of strong hydrogen bonds between water molecules. These hydrogen bonds require additional energy to break during boiling, leading to a higher boiling point."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3315,
        "content": [
          "the small size of O compared to the other group VIA elements."
        ],
        "isCorrect": false
      },
      {
        "id": 3316,
        "content": [
          "the basic different structures of each hydride."
        ],
        "isCorrect": false
      },
      {
        "id": 3317,
        "content": [
          "increasing boiling points with increasing molecular mass."
        ],
        "isCorrect": false
      },
      {
        "id": 3318,
        "content": [
          "hydrogen bonding present in $$H_2O$$ molecules."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 830,
    "content": [
      "Given the following catalyzed reactions",
      "I. $$2SO_2 (s) + O_2(g)$$ $$\\rightarrow$$ $$2SO_3 (g)$$; $$V_2O_5(s)$$ as a catalyst",
      "II. $$OCI^- (aq) + I^- (aq)$$ $$\\rightarrow$$ $$OI^- (aq) + Cl^- (aq)$$; $$OH^- (aq)$$ as inhibitor",
      "III. $$CO (s) + H_2(g)$$ $$\\rightarrow$$ $$CH_4 (g) + H_2O (g)$$; $$Ni(s)$$ as a catalyst",
      "IV. $$CO (s) + H_2(g)$$ $$\\rightarrow$$ $$HCHO (g)$$: $$Cu (s)$$ as a catalyst",
      "Which reactions is examples for homogeneous catalysis?"
    ],
    "explanation": [
      "Homogeneous catalysis occurs when the catalyst and the reactants are in the same phase. In reaction II, all species ($$OCI^-$$, $$I^-$$, $$OI^-$$, and $$Cl^-$$) are in the aqueous phase, thus representing homogeneous catalysis. The other reactions involve solid catalysts and gaseous or solid reactants, making them heterogeneous."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3319,
        "content": [
          "I and II"
        ],
        "isCorrect": false
      },
      {
        "id": 3320,
        "content": [
          "II"
        ],
        "isCorrect": true
      },
      {
        "id": 3321,
        "content": [
          "II and III"
        ],
        "isCorrect": false
      },
      {
        "id": 3322,
        "content": [
          "IV"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Chemical Kinetics"
  },
  {
    "id": 831,
    "content": [
      "Which statement is true about catalysts?"
    ],
    "explanation": [
      "Catalysts function by lowering the activation energy of a reaction, thereby increasing the rate of reaction. Catalysts are not consumed in the reaction process.\n\nPositive catalysts lower the activation energy, while negative catalysts (inhibitors) increase the activation energy, affecting the reaction rate."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3323,
        "content": [
          "A catalyst slows down or speeds up a reaction, itself being consumed."
        ],
        "isCorrect": false
      },
      {
        "id": 3324,
        "content": [
          "A positive catalyst decreases the rate of a reaction by increasing the activation energy."
        ],
        "isCorrect": false
      },
      {
        "id": 3325,
        "content": [
          "A negative catalyst increases the rate of a reaction by decreasing the value of activation energy."
        ],
        "isCorrect": false
      },
      {
        "id": 3326,
        "content": [
          "The role of a catalyst is to increase or decrease the rate of a reaction by lowering or increasing the activation energy."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Chemical Kinetics"
  },
  {
    "id": 832,
    "content": [
      "According to the transition state theory"
    ],
    "explanation": [
      "According to transition state theory, during a reaction, reactants pass through a transition state where the original bonds are weakened and new bonds are partially formed in an activated complex. This complex represents the highest energy point in the reaction pathway between reactants and products."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3327,
        "content": [
          "the collision between two reacting species results in the formation of an activated complex, which has less energy than both the reactants and products."
        ],
        "isCorrect": false
      },
      {
        "id": 3328,
        "content": [
          "in the activated complex, the original bonds are weakened and the new bonds are partially formed."
        ],
        "isCorrect": true
      },
      {
        "id": 3329,
        "content": [
          "the activation energy is the energy that must be absorbed or released by reactants to reach the activated complex."
        ],
        "isCorrect": false
      },
      {
        "id": 3330,
        "content": [
          "the standard reaction enthalpy ($$\\Delta H^0$$) depends on the magnitude of the activation energy ($$E_a$$)."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 833,
    "content": [
      "Which of the following is true about the rate constant?"
    ],
    "explanation": [
      "The rate constant ($$k$$) is a measure of the reaction rate; a larger $$k$$ indicates a faster reaction, while a smaller $$k$$ indicates a slower reaction."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3331,
        "content": [
          "It expresses the relationship between the rate of a chemical reaction and the volume of reacting species."
        ],
        "isCorrect": false
      },
      {
        "id": 3332,
        "content": [
          "The value of a rate constant tells us how fast or slow a reaction is."
        ],
        "isCorrect": true
      },
      {
        "id": 3333,
        "content": [
          "The value of a rate constant is independent of reaction conditions."
        ],
        "isCorrect": false
      },
      {
        "id": 3334,
        "content": [
          "A small rate constant indicates a faster reaction and a larger rate constant indicates a slower reaction."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Chemical Kinetics"
  },
  {
    "id": 834,
    "content": [
      "For a first order reaction, the concentration versus time of the reaction mixture is given by the following graph",
      "images/chemistry/year_2013/q29_1.png",
      "If a is the initial concentration of the reactant and if the half-life is 1hr, after how many hours would be the concentration of reactant reduced to a/32?"
    ],
    "explanation": [
      "For a first-order reaction, the concentration reduces by half in each half-life period. The half-life is given as 1 hour. To reach a/32, the concentration must halve 5 times ($$1/2^5 = 1/32$$). Therefore, it will take 5 half-lives, which equals 5 hours."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2013/q29_1.png"
    ],
    "choices": [
      {
        "id": 3335,
        "content": [
          "1 hr"
        ],
        "isCorrect": false
      },
      {
        "id": 3336,
        "content": [
          "4 hr"
        ],
        "isCorrect": false
      },
      {
        "id": 3337,
        "content": [
          "5 hr"
        ],
        "isCorrect": true
      },
      {
        "id": 3338,
        "content": [
          "3 hr"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 1,
    "unitName": "Acid Base Equilibria"
  },
  {
    "id": 835,
    "content": [
      "The mathematical expression\n$$\nlog \\ k = (\\frac{-E_a}{2.303 R})\\frac{1}{T} + log \\ A\n$$\nderived from the Arrhenius equation is of important as it shows"
    ],
    "explanation": [
      "The equation shows that as temperature (T) increases, the value of log k increases, assuming $$E_a$$ and A are constant. This is because the term $$(\\frac{-E_a}{2.303 R})\\frac{1}{T}$$ becomes less negative, resulting in a larger log k and, consequently, a larger rate constant k."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3339,
        "content": [
          "reactions with larger activation energies have higher values of k and are therefore faster."
        ],
        "isCorrect": false
      },
      {
        "id": 3340,
        "content": [
          "for a given value of activation energy the value of the rate constant increases as the temperature increases."
        ],
        "isCorrect": true
      },
      {
        "id": 3341,
        "content": [
          "reactions with larger activation energies, the value of the rate constant decreases as the temperature increases."
        ],
        "isCorrect": false
      },
      {
        "id": 3342,
        "content": [
          "for a given value of activation energy, the value of the rate constant decreases as the temperature increases."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Chemical Kinetics"
  },
  {
    "id": 836,
    "content": [
      "From the magnitude of the equilibrium constant, Keq one can deduce that"
    ],
    "explanation": [
      "A large $$K_{eq}$$ value indicates that at equilibrium, there is a high concentration of products compared to reactants. This implies that the reaction proceeds nearly to completion, leaving very little reactants remaining."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3343,
        "content": [
          "small Keq values indicate the reaction yields very higher amounts of products near equilibrium."
        ],
        "isCorrect": false
      },
      {
        "id": 3344,
        "content": [
          "large Keq value indicates that the reaction reaches equilibrium with very little reactants remaining."
        ],
        "isCorrect": true
      },
      {
        "id": 3345,
        "content": [
          "intermediate Keq value indicates that the reaction does proceed in the forward direction."
        ],
        "isCorrect": false
      },
      {
        "id": 3346,
        "content": [
          "Keq will be larger when we have higher amounts of reactants over products."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Chemical Equilibrium"
  },
  {
    "id": 837,
    "content": [
      "The statement 'If a system at equilibrium is subjected to a stress, the system will readjust itself to reduce the effects of the stress is known as"
    ],
    "explanation": [
      "Le Chatelier's principle states that if a system at equilibrium is subjected to a stress (such as a change in concentration, temperature, or pressure), the system will adjust itself to counteract the stress and restore a new equilibrium."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3347,
        "content": [
          "Faradays law"
        ],
        "isCorrect": false
      },
      {
        "id": 3348,
        "content": [
          "Avogadro's principle"
        ],
        "isCorrect": false
      },
      {
        "id": 3349,
        "content": [
          "Boyle's law"
        ],
        "isCorrect": false
      },
      {
        "id": 3350,
        "content": [
          "Le- Chatelier's principle"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Chemical Equilibrium"
  },
  {
    "id": 838,
    "content": [
      "The law of mass action states that"
    ],
    "explanation": [
      "The law of mass action states that the rate of a chemical reaction is directly proportional to the product of the activities or concentrations of the reactants raised to the power of their respective stoichiometric coefficients in the balanced chemical equation."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3351,
        "content": [
          "the rate of a reaction is directly proportional to the product of the concentration of reactants raised to the power of their respective coefficients in the balanced equation."
        ],
        "isCorrect": true
      },
      {
        "id": 3352,
        "content": [
          "the Keq expression is the ratio of the concentrations of reactants to the products raised to their coefficients."
        ],
        "isCorrect": false
      },
      {
        "id": 3353,
        "content": [
          "a chemical equilibrium is attained only when the reaction is started with reactants."
        ],
        "isCorrect": false
      },
      {
        "id": 3354,
        "content": [
          "for a reaction at equilibrium, the reaction quotient, Q is always less than the equilibrium constant, Keq."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 839,
    "content": [
      "For the reaction between gaseous $$NO$$ and $$O_2$$ to form $$NO_2(g)$$, what will be the equilibrium constant expression,",
      "$$2NO(g)$$ + $$O_2(g)$$ ⇌ $$2NO_2(g)$$"
    ],
    "explanation": [
      "The equilibrium constant expression $$K_c$$ for the given reaction $$2NO(g)$$ + $$O_2(g)$$ ⇌ $$2NO_2(g)$$ is determined by the ratio of the concentrations of the products to the reactants, each raised to the power of their stoichiometric coefficients. Therefore, the correct expression for $$K_c$$ is:\n$$\nKc = \\frac{[NO_2]^2}{[NO]^2[O_2]}\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3355,
        "content": [
          "$$Kc$$ = $$\\frac{[NO_2]^2}{[NO]^2[O_2]}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3356,
        "content": [
          "$$Kp$$ = $$\\frac{(P_{NO_2})}{(P_{NO})(P_{O_2})}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3357,
        "content": [
          "$$Kp$$ = $$\\frac{(P_{NO_2})^2}{[NO]^2[O_2]}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3358,
        "content": [
          "$$Kp$$ = $$\\frac{(P_{NO})^2(P_{O_2})}{(P_{NO_2})}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Chemical Equilibrium"
  },
  {
    "id": 840,
    "content": [
      "The equilibrium constant $$Kp$$ for the reaction $$2SO_3(g)$$ ⇌ $$2SO_2(g)$$ + $$O_2(g)$$ is $$3.8 \\times 10^{-3}$$ Kp at $$227^\\circ C$$. What is the value of $$Kc$$ for the reaction at the same temperature?"
    ],
    "explanation": [
      "To find $$K_c$$ from $$K_p$$, we use the relationship $$K_p = K_c (RT)^{\\Delta n}$$, where $$\\Delta n$$ is the change in the number of moles of gas in the reaction (products - reactants).\n\nHere, $$\\Delta n = (2 + 1) - 2 = 1$$. $$R$$ is the gas constant (8.314 J/mol·K), and $$T$$ is the temperature in Kelvin (227 + 273 = 500 K).\n\nRearranging for $$K_c$$ gives $$K_c = K_p / (RT)$$ = $$(3.8 \\times 10^{-3}) / (8.314 \\times 500)$$ $$\\approx 9.1 \\times 10^{-4}$$."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3359,
        "content": [
          "$$1.8 \\times 10^{-3} \\, mol \\, m^{-3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3360,
        "content": [
          "$$4.6 \\times 10^{-4} \\, mol \\, m^{-3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3361,
        "content": [
          "$$9.1 \\times 10^{-4} \\, mol \\, m^{-3}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3362,
        "content": [
          "$$2.3 \\times 10^{-3} \\, mol \\, m^{-3}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Chemical Equilibrium"
  },
  {
    "id": 841,
    "content": [
      "In the production of $$NH_3$$ by the Haber process according to the equation",
      "$$N_2(g)$$ + $$3H_2(g)$$ ⇌ $$2NH_3(g)$$ | $$\\Delta H = -92 \\, KJ \\, mol^{-1}$$",
      "What are the favorable conditions for the production of high yield of $$NH_3$$?"
    ],
    "explanation": [
      "The Haber process is an exothermic reaction ($$\\Delta H < 0$$), so according to Le Chatelier's principle, a low temperature will favor the production of $$NH_3$$. Since the reaction involves a decrease in the number of moles of gas (4 moles of reactants to 2 moles of product), a high pressure will also favor the production of $$NH_3$$. Therefore, the favorable conditions are high pressure and low temperature."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3363,
        "content": [
          "Law pressure and low temperature"
        ],
        "isCorrect": false
      },
      {
        "id": 3364,
        "content": [
          "High pressure and low temperature"
        ],
        "isCorrect": true
      },
      {
        "id": 3365,
        "content": [
          "High pressure and high temperature"
        ],
        "isCorrect": false
      },
      {
        "id": 3366,
        "content": [
          "Low pressure and high temperature"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Chemical Equilibrium"
  },
  {
    "id": 842,
    "content": [
      "Which one of the following statements describes laboratory and industrial preparation of acetic acid respectively?"
    ],
    "explanation": [
      "**Laboratory Preparation:**\n\n- Acetic acid can be prepared in the lab by oxidation of ethanol using an oxidizing agent like sodium dichromate in acidic medium.\n- This method is commonly used in organic chemistry laboratories.\n\n**Industrial Preparation:**\n\n- Acetic acid is industrially produced by fermentation of ethanol using acetic acid bacteria (*Acetobacter* species).\n- The process is called oxidative fermentation, where ethanol is oxidized to acetic acid.\n- This is the principle behind vinegar production."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3367,
        "content": [
          "Reduction of toluene by $$KMnO_4$$ and reduction of ethanol by sodium dichromate."
        ],
        "isCorrect": false
      },
      {
        "id": 3368,
        "content": [
          "Reduction of ethanol by $$NaBH_4$$ and fermentation of propanol."
        ],
        "isCorrect": false
      },
      {
        "id": 3369,
        "content": [
          "Oxidation of toluene by $$KMnO_4$$ and fermentation of ethanol."
        ],
        "isCorrect": true
      },
      {
        "id": 3370,
        "content": [
          "The oxidation of ethanol by sodium dichromate and fermentation of ethanol."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 843,
    "content": [
      "Which of the following is true about carboxylic acids?"
    ],
    "explanation": [
      "Carboxylic acids are characterized by the presence of a carboxyl group (-COOH), and their general formula is RCOOH, where R represents the alkyl or aryl group attached to the carboxyl group."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3371,
        "content": [
          "Carboxylic acid with the formula RCOOH."
        ],
        "isCorrect": true
      },
      {
        "id": 3372,
        "content": [
          "Methanoic, Ethanoic and Citric acids are monocarboxylic acids."
        ],
        "isCorrect": false
      },
      {
        "id": 3373,
        "content": [
          "Propanedioic acid is the simplest dicarboxylic acid."
        ],
        "isCorrect": false
      },
      {
        "id": 3374,
        "content": [
          "Citric acid is a typical dicarboxylic acid."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 844,
    "content": [
      "What is the IUPAC name for the branched carboxylic acid\n$$\nCH_3-CH(Cl)-CH(CH_3)-CH(CH_3)-COOH\n$$"
    ],
    "explanation": [
      "To name the compound, we need to identify the longest carbon chain containing the carboxylic acid group (-COOH). In this case, it is a pentanoic acid. The substituents are a chloro group at position 4 and methyl groups at positions 2 and 3. Therefore, the IUPAC name is 4-chloro-2,3-dimethylpentanoic acid."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3375,
        "content": [
          "1, 2-dimethyl-4-chloro 1-pentanoic acid."
        ],
        "isCorrect": false
      },
      {
        "id": 3376,
        "content": [
          "4-chloro-2, methyl 1-pentanoic acid."
        ],
        "isCorrect": false
      },
      {
        "id": 3377,
        "content": [
          "4-chloro-2, 3-dimethyl 1-pentanoic acid."
        ],
        "isCorrect": true
      },
      {
        "id": 3378,
        "content": [
          "4-chloro-1-methyl 1-pentanoic acid."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 845,
    "content": [
      "Esters are characterized by the following properties EXCEPT"
    ],
    "explanation": [
      "Esters are known for having pleasant odors, generally have lower boiling points than carboxylic acids and alcohols due to their inability to form strong hydrogen bonds, but they are not universally soluble in both inorganic and organic solvents; their solubility depends on the size and nature of the R groups.\n\n**Note:** We changed the choice “esters have **HIGHER** boiling point than carboxylic acid and alcohols.” from the paper to “esters have **LOWER** boiling point than carboxylic acid and alcohols.” in order to have a clear and unambiguous answer."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3379,
        "content": [
          "esters have pleasant odors of perfumes and food flavoring."
        ],
        "isCorrect": false
      },
      {
        "id": 3380,
        "content": [
          "esters have lower boiling point compared to the carboxylic acid and alcohols."
        ],
        "isCorrect": false
      },
      {
        "id": 3381,
        "content": [
          "all esters are soluble in inorganic solvents and organic."
        ],
        "isCorrect": true
      },
      {
        "id": 3382,
        "content": [
          "esters have lower boiling point than carboxylic acid and alcohols."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 846,
    "content": [
      "Oils are unsaturated fatty acids. The process of converting oils to solid fats involves"
    ],
    "explanation": [
      "Oils are converted to solid fats by hydrogenation, where hydrogen atoms are added to the C-C double bonds, reducing the degree of unsaturation and increasing the melting point."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3383,
        "content": [
          "esterification of the acids."
        ],
        "isCorrect": false
      },
      {
        "id": 3384,
        "content": [
          "saponification with $$NaOH$$."
        ],
        "isCorrect": false
      },
      {
        "id": 3385,
        "content": [
          "hydrogenation of the C-C double bonds."
        ],
        "isCorrect": true
      },
      {
        "id": 3386,
        "content": [
          "halogenations of the C-C double bonds."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 6,
    "unitName": "Hydrocarbons and Their Natural Sources"
  },
  {
    "id": 847,
    "content": [
      "A chemistry teacher has added different reactants and reagents in three different test tubes as described below",
      "I. Into the test tube A he added ethanol, sodium dichromate, and sulphuric acid.",
      "II. Into the test tube B he added acetaldehyde, sodium borohydride and water.",
      "III. Into the tube C he added methyl acetate and ethanol and sodium hydroxide.",
      "In which test tube would a reaction takes place that provide acetic acid?"
    ],
    "explanation": [
      "Acetic acid is produced by the oxidation of ethanol. In test tube A, ethanol is oxidized to acetic acid by sodium dichromate in the presence of sulfuric acid, which acts as a catalyst."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3387,
        "content": [
          "III"
        ],
        "isCorrect": false
      },
      {
        "id": 3388,
        "content": [
          "I and II"
        ],
        "isCorrect": false
      },
      {
        "id": 3389,
        "content": [
          "II and III"
        ],
        "isCorrect": false
      },
      {
        "id": 3390,
        "content": [
          "I"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Chemical Kinetics"
  },
  {
    "id": 848,
    "content": [
      "The difference between colloids and suspension is that"
    ],
    "explanation": [
      "Colloidal particles are smaller than the particles in a suspension. This smaller size allows colloidal particles to remain dispersed and prevents them from settling down, unlike the larger particles in a suspension, which will eventually settle out of the mixture."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3391,
        "content": [
          "colloidal particles are small enough and do not settle down unlike in a suspension."
        ],
        "isCorrect": true
      },
      {
        "id": 3392,
        "content": [
          "most colloids and suspensions appear cloudy."
        ],
        "isCorrect": false
      },
      {
        "id": 3393,
        "content": [
          "both colloids and suspensions are heterogeneous mixtures."
        ],
        "isCorrect": false
      },
      {
        "id": 3394,
        "content": [
          "colloids are as transparent as solutions."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 849,
    "content": [
      "The solubility of a substance is the amount of a substance that"
    ],
    "explanation": [
      "Solubility refers to the maximum amount of a solute that can dissolve in a solvent at a given temperature to form a saturated solution."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3395,
        "content": [
          "gives an unsaturated solution of the substance at given temperature."
        ],
        "isCorrect": false
      },
      {
        "id": 3396,
        "content": [
          "dissolves more amount of solute than it can normally dissolve."
        ],
        "isCorrect": false
      },
      {
        "id": 3397,
        "content": [
          "gives a saturated solution of the substance at a given temperature."
        ],
        "isCorrect": true
      },
      {
        "id": 3398,
        "content": [
          "dissolves double the amount of solute than it can normally dissolve."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 850,
    "content": [
      "50 mL of the supernatant saturated solution of $$NaCl$$ was taken in an evaporating dish (weight = $$w_0$$) and evaporated over a Bunsen burner until all the water has evaporated and dry sodium chloride is left in the evaporating dish. The evaporating dish with the dry sodium chloride is weighed (weight = $$w_1$$). Given the following information, $$w_0$$= 47.5 g and $$w_1$$ = 66.2. Calculate the solubility of $$NaCl$$ in water assuming 50 mL of the solution is equal to 50 mL of the solvent"
    ],
    "explanation": [
      "The mass of $$NaCl$$ is $$w_1 - w_0$$ = $$66.2 - 47.5$$ = $$18.7 \\, g$$. Assuming the density of water is 1 g/mL, 50 mL of water has a mass of 50 g. The mass of water in the solution is therefore 50 g. Solubility is expressed as g of solute per 100 g of water. So, $$S$$ = ($$18.7 \\, g \\, NaCl$$ / $$50 \\, g \\, water$$) $$\\times$$ $$100$$ = $$37.4 \\, g \\, NaCl$$ / $$100 \\, g \\, water$$."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3399,
        "content": [
          "37.4 g/100 g of water"
        ],
        "isCorrect": true
      },
      {
        "id": 3400,
        "content": [
          "113.7 g/100 g of water"
        ],
        "isCorrect": false
      },
      {
        "id": 3401,
        "content": [
          "18.7 g/100 g of water"
        ],
        "isCorrect": false
      },
      {
        "id": 3402,
        "content": [
          "187 g/100 g of water"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 851,
    "content": [
      "The \"like dissolves like \" rule accounts for one of the following observation"
    ],
    "explanation": [
      "The \"like dissolves like\" rule states that polar solvents dissolve polar solutes, and nonpolar solvents dissolve nonpolar solutes. Benzene ($$C_6H_6$$) is a nonpolar molecule, and carbon tetrachloride ($$CCl_4$$) is also a nonpolar solvent. Therefore, benzene is soluble in carbon tetrachloride because both are nonpolar."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3403,
        "content": [
          "The solubility of $$C_6H_6$$ in $$CCl_4$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3404,
        "content": [
          "The solubility of $$C_2H_6$$ in $$H_2O$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3405,
        "content": [
          "The solubility of $$KBr$$ in $$C_7H_8$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3406,
        "content": [
          "The insolubility of $$I_2$$ in $$H_2O$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 852,
    "content": [
      "Which of the following concentration units is correctly defined?"
    ],
    "explanation": [
      "Mass percentage is defined as the mass of the solute divided by the mass of the solution (solute + solvent), multiplied by 100. The correct formula is:\n$$\nMass \\, Percentage = \\frac{Mass \\, of \\, Solute}{Mass \\, of \\, Solution} \\times 100\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3407,
        "content": [
          "mass percentage = $$\\frac{mass \\, of \\, solute}{mass \\, of \\, solvent} \\times 100$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3408,
        "content": [
          "ppm (parts per million) = $$\\frac{mass \\, of \\, solute}{mass \\, of \\, solvent} \\times 10^6$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3409,
        "content": [
          "ppb (parts per billion) = $$\\frac{mass \\, of \\, solute}{mass \\, of \\, solution} \\times 10^6$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3410,
        "content": [
          "mass percentage = $$\\frac{mass \\, of \\, solute}{mass \\, of \\, solution} \\times 100$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 853,
    "content": [
      "The concentrated sulphuric acid $$H_2SO_4$$ we use in the laboratory is 98% $$H_2SO_4$$ by mass and has a density of 1.83 g/ mL. Below are given the concentrations of the acid in various units. which of the given alternatives correctly describes the concentration of the acid?"
    ],
    "explanation": [
      "The molar mass of H₂SO₄ is approximately 98 g/mol.\n\nGiven: 98% H₂SO₄  by mass, density = 1.83 g/mL\n\nIn 100 g of solution, there are 98 g of H₂SO₄. The volume of this solution is $$100 \\, g / 1.83 \\, g/mL$$ $$\\approx$$ $$54.64 \\, mL$$.\n\nTo find molarity (M): M = $$\\frac{moles \\, of \\, solute}{liters \\, of \\, solution}$$ = $$\\frac{98 \\, g / 98 \\, g/mol}{0.05464 \\, L}$$ = $$\\frac{1 \\, mol}{0.05464 \\, L} \\approx 18.3 \\, M$$\n\nNormality (N) is related to molarity by the number of equivalents per mole. For H2SO4, there are 2 acidic protons, so normality\n\nN = $$M \\times 2$$ = $$18.3 \\, M \\times 2$$ = $$36.6 \\, N$$.\n\nMole fraction (x) is the number of moles of solute divided by the total number of moles in the solution. Moles of H2SO4 = 1 mol (in 100 g solution).\n\nMoles of water = $$2 \\, g \\, H_2O / 18 \\, g/mol$$ $$\\approx$$ $$0.11 \\, mol$$.\n\nMole fraction = $$\\frac{1}{1 + 0.11}$$ $$\\approx$$ $$0.9$$"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3411,
        "content": [
          "Molarity = 18.3 M, Normality = 36.6 N, Mole fraction = 0.9"
        ],
        "isCorrect": true
      },
      {
        "id": 3412,
        "content": [
          "Molarity = 36.6 M, Normality = 18.3, N Mole fraction = 0.1"
        ],
        "isCorrect": false
      },
      {
        "id": 3413,
        "content": [
          "Molarity = 18.3 M, Normality = 3.66 N, Mole fraction = 0.9"
        ],
        "isCorrect": false
      },
      {
        "id": 3414,
        "content": [
          "Molarity = 1.83 M, Normality = 3.66 N, Mole fraction = 0.9"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 854,
    "content": [
      "How do you prepare 500mL of 1N $$Ca(OH)_2$$ solution? (Ca = 40, H = 1, O = 16)"
    ],
    "explanation": [
      "To prepare a **1N (Normal) solution** of **Ca(OH)₂**, we must determine the weight of **Ca(OH)₂** required per liter.\n\nThe molecular weight of **Ca(OH)₂** is: $$40$$ + $$(2 \\times 16)$$ + $$(2 \\times 1)$$ = $$74 \\text{ g/mol}$$\n\nSince **Ca(OH)₂** provides **2 hydroxide ions (OH⁻)** per molecule, the **equivalent weight** is:\n$$\n\\frac{74}{2} = 37 \\text{ g}\n$$\nBy definition, a **1N** solution contains **1 equivalent weight** (37 g) of solute per **liter** of solution.\nThus, for **1 liter of 1N solution**, we need **37 g of Ca(OH)₂**.\n\nSince 500 mL is **half of 1 liter**, we need half of 37 g:\n$$\n\\frac{37}{2} = 18.5 \\text{ g}\n$$\nOr we can dissolve 37g of $$Ca(OH)_2$$ in one liter and use 500ml from it to prepare 500mL of 1N $$Ca(OH)_2$$ solution,"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3415,
        "content": [
          "By dissolving 37 g of $$Ca(OH)_2$$ in 1 liter of solution."
        ],
        "isCorrect": true
      },
      {
        "id": 3416,
        "content": [
          "By dissolving 74 g of $$Ca(OH)_2$$ in 500.mL of solution."
        ],
        "isCorrect": false
      },
      {
        "id": 3417,
        "content": [
          "By dissolving 74 g of $$Ca(OH)_2$$ in 1 liter of solution."
        ],
        "isCorrect": false
      },
      {
        "id": 3418,
        "content": [
          "By dissolving 37 g of $$Ca(OH)_2$$ in 500.mL of solution."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 855,
    "content": [
      "The Ka of acetic acid $$CH_3COOH$$ is $$1.8 \\times 10^{-5}$$. What is the percent ionization of 1M $$CH_3COOH$$?"
    ],
    "explanation": [
      "**Note: We added the correct choice since the question on the paper has a mistake.**\n\nWe begin by writing the acid dissociation equilibrium for acetic acid:\n\n$$CH_3COOH$$ ⇌ $$H^+ + CH_3COO^-$$\n\nGiven that the initial concentration is 1 M and the acid dissociates by an amount x, at equilibrium we have:\n- $$[CH_3COOH] \\approx 1 - x \\approx 1$$ (since  is very small)\n- $$[H^+]$$ = $$x$$\n- $$[CH_3COO^-]$$ = $$x$$\n\nThe acid dissociation constant $$K_a$$ is given by:\n\n$$\nK_a = \\frac{[H^+][CH_3COO^-]}{[CH_3COOH]} \\approx \\frac{x^2}{1}\n$$\n\n$$\nx^2 = K_a = 1.8 \\times 10^{-5}\n$$\n\n$$\nx = \\sqrt{1.8 \\times 10^{-5}} \\approx 0.00424\n$$\n\n$$\n\\text{Percentage Ionization} = \\left(\\frac{x}{1}\\right) \\times 100\\% \\approx 0.424\\%\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3419,
        "content": [
          "3.6"
        ],
        "isCorrect": false
      },
      {
        "id": 3420,
        "content": [
          "1.42"
        ],
        "isCorrect": false
      },
      {
        "id": 3421,
        "content": [
          "1.34"
        ],
        "isCorrect": false
      },
      {
        "id": 3422,
        "content": [
          "4.2"
        ],
        "isCorrect": false
      },
      {
        "id": 3423,
        "content": [
          "0.42"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 856,
    "content": [
      "According to the Lewis definition of an acid, an acid is a substance that"
    ],
    "explanation": [
      "The Lewis definition of an acid states that an acid is a substance that can accept a pair of electrons."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3424,
        "content": [
          "dissociates in water to yield $$H_3O^+$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3425,
        "content": [
          "accepts a $$H^+$$ ion."
        ],
        "isCorrect": false
      },
      {
        "id": 3426,
        "content": [
          "donates an $$OH^-$$ ion."
        ],
        "isCorrect": false
      },
      {
        "id": 3427,
        "content": [
          "accepts a pair of electrons."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 857,
    "content": [
      "Water is a weak electrolyte, because"
    ],
    "explanation": [
      "Water is a weak electrolyte because it undergoes a reversible self-ionization (or dissociation) to a very small extent, resulting in a very low concentration of ions in the solution. This is reflected in its low ionic product, $$K_w$$."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3428,
        "content": [
          "it has a very high ionic product, Kw."
        ],
        "isCorrect": false
      },
      {
        "id": 3429,
        "content": [
          "it can accept a proton from an acid and donate a proton to a base."
        ],
        "isCorrect": false
      },
      {
        "id": 3430,
        "content": [
          "it undergoes a reversible dissociation with a very low ionic product, Kw."
        ],
        "isCorrect": true
      },
      {
        "id": 3431,
        "content": [
          "it acts both as Bronsted-Lowry acid and base."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 858,
    "content": [
      "Which of the following reactions represent the amphiprotic behavior of water"
    ],
    "explanation": [
      "Amphiprotic substances can act as both proton donors and proton acceptors.\n\nIn the correct option, water donates a proton to $$NH_3$$ in the second reaction and accepts a proton from $$HCl$$ in the first reaction."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3432,
        "content": [
          "$$HCl + H_2O$$ $$\\rightarrow$$ $$H^+ + Cl^-$$ and $$NaOH + H_2O$$ $$\\rightarrow$$ $$Na^+ + OH^-$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3433,
        "content": [
          "$$HCl + H_2O$$ ⇌ $$H_3O^+ + Cl^-$$ and $$NH_3 + H_2O$$ ⇌ $$NH_4^+ + OH^-$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3434,
        "content": [
          "$$H_3O^+ + OH^-$$ $$\\rightarrow$$ $$2H_2O$$ and $$H^+ + OH^-$$ $$\\rightarrow$$ $$H_2O$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3435,
        "content": [
          "$$H_2O + H^+$$ ⇌ $$H_3O^+$$ and $$NH_3 + H^+$$ ⇌ $$NH_4^+$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 859,
    "content": [
      "For an acidic solution, pH is less than 7. Since pH + pOH = pKw = 14 at 25°C, if pH < 7, then pOH > 7. Therefore, pH < pOH. And pKw - pH = pOH, so pOH > 7."
    ],
    "explanation": [
      "For an acidic solution, pH is less than"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3436,
        "content": [
          "pH = pOH and pH = 1/2pKw = 7"
        ],
        "isCorrect": false
      },
      {
        "id": 3437,
        "content": [
          "pH > pOH and pKw - pH < 7"
        ],
        "isCorrect": false
      },
      {
        "id": 3438,
        "content": [
          "pH < pOH and pKw - pH > 7"
        ],
        "isCorrect": true
      },
      {
        "id": 3439,
        "content": [
          "for acidic solution pH < 7 and [H⁺] < 1×10⁻⁷"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 860,
    "content": [
      "What is the pH of 0.25 M HF solution at 25°C. The ionization of the weak acid, HF is given by",
      "$$HF(aq) + H_2O(l)$$ ⇌ $$H_3O^+(aq) + F^-(aq)$$, ka for HF is $$6.8 \times 10^{-4}$$"
    ],
    "explanation": [
      "Let's assume $$x$$ is the concentration of $$H_3O^+$$ at equilibrium. Then, at equilibrium:\n- $$[H_3O^+]$$ = $$x$$\n- $$[F^-]$$ = $$x$$\n- $$[HF]$$ = $$0.25 - x$$\n\n$$K_a$$ = $$\\frac{[H_3O^+][F^-]}{[HF]}$$ = $$\\frac{x^2}{0.25 - x}$$ = $$6.8 \\times 10^{-4}$$\n\nAssuming x is small compared to 0.25, we can approximate 0.25 - x ≈ 0.25.\n\nTherefore, $$x^2$$ = ($$6.8$$ $$\\times$$ $$10^{-4}$$) $$\\times$$ $$0.25$$ = $$1.7$$ $$\\times$$ $$10^{-4}$$\n\n$$x$$ = $$\\sqrt{1.7 \\times 10^{-4}}$$ $$\\approx 0.01304$$.\n\nNow, we can calculate the pH using the formula pH = $$-log{[H_3O^+]}$$\n$$\npH = -log(0.01304) \\approx 1.89\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3440,
        "content": [
          "12.1"
        ],
        "isCorrect": false
      },
      {
        "id": 3441,
        "content": [
          "1.89"
        ],
        "isCorrect": true
      },
      {
        "id": 3442,
        "content": [
          "12.3"
        ],
        "isCorrect": false
      },
      {
        "id": 3443,
        "content": [
          "1.741"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 861,
    "content": [
      "One of the following given pairs represents examples of buffer systems"
    ],
    "explanation": [
      "A buffer solution is a mixture of a weak acid and its conjugate base or a weak base and its conjugate acid.\n\nThe pair $$NH_4OH/NH_4Cl$$ is a weak base (ammonium hydroxide) and its salt (ammonium chloride), and the pair $$CH_3COOH/CH_3COONa$$ is a weak acid (acetic acid) and its salt (sodium acetate). Therefore, both represent buffer systems."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3444,
        "content": [
          "$$NaOH/HCl$$ and $$HNO_3/KOH$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3445,
        "content": [
          "$$NH_4Cl/H_2O$$ and $$H_2O/CH_3COONa$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3446,
        "content": [
          "$$NH_4OH/CH_3COOH$$ and $$NH_4Cl/CH_3COONa$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3447,
        "content": [
          "$$NH_4OH/NH_4Cl$$ and $$CH_3COOH/CH_3COONa$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 862,
    "content": [
      "The reaction between a weak acid and strong base as represented by the reaction between acetic acid and NaOH gives a basic solution because\n$$\nCH_3COOH +NaOH \\longrightarrow Na^+ + CH_3COO^- + H_2O\n$$"
    ],
    "explanation": [
      "In the reaction between a weak acid and a strong base, the conjugate base of the weak acid ($$CH_3COO^-$$, acetate) is formed.\n\nAcetate can react with water to accept a proton (hydrolyze), forming $$CH_3COOH$$ and $$OH^-$$. This increases the concentration of $$OH^-$$ ions, resulting in a basic solution."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3448,
        "content": [
          "$$Na^+$$ is a strong acid and causes high concentration of $$H^+$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3449,
        "content": [
          "$$CH_3COO^-$$ as a strong base picks up $$H^+$$ and causes excess $$OH^-$$ ions."
        ],
        "isCorrect": true
      },
      {
        "id": 3450,
        "content": [
          "the $$OH^-$$ ions from $$NaOH$$ are not completely neutralized."
        ],
        "isCorrect": false
      },
      {
        "id": 3451,
        "content": [
          "$$CH_3COOH$$ does not produce sufficient amount of $$H^+$$ ions."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 863,
    "content": [
      "An acid is a substance that"
    ],
    "explanation": [
      "According to the Brønsted-Lowry definition, an acid is a substance that donates a proton (H+) in a chemical reaction."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3452,
        "content": [
          "has a bitter taste."
        ],
        "isCorrect": false
      },
      {
        "id": 3453,
        "content": [
          "produces more $$OH^-$$ ions in water than $$H^+$$ ions."
        ],
        "isCorrect": false
      },
      {
        "id": 3454,
        "content": [
          "donates a proton in a chemical reaction."
        ],
        "isCorrect": true
      },
      {
        "id": 3455,
        "content": [
          "donates a pair of electrons to a chemical species."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 864,
    "content": [
      "One of the following given masses of acids constitutes the corresponding equivalent of the acid"
    ],
    "explanation": [
      "The equivalent weight of an acid is calculated by dividing its molar mass by the number of ionizable hydrogen atoms (protons) it can donate.\n\nFor $$H_2SO_4$$:\n\n- **Molar mass:** $$98\\,\\text{g/mol}$$\n- **Proton donation:** is a diprotic acid, meaning it can donate 2 protons.\n- **Equivalent weight:** $$= \\frac{98\\,\\text{g/mol}}{2} = 49\\,\\text{g/equiv}$$\n\n$$\n\\frac{98\\,\\text{g}}{49\\,\\text{g/equiv}} = 2\\,\\text{equivalents}\n$$\nThus, 98 g of $$H_2SO_4$$ is equal to 2 equivalents"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3456,
        "content": [
          "$$H_2SO_4$$ = 98 g = 2 equivalent"
        ],
        "isCorrect": true
      },
      {
        "id": 3457,
        "content": [
          "$$HCl$$ = 36.5 g = 2 equivalents"
        ],
        "isCorrect": false
      },
      {
        "id": 3458,
        "content": [
          "$$H_2SO_4$$ = 49 g = 4 equivalents"
        ],
        "isCorrect": false
      },
      {
        "id": 3459,
        "content": [
          "$$H_3PO_4$$ = 98 g = 2 equivalents"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 865,
    "content": [
      "One of the following pairs shows Bronsted-Lowry acids behavior in water?"
    ],
    "explanation": [
      "According to the Bronsted-Lowry definition, an acid is a substance that donates a proton ($$H^+$$) in a reaction. In water:\n- $$HCl$$: This is a strong acid that donates a proton to water, forming hydronium ($$H_3O^+$$) and chloride ($$Cl^−$$)\n\n$$\n\\text{HCl} + \\text{H}_2\\text{O} \\rightarrow \\text{H}_3\\text{O}^+ + \\text{Cl}^-\n$$\n\n- $$NH_4^+$$: The ammonium ion is the conjugate acid of ammonia ($$NH_3$$) and can also donate a proton to water, forming hydronium and ammonia.\n\n$$\n\\text{NH}_4^+ + \\text{H}_2\\text{O} \\rightarrow \\text{H}_3\\text{O}^+ + \\text{NH}_3\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3460,
        "content": [
          "$$HNO_3$$ and $$NO_3^-$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3461,
        "content": [
          "$$H_3O^+$$ and $$NH_3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3462,
        "content": [
          "$$HPO_4^{2-}$$ and $$PO_4^{3-}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3463,
        "content": [
          "$$HCl$$ and $$NH_4^+$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 866,
    "content": [
      "In the reaction mixture of the two species $$NH_4OH$$ and $$NH_4Cl$$",
      "$$NH_4OH$$ ⇌ $$NH_4^+$$ + $$OH^-$$",
      "$$NH_4^+Cl^-$$ $$\\longrightarrow$$ $$NH_4^+$$ + $$Cl^-$$",
      "Which one of the is true about the reaction mixture?"
    ],
    "explanation": [
      "The addition of $$NH_4Cl$$ to the solution introduces $$NH_4^+$$ ions, which are common ions to the dissociation of $$NH_4OH$$.\n\nAccording to the common ion effect, the presence of $$NH_4^+$$ from $$NH_4Cl$$ suppresses the dissociation of the weak base $$NH_4OH$$, shifting the equilibrium to the left."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3464,
        "content": [
          "The $$NH_4^+$$ ion is a spectator ion in the reaction mixture."
        ],
        "isCorrect": false
      },
      {
        "id": 3465,
        "content": [
          "The presence of $$NH_4^+$$ ion suppresses the dissociation of the weak base $$NH_4OH$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3466,
        "content": [
          "The presence of $$NH_4^+$$ in the reaction mixture makes the solution more basic."
        ],
        "isCorrect": false
      },
      {
        "id": 3467,
        "content": [
          "The reaction equilibrium is shifted towards the right due to the presence of $$NH_4^+$$ ions."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 867,
    "content": [
      "Which one the following is correct about $$K_w$$ at different temperature?\nThe ionic product of water $$K_w$$ equals",
      "$$K_w$$ = $$1.0$$ $$\\times$$ $$10^{-14}$$ at $$25^\\circ C$$  |  $$\\sqrt{Kw}$$ = $$1$$ $$\\times$$ $$10^{-7}$$",
      "$$K_w$$ = $$2.92$$ $$\\times$$ $$10^{-14}$$ at $$40^\\circ C$$  |  $$\\sqrt{Kw}$$ = $$1$$ $$\\times$$ $$10^{-7}$$"
    ],
    "explanation": [
      "The value of $$K_w$$ increases with temperature, indicating that water dissociates to a greater extent at higher temperatures. Since $$K_w = [H^+][OH^-]$$, a higher $$K_w$$ means a higher concentration of both $$H^+$$ and $$OH^-$$."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3468,
        "content": [
          "Water is dissociate to a higher extent at $$40^\\circ C$$ than at $$25^\\circ C$$."
        ],
        "isCorrect": true
      },
      {
        "id": 3469,
        "content": [
          "At $$40^\\circ C$$ pure water is no more neutral."
        ],
        "isCorrect": false
      },
      {
        "id": 3470,
        "content": [
          "Hydrogen ion concentration at $$25^\\circ C$$ is higher than at $$40^\\circ C$$."
        ],
        "isCorrect": false
      },
      {
        "id": 3471,
        "content": [
          "Hydroxyl ion concentration is higher at $$40^\\circ C$$ than hydrogen ion concentration."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 868,
    "content": [
      "What is reduction? Reduction is"
    ],
    "explanation": [
      "Reduction is defined as the gain of electrons, which results in a decrease in oxidation number."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3472,
        "content": [
          "gain of electrons and increase in oxidation number."
        ],
        "isCorrect": false
      },
      {
        "id": 3473,
        "content": [
          "loss of electrons and decrease in oxidation number."
        ],
        "isCorrect": false
      },
      {
        "id": 3474,
        "content": [
          "gain of electrons and decrease in oxidation number."
        ],
        "isCorrect": true
      },
      {
        "id": 3475,
        "content": [
          "gain of electrons and no change in oxidation number."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 869,
    "content": [
      "During the electrolysis of dilute aqueous sulphuric acid, the ions present in solution are $$H^+$$, $$OH^−$$ and $$SO_4^{2−}$$. Which ions are preferentially discharged at the cathode and anode, respectively?"
    ],
    "explanation": [
      "At the cathode, $$H^+$$ ions are preferentially discharged over $$H_2O$$ due to their higher reduction potential in dilute acid.\n\nAt the anode, $$OH^−$$ ions are preferentially discharged over $$SO_4^{2−}$$ due to their lower oxidation potential."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3476,
        "content": [
          "Anode = $$4OH^−(aq)$$ $$\\rightarrow$$ $$H_2O(l)$$ + $$O_2(g)$$ + $$4e^−$$",
          "Cathode = $$2H^+(aq)$$ + $$2e^−$$ $$\\rightarrow$$ $$H_2(g)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3477,
        "content": [
          "Anode = $$SO_4^{2−}(aq)$$ + $$4H^+(aq)$$ + $$2e^−$$ $$\\rightarrow$$ $$SO_2(g)$$ + $$2H_2O$$",
          "Cathode = $$2H^+(aq)$$ + $$2e^−$$ $$\\rightarrow$$ $$H_2(g)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3478,
        "content": [
          "Anode = $$4OH^−(aq)$$ $$\\rightarrow$$ $$H_2O(l)$$ + $$O_2(g)$$ + $$4e^−$$",
          "Cathode = $$2H_2O(l)$$ + $$2e^−$$ $$\\rightarrow$$ $$H_2(g)$$ + $$2OH^−(aq)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3479,
        "content": [
          "Anode = $$2H_2O(l)$$ $$\\rightarrow$$ $$O_2(g)$$ + $$4H^+(aq)$$ + $$4e^−$$",
          "Cathode = $$2H^+(aq)$$ + $$2e^−$$ $$\\rightarrow$$ $$H_2(g)$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 870,
    "content": [
      "Which one of the following is NOT correct about electrodes and electrochemical cells?"
    ],
    "explanation": [
      "For a non-spontaneous process, the cell potential ($$E^o_{cell}$$) must be negative, not greater than zero.\n\nA spontaneous process has a positive cell potential, indicating that the reaction will occur without external energy input."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3480,
        "content": [
          "Electrons flow spontaneously from negative to positive electrode."
        ],
        "isCorrect": false
      },
      {
        "id": 3481,
        "content": [
          "The overall cell potential is calculated by the formula $$E^o_{cell}$$ = $$E_{cathode}$$ - $$E_{anode}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3482,
        "content": [
          "$$E^o_{cell}$$ is greater than zero for non-spontaneous process."
        ],
        "isCorrect": true
      },
      {
        "id": 3483,
        "content": [
          "The difference in the electrical potential of the electrode is positive that is positive cell."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Electrochemistry"
  },
  {
    "id": 871,
    "content": [
      "The mathematical expressions for Faraday's first law is summarized as"
    ],
    "explanation": [
      "Faraday's first law of electrolysis states that the amount of substance produced at an electrode during electrolysis is directly proportional to the quantity of electricity passed through the electrolyte. The correct mathematical expression is:\n$$\nm = \\frac{MIt}{nF}\n$$\nWhere m is the mass of the substance produced, M is the molar mass, I is the current, t is the time, n is the number of electrons transferred, and F is Faraday's constant."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3484,
        "content": [
          "$$n = \\frac{mIt}{MF}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3485,
        "content": [
          "$$m = \\frac{MIt}{nF}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3486,
        "content": [
          "$$M = \\frac{mIt}{nF}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3487,
        "content": [
          "$$m = \\frac{It}{F}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 872,
    "content": [
      "In the electrolysis of copper sulphate solution using graphite electrodes, $$O_2$$ is liberated at the anode and copper metal is deposited at the cathode. If the electrolysis of $$CuSO_4$$ is performed using copper electrode, what happens at the anode and cathode?"
    ],
    "explanation": [
      "When copper electrodes are used in the electrolysis of $$CuSO_4$$ solution, at the anode, the copper electrode dissolves (oxidizes) to form $$Cu^{2+}$$ ions in the solution.\n\nAt the cathode, $$Cu^{2+}$$ ions from the solution are reduced and deposited as copper metal on the cathode. This process is used in copper refining."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3488,
        "content": [
          "At the anode the copper electrode dissolves and copper metal is deposited at the cathode."
        ],
        "isCorrect": true
      },
      {
        "id": 3489,
        "content": [
          "At the anode $$H_2$$ is liberated, whereas copper is deposited at the cathode."
        ],
        "isCorrect": false
      },
      {
        "id": 3490,
        "content": [
          "At the anode copper is reduced, whereas copper is oxidized at the cathode."
        ],
        "isCorrect": false
      },
      {
        "id": 3491,
        "content": [
          "No electrochemical reaction takes place involving copper."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 873,
    "content": [
      "The statement 'the amount of a substance consumed or produced in an electrolytic cell is directly proportional to the amount of electricity that passes through the cell' is known as"
    ],
    "explanation": [
      "The statement describes **Faraday's law of electrolysis**, which states that the amount of a substance consumed or produced at the electrodes during electrolysis is directly proportional to the quantity of electricity passed through the electrolytic cell."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3492,
        "content": [
          "Dalton's law."
        ],
        "isCorrect": false
      },
      {
        "id": 3493,
        "content": [
          "Raoult's law."
        ],
        "isCorrect": false
      },
      {
        "id": 3494,
        "content": [
          "Faraday's law."
        ],
        "isCorrect": true
      },
      {
        "id": 3495,
        "content": [
          "Henry's law."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 874,
    "content": [
      "Given the following electromotive series of selected metals with their standard reduction potentials",
      "images/chemistry/year_2013/q69_1.png",
      "Which of the following statements is correct about reactivity of the metals?"
    ],
    "explanation": [
      "Potassium (K) is the strongest reducing agent among the listed metals. This is because it has the most negative standard reduction potential (-2.93 V). A more negative E° value signifies a greater tendency for the metal to undergo oxidation (lose electrons), thereby reducing another species."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2013/q69_1.png"
    ],
    "choices": [
      {
        "id": 3496,
        "content": [
          "Cu is the strongest reducing agent in the group."
        ],
        "isCorrect": false
      },
      {
        "id": 3497,
        "content": [
          "K is the strongest reduction agent among the metal silver."
        ],
        "isCorrect": true
      },
      {
        "id": 3498,
        "content": [
          "The reaction $$Cu + Zn^{2+} \\rightarrow Cu^{2+} + Zn$$ is spontaneous."
        ],
        "isCorrect": false
      },
      {
        "id": 3499,
        "content": [
          "Pb is more easily oxidized than Al"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 2,
    "unitName": "Electrochemistry"
  },
  {
    "id": 875,
    "content": [
      "One of the following is NOT true about the effects of corrosion?"
    ],
    "explanation": [
      "While some metals like aluminum do form a protective oxide layer, this is not a general characteristic of corrosion. Corrosion typically leads to the degradation and weakening of materials, rather than forming a protective layer."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_METALS_NONMETALS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3500,
        "content": [
          "It causes deterioration of metals by spontaneous chemical process."
        ],
        "isCorrect": false
      },
      {
        "id": 3501,
        "content": [
          "It causes enormous damage to buildings, bridges, ships and cars."
        ],
        "isCorrect": false
      },
      {
        "id": 3502,
        "content": [
          "Damage from corrosion costs billions of dollars annually."
        ],
        "isCorrect": false
      },
      {
        "id": 3503,
        "content": [
          "Corrosion forms protection oxide layers to prevent damage."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Metals and Non Metals"
  },
  {
    "id": 876,
    "content": [
      "In the Galvanic cell given in the diagram below",
      "images/chemistry/year_2013/q71_1_background.png",
      "identify the component parts correctly labelled for the letters a, b, c, d and choose the correct one among the following"
    ],
    "explanation": [
      "In a galvanic cell, the anode is the electrode where oxidation occurs, and the cathode is where reduction occurs.\n\nBased on the standard reduction potentials, zinc is more likely to be oxidized than copper, making the zinc electrode the anode and the copper electrode the cathode.\n\nThe salt bridge allows the flow of ions to maintain charge neutrality, and the voltmeter measures the potential difference between the two half-cells."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2013/q71_1_background.png"
    ],
    "choices": [
      {
        "id": 3504,
        "content": [
          "a: Zinc anode, b: copper cathode, c: salt bridge, d: voltmeter"
        ],
        "isCorrect": true
      },
      {
        "id": 3505,
        "content": [
          "a: Copper anode, b: Zinc cathode, c: voltmeter, d: salt"
        ],
        "isCorrect": false
      },
      {
        "id": 3506,
        "content": [
          "a: Zinc anode, b: Copper cathode, c: $$ZnSO_4(sol)$$, d: bridge salt"
        ],
        "isCorrect": false
      },
      {
        "id": 3507,
        "content": [
          "a: copper cathode, b: zinc anode, c: $$CuSO_4(sol)$$, d: voltmeter"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 877,
    "content": [
      "The conversion of nitrogen gas into useful nitrogen compounds is known as"
    ],
    "explanation": [
      "The conversion of nitrogen gas ($$N_2$$) into useful nitrogen compounds such as ammonia ($$NH_3$$), nitrate ($$NO_3^−$$), or nitrite ($$NO_2^−$$) is known as nitrogen fixation."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3508,
        "content": [
          "Respiration"
        ],
        "isCorrect": false
      },
      {
        "id": 3509,
        "content": [
          "Photosynthesis"
        ],
        "isCorrect": false
      },
      {
        "id": 3510,
        "content": [
          "Fixation"
        ],
        "isCorrect": true
      },
      {
        "id": 3511,
        "content": [
          "Oxidation"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 878,
    "content": [
      "$$CO_2$$ is released into the atmosphere by one of the following processes"
    ],
    "explanation": [
      "Natural fires and volcanoes release carbon dioxide ($$CO_2$$) into the atmosphere as they burn organic material or emit gases from the Earth's crust."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3512,
        "content": [
          "Plants consume atmospheric carbon dioxide during photosynthesis."
        ],
        "isCorrect": false
      },
      {
        "id": 3513,
        "content": [
          "Animals eat plants and release $$CO_2$$ by photosynthesis."
        ],
        "isCorrect": false
      },
      {
        "id": 3514,
        "content": [
          "Natural fires and volcanoes release $$CO_2$$ into the air."
        ],
        "isCorrect": true
      },
      {
        "id": 3515,
        "content": [
          "Utilization of electrical energy as energy sources."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Chemistry and it's Importance"
  },
  {
    "id": 879,
    "content": [
      "One of the following is NOT a common application of silicon"
    ],
    "explanation": [
      "Silicon is not commonly used for coating iron to prevent rusting. While silicon-based compounds can be used in protective coatings, it's not a primary or widespread method for this specific purpose, unlike applications such as galvanizing (using zinc)."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_METALS_NONMETALS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3516,
        "content": [
          "in the construction of transistors and microprocessors."
        ],
        "isCorrect": false
      },
      {
        "id": 3517,
        "content": [
          "in the control of the frequency of television transmissions."
        ],
        "isCorrect": false
      },
      {
        "id": 3518,
        "content": [
          "in the production of polish body parts cars."
        ],
        "isCorrect": false
      },
      {
        "id": 3519,
        "content": [
          "in coating iron to prevent it from rusting."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Metals and Non Metals"
  },
  {
    "id": 880,
    "content": [
      "One of the following is NOT among the chemical properties of silicon"
    ],
    "explanation": [
      "Silicon occurs as silica($$SiO_2$$) and silicate compounds containing the silicate ion ($$SiO_4^{-4}$$) is not a chemical property.\n\nIt describes silicon's natural occurrence, distinct from chemical properties which detail a substance's potential to undergo chemical change or reaction."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_METALS_NONMETALS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3520,
        "content": [
          "silicon reacts with $$CH_3Cl$$ at 300 °C in the Cu as a catalyst by further reactions with $$H_2O$$ yields the polymer $$[(CH_3)_2SiO_2]_n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3521,
        "content": [
          "silica is resistant to attack by all acids except HF, which it reacts to give $$SiF_4$$ and $$H_2O_2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3522,
        "content": [
          "silica dissolves in hot molten $$Na_2CO_3$$ to give $$Na_4SiO_4$$ and $$CO_2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3523,
        "content": [
          "silicon occurs as silica($$SiO_2$$) and silicate compounds containing the silicate ion ($$SiO_4^{-4}$$)"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Metals and Non Metals"
  },
  {
    "id": 881,
    "content": [
      "Which one the following is a common reaction of tin?"
    ],
    "explanation": [
      "Tin reacts with dilute hydrochloric acid ($$HCl$$) to produce tin(II) chloride ($$SnCl_2$$) and hydrogen gas ($$H_2$$). This is a common reaction for many metals, including tin, and is a typical acid-metal reaction."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3524,
        "content": [
          "$$Sn (s)$$ + $$dil.2HCl (aq)$$ $$\\rightarrow$$ $$SnCl_2 (aq)$$ + $$H_2 (g)$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3525,
        "content": [
          "$$Sn (s)$$ + $$H_2O (g)$$ $$\\rightarrow$$ $$SnO_2 (s)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3526,
        "content": [
          "$$Sn (s)$$ + $$2H_2O (g)$$ $$\\rightarrow$$ $$Sn(OH)_4 (s)$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3527,
        "content": [
          "$$Sn (s)$$ + $$2Cl_2 (g)$$ $$\\rightarrow$$ $$SnCl_2 (s)$$ in cold media"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 882,
    "content": [
      "The monomer of natural rubber is"
    ],
    "explanation": [
      "The monomer of natural rubber is isoprene, also known as 2-methyl-1,3-butadiene, and its chemical structure is\n$$\nCH_2=C(CH_3)-CH=CH_2\n$$"
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_POLYMER",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3528,
        "content": [
          "2-chloro-1,3-butadiene(chloroprene)",
          "$$\nH_2C=C(Cl)-CH=CH_2\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3529,
        "content": [
          "2-methyl-1,3-butadiene(isoprene)",
          "$$\nCH_2=C(CH_3)-CH=CH_2\n$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3530,
        "content": [
          "1,3-butadiene",
          "$$\nH_2C=CH-CH=CH_2\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3531,
        "content": [
          "images/chemistry/year_2013/q77c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Polymers"
  },
  {
    "id": 883,
    "content": [
      "All of the following are examples of addition polymers EXCEPT"
    ],
    "explanation": [
      "In addition polymerization, monomers add to one another in a way that the repeating unit has the same atoms as the monomer.\n$$\n-[CH_2CH_2]_n-[CH_2-CH(CH_3)]_n-\n$$\nThe structure represents a polymer system derived from two different monomer units (ethene and propene). Although formed through addition polymerization mechanisms, this describes a copolymer or a blend/mixture involving more than one type of repeating unit.\n\nThe other structures, are homopolymers, each formed from a single type of monomer."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_POLYMER",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3532,
        "content": [
          "$$\n-[CH_2-CH_2]_n-\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3533,
        "content": [
          "$$\n-[CH_2-CHCl]_n-\n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3534,
        "content": [
          "images/chemistry/year_2013/q78c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3535,
        "content": [
          "$$\n-[CH_2CH_2]_n-[CH_2-CH(CH_3)]_n-\n$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Polymers"
  },
  {
    "id": 884,
    "content": [
      "One of the following examples of polymers is correctly matched with its uses."
    ],
    "explanation": [
      "Polyvinyl chloride (PVC) is extensively and appropriately used for manufacturing pipes due to its durability, chemical resistance, and cost-effectiveness, representing a primary and widely recognized application."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_POLYMER",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3536,
        "content": [
          "Polyethylene; food containers"
        ],
        "isCorrect": false
      },
      {
        "id": 3537,
        "content": [
          "Polypropylene; electrical insulation"
        ],
        "isCorrect": false
      },
      {
        "id": 3538,
        "content": [
          "Polyvinyl chloride; making pipes"
        ],
        "isCorrect": true
      },
      {
        "id": 3539,
        "content": [
          "Polytetrafluoroethylene; making shoes"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Polymers"
  },
  {
    "id": 885,
    "content": [
      "Natural polymers are"
    ],
    "explanation": [
      "Natural polymers are polymers that are found in nature, such as rubber, starch, cellulose, proteins, and DNA. These substances are naturally occurring polymers."
    ],
    "year": "YEAR_2013",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_POLYMER",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3540,
        "content": [
          "polymers produced by the addition reaction of monomer units."
        ],
        "isCorrect": false
      },
      {
        "id": 3541,
        "content": [
          "polymers produced by condensation reaction of monomer units."
        ],
        "isCorrect": false
      },
      {
        "id": 3542,
        "content": [
          "polymers found in some substances like rubber in nature."
        ],
        "isCorrect": true
      },
      {
        "id": 3543,
        "content": [
          "polymers produced by the substitution of one or more atoms in the monomer units."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Polymers"
  },
  {
    "id": 946,
    "content": [
      "What are the molecular formulae of an alkene and alkyne containing seven carbon atoms, respectively?"
    ],
    "explanation": [
      "Alkenes have the general formula $$C_nH_{2n}$$, and alkynes have the general formula $$C_nH_{2n-2}$$.\n\nFor seven carbon atoms, the alkene formula would be $$C_7H_{14}$$, and the alkyne formula would be $$C_7H_{12}$$."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3784,
        "content": [
          "$$C_7H_{14}$$ and $$C_7H_{12}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3785,
        "content": [
          "$$C_7H_{16}$$ and $$C_7H_{14}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3786,
        "content": [
          "$$C_7H_{14}$$ and $$C_7H_{16}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3787,
        "content": [
          "$$C_7H_{12}$$ and $$C_7H_{14}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 6,
    "unitName": "Hydrocarbons and Their Natural Sources"
  },
  {
    "id": 947,
    "content": [
      "Which of the following is the CORRECT method of preparation of alkenes in the laboratory?"
    ],
    "explanation": [
      "Alkenes can be prepared by the dehydration of alcohols using concentrated sulfuric acid as a catalyst. This process removes a water molecule from the alcohol, forming a double bond and thus an alkene."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3788,
        "content": [
          "Alkylation of sodium acetylide with a primary alkyl halide."
        ],
        "isCorrect": false
      },
      {
        "id": 3789,
        "content": [
          "Heating of sodium salt of an organic acid with soda lime."
        ],
        "isCorrect": false
      },
      {
        "id": 3790,
        "content": [
          "Reaction of halogenated alkane with sodium."
        ],
        "isCorrect": false
      },
      {
        "id": 3791,
        "content": [
          "Dehydration of alcohols with concentrated sulfuric acid."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 948,
    "content": [
      "Which of the following is the CORRECT structure of benzene?"
    ],
    "explanation": [
      "Benzene is a cyclic hydrocarbon with the molecular formula $$C_6H_6$$, and its structure is typically represented as a hexagon with alternating double bonds, often depicted with a circle inside the hexagon to indicate delocalized electrons."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3792,
        "content": [
          "images/chemistry/year_2016/q3c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3793,
        "content": [
          "images/chemistry/year_2016/q3c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3794,
        "content": [
          "images/chemistry/year_2016/q3c3_1.png"
        ],
        "isCorrect": true
      },
      {
        "id": 3795,
        "content": [
          "images/chemistry/year_2016/q3c4_1.png"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 6,
    "unitName": "Hydrocarbons and Their Natural Sources"
  },
  {
    "id": 949,
    "content": [
      "Which of the following is the product of fractional distillation of crude oil?"
    ],
    "explanation": [
      "Fractional distillation of crude oil is a process that separates crude oil into different fractions based on their boiling points. Kerosene is one of the fractions obtained through this process."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3796,
        "content": [
          "Producer gas"
        ],
        "isCorrect": false
      },
      {
        "id": 3797,
        "content": [
          "Naphthalene"
        ],
        "isCorrect": false
      },
      {
        "id": 3798,
        "content": [
          "Water gas"
        ],
        "isCorrect": false
      },
      {
        "id": 3799,
        "content": [
          "Kerosene"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 950,
    "content": [
      "What is the molecular formula and IUPAC name of a saturated monocarboxylic acid having six carbon atoms?"
    ],
    "explanation": [
      "A saturated monocarboxylic acid with six carbons has the general formula $$C_6H_{12}O_2$$. This is derived from the structure $$RCOOH$$, where $$R$$ is a pentyl group $$C_5H_{11}$$. Combining $$C_5H_{11}$$ with $$COOH$$ gives $$C_5H_{11}COOH$$, which simplifies to $$C_6H_{12}O_2$$.\n\nThe IUPAC name is based on the longest carbon chain containing the carboxyl group. For six carbons, the chain includes the carboxyl carbon (numbered as position 1) followed by five additional carbons. This corresponds to **hexanoic acid**."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3800,
        "content": [
          "$$C_5H_{11}COOH$$, heptanoic acid"
        ],
        "isCorrect": false
      },
      {
        "id": 3801,
        "content": [
          "$$C_6H_{13}COOH$$, heptanoic acid"
        ],
        "isCorrect": false
      },
      {
        "id": 3802,
        "content": [
          "$$C_5H_{11}COOH$$, hexanoic acid"
        ],
        "isCorrect": true
      },
      {
        "id": 3803,
        "content": [
          "$$C_6H_{13}COOH$$, hexanoic acid"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 951,
    "content": [
      "Given the following structure:",
      "images/chemistry/year_2016/q6_1.png",
      "What is the IUPAC name for the above structure?"
    ],
    "explanation": [
      "The given structure is an ester. It's derived from ethanoic acid (acetic acid) and methanol. The IUPAC name is methyl ethanoate."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2016/q6_1.png"
    ],
    "choices": [
      {
        "id": 3804,
        "content": [
          "Methyl ethanoate"
        ],
        "isCorrect": true
      },
      {
        "id": 3805,
        "content": [
          "Ethyl ethanoate"
        ],
        "isCorrect": false
      },
      {
        "id": 3806,
        "content": [
          "Propyl formate"
        ],
        "isCorrect": false
      },
      {
        "id": 3807,
        "content": [
          "Ethyl acetate"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 952,
    "content": [
      "During summer, the average value for the temperature measured in a certain chemistry laboratory is 298.15 K. How many decimal places are there in the measured value?"
    ],
    "explanation": [
      "The number of decimal places is determined by counting the digits to the right of the decimal point. **298.15** has **two** decimal places."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3808,
        "content": [
          "5"
        ],
        "isCorrect": false
      },
      {
        "id": 3809,
        "content": [
          "3"
        ],
        "isCorrect": false
      },
      {
        "id": 3810,
        "content": [
          "2"
        ],
        "isCorrect": true
      },
      {
        "id": 3811,
        "content": [
          "1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 953,
    "content": [
      "Which of the following is the CORRECT Lewis electron - dot symbol of MgO? (Atomic number: Mg = 12 and O = 8)"
    ],
    "explanation": [
      "Magnesium (Mg) loses two electrons to become $$Mg^{2+}$$, and oxygen -O- gains two electrons to become $$O^{2-}$$. The Lewis dot symbol shows magnesium with a +2 charge and oxygen with a -2 charge and a complete octet."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3812,
        "content": [
          "images/chemistry/year_2016/q8c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3813,
        "content": [
          "images/chemistry/year_2016/q8c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3814,
        "content": [
          "images/chemistry/year_2016/q8c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3815,
        "content": [
          "images/chemistry/year_2016/q8c4_1.png"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 954,
    "content": [
      "A student collected four beakers in his/her laboratory and added some small amounts of the following: naphthalene to the first, graphite to the second, iodine to the third and alcohol to the fourth. If they added equal volume of water to each of the above beakers and shake each beaker, which of the following will be their observation?"
    ],
    "explanation": [
      "Naphthalene, graphite, and iodine are non-polar substances that are not soluble in water (a polar solvent). Alcohol, however, is soluble in water."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3816,
        "content": [
          "There will be dissolution in the first three breakers."
        ],
        "isCorrect": false
      },
      {
        "id": 3817,
        "content": [
          "Water will dissolve iodine rather than graphite."
        ],
        "isCorrect": false
      },
      {
        "id": 3818,
        "content": [
          "Water will dissolve the whole given chemicals in the four beakers."
        ],
        "isCorrect": false
      },
      {
        "id": 3819,
        "content": [
          "There will be dissolution of alcohol in the fourth beaker."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 955,
    "content": [
      "Which of the following explanations about reversible and irreversible reactions is CORRECT?"
    ],
    "explanation": [
      "An irreversible reaction is a chemical reaction that proceeds in one direction only: the reactants form products, but the products do not reform the reactants to any noticeable extent."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3820,
        "content": [
          "A reaction that has only a forward reaction or a reverse reaction is known as a reversible chemical reaction."
        ],
        "isCorrect": false
      },
      {
        "id": 3821,
        "content": [
          "A reaction that proceeds from reactant to product and from product to reactant is known as an irreversible reaction."
        ],
        "isCorrect": false
      },
      {
        "id": 3822,
        "content": [
          "Chemical reactions that proceed only towards the formation of a product are known as irreversible reactions."
        ],
        "isCorrect": true
      },
      {
        "id": 3823,
        "content": [
          "Chemical reactions that proceed only towards the formation of a product are known as reversible reactions."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 956,
    "content": [
      "Consider the following three steps:",
      "Step: 1 Electrolysis of water and fractional distillation of air",
      "Step: 2 Passing hot mixture of gases through a condenser",
      "Step: 3 Introducing hydrogen and nitrogen gases in a chamber containing iron particles at a temperature of 300-500 °C and a pressure of 15-25 MPa",
      "Which of the following is the CORRECT sequence involved during the industrial production of ammonia using the Haber process?"
    ],
    "explanation": [
      "Reactants (H₂, N₂) are first produced (Step 1), then reacted under catalytic conditions to form ammonia (Step 3), and finally, ammonia is separated by condensation (Step 2)."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3824,
        "content": [
          "Step 1 → Step 3 → Step 2"
        ],
        "isCorrect": true
      },
      {
        "id": 3825,
        "content": [
          "Step 2 → Step 3 → Step 1"
        ],
        "isCorrect": false
      },
      {
        "id": 3826,
        "content": [
          "Step 2 → Step 1 → Step 3"
        ],
        "isCorrect": false
      },
      {
        "id": 3827,
        "content": [
          "Step 1 → Step 2 → Step 3"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 957,
    "content": [
      "Which of the following is a physical property of nitric acid, $$HNO_3$$?"
    ],
    "explanation": [
      "A pungent smell is a physical property of nitric acid. Physical properties are those that can be observed without changing the substance's chemical identity."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3828,
        "content": [
          "On exposure to light, it turns brown."
        ],
        "isCorrect": false
      },
      {
        "id": 3829,
        "content": [
          "Nitric acid is a corrosive chemical."
        ],
        "isCorrect": false
      },
      {
        "id": 3830,
        "content": [
          "Nitric acid has a pungent smell."
        ],
        "isCorrect": true
      },
      {
        "id": 3831,
        "content": [
          "It forms large number of salts."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 958,
    "content": [
      "Which of the following is the CORRECT explanation about herbicides?"
    ],
    "explanation": [
      "Selective herbicides are designed to target and control specific weed species while leaving the desired crop unharmed. This selectivity is achieved through various mechanisms, such as differences in plant physiology or metabolism."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3832,
        "content": [
          "Selective herbicides control specific weed species, leaving the desired crop unharmed."
        ],
        "isCorrect": true
      },
      {
        "id": 3833,
        "content": [
          "Organochlorine compounds are the most common herbicide substances."
        ],
        "isCorrect": false
      },
      {
        "id": 3834,
        "content": [
          "Herbicides are substances that are used to control unwanted insects."
        ],
        "isCorrect": false
      },
      {
        "id": 3835,
        "content": [
          "Herbicides are substances that are used to enhance the growth of important plants."
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Introduction to Environmental Chemistry"
  },
  {
    "id": 959,
    "content": [
      "A student collected the following information from the community on the preparation of the local alcoholic drink \"ARAKI\":",
      "Step: 1 Distillation of the liquid mixture in traditional ways",
      "Step: 2 Adding a proportional amount of water to liquidity the tick dough-like mixture and leaving for 1-2 days for further fermentation",
      "Step: 3 \"Bikel\" preparation from barely, the starter (\"Tinses\") preparation by mixing the Bikel with Gesho (Rhamnuspronoides) powder and fermentation of the starter for few days",
      "Step: 4 Baking of bread from different ingredients and breaking down the bread and mixing with the fermented starter and leaving for fermentation for couple of days",
      "Which of the following is the correct procedure for the preparation of Araki?"
    ],
    "explanation": [
      "First, the starter (\"Tinses\") is prepared (Step 3). This starter is then used to ferment the main ingredients (bread) (Step 4). The resulting mixture is liquefied and undergoes further fermentation (Step 2). Finally, the fermented liquid is distilled (Step 1)."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3836,
        "content": [
          "Step - 2 → Step - 4 → Step - 3 → Step - 1"
        ],
        "isCorrect": false
      },
      {
        "id": 3837,
        "content": [
          "Step - 2 → Step - 3 → Step - 4 → Step - 1"
        ],
        "isCorrect": false
      },
      {
        "id": 3838,
        "content": [
          "Step - 3 → Step - 4 → Step - 2 → Step - 1"
        ],
        "isCorrect": true
      },
      {
        "id": 3839,
        "content": [
          "Step - 4 → Step - 3 → Step - 2 → Step - 1"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 960,
    "content": [
      "Which one of the following synthetic polymers is used to make squeeze bottles, plastic wrapping and electrical insulation?"
    ],
    "explanation": [
      "Polyethylene is widely used for squeeze bottles, plastic wrapping, and electrical insulation due to its flexibility, durability, and electrical insulating properties."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_POLYMER",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3840,
        "content": [
          "Polypropylene"
        ],
        "isCorrect": false
      },
      {
        "id": 3841,
        "content": [
          "Polymethyl methacrylate"
        ],
        "isCorrect": false
      },
      {
        "id": 3842,
        "content": [
          "Polyvinylchloride"
        ],
        "isCorrect": false
      },
      {
        "id": 3843,
        "content": [
          "Polyethylene"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Polymers"
  },
  {
    "id": 961,
    "content": [
      "Which of the following descriptions of the property of a covalent compound is CORRECT?"
    ],
    "explanation": [
      "Covalent compounds generally have low melting and boiling points because the intermolecular forces between the molecules are relatively weak compared to ionic compounds."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3844,
        "content": [
          "Covalent compounds have low melting and boiling points."
        ],
        "isCorrect": true
      },
      {
        "id": 3845,
        "content": [
          "Most covalent compounds are solids at room temperature."
        ],
        "isCorrect": false
      },
      {
        "id": 3846,
        "content": [
          "Most covalent compounds are soluble in water."
        ],
        "isCorrect": false
      },
      {
        "id": 3847,
        "content": [
          "Covalent compounds are non-volatile."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 962,
    "content": [
      "The attractive force between molecules is known as"
    ],
    "explanation": [
      "Intermolecular forces are the attractive or repulsive forces between molecules. These forces are responsible for many physical properties of matter, such as boiling point, melting point, and viscosity."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3848,
        "content": [
          "nuclear force"
        ],
        "isCorrect": false
      },
      {
        "id": 3849,
        "content": [
          "intermolecular force"
        ],
        "isCorrect": true
      },
      {
        "id": 3850,
        "content": [
          "lattice force"
        ],
        "isCorrect": false
      },
      {
        "id": 3851,
        "content": [
          "intramolecular forces"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 963,
    "content": [
      "The hybridization of the central atom xenon (Xe) in xenon tetraflouride, $$XeF_4$$, is $$sp^3d^2$$. Which of the following is the shape of $$XeF_4$$?"
    ],
    "explanation": [
      "In $$XeF_4$$, xenon is the central atom. Xenon has 8 valence electrons. There are four bonded pairs with fluorine atoms and two lone pairs. So, the structure is square planar."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3852,
        "content": [
          "Octahedral"
        ],
        "isCorrect": false
      },
      {
        "id": 3853,
        "content": [
          "Square planar"
        ],
        "isCorrect": true
      },
      {
        "id": 3854,
        "content": [
          "Tetrahedral"
        ],
        "isCorrect": false
      },
      {
        "id": 3855,
        "content": [
          "Seesaw shape"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 2,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 964,
    "content": [
      "Which of the following is the CORRECT electron configuration of a peroxide ion, $$O_2^{2-}$$?"
    ],
    "explanation": [
      "Oxygen has 8 electrons, so $$O_2$$ has 16 electrons. $$O_2^{2-}$$ has 18 electrons (16 + 2). The electronic configuration would be: $$(\\sigma_{1s})^2$$ $$(\\sigma^{1s})^2$$ $$(\\sigma{2s})^2$$ $$(\\sigma^{2s})^2$$ $$(\\sigma{2px})^2$$ $$(\\pi_{2py}$$ $$=$$ $$\\pi_{2pz})^4$$ $$(\\pi^{2py}$$ $$=$$ $$\\pi^*{2pz})^4$$."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_QUANTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3856,
        "content": [
          "$$(\\sigma_{1s})^2$$ $$(\\sigma^{1s})^2$$ $$(\\sigma{2s})^2$$ $$(\\sigma^{2s})^2$$ $$(\\sigma{2px})^2$$ $$(\\pi_{2py}$$ $$=$$ $$\\pi_{2pz})^2$$ $$(\\pi^*{2py})^2$$ $$(\\sigma^*_{2z})^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3857,
        "content": [
          "$$(\\sigma{1s})^2$$ $$(\\sigma^{1s})^2$$ $$(\\sigma{2s})^2$$ $$(\\sigma^{2s})^2$$ $$(\\sigma{2px})^2$$ $$(\\pi_{2py}$$ $$=$$ $$\\pi_{2pz})^2$$ $$(\\pi^*{2py}$$ $$=$$ $$\\pi^{2pz})^2$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3858,
        "content": [
          "$$(\\sigma{1s})^2$$ $$(\\sigma^{1s})^2$$ $$(\\sigma{2s})^2$$ $$(\\sigma^{2s})^2$$ $$(\\sigma{2px})^2$$ $$(\\pi_{2py}$$ $$=$$ $$\\pi_{2pz})^2$$ $$(\\pi^{2px})^2$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3859,
        "content": [
          "$$(\\sigma{1s})^2$$ $$(\\sigma^{1s})^2$$ $$(\\sigma{2s})^2$$ $$(\\sigma^{2s})^2$$ $$(\\sigma{2px})^2$$ $$(\\pi_{2py}$$ $$=$$ $$\\pi_{2pz})^2$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 965,
    "content": [
      "Consider the following reaction between nitrogen ($$N_2$$) and oxygen ($$O_2$$):\n$$\nN_2 (g) + O_2 (g) \\rightarrow 2NO (g)\n$$\nIf the rate of disappearance of $$N_2$$ is $$2.5 \\times 10^{-6} \\ M/s$$, what is the rate of reaction for the formation of NO?"
    ],
    "explanation": [
      "The rate of reaction is proportional to the stoichiometric coefficients in the balanced chemical equation.\n\nIn this reaction, for every one molecule of $$N_2$$ that disappears, two molecules of NO are formed. Therefore, the rate of formation of NO is twice the rate of disappearance of $$N_2$$.\n\nRate of formation of NO = $$2 \\times (2.5 \\times 10^{-6} \\text{ M/s})$$ = $$5.0 \\times 10^{-6} \\text{ M/s}$$."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3860,
        "content": [
          "$$5.0 \\times 10^{-6} \\ M/s$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3861,
        "content": [
          "$$1.25 \\times 10^{-3} M/s$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3862,
        "content": [
          "$$2.50 \\times 10^{-3} \\ M/s$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3863,
        "content": [
          "$$2.50 \\times 10^{-6} \\ M/s$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Chemical Kinetics"
  },
  {
    "id": 966,
    "content": [
      "Which of the following is a Lewis acid?"
    ],
    "explanation": [
      "A Lewis acid is a substance that can accept an electron pair. $$BF_3$$ is electron deficient and can accept a lone pair of electrons from a Lewis base."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3864,
        "content": [
          "$$SO_4^{2-}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3865,
        "content": [
          "$$SO_3^{2-}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3866,
        "content": [
          "$$BF_3$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3867,
        "content": [
          "$$NH_3$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 967,
    "content": [
      "The pH of a 0.10 M solution of an aqueous solution of a certain acid is 3. What is the value of acid ionization constant ($$K_a$$) of this acid?"
    ],
    "explanation": [
      "Given pH = 3, we can find the concentration of $$H^+$$ ions:\n$$\n[H^+] = 10^{-pH} = 10^{-3} \\text{ M}\n$$\nFor a weak acid HA, the dissociation is: $$HA$$ ⇌ $$H^+ + A^-$$",
      "|  | HA | H⁺ | A⁻ |\n| --- | --- | --- | --- |\n| Initial | 0.10 M | 0 | 0 |\n| Change | -x | +x | +x |\n| Equilibrium | 0.10 - x | x | x |",
      "Since the pH is 3, x = $$[H^+]$$ = $$10^{-3}$$\n\nThe acid ionization constant $$K_a$$ is given by:\n$$\nK_a = \\frac{[H^+][A^-]}{[HA]}\n$$\n$$\nK_a = \\frac{x^2}{0.10-x}\n$$\n$$\nK_a = \\frac{(10^{-3})^2}{0.10 - 10^{-3}} \\approx \\frac{10^{-6}}{0.10} = 10^{-5}\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3868,
        "content": [
          "$$1.0 \\times 10^{-7}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3869,
        "content": [
          "$$1.0 \\times 10^{-5}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3870,
        "content": [
          "$$1.0 \\times 10^{-3}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3871,
        "content": [
          "$$1.0 \\times 10^{-1}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 968,
    "content": [
      "The shift in the position of equilibrium caused by the addition of an ion already involved in the reaction is known as"
    ],
    "explanation": [
      "The common ion effect describes the decrease in the solubility of a sparingly soluble salt when a soluble salt containing a common ion is added to the solution."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3872,
        "content": [
          "common - ion effect"
        ],
        "isCorrect": true
      },
      {
        "id": 3873,
        "content": [
          "buffer - ion effect"
        ],
        "isCorrect": false
      },
      {
        "id": 3874,
        "content": [
          "hydrolysis - effect"
        ],
        "isCorrect": false
      },
      {
        "id": 3875,
        "content": [
          "titration -effect"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 969,
    "content": [
      "Which of the following is CORRECT about equivalents of acids and bases?"
    ],
    "explanation": [
      "The equivalent of an acid or base is the amount that reacts with one mole of hydroxide ions or hydrogen ions, respectively."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3876,
        "content": [
          "The volume of an acid or base required to reach equivalence point during acid - base titration reaction."
        ],
        "isCorrect": false
      },
      {
        "id": 3877,
        "content": [
          "The number of moles of an acid or base required to form a one molar aqueous acidic or basic solution."
        ],
        "isCorrect": false
      },
      {
        "id": 3878,
        "content": [
          "It is the amount of a substance that is required to react with one mole of hydroxide ions in redox reactions."
        ],
        "isCorrect": false
      },
      {
        "id": 3879,
        "content": [
          "It is the amount of a substance that is required to react with one mole of hydrogen ions in acid - base reactions."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 970,
    "content": [
      "A 250 mL solution is formed from 24.5 g of sulfuric acid (H₂SO₄). What is the normality of this solution? (Mt. wt. H₂SO₄ = 98 g/mol)"
    ],
    "explanation": [
      "First, calculate the number of moles of $$H_2SO_4$$:\n$$\nmoles = \\frac{mass}{molar \\ mass} = \\frac{24.5 \\ g}{98 \\ g/mol} = 0.25 \\ mol\n$$\nSince $$H_2SO_4$$ is a diprotic acid, its equivalent weight is half of its molar mass. Thus, 1 mol of $$H_2SO_4$$ is 2 equivalents.\n$$\nequivalents = moles \\times n_{factor}\n$$\n$$\nequivalents = 0.25 \\ mol \\times 2 = 0.5 \\ equivalents\n$$\nNormality is defined as equivalents per liter of solution:\n$$\nN = \\frac{equivalents}{volume \\ in \\ liters}\n$$\n$$\nN = \\frac{0.5 \\ equivalents}{0.250 \\ L} = 2.00 \\ N\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3880,
        "content": [
          "4.00 N"
        ],
        "isCorrect": false
      },
      {
        "id": 3881,
        "content": [
          "2.00 N"
        ],
        "isCorrect": true
      },
      {
        "id": 3882,
        "content": [
          "0.250 N"
        ],
        "isCorrect": false
      },
      {
        "id": 3883,
        "content": [
          "0.125 N"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 971,
    "content": [
      "Which of the following reaction is used for the preparation of bases?"
    ],
    "explanation": [
      "Active metal oxides react with water to form metal hydroxides, which are bases. For example, $$Na_2O + H_2O \\rightarrow 2NaOH$$."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3884,
        "content": [
          "Reaction of metal hydroxides with dilute acids."
        ],
        "isCorrect": false
      },
      {
        "id": 3885,
        "content": [
          "Reaction of active metal oxides with water."
        ],
        "isCorrect": true
      },
      {
        "id": 3886,
        "content": [
          "Heating of a salt with a non- volatile acid."
        ],
        "isCorrect": false
      },
      {
        "id": 3887,
        "content": [
          "Heating of carbonates with dilute acids."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 972,
    "content": [
      "Which of the following salts is used in the treatment of waste water?"
    ],
    "explanation": [
      "$$FeCl_3$$ (Ferric chloride) is commonly used in wastewater treatment as a coagulant to remove suspended solids and impurities. It helps in the flocculation process, where small particles clump together to form larger, more easily separable aggregates."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3888,
        "content": [
          "$$CaCO_3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3889,
        "content": [
          "$$BaSO_4$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3890,
        "content": [
          "$$FeCl_3$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3891,
        "content": [
          "$$KNO_3$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Introduction to Environmental Chemistry"
  },
  {
    "id": 973,
    "content": [
      "A student prepared two beakers, each containing 100 mL of water. The student dissolved 10 mL of concentrated $$HCl$$ in the first beaker and 10 mL of concentrated $$CH_3COOH$$ in the second beaker, which of the following would occur in the solution?"
    ],
    "explanation": [
      "$$HCl$$ is a strong acid and dissociates almost completely into ions in water. $$CH_3COOH$$ (acetic acid) is a weak acid and only a small fraction dissociates into ions in water."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3892,
        "content": [
          "In the first beaker, a large fraction of $$HCl$$ dissociates into ions and in the second beaker, a small fraction of $$CH_3COOH$$ dissociates into ions."
        ],
        "isCorrect": true
      },
      {
        "id": 3893,
        "content": [
          "In the first beaker, a small fraction of $$HCl$$ dissociates into ions and in the second beaker, a large fraction of $$CH_3COOH$$ dissociates into ions."
        ],
        "isCorrect": false
      },
      {
        "id": 3894,
        "content": [
          "There is no dissociation or ionization of the $$HCl$$ and $$CH_3COOH$$ in both the first and second beakers."
        ],
        "isCorrect": false
      },
      {
        "id": 3895,
        "content": [
          "The amount of $$HCl$$ dissociated in the first beaker and the amount of $$CH_3COOH$$ dissociated in the second beaker are identical."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 974,
    "content": [
      "Consider the following five - steps during the extraction of aluminum from its bauxite ore by the Hall process:",
      "I. Treating the mixture of an aqueous solution of sodium silicate and aluminate with an acid",
      "II. Heating aluminum oxide strongly in a furnace",
      "III. Heating the ore with sodium hydroxide solution",
      "IV. Conversion of aluminum oxide to soluble sodium aluminate",
      "V. Electrolysis of molten mixture of cryolite and aluminum oxide",
      "Which of the following is the CORRECT sequence of production?"
    ],
    "explanation": [
      "The correct sequence is:\n- Heating the ore with sodium hydroxide solution (III). This step is used to dissolve the aluminum oxide, forming sodium aluminate.\n- Conversion of aluminum oxide to soluble sodium aluminate (IV). Aluminum oxide is selectively dissolved in sodium hydroxide to form sodium aluminate.\n- Treating the mixture of an aqueous solution of sodium silicate and aluminate with an acid (I). After obtaining the sodium aluminate solution, carbon dioxide is bubbled through it to precipitate the aluminum hydroxide, while the silica remains in solution.\n- Heating aluminum oxide strongly in a furnace (II). Aluminum hydroxide is then calcined to obtain pure alumina.\n- Electrolysis of molten mixture of cryolite and aluminum oxide (V). Finally, the alumina is dissolved in molten cryolite and electrolyzed to produce aluminum metal."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_METALS_NONMETALS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3896,
        "content": [
          "III, IV, I, II and V"
        ],
        "isCorrect": true
      },
      {
        "id": 3897,
        "content": [
          "IV, II, I, III and V"
        ],
        "isCorrect": false
      },
      {
        "id": 3898,
        "content": [
          "V, I, II, IV and III"
        ],
        "isCorrect": false
      },
      {
        "id": 3899,
        "content": [
          "II, I, III, IV and V"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 5,
    "unitName": "Metals and Non Metals"
  },
  {
    "id": 975,
    "content": [
      "Which of the following food preservation methods leaves a product without loss of aroma or flavor?"
    ],
    "explanation": [
      "Freeze-drying (lyophilization) removes water from the product by sublimation, which occurs under low temperatures and vacuum conditions. This process minimizes the loss of volatile aromatic compounds, thus preserving the aroma and flavor of the food."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3900,
        "content": [
          "Vacuum - packing"
        ],
        "isCorrect": false
      },
      {
        "id": 3901,
        "content": [
          "Freeze - drying"
        ],
        "isCorrect": true
      },
      {
        "id": 3902,
        "content": [
          "Freezing"
        ],
        "isCorrect": false
      },
      {
        "id": 3903,
        "content": [
          "Melting"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 976,
    "content": [
      "The electronic configuration of an element in the periodic table is $$1s^22s^22p^63s^23p^64s^23d^{10}4p^5$$. In which block does this element belong?"
    ],
    "explanation": [
      "The given electronic configuration is:\n$$\n1s^22s^22p^63s^23p^64s^23d^{10}4p^5\n$$\nThe last electron enters the p-orbital, indicating that the element belongs to the p-block."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PERIODIC_TABLE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3904,
        "content": [
          "f - block"
        ],
        "isCorrect": false
      },
      {
        "id": 3905,
        "content": [
          "d - block"
        ],
        "isCorrect": false
      },
      {
        "id": 3906,
        "content": [
          "p - block"
        ],
        "isCorrect": true
      },
      {
        "id": 3907,
        "content": [
          "s - block"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Periodic Classification of Elements"
  },
  {
    "id": 977,
    "content": [
      "Consider the following chart of general periodic properties in the periodic table:",
      "images/chemistry/year_2016/q32_1.png",
      "From the given periodic properties, which one CORRECTLY agrees with the periodic trend in the chart?"
    ],
    "explanation": [
      "The chart shows that the property increases as you go down a group and decreases as you go across a period from left to right.\n\nAtomic radius generally increases down a group due to the addition of electron shells and decreases across a period due to increasing nuclear charge."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PERIODIC_TABLE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2016/q32_1.png"
    ],
    "choices": [
      {
        "id": 3908,
        "content": [
          "Electronegativity"
        ],
        "isCorrect": false
      },
      {
        "id": 3909,
        "content": [
          "Electron affinity"
        ],
        "isCorrect": false
      },
      {
        "id": 3910,
        "content": [
          "Ionization energy"
        ],
        "isCorrect": false
      },
      {
        "id": 3911,
        "content": [
          "Atomic radius"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 978,
    "content": [
      "Which of the following is CORRECT about the formation of a covalent bond?"
    ],
    "explanation": [
      "A covalent bond is formed by the sharing of valence electrons between atoms to achieve a stable electron configuration."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3912,
        "content": [
          "between positively and negatively charged ions."
        ],
        "isCorrect": false
      },
      {
        "id": 3913,
        "content": [
          "between mobile and stationary electrons."
        ],
        "isCorrect": false
      },
      {
        "id": 3914,
        "content": [
          "by the sharing of valence electrons."
        ],
        "isCorrect": true
      },
      {
        "id": 3915,
        "content": [
          "by the transfer of valence electrons."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 979,
    "content": [
      "The molecule of carbon tetrachloride ($$CCl_4$$) has four polar (C - Cl) bonds. However, $$CCl_4$$ is a non-polar molecule. Which of the following explains the reason for the observed property of $$CCl_4$$?"
    ],
    "explanation": [
      "$$CCl_4$$ is non-polar because the individual bond dipoles of the four $$C-Cl$$ bonds cancel each other out due to the symmetrical tetrahedral geometry of the molecule. Thus, the net dipole moment of the molecule is zero."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3916,
        "content": [
          "The molecule is non-polar because of the presence of four polar C- Cl bonds in the molecule."
        ],
        "isCorrect": false
      },
      {
        "id": 3917,
        "content": [
          "The molecule is non-polar because of the difference in electronegativity between carbon and chlorine."
        ],
        "isCorrect": false
      },
      {
        "id": 3918,
        "content": [
          "Even though the bond in $$CCl_4$$ is polar, the net dipole moment of the molecule is different from zero."
        ],
        "isCorrect": false
      },
      {
        "id": 3919,
        "content": [
          "Even though the bond in $$CCl_4$$ is polar, the net dipole moment of the molecule is zero."
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 980,
    "content": [
      "Which of the following is responsible for the unusual high boiling points of $$HF$$, $$H_2O$$ and $$NH_3$$?"
    ],
    "explanation": [
      "The unusually high boiling points of $$HF$$, $$H_2O$$, and $$NH_3$$ are due to hydrogen bonding.\n\nHydrogen bonding is a strong intermolecular force that occurs when hydrogen is bonded to highly electronegative atoms such as fluorine, oxygen, or nitrogen. This force is strong enough to significantly increase the boiling points of these compounds compared to similar compounds without hydrogen bonding."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3920,
        "content": [
          "London dispersion forces"
        ],
        "isCorrect": false
      },
      {
        "id": 3921,
        "content": [
          "Hydrogen bonding"
        ],
        "isCorrect": true
      },
      {
        "id": 3922,
        "content": [
          "Covalent bonding"
        ],
        "isCorrect": false
      },
      {
        "id": 3923,
        "content": [
          "Ionic bonding"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 981,
    "content": [
      "From the assumption of kinetic molecular theory of gases, which of the following is CORRECT?"
    ],
    "explanation": [
      "According to the kinetic molecular theory, gas particles are in constant, random motion, and the volume of the gas particles themselves is negligible compared to the space they occupy.\n\nTherefore, under ordinary conditions, the total volume of gas molecules is much smaller than the total volume of gas."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3924,
        "content": [
          "The pressure of a gas is the effect of the negligible volume of the gas compared to the total volume of the gas"
        ],
        "isCorrect": false
      },
      {
        "id": 3925,
        "content": [
          "The average kinetic energy of gas particles is inversely proportional to the absolute temperature of the gas."
        ],
        "isCorrect": false
      },
      {
        "id": 3926,
        "content": [
          "There are some forces of attraction or repulsion between gas particles."
        ],
        "isCorrect": false
      },
      {
        "id": 3927,
        "content": [
          "Under ordinary conditions, the total volume of gas molecules is much smaller than the total volume of gas."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 982,
    "content": [
      "Which of the following is CORRECT about the phase change observed in water?"
    ],
    "explanation": [
      "At the melting point of ice, the temperature remains constant because the energy added is used to break the intermolecular forces (hydrogen bonds) holding the solid structure together, rather than increasing the kinetic energy of the molecules (which would raise the temperature)."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3928,
        "content": [
          "Water starts to evaporate at the boiling point and condenses at the melting point."
        ],
        "isCorrect": false
      },
      {
        "id": 3929,
        "content": [
          "When a solid ice is heated, it is changed to liquuid water without melting."
        ],
        "isCorrect": false
      },
      {
        "id": 3930,
        "content": [
          "At the boiling point temperature, water exists in three different physical states."
        ],
        "isCorrect": false
      },
      {
        "id": 3931,
        "content": [
          "At the melting point of ice, the temperature remains constant."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 983,
    "content": [
      "Given the symbols of the three subatomic particles; electrons (e⁻), protons (p⁺) and neutrons (n⁰), which of the following is the CORRECT comparison of the absolute masses of protons, electrons and neutrons?"
    ],
    "explanation": [
      "The mass of an electron is significantly smaller than the mass of a proton, and the mass of a proton is slightly smaller than the mass of a neutron. Therefore, the correct relationship is: Mass of electron < Mass of proton < Mass of neutron."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3932,
        "content": [
          "Mass of e⁻ > mass of p⁺ = mass of n⁰"
        ],
        "isCorrect": false
      },
      {
        "id": 3933,
        "content": [
          "Mass of e⁻ = mass of p⁺ > mass of n⁰"
        ],
        "isCorrect": false
      },
      {
        "id": 3934,
        "content": [
          "Mass of e⁻ < mass of p⁺ < mass of n⁰"
        ],
        "isCorrect": true
      },
      {
        "id": 3935,
        "content": [
          "Mass of e⁻ > mass of p⁺ > mass of n⁰"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 984,
    "content": [
      "In the modern periodic table, what is the name of the group that contains the most electronegative elements?"
    ],
    "explanation": [
      "The group that contains the most electronegative elements in the periodic table is the halogens (Group 17). Electronegativity generally increases across a period and decreases down a group, making halogens the most electronegative group."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PERIODIC_TABLE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3936,
        "content": [
          "Alkali"
        ],
        "isCorrect": false
      },
      {
        "id": 3937,
        "content": [
          "Halogens"
        ],
        "isCorrect": true
      },
      {
        "id": 3938,
        "content": [
          "Chalcogens"
        ],
        "isCorrect": false
      },
      {
        "id": 3939,
        "content": [
          "Noble gases"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 985,
    "content": [
      "A given element has atomic number of 55 and mass number of 133. Which of the following describes CORRECTLY the property of this element?"
    ],
    "explanation": [
      "The element with an atomic number of 55 is Cesium (Cs), which belongs to Group 1 (Alkali Metals). Alkali metals are known for their high metallic character, as they readily lose their valence electron to form positive ions."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PERIODIC_TABLE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3940,
        "content": [
          "The non-metallic character of the element is high."
        ],
        "isCorrect": false
      },
      {
        "id": 3941,
        "content": [
          "The metallic character of the element is high."
        ],
        "isCorrect": true
      },
      {
        "id": 3942,
        "content": [
          "The element has high electron affinity."
        ],
        "isCorrect": false
      },
      {
        "id": 3943,
        "content": [
          "The element has high electronegativity."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 3,
    "unitName": "Periodic Classification of Elements"
  },
  {
    "id": 986,
    "content": [
      "Consider the mechanism for the decomposition of $$N_2O_5$$ to $$NO_2$$:",
      "First step: $$2N_2O_5 (g)$$ ⇌ $$N_4O_{10} (g)$$ (fast)",
      "Second step: $$N_4O_{10} (g)$$ $$\\rightarrow$$ $$N_2O_3 (g)$$ + $$2NO_2 (g)$$ + $$O_3 (g)$$ (slow)",
      "Third step: $$N_2O_3 (g)$$ + $$O_3 (g)$$ $$\\rightarrow$$ $$2NO_2 (g)$$ + $$O_2 (g)$$ (fast)",
      "Overall: $$2N_2O_5 (g)$$ $$\\rightarrow$$ $$4NO_2 (g)$$ + $$O_2 (g)$$",
      "Which step is the rate - determining step?"
    ],
    "explanation": [
      "The rate-determining step is the slowest step in a reaction mechanism. In this case, the second step is identified as the slow step, therefore, it is the rate-determining step."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3944,
        "content": [
          "Third step"
        ],
        "isCorrect": false
      },
      {
        "id": 3945,
        "content": [
          "First step"
        ],
        "isCorrect": false
      },
      {
        "id": 3946,
        "content": [
          "The overall step"
        ],
        "isCorrect": false
      },
      {
        "id": 3947,
        "content": [
          "Second step"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 987,
    "content": [
      "Consider the following reaction:",
      "$$N_2 (g)$$ + $$O_2 (g)$$ ⇌ $$2NO (g)$$",
      "The equilibrium concentrations of gaseous nitrogen, oxygen and nitrogen monoxide in a sealed container are as follows: $$[N_2]$$ = $$1 \\times 10^{-5} M$$, $$[O_2]$$ = $$2 \\times 10^{-5} M$$ and $$[NO]$$ = $$4 \\times 10^{-5} M$$.",
      "What is the value of the equilibrium constant for the reaction?"
    ],
    "explanation": [
      "The equilibrium constant, $$K$$, is given by:\n$$\nK = \\frac{[NO]^2}{[N_2][O_2]}\n$$\n$$\nK = \\frac{(4 \\times 10^{-5})^2}{(1 \\times 10^{-5})(2 \\times 10^{-5})} = 8\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3948,
        "content": [
          "8"
        ],
        "isCorrect": true
      },
      {
        "id": 3949,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 3950,
        "content": [
          "16"
        ],
        "isCorrect": false
      },
      {
        "id": 3951,
        "content": [
          "4"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Chemical Equilibrium"
  },
  {
    "id": 988,
    "content": [
      "At a certain temperature the following reaction has an equilibrium constant $$Kc = 12.4$$.",
      "$$N_2 (g) + 3H_2 (g)$$ ⇋ $$2NH_3 (g)$$",
      "If $$[N_2]$$ = $$2.0 M$$, $$[H_2]$$ = $$2.0 M$$ and $$[NH_3]$$ = $$10.0 M$$, to which direction will the reaction proceed to reach equilibrium?"
    ],
    "explanation": [
      "The reaction quotient, $$Q$$, is given by:\n$$\nQ = \\frac{[NH_3]^2}{[N_2][H_2]^3}\n$$\n$$\nQ = \\frac{(10.0)^2}{(2.0)(2.0)^3} = \\frac{100}{2.0 \\times 8.0} == 6.25\n$$\n\nSince $$Q_c$$ = $$6.25$$ and $$K_c$$ = $$12.4$$:\n\n- If $$Q_c < K_c$$, the reaction proceeds forward (toward products).\n- If $$Q_c > K_c$$, the reaction proceeds in the reverse direction (toward reactants).\n- If $$Q_c = K_c$$, the reaction is at equilibrium.\n\nSince $$Q_c$$ is **less than** $$K_c$$, the reaction will proceed in the **forward direction** to reach equilibrium."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3952,
        "content": [
          "The reaction will proceed to the reverse direction."
        ],
        "isCorrect": false
      },
      {
        "id": 3953,
        "content": [
          "The reaction is at a chemical equilibrium."
        ],
        "isCorrect": false
      },
      {
        "id": 3954,
        "content": [
          "The equilibrium is independent of the concentration."
        ],
        "isCorrect": false
      },
      {
        "id": 3955,
        "content": [
          "The reaction will proceed to the forward direction."
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Chemical Equilibrium"
  },
  {
    "id": 989,
    "content": [
      "Which of the following is the general formula for saturated monocarboxylic acids? (R is an alkyl group)"
    ],
    "explanation": [
      "The general formula for a saturated monocarboxylic acid is $$R-C(=O)-OH$$. This consists of an alkyl group (R) bonded to a carboxyl group (-COOH). The carboxyl group defines the compound as a carboxylic acid."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3956,
        "content": [
          "images/chemistry/year_2016/q44c1_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3957,
        "content": [
          "images/chemistry/year_2016/q44c2_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3958,
        "content": [
          "images/chemistry/year_2016/q44c3_1.png"
        ],
        "isCorrect": false
      },
      {
        "id": 3959,
        "content": [
          "images/chemistry/year_2016/q44c4_1.png"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 990,
    "content": [
      "Upon standing long, \"Tella\" or \"Tej\" turns sour. Which of the following is the CORRECT explanation for the observed effect?"
    ],
    "explanation": [
      "\"Tella\" or \"Tej\" turning sour upon standing is due to the oxidation of alcohol to an acid. Specifically, ethanol (alcohol) in the drink is oxidized to ethanoic acid (acetic acid), which has a sour taste."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3960,
        "content": [
          "The reduction of alcohol to an acid."
        ],
        "isCorrect": false
      },
      {
        "id": 3961,
        "content": [
          "The oxidation of alcohol to an acid."
        ],
        "isCorrect": true
      },
      {
        "id": 3962,
        "content": [
          "Addition reaction of alcohol with an acid."
        ],
        "isCorrect": false
      },
      {
        "id": 3963,
        "content": [
          "Decomposition reaction of alcohol."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 991,
    "content": [
      "A student is interested in determining the content of a leaf from his/her environment and performed the following.",
      "Step 1: He/she dried the leaves up in sun light",
      "Step 2: Evaluated the work and draw conclusions",
      "Step 3: Collected leaves from the tree around his village",
      "Step 4: He/she boiled the leaves and collected the leaves extracted",
      "Step 5: Analyze the content of the leaves extracted using an instrument\nWhich of the following is the CORRECT procedure if a student developed an experimental skill?"
    ],
    "explanation": [
      "The logical sequence of steps in this experiment would be:\n- **Collect leaves** (Step 3)\n- **Dry the leaves** (Step 1)\n- **Boil the leaves** (Step 4)\n- **Analyze the content** (Step 5)\n- **Evaluate the work and draw conclusions** (Step 2)"
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SCIENCE",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3964,
        "content": [
          "Steps: 3 → 5 → 4 → 1 → 2"
        ],
        "isCorrect": false
      },
      {
        "id": 3965,
        "content": [
          "Steps: 3 → 4 → 1 → 5 → 2"
        ],
        "isCorrect": false
      },
      {
        "id": 3966,
        "content": [
          "Steps: 3 → 1 → 4 → 5 → 2"
        ],
        "isCorrect": true
      },
      {
        "id": 3967,
        "content": [
          "Steps: 3 → 1 → 5 → 4 → 2"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 1,
    "unitName": "Chemistry and it's Importance"
  },
  {
    "id": 992,
    "content": [
      "Which of the following characteristics of an electromagnetic radiation is CORRECT?"
    ],
    "explanation": [
      "**Note: We added the correct choice since the question on the paper has a mistake.**\n\nThe speed of electromagnetic waves in a vacuum is always $$c = 3.00 \\times 10^8 m/s$$, regardless of their frequency or wavelength. This is a fundamental principle of physics derived from Maxwell's equations.\n\nThe other options are incorrect because the speed of electromagnetic waves does not change with wavelength or frequency in a vacuum, it does depend on the medium, and wavelength and frequency are inversely proportional ($$c = \\lambda f$$), not directly proportional."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_QUANTUM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3968,
        "content": [
          "The speed of an electromagnetic radiation decreases with increase in its wavelength."
        ],
        "isCorrect": false
      },
      {
        "id": 3969,
        "content": [
          "The speed of an electromagnetic radiation increases with increase in its frequency."
        ],
        "isCorrect": false
      },
      {
        "id": 3970,
        "content": [
          "The speed of electromagnetic radiation in a vacuum is constant and independent of its frequency or wavelength."
        ],
        "isCorrect": true
      },
      {
        "id": 3971,
        "content": [
          "The speed of an electromagnetic wave is independent of the nature of the medium it travels through."
        ],
        "isCorrect": false
      },
      {
        "id": 3972,
        "content": [
          "The wave length of an electromagnetic radiation is directly proportional to its frequency."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 993,
    "content": [
      "\"The hydrogen atom moves in a fixed circular orbit associated with allowable energy states\". This is called _______."
    ],
    "explanation": [
      "The statement \"The hydrogen atom moves in a fixed circular orbit associated with allowable energy states\" describes Bohr's theory.\n\nNiels Bohr proposed this model in 1913 to explain the discrete emission spectrum of hydrogen."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ATOM",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3973,
        "content": [
          "Planck's theory"
        ],
        "isCorrect": false
      },
      {
        "id": 3974,
        "content": [
          "Bohr's theory"
        ],
        "isCorrect": true
      },
      {
        "id": 3975,
        "content": [
          "Pauli's principle"
        ],
        "isCorrect": false
      },
      {
        "id": 3976,
        "content": [
          "Aufbau's principle"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 1,
    "unitName": "Atomic Structure and Periodic Properties of the Elements"
  },
  {
    "id": 994,
    "content": [
      "Which of the following is the core electron configuration of the metal ion in ferric sulfate, $$Fe_2(SO_4)_3$$? (Atomic Number of $$Fe = 26$$)"
    ],
    "explanation": [
      "In ferric sulfate, $$Fe_2(SO_4)_3$$, iron is in the $$Fe^{3+}$$ state.\n\nIron has an atomic number of 26, so its electron configuration is $$[Ar] 4s^2 3d^6$$.\n\nWhen it loses 3 electrons to become $$Fe^{3+}$$, it loses the two 4s electrons and one 3d electron, resulting in the configuration $$[Ar] 3d^5$$."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3977,
        "content": [
          "$$[Ar] 4s^23d^3$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3978,
        "content": [
          "$$[Ar] 4s^23d^6$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3979,
        "content": [
          "$$[Ar] 3d^5$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3980,
        "content": [
          "$$[Ar] 3d^6$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 995,
    "content": [
      "A chemical bond that results from the attractive force between shared electrons and nonmetal nucleus is called ________."
    ],
    "explanation": [
      "A covalent bond is a chemical bond that involves the sharing of electron pairs between atoms. These shared electrons create an attractive force between the positively charged nuclei of nonmetal atoms and the shared negatively charged electrons, holding the atoms together in a molecule."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3981,
        "content": [
          "covalent bond"
        ],
        "isCorrect": true
      },
      {
        "id": 3982,
        "content": [
          "ionic bond"
        ],
        "isCorrect": false
      },
      {
        "id": 3983,
        "content": [
          "hydrogen bond"
        ],
        "isCorrect": false
      },
      {
        "id": 3984,
        "content": [
          "metallic bond"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 996,
    "content": [
      "Which of the following is peroxide?"
    ],
    "explanation": [
      "A peroxide contains the peroxide ion, which is $$O_2^{2-}$$. In the given options, $$CaO_2$$ contains this ion, thus it is peroxide."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3985,
        "content": [
          "$$ZnO$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3986,
        "content": [
          "$$FeO$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3987,
        "content": [
          "$$K_2O$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3988,
        "content": [
          "$$CaO_2$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 997,
    "content": [
      "Among the following which one is a ternary acid?"
    ],
    "explanation": [
      "A ternary acid is an acid that contains three elements, typically hydrogen, oxygen, and another element (often a nonmetal).\n\nOut of the given options, $$H_2SO_4$$ (sulfuric acid) is the only one that fits this description, containing hydrogen, sulfur, and oxygen."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3989,
        "content": [
          "$$HBr$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3990,
        "content": [
          "$$HCl$$"
        ],
        "isCorrect": false
      },
      {
        "id": 3991,
        "content": [
          "$$H_2SO_4$$"
        ],
        "isCorrect": true
      },
      {
        "id": 3992,
        "content": [
          "$$H_2S$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 998,
    "content": [
      "A student collected few lemons from his/her backyard, brought it to their class and prepared a lemon juice in a beaker. They got blue and red litmus papers from his/her teacher and placed few drops of the lemon juice both on the red and blue litmus papers. What will be their observation on the litmus papers?"
    ],
    "explanation": [
      "Lemon juice is acidic due to the presence of citric acid.\n\nAcids turn blue litmus paper red. Red litmus paper remains red in acidic solutions. Therefore, the blue litmus paper will turn red, and the red litmus paper will maintain its color."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3993,
        "content": [
          "The blue litmus paper as well as the red litmus paper will maintain their color."
        ],
        "isCorrect": false
      },
      {
        "id": 3994,
        "content": [
          "The blue litmus paper and the red litmus paper will turn colorless."
        ],
        "isCorrect": false
      },
      {
        "id": 3995,
        "content": [
          "The red litmus paper will turn to blue and the blue litmus paper will maintain its color."
        ],
        "isCorrect": false
      },
      {
        "id": 3996,
        "content": [
          "The blue litmus paper will turn red and the red litmus paper will maintain its color."
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 999,
    "content": [
      "What is the $$pOH$$ of pure water at $$37^\\circ C$$, where $$K_w$$ equals $$2.50 \\times 10^{-14}$$ and its $$pH$$ is $$6.8$$? ($$log^{2.5} = 0.4$$)"
    ],
    "explanation": [
      "The relationship between **pH, pOH, and Kw** is given by:\n$$\npH + pOH = pK_w\n$$\n\nSince $$K_w$$ = $$2.50 \\times 10^{-14}$$ we calculate $$pK_w$$ as:\n$$\npK_w = -\\log (2.50 \\times 10^{-14})\n$$\nUsing the logarithm property:\n$$\n-\\log (2.50) - \\log (10^{-14})\n$$\n$$\n-0.4 + 14 = 13.6\n$$\nSince the pH of pure water at $$37^\\circ C$$ is given as **6.8**, we find pOH:\n$$\npOH = pK_w - pH\n$$\n$$\npOH = 13.6 - 6.8 = 6.8\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 3997,
        "content": [
          "8.8"
        ],
        "isCorrect": false
      },
      {
        "id": 3998,
        "content": [
          "8.2"
        ],
        "isCorrect": false
      },
      {
        "id": 3999,
        "content": [
          "6.8"
        ],
        "isCorrect": true
      },
      {
        "id": 4000,
        "content": [
          "7.5"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 1000,
    "content": [
      "The hydrogen ion concentration in a certain solution at $$25^\\circ C$$ is $$1.0 \\times 10^{-8} M$$. What is the pOH of this solution?"
    ],
    "explanation": [
      "First, calculate the pH:\n$$\npH = -log[H^+]\n$$\n$$\npH = -log(1.0 \\times 10^{-8}) = 8\n$$\nThen, use the relationship $$pH$$ + $$pOH$$ = $$14$$ to find the pOH:\n$$\npOH = 14 - 8 = 6\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4001,
        "content": [
          "8"
        ],
        "isCorrect": false
      },
      {
        "id": 4002,
        "content": [
          "10"
        ],
        "isCorrect": false
      },
      {
        "id": 4003,
        "content": [
          "2"
        ],
        "isCorrect": false
      },
      {
        "id": 4004,
        "content": [
          "6"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  },
  {
    "id": 1001,
    "content": [
      "Given the following oxidation - reduction reaction:\n$$\nH_2S + HNO_3 \\rightarrow S + NO + H_2O\n$$\nWhich of the following is CORRECT from the given equation?"
    ],
    "explanation": [
      "In this reaction, the oxidation number of sulfur increases from -2 in $$H_2S$$ to 0 in S, indicating that $$H_2S$$ is oxidized and acts as the reducing agent. The oxidation number of nitrogen decreases from +5 in $$HNO_3$$ to +2 in NO, indicating that $$HNO_3$$ is reduced and acts as the oxidizing agent. Thus, HNO3 is an oxidizing agent is the correct answer."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4005,
        "content": [
          "The oxidation number of N is increased."
        ],
        "isCorrect": false
      },
      {
        "id": 4006,
        "content": [
          "The oxidation number of S is decreased."
        ],
        "isCorrect": false
      },
      {
        "id": 4007,
        "content": [
          "S is a reducing substance."
        ],
        "isCorrect": false
      },
      {
        "id": 4008,
        "content": [
          "$$HNO_3$$ is an oxidizing agent."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 1002,
    "content": [
      "Consider the following diagram of an electrolytic cell:",
      "images/chemistry/year_2016/q57_1_background.png",
      "Which of the following is CORRECT from the given diagram?"
    ],
    "explanation": [
      "In this electrolytic cell, magnesium ions (Mg²⁺) migrate to the cathode and undergo reduction (Mg²⁺ + 2e⁻ → Mg). A species that is reduced (gains electrons) acts as an oxidizing agent. Therefore, the magnesium ion is an oxidizing agent. Oxidation (of Cl⁻) occurs at the anode, and its oxidation number increases."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [
      "images/chemistry/year_2016/q57_1_background.png"
    ],
    "choices": [
      {
        "id": 4009,
        "content": [
          "Oxidation takes place at the cathode."
        ],
        "isCorrect": false
      },
      {
        "id": 4010,
        "content": [
          "Reduction takes place at the anode."
        ],
        "isCorrect": false
      },
      {
        "id": 4011,
        "content": [
          "Magnesium ion is oxidizing agent in the electrode reaction."
        ],
        "isCorrect": true
      },
      {
        "id": 4012,
        "content": [
          "There is a decrease in oxidation number of chloride ion."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 1003,
    "content": [
      "Which of the following is CORRECT about molten electrolytes and aqueous electrolytes?"
    ],
    "explanation": [
      "During electrolysis, reduction always occurs at the cathode. In the case of molten electrolytes, only one type of cation is present, so its reduction occurs at the cathode."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4013,
        "content": [
          "The possible half reactions in molten electrolytes are more compared to aqueous electrolytes."
        ],
        "isCorrect": false
      },
      {
        "id": 4014,
        "content": [
          "Both molten and aqueous electrolytes involve preferential discharge of ions at each electrode."
        ],
        "isCorrect": false
      },
      {
        "id": 4015,
        "content": [
          "An electrolyte that conducts electricity when dissolved in a certain liquid is molten electrolyte."
        ],
        "isCorrect": false
      },
      {
        "id": 4016,
        "content": [
          "During the electrolysis of a molten electrolyte, the reduction of cations occurs at the cathode."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 1004,
    "content": [
      "Which of the following is NOT the industrial application of electrochemistry?"
    ],
    "explanation": [
      "Electrolytic refining, electroplating, and electrosynthesis are all industrial applications of electrochemistry.\n\nElectrolytic refining is used to purify metals, electroplating is used to coat metals with a thin layer of another metal, and electrosynthesis is used to produce chemicals.\n\nElectromagnetism, however, is not directly an industrial application of electrochemistry, though it is related to electricity and magnetism."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_ELECTROCHEMISTRY",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4017,
        "content": [
          "Electrolytic refining"
        ],
        "isCorrect": false
      },
      {
        "id": 4018,
        "content": [
          "Electroplating"
        ],
        "isCorrect": false
      },
      {
        "id": 4019,
        "content": [
          "Electromagnetism"
        ],
        "isCorrect": true
      },
      {
        "id": 4020,
        "content": [
          "Electro synthesis"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 4,
    "unitName": "Energy Changes and Electrochemistry"
  },
  {
    "id": 1005,
    "content": [
      "Which of the following chemical industries is INCORRECTLY matched with its products?"
    ],
    "explanation": [
      "The textile industry primarily deals with fabrics, yarns, and clothing, not glass. Therefore, the pairing of the textile industry with glasses is incorrect."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4021,
        "content": [
          "Textile industry- glasses"
        ],
        "isCorrect": true
      },
      {
        "id": 4022,
        "content": [
          "Beverage industry- alcohols"
        ],
        "isCorrect": false
      },
      {
        "id": 4023,
        "content": [
          "Food industry- Biscuits"
        ],
        "isCorrect": false
      },
      {
        "id": 4024,
        "content": [
          "Paper industry- cartons"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 3,
    "unitName": "Industrial Chemistry"
  },
  {
    "id": 1006,
    "content": [
      "A student added 25 mL of $$AgNO_3$$ solution to a beaker and weighed the mass of the beaker and its content as $$m_1$$. He/she added 50 mL of a saturated solution of $$NaCl$$ into the second beaker and weighed the mass of the beaker and its content as $$m_2$$. Finally, he/she mixed the two solutions and weighed the mass of the resulting solution with the two beakers and recorded as $$m_3$$. If he/she found that $$m_3$$ = $$m_1$$ + $$m_2$$, which one of the following laws is investigated by this trial?"
    ],
    "explanation": [
      "The law of conservation of mass states that mass is neither created nor destroyed in a chemical reaction. This means that the total mass of the reactants equals the total mass of the products."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4025,
        "content": [
          "Law of definite composition"
        ],
        "isCorrect": false
      },
      {
        "id": 4026,
        "content": [
          "Law of multiple proportions"
        ],
        "isCorrect": false
      },
      {
        "id": 4027,
        "content": [
          "Law of conservation of energy"
        ],
        "isCorrect": false
      },
      {
        "id": 4028,
        "content": [
          "Law of conservation of mass"
        ],
        "isCorrect": true
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 1007,
    "content": [
      "A chemical reaction that releases heat energy to the surrounding is known as"
    ],
    "explanation": [
      "An exothermic reaction is a chemical reaction that releases energy in the form of heat to the surroundings, causing the temperature of the surroundings to increase."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4029,
        "content": [
          "exothermic reaction"
        ],
        "isCorrect": true
      },
      {
        "id": 4030,
        "content": [
          "endothermic reaction"
        ],
        "isCorrect": false
      },
      {
        "id": 4031,
        "content": [
          "decomposition reaction"
        ],
        "isCorrect": false
      },
      {
        "id": 4032,
        "content": [
          "combination reaction"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 1008,
    "content": [
      "A type of reaction in which two compounds react together to form two or more products by exchanging reactants ions is known as"
    ],
    "explanation": [
      "A double displacement reaction is a type of chemical reaction where two reactants exchange ions to form two new compounds. This typically involves the exchange of ions between two ionic compounds in solution, leading to the formation of two different products."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4033,
        "content": [
          "Decomposition reaction"
        ],
        "isCorrect": false
      },
      {
        "id": 4034,
        "content": [
          "Combination reaction"
        ],
        "isCorrect": false
      },
      {
        "id": 4035,
        "content": [
          "Double Displacement reaction"
        ],
        "isCorrect": true
      },
      {
        "id": 4036,
        "content": [
          "Single Displacement reaction"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 1009,
    "content": [
      "\"At a given temperature and pressure, equal volumes of different gases contain equal number of molecules\", this is known as"
    ],
    "explanation": [
      "Avogadro's law states that at a given temperature and pressure, equal volumes of all gases contain the same number of molecules. This means that the number of molecules in a given volume of gas is independent of the size or mass of the gas molecules."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4037,
        "content": [
          "Charle's law"
        ],
        "isCorrect": false
      },
      {
        "id": 4038,
        "content": [
          "Boyle's law"
        ],
        "isCorrect": false
      },
      {
        "id": 4039,
        "content": [
          "Gay Lussac's law"
        ],
        "isCorrect": false
      },
      {
        "id": 4040,
        "content": [
          "Avogadro's law"
        ],
        "isCorrect": true
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 1010,
    "content": [
      "Which of the following includes the preconditions required for a chemical reaction to occur?"
    ],
    "explanation": [
      "For a chemical reaction to occur, the reactants must collide with sufficient energy (activation energy) and proper orientation. The reactants must also collide, making \"Activation energy, proper orientation and collision between reactants\" the correct answer."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4041,
        "content": [
          "Temperature, activation energy, proper orientation"
        ],
        "isCorrect": false
      },
      {
        "id": 4042,
        "content": [
          "Temperature, pressure and proper orientation"
        ],
        "isCorrect": false
      },
      {
        "id": 4043,
        "content": [
          "Activation energy, proper orientation and collision between reactants"
        ],
        "isCorrect": true
      },
      {
        "id": 4044,
        "content": [
          "Activation energy, pressure and collision between reactants"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 4,
    "unitName": "Chemical Kinetics"
  },
  {
    "id": 1011,
    "content": [
      "Consider the following reaction of zinc carbonate, $$ZnCO_3$$:\n$$\nZnCO_3(s) \\rightarrow ZnO(s) + CO_2(g)\n$$\nThe chemical reaction that takes place during the conversion of $$ZnCO_3$$ is classified as"
    ],
    "explanation": [
      "The given reaction is a decomposition reaction because a single reactant ($$ZnCO_3$$) breaks down into two or more products ($$ZnO$$ and $$CO_2$$)."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4045,
        "content": [
          "decomposition reaction"
        ],
        "isCorrect": true
      },
      {
        "id": 4046,
        "content": [
          "combination reaction"
        ],
        "isCorrect": false
      },
      {
        "id": 4047,
        "content": [
          "double displacement reaction"
        ],
        "isCorrect": false
      },
      {
        "id": 4048,
        "content": [
          "single displacement reaction"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 1012,
    "content": [
      "Given the following reaction:",
      "$$CaCO_3$$ + $$HCl$$ $$\\rightarrow$$ $$CaCl_2$$ + $$CO_2$$ + $$H_2O$$ (unbalanced)",
      "If 40 g of $$CaCO_3$$ reacts with 50 g of $$HCl$$, which substance is the limiting and which is the excess reagent? (Atomic Mass Ca = 40 g/mol, C = 12 g/mol, O = 16 g/mol, H =  1 g/mol and Cl = 35.5 g/mol)"
    ],
    "explanation": [
      "First, balance the equation:\n$$\nCaCO_3 + 2HCl \\rightarrow CaCl_2 + CO_2 + H_2O\n$$\n- Molar mass of $$CaCO_3$$ = 40 + 12 + (3 * 16) = 100 g/mol\n- Moles of $$CaCO_3$$ = 40 g / 100 g/mol = 0.4 mol\n- Molar mass of $$HCl$$ = 1 + 35.5 = 36.5 g/mol\n- Moles of $$HCl$$ = 50 g / 36.5 g/mol ≈ 1.37 mol\n\nFrom the balanced equation, 1 mol of $$CaCO_3$$ reacts with 2 mol of $$HCl$$. Therefore, 0.4 mol of $$CaCO_3$$ requires 0.8 mol of $$HCl$$. Since we have 1.37 mol of $$HCl$$, it is in excess.\n\nHence, $$CaCO_3$$ is the limiting reactant and $$HCl$$ is the excess reactant."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4049,
        "content": [
          "$$HCl$$ is limiting and $$CaCl_2$$ is excess reagents."
        ],
        "isCorrect": false
      },
      {
        "id": 4050,
        "content": [
          "$$HCl$$ is limiting and $$CaCO_3$$ is excess reactants."
        ],
        "isCorrect": false
      },
      {
        "id": 4051,
        "content": [
          "$$CaCO_3$$ is limiting and $$CaCl_2$$ is excess reagents."
        ],
        "isCorrect": false
      },
      {
        "id": 4052,
        "content": [
          "$$CaCO_3$$ is limiting and $$HCl$$ is excess reactants."
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 1,
    "unitName": "Chemical Reaction and Stoichiometry"
  },
  {
    "id": 1013,
    "content": [
      "A sample of a certain gas has a volume of 100 L at 27 °C and 750 torr. The gas is expanded to a volume of 250 L at 200 torr. What is the final temperature of the gas?"
    ],
    "explanation": [
      "We can use the combined gas law:\n$$\n\\frac{P_1V_1}{T_1} = \\frac{P_2V_2}{T_2}\n$$\nGiven:\n- $$P_1$$ = $$750 \\text{ torr}$$\n- $$V_1$$ = $$100 \\text{ L}$$\n- $$T_1$$ = $$27^\\circ C$$ = $$27 + 273.15$$ = $$300.15 \\text{ K}$$\n- $$P_2$$ = $$200 \\text{ torr}$$\n- $$V_2$$ = $$250 \\text{ L}$$\n\nSolve for $$T_2$$:\n$$\nT_2 = \\frac{P_2V_2T_1}{P_1V_1}\n$$\n$$\nT_2= \\frac{200 \\times 250 \\times 300.15}{750 \\times 100} = 200.1 \\text{ K}\n$$\nConvert to Celsius:\n$$\nT_2 = 200.1 - 273.15 = -73.05 ^\\circ C\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4053,
        "content": [
          "-83 °C"
        ],
        "isCorrect": false
      },
      {
        "id": 4054,
        "content": [
          "-73 °C"
        ],
        "isCorrect": true
      },
      {
        "id": 4055,
        "content": [
          "-17 °C"
        ],
        "isCorrect": false
      },
      {
        "id": 4056,
        "content": [
          "-273 °C"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 1014,
    "content": [
      "Which of the following is a CORRECT explanation of the given term?"
    ],
    "explanation": [
      "The boiling point is correctly defined as the temperature at which the vapor pressure of the liquid equals the atmospheric pressure. At this point, the liquid can overcome the surrounding pressure and change into a gaseous state."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_PHYSICAL_STATES",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4057,
        "content": [
          "Boiling point is the temperature at which the vapor pressure of the liquid equals the atmospheric pressure."
        ],
        "isCorrect": true
      },
      {
        "id": 4058,
        "content": [
          "Condensation is the process by which a liquid changes to a gas at the boiling point of the liquid."
        ],
        "isCorrect": false
      },
      {
        "id": 4059,
        "content": [
          "Normal boiling point is the temperature at which the liquid starts to be converted to the gaseous state."
        ],
        "isCorrect": false
      },
      {
        "id": 4060,
        "content": [
          "Heat of vaporization is the energy required to convert one gram of a solid to a gas at its boiling point."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 3,
    "unitName": "Physical State of Matter"
  },
  {
    "id": 1015,
    "content": [
      "Which of the following is the general formula of alkenes?"
    ],
    "explanation": [
      "Alkenes are unsaturated hydrocarbons that contain at least one carbon-carbon double bond. The general formula for alkenes is $$C_nH_{2n}$$, where n is the number of carbon atoms."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4061,
        "content": [
          "$$C_nH_{2n-2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4062,
        "content": [
          "$$C_nH_{2n+2}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4063,
        "content": [
          "$$C_nH_n$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4064,
        "content": [
          "$$C_nH_{2n}$$"
        ],
        "isCorrect": true
      }
    ],
    "grade": 10,
    "unit": 6,
    "unitName": "Hydrocarbons and Their Natural Sources"
  },
  {
    "id": 1016,
    "content": [
      "What are the two types of polymerizations?"
    ],
    "explanation": [
      "The two main types of polymerizations are addition polymerization and condensation polymerization. In addition polymerization, monomers add to each other in a chain reaction without the loss of any atoms. In condensation polymerization, monomers combine with the elimination of a small molecule, such as water."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_POLYMER",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4065,
        "content": [
          "Condensation and substitution polymerizations"
        ],
        "isCorrect": false
      },
      {
        "id": 4066,
        "content": [
          "Addition and decomposition polymerizations"
        ],
        "isCorrect": false
      },
      {
        "id": 4067,
        "content": [
          "Condensation and displacement polymerizations"
        ],
        "isCorrect": false
      },
      {
        "id": 4068,
        "content": [
          "Addition and condensation polymerizations"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Polymers"
  },
  {
    "id": 1017,
    "content": [
      "Which of the following is a monomer of natural rubber?"
    ],
    "explanation": [
      "Isoprene is the monomer of natural rubber. Natural rubber is a polymer of isoprene (2-methyl-1,3-butadiene), with the formula $$(C_5H_8)_n$$."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_POLYMER",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4069,
        "content": [
          "Ethylene terephthalate"
        ],
        "isCorrect": false
      },
      {
        "id": 4070,
        "content": [
          "Styrene"
        ],
        "isCorrect": false
      },
      {
        "id": 4071,
        "content": [
          "Hexamethylene diamine"
        ],
        "isCorrect": false
      },
      {
        "id": 4072,
        "content": [
          "Isoprene"
        ],
        "isCorrect": true
      }
    ],
    "grade": 12,
    "unit": 4,
    "unitName": "Polymers"
  },
  {
    "id": 1018,
    "content": [
      "The component of the environment consisting earth's upper outer most skin, and accessible to human beings is known as"
    ],
    "explanation": [
      "The lithosphere is the outermost layer of the Earth, consisting of the crust and the uppermost part of the mantle. It is the solid, rocky part of the Earth that humans can access, including mountains, soil, and landforms."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4073,
        "content": [
          "biosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 4074,
        "content": [
          "lithosphere"
        ],
        "isCorrect": true
      },
      {
        "id": 4075,
        "content": [
          "hydrosphere"
        ],
        "isCorrect": false
      },
      {
        "id": 4076,
        "content": [
          "atmosphere"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Introduction to Environmental Chemistry"
  },
  {
    "id": 1019,
    "content": [
      "Consider the following steps that occur during the nitrogen cycle:",
      "Step: 1 Reduction of nitrate by microbial action",
      "Step: 2 Fixation of nitrogen by bacteria and algae",
      "Step: 3 Nitrification by nitrosomas and nitrobactria",
      "Step: 4 Denitrification of nitrate with acid and formladyde",
      "Which of the following is the CORRECT sequence in the nitrogen cycle?"
    ],
    "explanation": [
      "The correct sequence in the nitrogen cycle is:\n- Fixation of nitrogen by bacteria and algae (Step 2)\n- Nitrification by nitrosomas and nitrobactria (Step 3)\n- Reduction of nitrate by microbial action (Step 1)\n- Denitrification of nitrate with acid and formladyde (Step 4)"
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_INORGANIC",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4077,
        "content": [
          "Step 2 → Step 3 → Step 4 → Step 1"
        ],
        "isCorrect": false
      },
      {
        "id": 4078,
        "content": [
          "Step 1 → Step 2 → Step 3 → Step 4"
        ],
        "isCorrect": false
      },
      {
        "id": 4079,
        "content": [
          "Step 2 → Step 3 → Step 1 → Step 4"
        ],
        "isCorrect": true
      },
      {
        "id": 4080,
        "content": [
          "Step 1 → Step 3 → Step 4 → Step 2"
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 3,
    "unitName": "Important Inorganic Compounds"
  },
  {
    "id": 1020,
    "content": [
      "Some hazardous substances damage and create unwanted changes in air, water, soil or any other natural resource. The resulting change created is known as:"
    ],
    "explanation": [
      "Pollution is the introduction of harmful substances or contaminants into the environment, including air, water, and soil, which can cause damage and unwanted changes to natural resources."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_APPLICATIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4081,
        "content": [
          "afforestation"
        ],
        "isCorrect": false
      },
      {
        "id": 4082,
        "content": [
          "pollution"
        ],
        "isCorrect": true
      },
      {
        "id": 4083,
        "content": [
          "greenhouse effect"
        ],
        "isCorrect": false
      },
      {
        "id": 4084,
        "content": [
          "global warming"
        ],
        "isCorrect": false
      }
    ],
    "grade": 12,
    "unit": 5,
    "unitName": "Introduction to Environmental Chemistry"
  },
  {
    "id": 1021,
    "content": [
      "Given the following heterogeneous reaction:",
      "$$CaCO_3(s)$$ ⇌ $$CaO(s)$$ + $$CO_2(g)$$",
      "What is the equilibrium constant expression for the above reaction?"
    ],
    "explanation": [
      "In the equilibrium constant expression, only gaseous and aqueous species are included. Solids and pure liquids are not included because their concentrations are considered constant.\n\nTherefore, the equilibrium constant expression for the given reaction is:\n$$\nK_c = [CO_2]\n$$"
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_REACTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4085,
        "content": [
          "$$K_c$$ = $$[CaO][CO_2]$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4086,
        "content": [
          "$$K_c$$ = $$\\frac{[CaO][CO_2]}{[CaCO_3]}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4087,
        "content": [
          "$$K_c$$ = $$[CO_2]$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4088,
        "content": [
          "$$K_c$$ = $$\\frac{[CaO]}{[CaCO_3]}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 5,
    "unitName": "Chemical Equilibrium"
  },
  {
    "id": 1022,
    "content": [
      "Which of the following statements is CORRECT regarding the properties of monocarboxylic acids?"
    ],
    "explanation": [
      "Carboxylic acids react with active metals to form salts and hydrogen gas. This is due to the acidic nature of the carboxyl group, which can donate a proton to form a salt."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_HYDROCARBONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4089,
        "content": [
          "Carboxylic acids react with active metals to form salt and hydrogen gas."
        ],
        "isCorrect": true
      },
      {
        "id": 4090,
        "content": [
          "The hydrolysis of carboxylic acids in water produces an ester and water."
        ],
        "isCorrect": false
      },
      {
        "id": 4091,
        "content": [
          "Carboxylic acids react with strong bases to form esters and water."
        ],
        "isCorrect": false
      },
      {
        "id": 4092,
        "content": [
          "Heating of carboxylic acid with alcohol produces salt and water."
        ],
        "isCorrect": false
      }
    ],
    "grade": 11,
    "unit": 6,
    "unitName": "Some Important Oxygen Containing Organic Compounds"
  },
  {
    "id": 1023,
    "content": [
      "What is the scientific notation for 0.0000055?"
    ],
    "explanation": [
      "The correct scientific notation for 0.0000055 is $$5.5 \\times 10^{-6}$$."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_MEASUREMENTS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4093,
        "content": [
          "$$55 \\times 10^{-7}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4094,
        "content": [
          "$$5.5 \\times 10^{-6}$$"
        ],
        "isCorrect": true
      },
      {
        "id": 4095,
        "content": [
          "$$55 \\times 10^{-5}$$"
        ],
        "isCorrect": false
      },
      {
        "id": 4096,
        "content": [
          "$$5.5 \\times 10^{-4}$$"
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 2,
    "unitName": "Measurements and Scientific Method"
  },
  {
    "id": 1024,
    "content": [
      "A water molecule has two bond pairs and two lone pairs of electrons. Which of the following is CORRECT about these pairs of electrons?"
    ],
    "explanation": [
      "Lone pair-lone pair repulsion is greater than lone pair-bonding pair repulsion, which in turn is greater than bonding pair-bonding pair repulsion.\n\nThis is because lone pairs are more diffuse and occupy more space around the central atom, leading to greater repulsion."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_BONDING",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4097,
        "content": [
          "The repulsion between the two bonding pairs is greater than the repulsion between the two lone pairs."
        ],
        "isCorrect": false
      },
      {
        "id": 4098,
        "content": [
          "The repulsion between the two lone pairs is greater than the repulsion between the two bonding pairs."
        ],
        "isCorrect": true
      },
      {
        "id": 4099,
        "content": [
          "Bonding pair - lone pair repulsion is greater than lone pair - lone pair repulsion."
        ],
        "isCorrect": false
      },
      {
        "id": 4100,
        "content": [
          "Lone pair - lone pair repulsion is exactly identical with bonding pair - bonding pair repulsion."
        ],
        "isCorrect": false
      }
    ],
    "grade": 9,
    "unit": 4,
    "unitName": "Chemical Bonding"
  },
  {
    "id": 1025,
    "content": [
      "Which of the following CORRECTLY describes conjugate acids and conjugate bases?"
    ],
    "explanation": [
      "A conjugate base is formed when an acid loses a proton ($$H^+$$).\n\nA conjugate acid is formed when a base gains a proton ($$H^+$$)."
    ],
    "year": "YEAR_2016",
    "subject": "CHEMISTRY",
    "chapter": "CHEMI_SOLLUTIONS",
    "field": "NATURAL",
    "isGrouped": false,
    "groupId": null,
    "groupIndex": null,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 4101,
        "content": [
          "Conjugate acid is a species formed after a removal of a proton from a base whereas conjugate base is formed after addition of proton to an acid."
        ],
        "isCorrect": false
      },
      {
        "id": 4102,
        "content": [
          "Conjugate base is a species formed after removal of a proton from an acid whereas conjugate acid is formed after addition of a proton to a base."
        ],
        "isCorrect": true
      },
      {
        "id": 4103,
        "content": [
          "Conjugate acid has one fewer hydrogen and one more minus charge than the corresponding acid."
        ],
        "isCorrect": false
      },
      {
        "id": 4104,
        "content": [
          "Conjugate base has one more hydrogen and one fewer minus charge than the corresponding base."
        ],
        "isCorrect": false
      }
    ],
    "grade": 10,
    "unit": 2,
    "unitName": "Solutions"
  }
];
export default questions;
