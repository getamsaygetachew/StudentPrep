// StudentPrep Premium Content — complete question bank.
const questions = [
  {
    "id": 3268,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Friend: Can you guess where this huge soup mug was made?",
      "You: Not exactly, but I think, it ______."
    ],
    "explanation": [
      "The phrase \"Not exactly, but I think\" suggests uncertainty about a past event. \"Could have been made\" is the correct modal verb form to express possibility or speculation in the past."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13080,
        "content": [
          "must have been made in Spain"
        ],
        "isCorrect": false
      },
      {
        "id": 13081,
        "content": [
          "was made in Spain"
        ],
        "isCorrect": false
      },
      {
        "id": 13082,
        "content": [
          "could have been made in Spain"
        ],
        "isCorrect": true
      },
      {
        "id": 13083,
        "content": [
          "was probably made in Spain"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3269,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Supervisor: ______? There are errors of all kind in your essay.",
      "Student: Sorry, I'll proofread it before I hand it in."
    ],
    "explanation": [
      "The student's apology and promise to proofread indicate that the supervisor has just made a critical comment. \"Do you care about your writing\" is a rhetorical question used to introduce a criticism, which fits the context of finding \"errors of all kind.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13084,
        "content": [
          "Do you care about your writing"
        ],
        "isCorrect": true
      },
      {
        "id": 13085,
        "content": [
          "Am I going to hate your writing"
        ],
        "isCorrect": false
      },
      {
        "id": 13086,
        "content": [
          "Could you tell me about your writing"
        ],
        "isCorrect": false
      },
      {
        "id": 13087,
        "content": [
          "Are there errors of any kind in your essay"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3270,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Mother: I don't have much to complain about you, but one thing that ______.",
      "Daughter: I'm sorry Mom; I promise not to watch any program until my final is over."
    ],
    "explanation": [
      "The daughter's response directly addresses the act of watching TV programs. This shows that the mother's complaint was about her spending too much time on that activity."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13088,
        "content": [
          "pleases me most about you is that you always finish your work before bed time"
        ],
        "isCorrect": false
      },
      {
        "id": 13089,
        "content": [
          "bothers me most about you is that you spend much time watching TV"
        ],
        "isCorrect": true
      },
      {
        "id": 13090,
        "content": [
          "annoys me most about you is that you spend little time using the social media"
        ],
        "isCorrect": false
      },
      {
        "id": 13091,
        "content": [
          "strikes me most about you is that you have very good friends"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3271,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Instructor: I ______ some of the challenges you face as freshman students.",
      "Students: Can we ask questions at the end?"
    ],
    "explanation": [
      "\"I would like to describe\" is a standard and polite phrase used to introduce the topic of a talk or presentation. The students' response about asking questions confirms that they understand a presentation is about to begin."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13092,
        "content": [
          "would like to describe"
        ],
        "isCorrect": true
      },
      {
        "id": 13093,
        "content": [
          "should like to describe"
        ],
        "isCorrect": false
      },
      {
        "id": 13094,
        "content": [
          "would like to give a lecture on"
        ],
        "isCorrect": false
      },
      {
        "id": 13095,
        "content": [
          "will like to describe"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3272,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Friend: We haven't met Blen over the last six weeks, have we?",
      "You: No. ______",
      "Friend: Good idea! That's exactly what I have in mind."
    ],
    "explanation": [
      "The friend's enthusiastic agreement (\"Good idea!\") indicates that a suggestion was made. Proposing to ask Blen for dinner is a logical suggestion after acknowledging they haven't seen her in a while."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 5,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13096,
        "content": [
          "I met her last Saturday at the cinema."
        ],
        "isCorrect": false
      },
      {
        "id": 13097,
        "content": [
          "Blen is your best friend, isn't she?"
        ],
        "isCorrect": false
      },
      {
        "id": 13098,
        "content": [
          "Perhaps we could ask her for dinner this evening"
        ],
        "isCorrect": true
      },
      {
        "id": 13099,
        "content": [
          "Does she have a very tight work schedule?"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3273,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Father: Hana is a careful girl.",
      "Mother: How about Lulit, her younger sister, I mean?",
      "Father: Hana is a careful girl, ______."
    ],
    "explanation": [
      "The mother asks about Lulit in contrast to Hana. The word \"whereas\" is used to show a contrast between two people or things. Since Hana is \"careful,\" the contrasting quality for her sister would be that she \"takes risks.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 6,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13100,
        "content": [
          "when her sister does not take risks."
        ],
        "isCorrect": false
      },
      {
        "id": 13101,
        "content": [
          "whereas, her sister takes risks."
        ],
        "isCorrect": true
      },
      {
        "id": 13102,
        "content": [
          "whereas, here sister is more intelligent."
        ],
        "isCorrect": false
      },
      {
        "id": 13103,
        "content": [
          "does her sister take risks?"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3274,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Teacher: ______ but the way you behaved in class.",
      "Student: I'm sorry, teacher."
    ],
    "explanation": [
      "The student's apology suggests the teacher has just expressed displeasure. The phrase \"Your behavior, more than your exam, was my concern\" clearly and directly states the reason for the teacher's disapproval, contrasting it with another potential issue (the exam)."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 7,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13104,
        "content": [
          "What concerns me more was about your behavior"
        ],
        "isCorrect": false
      },
      {
        "id": 13105,
        "content": [
          "What concerns me more was your score"
        ],
        "isCorrect": false
      },
      {
        "id": 13106,
        "content": [
          "What concerns me more about your exam is not what you did"
        ],
        "isCorrect": false
      },
      {
        "id": 13107,
        "content": [
          "Your behavior, more than your exam, was my concern"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3275,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Samson: ______",
      "Misrak: Correct. He has enormous musical talent."
    ],
    "explanation": [
      "Misrak's reply begins with \"Correct,\" indicating she agrees with a statement Samson just made. Her follow-up about \"enormous musical talent\" provides a reason for her agreement. Samson's statement, \"If I were him, I'd study music further,\" expresses an opinion that Misrak can agree with, justifying it with the person's talent."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 8,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13108,
        "content": [
          "What does he study?"
        ],
        "isCorrect": false
      },
      {
        "id": 13109,
        "content": [
          "Why does he study music?"
        ],
        "isCorrect": false
      },
      {
        "id": 13110,
        "content": [
          "If I were him, I wouldn't study music."
        ],
        "isCorrect": false
      },
      {
        "id": 13111,
        "content": [
          "If I were him, I'd study music further."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3276,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "You: I don't want people standing too close to me, ______",
      "Stranger: No, I don't, Sir."
    ],
    "explanation": [
      "The question \"do you mind?\" is a polite way to ask for permission or make a request. The standard polite response to show that you do not object is \"No, I don't mind\" or simply \"No, I don't,\" which matches the stranger's reply perfectly."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 9,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13112,
        "content": [
          "if you don't mind"
        ],
        "isCorrect": false
      },
      {
        "id": 13113,
        "content": [
          "if you mind"
        ],
        "isCorrect": false
      },
      {
        "id": 13114,
        "content": [
          "when you don't mind"
        ],
        "isCorrect": false
      },
      {
        "id": 13115,
        "content": [
          "do you mind"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3277,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "You: Do you know that there are more girls in schools these days than there in the past?",
      "Colleague: ______"
    ],
    "explanation": [
      "The question asks about an observed social change. The colleague's response should provide a logical reason for this change. The statement that parents are more aware of the need for girls' education is a direct and plausible explanation for the increase in female school enrollment."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 10,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13116,
        "content": [
          "Yes, more boys than girls love schools these days"
        ],
        "isCorrect": false
      },
      {
        "id": 13117,
        "content": [
          "Sure, schools are much crowed these days than were in the past"
        ],
        "isCorrect": false
      },
      {
        "id": 13118,
        "content": [
          "This is due to the fact that parents are more aware of the need for girls' education"
        ],
        "isCorrect": true
      },
      {
        "id": 13119,
        "content": [
          "This is due to the fact that girls need more education these days"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3278,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Wheel chair user: Could you tell me where the computer center is on this building?",
      "You: Oh sure, the 3rd room from here. ______",
      "Wheel chair user: Thank you indeed."
    ],
    "explanation": [
      "After providing directions, a helpful and polite follow-up would be to offer further assistance. \"Can I help you push the wheelchair?\" is a considerate offer that is relevant to the person's situation."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 11,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13120,
        "content": [
          "You cannot keep your wheelchair in my office."
        ],
        "isCorrect": false
      },
      {
        "id": 13121,
        "content": [
          "Can I help you push the wheelchair?"
        ],
        "isCorrect": true
      },
      {
        "id": 13122,
        "content": [
          "Don't leave your wheelchair in my office."
        ],
        "isCorrect": false
      },
      {
        "id": 13123,
        "content": [
          "Leave your wheelchair in my office."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3279,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "You: There is a job vacancy announced in our office. Do you want to apply?",
      "A jobless friend: ______?"
    ],
    "explanation": [
      "When told about a job vacancy, the most fundamental and initial question to ask is about the nature of the job itself. \"For the position of what?\" seeks this essential information before any other details like salary or deadline become relevant."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 12,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13124,
        "content": [
          "How much is the salary"
        ],
        "isCorrect": false
      },
      {
        "id": 13125,
        "content": [
          "When is the deadline"
        ],
        "isCorrect": false
      },
      {
        "id": 13126,
        "content": [
          "Is that going to be a good job"
        ],
        "isCorrect": false
      },
      {
        "id": 13127,
        "content": [
          "For the position of what"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3280,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Bezawit: When do you wash your clothes? I think you haven't time in the afternoon",
      "Samrawit: ______"
    ],
    "explanation": [
      "Bezawit's question is about the timing of a future action. The future perfect tense \"I will have washed it\" is used to indicate that an action will be completed by a specific time in the future, which directly answers the question about when the clothes will be washed."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 13,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13128,
        "content": [
          "It is not time to wash clothes"
        ],
        "isCorrect": false
      },
      {
        "id": 13129,
        "content": [
          "I will have washed it by the evening"
        ],
        "isCorrect": true
      },
      {
        "id": 13130,
        "content": [
          "I have washed it when the sun rises"
        ],
        "isCorrect": false
      },
      {
        "id": 13131,
        "content": [
          "I think it is too cold to wash clothes"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3281,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "You: What does our new English teacher look like?",
      "Friend: ______"
    ],
    "explanation": [
      "The question \"What does... look like?\" specifically asks about physical appearance. While hair color and age are part of a description, \"short, but well-built\" is the most direct and comprehensive answer about his physical stature and build."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 14,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13132,
        "content": [
          "He has grey hair"
        ],
        "isCorrect": false
      },
      {
        "id": 13133,
        "content": [
          "He's 30 years old, approximately"
        ],
        "isCorrect": false
      },
      {
        "id": 13134,
        "content": [
          "He's short, but well-built"
        ],
        "isCorrect": true
      },
      {
        "id": 13135,
        "content": [
          "He speaks English fluently"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3282,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Teacher: ______?",
      "Student: Yes. Horses, mules and donkeys are the main ones. There are also 'Bajaj' and motor cycles in some areas of the village."
    ],
    "explanation": [
      "The student provides a comprehensive list of different modes of transport. An open-ended question like \"What are the means of transportation in your village?\" would elicit such a detailed list, whereas the other options are closed questions that would likely get a simple \"yes\" or \"no\" answer."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 15,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13136,
        "content": [
          "Are horse and mules used for transportation in your village"
        ],
        "isCorrect": false
      },
      {
        "id": 13137,
        "content": [
          "Can you tell us the means of transportation in your village"
        ],
        "isCorrect": false
      },
      {
        "id": 13138,
        "content": [
          "Are Bajaj and motor cycles used for transportation in your village"
        ],
        "isCorrect": false
      },
      {
        "id": 13139,
        "content": [
          "What are the means of transportation in your village"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3283,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Journalist: Let's talk about marriage culture among this society. To begin with, could you tell me a few things about marriage culture here?",
      "Host: Sure, in this culture, ______."
    ],
    "explanation": [
      "The journalist asks for an introduction to the local marriage culture. A good starting point is to describe the fundamental process of how marriages are formed. Stating that marriages are arranged by go-betweens is a common and central aspect of many traditional cultures and serves as an excellent opening for a more detailed explanation."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 16,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13140,
        "content": [
          "marriage is primarily arranged by go-betweens. This means . . ."
        ],
        "isCorrect": true
      },
      {
        "id": 13141,
        "content": [
          "a boy and a girl can get married if they wish. What I mean is . . ."
        ],
        "isCorrect": false
      },
      {
        "id": 13142,
        "content": [
          "divorce is strictly prohibited by law in this culture which means . . ."
        ],
        "isCorrect": false
      },
      {
        "id": 13143,
        "content": [
          "a man cannot have two wives. In other words, . . ."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3284,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Teacher: Could you tell me ______?",
      "Student: It's an elephant. Despite their clumsy appearance, elephants are very intelligent."
    ],
    "explanation": [
      "The student's answer has two parts: naming the animal (\"It's an elephant\") and giving a reason (\"elephants are very intelligent\"). The teacher's question must have asked for both pieces of information. The phrase \"what your favorite animal is and why you chose it\" correctly forms an indirect question that requests both the 'what' and the 'why'."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 17,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13144,
        "content": [
          "why you chose an elephant as your favorite animal"
        ],
        "isCorrect": false
      },
      {
        "id": 13145,
        "content": [
          "what your favorite animal is and why you chose it"
        ],
        "isCorrect": true
      },
      {
        "id": 13146,
        "content": [
          "why an elephant, an intelligent animal, is your favorite animal"
        ],
        "isCorrect": false
      },
      {
        "id": 13147,
        "content": [
          "what intelligent animal is your favorite animal"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3285,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Customer: I'd like to withdraw 5,000 Birr, please.",
      "Cashier: ______?"
    ],
    "explanation": [
      "After a customer states their intention to withdraw a specific amount, the standard next step for a cashier is to ask about the desired denominations of the cash (e.g., in 100s, 50s, etc.). \"How would you like the money?\" is the common question for this."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 18,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13148,
        "content": [
          "How would you like the money"
        ],
        "isCorrect": true
      },
      {
        "id": 13149,
        "content": [
          "Do you want to make a withdrawal"
        ],
        "isCorrect": false
      },
      {
        "id": 13150,
        "content": [
          "What is the interest rate on your account"
        ],
        "isCorrect": false
      },
      {
        "id": 13151,
        "content": [
          "Could you write your name here, please"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3286,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Kedir: Do you like jogging?",
      "You: ______"
    ],
    "explanation": [
      "The question is a direct yes/no question about a specific activity, jogging. The most relevant and complete answer is to confirm participation (\"Yes\") and provide a detail about the frequency (\"I go jogging three days a week\")."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 19,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13152,
        "content": [
          "I like watching football"
        ],
        "isCorrect": false
      },
      {
        "id": 13153,
        "content": [
          "Yes, I'm a member of a gym"
        ],
        "isCorrect": false
      },
      {
        "id": 13154,
        "content": [
          "Yes, I go jogging three days a week"
        ],
        "isCorrect": true
      },
      {
        "id": 13155,
        "content": [
          "I quite like playing chess"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3287,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Neighbor: Help! The building is on fire.",
      "You: ______"
    ],
    "explanation": [
      "In an emergency situation where a building is on fire, the most critical and immediate action is to contact the appropriate emergency service. Shouting \"Call a fire brigade!\" is the correct and most urgent response."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 20,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13156,
        "content": [
          "Call a fire brigade!"
        ],
        "isCorrect": true
      },
      {
        "id": 13157,
        "content": [
          "Call an ambulance."
        ],
        "isCorrect": false
      },
      {
        "id": 13158,
        "content": [
          "Can you smell burning?"
        ],
        "isCorrect": false
      },
      {
        "id": 13159,
        "content": [
          "Do you need a doctor?"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3288,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "You: Did you enjoy your flight to Mogadishu?",
      "Friend: ______"
    ],
    "explanation": [
      "The question asks about the enjoyment of the flight. \"All in all, it was a pleasant flight\" provides a direct summary and answer to the question about the overall experience. The other options provide facts about the flight but do not address the aspect of enjoyment."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 21,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13160,
        "content": [
          "All in all, it was a pleasant flight"
        ],
        "isCorrect": true
      },
      {
        "id": 13161,
        "content": [
          "On the whole, it took us 5 hours"
        ],
        "isCorrect": false
      },
      {
        "id": 13162,
        "content": [
          "The landing was as safe the take off"
        ],
        "isCorrect": false
      },
      {
        "id": 13163,
        "content": [
          "Altogether, there were 250 passengers"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3289,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Teacher: Your brother is very honest.",
      "You: ______"
    ],
    "explanation": [
      "To agree with a positive statement that uses the verb 'to be' (like \"he is\"), the correct structure is \"So + auxiliary verb + subject\". In this case, the verb is 'is', so the auxiliary is 'am' for the subject 'I'. Thus, \"So am I\" is the grammatically correct way to agree."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 22,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13164,
        "content": [
          "So do I"
        ],
        "isCorrect": false
      },
      {
        "id": 13165,
        "content": [
          "So I am"
        ],
        "isCorrect": false
      },
      {
        "id": 13166,
        "content": [
          "Me either"
        ],
        "isCorrect": false
      },
      {
        "id": 13167,
        "content": [
          "So am I"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3290,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Journalist: How serious was the damage caused by the earthquake?",
      "Community leader: Thousands were left homeless, just ______"
    ],
    "explanation": [
      "The community leader provides a specific, powerful example (thousands homeless) to help the journalist understand the magnitude of the situation. The phrase \"to give you an idea of the scale of the disaster\" correctly explains the purpose of providing this specific piece of information."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 23,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13168,
        "content": [
          "to summarize the scale of the disaster"
        ],
        "isCorrect": false
      },
      {
        "id": 13169,
        "content": [
          "to give you an idea of the scale of the disaster"
        ],
        "isCorrect": true
      },
      {
        "id": 13170,
        "content": [
          "to illustrate the details of the disaster"
        ],
        "isCorrect": false
      },
      {
        "id": 13171,
        "content": [
          "as an example of the scale of the disaster"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3291,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "You: I'm going to sell my car. What's your advice?",
      "Friend: I ______. The price of used cars has tremendously declined."
    ],
    "explanation": [
      "The friend provides a reason (\"The price of used cars has tremendously declined\") that contradicts the idea of selling the car. Therefore, \"disagree\" is the logical verb to describe the friend's stance."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 24,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13172,
        "content": [
          "argue"
        ],
        "isCorrect": false
      },
      {
        "id": 13173,
        "content": [
          "disagree"
        ],
        "isCorrect": true
      },
      {
        "id": 13174,
        "content": [
          "don't care"
        ],
        "isCorrect": false
      },
      {
        "id": 13175,
        "content": [
          "agree"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3292,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Teacher: Do you plan a marriage before college?",
      "Student: ______"
    ],
    "explanation": [
      "The question is about the timing of marriage relative to college. The student's response \"No, but marriage is inevitable at some point in the future\" directly answers the question (\"No\") and adds a relevant personal view that clarifies their position."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 25,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13176,
        "content": [
          "Congratulations! I'll be 20 ten days from today"
        ],
        "isCorrect": false
      },
      {
        "id": 13177,
        "content": [
          "Yes, but nothing precedes college at the moment"
        ],
        "isCorrect": false
      },
      {
        "id": 13178,
        "content": [
          "No, but marriage is inevitable at some point in the future"
        ],
        "isCorrect": true
      },
      {
        "id": 13179,
        "content": [
          "Sure. I love to have two children when I get married"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3293,
    "content": [
      "Choose from the alternatives that is most appropriate to complete the dialogue.",
      "---",
      "Sports Journalist: Do you have an athlete to admire?",
      "You: Yes. ______"
    ],
    "explanation": [
      "The question asks for a personal opinion (\"Do you have...\"). The response \"I admire Darartu Tulu...\" directly answers the question by naming a specific athlete and then provides a reason for the admiration (\"she is such a well-behaved model athlete\"), making it a complete and appropriate answer."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_CONVERSATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 119,
    "groupIndex": 26,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13180,
        "content": [
          "Darartu Tulu is a courageous athlete you should admire."
        ],
        "isCorrect": false
      },
      {
        "id": 13181,
        "content": [
          "I admire Darartu Tulu; she is such a well-behaved model athlete of all time."
        ],
        "isCorrect": true
      },
      {
        "id": 13182,
        "content": [
          "Don't you admire Darartu Tulu yourself?"
        ],
        "isCorrect": false
      },
      {
        "id": 13183,
        "content": [
          "Athletes work in competitive situations. Admire them."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3294,
    "content": [
      "The words are out of order. Choose the alternative that forms a correct English sentence.",
      "---",
      "with here you return I or until either go wait can me"
    ],
    "explanation": [
      "This option correctly constructs a sentence with a clear choice using the \"either...or...\" structure: \"either go with me or wait here\". The clause \"until I return\" logically modifies the action of waiting."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_JUMBLED_WORDS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 120,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13184,
        "content": [
          "return Until I return you can either go or wait here with me."
        ],
        "isCorrect": false
      },
      {
        "id": 13185,
        "content": [
          "With me here you can either wait or go until I."
        ],
        "isCorrect": false
      },
      {
        "id": 13186,
        "content": [
          "Wait until I can either go or you return with me here."
        ],
        "isCorrect": false
      },
      {
        "id": 13187,
        "content": [
          "You can either go with me or wait here until I return."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3295,
    "content": [
      "The words are out of order. Choose the alternative that forms a correct English sentence.",
      "---",
      "people all idea to whose invite was these it"
    ],
    "explanation": [
      "This is the correct structure for a 'Wh'-question: Wh-phrase (\"Whose idea\") + auxiliary verb (\"was\") + subject (\"it\") + main verb infinitive phrase (\"to invite...\")."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_JUMBLED_WORDS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 120,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13188,
        "content": [
          "Whose idea it was to invite all these people?"
        ],
        "isCorrect": false
      },
      {
        "id": 13189,
        "content": [
          "To invite all these people it was whose idea?"
        ],
        "isCorrect": false
      },
      {
        "id": 13190,
        "content": [
          "Whose idea was it to invite all these people?"
        ],
        "isCorrect": true
      },
      {
        "id": 13191,
        "content": [
          "It was whose idea to invite all these people?"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3296,
    "content": [
      "The words are out of order. Choose the alternative that forms a correct English sentence.",
      "---",
      "to want visit always I have Casablanca"
    ],
    "explanation": [
      "This sentence follows the standard English word order: Subject (\"I\") + Verb Phrase (\"have always wanted\") + Object (\"to visit Casablanca\"). The adverb \"always\" is correctly placed within the verb phrase."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_JUMBLED_WORDS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 120,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13192,
        "content": [
          "I have always wanted to visit Casablanca."
        ],
        "isCorrect": true
      },
      {
        "id": 13193,
        "content": [
          "Casablanca I have always wanted to visit."
        ],
        "isCorrect": false
      },
      {
        "id": 13194,
        "content": [
          "I wanted to always have visit Casablanca."
        ],
        "isCorrect": false
      },
      {
        "id": 13195,
        "content": [
          "Always I wanted to have visit Casablanca."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3297,
    "content": [
      "Choose the alternative that best states the main idea of the paragraph.",
      "---",
      "Education is fundamental to development and growth. The human mind makes possible all development achievements. Advances in health, agricultural and public administration are a few examples of development achievements. There is no better tool than education for countries to achieve these development goals."
    ],
    "explanation": [
      "The paragraph opens by stating education is \"fundamental to development and growth\" and closes by calling it the best \"tool\" for development goals. This choice accurately summarizes this central point."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_PARAGRAPH_DEVELOPMENT_TECHNIQUE",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 121,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13196,
        "content": [
          "Education is the basis of all aspects of development and growth."
        ],
        "isCorrect": true
      },
      {
        "id": 13197,
        "content": [
          "Advances in health is possible due to fair public administration."
        ],
        "isCorrect": false
      },
      {
        "id": 13198,
        "content": [
          "The human mind is a better tool for advanced education."
        ],
        "isCorrect": false
      },
      {
        "id": 13199,
        "content": [
          "Advance in agriculture is fundamental to a country's development."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3298,
    "content": [
      "Choose the alternative that best states the main idea of the paragraph.",
      "---",
      "Transportation plays a critical role in the livability of a community. Access to transportation increases people's ability to access recreation, entertainment, and other activities that promote community engagement. Efficient and affordable transportation ensure that people can obtain services and participate in public life. Participation in public life increases the economic growth of a community"
    ],
    "explanation": [
      "The paragraph repeatedly links transportation access to the ability to \"participate in public life\" and \"promote community engagement.\" This statement best captures the cause-and-effect relationship described throughout the text."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_PARAGRAPH_DEVELOPMENT_TECHNIQUE",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 121,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13200,
        "content": [
          "When people obtain services, their economic growth is ensured."
        ],
        "isCorrect": false
      },
      {
        "id": 13201,
        "content": [
          "Participation in public life makes transportation affordable."
        ],
        "isCorrect": false
      },
      {
        "id": 13202,
        "content": [
          "Access to affordable transportation increases a community's participation in public life."
        ],
        "isCorrect": true
      },
      {
        "id": 13203,
        "content": [
          "Access to recreation ensures the economic growth of a community."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3299,
    "content": [
      "Choose the alternative with the correct spelling."
    ],
    "explanation": [
      "The word \"subsistence\" is spelled correctly. The correct spellings for the other words are \"maintenance,\" \"exhibition,\" and \"fascination.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_WORD_SPELLING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 122,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13204,
        "content": [
          "maintnance"
        ],
        "isCorrect": false
      },
      {
        "id": 13205,
        "content": [
          "exhibtion"
        ],
        "isCorrect": false
      },
      {
        "id": 13206,
        "content": [
          "fasination"
        ],
        "isCorrect": false
      },
      {
        "id": 13207,
        "content": [
          "subsistence"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3300,
    "content": [
      "Choose the alternative with the correct spelling."
    ],
    "explanation": [
      "The word \"audience\" is spelled correctly. The correct spellings for the other words are \"experience,\" \"souvenir,\" and \"cigarette.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_WORD_SPELLING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 122,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13208,
        "content": [
          "experince"
        ],
        "isCorrect": false
      },
      {
        "id": 13209,
        "content": [
          "souvenr"
        ],
        "isCorrect": false
      },
      {
        "id": 13210,
        "content": [
          "audience"
        ],
        "isCorrect": true
      },
      {
        "id": 13211,
        "content": [
          "cigarete"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3301,
    "content": [
      "Answer the following questions about formal letter writing.",
      "---",
      "Where would you write a request for an action in the format of a formal letter?"
    ],
    "explanation": [
      "The body of the letter contains the main message, including the purpose of writing, detailed information, and any specific requests for action."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LETTER_WRITING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 123,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13212,
        "content": [
          "in the Complementary closure"
        ],
        "isCorrect": false
      },
      {
        "id": 13213,
        "content": [
          "in the Salutation"
        ],
        "isCorrect": false
      },
      {
        "id": 13214,
        "content": [
          "in the Body of the letter"
        ],
        "isCorrect": true
      },
      {
        "id": 13215,
        "content": [
          "in the Subject line"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3302,
    "content": [
      "Answer the following questions about formal letter writing.",
      "---",
      "When you write a formal letter, where would you write your address and contact details?"
    ],
    "explanation": [
      "Standard formal letter format requires the writer's (sender's) address and contact information to be placed at the top of the letter."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LETTER_WRITING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 123,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13216,
        "content": [
          "In the Sender's Address"
        ],
        "isCorrect": true
      },
      {
        "id": 13217,
        "content": [
          "In the Complimentary Closure"
        ],
        "isCorrect": false
      },
      {
        "id": 13218,
        "content": [
          "In the Receiver's Address"
        ],
        "isCorrect": false
      },
      {
        "id": 13219,
        "content": [
          "In the Salutation"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3303,
    "content": [
      "Answer the following questions about formal letter writing.",
      "---",
      "Where is the correct place to write the date in a formal letter?"
    ],
    "explanation": [
      "In a formal letter, the date is typically written on its own line, directly below the sender's address and before the recipient's address."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LETTER_WRITING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 123,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13220,
        "content": [
          "on the same line as the sender's address"
        ],
        "isCorrect": false
      },
      {
        "id": 13221,
        "content": [
          "immediately before the sender's address"
        ],
        "isCorrect": false
      },
      {
        "id": 13222,
        "content": [
          "just before the recipient's address"
        ],
        "isCorrect": false
      },
      {
        "id": 13223,
        "content": [
          "immediately after the sender's address"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3304,
    "content": [
      "The sentences are out of order. Choose the alternative that shows the correct order to form a coherent paragraph.",
      "---",
      "a. They make their home in buildings, gardens, etc.",
      "b. Ants are found everywhere in the world.",
      "c. In the summer, ants collect food for the winter season.",
      "d. They are very hardworking insects."
    ],
    "explanation": [
      "The logical flow is: general statement (b), key characteristic (d), supporting detail about location (a), and supporting detail about behavior (c). This order (b-d-a-c) moves from a broad topic to specific examples."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_PARAGRAPH_COHERENCE",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 124,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13224,
        "content": [
          "c b a d"
        ],
        "isCorrect": false
      },
      {
        "id": 13225,
        "content": [
          "b d a c"
        ],
        "isCorrect": true
      },
      {
        "id": 13226,
        "content": [
          "b a c d"
        ],
        "isCorrect": false
      },
      {
        "id": 13227,
        "content": [
          "d a c b"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3305,
    "content": [
      "The sentences are out of order. Choose the alternative that shows the correct order to form a coherent paragraph.",
      "---",
      "a. Schools help us to be consistent, punctual, and obedient.",
      "b. In short, we learn how to be better people in schools.",
      "c. For example, we learn how to read and write in schools.",
      "d. School is the place where we learn new things"
    ],
    "explanation": [
      "The paragraph should start with a general topic sentence (d), followed by a specific example (c), then another benefit (a), and finally a concluding summary statement (b). The order d-c-a-b provides the most logical progression."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_PARAGRAPH_COHERENCE",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 124,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13228,
        "content": [
          "d a d b"
        ],
        "isCorrect": false
      },
      {
        "id": 13229,
        "content": [
          "d b a c"
        ],
        "isCorrect": false
      },
      {
        "id": 13230,
        "content": [
          "b d c a"
        ],
        "isCorrect": false
      },
      {
        "id": 13231,
        "content": [
          "d c a b"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3306,
    "content": [
      "The sentences are out of order. Choose the alternative that shows the correct order to form a coherent paragraph.",
      "---",
      "a. The first thing you need is egg.",
      "b. Omelet is one of my most favorite food items.",
      "c. It is one of the easiest things to do in the kitchen.",
      "d. Today, I will show you how to make an omelet."
    ],
    "explanation": [
      "The paragraph logically begins by introducing the subject (b) and adding a detail about it (c). It then states the purpose (d), and finally begins the instructions with the first step (a). The sequence b-c-d-a is a clear and effective introduction."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_PARAGRAPH_COHERENCE",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 124,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13232,
        "content": [
          "b c d a"
        ],
        "isCorrect": true
      },
      {
        "id": 13233,
        "content": [
          "b d c a"
        ],
        "isCorrect": false
      },
      {
        "id": 13234,
        "content": [
          "c d a b"
        ],
        "isCorrect": false
      },
      {
        "id": 13235,
        "content": [
          "c a d b"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3307,
    "content": [
      "The sentences are out of order. Choose the alternative that shows the correct order to form a coherent paragraph.",
      "---",
      "a. You can use it to talk with your friends or family, for example.",
      "b. A mobile phone is a very useful device to get connected with others.",
      "c. A mobile phone call can be made in so many ways.",
      "d. These days, everyone has a mobile phone."
    ],
    "explanation": [
      "A strong paragraph structure starts with a clear topic sentence (b), supports it with evidence of its prevalence (d), provides a specific example of its use (a), and adds another feature (c). The order b-d-a-c flows logically from general to specific."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_PARAGRAPH_COHERENCE",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 124,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13236,
        "content": [
          "d c a b"
        ],
        "isCorrect": false
      },
      {
        "id": 13237,
        "content": [
          "a d b c"
        ],
        "isCorrect": false
      },
      {
        "id": 13238,
        "content": [
          "b d a c"
        ],
        "isCorrect": true
      },
      {
        "id": 13239,
        "content": [
          "c a b d"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3308,
    "content": [
      "Choose the sentence with the correct punctuation and capitalization."
    ],
    "explanation": [
      "The sentence is a simple declarative statement. Therefore, it should end with a period (.). The other punctuation marks (comma, exclamation mark, colon) are not appropriate for this type of sentence."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 125,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13240,
        "content": [
          "It is difficult for students to make changes in essays written by hand,"
        ],
        "isCorrect": false
      },
      {
        "id": 13241,
        "content": [
          "It is difficult for students to make changes in essays written by hand!"
        ],
        "isCorrect": false
      },
      {
        "id": 13242,
        "content": [
          "It is difficult for students to make changes in essays written by hand:"
        ],
        "isCorrect": false
      },
      {
        "id": 13243,
        "content": [
          "It is difficult for students to make changes in essays written by hand."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3309,
    "content": [
      "Choose the sentence with the correct punctuation and capitalization."
    ],
    "explanation": [
      "When a dialogue tag like \"he said\" interrupts a sentence of dialogue, a comma is needed before the tag and inside the quotation marks. Another comma is needed after the tag. The final period goes inside the closing quotation mark."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 125,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13244,
        "content": [
          "\"I thought she knew the answer, he said, \"but she didn't.\""
        ],
        "isCorrect": false
      },
      {
        "id": 13245,
        "content": [
          "\"I thought she knew the answer\" he said, \"but she didn't.\""
        ],
        "isCorrect": false
      },
      {
        "id": 13246,
        "content": [
          "\"I thought she knew the answer,\" he said, \"but she didn't.\""
        ],
        "isCorrect": true
      },
      {
        "id": 13247,
        "content": [
          "\"I thought she knew the answer,\" he said, \"but she didn't\"."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3310,
    "content": [
      "Choose the sentence with the correct punctuation and capitalization."
    ],
    "explanation": [
      "A comma is needed before the coordinating conjunction \"but\" that joins two independent clauses. The possessive pronoun \"hers\" should not have an apostrophe."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 125,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13248,
        "content": [
          "I passed my driving test last week but she failed her's."
        ],
        "isCorrect": false
      },
      {
        "id": 13249,
        "content": [
          "I passed my driving test last week, but she failed hers."
        ],
        "isCorrect": true
      },
      {
        "id": 13250,
        "content": [
          "I passed my driving test last week, but, she failed hers."
        ],
        "isCorrect": false
      },
      {
        "id": 13251,
        "content": [
          "I passed my driving test last week but, she failed hers."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3311,
    "content": [
      "Choose the sentence with the correct punctuation and capitalization."
    ],
    "explanation": [
      "\"Addis Ababa\" and \"Dire-Dawa\" are proper nouns (names of cities) and all parts of the names must be capitalized."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_PUNCTUATION_CAPITALIZATION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 125,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13252,
        "content": [
          "Both addis Ababa and Dire-Dawa have become exciting cities for living."
        ],
        "isCorrect": false
      },
      {
        "id": 13253,
        "content": [
          "Both Addis Ababa and Dire-dawa have become exciting cities for living."
        ],
        "isCorrect": false
      },
      {
        "id": 13254,
        "content": [
          "Both Addis Ababa and Dire-Dawa have become exciting cities for living."
        ],
        "isCorrect": true
      },
      {
        "id": 13255,
        "content": [
          "Both Addis Ababa and dire-Dawa have become exciting cities for living."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3312,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "______ does it take students to do their bachelor's degree in Physics?"
    ],
    "explanation": [
      "The question is asking about a duration of time. \"How long\" is the correct interrogative phrase to inquire about the length of time something takes."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13256,
        "content": [
          "How far"
        ],
        "isCorrect": false
      },
      {
        "id": 13257,
        "content": [
          "How much"
        ],
        "isCorrect": false
      },
      {
        "id": 13258,
        "content": [
          "How many"
        ],
        "isCorrect": false
      },
      {
        "id": 13259,
        "content": [
          "How long"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3313,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "\"Just a moment, please!\" \"The room ______,\" said the teacher."
    ],
    "explanation": [
      "The phrase \"Just a moment\" implies an action is currently in progress. Since the room is the object of the action (it is not cleaning itself), the passive voice is required. \"Is being cleaned\" is the present continuous passive form."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13260,
        "content": [
          "is cleaning"
        ],
        "isCorrect": false
      },
      {
        "id": 13261,
        "content": [
          "is being cleaned"
        ],
        "isCorrect": true
      },
      {
        "id": 13262,
        "content": [
          "has been cleaned"
        ],
        "isCorrect": false
      },
      {
        "id": 13263,
        "content": [
          "is cleaned"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3314,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "There are two newspapers on my table. ______ of which has an interesting thing to read."
    ],
    "explanation": [
      "The singular verb \"has\" indicates that the subject must be singular. \"Neither\" means \"not one and not the other\" and is treated as a singular pronoun, fitting the grammar of the sentence. It implies a negative assessment of both newspapers."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13264,
        "content": [
          "Neither"
        ],
        "isCorrect": true
      },
      {
        "id": 13265,
        "content": [
          "Either"
        ],
        "isCorrect": false
      },
      {
        "id": 13266,
        "content": [
          "No one"
        ],
        "isCorrect": false
      },
      {
        "id": 13267,
        "content": [
          "A single"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3315,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "Our teacher ______ in any language other than English in class."
    ],
    "explanation": [
      "The verb \"let\" is followed by an object (\"us\") and a bare infinitive (\"speak\"). The verb \"allow\" requires a \"to\" infinitive (\"allow us to speak\"). The verb \"make\" in the active voice also uses a bare infinitive (\"make us speak\"), but its meaning is different. \"Doesn't let us speak\" is the grammatically correct option that fits the context."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13268,
        "content": [
          "doesn't allow us speak"
        ],
        "isCorrect": false
      },
      {
        "id": 13269,
        "content": [
          "doesn't let us speak"
        ],
        "isCorrect": true
      },
      {
        "id": 13270,
        "content": [
          "doesn't like us speak"
        ],
        "isCorrect": false
      },
      {
        "id": 13271,
        "content": [
          "doesn't make us to speak"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3316,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "I ______ hear a knock on the door. Are you expecting a guest at this moment?"
    ],
    "explanation": [
      "\"Can\" is used here to express the perception of a present event. The speaker is reporting what they are hearing right now."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 5,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13272,
        "content": [
          "can"
        ],
        "isCorrect": true
      },
      {
        "id": 13273,
        "content": [
          "could"
        ],
        "isCorrect": false
      },
      {
        "id": 13274,
        "content": [
          "shall"
        ],
        "isCorrect": false
      },
      {
        "id": 13275,
        "content": [
          "will"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3317,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "I couldn't hear what the teacher was saying during the lesson, but I think I ______ him to be louder."
    ],
    "explanation": [
      "This sentence describes a missed opportunity in the past. \"Could have asked\" correctly expresses a past possibility that did not happen. The speaker had the option to ask but didn't."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 6,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13276,
        "content": [
          "would have asked"
        ],
        "isCorrect": false
      },
      {
        "id": 13277,
        "content": [
          "would ask"
        ],
        "isCorrect": false
      },
      {
        "id": 13278,
        "content": [
          "could have asked"
        ],
        "isCorrect": true
      },
      {
        "id": 13279,
        "content": [
          "could ask"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3318,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "Dad doesn't care much, but mom gets angry if I don't ______ her text message."
    ],
    "explanation": [
      "The verb \"reply\" is followed by the preposition \"to\" when indicating what is being responded to (e.g., a message, a letter, a question)."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 7,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13280,
        "content": [
          "reply for"
        ],
        "isCorrect": false
      },
      {
        "id": 13281,
        "content": [
          "reply"
        ],
        "isCorrect": false
      },
      {
        "id": 13282,
        "content": [
          "apply to"
        ],
        "isCorrect": false
      },
      {
        "id": 13283,
        "content": [
          "reply to"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3319,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "I don't have a car. ______, I don't even have a driving license."
    ],
    "explanation": [
      "\"Furthermore\" is a transitional word used to add another point that supports or expands upon the previous one. The second sentence adds more information to emphasize the speaker's lack of driving capability."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 8,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13284,
        "content": [
          "By the way"
        ],
        "isCorrect": false
      },
      {
        "id": 13285,
        "content": [
          "Therefore"
        ],
        "isCorrect": false
      },
      {
        "id": 13286,
        "content": [
          "Furthermore"
        ],
        "isCorrect": true
      },
      {
        "id": 13287,
        "content": [
          "Incidentally"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3320,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "Olang: I'm the only child for my family. How about you?",
      "Oncho: ______"
    ],
    "explanation": [
      "The correct order for adjectives in English is generally: quantity, opinion, size, age, shape, color, origin, material, purpose. Here, quantity (\"two\") comes before opinion (\"beautiful\") which comes before size (\"tall\")."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 9,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13288,
        "content": [
          "I've beautiful, tall two sisters"
        ],
        "isCorrect": false
      },
      {
        "id": 13289,
        "content": [
          "I've two beautiful, tall sisters"
        ],
        "isCorrect": true
      },
      {
        "id": 13290,
        "content": [
          "I've tall two, beautiful, sisters"
        ],
        "isCorrect": false
      },
      {
        "id": 13291,
        "content": [
          "I've two tall, beautiful sisters"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3321,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "I'm worried about my driving test; I think I ______ hear bad news again."
    ],
    "explanation": [
      "\"Am going to\" is used to express a prediction based on present evidence or feeling. The speaker's worry is the evidence that leads to the prediction of hearing bad news."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 10,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13292,
        "content": [
          "may"
        ],
        "isCorrect": false
      },
      {
        "id": 13293,
        "content": [
          "am going to"
        ],
        "isCorrect": true
      },
      {
        "id": 13294,
        "content": [
          "have to"
        ],
        "isCorrect": false
      },
      {
        "id": 13295,
        "content": [
          "will"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3322,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "______ you see the dictionary on the table when you ______ the office this morning?"
    ],
    "explanation": [
      "The phrase \"this morning\" refers to a specific, completed time in the past. Therefore, the simple past tense is required for both verbs. The question form for the simple past uses \"Did\" + subject + base form of the verb, and the second clause uses the simple past form of the verb. However, the choices combine the question formation and the second verb. \"Did/entered\" correctly uses the simple past auxiliary \"Did\" for the question and the simple past \"entered\" for the action in the second clause."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 11,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13296,
        "content": [
          "Have/ entered"
        ],
        "isCorrect": false
      },
      {
        "id": 13297,
        "content": [
          "Do/entered"
        ],
        "isCorrect": false
      },
      {
        "id": 13298,
        "content": [
          "Did/entered"
        ],
        "isCorrect": true
      },
      {
        "id": 13299,
        "content": [
          "Do/enter"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3323,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "______ my grade was satisfactory, I feel I studied hard this semester."
    ],
    "explanation": [
      "\"Although\" is a subordinating conjunction used to introduce a clause that contrasts with the main clause. It correctly shows the contrast between the satisfactory grade and the feeling of having studied hard (implying the speaker expected an even better grade)."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 12,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13300,
        "content": [
          "Although"
        ],
        "isCorrect": true
      },
      {
        "id": 13301,
        "content": [
          "However"
        ],
        "isCorrect": false
      },
      {
        "id": 13302,
        "content": [
          "Even"
        ],
        "isCorrect": false
      },
      {
        "id": 13303,
        "content": [
          "Despite"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3324,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "Teacher: ______ do you often prefer to study?",
      "Student: from 2-5 pm"
    ],
    "explanation": [
      "The student's answer specifies a period of time. \"What time of the day\" is the standard and most common way to ask a general question about the preferred time for an activity."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 13,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13304,
        "content": [
          "During what time of the day"
        ],
        "isCorrect": false
      },
      {
        "id": 13305,
        "content": [
          "Which time of the day"
        ],
        "isCorrect": false
      },
      {
        "id": 13306,
        "content": [
          "Which time in the day"
        ],
        "isCorrect": false
      },
      {
        "id": 13307,
        "content": [
          "What time of the day"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3325,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "If you continue practising speaking English like this, you ______ speak it fluently very soon."
    ],
    "explanation": [
      "This is a first conditional sentence expressing a likely future result. \"Will be able to\" correctly expresses future ability that will result from the condition of continued practice."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 14,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13308,
        "content": [
          "shall"
        ],
        "isCorrect": false
      },
      {
        "id": 13309,
        "content": [
          "will be able to"
        ],
        "isCorrect": true
      },
      {
        "id": 13310,
        "content": [
          "can"
        ],
        "isCorrect": false
      },
      {
        "id": 13311,
        "content": [
          "are able to"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3326,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "______, this noise will die down soon; surely, it has been a terribly noisy night."
    ],
    "explanation": [
      "The speaker is expressing a wish or hope for a future event (the noise dying down). \"Hopefully\" is the adverb that correctly conveys this meaning."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 15,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13312,
        "content": [
          "Sadly"
        ],
        "isCorrect": false
      },
      {
        "id": 13313,
        "content": [
          "Truthfully"
        ],
        "isCorrect": false
      },
      {
        "id": 13314,
        "content": [
          "Essentially"
        ],
        "isCorrect": false
      },
      {
        "id": 13315,
        "content": [
          "Hopefully"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3327,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "Unwise use of drugs can sooner or later ______ a serious ailment, if not death."
    ],
    "explanation": [
      "The phrasal verb \"result in\" means to cause or have as a consequence. It correctly shows the relationship between the cause (drug use) and the effect (ailment)."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 16,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13316,
        "content": [
          "result in"
        ],
        "isCorrect": true
      },
      {
        "id": 13317,
        "content": [
          "results from"
        ],
        "isCorrect": false
      },
      {
        "id": 13318,
        "content": [
          "rises from"
        ],
        "isCorrect": false
      },
      {
        "id": 13319,
        "content": [
          "arises from"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3328,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "She doesn't speak French very well, ______?"
    ],
    "explanation": [
      "This is a tag question. When the main clause is negative (\"doesn't speak\"), the tag must be positive. The auxiliary verb in the main clause is \"does,\" so the tag must use \"does.\" The subject is \"she.\" Therefore, the correct tag is \"does she?\"."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 17,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13320,
        "content": [
          "does she"
        ],
        "isCorrect": true
      },
      {
        "id": 13321,
        "content": [
          "will she"
        ],
        "isCorrect": false
      },
      {
        "id": 13322,
        "content": [
          "don't she"
        ],
        "isCorrect": false
      },
      {
        "id": 13323,
        "content": [
          "won't she"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3329,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "I was ______ scared to go out in the dark alone. That is why I couldn't join you for dinner."
    ],
    "explanation": [
      "\"Absolutely\" is an intensifier often used with non-gradable adjectives like \"terrified\" or \"petrified\". While \"scared\" is gradable, \"absolutely\" is used colloquially to mean \"extremely\" or \"completely,\" fitting the context of being too scared to go out."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 18,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13324,
        "content": [
          "definitely"
        ],
        "isCorrect": false
      },
      {
        "id": 13325,
        "content": [
          "certainly"
        ],
        "isCorrect": false
      },
      {
        "id": 13326,
        "content": [
          "absolutely"
        ],
        "isCorrect": true
      },
      {
        "id": 13327,
        "content": [
          "surely"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3330,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "We ______ study in small groups when we were in the secondary school."
    ],
    "explanation": [
      "The phrase \"used to\" followed by the base form of a verb is used to describe a habitual action or state in the past that is no longer true. This fits the context of reminiscing about secondary school habits."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 19,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13328,
        "content": [
          "had used"
        ],
        "isCorrect": false
      },
      {
        "id": 13329,
        "content": [
          "used to"
        ],
        "isCorrect": true
      },
      {
        "id": 13330,
        "content": [
          "have used to"
        ],
        "isCorrect": false
      },
      {
        "id": 13331,
        "content": [
          "were used to"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3331,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "You will repeat this course ______ you work harder; your last two test scores were unsatisfactory."
    ],
    "explanation": [
      "\"Unless\" means \"except if.\" The sentence means \"You will repeat this course except if you work harder.\" This sets up a condition that must be met to avoid the negative consequence."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 20,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13332,
        "content": [
          "unless"
        ],
        "isCorrect": true
      },
      {
        "id": 13333,
        "content": [
          "if"
        ],
        "isCorrect": false
      },
      {
        "id": 13334,
        "content": [
          "until"
        ],
        "isCorrect": false
      },
      {
        "id": 13335,
        "content": [
          "otherwise"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3332,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "I have read ______ I did last year; it has been a terribly busy year for me."
    ],
    "explanation": [
      "\"Fewer\" is the correct comparative adjective for countable nouns like \"books.\" The structure for comparison is \"fewer...than.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 21,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13336,
        "content": [
          "few books this year than"
        ],
        "isCorrect": false
      },
      {
        "id": 13337,
        "content": [
          "fewer books this year as"
        ],
        "isCorrect": false
      },
      {
        "id": 13338,
        "content": [
          "few books this year as"
        ],
        "isCorrect": false
      },
      {
        "id": 13339,
        "content": [
          "fewer books this year than"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3333,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "I don't have a long standing acquaintance with Lojo, but I already feel that I ______ her for years."
    ],
    "explanation": [
      "The verb \"know\" is a stative verb and is generally not used in the continuous tense. To express a feeling that started in the past and continues to the present, the present perfect tense \"have known\" is used."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 22,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13340,
        "content": [
          "have been knowing"
        ],
        "isCorrect": false
      },
      {
        "id": 13341,
        "content": [
          "have known"
        ],
        "isCorrect": true
      },
      {
        "id": 13342,
        "content": [
          "had known"
        ],
        "isCorrect": false
      },
      {
        "id": 13343,
        "content": [
          "knew"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3334,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "I cannot afford to go out this weekend; I have ______ assignments on my table."
    ],
    "explanation": [
      "\"Too many\" indicates an excessive quantity, which provides a reason for not being able to go out. \"Assignments\" is a countable noun, so \"many\" is used instead of \"much\"."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 23,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13344,
        "content": [
          "very many"
        ],
        "isCorrect": false
      },
      {
        "id": 13345,
        "content": [
          "very little"
        ],
        "isCorrect": false
      },
      {
        "id": 13346,
        "content": [
          "too few"
        ],
        "isCorrect": false
      },
      {
        "id": 13347,
        "content": [
          "too many"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3335,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "The witness was ______ biased that whatever he said was unbelievable."
    ],
    "explanation": [
      "The structure \"so + adjective + that\" is used to show a cause and effect relationship. The witness's high degree of bias (cause) resulted in his testimony being unbelievable (effect)."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 24,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13348,
        "content": [
          "such"
        ],
        "isCorrect": false
      },
      {
        "id": 13349,
        "content": [
          "so"
        ],
        "isCorrect": true
      },
      {
        "id": 13350,
        "content": [
          "as much"
        ],
        "isCorrect": false
      },
      {
        "id": 13351,
        "content": [
          "as such"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3336,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "Finally, I ______ marrying my classmate who I never talked to when we were in high school. Isn't this amazing!"
    ],
    "explanation": [
      "The phrasal verb \"ended up\" means to eventually reach or do something, often unexpectedly. It perfectly fits the context of an surprising final outcome like marrying an old classmate."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 25,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13352,
        "content": [
          "summed up"
        ],
        "isCorrect": false
      },
      {
        "id": 13353,
        "content": [
          "chose"
        ],
        "isCorrect": false
      },
      {
        "id": 13354,
        "content": [
          "wound up"
        ],
        "isCorrect": false
      },
      {
        "id": 13355,
        "content": [
          "ended up"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3337,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "My grade this semester is ______ than my first semester's."
    ],
    "explanation": [
      "The sentence uses \"than,\" which requires a comparative adjective. \"Better\" is the comparative form of \"good.\" \"Much\" is used to intensify the comparison."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 26,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13356,
        "content": [
          "best"
        ],
        "isCorrect": false
      },
      {
        "id": 13357,
        "content": [
          "much better"
        ],
        "isCorrect": true
      },
      {
        "id": 13358,
        "content": [
          "so much better"
        ],
        "isCorrect": false
      },
      {
        "id": 13359,
        "content": [
          "so good"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3338,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "______ English is much harder than speaking it."
    ],
    "explanation": [
      "The sentence needs a noun or gerund to act as the subject. \"Writing\" is a gerund (a verb form ending in -ing that functions as a noun) and correctly serves as the subject of the sentence."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 27,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13360,
        "content": [
          "Writing"
        ],
        "isCorrect": true
      },
      {
        "id": 13361,
        "content": [
          "Having writing"
        ],
        "isCorrect": false
      },
      {
        "id": 13362,
        "content": [
          "Getting writing"
        ],
        "isCorrect": false
      },
      {
        "id": 13363,
        "content": [
          "To write"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3339,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "I ______ the importance of hard work long before I joined university."
    ],
    "explanation": [
      "The sentence describes an action (realizing) that was completed before another past action (joined university). The past perfect tense \"had realized\" is used to show that one past event occurred before another past event."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 28,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13364,
        "content": [
          "was realizing"
        ],
        "isCorrect": false
      },
      {
        "id": 13365,
        "content": [
          "have realized"
        ],
        "isCorrect": false
      },
      {
        "id": 13366,
        "content": [
          "had been realizing"
        ],
        "isCorrect": false
      },
      {
        "id": 13367,
        "content": [
          "had realized"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3340,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "She has just had a haircut; she ______ 20 in this new hair style, doesn't she?"
    ],
    "explanation": [
      "“Looks as if she were 20” is the correct idiomatic and grammatical form for an unreal comparison."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 29,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13368,
        "content": [
          "as if she becomes"
        ],
        "isCorrect": false
      },
      {
        "id": 13369,
        "content": [
          "looks like"
        ],
        "isCorrect": false
      },
      {
        "id": 13370,
        "content": [
          "looks at"
        ],
        "isCorrect": false
      },
      {
        "id": 13371,
        "content": [
          "looks as if she were"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3341,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "There is no point in sitting and contemplating; ______ study hard, score a good grade and join the department of my choice."
    ],
    "explanation": [
      "This is a second conditional sentence used to give advice. The structure is \"If I were you, I would...\". \"I'd\" is the contraction of \"I would.\" The speaker is advising on the best course of action instead of contemplating."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 30,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13372,
        "content": [
          "if I were you, I can"
        ],
        "isCorrect": false
      },
      {
        "id": 13373,
        "content": [
          "if I were you, I'd"
        ],
        "isCorrect": true
      },
      {
        "id": 13374,
        "content": [
          "if I were you, I"
        ],
        "isCorrect": false
      },
      {
        "id": 13375,
        "content": [
          "if I were you, I will"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3342,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "Look, ______ books, newspapers, shoes and socks scattered everywhere on the floor; why don't you keep your room tidy?"
    ],
    "explanation": [
      "\"There are\" is used to indicate the existence or presence of plural items in a place. The sentence is pointing out that these items exist on the floor."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 31,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13376,
        "content": [
          "those are"
        ],
        "isCorrect": false
      },
      {
        "id": 13377,
        "content": [
          "these are"
        ],
        "isCorrect": false
      },
      {
        "id": 13378,
        "content": [
          "those were"
        ],
        "isCorrect": false
      },
      {
        "id": 13379,
        "content": [
          "there are"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3343,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "Why should some people expect to be given food ______ clothes for free?"
    ],
    "explanation": [
      "\"As well as\" is a conjunction used to mean \"in addition to.\" It correctly links the two items, \"food\" and \"clothes,\" that people expect to be given."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 32,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13380,
        "content": [
          "as well as"
        ],
        "isCorrect": true
      },
      {
        "id": 13381,
        "content": [
          "so well as"
        ],
        "isCorrect": false
      },
      {
        "id": 13382,
        "content": [
          "in accordance with"
        ],
        "isCorrect": false
      },
      {
        "id": 13383,
        "content": [
          "in spite of"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3344,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "Can you guess what ______ in this room now?"
    ],
    "explanation": [
      "The word \"now\" indicates a present, ongoing action. Since \"what\" is the object of the action (something is being done), the passive voice is required. \"Is being done\" is the present continuous passive form."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 33,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13384,
        "content": [
          "is being done"
        ],
        "isCorrect": true
      },
      {
        "id": 13385,
        "content": [
          "is doing"
        ],
        "isCorrect": false
      },
      {
        "id": 13386,
        "content": [
          "is being doing"
        ],
        "isCorrect": false
      },
      {
        "id": 13387,
        "content": [
          "has been doing"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3345,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "You can borrow my new book, but you ______ show it to anybody in your class."
    ],
    "explanation": [
      "\"Mustn't\" is used to express strong prohibition or a rule. It means that showing the book to others is not allowed."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 34,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13388,
        "content": [
          "don't"
        ],
        "isCorrect": false
      },
      {
        "id": 13389,
        "content": [
          "needn't"
        ],
        "isCorrect": false
      },
      {
        "id": 13390,
        "content": [
          "won't"
        ],
        "isCorrect": false
      },
      {
        "id": 13391,
        "content": [
          "mustn't"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3346,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "I have no time to spare! I will ______ myself a sandwich and get back to work quickly."
    ],
    "explanation": [
      "The verb \"make\" is commonly used with food that is assembled or prepared quickly, such as a sandwich, a salad, or a cup of tea."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 35,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13392,
        "content": [
          "make"
        ],
        "isCorrect": true
      },
      {
        "id": 13393,
        "content": [
          "do"
        ],
        "isCorrect": false
      },
      {
        "id": 13394,
        "content": [
          "prepare"
        ],
        "isCorrect": false
      },
      {
        "id": 13395,
        "content": [
          "cook"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3347,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "Which one is ______, a lemon or a blueberry?"
    ],
    "explanation": [
      "The sentence is comparing two items (a lemon and a blueberry). The comparative form of the adjective \"bitter\" is \"more bitter.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 36,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13396,
        "content": [
          "more bitter"
        ],
        "isCorrect": true
      },
      {
        "id": 13397,
        "content": [
          "the more the better"
        ],
        "isCorrect": false
      },
      {
        "id": 13398,
        "content": [
          "the most bitter"
        ],
        "isCorrect": false
      },
      {
        "id": 13399,
        "content": [
          "the better bitter"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3348,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "Which of the following questions expects Jimma is 350 kilometers away from Addis Ababa as the best answer?"
    ],
    "explanation": [
      "The answer \"350 kilometers away\" specifies a distance. The question \"How far...?\" is used to ask about distance."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 37,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13400,
        "content": [
          "How long is Jimma from Addis Ababa?"
        ],
        "isCorrect": false
      },
      {
        "id": 13401,
        "content": [
          "Is Jimma 350 kilometers away from Addis Ababa?"
        ],
        "isCorrect": false
      },
      {
        "id": 13402,
        "content": [
          "Is 350 kilometers the distance of Jimma from Addis Ababa?"
        ],
        "isCorrect": false
      },
      {
        "id": 13403,
        "content": [
          "How far is Jimma from Addis Ababa?"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3349,
    "content": [
      "Choose the word or phrase that best completes the sentence.",
      "---",
      "Hana met Solomon in the corridor and asked him, \"______ for someone?\" He answered, \"Yes, I wanted to speak to Hilina; she isn't in her office.\""
    ],
    "explanation": [
      "To ask about an action happening at the moment of speaking, the present continuous tense is used. \"Are you looking\" is the correct question form for this tense."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_LANGUAGE_FOCUS",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 126,
    "groupIndex": 38,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13404,
        "content": [
          "Do you look"
        ],
        "isCorrect": false
      },
      {
        "id": 13405,
        "content": [
          "Are you looking"
        ],
        "isCorrect": true
      },
      {
        "id": 13406,
        "content": [
          "You look"
        ],
        "isCorrect": false
      },
      {
        "id": 13407,
        "content": [
          "Have you looked"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3350,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which of the following is an example of non-recyclable material?"
    ],
    "explanation": [
      "Paragraph 2 explicitly states, \"While newspapers are recyclable, their glossy, colored inserts are not.\" Junk mail inserts are often glossy and colored."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 1,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13408,
        "content": [
          "junk mail inserts"
        ],
        "isCorrect": true
      },
      {
        "id": 13409,
        "content": [
          "paper bags"
        ],
        "isCorrect": false
      },
      {
        "id": 13410,
        "content": [
          "newspapers"
        ],
        "isCorrect": false
      },
      {
        "id": 13411,
        "content": [
          "egg cartons"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3351,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Recycled paper can be used to make one of the following products. Which one is it?"
    ],
    "explanation": [
      "Paragraph 3 lists several products made from recycled paper, including \"food and clothing boxes.\" Paragraph 2 also mentions \"some food packaging can all be recycled.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 2,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13412,
        "content": [
          "chemicals"
        ],
        "isCorrect": false
      },
      {
        "id": 13413,
        "content": [
          "wax"
        ],
        "isCorrect": false
      },
      {
        "id": 13414,
        "content": [
          "cleaner-burning fuels"
        ],
        "isCorrect": false
      },
      {
        "id": 13415,
        "content": [
          "food packaging can"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3352,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which word used in paragraph 2 refers to a site for sanitary waste disposal?"
    ],
    "explanation": [
      "A landfill is a designated site for the disposal of waste materials by burial. Paragraph 2 mentions that the majority of used paper \"ends up in the landfills.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 3,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13416,
        "content": [
          "landfill"
        ],
        "isCorrect": true
      },
      {
        "id": 13417,
        "content": [
          "cellophane"
        ],
        "isCorrect": false
      },
      {
        "id": 13418,
        "content": [
          "plain"
        ],
        "isCorrect": false
      },
      {
        "id": 13419,
        "content": [
          "particles"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3353,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Why is the process of manufacturing recycled paper better for the environment than the process of new paper manufacturing is?"
    ],
    "explanation": [
      "Paragraph 5 states that manufacturing recycled paper \"uses less water, fewer trees and causes less pollution\" than making paper from new pulp."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 4,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13420,
        "content": [
          "The by-product of the recycled paper manufacturing process is sludge."
        ],
        "isCorrect": false
      },
      {
        "id": 13421,
        "content": [
          "The former releases treated wastes."
        ],
        "isCorrect": false
      },
      {
        "id": 13422,
        "content": [
          "The waste of the recycled paper manufacturing can be added to construction materials."
        ],
        "isCorrect": false
      },
      {
        "id": 13423,
        "content": [
          "The process does not require as much water as is required in new paper manufacturing."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3354,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which of the following can be the best title for the passage?"
    ],
    "explanation": [
      "The passage discusses the problems of paper pollution and waste, but its main focus is on recycling as a solution, detailing what can be recycled, the products made from it, and its environmental benefits. Therefore, \"Recycling Paper\" is the most encompassing title."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 5,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13424,
        "content": [
          "Paper Pollution"
        ],
        "isCorrect": false
      },
      {
        "id": 13425,
        "content": [
          "Recycling Paper"
        ],
        "isCorrect": true
      },
      {
        "id": 13426,
        "content": [
          "Recyclable and Unrecyclable Things"
        ],
        "isCorrect": false
      },
      {
        "id": 13427,
        "content": [
          "Paper Manufacturing"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3355,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Why is paper considered as an environmental problem by paper manufacturers themselves?"
    ],
    "explanation": [
      "Paragraph 1 discusses the pollution caused by paper manufacturing, including releasing \"untreated production wastes, such as chemicals, into nearby streams and rivers.\" This is a problem directly caused by the manufacturers."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 6,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13428,
        "content": [
          "Much of the paper produced cannot be recycled."
        ],
        "isCorrect": false
      },
      {
        "id": 13429,
        "content": [
          "Much of the paper produced is dumped into landfills."
        ],
        "isCorrect": false
      },
      {
        "id": 13430,
        "content": [
          "Much of the paper produced, if not recycled, is dumped into landfill."
        ],
        "isCorrect": false
      },
      {
        "id": 13431,
        "content": [
          "Many paper companies release untreated wastes."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3356,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which of the statements below is true about cleaner-burning fuels?"
    ],
    "explanation": [
      "Paragraph 1 states, \"Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 7,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13432,
        "content": [
          "They reduce the amount of sulfur dioxide produced."
        ],
        "isCorrect": true
      },
      {
        "id": 13433,
        "content": [
          "They pollute the landfills."
        ],
        "isCorrect": false
      },
      {
        "id": 13434,
        "content": [
          "They make many paper packaging unrecyclable."
        ],
        "isCorrect": false
      },
      {
        "id": 13435,
        "content": [
          "They affect the growth of trees and plants."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3357,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which of the following is true according to paragraph 2?"
    ],
    "explanation": [
      "Paragraph 2 begins, \"Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem.\" This directly names these three things as concerns."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 8,
    "sharedContentId": 34,
    "sharedContent": [
      "1. Manufacturing paper pollutes the air and the water. Fortunately, new technology has made it possible for paper manufacturers to reduce the amount of pollution they make. Many paper companies have reduced the amount of sulfur dioxide emitted during production by switching to cleaner-burning fuels. When a sulfur dioxide mixes with the nitrogen and moisture in the air, they combine to form acid-rain. When acid-rain falls to earth, it affects the growth of trees and plants and can kill all forms of life in lakes. Paper manufacturers have also worked to reduce the water pollution caused by releasing untreated production wastes, such as chemicals, into nearby streams and rivers.",
      "2. Particles and chemicals are not the only environmental concerns of the paper industry. The paper they produce is a growing environmental problem. Americans use over 67 million tons of paper a year, and the majority of it ends up in the landfills. One way to keep so much paper from filling the landfills is to recycle it. A lot of paper we use is recyclable. Plain or office paper, corrugated cardboard, newspapers, and some food packaging can all be recycled. Unfortunately, a lot of things that you might think are recyclable are not. Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable. Most junk mail isn't recyclable. While newspapers are recyclable, their glossy, colored inserts are not.",
      "3. Recycled paper can be used to make products such as newspapers, egg cartons, paper bags, tissues, food and clothing boxes and corrugated boxes. In addition, recycled paper can also be used to make cardboard displays, building insulation and roofing material.",
      "4. Even the \"waste\" left over after recycling paper may be recycled. Manufacturing recycled paper produces by-product called \"sludge.\" It is expected that sludge can be used as a soil conditioner. Spreading it on farm and forest land can add important nutrients to the soil. It can be similarly used to line and cover landfills. It can even be burned and used for energy.",
      "5. In addition to all this, the process involved in manufacturing recycled paper is better for the environment. It uses less water, fewer trees and causes less pollution than manufacturing paper with virgin (new) pulp. Air pollution may be reduced as much as 74 percent, and water pollution as much as 35 percent.",
      "Source: Adapted from James Vincent E. & Kuetemeyer. 1997. Technology\nToday and Tomorrow. Gencoe/McGraw-Hill."
    ],
    "images": [],
    "choices": [
      {
        "id": 13436,
        "content": [
          "Particles, wax-coated cellophane and chemicals are the environmental concerns of the paper industry."
        ],
        "isCorrect": false
      },
      {
        "id": 13437,
        "content": [
          "Cleaner burning fuels, chemicals and the paper produced are the environmental concerns of the paper industry."
        ],
        "isCorrect": false
      },
      {
        "id": 13438,
        "content": [
          "The paper produced, particles and chemicals are the environmental concerns of the paper industry."
        ],
        "isCorrect": true
      },
      {
        "id": 13439,
        "content": [
          "Chemicals, corrugated cardboard and the paper produced are the environmental concerns of the paper industry."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3358,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "What does them as used in This makes them non-recyclable... (Paragraph 2) refer to?"
    ],
    "explanation": [
      "In paragraph 2 of the passage, the sentence says \"Many kinds of paper packaging contain wax or wax-coated cellophane. This makes them non-recyclable.\" The pronoun \"them\" clearly refers to \"Many kinds of paper packaging.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 9,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13440,
        "content": [
          "kinds of paper packaging"
        ],
        "isCorrect": true
      },
      {
        "id": 13441,
        "content": [
          "food packaging"
        ],
        "isCorrect": false
      },
      {
        "id": 13442,
        "content": [
          "newspapers"
        ],
        "isCorrect": false
      },
      {
        "id": 13443,
        "content": [
          "corrugated boxes"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3359,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which of the following is similar in meaning to glossy as used in paragraph 2?"
    ],
    "explanation": [
      "In paragraph 2 of the passage, \"glossy\" describes the inserts in newspapers. Glossy means having a shiny, smooth surface. \"Smooth\" is the closest synonym."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 127,
    "groupIndex": 10,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13444,
        "content": [
          "soft"
        ],
        "isCorrect": false
      },
      {
        "id": 13445,
        "content": [
          "smooth"
        ],
        "isCorrect": true
      },
      {
        "id": 13446,
        "content": [
          "rough"
        ],
        "isCorrect": false
      },
      {
        "id": 13447,
        "content": [
          "harsh"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3360,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Of the words given below, which one from paragraph 3 can be replaced by dislike?"
    ],
    "explanation": [
      "Paragraph 3 states, \"Trappist monks abhor the taking of life...\" To abhor something means to regard it with disgust and hatred, which is a very strong form of dislike."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 1,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13448,
        "content": [
          "exploit"
        ],
        "isCorrect": false
      },
      {
        "id": 13449,
        "content": [
          "impose"
        ],
        "isCorrect": false
      },
      {
        "id": 13450,
        "content": [
          "abhor"
        ],
        "isCorrect": true
      },
      {
        "id": 13451,
        "content": [
          "prohibit"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3361,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which statement is true according to paragraph 4?"
    ],
    "explanation": [
      "Paragraph 4 describes \"enforced vegetarianism\" in Africa and Asia due to the high cost of meat. It then states that \"About eighteen per cent of the world's populations... eat less than 10g... of animal protein,\" which is a form of enforced vegetarianism due to economic reasons."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 2,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13452,
        "content": [
          "In Africa and Asia, the cost of meat is seldom beyond what the poor can afford to buy."
        ],
        "isCorrect": false
      },
      {
        "id": 13453,
        "content": [
          "Vegetarianism has become a matter of individual choice in Africa and Asia."
        ],
        "isCorrect": false
      },
      {
        "id": 13454,
        "content": [
          "Followers of the Ethiopian Coptic church abhor the taking of life on more than 200 days."
        ],
        "isCorrect": false
      },
      {
        "id": 13455,
        "content": [
          "Enforced vegetarianism is common among eighteen percent of the world's population."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3362,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which of the following is the consequence of the spread of wealth in Europe and the West?"
    ],
    "explanation": [
      "Paragraph 5 states, \"But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing.\" \"Affluence\" means wealth."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 3,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13456,
        "content": [
          "an increase in the mount of vegetable eaten"
        ],
        "isCorrect": false
      },
      {
        "id": 13457,
        "content": [
          "an increase in enforced vegetarianism"
        ],
        "isCorrect": false
      },
      {
        "id": 13458,
        "content": [
          "an increase in the amount of animal protein eaten"
        ],
        "isCorrect": true
      },
      {
        "id": 13459,
        "content": [
          "a decrease in the amount of animal protein produced"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3363,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Why are 'voluntary vegetarians' mentioned in paragraph 5 in the passage?"
    ],
    "explanation": [
      "Paragraph 5 contrasts the \"economic necessity\" of enforced vegetarianism (paragraph 4) with the situation in the West, stating, \"Vegetarianism in the West is therefore less than a matter of economic necessity than of choice.\" The 'voluntary vegetarians' are an example of this choice, not necessity."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 4,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13460,
        "content": [
          "to disprove the belief that there is an increase in the amount of animal protein eaten in the average diet"
        ],
        "isCorrect": false
      },
      {
        "id": 13461,
        "content": [
          "to support the author's argument against animal protein in one's diet"
        ],
        "isCorrect": false
      },
      {
        "id": 13462,
        "content": [
          "to supplement the author's argument against the consequence of an increase in affluence"
        ],
        "isCorrect": false
      },
      {
        "id": 13463,
        "content": [
          "to indicate that economic necessity is no longer significant in choosing what to eat"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3364,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which of the following can be the best title for the passage?"
    ],
    "explanation": [
      "The passage covers many aspects of vegetarianism, including its supposed evolutionary roots, cultural and religious reasons, economic enforcement, voluntary choice, and its extreme form, veganism. \"Vegetarianism\" is the broad title that encompasses all these topics."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 5,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13464,
        "content": [
          "Voluntary Vegetarianism"
        ],
        "isCorrect": false
      },
      {
        "id": 13465,
        "content": [
          "Vegetarianism"
        ],
        "isCorrect": true
      },
      {
        "id": 13466,
        "content": [
          "Enforced Vegetarianism"
        ],
        "isCorrect": false
      },
      {
        "id": 13467,
        "content": [
          "Becoming a Vegetarian"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3365,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "As used in paragraph 1, which word from those given below is similar in meaning to gorge?"
    ],
    "explanation": [
      "Paragraph 1 says, \"We cannot gorge ourselves on meat...\" To gorge means to eat a large amount greedily. \"Stuff\" oneself is a common, informal synonym for this action."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 6,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13468,
        "content": [
          "gather"
        ],
        "isCorrect": false
      },
      {
        "id": 13469,
        "content": [
          "stuff"
        ],
        "isCorrect": true
      },
      {
        "id": 13470,
        "content": [
          "hunt"
        ],
        "isCorrect": false
      },
      {
        "id": 13471,
        "content": [
          "cheat"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3366,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which one of the following is true about carnivores as implied in paragraph 1?"
    ],
    "explanation": [
      "Paragraph 1 states that humans \"cannot gorge ourselves on meat and then go without eating for days as many carnivores do,\" implying that this is precisely what carnivores *can* do."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 6,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13472,
        "content": [
          "They hunt poultry and fish to get as much meat as they need."
        ],
        "isCorrect": false
      },
      {
        "id": 13473,
        "content": [
          "They have meat, poultry and fish as part of their everyday diet."
        ],
        "isCorrect": false
      },
      {
        "id": 13474,
        "content": [
          "They cannot eat tubers and seeds because of their teeth."
        ],
        "isCorrect": false
      },
      {
        "id": 13475,
        "content": [
          "They can eat much at a time and stay for days on that."
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3367,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Disheartening as used in paragraph 2 can be replaced with which one of the following words?"
    ],
    "explanation": [
      "Paragraph 2 says many people find the prospect of giving up meat \"disheartening.\" Something that is disheartening causes someone to lose determination or confidence. \"Depressing\" has a similar meaning of causing unhappiness and discouragement."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 7,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13476,
        "content": [
          "engraving"
        ],
        "isCorrect": false
      },
      {
        "id": 13477,
        "content": [
          "interesting"
        ],
        "isCorrect": false
      },
      {
        "id": 13478,
        "content": [
          "impressing"
        ],
        "isCorrect": false
      },
      {
        "id": 13479,
        "content": [
          "depressing"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3368,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Choose from those given below an example of the evolutionary argument referred to in paragraph 2."
    ],
    "explanation": [
      "Paragraph 2 refers back to \"Such evolutionary arguments\" from paragraph 1. Paragraph 1 provides examples like \"Our teeth evolved to deal with tubers and seeds, not flesh,\" which are characteristics of foragers. This makes \"foragers' teeth\" a direct example of the evolutionary argument."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 8,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13480,
        "content": [
          "going without eating for days"
        ],
        "isCorrect": false
      },
      {
        "id": 13481,
        "content": [
          "carnivores' teeth"
        ],
        "isCorrect": false
      },
      {
        "id": 13482,
        "content": [
          "foragers' teeth"
        ],
        "isCorrect": true
      },
      {
        "id": 13483,
        "content": [
          "hunters' digestive system"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3369,
    "content": [
      "Based on the passage, choose the best answer.",
      "---",
      "Which one of the following is a reason why vegetarianism eventually gained public acceptance?"
    ],
    "explanation": [
      "Paragraph 2 states that \"a habit that was once regarded as an eccentricity is gaining respect.\" Paragraphs 3 and 5 then list various reasons: philosophical, religious, moral, economic, and health. All of these contribute to an increased awareness of the potential benefits or reasons for vegetarianism."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_READING",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 128,
    "groupIndex": 9,
    "sharedContentId": 35,
    "sharedContent": [
      "1. Meat, poultry and fish were not originally part of man's diet. Our teeth evolved to deal with tubers and seeds, not flesh. Our digestive systems are those of foragers, not hunters. We cannot gorge ourselves on meat and then go without eating for days as many carnivores do.",
      "2. Such evolutionary arguments may seem a thin basis for adopting a vegetarian diet today, however. The fact is that meat is a highly concentrated form of nutriment. It is also among the most appetizing foods in the average diet. Its flavors and smells are so thoroughly woven into traditional Western way of eating that many people find the prospect of doing without it disheartening. Yet the evidence that vegetarianism is as a matter of individual choice is now spreading. For a variety of reasons, a habit that was once regarded as an eccentricity is gaining respect.",
      "3. A vegetarian diet may be adopted for any one of three reasons- the philosophy of the individual, range of foods that are available locally, or the religious beliefs of a particular community. Religions can impose varying degrees of vegetarianism. The Ethiopian Coptic Church, for example, prohibits meat on more than 200 days of the year. Trappist monks abhor the taking of life and are entirely vegetarian. Of the major world religions, both Hinduism and Buddhism have similar objections to exploiting other living creatures for food. Strict followers of these faiths are wholly or partly vegetarian.",
      "4. A form of enforced vegetarianism is common in many parts of Africa and Asia, where meat costs so much to produce that poorer people are seldom able to eat it. About eighteen per cent of the world's populations (excluding China) eat less than 10g (0.3oz) of animal protein per head per day- equivalent to two small eggs or one cup of milk.",
      "5. But with the spread of affluence, the amount of animal protein eaten in the average diet is increasing. Vegetarianism in the West is therefore less than a matter of economic necessity than of choice. The number of voluntary vegetarians in Europe and the US is estimated at several million. Some are motivated by aesthetic or moral ideas; they deplore the killing of animals and some of the methods of raising them for food. Some base their choice on economics; it is more efficient to use land for growing food directly than for feeding animals. Still others simply believe a vegetarian diet is healthier.",
      "6. An extreme form of vegetarianism is veganism. The Charter of the Vegan Society says that 'Veganism is a way of living which excludes all forms of exploitation of, and cruelty to, the animal kingdom and includes a reverence and compassion for all life.' In practice, the vegan excludes from his diet not only meat, poultry and fish but also animal milk and other derivates such as eggs and honey. Soya-based plant-milks are substituted for cow's milk and equally nutritious. Extending the vegan philosophy to clothing, vegans use plastics for rubber and PVC instead of leather jackets, belts or shoes."
    ],
    "images": [],
    "choices": [
      {
        "id": 13484,
        "content": [
          "increase in our awareness of the benefits of vegetarianism"
        ],
        "isCorrect": true
      },
      {
        "id": 13485,
        "content": [
          "decline in the flavors and smell of meat"
        ],
        "isCorrect": false
      },
      {
        "id": 13486,
        "content": [
          "increase in our understanding of the appetizing nature of meat"
        ],
        "isCorrect": false
      },
      {
        "id": 13487,
        "content": [
          "decline in the spread of a concentrated form of nutrient"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3370,
    "content": [
      "Choose the sentence that is closest in meaning to the given sentence.",
      "---",
      "Both public and private authorities can manage transportation systems, which can involve maintaining and updating infrastructure to ensure the system runs smoothly."
    ],
    "explanation": [
      "The original sentence states that maintaining/updating infrastructure is done \"to ensure the system runs smoothly.\" This choice correctly identifies that the purpose of the maintenance and updates is the smooth operation of the transportation system itself."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_SENTENCE_COMPREHENSION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 129,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13488,
        "content": [
          "Maintaining and updating infrastructure ensures public and private authorities run smoothly."
        ],
        "isCorrect": false
      },
      {
        "id": 13489,
        "content": [
          "Public and private authorities ensure updating infrastructure runs smoothly."
        ],
        "isCorrect": false
      },
      {
        "id": 13490,
        "content": [
          "Maintaining and updating infrastructure ensures the transportation systems run smoothly."
        ],
        "isCorrect": true
      },
      {
        "id": 13491,
        "content": [
          "Maintaining and updating infrastructure can be managed by public and private authorities."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3371,
    "content": [
      "Choose the sentence that is closest in meaning to the given sentence.",
      "---",
      "In the West or in Europe, there is a great variety of food for people to buy if they want to."
    ],
    "explanation": [
      "The statement that there is \"a great variety of food for people to buy\" directly implies that there is an abundance of food available and a lack of scarcity. This is the definition of \"no food shortage.\""
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_SENTENCE_COMPREHENSION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 129,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13492,
        "content": [
          "There is no food shortage in the West or in Europe."
        ],
        "isCorrect": true
      },
      {
        "id": 13493,
        "content": [
          "People in the West or in Europe want a great variety of food."
        ],
        "isCorrect": false
      },
      {
        "id": 13494,
        "content": [
          "There is no need for a great variety of food in the West or in Europe."
        ],
        "isCorrect": false
      },
      {
        "id": 13495,
        "content": [
          "People in the West or in Europe buy a great variety of food."
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3372,
    "content": [
      "Choose the word that best completes the sentence.",
      "---",
      "Ethiopia is working hard towards strengthening its ______ relations with many countries."
    ],
    "explanation": [
      "\"Diplomatic relations\" is the standard term for the formal relationships and interactions between countries."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_COMPLETION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 130,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13496,
        "content": [
          "dramatic"
        ],
        "isCorrect": false
      },
      {
        "id": 13497,
        "content": [
          "aromatic"
        ],
        "isCorrect": false
      },
      {
        "id": 13498,
        "content": [
          "diplomatic"
        ],
        "isCorrect": true
      },
      {
        "id": 13499,
        "content": [
          "automatic"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3373,
    "content": [
      "Choose the word that best completes the sentence.",
      "---",
      "Worldwide, a large number of organizations ______ children who have lost their parents in death."
    ],
    "explanation": [
      "To \"foster\" means to encourage the development of something. In the context of children, it often means to care for a child as one's own, which is a common role for organizations that support orphans."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_COMPLETION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 130,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13500,
        "content": [
          "offer"
        ],
        "isCorrect": false
      },
      {
        "id": 13501,
        "content": [
          "sponsor"
        ],
        "isCorrect": false
      },
      {
        "id": 13502,
        "content": [
          "foster"
        ],
        "isCorrect": true
      },
      {
        "id": 13503,
        "content": [
          "respect"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3374,
    "content": [
      "Choose the word that best completes the sentence.",
      "---",
      "Clean air ______ the well-being of people everywhere."
    ],
    "explanation": [
      "To \"sustain\" means to strengthen or support physically or mentally. Clean air is essential for life and health, so it sustains well-being."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_COMPLETION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 130,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13504,
        "content": [
          "differentiates"
        ],
        "isCorrect": false
      },
      {
        "id": 13505,
        "content": [
          "substantiates"
        ],
        "isCorrect": false
      },
      {
        "id": 13506,
        "content": [
          "sustains"
        ],
        "isCorrect": true
      },
      {
        "id": 13507,
        "content": [
          "maintains"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3375,
    "content": [
      "Choose the word that best completes the sentence.",
      "---",
      "Slapping small children on the face is a ______ act."
    ],
    "explanation": [
      "A \"cruel\" act is one that willfully causes pain or suffering to others. Slapping a child fits this definition."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_COMPLETION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 130,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13508,
        "content": [
          "compulsory"
        ],
        "isCorrect": false
      },
      {
        "id": 13509,
        "content": [
          "gentle"
        ],
        "isCorrect": false
      },
      {
        "id": 13510,
        "content": [
          "generous"
        ],
        "isCorrect": false
      },
      {
        "id": 13511,
        "content": [
          "cruel"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3376,
    "content": [
      "Choose the word that best completes the sentence.",
      "---",
      "The bad weather ______ our plan to travel to Dire-Dawa this afternoon."
    ],
    "explanation": [
      "To \"disrupt\" means to interrupt an event, activity, or process by causing a disturbance or problem. Bad weather can disrupt travel plans."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_COMPLETION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 130,
    "groupIndex": 5,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13512,
        "content": [
          "disturbed"
        ],
        "isCorrect": false
      },
      {
        "id": 13513,
        "content": [
          "disappointed"
        ],
        "isCorrect": false
      },
      {
        "id": 13514,
        "content": [
          "disrupted"
        ],
        "isCorrect": true
      },
      {
        "id": 13515,
        "content": [
          "dislodged"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3377,
    "content": [
      "Choose the word that best completes the sentence.",
      "---",
      "School buses should always be driven by a/an ______ driver."
    ],
    "explanation": [
      "A \"licensed\" driver is someone who has been officially granted a license, or permit, to drive, which is a legal requirement for driving, especially a school bus."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_COMPLETION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 130,
    "groupIndex": 6,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13516,
        "content": [
          "enthused"
        ],
        "isCorrect": false
      },
      {
        "id": 13517,
        "content": [
          "licensed"
        ],
        "isCorrect": true
      },
      {
        "id": 13518,
        "content": [
          "engaged"
        ],
        "isCorrect": false
      },
      {
        "id": 13519,
        "content": [
          "entrusted"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3378,
    "content": [
      "Choose the word that best completes the sentence.",
      "---",
      "These days, many of our old traditions have nearly become ______. One such example is paying dowry in marriage."
    ],
    "explanation": [
      "A tradition that has become \"extinct\" is one that no longer exists or is practiced. The word \"nearly\" indicates that it is very close to disappearing completely."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_COMPLETION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 130,
    "groupIndex": 7,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13520,
        "content": [
          "extra"
        ],
        "isCorrect": false
      },
      {
        "id": 13521,
        "content": [
          "external"
        ],
        "isCorrect": false
      },
      {
        "id": 13522,
        "content": [
          "excise"
        ],
        "isCorrect": false
      },
      {
        "id": 13523,
        "content": [
          "extinct"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3379,
    "content": [
      "Choose the word that best completes the sentence.",
      "---",
      "Many children are often reported missing; you should teach your child not to talk to a ______."
    ],
    "explanation": [
      "A \"stranger\" is a person whom one does not know. A common safety rule taught to children is not to talk to strangers."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_COMPLETION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 130,
    "groupIndex": 8,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13524,
        "content": [
          "saboteur"
        ],
        "isCorrect": false
      },
      {
        "id": 13525,
        "content": [
          "smuggler"
        ],
        "isCorrect": false
      },
      {
        "id": 13526,
        "content": [
          "sniffer"
        ],
        "isCorrect": false
      },
      {
        "id": 13527,
        "content": [
          "stranger"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3380,
    "content": [
      "Choose the alternative that best replaces the meaning of the BOLDED AND CAPITALIZED word or phrase.",
      "---",
      "Seventy is a **COMPULSORY** retirement age in some developed countries. Do you mean they are to retire at the age of 70?"
    ],
    "explanation": [
      "\"Compulsory\" means required by law or a rule; obligatory. Therefore, people are \"forced\" or required to retire at that age."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_SUBSTITUTION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 131,
    "groupIndex": 1,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13528,
        "content": [
          "guided"
        ],
        "isCorrect": false
      },
      {
        "id": 13529,
        "content": [
          "advised"
        ],
        "isCorrect": false
      },
      {
        "id": 13530,
        "content": [
          "rebuked"
        ],
        "isCorrect": false
      },
      {
        "id": 13531,
        "content": [
          "forced"
        ],
        "isCorrect": true
      }
    ]
  },
  {
    "id": 3381,
    "content": [
      "Choose the alternative that best replaces the meaning of the BOLDED AND CAPITALIZED word or phrase.",
      "---",
      "There was a **CHEERFUL** receptionist at the hotel; she always enjoyed amusing her guests."
    ],
    "explanation": [
      "\"Cheerful\" means noticeably happy and optimistic. A person who is cheerful is generally also warm and \"friendly\" in their demeanor."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_SUBSTITUTION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 131,
    "groupIndex": 2,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13532,
        "content": [
          "hopeful"
        ],
        "isCorrect": false
      },
      {
        "id": 13533,
        "content": [
          "mournful"
        ],
        "isCorrect": false
      },
      {
        "id": 13534,
        "content": [
          "friendly"
        ],
        "isCorrect": true
      },
      {
        "id": 13535,
        "content": [
          "thoughtful"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3382,
    "content": [
      "Choose the alternative that best replaces the meaning of the BOLDED AND CAPITALIZED word or phrase.",
      "---",
      "The use of real life situations made the activity so **INTERACTIVE** that everyone in the class loved it."
    ],
    "explanation": [
      "An \"interactive\" activity is one that involves communication and action between people. \"Participatory\" means characterized by participation, which has the same core meaning of active involvement."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_SUBSTITUTION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 131,
    "groupIndex": 3,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13536,
        "content": [
          "fascinating"
        ],
        "isCorrect": false
      },
      {
        "id": 13537,
        "content": [
          "participatory"
        ],
        "isCorrect": true
      },
      {
        "id": 13538,
        "content": [
          "distributive"
        ],
        "isCorrect": false
      },
      {
        "id": 13539,
        "content": [
          "argumentative"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3383,
    "content": [
      "Choose the alternative that best replaces the meaning of the BOLDED AND CAPITALIZED word or phrase.",
      "---",
      "There is no point in complaining about his **IMMATURE** behavior; he is always nagging his girlfriend over trivial points."
    ],
    "explanation": [
      "\"Immature\" behavior means acting in a way that is not fully developed or is typical of someone younger. \"Childlike\" directly conveys this meaning of behaving like a child."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_SUBSTITUTION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 131,
    "groupIndex": 4,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13540,
        "content": [
          "young"
        ],
        "isCorrect": false
      },
      {
        "id": 13541,
        "content": [
          "premature"
        ],
        "isCorrect": false
      },
      {
        "id": 13542,
        "content": [
          "childlike"
        ],
        "isCorrect": true
      },
      {
        "id": 13543,
        "content": [
          "grown-up"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3384,
    "content": [
      "Choose the alternative that best replaces the meaning of the BOLDED AND CAPITALIZED word or phrase.",
      "---",
      "The police arrested the man who often has his lunch at this afternoon and **MAKES OFF**."
    ],
    "explanation": [
      "The phrasal verb \"makes off\" means to leave hurriedly, especially in order to escape. \"Leaves in haste\" is a direct synonym."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_SUBSTITUTION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 131,
    "groupIndex": 5,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13544,
        "content": [
          "leaves slowly"
        ],
        "isCorrect": false
      },
      {
        "id": 13545,
        "content": [
          "leaves in haste"
        ],
        "isCorrect": true
      },
      {
        "id": 13546,
        "content": [
          "snores"
        ],
        "isCorrect": false
      },
      {
        "id": 13547,
        "content": [
          "sleeps"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3385,
    "content": [
      "Choose the alternative that best replaces the meaning of the BOLDED AND CAPITALIZED word or phrase.",
      "---",
      "Our population size has tremendously **SWELLED** over the last few decades. Do you know why?"
    ],
    "explanation": [
      "To \"swell\" in this context means to become larger or greater in amount. \"Increased\" is a direct synonym for this meaning."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_SUBSTITUTION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 131,
    "groupIndex": 6,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13548,
        "content": [
          "leaped"
        ],
        "isCorrect": false
      },
      {
        "id": 13549,
        "content": [
          "escaped"
        ],
        "isCorrect": false
      },
      {
        "id": 13550,
        "content": [
          "increased"
        ],
        "isCorrect": true
      },
      {
        "id": 13551,
        "content": [
          "jumped"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3386,
    "content": [
      "Choose the alternative that best replaces the meaning of the BOLDED AND CAPITALIZED word or phrase.",
      "---",
      "Regular exercises and balanced diet have many **BENEFICIAL** health effects."
    ],
    "explanation": [
      "\"Beneficial\" means favorable or advantageous; resulting in good. Something that is \"useful\" serves a good purpose and provides a benefit."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_SUBSTITUTION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 131,
    "groupIndex": 7,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13552,
        "content": [
          "useful"
        ],
        "isCorrect": true
      },
      {
        "id": 13553,
        "content": [
          "benevolent"
        ],
        "isCorrect": false
      },
      {
        "id": 13554,
        "content": [
          "benign"
        ],
        "isCorrect": false
      },
      {
        "id": 13555,
        "content": [
          "operational"
        ],
        "isCorrect": false
      }
    ]
  },
  {
    "id": 3387,
    "content": [
      "Choose the alternative that best replaces the meaning of the BOLDED AND CAPITALIZED word or phrase.",
      "---",
      "Zeineb **TOOK AFTER** her mother; she was as intolerant of liars as her mother was."
    ],
    "explanation": [
      "The phrasal verb \"took after\" means to resemble a parent or ancestor in appearance or character. \"Resembled\" is a direct synonym."
    ],
    "year": "YEAR_2015",
    "subject": "ENGLISH_SOCIAL",
    "chapter": "ENG_VOCABULARY_SUBSTITUTION",
    "field": "SOCIAL",
    "isGrouped": true,
    "groupId": 131,
    "groupIndex": 8,
    "sharedContentId": null,
    "sharedContent": null,
    "images": [],
    "choices": [
      {
        "id": 13556,
        "content": [
          "preserved"
        ],
        "isCorrect": false
      },
      {
        "id": 13557,
        "content": [
          "resembled"
        ],
        "isCorrect": true
      },
      {
        "id": 13558,
        "content": [
          "resumed"
        ],
        "isCorrect": false
      },
      {
        "id": 13559,
        "content": [
          "reassembled"
        ],
        "isCorrect": false
      }
    ]
  }
];
export default questions;
